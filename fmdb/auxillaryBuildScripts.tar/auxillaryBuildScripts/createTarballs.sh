#!/bin/bash -ex

create_tarballs() {
  if [ "x$1" == "x1" ]; then
    echo "Creating $2 Tarball"
    make dist
  fi
}
