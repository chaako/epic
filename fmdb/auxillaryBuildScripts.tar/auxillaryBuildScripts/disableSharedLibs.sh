#!/bin/bash -ex
disable_shared_libs() {
   if [ "x$1" == "x1" ]
   then
     echo "disabling shared libraries"
     SHARED_LIBS="--disable-shared"
   else
     echo "shared libraries enabled"
     SHARED_LIBS="--enable-shared"
   fi
   echo "Variable \'SHARED_LIBS\' set to $SHARED_LIBS"
}
