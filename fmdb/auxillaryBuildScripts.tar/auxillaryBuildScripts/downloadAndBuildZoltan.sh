#!/bin/bash -ex

download_and_build_zoltan() {
   SCRIPT_HOME=$PWD
   PARMETIS_HOME=$1
   echo "Creating a directory for Zoltan"
   if [ ! -e "$PARMETIS_HOME/parmetis.h" ] &&
      [ ! -e "$PARMETIS_HOME/libparmetis.a" ]; then
     echo "ERROR: $PARMETIS_HOME/parmetis.h and $PARMETIS_HOME/libparmetis.a required for Zoltan build"
     return 1
   fi

   if [ ! -e zoltan ]; then 
     mkdir zoltan
   fi
   cd zoltan
   set +e
   wget -T 20 http://www.cs.sandia.gov/~kddevin/Zoltan_Distributions/zoltan_distrib_v3.1.tar.gz
   if [ ! -f zoltan_distrib_v3.1.tar.gz ]; then
     wget http://www.scorec.rpi.edu/~cwsmith/zoltan/zoltan_distrib_v3.1.tar.gz
     if [ ! -f zoltan_distrib_v3.1.tar.gz ]; then
       echo 'failed to download zoltan'
       return 1
     fi
   fi
   set -e
   echo "Downloading Zoltan"
   tar -xzf zoltan_distrib_v3.1.tar.gz
   cd Zoltan_v3.1
   if [ ! -e build ]; then 
     mkdir build
   fi
   cd build

   echo "Building Zoltan"
   ../configure $SHARED_LIBS --enable-mpi --disable-examples --with-gnumake --with-parmetis --with-parmetis-libdir=$PARMETIS_HOME --with-parmetis-incdir=$PARMETIS_HOME --prefix=$SCRIPT_HOME/zoltan/Zoltan_v3.1-install
   make everything
   make install

   export ZOLTAN_HOME=$SCRIPT_HOME/zoltan/Zoltan_v3.1-install
   echo "Variable \'ZOLTAN_HOME\' set to $ZOLTAN_HOME"
}

