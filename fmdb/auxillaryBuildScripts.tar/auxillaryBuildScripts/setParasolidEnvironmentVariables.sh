#!/bin/bash -ex

set_parasolid_environment_variables() {
   HOSTNAME=`hostname`
   echo "setting parasolid environment for $HOSTNAME"
   case "x$HOSTNAME" in
      xremus* | xmonopoly.scorec.rpi.edu* | xromulus* | xothello* ) export PARASOLID=/usr/local/parasolid/latest;
	 export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$PARASOLID/shared_object/;
	 export P_LIST=$PARASOLID/lispdata;
	 export P_SCHEMA=$PARASOLID/schema;;
      * ) echo "********$HOSTNAME NOT SUPPORTED**************";;
   esac
}



