#!/bin/bash -ex

download_and_build_parmetis() {
  echo "Creating a directory for ParMETIS"
  if [ ! -e parmetis ]; then
     mkdir parmetis
  fi
  cd parmetis
  echo "Downloading ParMETIS"
  set +e
  wget -T 20 http://glaros.dtc.umn.edu/gkhome/fetch/sw/parmetis/ParMetis-3.1.1.tar.gz    
  if [ ! -f ParMetis-3.1.1.tar.gz ]; then
    wget http://www.scorec.rpi.edu/~cwsmith/parmetis/ParMetis-3.1.1.tar.gz
    if [ ! -f ParMetis-3.1.1.tar.gz ]; then
      echo 'failed to download parmetis'
      return 1
    fi
  fi
  set -e
  tar -xzf ParMetis-3.1.1.tar.gz
  cd ParMetis-3.1.1
  export PARMETIS_HOME=$PWD

  echo "Building ParMETIS"
  make CC=$CC
  echo "Variable \'PARMETIS_HOME\' set to $PARMETIS_HOME"
}
