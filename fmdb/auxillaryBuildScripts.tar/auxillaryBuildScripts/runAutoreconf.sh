#!/bin/bash -ex

run_autoreconf() {
   if [ "x$1" == "x1" ] && 
      [ ! -h m4 ]; then 
      ln -s $M4 
      autoreconf -fi
   fi
}
