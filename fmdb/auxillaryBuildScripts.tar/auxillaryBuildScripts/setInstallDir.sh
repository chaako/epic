#!/bin/bash -ex

set_install_dir() {
   if [ "$1" ]
   then
     echo "install directory specified as: $1"
     INSTALL_TARGET=$1
   else
     INSTALL_TARGET=$PWD
     echo "install directory not specified... default value set as: $INSTALL_TARGET"
   fi
}


