/*
Intersect triangle with line segment (coplanar case)
Can return up to 6 intersections (2 time 2 + 1 + 1)
*/

#include "MeshTools.h"

#define FALSE 0
#define TRUE  1

void MT_intTrianLine2(
 double t_xyz[3][3],
 double l_xyz[2][3],
 double tol,
 int level,
 int *int_nbr,
 double int_xyz[6][3]
)

{

 int side;
 int i;
 double L_XYZ[2][3];
 int int_nbr2;
 double int_xyz2[4][3];
 int int_ind2;
 int p;
 double xyz[3];
 int status;

 /*
 Case when segment fully inside the triangle not considered
 as an intersection
 Assumption ok when considering face removal validity checks
 and check between new region and nearby verts performed already
 */

 /*
 Simply loop over the sides
 */

 *int_nbr= 0;

 for ( side= 0 ; side< 3 ; side++ ) {
    for ( i= 0 ; i< 3 ; i++ )
     L_XYZ[0][i]= t_xyz[side][i];
    for ( i= 0 ; i< 3 ; i++ )
     L_XYZ[1][i]= t_xyz[(side+1)%3][i];

    MT_intLineLine(L_XYZ,l_xyz,tol,level,&int_nbr2,int_xyz2);

    for ( int_ind2= 0 ; int_ind2< int_nbr2 ; int_ind2++ ) {
       for ( i= 0 ; i< 3 ; i++)
        int_xyz[*int_nbr][i]= int_xyz2[int_ind2][i];
       (*int_nbr)++;
    }
 }

 if ( level == 1 ) {

    /*
    Case when segment fully inside the triangle not considered
    as an intersection
    Assumption ok when considering face removal validity checks
    and check between new region and nearby verts performed already
    */

    return;
 }

 /*
 Have to check if segment fully inside the triangle
 */

 for ( p= 0 ; p< 2 ; p++ ) {

    for ( i= 0 ; i< 3 ; i++ )
     xyz[i]= l_xyz[p][i];

    status= MT_isPtInTrian(t_xyz,xyz,tol);

    if ( status == TRUE ) {

       /*
       That s an intersection
       */

       for ( i= 0 ; i< 3 ; i++ )
        int_xyz[*int_nbr][i]= xyz[i];
       (*int_nbr)++;
    }
 }

}
