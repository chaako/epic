/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Saikat Dey
  Creation  : Jan., 95
  Modifi.   : 
  Function  :
    given a mesh region, return the edge opposite to a specific edge.
-------------------------------------------------------------------------*/
#include <stdio.h>
#include "oldFMDB.h"
#include "MeshTools.h"
#include "Defines.h"

#ifdef __cplusplus
extern "C" {
#endif

pEdge R_gtOppEdg(pRegion currgn,pEdge edge) {
  pEdge   opp_edge;
  pVertex v, v0,v1,oppv[2];
  pPList  vlist;
  int     i,k=0;
  void   *tmp=0;

  /* get the two vertices of the edge */
  v0=E_vertex(edge,0);
  v1=E_vertex(edge,1);

  /* get the verticies of this region */
  vlist = R_vertices(currgn,1);
  if (PList_size(vlist)!=4) {
    MT_ErrorHandler("Wrong number of vertices","getOppEdg",WARN);
    return(0);
  }

  /* find the opposite edge in currgn */
  while (v=PList_next(vlist,&tmp)) {
    if (v!=v0 && v!=v1) {
      oppv[k]=v;
      k++;
    }
  }
  PList_delete(vlist);
  opp_edge=E_exists(oppv[0],oppv[1]);
  if (!opp_edge) {
    MT_ErrorHandler("Edge not found","R_gtOppEdg",WARN);
    return(0);
  }
  return opp_edge;
}

#ifdef __cplusplus
}
#endif
