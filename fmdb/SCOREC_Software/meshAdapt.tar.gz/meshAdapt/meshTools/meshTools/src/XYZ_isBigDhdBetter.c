/*-------------------------------------------------------------------------
   Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC
 
   Project  : Mesh Tools
   Author(s): Marcel Georges
   Creation : May, 95
   Modifi.  : P. Frey / May, 95
   Function :
     return FALSE if at least 1 large dihedral angle exists in a region
     defined by 4 points (above the target value).
     WARNING:
       the dihedral angle value is not initialized is FALSE is returned.
-------------------------------------------------------------------------*/
#include <stdio.h>
#include <math.h>
#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RANGE 1e-12

int XYZ_isBigDhdBetter(double xyz[4][3],double cos_target,double *maxAng) {
  double t1, t2, t3, t4, t6, t7, t10, t11, t12, t14, t15, t17;
  double t20, t21, t22, t27, t28, t29, t31, t32, t33, t34, t35;
  double t36, t37, t38, t40, t43, t44, t46, t49, t50, t54, t55, t56;
  double t57, t58, t62, t64, t66, t70, t71, t75, t76, t80, t81; 
  double t82, t90, t95, t105, t106, t114, t115, t119, t120, t124, t125; 
  double t83, t84, t86, t92, t91, t101, t130, t150, t126, t135; 
  double t137, t146, t162, t85;
  double cos_ang2, cos_target2;

  *maxAng = 1.0 ;
  cos_target2 = cos_target * cos_target ;
  if(cos_target<0.0)
    cos_target2 = -cos_target2 ;
  t1 = -xyz[1][1];
  t3 = -xyz[1][2];
  t11 = -xyz[0][0];
  t12 = xyz[1][0]+t11;
  t14 = -xyz[1][0];
  t21 = -xyz[0][1];
  t22 = xyz[1][1]+t21;
  t28 = -xyz[0][2];
  t29 = xyz[1][2]+t28;
  t38 = xyz[2][1]+t21;
  t40 = xyz[2][2]+t28;
  t43 = t38*t29-t40*t22;
  t44 = t43*t43;
  t46 = xyz[2][0]+t11;
  t49 = t40*t12-t46*t29;
  t50 = t49*t49;
  t54 = t46*t22-t38*t12;
  t55 = t54*t54;
  t56 = t44+t50+t55;
  if (t56==0.0 )
    return(0);

  t58 = xyz[3][0]+t11;
  t32 = xyz[3][1]+t21;
  t35 = xyz[3][2]+t28;
  t62 = t43*t58+t49*t32+t54*t35;
  if (t62>0.0) 
    return(0);
  t70 = t22*t35-t29*t32;
  t71 = t70*t70;
  t75 = t29*t58-t12*t35;
  t76 = t75*t75;
  t80 = t12*t32-t22*t58;
  t81 = t80*t80;
  t82 = t71+t76+t81;
  if (t82==0.0)
    return(0);

  t90 = t43*t70+t49*t75+t54*t80;
  t95 = 1/t82;
  t64 = 1/t56;
  cos_ang2 = t90*t90*t64*t95;
  if (t90>0)
    cos_ang2 = - cos_ang2 ;
  if ( C_rnleql(cos_ang2,cos_target2,RANGE) )
    return(0) ;
  if (cos_ang2 < *maxAng)
    *maxAng = cos_ang2 ;

  t105 = t70*t46+t75*t38+t80*t40;
  if ( t105 > 0.0) 
    return(0);

  t114 = t32*t40-t35*t38;
  t115 = t114*t114;
  t119 = t35*t46-t58*t40;
  t120 = t119*t119;
  t124 = t58*t38-t32*t46;
  t125 = t124*t124;
  t126 = t115+t120+t125;

  if (t126==0.)
    return(0);

  t135 = t114*t12+t119*t22+t124*t29;
  if (t135>0.) 
    return(0);

  t137 = 1/t126;
  t146 = t43*t114+t49*t119+t54*t124;
  
  cos_ang2 = t146*t146*t64*t137;
  if (t146>0.)
    cos_ang2 = -cos_ang2;

  if (C_rnleql(cos_ang2,cos_target2,RANGE))
    return(0);
        
  if (cos_ang2< *maxAng)
    *maxAng = cos_ang2;

  t162 = t70*t114+t75*t119+t80*t124;

  cos_ang2 = t162*t162*t95*t137;
  if (t162>0.)
    cos_ang2 = -cos_ang2;

  if (C_rnleql(cos_ang2,cos_target2,RANGE))
    return(0);
        
  if (cos_ang2< *maxAng)
    *maxAng = cos_ang2;
  
  t2 = xyz[2][1]+t1;
  t6 = xyz[2][2]+t3;
  t17 = xyz[2][0]+t14;
  
  t7 = xyz[3][1]+t1;
  t4 = xyz[3][2]+t3;
  t15 = xyz[3][0]+t14;
  t10 = t2*t4-t6*t7;
  t20 = t6*t15-t17*t4;
  t27 = t17*t7-t2*t15;
  t83 = t10*t10;
  t84 = t20*t20;
  t85 = t27*t27;
  t86 = t83+t84+t85;

  if (t86==0.) 
    return(0);

  t31 = t10*t12+t20*t22+t27*t29;
  if (t31<0.) 
    return(0);

  t92 = 1/t86;
  t101 = t43*t10+t49*t20+t54*t27;

  cos_ang2 = t101*t101*t64*t92;
  if (t101>0.)
    cos_ang2 = -cos_ang2;
  
  if (C_rnleql(cos_ang2,cos_target2,RANGE))
    return(0);
        
  if (cos_ang2< *maxAng)
    *maxAng = cos_ang2 ;

  t130 = t70*t10+t75*t20+t80*t27;
  cos_ang2 = t130*t130*t95*t92;
  if (t130>0.)
    cos_ang2 = -cos_ang2;

  if (C_rnleql(cos_ang2,cos_target2,RANGE))
    return(0);
  if (cos_ang2< *maxAng)
    *maxAng = cos_ang2 ;
  t150 = t114*t10+t119*t20+t124*t27;
  cos_ang2 = t150*t150*t137*t92;
  if (t150>0.)
    cos_ang2 = -cos_ang2;

  if (C_rnleql(cos_ang2,cos_target2,RANGE))
    return(0);
  if (cos_ang2< *maxAng)
    *maxAng = cos_ang2;
  if(*maxAng<0.) 
    *maxAng = -sqrt(-(*maxAng));
  else
    *maxAng = sqrt(*maxAng);
  return(1);
}

#ifdef __cplusplus
}
#endif
