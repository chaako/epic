#include "oldFMDB.h"
#include "MeshTools.h"

/*----------------------------------------------------------------------------
----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/* map of nodes from right to left handed numbering for 10-noded tet       */
/* To get this map, flip vertices 1 and 2 (vertex numbering starts from 0) */
/* and then renumber the edges according to mesh database rules, i.e., e0  */
/* is b/w v0,v1, e1 b/w v1,v2, e2 b/w v2,v0, e3 b/w v0,v3, e4 b/w v1,v3    */
/* and e5 is between v2 and v3                                             */

static int rlmap [10] = {0,2,1,3,6,5,4,7,9,8};

void R_coordLeft(pRegion rgn,dArray *xyz) {
  pPList  list = R_vertices(rgn,1);
  pEdge edge;
  pVertex vtx;
  pPoint pnt;
  int     i=0,j, n;
  void   *tmp=0;

  /* points of vertices */
  while (vtx=(pVertex)PList_next(list,&tmp)) {
    V_coord(vtx,xyz[rlmap[i]]);
    i++;
  }
  PList_delete(list);

  /* points on edges (higher order nodes) */
  list = R_edges(rgn,1);
  tmp = 0;
  while (edge = PList_next(list, &tmp)) {
    if (n = E_numPoints(edge)) {
      for (j = 0; j < n; j++) {
	pnt = E_point(edge,j);
	xyz[rlmap[i]][0] = P_x(pnt); 
	xyz[rlmap[i]][1] = P_y(pnt); 
	xyz[rlmap[i]][2] = P_z(pnt);
	i++;
      }
    }
  }
  PList_delete(list);
}

#ifdef __cplusplus
}
#endif
