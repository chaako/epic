/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Tools
  Author(s) : J. Wan
  Creation  : October, 1999
  Function  :
              Compute the intersection coordinate between a ray and an 
	      infinite plane given by F_xyz[3][3]. If there exists intersection
	      points, return 1 else 0. If there are infinite intersection points,
	      infinite =1 else =0. If there is only one intersection point,
	      its coordinates are are returned as double array int_xyz[2][3].
-------------------------------------------------------------------------*/

#include "MeshTools.h"
#include "oldFMDB.h"
#include "Defines.h"
#include <math.h>

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
#endif

int M_intersectRay3XYZ (double start[3], double dir[3], double F_xyz[3][3], double int_xyz[3], int *infinite)
{
  double E_xyz[2][3];
  double tol, tol2;
  int i, j, CaseID;
  double fVector[2][3], feVector[3], Normal[3];
  double Normal_Len2, vol[2], tmp[3], dir_Len2;

  /* Initialize */
  tol =M_getTolerance();
  tol2 =tol*tol;
  *infinite =0;

  /* Check if the dir is valid */
  dir_Len2 =dotProd (dir, dir);
  if (dir_Len2 <tol2)
   MT_ErrorHandler ("Zero dir vector", "M_intersectRayXYZ", FATAL);

  /* Construct a line segment */
  for (i=0; i<3; i++) {
    E_xyz[0][i] =start[i];
    E_xyz[1][i] =start[i] + dir[i];
  }

  /* Start to check if the segment lies in the plane */
  for (i=0; i<2; i++)
    diffVt (F_xyz[i+1], F_xyz[0], fVector[i]);

  diffVt (E_xyz[0], F_xyz[0], feVector);

  /* Compute the normal of the plane */
  crossProd (fVector[0], fVector[1], Normal);
  Normal_Len2 =dotProd (Normal, Normal);

  /* Compute the important dot products */
  vol[0] =dotProd (Normal, dir);
  tmp[0] =vol[0]*vol[0];

  vol[1] =dotProd (Normal, feVector);
  tmp[1] =vol[1]*vol[1];

  tmp[2]=tol2*Normal_Len2;

  /* Analyze the cases */
  if (tmp[0] <= tmp[2]*dir_Len2) {
    /* the ray is parallel to the plane */
    if (tmp[1] <= tmp[2])    /* ray lies in the plane */
      CaseID =0;
    else                     /* ray lies in another plane  parallel to the plane */
      return 0;
  } else                     /* ray is not parallel to the plane */
    CaseID =1;

  switch (CaseID) {
  case 0:     /* of CaseID, ray lies in the plane */
              /* Infinite points */
    *infinite =1;
    return 1;
  case 1:    /* of CaseID, ray may cross the face plane */
             /* Cumpute the intersection point between ray and the face plane */
    vol[1] /=vol[0];
    for (i=0; i<3; i++)
      int_xyz[i] =E_xyz[0][i]-vol[1]*dir[i];


    /* Check if the point is on the directional ray */
    diffVt (int_xyz, start, feVector);
    if (dotProd (dir, feVector)<0)
      return 0;
    else
      return 1;
  }   /* End of Switch (CaseID) */

}

int M_intersectRay2XYZ (double start[3], double dir[3], double L_xyz[2][3], double int_xyz[3], int *infinite)
{
  double tol, tol2;
  double Vector[3], Normal[2][3], vol[2], dir_Len2;
  double MaxVal_inNormal, tmp;
  double A[2][2], B[2], Scale;
  int i, j, MaxDim_inNormal=0;

  /* Initialize */
  tol =M_getTolerance();
  tol2 =tol*tol;
  *infinite =0;

  /* Check if the dir is valid */
  dir_Len2 =dotProd (dir, dir);
  if (dir_Len2 <tol2)
    MT_ErrorHandler ("Zero dir vector", "M_intersectRay2XYZ", FATAL);

  for (i=0; i<2; i++) {
    diffVt (L_xyz[i], start, Vector);
    crossProd (dir, Vector, Normal[i]);
    vol[i] =dotProd (Normal[i], Normal[i]);
  }

  tol2 =tol2*dir_Len2;
  
  /* First check if the edges are colinear */
  if (vol[0]*vol[0] <= tol2 && vol[1]*vol[1] <= tol2) {
    /* The edges are colinear */
    *infinite =1;
    return 1;
  }

  /* Then check if the edges are coplanar (do possibly cross each other) */
  crossProd (Normal[0], Normal[1], Vector);
  

  if (dotProd (Vector, Vector)>tol*tol)
    /* Non-planar, No intersection points */
    return 0;

  /* At last, compute the intersection point when the edges or their extended line cross each other*/
  diffVt (L_xyz[1], L_xyz[0], Vector);
  crossProd (dir, Vector, Normal[0]);
  
  MaxVal_inNormal =fabs (Normal[0][0]);
  for (i=1; i<3; i++) {
    if ((tmp=fabs (Normal[0][i])) > MaxVal_inNormal) {
      MaxDim_inNormal =i;
      MaxVal_inNormal =tmp;
    }
  }
  
  for (i=j=0; i<3; i++) {
    if (i==MaxDim_inNormal) continue;
    A[j][0] =dir[i];
    A[j][1] =-Vector[i];
    B[j] =L_xyz[0][i] - start[i];
    j ++;
  }
  
  tmp =A[0][0]*A[1][1] - A[0][1]*A[1][0];
  if (fabs (tmp) <tol)
    return -1;

  /* Compute the Scale parameter on edge1 */
  Scale =(A[1][1]*B[0] - A[0][1]*B[1]) / tmp;
  
  for (i=0; i<3; i++)
    int_xyz[i] =start[i] + Scale * dir[i];

  /* Check if the point is on the directional ray */
  diffVt (int_xyz, start, Vector);
  if (dotProd (dir, Vector)<0)
    return 0;
  else
    return 1;
}


/* compute the intersection between an infinite plane and an infinite line */
int M_intersectLine3XYZ (double start[3], double dir[3], double F_xyz[3][3], double int_xyz[3], int *infinite)
{
  double E_xyz[2][3];
  double tol, tol2;
  int i, j, CaseID;
  double fVector[2][3], feVector[3], Normal[3];
  double Normal_Len2, vol[2], tmp[3], dir_Len2;

  /* Initialize */
  tol =M_getTolerance();
  tol2 =tol*tol;
  *infinite =0;

  /* Check if the dir is valid */
  dir_Len2 =dotProd (dir, dir);
  if (dir_Len2 <tol2)
    MT_ErrorHandler ("Zero dir vector", "M_intersectRayXYZ", FATAL);

  /* Construct a line segment */
  for (i=0; i<3; i++) {
    E_xyz[0][i] =start[i];
    E_xyz[1][i] =start[i] + dir[i];
  }

  /* Start to check if the segment lies in the plane */
  for (i=0; i<2; i++)
    diffVt (F_xyz[i+1], F_xyz[0], fVector[i]);

  diffVt (E_xyz[0], F_xyz[0], feVector);

  /* Compute the normal of the plane */
  crossProd (fVector[0], fVector[1], Normal);
  Normal_Len2 =dotProd (Normal, Normal);

  /* Compute the important dot products */
  vol[0] =dotProd (Normal, dir);
  tmp[0] =vol[0]*vol[0];

  vol[1] =dotProd (Normal, feVector);
  tmp[1] =vol[1]*vol[1];

  tmp[2]=tol2*Normal_Len2;

  /* Analyze the cases */
  if (tmp[0] <= tmp[2]*dir_Len2) {
    /* the ray is parallel to the plane */
    if (tmp[1] <= tmp[2])    /* ray lies in the plane */
      CaseID =0;
    else                     /* ray lies in another plane  parallel to the plane */
      return 0;
  } else                     /* ray is not parallel to the plane */
    CaseID =1;

  switch (CaseID) {
  case 0:     /* of CaseID, ray lies in the plane */
              /* Infinite points */
    *infinite =1;
    return 1;
  case 1:    /* of CaseID, ray may cross the face plane */
             /* Cumpute the intersection point between ray and the face plane */
    vol[1] /=vol[0];
    for (i=0; i<3; i++)
      int_xyz[i] =E_xyz[0][i]-vol[1]*dir[i];

    return 1;
  }   /* End of Switch (CaseID) */

}



