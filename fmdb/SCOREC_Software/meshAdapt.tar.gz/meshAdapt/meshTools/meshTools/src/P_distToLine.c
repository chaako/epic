#include "MeshTools.h"

/* Square of the Perp. distance of a point to a line */

double P_distToLine(double* pxyz,double *xyz0, double *xyz1, double *normal)

{ 
  double snorm, dist;
  double v1[3],v2[3],v3[3];

    diffVt(xyz1,xyz0,v1);
    diffVt(pxyz,xyz0,v2);
    crossProd(v1,v2,v3);
    snorm=dotProd(v1,v1);
    dist =dotProd(v3,v3)/snorm;

    if(normal)
      if(dotProd(normal,v3)<=0.0)
        return(-dist);

    return(dist);
}
