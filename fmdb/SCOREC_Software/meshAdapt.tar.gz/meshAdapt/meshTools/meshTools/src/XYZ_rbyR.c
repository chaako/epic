/* Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project: 

   Authors/Dates:
   Rao Garimella, Feb 1995

   Functionality:
   Returns the r by R ratio

   Argument Variable(s):
   Name  Type In/Out Description
 |------|----|------|-----------------------------------------------------|
*/

#ifdef __cplusplus
extern "C" {
#endif

#include <math.h>
#include "oldFMDB.h"
#include "Defines.h"
#include "MeshTools.h"


double XYZ_rbyR(dArray *xyz) {

  return(3.0*XYZ_inscrRad(xyz)/XYZ_circumRad(xyz));

} /* R_rbyR */

#ifdef __cplusplus
}
#endif
