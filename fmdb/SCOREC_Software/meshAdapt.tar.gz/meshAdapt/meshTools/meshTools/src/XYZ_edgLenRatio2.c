/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Rao Garimella
  Creation  : Aug., 95
  Modifi.   : 
  Function  :
    Return the square of maximum edge length ratio of a region. Currently, only
    tetrahedrons are supported.
-------------------------------------------------------------------------*/
#include <math.h>
#include "oldFMDB.h"
#include "Defines.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

double XYZ_edgLenRatio2(dArray *xyz) {
  double  longest, shortest, vects[3], length;
  int     i,j;
  void   *temp=0;

  shortest = 999999999.0;
  longest = 0.0;
  for (i=0; i<3; i++) {
    for (j=i+1; j<4; j++) {
      diffVt(xyz[i], xyz[j], vects);
      length = dotProd(vects, vects);
      if (length < shortest) shortest = length;
      if (length > longest) longest = length;
    }
  }
  return (longest/shortest);
} /* XYZ_edgeLenRatio2 */

#ifdef __cplusplus
}
#endif
