/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Tools
  Author(s) : J. Wan
  Creation  : October, 1999
  Function  :
              Compute the intersection between two regions. 
	      If there exists intersection, return 1 else 0. The 
	      details of intersection are returned via IntersectionData.
-------------------------------------------------------------------------*/

#include "MeshTools.h"
#include "oldFMDB.h"
#include "Defines.h"
#include <math.h>

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
#endif

int XYZ_coplanar (int npt, double xyz[][3], double tol)
{
  double normal[3], vector[2][3], vol[2];
  int i;

  if (npt<4) return 1;
  
  /* Calculate the normal of the 1st triangle */
  for (i=0; i<2; i++)
    diffVt (xyz[i+1], xyz[0], vector[i]);
  crossProd (vector[0], vector[1], normal);
  vol[0] =tol*tol*dotProd (normal, normal);
  
  for (i=3; i<npt; i++) {
    diffVt (xyz[i], xyz[0], vector[0]);
    vol[1] =dotProd (vector[0], normal);
    vol[1] =vol[1]*vol[1];
    if (vol[1]>vol[0])
      return 0;
  }
  
  return 1;
}

/* compute the corner coordinates of the region */
void R_bounds (pRegion region, double min[3], double max[3])
{
  pPList vlist;
  int i, j;
  double xyz[3];

  vlist =R_vertices (region,1);
  V_coord (PList_item (vlist, 0), min);
  for (i=0; i<3; i++)
    max[i] =min[i];

  for (i=0; i<4; i++) {
    V_coord (PList_item (vlist, i), xyz);
    for (j=0; j<3; j++) {
      if (min[j]>xyz[j])
	min[j] =xyz[j];
      if (max[j]<xyz[j])
	max[j] =xyz[j];
    }
  }
  PList_delete (vlist);
}

int R_boundBoxInterfer (pRegion reg1, pRegion reg2)
{
  double box[2][2][3];
  int i, j, count;

  /* Get the corner coordinates of the region boxes */
  R_bounds (reg1, box[0][0], box[0][1]);
  R_bounds (reg2, box[1][0], box[1][1]);

  count =0;
  for (j=0; j<3; j++)
    if ((box[0][0][j]>=box[1][0][j] && box[0][0][j]<=box[1][1][j]) || 
	((box[0][1][j]>=box[1][0][j] && box[0][1][j]<=box[1][1][j])))
      count ++;

  if (count==3) return 1;
  
  return 0;
}


int M_intersectRegions (pRegion reg1, int ClosureFlag1, pRegion reg2, int ClosureFlag2, IntersectionData *idata)
{
  double int_xyz[18][3], tol, tol2;
  int i, j, k, num_int, faceCounted=0, regCounted=0, IntersectOnFaces;
  pVertex v[3];
  pEdge edge;
  pFace r_face;
  pPList vlist, elist, flist;
  int NumExistingIntPts, NumBeforeThisIntPts;
  struct IntDescription *thisDescription;
  pEntity int_Ent1[18], int_Ent2[18];

  /* Initialize */
  tol =M_getTolerance();
  tol2 =tol*tol;

  /* Record the procedure: 
     1) if the routine is called independently, NumExistingIntPts=0
     2) if the routine is called embeddedly, NumExistingIntPts may Nonzero */
  NumExistingIntPts =idata->nbr;

  /* Apply the bounding box interference check */
  /*  if (!R_boundBoxInterfer (reg1, reg2)) return 0;
   */

  /* Compute the intersections between the faces of reg and the face */
  /* Up to 18 intersection bounding pts may exist between the ents*/

  /* Compute the intersection between reg1 and the faces of reg2 */
  for (i=0; i<=3; i++) {
    r_face =R_face (reg2, (int)i);

    R_intersectFace (reg1, 1, r_face, 1, idata);

    if (idata->nbr-NumExistingIntPts==18)
      break;
  }


  if (idata->nbr<18) {
    /* Mark the position for the data swap later */
    NumBeforeThisIntPts =idata->nbr;
    
    /* Compute the intersection between reg2 and the faces of reg1 */
    for (i=0; i<4; i++) {
      r_face =R_face (reg1, i);
      R_intersectFace (reg2, 1, r_face, 1, idata);
      if (idata->nbr-NumExistingIntPts==18)
	break;
    }
    if (NumBeforeThisIntPts < idata->nbr)  /* Any new intersection point found */
      swapIntersectedEnt (idata, NumBeforeThisIntPts);
  }
  

  /* So far we have finished the computation of bounding pts */
  
  /* When it is called as a subroutine of another complex intersection routine,
     do not apply closure control */
  if (NumExistingIntPts) return 1;
  

  /* Now we start to implement the closure control. Note that we donot need to
     consider the situation when Face is coplanar with a face of reg */
  /* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  /* Start to implement closure control and append bounded ents */
  /* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

  thisDescription =idata->Description;
  
  /* First retrieve the intersection bounding points into array */
  num_int =idata->nbr;
  for (i=0; i<idata->nbr; i++) {
    int_Ent1[i] =thisDescription->IntEnt1;
    int_Ent2[i] =thisDescription->IntEnt2;
    for (j=0; j<3; j++)
      int_xyz[i][j] =thisDescription->xyz[j];
    thisDescription =thisDescription->next;
  }

  /* Initialize the intersectionData */
  M_intersectionData_delete (*idata);
  *idata =M_intersectionData_new ();
  
  switch (num_int) {
  case 0:
    return 0;
    
  case 1:   /* One vertex of a region on the boundary of another region */
    if (ClosureFlag1 && ClosureFlag2)    /* Full closure case */
      M_updateIntersectionData (idata, int_Ent1[0], int_Ent2[0], int_xyz[0], -1);
    else 
      return 0;
    break;

  case 2:   /* One edge of a region on the boundary of another region */

    if (ClosureFlag1 && ClosureFlag2) {     /* Full closure case */
      
      /* ******  First consider the bounded ents on reg1 ******   */
      /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

      switch (EN_type (int_Ent1[0])) {
	
      case Tvertex:   /* 1st pt located on a vertex */

	switch (EN_type (int_Ent1[1])) {
	    
	case Tvertex:   /* 1st pt on a vertex, 2nd pt on a vertex */
	  /* the ents intersect on a whole edge of reg */
	  PList_append (idata->boundedEntList, M_boundedEdgeOnRegion (reg1, int_Ent1[0], int_Ent1[1]));
	  break;

	case Tedge:     /* 1st pt on a vertex, 2nd pt on an edge */
	  /* to check if the ents intersect on a part of an edge of reg */
	  if (int_Ent1[0]!=E_vertex (int_Ent1[1],0) && int_Ent1[0]!=E_vertex (int_Ent1[1],1)) {
	    
	    r_face =M_boundedFaceOnRegion (reg1, int_Ent1[0], int_Ent1[1]);
	    if (r_face) /* a face of reg bounded by bounding pts */
	      PList_append (idata->boundedEntList, r_face);
	  }
	  break;
	}  /* end of switch */
	break;
	
      case Tedge:   /* 1st pt located on an edge */
	
	switch (EN_type (int_Ent1[1])) {
	  
	case Tvertex:     /* 1st pt on an edge, 2nd pt on a vertex */
	  /* to check if the ents intersect on a part of an edge of reg */
	  if (int_Ent1[1]!=E_vertex (int_Ent1[0],0) && int_Ent1[1]!=E_vertex (int_Ent1[0],1)) {
	    
	    r_face =M_boundedFaceOnRegion (reg1, int_Ent1[0], int_Ent1[1]);
	    if (r_face)   /* a face of reg bounded by bounding pts */
	      PList_append (idata->boundedEntList, r_face);
	  }
	  break;
	  
	case Tedge:    /* 1st pt on an edge, 2nd pt on an edge */
	  /* to check if an edge of face lies on an edge of reg */
	  if (int_Ent1[0]!=int_Ent1[1]) {
	    
	    /* An edge of face crosses a face of reg or reg itself*/
	    
	    r_face =M_boundedFaceOnRegion (reg1, int_Ent1[0], int_Ent1[1]);
	    if (r_face)    /* a face of reg bounded bounding pts*/ 
	      PList_append (idata->boundedEntList, r_face);
	  }
	  break;
	}   /* end of switch */
	break;

      }  /* End of switch */
      

      /* ***** Secondly, consider the bounded ents on reg2 ***** */
      /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

      switch (EN_type (int_Ent2[0])) {
	
      case Tvertex:   /* 1st pt located on a vertex */

	switch (EN_type (int_Ent2[1])) {
	    
	case Tvertex:   /* 1st pt on a vertex, 2nd pt on a vertex */
	  /* the ents intersect on a whole edge of reg */
	  PList_append (idata->boundedEntList, M_boundedEdgeOnRegion (reg2, int_Ent2[0], int_Ent2[1]));
	  break;

	case Tedge:     /* 1st pt on a vertex, 2nd pt on an edge */
	  /* to check if the ents intersect on a part of an edge of reg */
	  if (int_Ent2[0]!=E_vertex (int_Ent2[1],0) && int_Ent2[0]!=E_vertex (int_Ent2[1],1)) {
	    
	    r_face =M_boundedFaceOnRegion (reg2, int_Ent2[0], int_Ent2[1]);
	    if (r_face)  /* a face of reg bounded by bounding pts */
	      PList_append (idata->boundedEntList, r_face);
	  
	  }
	  break;
	}  /* end of switch */
	break;
	
      case Tedge:   /* 1st pt located on an edge */
	
	switch (EN_type (int_Ent2[1])) {
	  
	case Tvertex:     /* 1st pt on an edge, 2nd pt on a vertex */
	  /* to check if the ents intersect on a part of an edge of reg */
	  if (int_Ent2[1]!=E_vertex (int_Ent2[0],0) && int_Ent2[1]!=E_vertex (int_Ent2[0],1)) {
	    
	    r_face =M_boundedFaceOnRegion (reg2, int_Ent2[0], int_Ent2[1]);
	    if (r_face)   /* a face of reg bounded by bounding pts */
	      PList_append (idata->boundedEntList, r_face);
	  }
	  break;

	case Tedge:    /* 1st pt on an edge, 2nd pt on an edge */
	  /* to check if an edge of face lies on an edge of reg */
	  if (int_Ent2[0]!=int_Ent2[1]) {

	    /* An edge of face crosses a face of reg or reg itself*/

	    r_face =M_boundedFaceOnRegion (reg2, int_Ent2[0], int_Ent2[1]);
	    if (r_face)    /* a face of reg bounded bounding pts*/
	      PList_append (idata->boundedEntList, r_face);
	  }
	  break;
	}   /* end of switch */
	break;

      }  /* End of switch */
      
      for (i=0; i<2; i++)
	M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);
      
    } else
      return 0;    /* No intersection */
    break;
    
    
  default:
    /* Check if two regions only intersect on two faces */
    
    if (num_int==3)      /* Regions intersect on faces */
      IntersectOnFaces =1;
    else if (num_int>6)  /* Intersection is a volume */
      IntersectOnFaces =0;
    else   /* 4=< num_int <=6, need to check */
      IntersectOnFaces =XYZ_coplanar (num_int, int_xyz, tol);
    
    if (ClosureFlag1) {    /* ClosureFlag1 =1 */
      if (ClosureFlag2) {  /* Full closure case */

	/* ++++++++++++++ Consider reg1 first ++++++++++++++ */

	for (i=0; i<num_int; i++)
	  for (j=i+1; j<num_int; j++) {
	    
	    switch (EN_type (int_Ent1[i])) {
	
	    case Tvertex:   /* ith pt located on a vertex */
	      
	      switch (EN_type (int_Ent1[j])) {
		
	      case Tvertex:   /* ith pt on a vertex, jth pt on a vertex */
		/* the ents intersect on a whole edge of reg */
		PList_append (idata->boundedEntList, M_boundedEdgeOnRegion (reg1, int_Ent1[i], int_Ent1[j]));
		break;
		
	      case Tedge:     /* ith pt on a vertex, jth pt on an edge */
		/* to check if the ents intersect on an edge of reg */
		if (int_Ent1[i]!=E_vertex (int_Ent1[j],0) && int_Ent1[i]!=E_vertex (int_Ent1[j],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg1, int_Ent1[i], int_Ent1[j]);
		  if (r_face)  {/* a face of reg bounded by bounding pts */
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent1[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);
		  }
		}
		break;

	      }  /* end of switch */
	      break;
	      
	    case Tedge:   /* ith pt located on an edge */
	      
	      switch (EN_type (int_Ent1[j])) {
		
	      case Tvertex:     /* ith pt on an edge, jth pt on a vertex */
		/* to check if the ents intersect on a part of an edge of reg */
		if (int_Ent1[j]!=E_vertex (int_Ent1[i],0) && int_Ent1[j]!=E_vertex (int_Ent1[i],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg1, int_Ent1[i], int_Ent1[j]);
		  if (r_face) {  /* a face of reg bounded by bounding pts */
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent1[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);
		  }
		}
		break;
		
	      case Tedge:    /* ith pt on an edge, jth pt on an edge */
		/* to check if an edge of face lies on an edge of reg */
		if (int_Ent1[i]!=int_Ent1[j]) {
		  
		  /* An edge of face crosses a face of reg or reg itself*/
		  
		  r_face =M_boundedFaceOnRegion (reg1, int_Ent1[i], int_Ent1[j]);
		  if (r_face) {   /* a face of reg bounded bounding pts*/ 
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent1[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);	
		  }
		}
		break;
	      }   /* end of switch */
	      break;	      
	      
	    }  /* End of switch */

	  }  /* end of for */


	/* ++++++++++++++ Consider reg2 then ++++++++++++++ */

	for (i=0; i<num_int; i++)
	  for (j=i+1; j<num_int; j++) {
	    
	    switch (EN_type (int_Ent2[i])) {
	
	    case Tvertex:   /* ith pt located on a vertex */
	      
	      switch (EN_type (int_Ent2[j])) {
		
	      case Tvertex:   /* ith pt on a vertex, jth pt on a vertex */
		/* the ents intersect on a whole edge of reg */
		PList_appUnique (idata->boundedEntList, M_boundedEdgeOnRegion (reg2, int_Ent2[i], int_Ent2[j]));
		break;
		
	      case Tedge:     /* ith pt on a vertex, jth pt on an edge */
		/* to check if the ents intersect on an edge of reg */
		if (int_Ent2[i]!=E_vertex (int_Ent2[j],0) && int_Ent2[i]!=E_vertex (int_Ent2[j],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg2, int_Ent2[i], int_Ent2[j]);
		  if (r_face) { /* a face of reg bounded by bounding pts */
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent2[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);
		  }
		}
		break;

	      }  /* end of switch */
	      break;
	      
	    case Tedge:   /* ith pt located on an edge */
	      
	      switch (EN_type (int_Ent2[j])) {
		
	      case Tvertex:     /* ith pt on an edge, jth pt on a vertex */
		/* to check if the ents intersect on a part of an edge of reg */
		if (int_Ent2[j]!=E_vertex (int_Ent2[i],0) && int_Ent2[j]!=E_vertex (int_Ent2[i],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg2, int_Ent2[i], int_Ent2[j]);
		  if (r_face) {  /* a face of reg bounded by bounding pts */
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent2[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);
		  }
		}
		break;
		
	      case Tedge:    /* ith pt on an edge, jth pt on an edge */
		/* to check if an edge of face lies on an edge of reg */
		if (int_Ent2[i]!=int_Ent2[j]) {
		  
		  /* An edge of face crosses a face of reg or reg itself*/
		  
		  r_face =M_boundedFaceOnRegion (reg2, int_Ent2[i], int_Ent2[j]);
		  if (r_face) {   /* a face of reg bounded bounding pts*/
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent2[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);
		  }
		}
		break;
	      }   /* end of switch */
	      break;	      
	      
	    }  /* End of switch */

	  }  /* end of for */

	/* Check if the regions need to be included */
	if (IntersectOnFaces==0) {
	  regCounted =0;
	  for (i=0; i<num_int; i++)
	    if (EN_type (int_Ent1[i])==Tregion) {
	      regCounted =1;
	      break;
	    }
	  if (regCounted==0)
	    PList_append (idata->boundedEntList, reg1);

	  regCounted =0;
	  for (i=0; i<num_int; i++)
	    if (EN_type (int_Ent2[i])==Tregion) {
	      regCounted =1;
	      break;
	    }
	  if (regCounted==0)
	    PList_append (idata->boundedEntList, reg2);
	}

	
      } else {             /* Half closure case, ClosureFlag1=1, ClosureFlag2=0 */

	if (IntersectOnFaces) return 0;

	/* Append bounded ents on reg1*/
	for (i=0; i<num_int; i++)
	  for (j=i+1; j<num_int; j++) {
	    
	    /* if intersect on an edge of reg2. skip it */
	    if (EN_type (int_Ent2[i])==Tvertex && 
		(EN_type (int_Ent2[j])==Tvertex || EN_type (int_Ent2[j])==Tedge && 
		 (int_Ent2[i]==E_vertex (int_Ent2[j],0) || int_Ent2[i]==E_vertex (int_Ent2[j],1))) ||
		EN_type (int_Ent2[j])==Tvertex && EN_type (int_Ent2[i])==Tedge && 
		(int_Ent2[j]==E_vertex(int_Ent2[i],0) || int_Ent2[j]==E_vertex (int_Ent2[i],1))) continue;
	    
	    switch (EN_type (int_Ent1[i])) {
	      
	    case Tvertex:   /* ith pt located on a vertex */
	      
	      switch (EN_type (int_Ent1[j])) {
		
	      case Tvertex:   /* ith pt on a vertex, jth pt on a vertex */
		/* the ents intersect on a whole edge of reg */
		PList_append (idata->boundedEntList, M_boundedEdgeOnRegion (reg1, int_Ent1[i], int_Ent1[j]));
		break;
		
	      case Tedge:     /* ith pt on a vertex, jth pt on an edge */
		/* to check if the ents intersect on an edge of reg */
		if (int_Ent1[i]!=E_vertex (int_Ent1[j],0) && int_Ent1[i]!=E_vertex (int_Ent1[j],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg1, int_Ent1[i], int_Ent1[j]);
		  if (r_face) { /* a face of reg1 bounded by bounding pts */
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent1[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);
		  }
		}
		break;
		
	      }  /* end of switch */
	      break;
	      
	    case Tedge:   /* ith pt located on an edge */
	      
	      switch (EN_type (int_Ent1[j])) {
		
	      case Tvertex:     /* ith pt on an edge, jth pt on a vertex */
		/* to check if the ents intersect on a part of an edge of reg */
		if (int_Ent1[j]!=E_vertex (int_Ent1[i],0) && int_Ent1[j]!=E_vertex (int_Ent1[i],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg1, int_Ent1[i], int_Ent1[j]);
		  if (r_face) {   /* a face of reg bounded by bounding pts */
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent1[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);
		  }
		}
		break;
		
	      case Tedge:    /* ith pt on an edge, jth pt on an edge */
		/* to check if an edge of face lies on an edge of reg */
		if (int_Ent1[i]!=int_Ent1[j]) {
		  
		  /* An edge of face crosses a face of reg or reg itself*/
		  
		  r_face =M_boundedFaceOnRegion (reg1, int_Ent1[i], int_Ent1[j]);
		  if (r_face) {    /* a face of reg1 bounded bounding pts*/ 
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent1[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);	
		  }
		}
		break;
	      }   /* end of switch */
	      break;	      
	      
	    }  /* End of switch */
	    
	  }  /* end of for */

	/* classify the ents at intersection pts */
	for (i=0; i<num_int; i++) {
	  switch (EN_type(int_Ent2[i])) {
	  case Tvertex:
	    int_Ent1[i] =reg2;
	    break;
	  case Tedge:
	    switch (EN_type (int_Ent1[i])) {
	    case Tvertex:
	    case Tedge:
	      int_Ent1[i] =reg2;
	      break;
	    case Tface:
	      if (M_coplanarEdgeFace (int_Ent2[i], int_Ent1[i], tol))
		int_Ent1[i] =reg1;
	      break;
	    }
	    break;
	  case Tface:
	    switch (EN_type (int_Ent1[i])) {
	    case Tvertex:
	      int_Ent1[i] =reg1;
	      break;
	    case Tedge:
	      if (M_coplanarEdgeFace (int_Ent1[i], int_Ent2[i], tol))
		int_Ent1[i] =reg1;
	      break;
	    }
	    break;
	  }
	  int_Ent2[i] =reg2;
	}	


	/* Check if reg1 needs to be included */
	regCounted =0;
	for (i=0; i<num_int; i++)
	  if (EN_type (int_Ent1[i])==Tregion) {
	    regCounted =1;
	    break;
	  }
	if (regCounted==0)
	  PList_append (idata->boundedEntList, reg1);
      }     
 
    } else {               /* ClosureFlag1 =0 */

      if (IntersectOnFaces) return 0;

      if (ClosureFlag2) {  /* Half closure case, ClosureFlag1 =0, ClosureFlag2 =1 */
	
	/* Append bounded ents on reg2*/
	for (i=0; i<num_int; i++)
	  for (j=i+1; j<num_int; j++) {
	    
	    /* if intersect on an edge of reg1. skip it */
	    if (EN_type (int_Ent1[i])==Tvertex && 
		(EN_type (int_Ent1[j])==Tvertex || EN_type (int_Ent1[j])==Tedge && 
		 (int_Ent1[i]==E_vertex (int_Ent1[j],0) || int_Ent1[i]==E_vertex (int_Ent1[j],1))) ||
		EN_type (int_Ent1[j])==Tvertex && EN_type (int_Ent1[i])==Tedge && 
		(int_Ent1[j]==E_vertex(int_Ent1[i],0) || int_Ent1[j]==E_vertex (int_Ent1[i],1))) continue;
	    

	    switch (EN_type (int_Ent2[i])) {
	      
	    case Tvertex:   /* ith pt located on a vertex */
	      
	      switch (EN_type (int_Ent2[j])) {
		
	      case Tvertex:   /* ith pt on a vertex, jth pt on a vertex */
		/* the ents intersect on a whole edge of reg2 */
		PList_append (idata->boundedEntList, M_boundedEdgeOnRegion (reg2, int_Ent2[i], int_Ent2[j]));
		break;
		
	      case Tedge:     /* ith pt on a vertex, jth pt on an edge */
		/* to check if the ents intersect on an edge of reg2 */
		if (int_Ent2[i]!=E_vertex (int_Ent2[j],0) && int_Ent2[i]!=E_vertex (int_Ent2[j],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg2, int_Ent2[i], int_Ent2[j]);
		  if (r_face) { /* a face of reg2 bounded by bounding pts */
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent2[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);
		  }
		}
		break;
		
	      }  /* end of switch */
	      break;
	      
	    case Tedge:   /* ith pt located on an edge */
	      
	      switch (EN_type (int_Ent2[j])) {
		
	      case Tvertex:     /* ith pt on an edge, jth pt on a vertex */
		/* to check if the ents intersect on a part of an edge of reg2 */
		if (int_Ent2[j]!=E_vertex (int_Ent2[i],0) && int_Ent2[j]!=E_vertex (int_Ent2[i],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg2, int_Ent2[i], int_Ent2[j]);
		  if (r_face) {   /* a face of reg bounded by bounding pts */
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent2[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);
		  }
		}
		break;
		
	      case Tedge:    /* ith pt on an edge, jth pt on an edge */
		/* to check if an edge of face lies on an edge of reg */
		if (int_Ent2[i]!=int_Ent2[j]) {
		  
		  /* An edge of face crosses a face of reg or reg itself*/
		  
		  r_face =M_boundedFaceOnRegion (reg2, int_Ent2[i], int_Ent2[j]);
		  if (r_face) {    /* a face of reg1 bounded bounding pts*/ 
		    faceCounted =0;
		    for (k=0; k<num_int; k++)
		      if (int_Ent2[k]==r_face) {
			faceCounted =1;
			break;
		      }
		    if (!faceCounted)
		      PList_appUnique (idata->boundedEntList, r_face);	
		  }
		}
		break;
	      }   /* end of switch */
	      break;	      
	      
	    }  /* End of switch */
	    
	  }  /* end of for */
	
	for (i=0; i<num_int; i++) {
	  switch (EN_type(int_Ent1[i])) {
	  case Tvertex:
	    int_Ent2[i] =reg2;
	    break;
	  case Tedge:
	    switch (EN_type (int_Ent2[i])) {
	    case Tvertex:
	    case Tedge:
	      int_Ent2[i] =reg2;
	      break;
	    case Tface:
	      if (M_coplanarEdgeFace (int_Ent1[i], int_Ent2[i], tol))
		int_Ent2[i] =reg2;
	      break;
	    }
	    break;
	  case Tface:
	    switch (EN_type (int_Ent2[i])) {
	    case Tvertex:
	      int_Ent2[i] =reg2;
	      break;
	    case Tedge:
	      if (M_coplanarEdgeFace (int_Ent2[i], int_Ent1[i], tol))
		int_Ent2[i] =reg2;
	      break;
	    }
	    break;
	  }
	  int_Ent1[i] =reg1;
	}

	/* Check if reg2 needs to be included */
	regCounted =0;
	for (i=0; i<num_int; i++)
	  if (EN_type (int_Ent2[i])==Tregion) {
	    regCounted =1;
	    break;
	  }
	if (regCounted==0)
	  PList_append (idata->boundedEntList, reg2);

      } else {             /* Non closure case */

	for (i=0; i<num_int; i++) {
	  int_Ent1[i] =reg1;
	  int_Ent2[i] =reg2;
	}

      }
    }

    for (i=0; i<num_int; i++)
      M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], tol2);
    break;
  }
  
  if (idata->nbr) {
    switch (idata->nbr) {
    case 1:
      idata->dim =0;
      break;
    case 2:
      idata->dim =1;
      break;
    default:
      if (IntersectOnFaces)
	idata->dim =2;
      else
	idata->dim =3;
      break;
    }

    return 1;
  }

  return 0;
}





