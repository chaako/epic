/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Pascal J. Frey
  Creation  : Feb., 95
  Modifi.   : 
  Function  :
    returns the cosine of smallest and largest dihedral angle in a tetra.
-------------------------------------------------------------------------*/
#include <math.h>
#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

void XYZ_dihedral(dArray *xyz,double *sml,double *big) {
  double  cossml,cosbig,cosangs[6];
  int     e;

  /* get all 6 dihedral angles */
  XYZ_dhdAngs(xyz,cosangs);
  cossml=cosangs[0];
  cosbig=cosangs[0];
  /* evaluate 5 other dihedral angles */
  for (e=1; e<6; e++) {
    /* dihedral angle evaluation */
    if (cosangs[e]<cosbig)
      cosbig = cosangs[e];
    if (cosangs[e] > cossml)
      cossml = cosangs[e];
  }
  if (cosbig<0.)
    *big = -sqrt(-cosbig);
  else
    *big = sqrt(cosbig);
  if (cossml<0.)
    *sml = -sqrt(-cossml);
  else
    *sml = sqrt(cossml);
}

#ifdef __cplusplus
}
#endif

