/*---------------------------------------------------------------------------    Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC
 
   Project  : Mesh Tools
   Author(s): Rao Garimella
   Creation : Jan 96
   Modif.   :
   Function :
     computes and returns smallest and largest face angles of a triangle
     return 0 if triangle is flat. Flatness check is w.r.t. a given normal
---------------------------------------------------------------------------*/
#include "oldFMDB.h"
#include "Macros.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ANG_TOL  4.e-10

int F_angles(pFace face, double *normal, double *cosangs) {
  double xyz[3][3];

  F_coord(face,xyz);
  return (XYZ_FAngles(xyz,normal,cosangs));
}

#ifdef __cplusplus
}
#endif






