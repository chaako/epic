#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

double worstMinDhd(dArray *xyz) {
  double minDhd,dhd,org[4][3] ;
  int    e,j,imap ;
  static int map[6][4] = 
    { 0,1,2,3, 1,2,0,3, 2,0,1,3, 0,3,1,2, 1,3,2,0, 2,3,0,1 } ;
 
  /* evaluate the 1st edge angle (no mapping required) */
  minDhd = E_dihedral(xyz) ;
 
  /* evaluate 5 other dihedral angles */
  for ( e=1 ; e<6 ; e++ )
  {
    for ( j=0 ; j<4 ; j++ )
    {
      imap = map[e][j] ;
      org[j][0] = xyz[imap][0] ;
      org[j][1] = xyz[imap][1] ;
      org[j][2] = xyz[imap][2] ;
    }
    
    /* dihedral angle evaluation */
    dhd = E_dihedral(org) ;
    if ( dhd > minDhd )
      minDhd = dhd ; 
  }
 
  /* normalize the worst angle */
  return ( (1.+minDhd) * 0.5 ) ;
}
 

#ifdef __cplusplus
}
#endif
