/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Rao Garimella
  Creation  : Aug., 95
  Modifi.   : 
  Function  :
    Return the maximum edge length ratio of a region. Currently, only
    tetrahedrons are supported.
-------------------------------------------------------------------------*/
#include <math.h>
#include "oldFMDB.h"
#include "Defines.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

double R_edgLenRatio(pRegion reg) {
  pPList  vlist;
  pVertex vert;
  double  longest, shortest, xyz[10][3], vects[3], length;
  int     i,j;
  void   *temp=0;

  vlist = R_vertices(reg,1);
  temp = 0; i = 0;
  while (vert = PList_next(vlist,&temp)) {
    V_coord(vert,xyz[i]);
    i++;
  }
  PList_delete(vlist);

  shortest = 999999999.0;
  longest = 0.0;
  for (i=0; i<3; i++) {
    for (j=i+1; j<4; j++) {
      diffVt(xyz[i], xyz[j], vects);
      length = dotProd(vects, vects);
      if (length < shortest) shortest = length;
      if (length > longest) longest = length;
    }
  }
  return (sqrt(longest/shortest));
} /* R_edgeLenRatio */

#ifdef __cplusplus
}
#endif
