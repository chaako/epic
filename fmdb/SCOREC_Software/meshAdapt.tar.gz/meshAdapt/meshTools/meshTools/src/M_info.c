/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Debug Tools
  Author(s) : Pascal J. Frey
  Creation  : Jan., 95
  Modifi.   : Pascal Frey, Feb., 95
	      J. Wan, July 99
  Function  :
    Module to print information about mesh entities
-------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "MeshTools.h"
/* #include "Constants.h"      header is obsolete */ 
#include "modeler.h"

#ifdef __cplusplus
extern "C" {
#endif

int forcelink=0;

void M_info(pMesh m) {
  printf("mesh/model statistics\n");
  printf(" # regions : %12d\n",M_numRegions(m));
  printf(" # faces   : %12d\n",M_numFaces(m));
  printf(" # edges   : %12d\n",M_numEdges(m));
  printf(" # vertices: %12d\n",M_numVertices(m));
/*  printf(" # points  : %12d\n",M_numPoints(m)); */
}

void R_info(pRegion rgn) {
  pPList  list;
  pGEntity ent;
  pFace   face;
  pEdge   edge;
  pVertex vtx;
  double  xyz[3],sml,big,vol,shape;
  int     i, gtag;
  gType   gtype;
  void   *tmp;

  if (!rgn) {
    printf("Null pointer passed to R_info\n");
    return;
  }

  if (EN_type(rgn) != Tregion) {
    printf("\n****** Entity is not a Region!!!\n");
    return;
  }

  ent =(pGEntity)R_whatIn(rgn);
  if (!ent) {
    printf("\n****** Null Classification");
    gtag = -1;
  }
  else 
    gtag = GEN_tag(ent);
  gtype = R_whatInType(rgn);
  
  printf("\nRegion : 0x%x (ID=%7d)  model ent.: 0x%x  tag: %d\n",rgn,
	 (int)EN_id(rgn),ent,gtag);
  /* print 'quality' info. about region (for tets only) */
  if (R_numFaces(rgn)==4) {
    printf("Geometry:\n");
    vol = R_volume(rgn);
    printf(" volume      : %15.5f\n",vol);
    if (vol<0.)
      printf("  *** invalid element! ***\n");
    else {
      printf(" r/R ratio   : %15.5f\n",R_rbyR(rgn));
      R_dihedral(rgn,&sml,&big);
      sml = 180. * acos(sml) / M_PI;
      big = 180. * acos(big) / M_PI;
      printf(" dhd angles  : %15.5f\t%15.5f\n",sml,big);
      printf(" E_lgth ratio: %15.5f\n",R_edgLenRatio(rgn));
      printf(" aspect ratio: %15.5f\n",R_aspectRatio(rgn));
      R_shape(rgn,&shape);
      printf(" shape       : %15.5f\n",shape);
    }
  }
  printf("Topology:\n");
  printf("\nFaces       (ids):   type  model ent.      tag   orient\n");
  for ( i=0 ; i<R_numFaces(rgn) ; i++ ) {
    face = R_face(rgn,i);
    ent = F_whatIn(face);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = F_whatInType(face);
    printf(" 0x%x (%7d) %4d   0x%x %10d %4d\n",face,EN_id(face),gtype,ent, gtag, R_faceDir(rgn,i));
  }
  printf("\nEdges       (ids):   type  model ent.      tag   orient\n");
  list = R_edges(rgn,1);
  tmp=0;
  while (edge=(pEdge)PList_next(list,&tmp)) {
    ent = E_whatIn(edge);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = E_whatInType(edge);
    printf(" 0x%x (%7d) %4d   0x%x %10d\n",edge,EN_id(edge),gtype,ent,gtag);
  }
  PList_delete(list);
  list = R_vertices(rgn,1);
  printf("\nVertices    (ids):   type  model ent.      tag               coordinates\n");
  tmp = 0;
  while (vtx=(pVertex)PList_next(list,&tmp) ) {
    V_coord(vtx,xyz);
    ent = V_whatIn(vtx);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = V_whatInType(vtx);
    printf(" 0x%x (%7d) %4d   0x%x %10d %12.5f %12.5f %12.5f\n",
	   vtx,EN_id(vtx),gtype,ent,gtag,xyz[0],xyz[1],xyz[2]);
  }
  PList_delete(list);
}

void F_info(pFace face) {
  pPList   list;
  pGEntity ent;
  pRegion  rgn;
  pEdge    edge;
  pVertex  vtx;
  double   xyz[3];
  int      i, gtag, gtype;
  void*    tmp;

  if (!face) {
    printf("Null pointer passed to F_info\n");
    return;
  }

  if (EN_type(face) != Tface) {
    printf("\n****** Entity is not a Face!!!\n");
    return;
  }

  ent=(pGEntity)F_whatIn(face);
  if (!ent) {
    printf("\n****** Null Classification");
    gtag = -1;
  }
  else 
    gtag = GEN_tag(ent);
  gtype = F_whatInType(face);
  printf("\nFace : 0x%x (ID=%d)  type: %2d  model ent.: 0x%x  tag: %d\n",
	 face,EN_id(face),gtype,ent,gtag) ;
  printf("Topology:\n");
  printf("\nVertices    (ids):   type  model ent.      tag               coordinates\n") ;
  list = F_vertices(face,1);
  tmp=0;
  while (vtx=(pVertex)PList_next(list,&tmp)){
    V_coord(vtx,xyz);
    ent = V_whatIn(vtx);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = V_whatInType(vtx);
    printf(" 0x%x (%7d)  %4d  0x%x %10d %10.5f %10.5f %10.5f ",
	   vtx,EN_id(vtx),gtype,ent,gtag,xyz[0],xyz[1],xyz[2]);
    
    switch( gtype ) {
    case 1: 
      printf("(%10.7f) \n",P_param1(V_point(vtx)));
      break;
    case 2: {
      double par0,par1;
      int patch;
      P_param2(V_point(vtx),&par0, &par1, &patch);
      printf("(%10.7f, %10.7f) \n",par0,par1);
      break;
    }
    default:
      printf("\n");
    }
  }
  PList_delete(list);

  printf("\nEdges       (ids):   type  model ent.      tag   dir\tvertices\n");
  for ( i=0 ; i<F_numEdges(face) ; i++ ) {
    edge = F_edge(face,i);
    ent = E_whatIn(edge);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = E_whatInType(edge);
    printf(" 0x%x (%7d)  %4d   0x%x %10d %4d\t0x%x\t0x%x\n",edge,EN_id(edge),
	   gtype,ent,gtag,F_edgeDir(face,i),E_vertex(edge,0),
	   E_vertex(edge,1));
  }
  printf("\nRegions     (ids):   model ent.      tag\n");
  for (i=0 ; i<2 ; i++ ){
    rgn = F_region(face,i);
    if (rgn){
      ent = (pGEntity) R_whatIn(rgn);
      gtag = ent ? GEN_tag(ent) : -1;
      gtype = R_whatInType(rgn);
      printf(" 0x%x (%d)  \t0x%x %10d\n",rgn,EN_id(rgn),ent,gtag);
    }
  }
}

void E_info(pEdge edge) {
  pPList   list;
  pGEntity ent;
  pRegion  rgn;
  pFace    face;
  pVertex  vtx;
  double   xyz[3];
  int      i, gtag, gtype;
  void    *tmp;

  if (!edge) {
    printf("Null pointer passed to E_info\n");
    return;
  }

  if (EN_type(edge) != Tedge) {
    printf("\n****** Entity is not a Edge!!!\n");
    return;
  }

  ent=(pGEntity)E_whatIn(edge);
  if (!ent) {
    printf("\n****** Null Classification");
    gtag = -1;
  }
  else 
    gtag = GEN_tag(ent);
  gtype = E_whatInType(edge);

  /* print edge classification */
  printf("\nEdge : 0x%x (%d)  type: %2d  model ent.: 0x%x  tag: %d\n",
	 edge,EN_id(edge),gtype,ent,gtag);
  printf("Topology:\n");
  printf("\nVertices    (ids):   type model ent.      tag               coordinates\n");
  for ( i=0 ; i<2 ; i++ ) {
    vtx = E_vertex(edge,i);
    V_coord(vtx,xyz);
    ent = V_whatIn(vtx);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = V_whatInType(vtx);
    printf(" 0x%x (%7d)  %4d  0x%x %10d %10.5f %10.5f %10.5f\n",
	   vtx,EN_id(vtx),gtype,ent,gtag,xyz[0],xyz[1],xyz[2]);
  }
  printf("\nFaces       (ids):   type model ent.      tag\n");
  for ( i=0 ; i<E_numFaces(edge) ; i++ ) {
    face = E_face(edge,i);
    ent = F_whatIn(face);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = F_whatInType(face);
    printf(" 0x%x (%7d) %4d   0x%x %10d\n",face,EN_id(face),gtype,ent,
	   gtag);
  }
  list = E_regions(edge);
  printf("\nRegions     (ids):    model ent.      tag\n");
  tmp = 0;
  while ( rgn = PList_next(list,&tmp) ) {
    ent = (pGEntity) R_whatIn(rgn);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = R_whatInType(rgn);
    printf(" 0x%x (%7d)  0x%x %10d\n",rgn,EN_id(rgn),ent,gtag);
  }
  PList_delete(list);
}

void V_info(pVertex vtx) {
  pGEntity ent;
  pPList   list;
  pFace    face;
  pEdge    edge;
  double   xyz[3],r,s;
  int      i, gtag, gtype,patch;
  void    *tmp;
  
  if (!vtx) {
    printf("Null pointer passed to V_info\n");
    return;
  }

  if (EN_type(vtx) != Tvertex) {
    printf("\n****** Entity is not a Vertex!!!\n");
    return;
  }

  ent=(pGEntity)V_whatIn(vtx);
  if (!ent) {
    printf("\n****** Null Classification");
    gtag = -1;
  }
  else 
    gtag = GEN_tag(ent);
  gtype = V_whatInType(vtx);
  printf("\nVertex: 0x%x (%d)  type: %2d  model ent.: 0x%x  tag: %d\n",
	 vtx,EN_id(vtx),gtype,ent,gtag);
  V_coord(vtx,xyz);
  printf("Coordinates: %15.5f %15.5f %15.5f\n",xyz[0],xyz[1],xyz[2]);
  switch (GEN_type(ent)) {
  case Tedge:
    printf("Parameters : %15.5f\n",P_param1(V_point(vtx)));
    break;
  case Tface:
    P_param2(V_point(vtx),&r,&s,&patch);
    printf("Parameters : %15.5f %15.5f\tpatch: %d\n",r,s,patch);
    break;
  default:
    break;
  }
  printf("\nEdges       (ids):   type model ent.      tag\n");
  for ( i=0 ; i<V_numEdges(vtx) ; i++ ) {
    edge = V_edge(vtx,i);
    ent = E_whatIn(edge);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = E_whatInType(edge);
    printf(" 0x%x (%7d) %4d   0x%x %10d\n",edge,EN_id(edge),gtype,ent,	   gtag);
  }
  printf("\nFaces       (ids):   type model ent.      tag\n");
  list = V_faces(vtx);
  tmp = 0;
  while ( face=(pFace)PList_next(list,&tmp) ) {
    ent = F_whatIn(face);
    gtag = ent ? GEN_tag(ent) : -1;
    gtype = F_whatInType(face);
    printf(" 0x%x (%7d) %4d   0x%x %10d\n",face,EN_id(face),gtype,ent,gtag);
  }
  PList_delete(list);
}

void EN_info(pEntity entity) {
  if (!entity) {
    printf("Null pointer passed to EN_info\n");
    return;
  }

  switch (EN_type(entity)) {
    case Tvertex:
      V_info((pVertex)entity);
      break;
    case Tedge: 
      E_info((pEdge)entity);
      break;
    case Tface: 
      F_info((pFace)entity);
      break;
    case Tregion: 
      R_info((pRegion)entity);
      break;
    default:
      printf("***** Unrecognized entity type\n");
      break;
  }
}

#ifdef __cplusplus
}
#endif
