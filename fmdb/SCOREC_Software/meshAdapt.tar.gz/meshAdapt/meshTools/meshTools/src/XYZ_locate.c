/*
B. Kaan Karamete
Jan. 8, 1999. 09:30
*/

#include "MeshTools.h"
#include <math.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

int searchEveryFace(double px[3],pEntity* face,double tol)
{
int i,j,orient,k,m,ok;
pFace face2;
pEdge edge, edge2;
pPList vlist,slist;
double x[3][3],normal[3], fxyz[3][3], xpro,vol;
void* tmp;

 slist=PList_new(); 
 for(i=0;i<3;++i){
   edge =F_edge (*face, i);
   PList_append(slist,edge);
   EN_attachDataI(edge,"srch",1);
 }


 ok=0;
 tmp=0;
 while(edge2=PList_next(slist,&tmp)) {
      
   for(k=0;k<2;++k){
     face2=E_face (edge2,k);
     if(face2){
       ok=1;

       for(i=0;i<3;++i){ 
	 edge =F_edge (face2,i);
	 orient=F_edgeDir(face2,i);
         V_coord(E_vertex(edge,1-orient),x[0]);
         V_coord(E_vertex(edge,orient),x[1]);

	 vol=P_distToLine (px, x[0],x[1],normal);
	 if(vol<-tol*tol){
	   ok=0;
	   break;
	 }
       }

       if(!ok){
	 for(m=0;m<3;++m){
	   edge =F_edge (face2,m);
	   if(EN_dataI(edge,"srch")) 
	     continue;
	   PList_append(slist,edge);
	   EN_attachDataI(edge,"srch",1);
	 }
       }
       else
	 break;
     }
   }
   if(ok)
     break;
 }
 for(i=0;i<PList_size(slist);++i){
   edge=PList_item(slist,i);
   EN_removeData(edge,"srch");
 }
 PList_delete(slist);
 if(ok){
   *face=face2;
   return(1);
 }
 else
   return(0);
}

int searchEveryRegion(double px[3],pEntity* region,double tol)
{
int i,j,orient,k,m,ok;
pFace face,face2;
pRegion region2;
pPList vlist,slist;
double x[3][3],snorm,vol;
void* tmp;
 slist=PList_new(); 
 for(i=0;i<4;++i){
   face=R_face(*region,i);
   PList_append(slist,face);
   EN_attachDataI(face,"srch",1);
 }

 ok=0;
 tmp=0;
 while(face2=PList_next(slist,&tmp)){
      
   for(k=0;k<2;++k){
     region2=F_region(face2,k);
     if(region2){
       ok=1;
       for(i=0;i<4;++i){ 
	 face=R_face(region2,i);
	 orient=R_faceDir(region2,i);
	 vlist=F_vertices(face,!orient);
	 for(j=0;j<3;++j)
	   V_coord(PList_item(vlist,j),x[j]);
	 PList_delete(vlist);
	 vol=P_distToPlane(px, x[0],x[1],x[2],&snorm);
	 if(vol<-tol*sqrt(snorm)){
	   ok=0;
	   break;
	 }
       }
       if(!ok){
	 for(m=0;m<4;++m){
	   face=R_face(region2,m);
	   if(EN_dataI(face,"srch")) 
	     continue;
	   PList_append(slist,face);
	   EN_attachDataI(face,"srch",1);
	 }
       }
       else
	 break;
     }
   }
   if(ok)
     break;
 }
 for(i=0;i<PList_size(slist);++i){
   face=PList_item(slist,i);
   EN_removeData(face,"srch");
 }
 PList_delete(slist);
 if(ok){
   *region=region2;
   return(1);
 }
 else
   return(0);
}

 

int XYZ_locate(double px[3], pEntity* seed, double tol)
{

double x[3][3];
int i,ok,icount,k,found,orient,j;
long int s;
pEdge edge;
pFace face,face2;
pPList vlist;
double vol;
pRegion region2,region;
double normal[3];
double snorm;
double fxyz[3][3],xpro[3];
eType t;
pFace oldface;
int fluk;

 if(*seed==0){
   MT_ErrorHandler("Should Specify a seed entity","XYZ_locate",MESSG);
   return(0);
 }

 t=EN_type(*seed);
 switch (t) {
  case Tface: 
        fluk=0;
	oldface=(pFace)0;
        do{
         found=1;
         s=time(NULL);
         srand(s);         
         i=rand()%3;
	 face =(pFace)*seed;
	 icount=0;

	 vlist=F_vertices(face,1);
	 for(j=0;j<3;++j)
           V_coord(PList_item(vlist,j),fxyz[j]);
	 PList_delete(vlist);
	 P_projOnTriPlane(fxyz,px,xpro,normal,&snorm);

	 while(icount<3){
          ++icount;
          edge=F_edge(face,i);
          orient=F_edgeDir(face,i);
	  V_coord(E_vertex(edge,1-orient),x[0]);          
	  V_coord(E_vertex(edge,orient),x[1]);
	  vol=P_distToLine(xpro,x[0],x[1],normal);
          if(vol < -(tol*tol) ){
            ok=0;
            for(j=0;j<2;++j){
              face2=E_face(edge,j);
              if(face2)
              if(face2!=face && F_numEdges(face2)==3){
		if(face2==oldface){
		  fluk=1;
		  break;
                }
		oldface=*seed;
                *seed=(pEntity)face2;
                ok=1;  
                break;
              }
            }
            if(!ok && icount==3) {
	      /*
	      ok =searchEveryFace (px, seed, tol);
	      if (!ok) return(0);
	      else {
		found =1;
		break;
	      }
	      */
	      return 0;
	    }
	    if(fluk){
	      found=1;
	      break;
            } 
            found=0;
            break;
          }
          i=(i+1)%3;
         }
        }while(!found);

	if(fluk)
	  *seed=(pEntity)edge;
	else
	  *seed=XYZ_onBoundary (px,*seed,tol);
        break;

  case Tregion:

       do{
         found=1;
         s=time(NULL);
         srand(s);
         i=rand()%4;
	 region =(pRegion)*seed;
         icount=0;
         while(icount<4){
          ++icount;
          face=R_face(region,i);
          orient=R_faceDir(region,i);
          vlist=F_vertices(face,!orient);
	  for(j=0;j<3;++j)
           V_coord(PList_item(vlist,j),x[j]);
          PList_delete(vlist);
          vol=P_distToPlane(px, x[0],x[1],x[2],&snorm);
          if(vol<-tol*sqrt(snorm)){
            ok=0; 
            for(k=0;k<2;++k){
              region2=F_region(face,k);
              if(region2)
              if(region2!=region && 
		 R_numFaces(region2)==4){
                *seed=(pEntity)region2;
                ok=1;
                break;
              }
            }
            if(!ok && icount==4){
	      ok=searchEveryRegion(px,seed,tol);
	      if(!ok)
		return(0);
	      else{
		found=1;
		break;
              } 
	    }		
            found=0;
            break;  
          }
         i=(i+1)%4;
         } 
        }while(!found);

        *seed =XYZ_onBoundary (px,*seed,tol); 
        break;
 }
 
 return(1);
}


#ifdef __cplusplus
}
#endif


