/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Tools
  Author(s) : J. Wan
  Creation  : October, 1999
  Function  :
              Compute the intersection between a face and a region. 
	      If there exists intersection, return 1 else 0. The 
	      details of intersection are returned via IntersectionData.
-------------------------------------------------------------------------*/

#include "MeshTools.h"
#include "oldFMDB.h"
#include "Defines.h"
#include <math.h>

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
#endif

/* checks if two faces are coplanar;
   If two faces are coplanar, return 1 else 0*/
int M_coplanarFaces (pFace face1, pFace face2, double tol) 
{
  pPList vlist;
  int i;
  double F1_xyz[3][3], F2_xyz[3][3], F_vector[2][3], normal[3], tmp[4];

  /* Retrieve coordinates of Face 1 */
  vlist =F_vertices (face1, 1);
  for (i=0; i<3; i++) 
    V_coord  (PList_item (vlist, i),F1_xyz[i]);
  PList_delete (vlist);
  
  /* Retrieve coordinates of Face 2 */
  vlist =F_vertices (face2, 1);
  for (i=0; i<3; i++)
    V_coord (PList_item (vlist, i), F2_xyz[i]); 
  PList_delete (vlist);

  for (i=0; i<2; i++)
    diffVt (F1_xyz[i+1], F1_xyz[0], F_vector[i]);

  crossProd (F_vector[0], F_vector[1], normal);

  for (i=0; i<3; i++) {
    diffVt (F2_xyz[i], F1_xyz[0], F_vector[0]);
    tmp[3] =dotProd (normal, F_vector[0]);
    tmp[i] =tmp[3]*tmp[3];
  }
  tmp[3]=tol*tol*dotProd (normal, normal);

  if (tmp[0] <= tmp[3] && tmp[1] <= tmp[3] && tmp[2]<=tmp[3])
    return 1;  /* Faces are coplanar */

  return 0;    /* Faces are not coplanar */
}

/* checks if edge is coplanar with a face;
   If two ents are coplanar, return 1 else 0*/
int M_coplanarEdgeFace (pEdge edge, pFace face, double tol) 
{
  double F_xyz[3][3], E_xyz[2][3];
  int i;
  pPList vlist;
  double fVector[2][3], Normal[3], vol[3];

  /* Get the vertices and their coordinates */
  for (i=0; i<2; i++)
    V_coord (E_vertex (edge, i), E_xyz[i]);
  
  vlist =F_vertices (face, 1);
  for (i=0; i<3; i++)
    V_coord (PList_item (vlist, i), F_xyz[i]);
  PList_delete (vlist);

  /* Check if the entities are coplanar */
  for (i=0; i<2; i++)
    diffVt (F_xyz[i+1], F_xyz[0], fVector[i]);
  crossProd (fVector[0], fVector[1], Normal);

  for (i=0; i<2; i++) {
    diffVt (E_xyz[i], F_xyz[0], fVector[i]);
    vol[i] =pow (dotProd (Normal, fVector[i]),2);
  }
  vol[2]=tol*tol*dotProd (Normal, Normal);

  /* Analyze the cases */
  if (vol[0] <= vol[2] && vol[1] <= vol[2])
    return 1;  /* ents are coplanar */

  return 0;    /* ents are not coplanar */
}

/* checks if two edges are colinear;
   If two edges are colinear, return 1 else 0*/
int M_colinearEdges (pEdge edge1, pEdge edge2, double tol) 
{
  double L1_xyz[2][3], L2_xyz[2][3];
  int i;
  double L_vector[2][3], Normal[3], vol[3];

  for (i=0; i<2; i++) {
    V_coord (E_vertex (edge1, i), L1_xyz[i]);
    V_coord (E_vertex (edge2, i), L2_xyz[i]);
  }
  
  /* Computes the vector and concerned values */
  diffVt (L1_xyz[1], L1_xyz[0], L_vector[0]);


  for (i=0; i<2; i++) {
    diffVt (L2_xyz[i], L1_xyz[0], L_vector[1]);
    crossProd (L_vector[0], L_vector[1], Normal);
    vol[i] =dotProd (Normal, Normal);
  }

  vol[2] =dotProd (L_vector[0], L_vector[0])*tol*tol;
  
  /* check if the edges are colinear */
  if (vol[0]*vol[0] <= vol[2] && vol[1]*vol[1] <= vol[2])
    return 1;
  
  return 0;    /* edges are not colinear*/
}


int R_intersectFace (pRegion reg, int ClosureFlag1, pFace face, int ClosureFlag2, IntersectionData *idata)
{
  double int_xyz[6][3], tol, tol2;
  int i, j, k, num_int[2]={-1,-1}, faceCounted=0, regCounted=0;
  pVertex v[3];
  pEdge edge;
  pFace r_face;
  pPList vlist;
  int NumExistingIntPts;
  struct IntDescription *thisDescription;
  pEntity int_Ent1[6], int_Ent2[6];

  /* Initialize */
  tol =M_getTolerance();
  tol2 =tol*tol;

  /* Record the procedure: 
     1) if the routine is called independently, NumExistingIntPts=0
     2) if the routine is called embeddedly, NumExistingIntPts may Nonzero */
  NumExistingIntPts =idata->nbr;

  /* Compute the intersections between the faces of reg and the face */
  /* Up to six (6) intersection bounding pts may exist between the ents*/

  /* First check if Face is coplanar with any face of reg */
  for (i=0; i<4; i++) {
    r_face =R_face (reg, i);

    if (M_coplanarFaces (r_face, face, tol)) {
      /* Face and r_face are coplanar */
      if (ClosureFlag1) {
	return M_intersectFaces (r_face, 1, face, ClosureFlag2, idata);

	/* All pts have been found, process done */

      } else   /* ClosureFlag1 =0 */
	return 0;  /* No intersection found */
    }
  }


  /* When Face is coplanar with none face of reg, do the following */
  for (i=0; i<4; i++) {
    r_face =R_face (reg, i);
    M_intersectFaces (r_face, 1, face, 1, idata);
    
    /* If 6 pts found, stop */
    if (idata->nbr-NumExistingIntPts==6) break;
  }


  /* If less than 6 pts found */
  if (idata->nbr-NumExistingIntPts<6) {
    /* Retrieve Face info */
    vlist =F_vertices (face, 1);
    for (i=0; i<3; i++) {
      v[i] =PList_item (vlist, i);
      V_coord (v[i],int_xyz[i]);
    }
    PList_delete (vlist);

 
    /* explore potential pts */
    if (idata->nbr-NumExistingIntPts==0) {
      /* the face is completely inside or outside reg */
      if (IntXYZ_insideRegion (int_xyz[0], reg, tol2)) {
	/* The whole face is inside the region */
	if (ClosureFlag2)
	  for (i=0; i<3; i++)
	    M_updateIntersectionData (idata, reg, v[i], int_xyz[i], tol2);
	else
	  for (i=0; i<3; i++)
	    M_updateIntersectionData (idata, reg, face, int_xyz[i], tol2);

	if (NumExistingIntPts) return 1;
	if (ClosureFlag2) {   /* ClosureFlag2 =1 */
	  /* Append the bounded ents on Face */
	  PList_append (idata->boundedEntList, face);
	  for (i=0; i<3; i++)
	    PList_append (idata->boundedEntList, F_edge (face, i));
	}

	idata->dim =2;
	/* All info found, process done */
	return 1;
      }
      else  /* The whole face is outside reg */ 
	return 0;  /* No intersection */
      
    } else {    
      /* Face crosses reg, all pts may be on the boundary of reg,
	 or some pts on the boundary and some inside*/
      /* check if the vertices of face fall inside reg */

      num_int[0] =idata->nbr;
      for (i=0; i<3; i++) {
	if (xyz_inIntersectionData (idata, int_xyz[i], tol2)==0) {
	  /* This vertex is not already in intersectionData */
	  if (IntXYZ_insideRegion (int_xyz[i], reg, tol2)) {
	    M_updateIntersectionData (idata, reg, v[i], int_xyz[i], tol2);
	    if (idata->nbr-NumExistingIntPts==6)
	      break;   /* Sure that all bounding pts have been found */
	  }
	}
      }
    } 
  }

  /* So far we have finished the computation of bounding pts */

  /* When it is called as a subroutine of another complex intersection routine,
     do not apply closure control */
  if (NumExistingIntPts) return 1;

  /* Now we start to implement the closure control. Note that we donot need to
     consider the situation when Face is coplanar with a face of reg */
  /* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  /* Start to implement closure control and append bounded ents */
  /* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

  thisDescription =idata->Description;
  
  /* First retrieve the intersection bounding points into array */
  num_int[1] =idata->nbr;
  for (i=0; i<idata->nbr; i++) {
    int_Ent1[i] =thisDescription->IntEnt1;
    int_Ent2[i] =thisDescription->IntEnt2;
    for (j=0; j<3; j++)
      int_xyz[i][j] =thisDescription->xyz[j];
    thisDescription =thisDescription->next;
  }
 

  /* Initialize the intersectionData */
  M_intersectionData_delete (*idata);
  *idata =M_intersectionData_new ();

  switch (num_int[1]) {

  case 1:    /* The whole face is inside reg */
    if (ClosureFlag1 && ClosureFlag2)    /* Full closure case */
      M_updateIntersectionData (idata, int_Ent1[0], int_Ent2[0], int_xyz[0], -1);
    else 
      return 0;
    break;

  case 2:
    if (ClosureFlag1 && ClosureFlag2) {     /* Full closure case */
      
      /* ******  First consider the bounded ents on reg ******   */
      /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

      switch (EN_type (int_Ent1[0])) {
	
      case Tvertex:   /* 1st pt located on a vertex */

	switch (EN_type (int_Ent1[1])) {
	    
	case Tvertex:   /* 1st pt on a vertex, 2nd pt on a vertex */
	  /* the ents intersect on a whole edge of reg */
	  PList_append (idata->boundedEntList, M_boundedEdgeOnRegion (reg, int_Ent1[0], int_Ent1[1]));
	  break;

	case Tedge:     /* 1st pt on a vertex, 2nd pt on an edge */
	  /* to check if the ents intersect on a part of an edge of reg */
	  if (int_Ent1[0]!=E_vertex (int_Ent1[1],0) && int_Ent1[0]!=E_vertex (int_Ent1[1],1)) {
	    
	    r_face =M_boundedFaceOnRegion (reg, int_Ent1[0], int_Ent1[1]);
	    if (r_face) /* a face of reg bounded by bounding pts */
	      PList_append (idata->boundedEntList, r_face);
	  }
	  break;
	}  /* end of switch */
	break;
	
      case Tedge:   /* 1st pt located on an edge */
	
	switch (EN_type (int_Ent1[1])) {
	  
	case Tvertex:     /* 1st pt on an edge, 2nd pt on a vertex */
	  /* to check if the ents intersect on a part of an edge of reg */
	  if (int_Ent1[1]!=E_vertex (int_Ent1[0],0) && int_Ent1[1]!=E_vertex (int_Ent1[0],1)) {
	    
	    r_face =M_boundedFaceOnRegion (reg, int_Ent1[0], int_Ent1[1]);
	    if (r_face)   /* a face of reg bounded by bounding pts */
	      PList_append (idata->boundedEntList, r_face);
	  }
	  break;
	  
	case Tedge:    /* 1st pt on an edge, 2nd pt on an edge */
	  /* to check if an edge of face lies on an edge of reg */
	  if (int_Ent1[0]!=int_Ent1[1]) {
	    
	    /* An edge of face crosses a face of reg or reg itself*/
	    
	    r_face =M_boundedFaceOnRegion (reg, int_Ent1[0], int_Ent1[1]);
	    if (r_face)    /* a face of reg bounded bounding pts*/ 
	      PList_append (idata->boundedEntList, r_face);
	  }
	  break;
	}   /* end of switch */
	break;

      }  /* End of switch */
      

      /* ***** Secondly, consider the bounded ents on face ***** */
      /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

      switch (EN_type (int_Ent2[0])) {
	
      case Tvertex:   /* 1st pt located on a vertex */

	switch (EN_type (int_Ent2[1])) {
	    
	case Tvertex:   /* 1st pt on a vertex, 2nd pt on a vertex */
	  /* the ents intersect on a whole edge of face */
	  PList_append (idata->boundedEntList, M_boundedEdgeOnFace (face, int_Ent2[0], int_Ent2[1]));
	  break;

	case Tedge:     /* 1st pt on a vertex, 2nd pt on an edge */
	  /* to check if the ents intersect on an edge of face */
	  if (int_Ent2[0]!=E_vertex (int_Ent2[1],0) && int_Ent2[0]!=E_vertex (int_Ent2[1],1))
	    /* face bounded by bounding pts */
	    PList_append (idata->boundedEntList, face);
	  break;
	  
	}  /* end of switch */
	break;
	
      case Tedge:   /* 1st pt located on an edge */
	
	switch (EN_type (int_Ent2[1])) {
	  
	case Tvertex:     /* 1st pt on an edge, 2nd pt on a vertex */
	  /* to check if the ents intersect on an edge of face */
	  if (int_Ent2[1]!=E_vertex (int_Ent2[0],0) && int_Ent2[1]!=E_vertex (int_Ent2[0],1))
	    /* face bounded by bounding pts */
	    PList_append (idata->boundedEntList, face);	
	  break;
	  
	case Tedge:    /* 1st pt on an edge, 2nd pt on an edge */
	  /* to check if the ents intersect on an edge of face */
	  if (int_Ent1[0]!=int_Ent1[1])
	    /* face bounded by bounding pts */
	    PList_append (idata->boundedEntList, face);	    

	  break;
	}  /* end of switch */ 
	break;

      }  /* End of switch */      
      
      for (i=0; i<2; i++)
	M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);
      
    } else
      return 0;    /* No intersection */      
    break;
    
  case 3:
  case 4:
  case 5:
  case 6:
    if (ClosureFlag1) {    /* ClosureFlag1 =1 */
      if (ClosureFlag2) {  /* Full closure case */

	/* ++++++++++++++ Consider reg first ++++++++++++++ */

	/* Append bounded ents on reg by intuition */
	if (num_int[0]==num_int[1])  /* No pts inside reg */
	  PList_append (idata->boundedEntList, reg);

	/* Append bounded ents on reg by reasoning*/
	for (i=0; i<num_int[0]; i++)
	  for (j=i+1; j<num_int[0]; j++) {
	    
	    switch (EN_type (int_Ent1[i])) {
	
	    case Tvertex:   /* ith pt located on a vertex */
	      
	      switch (EN_type (int_Ent1[j])) {
		
	      case Tvertex:   /* ith pt on a vertex, jth pt on a vertex */
		/* the ents intersect on a whole edge of reg */
		PList_append (idata->boundedEntList, M_boundedEdgeOnRegion (reg, int_Ent1[i], int_Ent1[j]));
		break;
		
	      case Tedge:     /* ith pt on a vertex, jth pt on an edge */
		/* to check if the ents intersect on an edge of reg */
		if (int_Ent1[i]!=E_vertex (int_Ent1[j],0) && int_Ent1[i]!=E_vertex (int_Ent1[j],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg, int_Ent1[i], int_Ent1[j]);
		  if (r_face) /* a face of reg bounded by bounding pts */
		    PList_append (idata->boundedEntList, r_face);
		}
		break;

	      }  /* end of switch */
	      break;
	      
	    case Tedge:   /* ith pt located on an edge */
	      
	      switch (EN_type (int_Ent1[j])) {
		
	      case Tvertex:     /* ith pt on an edge, jth pt on a vertex */
		/* to check if the ents intersect on a part of an edge of reg */
		if (int_Ent1[j]!=E_vertex (int_Ent1[i],0) && int_Ent1[j]!=E_vertex (int_Ent1[i],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg, int_Ent1[i], int_Ent1[j]);
		  if (r_face)   /* a face of reg bounded by bounding pts */
		    PList_append (idata->boundedEntList, r_face);
		}
		break;
		
	      case Tedge:    /* ith pt on an edge, jth pt on an edge */
		/* to check if an edge of face lies on an edge of reg */
		if (int_Ent1[i]!=int_Ent1[j]) {
		  
		  /* An edge of face crosses a face of reg or reg itself*/
		  
		  r_face =M_boundedFaceOnRegion (reg, int_Ent1[i], int_Ent1[j]);
		  if (r_face)    /* a face of reg bounded bounding pts*/ 
		    PList_append (idata->boundedEntList, r_face);	
		}
		break;
	      }   /* end of switch */
	      break;	      
	      
	    }  /* End of switch */

	  }  /* end of for */


	/* ++++++++++++++ Then consider face ++++++++++++++ */

	/* Append bounded ents on face by intuition */
	for (i=0; i<num_int[1]; i++)
	  if (EN_type (int_Ent2[i])==Tface) {
	    faceCounted =1;
	    break;
	  }
	if (faceCounted==0) {
	  PList_append (idata->boundedEntList, face);
	  faceCounted =1;
	}

	/* Append bounded ents on face by reasoning*/
	for (i=0; i<num_int[1]; i++)
	  for (j=i+1; j<num_int[1]; j++) {

	    switch (EN_type (int_Ent2[i])) {
	      
	    case Tvertex:   /* ith pt located on a vertex */
	      
	      switch (EN_type (int_Ent2[j])) {
		
	      case Tvertex:   /* ith pt on a vertex, jth pt on a vertex */
		/* the ents intersect on a whole edge of face */
		PList_append (idata->boundedEntList, M_boundedEdgeOnFace (face, int_Ent2[i], int_Ent2[j]));
		break;
		
	      case Tedge:     /* ith pt on a vertex, jth pt on an edge */
		/* to check if the ents intersect on an edge of face */
		if (faceCounted==0)
		  if (int_Ent2[i]!=E_vertex (int_Ent2[j],0) && int_Ent2[i]!=E_vertex (int_Ent2[j],1))
		    /* face bounded by bounding pts */
		    PList_append (idata->boundedEntList, face);
		break;
		
	      }  /* end of switch */
	      break;
	      
	    case Tedge:   /* ith pt located on an edge */
	      
	      switch (EN_type (int_Ent2[j])) {
		
	      case Tvertex:     /* ith pt on an edge, jth pt on a vertex */
		/* to check if the ents intersect on an edge of face */
		if (faceCounted==0)
		  if (int_Ent2[j]!=E_vertex (int_Ent2[i],0) && int_Ent2[j]!=E_vertex (int_Ent2[i],1))
		    /* face bounded by bounding pts */
		    PList_append (idata->boundedEntList, face);	
		break;
		
	      case Tedge:    /* ith pt on an edge, jth pt on an edge */
		/* to check if the ents intersect on an edge of face */
		if (faceCounted==0)
		  if (int_Ent1[i]!=int_Ent1[j])
		    /* face bounded by bounding pts */
		    PList_append (idata->boundedEntList, face);	    
		
		break;
	      }  /* end of switch */ 
	      break;
	      
	    }  /* End of switch */ 
	    
	  } /* end of for */
	
      } else {             /* Half closure case, ClosureFlag1=1, ClosureFlag2=0 */
	
	/* Append bounded ents on reg by reasoning*/
	for (i=0; i<num_int[0]; i++)
	  for (j=i+1; j<num_int[0]; j++) {
	    
	    /* if intersect on an edge of face. skip it */
	    if (EN_type (int_Ent2[i])==Tvertex && 
		(EN_type (int_Ent2[j])==Tvertex || EN_type (int_Ent2[j])==Tedge && 
		 (int_Ent2[i]==E_vertex (int_Ent2[j],0) || int_Ent2[i]==E_vertex (int_Ent2[j],1))) ||
		EN_type (int_Ent2[j])==Tvertex && EN_type (int_Ent2[i])==Tedge && 
		(int_Ent2[j]==E_vertex(int_Ent2[i],0) || int_Ent2[j]==E_vertex (int_Ent2[i],1))) continue;
	    
	    switch (EN_type (int_Ent1[i])) {
	      
	    case Tvertex:   /* ith pt located on a vertex */
	      
	      switch (EN_type (int_Ent1[j])) {
		
	      case Tvertex:   /* ith pt on a vertex, jth pt on a vertex */
		/* the ents intersect on a whole edge of reg */
		PList_append (idata->boundedEntList, M_boundedEdgeOnRegion (reg, int_Ent1[i], int_Ent1[j]));
		break;
		
	      case Tedge:     /* ith pt on a vertex, jth pt on an edge */
		/* to check if the ents intersect on an edge of reg */
		if (int_Ent1[i]!=E_vertex (int_Ent1[j],0) && int_Ent1[i]!=E_vertex (int_Ent1[j],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg, int_Ent1[i], int_Ent1[j]);
		  if (r_face) /* a face of reg bounded by bounding pts */
		    PList_append (idata->boundedEntList, r_face);
		}
		break;
		
	      }  /* end of switch */
	      break;
	      
	    case Tedge:   /* ith pt located on an edge */
	      
	      switch (EN_type (int_Ent1[j])) {
		
	      case Tvertex:     /* ith pt on an edge, jth pt on a vertex */
		/* to check if the ents intersect on a part of an edge of reg */
		if (int_Ent1[j]!=E_vertex (int_Ent1[i],0) && int_Ent1[j]!=E_vertex (int_Ent1[i],1)) {
		  
		  r_face =M_boundedFaceOnRegion (reg, int_Ent1[i], int_Ent1[j]);
		  if (r_face)   /* a face of reg bounded by bounding pts */
		    PList_append (idata->boundedEntList, r_face);
		}
		break;
		
	      case Tedge:    /* ith pt on an edge, jth pt on an edge */
		/* to check if an edge of face lies on an edge of reg */
		if (int_Ent1[i]!=int_Ent1[j]) {
		  
		  /* An edge of face crosses a face of reg or reg itself*/
		  
		  r_face =M_boundedFaceOnRegion (reg, int_Ent1[i], int_Ent1[j]);
		  if (r_face)    /* a face of reg bounded bounding pts*/ 
		    PList_append (idata->boundedEntList, r_face);	
		}
		break;
	      }   /* end of switch */
	      break;	      
	      
	    }  /* End of switch */
	    
	  }  /* end of for */
	
	for (i=0; i<num_int[1]; i++) {
	  switch (EN_type (int_Ent2[i])) {
	  case Tvertex:  /* Intersect on a vertex of face */
	    int_Ent1[i] =reg;
	    break;
	  case Tedge:    /* Intersect on an edge of face */
	    switch (EN_type (int_Ent1[i])) {
	    case Tvertex:  /* an edge of face crosses thru a vertex of reg */
	      int_Ent1[i] =reg;
	      break;
	    case Tedge:    /* an edge of face crosses thru an edge of reg */
	      /* check if the edge of reg is coplanar with face */
	      if (M_coplanarEdgeFace (int_Ent1[i], face, tol)==0)
		/* Not coplanar */
		int_Ent1[i] =reg;
	      break;
	    }
	    break;	    
	  }
	  int_Ent2[i] =face;
	}

	regCounted =0;
	for (i=0; i<num_int[1]; i++)
	  if (EN_type (int_Ent1[i])==Tregion) {
	    regCounted =1;
	    break;
	  }
       if (regCounted==0)
	 PList_append (idata->boundedEntList, reg);

      }
      
    } else {               /* ClosureFlag1 =0 */
      if (ClosureFlag2) {  /* Half closure case, ClosureFlag1 =0, Closureflag2 =1 */

	/* Snap the bounding pts on face */
	for (i=0; i<num_int[1]; i++) {
	  switch (EN_type (int_Ent1[i])) {
	  case Tvertex:
	    switch (EN_type (int_Ent2[i])) {
	    case Tvertex:
	      int_Ent2[i] =face;
	      break;
	    case Tedge:
	      faceCounted =0;
	      for (k=0; k<4; k++)
		if (M_coplanarEdgeFace (edge, R_face (reg, k), tol)) {
		  faceCounted =1;
		  break;
		}
	      
	      if (faceCounted)
		int_Ent2[i] =face;
	      
	      break;
	    }
	    break;
	 
	  case Tedge:
	    switch (EN_type (int_Ent2[i])) {
	    case Tvertex:
	      int_Ent2[i] =face;
	      break;
	    case Tedge:
	      if (M_colinearEdges (int_Ent1[i], int_Ent2[i], tol))
		int_Ent2[i] =face;
	      break;
	    }
	    break;
	    
	  case Tface:
	    switch (EN_type (int_Ent2[i])) {
	    case Tvertex:
	      int_Ent2[i] =face;
	      break;
	    case Tedge:
	      if (M_coplanarEdgeFace (int_Ent2[i], int_Ent1[i], tol)) {
		int_Ent2[i] =face;
		break;
	      }
	      break;
	    }
	  }
	  int_Ent1[i] =reg;
	}

	/* Append bounded ents on face by reasoning*/
	for (i=0; i<num_int[1]; i++)
	  for (j=i+1; j<num_int[1]; j++) {
	    
	    switch (EN_type (int_Ent2[i])) {
	      
	    case Tvertex:   /* ith pt located on a vertex */
	      
	      switch (EN_type (int_Ent2[j])) {
		
	      case Tvertex:   /* ith pt on a vertex, jth pt on a vertex */
		/* the ents intersect on a whole edge of face */		
		edge =M_boundedEdgeOnFace (face, int_Ent2[i], int_Ent2[j]);
		PList_append (idata->boundedEntList, edge);
		break;

	      }  /* end of switch */
	      break;
	    }  /* End of switch */ 
	    
	  } /* end of for */
	

	/* Append face as a bounded ent if applicable */
	faceCounted =0;
	for (i=0; i<num_int[1]; i++) 
	  if (EN_type (int_Ent2[i])==Tface) {
	    faceCounted =1;
	    break;
	  }
	if (faceCounted==0)
	  PList_append (idata->boundedEntList, face);
		
      } else {             /* No closure */
	for (i=0; i<num_int[1]; i++) {
	  int_Ent1[i] =reg;
	  int_Ent2[i] =face;
	}
      }

    }

      
    for (i=0; i<num_int[1]; i++)
      M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);      

    break;
  }

  if (idata->nbr)  {
    /* Set dim in intersectionData */
    switch (idata->nbr) {
    case 1:
      idata->dim =0;
      break;
    case 2:
      idata->dim =1;
      break;
    case 3:
    case 4:
    case 5:
    case 6:
      idata->dim =2;
    }
    return 1;
  }

  return 0;
}





