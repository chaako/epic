/* Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project:

   Authors/Dates:
   Rao Garimella, Feb 95

   Functionality:
   Return the inscribed radius of a tetrahedron

   Argument Variable(s):
   Name  Type In/Out Description
 |------|----|------|-----------------------------------------------------|
*/
#include <math.h>
#include "oldFMDB.h"
#include "Defines.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

double XYZ_inscrRad(dArray *xyz) {
  pVertex vert;
  pPoint point;

  double vects[5][3], res[3];
  double A1, A2, A3, A4, SA, V;
  int i;
  void *temp = 0;
  
  for (i = 0; i < 3; i++)
    diffVt(xyz[i+1], xyz[0], vects[i]);

  crossProd(vects[0], vects[1], res);
  V = (dotProd(res, vects[2]))/6.0;
  A1 = sqrt(dotProd(res,res))/2.0;

  crossProd(vects[1], vects[2], res);
  A2 = sqrt(dotProd(res,res))/2.0;

  crossProd(vects[2], vects[0], res);
  A3 = sqrt(dotProd(res,res))/2.0;

  diffVt(xyz[1], xyz[2], vects[3]);
  diffVt(xyz[2], xyz[3], vects[4]);
  crossProd(vects[3], vects[4], res);
  A4 = sqrt(dotProd(res, res))/2.0;

  SA = A1 + A2 + A3 + A4;

  return (3*V/SA);

} /* R_inscrRad */

#ifdef __cplusplus
}
#endif
