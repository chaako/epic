/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Saikat Dey
  Creation  : Jan., 95
  Modifi.   : 
  Function  :
    queue implementation.
-------------------------------------------------------------------------*/
#include <stdlib.h>
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

void PList_remFirst(pPList this,void *tag);

pPQueue PQueue_new(void) {
  return PList_new();
}

void PQueue_reset(pPQueue q) {
  while(PList_size(q))
    PList_remItem(q, PList_item(q,0) );
}

void PQueue_delete(pPQueue q) {
  PList_delete(q);
}

void PQueue_pushUnique(pPQueue q, pEntity item) {
  PList_appUnique(q,item);
}

void PQueue_push(pPQueue q, pEntity item) {
  PList_append(q,item);
}

pEntity PQueue_pop(pPQueue q) {
  pEntity item = (pEntity)0;
  if(PList_size(q)) {
    item = PList_item(q,0);
    PList_remFirst(q,item);
  }
  return item;
}

void PQueue_remItem(pPQueue q, pEntity item) {
  PList_remItem(q,item);
}

int PQueue_size(pPQueue q) {
  return PList_size(q);
}

#ifdef __cplusplus
}
#endif
