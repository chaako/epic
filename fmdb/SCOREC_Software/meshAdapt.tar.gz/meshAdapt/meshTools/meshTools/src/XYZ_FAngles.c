/*---------------------------------------------------------------------------    Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC
 
   Project  : Mesh Tools
   Author(s): Pascal J. Frey
   Creation : Jun., 95
   Modif.   :
   Function :
     computes smallest and largest face angles of a triangle
     given coordinates of face vertices. return 0 if triangle is flat.
---------------------------------------------------------------------------*/
#include "oldFMDB.h"
#include "Macros.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

int XYZ_FAngles(dArray *xyz, double *normal, double *cosangs) {
  double v01[3],v02[3],v12[3], nv01[3], nv02[3], nv12[3], vv, tol;
  int ok;

  /* calculate the vectors */
  diffVt(xyz[1],xyz[0],v01);
  diffVt(xyz[2],xyz[0],v02);
  diffVt(xyz[2],xyz[1],v12);

  /* normalize these vectors */
  normVt (v01,nv01);
  normVt (v02,nv02);
  normVt (v12,nv12);

  /* calculate the cosine angles of the triangle */  
  cosangs[0] = dotProd(nv01,nv02);
  cosangs[1] = -dotProd(nv01,nv12);
  cosangs[2] = dotProd(nv02,nv12);

  /* check if the triangle is flat or of negative volume */
  return 1-XYZ_checkFlatTri (xyz, normal);
}

#ifdef __cplusplus
}
#endif






