/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project  : Mesh Tools
  Author(s): Rao Garimella
  Creation : Jan 28
  Modifi.  : 
  Function :
-------------------------------------------------------------------------*/
#include <stdio.h>
#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

int MT_MarkID=-1;
int MAXNUM=0;
int MT_mark;

int MT_getMarkID() {
  int i, found=0;

  if (MT_MarkID == -1) {
    /* Entering this routine for the first time   */
    /* We have to get data from the mesh database */

    MAXNUM = 6; /* Maximum number of markers we are going to use at a time */
    MT_mark = MD_registerMark("MTmk",MAXNUM,0);
    MT_MarkID = 0;
  }

  for (i = 0; !found && i < MAXNUM; i++) {
    if (!(MT_MarkID & 1<<i)) {
      found = 1;
      MT_MarkID = MT_MarkID | 1<<i;
      return (i+1);
    }
  }

  if (!found) {
    MT_ErrorHandler("Out of marks","MT_getMarkId",FATAL);
    return 0;
  }
}

void MT_freeMarkID(int markID) {
  if (markID < 1 || markID > MAXNUM) {
    MT_ErrorHandler("Invalid mark ID","MT_freeMarkID",WARN);
    return;
  }

  MT_MarkID = MT_MarkID & ~(1<<(markID-1));
}

void MT_setMark(pEntity ent, int markID) {
  int mark;

  mark = EN_mark(ent,MT_mark);  
  mark = mark | 1<<(markID-1);
  EN_setMark(ent,MT_mark,mark);
}

void MT_setMarkList(pPList list, int markID) {
  void *tmp;
  pEntity ent;

  tmp = 0;
  while (ent = PList_next(list, &tmp))
    MT_setMark(ent, markID);
}

void MT_unMark(pEntity ent, int markID) {
  int mark;

  mark = EN_mark(ent,MT_mark);
  if (!mark)
    return;

  mark = mark & ~(1<<(markID-1));
  EN_setMark(ent,MT_mark,mark);
}

void MT_unMarkList(pPList list, int markID) {
  void *tmp;
  pEntity ent;

  tmp = 0;
  while (ent = PList_next(list, &tmp))
    MT_unMark(ent,markID);
}

int MT_isMarked(pEntity ent, int markID) {
  int mark;

  mark = EN_mark(ent,MT_mark);
  return (mark & 1<<(markID-1));
}

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
}
#endif
