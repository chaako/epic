/* Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project: 

   Authors/Dates:
   Rao Garimella, Feb 1995

   Functionality:
   Return the aspect ratio (longest edge)/(shortest edge) of a region. 
   Currently, only tetrahedrons are supported.

   Argument Variable(s):
   Name  Type In/Out Description
 |------|----|------|-----------------------------------------------------|
*/

#include <math.h>
#include "oldFMDB.h"
#include "Defines.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

double R_aspectRatio(pRegion reg) {
  pVertex vert;
  pPoint point;
  pPList vlist;

  double eLong, hShort2, xyz[10][3], vec1[3], vec2[3], vec3[3], ilen;
  double alt2, length, dp12;
  int i,j;
  void *temp = 0;

  R_coord(reg, xyz);

  eLong = 0.0;
  for (i = 0; i < 3; i++) {
    for (j = i+1; j < 4; j++) {
      diffVt(xyz[i], xyz[j], vec1);
      length = dotProd(vec1,vec1);
      if (length > eLong) eLong = length;
    }
  }

  hShort2 = MTBIG;
  for (i = 0; i < 4; i++) {
    diffVt(xyz[(i+1)%4], xyz[(i+2)%4], vec1);
    diffVt(xyz[(i+1)%4], xyz[(i+3)%4], vec2);
    crossProd(vec1, vec2, vec3);
    ilen = 1.0/dotProd(vec3, vec3); /* reciprocal of vector length */

    diffVt(xyz[i], xyz[(i+1)%4], vec1);
    dp12 = dotProd(vec1, vec3);
    alt2 = dp12*dp12*ilen;      /* square of height */
    if (hShort2 > alt2) hShort2 = alt2;
  }

  return (sqrt(eLong/hShort2));

} /* R_aspectRatio */

#ifdef __cplusplus
}
#endif
