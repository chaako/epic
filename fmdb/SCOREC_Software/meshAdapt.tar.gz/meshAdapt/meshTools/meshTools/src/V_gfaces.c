/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Rao Garimella
  Creation  : Feb 96
  Modifi.   :
  Function  : Get model faces connected to model entity that mesh vertex
              is classified on. DO THIS BASED ON CLASSIFICATION OF MESH
              FACES CONNECTED TO MESH VERTEX. THIS IS USEFUL WHEN SMALL 
              FEATURES ARE REMOVED FROM THE MESH AND SO USING E_faces
	      OR V_faces ON THE MODEL ENTITY WILL GIVE INCORRECT INFO
-------------------------------------------------------------------------*/
#include "oldFMDB.h"
#include "modeler.h"

#ifdef __cplusplus
extern "C" {
#endif

pPList V_gfaces(pVertex v) {
  int i ;
  pFace vf;
  pPList flist = PList_new(), vflist = V_faces(v);
  pGEntity gent;
  void *temp = 0;

  temp = 0;
  while (vf = PList_next(vflist,&temp)) {
    gent = F_whatIn(vf);
    if (GEN_type(gent) == Gface)
      PList_appUnique(flist,gent);
  }

  if (!PList_size(flist)) {
    PList_delete(flist);
    flist = 0;
  }
  PList_delete(vflist);
  return flist ;    
}

#ifdef __cplusplus
}
#endif


