/*--------------------------------------------------------------------------- 
   Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project  : Debug Tools / Mesh Database
   Author(s): Pascal J. Frey
   Creation : Feb., 95
   Function :
     check if the mesh is valid,
---------------------------------------------------------------------------*/
#include "Defines.h"
#include "MeshTools.h"
#include "modeler.h"
#undef MPI

#define ABS(x) ((x) < 0 ? -(x) : (x))

#ifdef __cplusplus
extern "C" {
#endif

int M_checkAdj(pMesh mesh) {
  pPList   vlist,elist,list,velist, gvelist,eflist;
  pGEntity gent,gmptr, tag[2];
  pGRegion grgn, grgn0, grgn1;
  pRegion  rgn;
  pFace    face;
  pGFace   m_face;
  pEdge    edge; 
  pGEdge   m_edge;
  pVertex  v0,v1,vtx, vert;
  pGVertex m_vert;
  double   xyz[4][3];
  int      i,j,type,nbr,gnbr,dir, gmtyp, m_nbr,ok;
  int      count, count2, m_nbr2, n, status=1; 
  void    *tmp,*ltmp, *temp, *vtemp;

  /* added 01/28/02 -li */
  void* tmpgfaces;
  pPList gf_list;

  VIter vit=M_vertexIter(mesh);
  EIter e_iter=M_edgeIter(mesh);
  FIter fit=M_faceIter(mesh);

#ifdef MPI
  int link_nbr;
#endif

 /*
 Check if a vert is properly connected
 */

  while( vert=VIter_next(vit) ) {
    
#ifdef MPI
    /*
      if on part. bdry, cannot get all connected edges
    */

    link_nbr= pmdb_en_num_iplinks(vert);
    if ( link_nbr > 0 ) {
       continue;
    }
#endif

    gmptr= V_whatIn(vert);
    gmtyp= GEN_type(gmptr);
    if ( gmtyp == Gedge ) {

       /*
       Vert should be connected to 2 edges
       on model edge
       */

       m_edge= (pGEdge)gmptr;
       nbr= V_numEdges(vert);
       count= 0;
       for ( i= 0 ; i< nbr ; i++ ) {
          edge= V_edge(vert,i);
          gmptr= E_whatIn(edge);
          gmtyp= GEN_type(gmptr);
          if ( gmtyp == Gedge && ((pGEdge)gmptr) == m_edge ) count++;
       }
       if ( count != 2 ) {
          MT_ErrorHandler("bad vert up adj. 1","M_checkAdj",WARN);
	  status = 0;
       }
    }
    else if ( gmtyp == Tvertex ) {

       /*
       For each model edge, vert should be connected
       to 1 edge on it, but the same model edge could be there twice
       */
      velist = V_edges(vert);
      m_vert= (pGVertex)gmptr;

      gvelist = GV_edges(m_vert);      

      tmp = 0;
      while (m_edge = PList_next(gvelist, &tmp)) {
        m_nbr= 1;
	if (GE_vertex(m_edge,0) == GE_vertex(m_edge,1))
 	  m_nbr++;

        count= 0;
	vtemp = 0;
	while(edge = PList_next(velist,&vtemp)){
	  gmptr= E_whatIn(edge);
	  gmtyp= GEN_type(gmptr);
	  if ( gmtyp == Gedge && ((pGEdge)gmptr) == m_edge ){
	    count++;
	  }
	}
        if ( count != m_nbr ) {
         MT_ErrorHandler("bad vert up adj. 2","M_checkAdj",WARN);
	 status = 0;
	}
      }
      PList_delete(gvelist);
      PList_delete(velist);
    }
  } /* End loop on verts */
  

  /* check mesh edges */
  
  while( edge=EIter_next(e_iter) ) {
    if (EN_type(edge)!=Tedge) {
      MT_ErrorHandler("bad type","M_checkAdj",WARN);
      status = 0;
    }

    /* check if mesh edge vertices are different */

    v0 = E_vertex(edge,0);
    v1 = E_vertex(edge,1);
    if (v0==v1) {
      MT_ErrorHandler("adjacency problem 1","M_checkAdj",WARN) ;
      status = 0;
    }

    /* check if a edge has vertices classified
       on a higher order model ent.  */

    gent = E_whatIn(edge);
    type = GEN_type(gent);
    if (V_whatInType(v0)>type || V_whatInType(v1)>type) {
        MT_ErrorHandler("adjacency problem 2","M_checkAdj",WARN);
	status = 0;
    }

    /*
    Check for upward adj.
    */
    
#ifdef MPI
    /*
      If edge on part. bdry,
      cannot get to all connected faces
    */

    link_nbr= pmdb_en_num_iplinks(edge);
    if ( link_nbr > 0 ) {
       continue;
    }
#endif

    gmptr= E_whatIn(edge);
    gmtyp= GEN_type(gmptr);
    if ( gmtyp == Gface ) {

       /*
       Edge should be connected to 2 and only 2 faces
       classified on a model face and that model face
       must be the same as the one the edge is on
       */
      
      m_face= (pGFace)gmptr;
      nbr= E_numFaces(edge);
      count= 0; count2 = 0;
      for ( i= 0 ; i< nbr ; i++ ) {
	face= E_face(edge,i);
	gmptr= F_whatIn(face);
	gmtyp= GEN_type(gmptr);
	if ( gmtyp == Gface ) {
	  count2++;
	  if (((pGFace)gmptr) == m_face ) count++;
	}
      }
      if ( count != 2 || count2 != 2) {
	MT_ErrorHandler("bad edge up adj. 3","M_checkAdj",WARN);
	status = 0;
      }
    }
    else if ( gmtyp == Tedge ) {
      
      /*
	For each model face, edge should be connected
	to 1 face on it
      */
      
      eflist = E_faces(edge);
      m_edge= (pGEdge)gmptr;
      m_nbr = m_nbr2 = GE_numFaces(m_edge);
      count = 0;
      gf_list=GE_faces(m_edge);
      tmpgfaces = 0;
      while( m_face=(pGFace)PList_next(gf_list,&tmpgfaces) ) {
	if (C_F_edgeDir(m_face,m_edge) == 2) {
	  /* edge is used twice by the face, up the count */
	  /* of model faces by one                        */

	  m_nbr2++;
	}

	vtemp = 0;
	while(face = PList_next(eflist,&vtemp)){
	  gmptr= F_whatIn(face);
	  gmtyp= GEN_type(gmptr);
	  if ( gmtyp == Gface && ((pGFace)gmptr) == m_face ){
	    count++;
	  }
	}
      }
      PList_delete(gf_list);
      if ( count != m_nbr2 ) {
	MT_ErrorHandler("bad edge up adj. 4","M_checkAdj",WARN);
	status = 0;
      }
      PList_delete(eflist);
    } 
  } /* End loop on mesh edges */



  /* check mesh faces */
  
  while( face=FIter_next(fit) ) {
    if (EN_type(face)!=Tface) {
      MT_ErrorHandler("bad type","M_checkAdj",WARN);
      status = 0;
    }
    
    gent = F_whatIn(face);
    if (GEN_type(gent)==Gface) {
      grgn0 = GF_region((pGFace) gent,0);

      grgn1 = GF_region((pGFace) gent,1);
      tag[0] = (pGEntity) grgn0;
      tag[1] = (pGEntity) grgn1;
    }

    /* check if any connected region is geometrically valid */
    F_regionValid(face);
/*     for (i=0; i<2; i++) { */
/* 	rgn = F_region(face,i); */
/* 	if (rgn) { */
/* 	  grgn = (pGRegion) R_whatIn(rgn); */
/*  	  if (GEN_type(gent)==Gface && ((pGEntity) grgn != tag[i])) { */
/*  	    MT_ErrorHandler("wrong classification of region","M_checkAdj",WARN); */
/*  	    printf (" %p %p %p %d %d \n",tag[0],tag[1],grgn,GEN_type(gent),Gface); */
/*  	    status = 0; */
/*  	  } */
/* 	  if (R_numFaces(rgn) > 4) */
/* 	    continue; */
/* 	  list = F_vertices(face,i); */
/* 	  vtx = (pVertex)PQueue_pop(list); */
/* 	  V_coord(vtx,xyz[0]); */
/* 	  vtx = (pVertex)PQueue_pop(list); */
/* 	  V_coord(vtx,xyz[1]); */
/* 	  vtx = (pVertex)PQueue_pop(list); */
/* 	  V_coord(vtx,xyz[2]); */
/* 	  vtx = R_fcOpVt(rgn,face); */
/* 	  V_coord(vtx,xyz[3]); */
/* 	  PList_delete(list); */
/* 	  if (XYZ_checkFlat(xyz)) { */
/* 	    if (XYZ_volume(xyz) < 0.0) */
/* 	      MT_ErrorHandler("Negative volume region","M_checkAdj",WARN); */
/* 	    else */
/* 	      MT_ErrorHandler("Flat region","M_checkAdj",WARN); */
/* 	    status = 0; */
/* 	  } */
/* 	} */
/*     } */

    /* check if all edges are distincts */

    elist = F_edges(face,1,0);
    ltmp=0;
    list = PList_new();
    while (edge=PList_next(elist,&ltmp))
      PList_appUnique(list,edge);
    if (PList_size(list) != PList_size(elist)) {
      MT_ErrorHandler("adjacency problem 3","M_checkAdj",WARN);
      status = 0;
    }
    PList_delete(list);

    /* check if vertices are distincts */

    ltmp=0;
    list = PList_new();
    while (edge=PList_next(elist,&ltmp)) {
      dir= F_dirUsingEdge(face,edge);
      PList_appUnique(list,E_vertex(edge,!dir));
    }
    if (PList_size(list) != PList_size(elist)) {
      MT_ErrorHandler("adjacency problem 4","M_checkAdj",WARN);
      status = 0;
    }
    PList_delete(list);

    /* check if boundary face has edges classified boundary */

    if (F_whatInType(face)==Gface) {
      ltmp=0;
      while (edge=PList_next(elist,&ltmp)) {
	if (E_whatInType(edge)==Gregion) {
	  MT_ErrorHandler("adjacency problem 5","M_checkAdj",WARN);
	  E_info(edge);
	  status = 0;
	}
      }
    }
    PList_delete(elist);

#ifdef MPI
    /*
    if on part. bdry, cannot get all connected regions
    */
    
    link_nbr= pmdb_en_num_iplinks(face);
    if ( link_nbr > 0 ) {
       continue;
    }
#endif

    /* check # connected mesh regions w/r face classification */

    nbr=0;
    for (i=0; i<2; i++)
      if (F_region(face,i))
        nbr++;
    /* check if face is partially connected */
    type = F_partialCon(face);
    switch (F_whatInType(face)) {
      case Gface:
        /* at least one model region connected to model face */
        gnbr=0;
        for (i=0; i<2; i++)
          if (GF_region((pGFace)F_whatIn(face),i))
            gnbr++;
        if (nbr<gnbr && !type)
          MT_ErrorHandler("wrong # model regions","M_checkAdj",WARN);
        break;
      case Gregion:
        if (!nbr)
          MT_ErrorHandler("wrong # region(s)","M_checkAdj",WARN);
        if (nbr==1 && !type)
          MT_ErrorHandler("wrong # region(s)","M_checkAdj",WARN);
        if (nbr==2 && type)
          MT_ErrorHandler("wrong # region(s)","M_checkAdj",WARN);
        break;
      default:
        MT_ErrorHandler("wrong classification","M_checkAdj",WARN) ;
	status = 0;
    }
  } /* all mesh faces */

  VIter_delete(vit);
  EIter_delete(e_iter);
  FIter_delete(fit);

  return(status);
}
  
  /* 
     Check local self-intersection without entity use info 
     
     Given a face, there should be one or two region attched to it;
     In case of two attached regions, the two regions must be on
     different side of the face; In case of one attached region,
     the face must be classified on model face with orientation
     poining out.    
     
     return 1: valid
            0: invalid

     created   01/17/03   -li 
  */
  int F_regionValid(pFace face) {
    pRegion rgn[2];
    pVertex vert;
    double vol[2], fxyz[3][3], vxyz[3];
    double v10[3], v20[3], nor[3];
    double mtol;
    int i;

    if ( !F_region(face,0) && !F_region(face,1) ) {
      MT_ErrorHandler("a mesh face without region attached","M_checkAdj",WARN);
      return 0;
    }

    mtol=M_getTolerance();

    if( F_region(face,0) && F_region(face,1) ) {
      /* the two regions must locate in different side */

      /* compute face normal associated to its orientation */
      F_coord(face,fxyz);
      diffVt(fxyz[1],fxyz[0],v10);
      diffVt(fxyz[2],fxyz[0],v20);
      crossProd(v10,v20,nor);
      
      /* check side */
      for( i=0; i<2; i++ ) {
	rgn[i]=F_region(face,i);
	vert=R_fcOpVt(rgn[i],face);
	V_coord(vert,vxyz);
	diffVt(vxyz,fxyz[0],v10);
	vol[i]=dotProd(nor,v10);
	if( ABS(vol[i])<mtol ) {
	  MT_ErrorHandler("Flat region","M_checkAdj",WARN); 
	  return 0;
	}
      }
      if( vol[0]*vol[1] > 0 ) {
        printf(" vol[0]=%f   vol[1]=%f  \n",vol[0],vol[1]);
	MT_ErrorHandler("Local self intersection","M_checkAdj",WARN);
	return 0;
      }
    }

    else {
      /* it must be classified on model region */
      if (F_whatInType(face)!=Gface) {
	MT_ErrorHandler("wrong classification","M_checkAdj",WARN) ;
	return 0;
      }

#if 0
      /* the orientation of the face must point out side */
      /* we have to make such kind an assumption */
      F_coord(face,fxyz);
      diffVt(fxyz[1],fxyz[0],v10);
      diffVt(fxyz[2],fxyz[0],v20);
      crossProd(v10,v20,nor);

      rgn = F_region(face,0); 
      if (!rgn)
	rgn = F_region(face,1); 
      vert=R_fcOpVt(rgn,face);
      V_coord(vert,vxyz);
      diffVt(vxyz,fxyz[0],v10);
      vol[0]=dotProd(nor,v10);
      if( vol[0] > mtol ) {
        printf(" volume=%f\n",vol[0]);
	MT_ErrorHandler("Flipped boundary face orientation","M_checkAdj",WARN);
      }
      else if( vol[0] > -mtol )
	MT_ErrorHandler("Flat region","M_checkAdj",WARN); 
#endif    
    }
  }


#if 0
  /*
    check the consistency of orientations without entity use info

    For an edge classified on model face, there must be two adjacent faces 
    classified on the same model face, and these two faces should have
    consistent orientation. In case of an edge classified on model edge,
    the orientation of the mesh face must be consistent with its classified
    model face.

    return 1: valid
           0: invalid

    created   01/17/03   -li 
  */
  int E_facesConsistent(pEdge edge) {
    int i, count;
    int use[2];
    pFace face;
    void *iter;
    pGEntity gent=E_whatIn(edge);

    if( E_whatInType(edge)==Gface ) {

      // get the two faces on model face
      count= 0;
      for ( i= 0 ; i<E_numFaces(edge) ; i++ ) {
	face= E_face(edge,i);
	if ( F_whatIn(face) == gent ) {
	  use[count]=F_edgeDir_2(face,edge);
	  ++count;
	}
      }

      if( count != 2 ) {
	MT_ErrorHandler("adjacency problem 6","M_checkAdj",WARN);
	return 0;
      }      

      if( use[0]*use[1] == 1 ) {
	MT_ErrorHandler("inconsistent boundary face orientation","M_checkAdj",WARN);
	return 0;
      }
    }  /* end if on Gface */
    

/*      else if( E_whatInType(edge)==Gedge ) { */
/*        /* we should have already checked the consistency between */
/*  	 model face and mesh edge, now just need to ensure the  */
/*  	 mesh face and its classified model face use the edge */
/*  	 in the same direction */ 
/*        pGFace gf; */
/*        pPList gefaces=GE_faces((pGEdge)gent); */
/*        pFace bdryface; */

/*        iter=0; */
/*        while( gf=(pGFace)PList_next(gefaces,&iter) ) { */
/*  	// get the mesh face on current model face */
/*  	guse= */

/*  	count= 0; */
/*  	for ( i= 0 ; i<E_numFaces(edge) ; i++ ) { */
/*  	  face= E_face(edge,i); */
/*  	  if ( (pGFace)F_whatIn(face) != gf ) */
/*  	    continue; */
/*  	  bdryface=face; */
/*  	  ++count; */
/*  	} */
/*  	if( count != 1 ) { */
/*  	  MT_ErrorHandler("adjacency problem 6","M_checkAdj",WARN); */
/*  	  return 0; */
/*  	} */
/*        } */
/*        PList_delete(gefaces); */
/*      } */

    return 1;
  }
  
  int F_edgeDir_2(pFace face, pEdge edge) {
    pVertex verts[2];
    pVertex vertex;
    pPList fverts;
    int nn[2];
    void *iter=0;
    int count=0;

    // get the direction of the edge
    verts[0]=E_vertex(edge,0);
    verts[1]=E_vertex(edge,1);
    if( verts[0]==verts[1] ) {
      MT_ErrorHandler("adjacency problem 1","M_checkAdj",WARN) ;
      return 0;
    }

    fverts=F_vertices(face,1);
    while( vertex=(pVertex)PList_next(fverts,&iter) ) {
      if( vertex==verts[0] )
	nn[0]=count;
      if( vertex==verts[1] )
	nn[1]=count;
      count++;
    }
    PList_delete(fverts);

    if( nn[1]==(nn[0]+1)%3 )
      return 1;
    return -1;
  }
#endif


#ifdef __cplusplus
}
#endif







