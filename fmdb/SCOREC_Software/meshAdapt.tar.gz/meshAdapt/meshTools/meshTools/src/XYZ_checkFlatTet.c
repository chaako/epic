/*--------------------------------------------------------------------------
   Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project  : Mesh Tools
   Author(s): Kaan Karamete
   Creation : Feb. 99
   Function : checks if a given tetra is near flat or negative volume
---------------------------------------------------------------------------*/
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

int XYZ_checkFlatTet(dArray *xyz,double tol) {

int i;
double d, snorm;
 
  for(i=0;i<4;++i){

    switch (i) {
    case 0:
      d=P_distToPlane(xyz[0],xyz[1],xyz[3],xyz[2],&snorm);
      break;
    case 1:
      d=P_distToPlane(xyz[1],xyz[0],xyz[2],xyz[3],&snorm);
      break;
    case 2:
      d=P_distToPlane(xyz[2],xyz[3],xyz[1],xyz[0],&snorm);
      break;
    case 3:
      d=P_distToPlane(xyz[3],xyz[0],xyz[1],xyz[2],&snorm);
      break;
    }

    if(d<=0.0 || d*d<tol*tol*snorm) 
      return(1);
  }

 return(0);

}

#ifdef __cplusplus
}
#endif

