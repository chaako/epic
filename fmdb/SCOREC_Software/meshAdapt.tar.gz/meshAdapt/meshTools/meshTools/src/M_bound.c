#include "MeshTools.h"

pEdge M_boundedEdgeOnFace (pFace face, pVertex vertex1, pVertex vertex2)
{
  int i;
  pEdge edge;
  pVertex v1, v2;

  for (i=0; i<3; i++) {
    edge =F_edge (face, i);
    v1 =E_vertex (edge, 0);
    v2 =E_vertex (edge, 1);
    if ((v1==vertex1 && v2==vertex2) || (v1==vertex2 && v2==vertex1))
      return edge;
  }

  return (pEdge) 0;
}

pEdge M_boundedEdgeOnRegion (pRegion reg, pVertex vertex1, pVertex vertex2)
{
  int i;
  pEdge edge;
  pPList elist;
  pVertex v1, v2;

  elist =R_edges (reg,1);
  for (i=0; i<3; i++) {
    edge =PList_item (elist, i);
    v1 =E_vertex (edge, 0);
    v2 =E_vertex (edge, 1);
    if ((v1==vertex1 && v2==vertex2) || (v1==vertex2 && v2==vertex1)) {
      PList_delete (elist);
      return edge;
    }
  }

  PList_delete (elist);
  return (pEdge) 0;
}

pFace M_boundedFaceOnRegion (pRegion reg, pEntity ent0, pEntity ent1)
{
  int i, j, CaseID, num;
  pEntity ents[2];
  pFace face;
  pEdge edge;

  /* First classify the situation */
  switch (EN_type (ent0)) {
  case Tvertex:
    switch (EN_type (ent1)) {
    case Tedge:
      ents[0] =ent0;
      ents[1] =ent1;
      CaseID =1;
      break;
    default:
      CaseID =-1;
    }
    break;
  case Tedge:
    switch (EN_type (ent1)) {
    case Tvertex:
      ents[0] =ent1;
      ents[1] =ent0;
      CaseID =1;
      break;
    case Tedge:
      ents[0] =ent0;
      ents[1] =ent1;
      CaseID =2;
      break;
    default:
      CaseID =-1;
    }
    break;
  default:
    CaseID =-1;
  }
	      

  switch (CaseID) {
  case 1:
    /* a vertex and an edge bound a face */

    for (i=0; i<4; i++) {
      face =R_face (reg, i);
	      
      /* First search for the faces contain the edge */
      for (j=0; j<3; j++) {
	if (ents[1]==F_edge (face, j)) {
	  /* The face uses the edge */
	  /* Then check if the face also contains the vertex */
	  if (ents[0]==F_edOpVt(face, ents[1]))
	    return face;
	}
      }  
    }
    break;

  case 2:
    /* two edges may bound a face */
    for (i=0; i<4; i++) {
      num =0;
      face =R_face (reg, i);
      for (j=0; j<3; j++) {
	edge =F_edge (face, j);
	if (edge==ents[0] || edge==ents[1])
	  num ++;
		
	/* check if Edge lies in a face */
	if (num==2)
	  return face;
      }
    }
    break;
  }

  return (pFace) 0;
}

























