/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1998, RPI-SCOREC
     
  Project   : Mesh Tools
  Author(s) : Kaan Karamete,
  Creation  : Jan 99
  Modifi.   :  
  Function  : The perpendicular distance to the plane of a triangle=
              the return value of this routine/sqrt(*snorm)
	      The sign of the distance is not lost and hence sqrt operation
	      can be avoided by this way of specifying the below function.
	      See XYZ_checkFlatTet.c for how the return value is treated.
 -------------------------------------------------------------------------*/
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

double P_distToPlane(double* pxyz,double* v0,double* v1,double* v2,double *snorm)

{
  double v01[3],v02[3],v0P[3];
  double normal[3];

  diffVt(v1,v0,v01);
  diffVt(v2,v0,v02); 
  crossProd(v01,v02,normal);
  *snorm=dotProd(normal,normal); 

  diffVt(pxyz,v0,v0P);
  return (dotProd (v0P, normal));

}

#ifdef __cplusplus
}
#endif


