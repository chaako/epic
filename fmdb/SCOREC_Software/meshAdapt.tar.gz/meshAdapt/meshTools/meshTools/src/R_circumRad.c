/* Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project: 

   Authors/Dates:
   Rao Garimella, Feb 1995

   Functionality:
   Return the circumradius of tetrahedron

   Argument Variable(s):
   Name  Type In/Out Description
 |------|----|------|-----------------------------------------------------|
*/

#include <math.h>
#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

double R_circumRad(pRegion reg) {
  pVertex vert;
  pPoint point;

  double xyz[10][3], **vects, mids[3][3], rhs[3];
  double p_mixt, **cols, center[3], cradius;
  int i,j;
  void *temp = 0;
  pPList vlist;

  vlist = R_vertices(reg,1);
  temp = 0; i = 0;
  while (vert = PList_next(vlist,&temp)) {
    V_coord(vert,xyz[i]);
    i++;
  }
  PList_delete(vlist);

  vects = dMatAlloc(3,3);
  for (i = 0; i < 3; i++)
    diffVt(xyz[i+1], xyz[0], vects[i]);

  for (i = 0; i < 3; i++)
    for (j = 0; j < 3; j++)
      mids[i][j] = (xyz[0][j] + xyz[i+1][j])/2.0;

  for (i = 0; i < 3; i++)
    rhs[i] = dotProd(vects[i],mids[i]);

  p_mixt = det(3, vects);

  cols = dMatAlloc(3,3);
  for (i = 0; i < 3; i++) {
    cols[i][0] = rhs[i];
    cols[i][1] = vects[i][1];
    cols[i][2] = vects[i][2];
  }

  center[0] = (det(3,cols))/p_mixt;

  for (i = 0; i < 3; i++) {
    cols[i][0] = vects[i][0];
    cols[i][1] = rhs[i];
    cols[i][2] = vects[i][2];
  }

  center[1] = (det(3,cols))/p_mixt;

  for (i = 0; i < 3; i++) {
    cols[i][0] = vects[i][0];
    cols[i][1] = vects[i][1];
    cols[i][2] = rhs[i];
  }

  center[2] = (det(3,cols))/p_mixt;
   
  diffVt(center,xyz[0],vects[0]);

  cradius = vecMag(vects[0]);

  dMatFree(cols);
  dMatFree(vects);

  return cradius;

} /* R_circumRad */

#ifdef __cplusplus
}
#endif
