/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1998, RPI-SCOREC
     
  Project   : Mesh Tools
  Author(s) : Kaan Karamete
  Creation  : Mar 98
  Modifi.   : 
  Function  : Project point onto the plane of a triangle
 -------------------------------------------------------------------------*/
#include <math.h>
#include "oldFMDB.h"
#include "Macros.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

void P_projOnTriPlane(
double fxyz[3][3],
double pxyz[3],
double *proxyz,
double normal[3],
double *distance)
{
int i;
double v01[3],v02[3],v0P[3],ratio;
double magCP,magN;
 
  diffVt(fxyz[1],fxyz[0],v01);
  diffVt(fxyz[2],fxyz[0],v02); 
  crossProd(v01,v02,normal);

  magN=dotProd(normal,normal);

  diffVt(pxyz,fxyz[0],v0P);
  magCP=dotProd(v0P,normal);

  ratio=magCP/magN;

  for(i=0;i<3;++i)
    proxyz[i]=pxyz[i]-ratio*normal[i];

  *distance=magCP/sqrt(magN);
}

#ifdef __cplusplus
}
#endif
