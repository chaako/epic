#include "MeshTools.h"

/* computes the global mesh tolerance */

static double tol=-1.0;

void M_setTolerance(pMesh mesh)
{

pGModel model;
pVertex vertex;
double min[3],max[3];
double l,maxl;
int i,j;
double xyz[3];
void *tmp;
VIter vit=M_vertexIter(mesh);

 model=M_model(mesh);

 if(model){
   GM_bounds(model,min,max);
   
   maxl=max[0]-min[0];

   for(i=1;i<3;++i){
     l=max[i]-min[i];
     if(l>maxl) 
       maxl=l;
   }
 }
 /* Check if model returns a bounding box or not */
 if(!model || maxl>1.0E+50){
   /* no other way left to go and grab the bounds from the mesh */
   i=0;
   tmp=0;
   while( vertex=VIter_next(vit) ) {
     V_coord(vertex,xyz);
     ++i;
     if(i==1){
       for(j=0;j<3;++j){
	 max[j]=xyz[j];
         min[j]=xyz[j];
       }
     }
     else
       for(j=0;j<3;++j){
	 if(xyz[j]<min[j])
	   min[j]=xyz[j];
	 if(xyz[j]>max[j])
	   max[j]=xyz[j];
       }
   }
   maxl=max[0]-min[0];
   for(i=1;i<3;++i){
     l=max[i]-min[i];
     if(l>maxl) 
       maxl=l;
   }   
 }
 tol=maxl*1.0E-14;
 VIter_delete(vit);
}
 
double M_getTolerance()  
{
#ifdef DEBUG
  if(tol<0.0){
    MT_ErrorHandler("Tolerance was not initialized!Setting it to default.",
		 "M_getTolerance",MESSG);
    tol=1.0E-14;
  }
#endif
  if(tol<0.0)
    tol=1.0E-14;
  return(tol);
} 
