/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Tools
  Author(s) : J. Wan
  Creation  : August, 1999
  Function  :
              Check and update the intersection data. The procedure first check
	      if the intersection point is repeated. Only the new intersection 
	      points are appended.
-------------------------------------------------------------------------*/

#include "MeshTools.h"
#include "oldFMDB.h"
#include "Defines.h"
#include <math.h>

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
#endif

/* Check if the intersection points repeated. If repeated, data are not changed. */
int xyz_inIntersectionData (IntersectionData *idata, double int_xyz[3], double myTol)
{
  int i;
  double vector[3];
  double vol;
  struct IntDescription *thisDescription;

  if (idata->nbr>0) {
    thisDescription =idata->Description;
    for (i=0; i<idata->nbr; i++) {
      diffVt (int_xyz, thisDescription->xyz, vector);
      vol =dotProd (vector, vector);

      /* if vol is small enough, the point is regarded in IntersectionData */
      if (vol <= myTol)
	return 1;
      else thisDescription =thisDescription->next;
    }
  }

  /* the point is not in IntersectionData */
  return 0;
}

void M_updateIntersectionData (IntersectionData *idata, pEntity ent1, pEntity ent2, double int_xyz[3], double tol2)
{
  int i;
  struct IntDescription *thisDescription, *newDescription;
  

  /* Check if the intersection point is repeated */
  /* if the point is repeated, it is not counted again */
  if (tol2>0 && xyz_inIntersectionData (idata, int_xyz, tol2)) return;

  /* Load the intersection information to the new description */
  newDescription =(struct IntDescription *)calloc (1, sizeof (struct IntDescription));

  if (newDescription==NULL)
    MT_ErrorHandler ("Could not allocate memory", "UpdateIntersectData",FATAL);

  for (i=0; i<3; i++)
    newDescription->xyz[i] =int_xyz[i];
  newDescription->IntEnt1 =ent1;
  newDescription->IntEnt2 =ent2;
  newDescription->next =NULL;
  
  /* link the new description to the list */
  if (!idata->nbr) {
    idata->Description =newDescription;
    newDescription->prev =NULL; /* added by JW on 09/03/2000 */
  }
  else
    {
      thisDescription =idata->Description;
      while (thisDescription->next)
	thisDescription =thisDescription->next;
      thisDescription->next =newDescription;
      newDescription->prev =thisDescription;  /* added by JW on 09/03/2000 */
    }

  idata->nbr ++;
}

IntersectionData M_intersectionData_new ()
{ 
  IntersectionData idata;

  /* Initialize the areas of the intersection description */

  idata.dim =0;
  idata.nbr =0;
  idata.Description =NULL;
  idata.boundedEntList =PList_new ();
  return idata;
}

void M_intersectionData_delete (IntersectionData idata)
{
  int i;
  struct IntDescription *thisDescription, *tmpDescription;

  /* free all memory allocated */
  if (idata.nbr) {
    thisDescription =idata.Description;
    while (thisDescription->next)
      thisDescription =thisDescription->next;

    /* added by JW on 09/03/2000 starts*/
    /* free all descriptions except the first from the end */
    while (thisDescription->prev) {
      tmpDescription =thisDescription->prev;
      free (thisDescription);
      thisDescription =tmpDescription;
    }
    /* added by JW on 09/03/2000 ends */

    /* free the first description */
    free (thisDescription);
  }

  PList_delete (idata.boundedEntList);
}

