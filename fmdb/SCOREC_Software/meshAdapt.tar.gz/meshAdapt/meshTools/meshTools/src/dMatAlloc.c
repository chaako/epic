/* Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project: 

   Authors/Dates:
   Rao Garimella, Feb 1995

   Functionality:
   Allocate memory for a matrix

   Argument Variable(s):
   Name  Type In/Out Description
 |------|----|------|-----------------------------------------------------|
*/

#include <stdio.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

double **dMatAlloc(int m, int n) {
  int i;
  double *B, **A;

  B = (double *) calloc(m*n, sizeof(double));
  A = (double **) malloc(m*sizeof(double));
  if (B && A) {
    for (i = 0; i < m; i++)  A[i] = B + i*n;
    return A;
  }
  else {
    fprintf(stderr,"Out of memory in dMatAlloc\n");
    exit(1);
  }
}

#ifdef __cplusplus
}
#endif
