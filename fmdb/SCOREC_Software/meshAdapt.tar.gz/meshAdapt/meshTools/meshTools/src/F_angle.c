/*---------------------------------------------------------------------------    Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC
 
   Project  : Mesh Tools
   Author(s): Pascal J. Frey
   Creation : Jun., 95
   Modif.   :
   Function :
     computes and returns smallest and largest face angles of a triangle
     return 0 if triangle is flat.
---------------------------------------------------------------------------*/
#include "oldFMDB.h"
#include "Macros.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ANG_TOL  4.e-10

int F_angle(double xyz[3][3],double *sml,double *big) {
  double v01[3],v02[3],v10[3],v12[3],v20[3],v21[3];
  double alpha,beta,gamma;

  diffVt(xyz[1],xyz[0],v01);
  diffVt(xyz[2],xyz[0],v02);
  /* check if the vectors are not nuls */
  if (C_equal(v01[0],0.) && C_equal(v01[1],0.) && C_equal(v01[2],0.))
    return(0);
  if (C_equal(v02[0],0.) && C_equal(v02[1],0.) && C_equal(v02[2],0.))
    return(0);
  /* normalize these vectors */
  normVt(v01,v01);
  normVt(v02,v02);
  /* check if the vectors are colinear */
  alpha = dotProd(v01,v02);
  if (C_raneql(ABS(alpha),1.,ANG_TOL))
    return(0);
  /* compute the 2nd angle */
  v10[0] = -v01[0]; v10[1] = -v01[1]; v10[2] = -v01[2];
  diffVt(xyz[2],xyz[1],v12);
  if (C_equal(v12[0],0.) && C_equal(v12[1],0.) && C_equal(v12[2],0.))
    return(0);
  /* normalize v12 */
  normVt(v12,v12);
  beta = dotProd(v10,v12);
  if (C_raneql(ABS(beta),1.,ANG_TOL))
    return(0);
  /* compute the 3rd angle */
  v20[0] = -v02[0]; v20[1] = -v02[1]; v20[2] = -v02[2];
  v21[0] = -v12[0]; v21[1] = -v12[1]; v21[2] = -v12[2];
  gamma = dotProd(v20,v21);
  *sml = MAX(alpha,MAX(beta,gamma));
  *big = MIN(alpha,MIN(beta,gamma));
  return (!C_raneql(ABS(*big),1.,ANG_TOL));	
}

#ifdef __cplusplus
}
#endif






