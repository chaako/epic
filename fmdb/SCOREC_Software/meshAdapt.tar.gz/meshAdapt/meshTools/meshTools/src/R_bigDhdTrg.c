#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif


/*---------------------------------------------------------------------------
  returns the cosine of smallest and largest dihedral angle in a tetra.
---------------------------------------------------------------------------*/
int R_bigDhdTrg(pRegion rgn,double target,double *big)
{
  double  xyz[4][3] ;

  /* get the vertices coordinates */
  R_coord(rgn,xyz) ;
  /* get the worst(largest) dihedral angle */
  return XYZ_bigDhdTrg(xyz,target,big) ;
}

#ifdef __cplusplus
}
#endif

