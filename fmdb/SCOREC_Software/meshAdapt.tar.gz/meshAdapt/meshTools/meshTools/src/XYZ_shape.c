#include "MeshTools.h"
#include "Defines.h"
#include "Macros.h"

#ifdef __cplusplus
extern "C" {
#endif


/*--------------------------------------------------------------------------
  computes and returns the volume of a tetra.
--------------------------------------------------------------------------*/
int XYZ_shape(dArray *xyz,double *shape) {
  double v31[3],v32[3],v30[3],v20[3],v21[3],cp[3],jcb,area ;

  diffVt(xyz[0],xyz[3],v30) ;
  diffVt(xyz[2],xyz[3],v32) ;
  diffVt(xyz[1],xyz[3],v31) ;
  crossProd(v30,v32,cp) ;
  jcb = dotProd(cp,v31) ;
  /* check if element is valid */
  if ( jcb < 0. ) {
    *shape = jcb ;
    return(0) ;
  }
  /* compute the face areas */
  area = dotProd(cp,cp) ;
  crossProd(v30,v31,cp) ;
  area += dotProd(cp,cp) ;
  crossProd(v31,v32,cp) ;
  area += dotProd(cp,cp) ;
  
  diffVt(xyz[0],xyz[2],v20) ;
  diffVt(xyz[1],xyz[2],v21) ;
  crossProd(v20,v21,cp) ;
  area += dotProd(cp,cp) ;

  *shape = jcb / area ;
  *shape = (*shape) * (*shape) * (*shape) *jcb ;
  return(1) ;
}

#ifdef __cplusplus
}
#endif

