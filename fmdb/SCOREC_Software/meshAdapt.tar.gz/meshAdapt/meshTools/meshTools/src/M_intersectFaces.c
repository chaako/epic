/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Tools
  Author(s) : J. Wan
  Creation  : August, 1999
  Function  :
              Compute the intersection between two faces. If there
              exists intersection, return 1 else 0. The details of intersection
              are returned via IntersectionData.
-------------------------------------------------------------------------*/

#include "MeshTools.h"
#include "oldFMDB.h"
#include "Defines.h"
#include <math.h>
#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
#endif


/* Append the bounded entities on the face when applicable */
void appendEntsOnFace (pFace face, pEntity int_Ent[], IntersectionData *idata)
{
  int num_int =idata->nbr;
  int i, i_next;
  int faceCounted=0;

  if (num_int==2) {
    /* There are two intersection bounding pts */
    if (EN_type (int_Ent[0])==Tvertex && EN_type (int_Ent[1])==Tvertex)
      /* An edge of Face is bounded */
      PList_append (idata->boundedEntList, M_boundedEdgeOnFace (face, int_Ent[0], int_Ent[1]));

    else if ((int_Ent[0]!=int_Ent[1] && EN_type(int_Ent[0])==Tedge && EN_type(int_Ent[1])==Tedge) ||
	     (EN_type (int_Ent[0])==Tvertex && int_Ent[1]==F_vtOpEd(face, int_Ent[0])) ||
	     (EN_type (int_Ent[1])==Tvertex && int_Ent[0]==F_vtOpEd(face, int_Ent[1])))
      /* face is bounded */
      PList_append (idata->boundedEntList, face);

  } else {
    /* There are more than two intersection bounding pts */

    /* Check if face is counted in Descriptions */
    for (i=0; i<num_int; i++)
      if (EN_type (int_Ent[i])==Tface) {
	faceCounted =1;
	break;
      }

    if (faceCounted==0)
      /* face is not counted in Descriptions, so append it as the bounded ent */
      PList_append (idata->boundedEntList, face);

    for (i=0; i<num_int; i++) {
      i_next =(i+1)%num_int;

      if (EN_type (int_Ent[i])==Tvertex && EN_type (int_Ent[i_next])==Tvertex)
	/* An edge is bounded */
	PList_append (idata->boundedEntList, M_boundedEdgeOnFace (face, int_Ent[i], int_Ent[i_next]));
    }
  }
}


int areTwoPtsOnOneEdge (pEntity int_Ent[])
{

  /* if intersection bounding pts are located on two vertices */
  if (EN_type (int_Ent[0])==Tvertex && EN_type (int_Ent[1])==Tvertex) return 1;
 
  /* if intersection bounding pts are located on an edge and one of its vertices */
  if ((EN_type (int_Ent[0])==Tedge && EN_type (int_Ent[1])==Tvertex && 
       (int_Ent[1]==E_vertex (int_Ent[0],0) || int_Ent[1]==E_vertex (int_Ent[0],1))) ||
      (EN_type (int_Ent[1])==Tedge && EN_type (int_Ent[0])==Tvertex &&
       (int_Ent[0]==E_vertex (int_Ent[1],0) || int_Ent[0]==E_vertex (int_Ent[1],1))))
    return 1;

  /* if intersection bounding pts are located on an edge of face2, give up them */
  if (int_Ent[0]==int_Ent[1] && EN_type (int_Ent[0])==Tedge) return 1;

  return 0;
}

void FF_intEntSnapOnHalfClosure (pEntity int_Ent1[], pEntity face, pEntity int_Ent2[], int num_int, IntersectionData *idata)
{
  pEdge fEdge[3], fEdge_intEnt[3][2];
  int fEdge_intFlag[3], fEdge_intNum[3], fEdge_intID[3][2],i, j, k, Found;


  for (i=0; i<3; i++) {
    fEdge[i] =F_edge (face, i);
    fEdge_intFlag[i] =0;
    fEdge_intNum[i] =0;
  }

  /* Mark if the edges are intersected */
  for (i=0; i<num_int; i++) {
    if (EN_type (int_Ent1[i])==Tvertex) {
      for (j=0; j<3; j++)
	if (int_Ent1[i]==E_vertex(fEdge[j],0) || int_Ent1[i]==E_vertex(fEdge[j],1)) {
	  /* One vertex is intersected */
	  fEdge_intFlag[j] ++;
	  fEdge_intID[j][fEdge_intNum[j]] =i;
	  fEdge_intEnt[j][fEdge_intNum[j]] =int_Ent2[i];
	  fEdge_intNum[j] ++;
	}
    } else if (EN_type (int_Ent1[i])==Tedge) {
      for (j=0; j<3; j++)
	if (int_Ent1[i]==fEdge[j]) {
	  /* Body is intersected */
	  fEdge_intFlag[j] +=3;
	  fEdge_intID[j][fEdge_intNum[j]] =i;
	  fEdge_intEnt[j][fEdge_intNum[j]] =int_Ent2[i];
	  fEdge_intNum[j] ++;
	}
    }
  }

  /* 2V   ==> 2
     V +B ==> 4
     B    ==> 3 */

  /* Check if the edges of face are on the boundary of the other face */
  for (i=0; i<3; i++)
    switch (fEdge_intFlag[i]) {
    case 1:  /* 1 vertex */
      fEdge_intFlag[i] =0;
      break;

    case 2:  /* 2 Vertices */
    case 4:  /* 1 Vertex + body */
      switch (EN_type (fEdge_intEnt[i][0])) {
      case Tvertex:     /* intersect with a vertex */
	switch (EN_type (fEdge_intEnt[i][1])) {
	case Tvertex:   /* overlap with an edge of the other face */
	  fEdge_intFlag[i] =0;
	  break;
	case Tedge:
	  if (fEdge_intEnt[i][0]==(pEntity)E_vertex(fEdge_intEnt[i][1],0) ||
	      fEdge_intEnt[i][0]==(pEntity)E_vertex(fEdge_intEnt[i][1],1))
	    /* Overlap with an edge of the other face */
	    fEdge_intFlag[i] =0;
	  else
	    fEdge_intFlag[i] =1;
	  break;
	default:
	  fEdge_intFlag[i] =1;
	}
	break;
	
      case Tedge:       /* intersect with an edge of the other face */
	switch (EN_type (fEdge_intEnt[i][1])) {
	case Tvertex:
	  if (fEdge_intEnt[i][1]==(pEntity)E_vertex(fEdge_intEnt[i][0],0) ||
	      fEdge_intEnt[i][1]==(pEntity)E_vertex(fEdge_intEnt[i][0],1))
	    /* overlap with an edge of the other face */
	    fEdge_intFlag[i] =0;
	  else
	    fEdge_intFlag[i] =1;
	  break;
	case Tedge:
	  if (fEdge_intEnt[i][0]==fEdge_intEnt[i][1])
	    /* overlap with an edge of the other face */
	    fEdge_intFlag[i] =0;
	  else
	    fEdge_intFlag[i] =1;
	  break;
	default:
	  fEdge_intFlag[i] =1;
	}
	break;
	
      default:
	fEdge_intFlag[i] =1;
      }
      break;

    case 3:  /* Body intersected */
      if (EN_type (fEdge_intEnt[i][0])==Tvertex)
	/* 1 vertex */
	fEdge_intFlag[i] =0;
      else
	fEdge_intFlag[i] =1;
      break;
    }

  
  for (i=0; i<num_int; i++) {
    Found =0;
    if (EN_type (int_Ent1[i])!=Tface && EN_type (int_Ent2[i])!=Tface) {
      for (j=0; j<3; j++) 
	if (fEdge_intFlag[j]) {
	  for (k=0; k<fEdge_intNum[j]; k++)
	    if (fEdge_intID[j][k]==i) {
	      int_Ent1[i] =fEdge[j];
	      fEdge_intFlag[j] ++;
	      Found =1;
	      break;
	    }
	  if (Found) break;
	}
    }
    if (Found==0)
      int_Ent1[i] =face;
  }

  /* Append the edges intersected but not counted as intEnt to boundedEntList */
  for (i=0; i<3; i++)
    if (fEdge_intFlag[i]==1)
      PList_append (idata->boundedEntList, fEdge[i]);
}


/* This function is used to filter the intersection information according to the clousure setting. If no intersection found after filtering, return 0 else 1 */
int FF_ClosureControl (pFace face1, int ClosureFlag1, pFace face2, int ClosureFlag2, IntersectionData *idata)
{
  struct IntDescription *thisDescription;
  pEntity int_Ent1[6], int_Ent2[6];
  double int_xyz[6][3];  /* Up to six (6) intersection points */
  int i,j, num_int;
  
  thisDescription =idata->Description;
  
  /* First retrieve the intersection bounding points into array */
  for (i=0; i<idata->nbr; i++) {
    int_Ent1[i] =thisDescription->IntEnt1;
    int_Ent2[i] =thisDescription->IntEnt2;
    for (j=0; j<3; j++)
      int_xyz[i][j] =thisDescription->xyz[j];
    thisDescription =thisDescription->next;
  }
  num_int =idata->nbr;

 
  /* Initialize the intersectionData */
  M_intersectionData_delete (*idata);
  *idata =M_intersectionData_new ();
  

  /* Then implement the closure control */
  switch (num_int) {

  case 1:    /* There is one intersection point originally */

    /* If ClosureFlag1 =0 and intersection location is not on face1; or
       if ClosureFlag2 =0 and intersection location is not on face2, then give up it*/
    if ((!ClosureFlag1 && EN_type (int_Ent1[0])!=Tface) || 
	(!ClosureFlag2 && EN_type (int_Ent2[0])!=Tface)) break;

    M_updateIntersectionData (idata, int_Ent1[0], int_Ent2[0], int_xyz[0], -1);
    break;
    
  case 2:    /* There are two intersection points originally */
    if (ClosureFlag1)
      if (ClosureFlag2) { /* Full closure case */

	for (i=0; i<2; i++)
	  M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);

	/* need to append the bounded ent on Face1 and Face2 if applicable */

	appendEntsOnFace (face1, int_Ent1, idata);
	appendEntsOnFace (face2, int_Ent2, idata);


      } else {            /* Half closure case, ClosureFlag1 =1 and ClosreFlag2=0 */

	/* If faces intersect on the boundary of face2, give up */
	if (areTwoPtsOnOneEdge(int_Ent2)) break;

	for (i=0; i<2; i++)
	  M_updateIntersectionData (idata, int_Ent1[i], face2, int_xyz[i], -1);

	/* Append bounded entity on Face1 if applicable */
	appendEntsOnFace (face1, int_Ent1, idata);
      }

    else /* ClosureFlag1 =0 */
      if (ClosureFlag2) { /* Half closure case, ClosureFlag1 =0, ClosureFlag2 =1 */

	/* If faces intersect on the boundary of face1, give up */
	if (areTwoPtsOnOneEdge(int_Ent1)) break;

	for (i=0; i<2; i++)
	  M_updateIntersectionData (idata, face1, int_Ent2[i], int_xyz[i], -1);

	/* Append bounded entity on Face2 if applicable */
	appendEntsOnFace (face2, int_Ent2, idata);
 
      } else {           /* Non-closure case, ClosureFlag1=0, ClosureFlag2 =0 */

	/* If faces intersect on the boundary of face1, give up */
	if (areTwoPtsOnOneEdge(int_Ent1)) break;

	/* If faces intersect on the boundary of face2, give up */
	if (areTwoPtsOnOneEdge(int_Ent2)) break;

	for (i=0; i<2; i++)
	  M_updateIntersectionData (idata, face1, face2, int_xyz[i], -1);

	/* No bounded entity in this situation */
      }
    break;

  case 3:
  case 4:
  case 5:
  case 6:
    if (ClosureFlag1)
      if (ClosureFlag2) { /* Full closure case */

	for (i=0; i<num_int; i++)
	  M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);

	/* need to append the bounded ent on Face1 and Face2 if applicable */

	appendEntsOnFace (face1, int_Ent1, idata);
	appendEntsOnFace (face2, int_Ent2, idata);
	    
      } else {            /* Half closure case, ClosureFlag1 =1, ClosureFlag2 =0 */

	/* There exist num_int intersection bounding pts necessarily */
	FF_intEntSnapOnHalfClosure (int_Ent1, face1, int_Ent2, num_int, idata);

	for (i=0; i<num_int; i++)
	  M_updateIntersectionData (idata, int_Ent1[i], face2, int_xyz[i], -1);

	/* Append the bounded entities on Face1 if applicable */
	appendEntsOnFace (face1, int_Ent1, idata);
      }

    else                  /* ClosureFlag1 =0 */
      if (ClosureFlag2) { /* Half closure case, ClosureFlag1 =0, ClosureFlag2 =1 */

	FF_intEntSnapOnHalfClosure (int_Ent2, face2, int_Ent1, num_int, idata);

	for (i=0; i<num_int; i++)
	  M_updateIntersectionData (idata, face1, int_Ent2[i], int_xyz[i], -1);

	/* Append the bounded entities on Face2 if applicable */
	appendEntsOnFace (face2, int_Ent2, idata);

      } else {           /* Non-closure case, ClosureFlag1 =0, ClosureFlag2 =0 */

	for (i=0; i<num_int; i++)
	  M_updateIntersectionData (idata, face1, face2, int_xyz[i], -1);
	
	/* No bounded entity to be appended */
      }
 
    break;
  }
 
  if (idata->nbr)  {
    /* Set dim in intersectionData */
    switch (idata->nbr) {
    case 1:
      idata->dim =0;
      break;
    case 2:
      idata->dim =1;
      break;
    case 3:
    case 4:
    case 5:
    case 6:
      idata->dim =2;
    }
    return 1;
  }

  return 0;
}

void swapIntersectedEnt (IntersectionData *idata, int NumBeforeThisIntPts)
{
  struct IntDescription *thisDescription;
  pEntity Int_Ent1;
  int i;

  thisDescription =idata->Description;
  
  for (i=0; i<NumBeforeThisIntPts; i++)
    thisDescription =thisDescription->next;
  
  /* Exchange the intersection entity */
  for (i=NumBeforeThisIntPts; i<idata->nbr; i++) {
    Int_Ent1 =thisDescription->IntEnt1;
    thisDescription->IntEnt1 =thisDescription->IntEnt2 ;
    thisDescription->IntEnt2 =Int_Ent1;
    thisDescription =thisDescription->next;
  }

}


int M_intersectFaces (pFace face1, int ClosureFlag1, pFace face2, int ClosureFlag2, IntersectionData *idata)
{
  double F1_xyz[3][3], F2_xyz[3][3];
  double tol;
  int i, j, CaseID;
  pVertex F1_vertex[3], F2_vertex[3];
  pEdge edgeOfFace;
  pEntity ent, IntEnt1, IntEnt2;
  pPList vlist;
  double F_vector[2][3], FF_vector[3][3], Normal[3];
  double Normal_Len2, vol[3], tmp[4];
  int NumExistingIntPts, NumNewlyFoundIntPts, NumBeforeThisIntPts;

  /* Initialize */
  tol =M_getTolerance();

  /* Record the procedure: 
     1) if the routine is called independently, NumExistingIntPts=0
     2) if the routine is called embeddedly, NumExistingIntPts may Nonzero */
  NumExistingIntPts =idata->nbr;

  /* Get the vertices and their coordinates */
  /* Of Face 1 */
  vlist =F_vertices (face1, 1);
  for (i=0; i<3; i++) {
    F1_vertex[i] =PList_item (vlist, i);
    V_coord (F1_vertex[i], F1_xyz[i]);
  }
  PList_delete (vlist);
  
  /* Of Face 2 */
  vlist =F_vertices (face2, 1);
  for (i=0; i<3; i++) {
    F2_vertex[i] =PList_item (vlist, i);
    V_coord (F2_vertex[i], F2_xyz[i]);
  }
  PList_delete (vlist);

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  /* First, explore the cases by exploding the entities from face2 */
  for (i=0; i<2; i++)
    diffVt (F1_xyz[i+1], F1_xyz[0], F_vector[i]);

  for (i=0; i<3; i++)
    diffVt (F2_xyz[i], F1_xyz[0], FF_vector[i]);

  crossProd (F_vector[0], F_vector[1], Normal);
  Normal_Len2 =dotProd (Normal, Normal);
  for (i=0; i<3; i++) {
    vol[i] =dotProd (Normal, FF_vector[i]);
    tmp[i] =vol[i]*vol[i];
  }
  tmp[3]=tol*tol*Normal_Len2;

  /* Analyze the cases */
  if (tmp[0] <= tmp[3] && tmp[1] <= tmp[3] && tmp[2]<=tmp[3])    /* Faces are coplanar */
    CaseID =0;
  else if (vol[0]*vol[1]<0.0 || vol[0]*vol[2]<0.0 || vol[1]*vol[2]<0.0)  
    /* Non-coplanar, face2 cross the face1 plane */
    CaseID =13;
  else if (tmp[0] <= tmp[3] && tmp[1] <=tmp[3])  /* Non-coplanar, 1st edge of face2 on the face1 plane */
    CaseID =1;
  else if (tmp[1] <= tmp[3] && tmp[2] <=tmp[3])  /* Non-coplanar, 2nd edge of face2 on the face1 plane */
    CaseID =2;
  else if (tmp[0] <= tmp[3] && tmp[2] <=tmp[3])  /* Non-coplanar, 3rd edge of face2 on the face1 plane */
    CaseID =3;
  else if (tmp[0] <= tmp[3])  /* Non-coplanar, 1st vertex of face2 on the face1 plane */
    CaseID =4;
  else if (tmp[1] <= tmp[3])  /* Non-coplanar, 2nd vertex of face2 on the face1 plane */
    CaseID =5;
  else if (tmp[2] <= tmp[3])  /* Non-coplanar, 3rd vertex of face2 on the face1 plane */
    CaseID =6;
  else {           /* Non-coplanar, face2 falls in a side of the face1 plane */
    CaseID =14;      /* Need to consider further */
  }


  switch (CaseID) {
  case 0:     /* of CaseID, faces are coplanar */
    /* Compute the intersections between face1 and each edge of face2 */
    for (i=0; i<3; i++) {
      edgeOfFace =F_edge (face2, i);

      F_intersectEdge (face1, 1, edgeOfFace, 1, idata);
      
      /* Check if all the intersection points have been found */
      if ((idata->nbr-NumExistingIntPts)==6) /* all intersection points between the two faces found */
	if (NumExistingIntPts) return 1;   /* if the routine is called as a child routine, omit ClosureControl*/
	else return FF_ClosureControl (face1, ClosureFlag1, face2, ClosureFlag2, idata);
    }

    /* Compute the intersections between face2 and each edges of face1 */

    /* Mark the position for the data swap later */
    NumBeforeThisIntPts =idata->nbr;
    for (i=0; i<3; i++) {
      edgeOfFace =F_edge (face1, i);

      F_intersectEdge (face2, 1, edgeOfFace, 1, idata);
      
      /* Check if all the intersection points have been found */
      if ((idata->nbr-NumExistingIntPts)==6) {	/* all intersection points between the two faces found */

	  /* Exchange the intersection entities newly found */
	if (NumBeforeThisIntPts < idata->nbr)  /* Any new intersection point found */
	  swapIntersectedEnt (idata, NumBeforeThisIntPts);

	if (NumExistingIntPts) return 1;
	else return FF_ClosureControl (face1, ClosureFlag1, face2, ClosureFlag2, idata);
      }
    }

    /* When less than 6 intersection points found */
    if (idata->nbr > NumExistingIntPts) {
      if (NumBeforeThisIntPts < idata->nbr) 
	swapIntersectedEnt (idata, NumBeforeThisIntPts);

      if (NumExistingIntPts) return 1;
      else return FF_ClosureControl (face1, ClosureFlag1, face2, ClosureFlag2, idata);
    } 
    else return 0;
    break;

  case 1:    /* of CaseID, Non-coplanar, 1st edge of face2 on the face1 plane */
  case 2:    /* of CaseID, Non-coplanar, 2nd edge of face2 on the face1 plane */
  case 3:    /* of CaseID, Non-coplanar, 3rd edge of face2 on the face1 plane */
    /* Compute the intersection between face1 and the edges of face2 */

    /* Only when ClosureFlag2 =1, it makes sense */
    if (ClosureFlag2) {
      edgeOfFace =F_edge (face2, CaseID-1);
      F_intersectEdge (face1, 1, edgeOfFace, 1, idata);

      if (idata->nbr>NumExistingIntPts)
	if (NumExistingIntPts) return 1;
	else return FF_ClosureControl (face1, ClosureFlag1, face2, ClosureFlag2, idata); 
    }
    else return 0;
    break;

  case 4:    /* of CaseID, Non-coplanar, 1st vertex of face2 on the face1 plane */
  case 5:    /* of CaseID, Non-coplanar, 2nd vertex of face2 on the face1 plane */
  case 6:    /* of CaseID, Non-coplanar, 3rd vertex of face2 on the face1 plane */
    /* Compute the intersection between face1 and the vertex of face2 */

    /* Only when CloseFlag2=1, it makes sense */
    if (ClosureFlag2) {
      ent =XYZ_onBoundary (F2_xyz[CaseID-4], face1, tol);
      /* return the details */

      if (ent)
	/* Only when ClosureFlag1=1 or the vertex is inside Face1, it makes sense */
	if (ClosureFlag1 || EN_type (ent)==Tface) {
	  M_updateIntersectionData (idata, ent, F2_vertex[CaseID-4], F2_xyz[CaseID-4], tol*tol);
	  idata->dim =0;
	  return 1;
	}
      /* Else return 0 */
    }
    return 0; 
    break;

  case 13:    /* of CaseID, Non-coplanar, face2 cross the face1 plane */
    /* Compute the intersection between face1 and the edges of face2 */
    /* In this case, two and only two intersection points exist! */
    /* 3 cases:
         1.) Two edges of face2 cross through face 1;
	 2.) Two edges of face1 cross through face 2;
	 3.) One edge of face2 cross through face 1, and
	     one edge of face1 cross through face 2;
    */

    for (i=0; i<3; i++) {
      edgeOfFace =F_edge (face2, i);

      F_intersectEdge (face1, 1, edgeOfFace, 1, idata);
      
      /* Check if all the intersection points have been found */
      if ((idata->nbr-NumExistingIntPts)==2)  /* all intersection points between the two faces found */
	if (NumExistingIntPts) return 1;
	else return FF_ClosureControl (face1, ClosureFlag1, face2, ClosureFlag2, idata);
    }


    /* If less than two intersection points has been found, turn to face 2 */

    /* Compute the intersection between face2 and the edges of face1 */

    /* make a mark for data swapping later */
    NumBeforeThisIntPts =idata->nbr;
    for (i=0; i<3; i++) {
      edgeOfFace =F_edge (face1, i);

      F_intersectEdge (face2, 1, edgeOfFace, 1, idata);
      
      /* Check if all the intersection points have been found */
      if ((idata->nbr-NumExistingIntPts)==2) { 
	/* all intersection points between the two faces found */

	if (NumBeforeThisIntPts < idata->nbr)
	  swapIntersectedEnt (idata, NumBeforeThisIntPts);

	if (NumExistingIntPts) return 1;
	else return FF_ClosureControl (face1, ClosureFlag1, face2, ClosureFlag2, idata);
      }
    }

    /* for exception case */

    if (NumBeforeThisIntPts < idata->nbr)
      swapIntersectedEnt (idata, NumBeforeThisIntPts);

    if (idata->nbr-NumExistingIntPts)
      if (NumExistingIntPts) return 1;
      else return FF_ClosureControl (face1, ClosureFlag1, face2, ClosureFlag2, idata);
    else return 0;

  }   /* End of Switch (CaseID) */


  /* When CaseID =14, continue to the following computation */
  /* If not all intersection points have been found, turn to face 2 */
  /*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
  /* Then explore the cases by exploding the entities of face1 */

  for (i=0; i<2; i++)
    diffVt (F2_xyz[i+1], F2_xyz[0], F_vector[i]);

  for (i=0; i<3; i++)
    diffVt (F1_xyz[i], F2_xyz[0], FF_vector[i]);

  crossProd (F_vector[0], F_vector[1], Normal);
  Normal_Len2 =dotProd (Normal, Normal);
  for (i=0; i<3; i++) {
    vol[i] =dotProd (Normal, FF_vector[i]);
    tmp[i] =vol[i]*vol[i];
  }
  tmp[3]=tol*tol*Normal_Len2;

  /* Analyze the cases */
  if (tmp[0] <= tmp[3] && tmp[1] <= tmp[3] && tmp[2]<=tmp[3])    /* Faces are coplanar */
    CaseID =0;
  else if (vol[0]*vol[1]<0.0 || vol[0]*vol[2]<0.0 || vol[1]*vol[2]<0.0)
    /* Non-coplanar, face1 cross the face2 plane */
    CaseID =13;
  else if (tmp[0] <= tmp[3] && tmp[1] <=tmp[3])  /* Non-coplanar, 1st edge of face1 on the face2 plane */
    CaseID =7;
  else if (tmp[1] <= tmp[3] && tmp[2] <=tmp[3])  /* Non-coplanar, 2nd edge of face1 on the face2 plane */
    CaseID =8;
  else if (tmp[0] <= tmp[3] && tmp[2] <=tmp[3])  /* Non-coplanar, 3rd edge of face1 on the face2 plane */
    CaseID =9;
  else if (tmp[0] <= tmp[3])  /* Non-coplanar, 1st vertex of face1 on the face2 plane */
    CaseID =10;
  else if (tmp[1] <= tmp[3])  /* Non-coplanar, 2nd vertex of face1 on the face2 plane */
    CaseID =11;
  else if (tmp[2] <= tmp[3])  /* Non-coplanar, 3rd vertex of face1 on the face2 plane */
    CaseID =12;
  else {           /* Non-coplanar, face1 falls in a side of the face2 plane */
    return 0;      /* No intersetcions */
  }

  switch (CaseID) {
  case 0:     
  case 13:
    /* The situation has been completely considered previously */
    /* The procedure will never go here */
    break;

  case 7:    /* of CaseID, Non-coplanar, 1st edge of face1 on the face2 plane */
  case 8:    /* of CaseID, Non-coplanar, 2nd edge of face1 on the face2 plane */
  case 9:    /* of CaseID, Non-coplanar, 3rd edge of face1 on the face2 plane */
    /* Compute the intersection between face2 and the edges of face1 */
    
    /* Only when ClosureFlag1=1, it makes sense */
    if (ClosureFlag1) {

      /* Make a mark for the later data swapping */
      NumBeforeThisIntPts =idata->nbr;
      edgeOfFace =F_edge (face1, CaseID-7);
      F_intersectEdge (face2, 1, edgeOfFace, 1, idata);
      
      if (NumBeforeThisIntPts < idata->nbr)
	swapIntersectedEnt (idata, NumBeforeThisIntPts);
      
      if (NumExistingIntPts) return 1;
      else return FF_ClosureControl (face1, ClosureFlag1, face2, ClosureFlag2, idata); 
    }
    else return 0;
    break;

  case 10:    /* if CaseID, Non-coplanar, 1st vertex of face1 on the face2 plane */
  case 11:    /* if CaseID, Non-coplanar, 2nd vertex of face1 on the face2 plane */
  case 12:    /* if CaseID, Non-coplanar, 3rd vertex of face1 on the face2 plane */
    /* Compute the intersection between face2 and the vertex of face1 */

    /* Only when ClosureFlag1=1, it makes sense */    
    if (ClosureFlag1) {
      ent =XYZ_onBoundary (F1_xyz[CaseID-10], face2, tol);
      /* return the details */

      if (ent)
	if (ClosureFlag2 || EN_type (ent)==Tface) {
	  M_updateIntersectionData (idata, F1_vertex[CaseID-10], ent, F1_xyz[CaseID-10], tol*tol);
	  idata->dim =0;
	  return 1;
	}
    }
    return 0;
  }   /* End of Switch (CaseID) */


  /* No intersection points found */
  return 0;
}


















