/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : 
  Author(s) : Pascal J. Frey
  Creation  : Jan., 95
  Modifi.   : 
  Function  :
    returns local edge mapping for a region
-------------------------------------------------------------------------*/
#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

int E_rgnLocalId(pRegion rgn,pEdge edge)
{
  pPList   vlist ;
  pEdge    local_edge ;
  pVertex  v1,v2 ;
  int      i ;
  static   int emap[6][2] = { 0,1, 1,2, 2,0, 0,3, 1,3, 2,3 } ; 

  vlist = R_vertices(rgn,1) ;
  for ( i=0 ; i<6 ; i++ ) {
    v1 = (pVertex)PList_item(vlist,emap[i][0]) ;
    v2 = (pVertex)PList_item(vlist,emap[i][1]) ;
    local_edge = E_exists(v1,v2) ;
    if ( local_edge && local_edge == edge ) {
      PList_delete(vlist) ;
      return i ;
    }
  }
  PList_delete(vlist) ;
  return(-1) ;
}

#ifdef __cplusplus
}
#endif
