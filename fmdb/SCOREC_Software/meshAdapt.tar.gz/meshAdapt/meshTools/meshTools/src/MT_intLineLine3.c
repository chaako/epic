/*
Intersect line segment with line segment
Case of line segments being colinear
Can return up to 4 intersections (2 times 2)
*/

#include "MeshTools.h"

void MT_intLineLine3(
 double L_XYZ[2][3],
 double l_xyz[2][3],
 double tol,
 int *int_nbr,
 double int_xyz[4][3]
)

{

 int p;
 double xyz[3];
 double e_xyz[2][3];
 int i;
 double vec0[3];
 double vec0_norm2;
 double vec1[3];
 double vec1_norm2;
 double dot_p;

 *int_nbr= 0;

 for ( p= 0 ; p< 4 ; p++ ) {
    if ( p == 0 ) {
       for ( i= 0 ; i< 3 ; i++ )
        xyz[i]= L_XYZ[0][i];
       for ( i= 0 ; i< 3 ; i++ )
        e_xyz[0][i]= l_xyz[0][i];
       for ( i= 0 ; i< 3 ; i++ )
        e_xyz[1][i]= l_xyz[1][i];
    }
    if ( p == 1 ) {
       for ( i= 0 ; i< 3 ; i++ )
        xyz[i]= L_XYZ[1][i];
       for ( i= 0 ; i< 3 ; i++ )
        e_xyz[0][i]= l_xyz[0][i];
       for ( i= 0 ; i< 3 ; i++ )
        e_xyz[1][i]= l_xyz[1][i];
    }
    if ( p == 2 ) {
       for ( i= 0 ; i< 3 ; i++ )
        xyz[i]= l_xyz[0][i];
       for ( i= 0 ; i< 3 ; i++ )
        e_xyz[0][i]= L_XYZ[0][i];
       for ( i= 0 ; i< 3 ; i++ )
        e_xyz[1][i]= L_XYZ[1][i];
    }
    if ( p == 3 ) {
       for ( i= 0 ; i< 3 ; i++ )
        xyz[i]= l_xyz[1][i];
       for ( i= 0 ; i< 3 ; i++ )
        e_xyz[0][i]= L_XYZ[0][i];
       for ( i= 0 ; i< 3 ; i++ )
        e_xyz[1][i]= L_XYZ[1][i];
    }

    diffVt(e_xyz[0],xyz,vec0);
    vec0_norm2= dotProd(vec0,vec0);
    diffVt(e_xyz[1],xyz,vec1);
    vec1_norm2= dotProd(vec1,vec1);
    dot_p= dotProd(vec0,vec1);

    if ( dot_p <= 0.0 ||
         (vec0_norm2 < tol*tol) ||
         (vec1_norm2 < tol*tol) ) {

       /*
       xyz is between e_xyz[0] and e_xyz[1]
       */

       for ( i= 0 ; i< 3 ; i++ )
        int_xyz[*int_nbr][i]= xyz[i];
       (*int_nbr)++;
    }
 }

}
