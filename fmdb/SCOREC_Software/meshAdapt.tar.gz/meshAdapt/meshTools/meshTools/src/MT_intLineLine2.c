/*
Intersect line with line
Both line segments on same plane
*/
#include "MeshTools.h"
void MT_intLineLine2(
 double L_XYZ[2][3],
 double l_xyz[2][3],
 int *int_nbr,
 double int_xyz[3]
)

{

 double LVEC[3];
 double Lvec0[3];
 double Lvec1[3];
 double vec0[3];
 double vec1[3];
 double dot_p;
 int end;
 double vecs[2][3];
 double lvec[3];
 double normal[3];
 int max_dim;
 double max_val;
 int dim;
 int ind;
 double A[2][2];
 double B[2];
 double den;
 double s;
 double t;
 double int_xyz2[3];
 double LVEC_norm2;
 double vec0_norm2;
 double vec1_norm2;
 int nbr;
 double lvec_norm2;
 double lVEC0[3];
 double lVEC1[3];

 /*
 1 intersection
 unless lines are strictly parallel
 */

 *int_nbr= 1;

 /*
 To find intersection,
 have to resolve a system of 3 eqns with 2 unknowns
 Do not consider axis closest to plane normal
 */

 diffVt(l_xyz[1],l_xyz[0],lvec);
 diffVt(L_XYZ[1],L_XYZ[0],LVEC);
 crossProd(lvec,LVEC,normal);

 max_dim= 0;
 max_val= fabs(normal[0]);
 for ( dim= 1 ; dim< 3 ; dim++ ) {
    if ( fabs(normal[dim]) > max_val ) {
       max_dim= dim;
       max_val= fabs(normal[dim]);
    }
 }

 ind= 0;
 for ( dim= 0 ; dim< 3 ; dim++ ) {
    if ( dim == max_dim ) continue;
    A[ind][0]= LVEC[dim];
    A[ind][1]= -lvec[dim];
    B[ind]= l_xyz[0][dim] - L_XYZ[0][dim];
    ind++;
 }

 den= A[0][0]*A[1][1]-A[0][1]*A[1][0];

 if ( den == 0.0 ) {
    *int_nbr= 0;
    return;
 }

 s= (B[0]*A[1][1]-A[0][1]*B[1])/den;
 t= (A[0][0]*B[1]-B[0]*A[1][0])/den;

 /*
 Get intersection location
 s is parametric rep. on L
 t is parametric rep. on l
 Both should give same answer
 Only consider L
 */

 for ( dim= 0 ; dim< 3 ; dim++ ) {
    int_xyz[dim]= L_XYZ[0][dim]+s*LVEC[dim];
 }

 for ( dim= 0 ; dim< 3 ; dim++ ) {
    int_xyz2[dim]= l_xyz[0][dim]+t*lvec[dim];
 }

}
