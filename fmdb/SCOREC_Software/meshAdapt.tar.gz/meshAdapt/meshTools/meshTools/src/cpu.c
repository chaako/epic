/*---------------------------------------------------------------------------    Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC
 
   Project  : Debug Tools
   Author(s): Pascal J. Frey
   Creation : Feb., 95
   Modif.   :
   Function :
     Returns the total cpu time used in seconds.
---------------------------------------------------------------------------*/
#include <sys/types.h>
#include <sys/times.h>
#ifdef _HPUX_SOURCE
#include <sys/unistd.h>
#else
#include <unistd.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

double getElapsedTime() {
  struct tms buf;
  long   clk_tck=sysconf(_SC_CLK_TCK);
 
  if (times(&buf)!=-1)
    /* Get system time and user time in micro-seconds. */
    return(((double)buf.tms_utime+(double)buf.tms_stime)/clk_tck);
  else
    return 0.;
}

#ifdef __cplusplus
}
#endif

