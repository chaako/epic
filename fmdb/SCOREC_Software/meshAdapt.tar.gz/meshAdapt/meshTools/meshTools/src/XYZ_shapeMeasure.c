#include "MeshTools.h"
#include "Defines.h"
#include "Macros.h"

#ifdef __cplusplus
extern "C" {
#endif


/*--------------------------------------------------------------------------
  computes and returns the shape measure of a tetra.

  Written By Dinesh Godavarty
--------------------------------------------------------------------------*/

int XYZ_shapeMeasure(dArray *xyz,double *shape) {

  int i, j ;
  double TOLERANCE = 1E-14 ;
  double sumSq = 0.0 ;
  double length = 0.0, myShape ;
  int k ;
  double volume = XYZ_volume( xyz ) ;
  if( volume < 0.0 ) {
    *shape = 0.0 ;
    return 0 ;
  }

  // compute shape measure

  for( i = 0 ; i < 3 ; ++i ) {
    for( j = i+1 ; j < 4 ; ++j ) {

      double edgeVector[3] ;
      diffVt( xyz[i], xyz[j], edgeVector ) ;

      length = 0.0 ;
 
      for( k = 0 ; k < 3 ; ++k )
        length += edgeVector[k]*edgeVector[k] ;

      sumSq += length ;
    }
  }

  myShape = 15552.0*volume*volume/( sumSq*sumSq*sumSq ) ;

  if( myShape < TOLERANCE ) {
    *shape = 0.0 ;
    return 0 ;
  }

  *shape = myShape ;
  return(1) ;
}

#ifdef __cplusplus
}
#endif

