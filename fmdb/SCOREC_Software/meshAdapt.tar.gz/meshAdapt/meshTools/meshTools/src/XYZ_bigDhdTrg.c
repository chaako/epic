#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------------------------------------------------------
  returns the cosine of smallest and largest dihedral angle in a tetra.
---------------------------------------------------------------------------*/
int XYZ_bigDhdTrg(dArray *xyz,double target,double *big) {
  double  dhd,org[4][3] ;
  int     e,j,imap ;
  static int map[6][4] = 
    { 0,1,2,3, 1,2,0,3, 2,0,1,3, 0,3,1,2, 1,3,2,0, 2,3,0,1 } ;

  /* evaluate 1st dihedral angle (no mapping required */
  *big = E_dihedral(xyz) ;
  if ( *big < target )
    return(0) ;
  /* evaluate 5 other dihedral angles */
  for ( e=1 ; e<6 ; e++ ) {
    for ( j=0 ; j<4 ; j++ ) {
      imap = map[e][j] ;
      org[j][0] = xyz[imap][0] ;
      org[j][1] = xyz[imap][1] ;
      org[j][2] = xyz[imap][2] ;
    }
    /* dihedral angle evaluation */
    dhd = E_dihedral(org) ;
    if ( dhd < target )
      return(0) ;
    if ( dhd < *big )
      *big = dhd ;
  }
  return(1) ;
}

#ifdef __cplusplus
}
#endif

