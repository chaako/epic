/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Tools
  Author(s) : J. Wan
  Creation  : August, 1999
  Function  :
              Compute the intersection between a face and an edge. If there
              exists intersection, return 1 else 0. The details of intersection
              are returned via IntersectionData.
-------------------------------------------------------------------------*/

#include "MeshTools.h"
#include "oldFMDB.h"
#include "Defines.h"
#include <math.h>
#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
#endif


int IntXYZ_insideFace (double xyz[3], pFace face, double tol)
{
  int i, orient;
  pEdge edge2;
  double fxyz[2][3], normal[3], d;

  F_normalVector (face, 1, normal);
  for (i=0; i<3; i++) {
    edge2=F_edge(face,i);
    orient=F_edgeDir(face,i);
    V_coord(E_vertex(edge2,1-orient),fxyz[0]);
    V_coord(E_vertex(edge2,orient),fxyz[1]);
    d=P_distToLine(xyz,fxyz[0],fxyz[1],normal);
    
    /* if the point is outside the face, return 0 */
    if(d < -(tol*tol)) {
      return 0;
    }   
  }
  return 1;
}

/* check if the Edge cross the face when they are coplanar */
int edgeCrossCoplanarFace (pFace face, pEntity int_Ent[])
{
  if ((EN_type (int_Ent[0])==Tvertex && int_Ent[1]==F_vtOpEd (face, int_Ent[0])) ||
      (EN_type (int_Ent[1])==Tvertex && int_Ent[0]==F_vtOpEd (face, int_Ent[1])) ||
      (EN_type (int_Ent[0])==Tedge && EN_type (int_Ent[1])==Tedge && int_Ent[0]!=int_Ent[1]) ||
      (EN_type (int_Ent[0])==Tface || EN_type (int_Ent[1])==Tface))
    return 1;
  else return 0;
}

/* This function is used to filter the intersection information according to the clousure setting. If no intersection found after filtering, return 0 else 1 */
int ClosureControl (pFace face, int ClosureFlag1, pEdge edge, int ClosureFlag2, IntersectionData *idata)
{
  struct IntDescription *thisDescription;
  pEntity int_Ent1[2], int_Ent2[2], boundedEnt, lyingEdgeOnFace;
  double int_xyz[2][3];
  int i,j, num_int;

  thisDescription =idata->Description;
  
  /* First retrieve the intersection bounding points into array */
  for (i=0; i<idata->nbr; i++) {
    int_Ent1[i] =thisDescription->IntEnt1;
    int_Ent2[i] =thisDescription->IntEnt2;
    for (j=0; j<3; j++)
      int_xyz[i][j] =thisDescription->xyz[j];
    thisDescription =thisDescription->next;
  }
  num_int =idata->nbr;

  /* Initial idata */
  M_intersectionData_delete (*idata);
  *idata =M_intersectionData_new ();
  
  /* Then implement the closure control */
  switch (num_int) {
  case 1:    /* There are one intersection point originally */

    /* If ClosureFlag1 =0 and intersection location is on the face; or
       if ClosureFlag2 =0 and intersection location is on the edge */
    if ((!ClosureFlag1 && EN_type (int_Ent1[0])!=Tface) || 
	(!ClosureFlag2 && EN_type (int_Ent2[0])!=Tedge)) break;

    M_updateIntersectionData (idata, int_Ent1[0], int_Ent2[0], int_xyz[0], -1);
    break;
    
  case 2:    /* There are two intersection points originally */

    if (ClosureFlag1) {
      if (ClosureFlag2) {    /* Full closure case */

	/* Added the edge if it is bouned by the intersection points */
	if (EN_type (int_Ent2[0])==Tvertex && EN_type (int_Ent2[1])==Tvertex)
	  PList_append (idata->boundedEntList, edge);

	for (i=0; i<2; i++)
	  M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);
      }

      else {                /* Half closure case, ClosureFlag1 =1 and ClosureFlag2 =0 */
	if (edgeCrossCoplanarFace(face, int_Ent1)) {
	  for (i=0; i<2; i++)
	    if (EN_type (int_Ent2[i])==Tvertex) {
	      int_Ent1[i] =face;
	      int_Ent2[i] =edge;
	    }
	   
	} else {   /* Edge lies on an edge of Face */
	  /* Get the edge of Face */
	  if (EN_type (int_Ent1[0])==Tvertex && EN_type (int_Ent1[1])==Tvertex) 
	    lyingEdgeOnFace =M_boundedEdgeOnFace (face, int_Ent1[0], int_Ent1[1]);
	  else if (EN_type (int_Ent1[0])==Tedge)
	    lyingEdgeOnFace =int_Ent1[0];
	  else if (EN_type (int_Ent1[1])==Tedge)
	    lyingEdgeOnFace =int_Ent1[1];
	  
	  for (i=0; i<2; i++)
	    if (EN_type (int_Ent2[i])==Tvertex) {
	      int_Ent1[i] =lyingEdgeOnFace;
	      int_Ent2[i] =edge;
	    }
	}
	for (i=0; i<2; i++)
	  M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);
      }

      /* Append the bounded entity on Face if applicable */
      if (EN_type (int_Ent1[0])==Tvertex && EN_type (int_Ent1[1])==Tvertex)
	PList_append (idata->boundedEntList, M_boundedEdgeOnFace (face, int_Ent1[0], int_Ent1[1]));
      else if (int_Ent1[0] != int_Ent1[1] && int_Ent1[0]!=face && int_Ent1[1]!=face)
	PList_append (idata->boundedEntList, face);

    } else {   /* ClosureFlag1 =0 */
      /* If Edge does not cross the face, no intersection */
      if (!edgeCrossCoplanarFace (face, int_Ent1)) break;

      if (ClosureFlag2) {    /* Half-closure case, ClosureFlag1 =0 and ClosureFlag2 =1 */
	
	for (i=0; i<2; i++)
	  if (EN_type (int_Ent1[i])!=Tface) {
	    int_Ent1[0] =face;
	    if (EN_type (int_Ent2[i])==Tvertex)
	      int_Ent2[i] =edge;
	  }

	/* Append Edge if it is bounded */
	if (EN_type (int_Ent2[0])==Tvertex && EN_type (int_Ent2[1])==Tvertex)
	  PList_append (idata->boundedEntList, edge);

      } else {               /* No-closure case, ClosureFlag1 =0 and closureFlag2 =0 */
	for (i=0; i<2; i++) {
	  int_Ent1[i] =face;
	  int_Ent2[i] =edge;
	}
      }

      for (i=0; i<2; i++)
	M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);
    }

    break;
  }
  
  if (idata->nbr)  {
    /* set dim in intersectionData */
    switch (idata->nbr) {
    case 1:
      idata->dim =0;
      break;
    case 2:
      idata->dim =1;
      break;
    }

    return 1;
  }
  return 0;
}

int F_intersectEdge (pFace face, int ClosureFlag1, pEdge edge, int ClosureFlag2, IntersectionData *idata)
{
  double F_xyz[3][3], E_xyz[2][3];
  double tol;
  int i, j, CaseID;
  pVertex eVertex[2], fVertex[3];
  pEdge edgeOfFace;
  pEntity ent, IntEnt1, IntEnt2;
  pPList vlist;
  double fVector[2][3], feVector[2][3], Normal[3];
  double Normal_Len2, vol[2], tmp[3];
  int NumExistingIntPts, NumNewlyFoundIntPts;

  /* Initialize */
  tol =M_getTolerance();
  NumExistingIntPts =idata->nbr;

  /* Get the vertices and their coordinates */
  for (i=0; i<2; i++) {
    eVertex[i] =E_vertex (edge, i);
    V_coord (eVertex[i], E_xyz[i]);
  }
  
  vlist =F_vertices (face, 1);
  for (i=0; i<3; i++) {
    fVertex[i] =PList_item (vlist, i);
    V_coord (fVertex[i], F_xyz[i]);
  }
  PList_delete (vlist);

  /* Check if the entities are coplanar */
  for (i=0; i<2; i++) {
    diffVt (F_xyz[i+1], F_xyz[0], fVector[i]);
    diffVt (E_xyz[i], F_xyz[0], feVector[i]);
  }

  crossProd (fVector[0], fVector[1], Normal);
  Normal_Len2 =dotProd (Normal, Normal);
  for (i=0; i<2; i++) {
    vol[i] =dotProd (Normal, feVector[i]);
    tmp[i] =vol[i]*vol[i];
  }
  tmp[2]=tol*tol*Normal_Len2;

  /* Analyze the cases */
  if (tmp[0] <= tmp[2] && tmp[1] <= tmp[2])    /* Entities are coplanar */
    CaseID =0;
  else if (tmp[0] <=tmp[2])    /* Non-coplanar, First vertex of edge falls on the plane */
    CaseID =1;
  else if (tmp[1] <=tmp[2])    /* Non-coplanar, Second vertex of edge falls on the plane */
    CaseID =2;
  else if (vol[0]*vol[1]<0.0)  /* Non-coplanar, edge cross the face plane */
    CaseID =3;
  else {                       /* Non-coplanar, edge falls in a side of the face plane */
    return 0;                  /* No intersetcions */
  }

  switch (CaseID) {
  case 0:     /* of CaseID, entities are coplanar */
              /* Up to 2 intersection bounding points */
    for (i=0; i<3; i++) {
      edgeOfFace =F_edge (face, i);
      /* First to get the intersection information from closure case */
      M_intersectEdges (edgeOfFace, 1, edge, 1, idata);
      
      /* Check if all the intersection points have been found */
      if ((idata->nbr-NumExistingIntPts)==2)   /* all intersection points between the two entities found */
	if (NumExistingIntPts) return 1;
	else return ClosureControl (face, ClosureFlag1, edge, ClosureFlag2, idata);
    }

    /* If no or not all intersection points have been found, 
       check if the vertices of edge fall inside the face 
       without considering its boundary again */

    for (i=0; i<2; i++) {
      /* Check if the endpoints of the edge are in the intersectionData;
	 If the endpoint is not in the Data, then check if it is located inside the face */

      if (!xyz_inIntersectionData (idata, E_xyz[i], tol*tol))
	if (IntXYZ_insideFace (E_xyz[i], face, tol)) {
	
	  M_updateIntersectionData (idata, face, eVertex[i], E_xyz[i], -1);
	  
	  if ((idata->nbr-NumExistingIntPts)==2)
	    /*all intersection points between the two entities have been found */
	    
	    /* If the F_intersectEdge() is called by another intersection procedure as a child,
	       no closure control needs to be implemented */
	    if (NumExistingIntPts) return 1;
	    else return ClosureControl (face, ClosureFlag1, edge, ClosureFlag2, idata);
	}
    }

    /* Implement closure control if there is any intersection found in the two entities*/
    if ((idata->nbr-NumExistingIntPts))
      if (NumExistingIntPts) return 1;
      else return ClosureControl (face, ClosureFlag1, edge, ClosureFlag2, idata);
    return 0;


  case 1:    /* of CaseID, Non-coplanar, 1st vertex of edge on the face plane */
  case 2:    /* of CaseID, Non-coplanar, 2nd vertex of edge on the face plane */
             /* Up to 1 intersection bounding point */
    i =CaseID-1;
    ent =XYZ_onBoundary (E_xyz[i], face, tol);
    /* return the details */
    if (ent && ClosureFlag2)
      if (ClosureFlag1 || EN_type (ent)==Tface) {
	M_updateIntersectionData (idata, ent, eVertex[i], E_xyz[i], tol*tol);
	idata->dim =0;
	return 1;
      }
    return 0;

  case 3:    /* of CaseID, Non-coplanar, edge cross the face plane */
             /* Cumpute the intersection points between the edge and the face plane */
             /* Up to 1 intersection bounding point */
    diffVt (E_xyz[1], E_xyz[0], feVector[0]);
    vol[0] =dotProd (feVector[0], Normal);
    diffVt (E_xyz[0], F_xyz[0], feVector[1]);
    vol[1] =-dotProd (feVector[1], Normal)/vol[0];
    for (i=0; i<3; i++)
      E_xyz[1][i] =E_xyz[0][i]+vol[1]*feVector[0][i];

    /* Check if the point falls on the face */
    ent =XYZ_onBoundary (E_xyz[1], face, tol);
    if (ent)
      if (ClosureFlag1 || EN_type (ent)==Tface) {
	M_updateIntersectionData (idata, ent, edge, E_xyz[1], tol*tol);     
	idata->dim =0;
	return 1;
      }
    return 0;

  }   /* End of Switch (CaseID) */

}




