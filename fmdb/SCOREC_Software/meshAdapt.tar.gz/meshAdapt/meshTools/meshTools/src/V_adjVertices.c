/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  THE SOFTWARE AND ACCOMPANYING WRITTEN MATERIALS ARE PROVIDED  "AS IS" AND 
  WITHOUT ANY WARRANTY, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK 
  AS TO THE QUALITY AND PERFORMANCE OF THE SOFTWARE AND USE OF THE ACCOMPA-
  NYING WRITTEN MATERIALS IS ASSUMED BY YOU.  IN NO EVENT SHALL RENSSELAER 
  POLYTECHNIC INSTITUTE BE LIABLE FOR ANY LOST REVENUE, LOST PROFITS OR 
  OTHER INCIDENTAL OR CONSEQUENTIAL DAMAGES, EVEN IF ADVISED OF THE POSSIB-
  ILITIES OF SUCH DAMAGES, WHERE DAMAGES ARISE OUT OF OR IN CONNECTION WITH 
  THE USE OF, PERFORMANCE OR NONPERFORMANCE OF THIS SOFTWARE.

  This software and accompanying written materials may not be distributed 
  outside your organization or outside the United States of America without
  express written authorization from Rensselaer Polytechnic Institute.


  Project   : MeshTools
  Author(s) : Rao Garimella
  Creation  : Jan 4, 95
  Modified  : 
  Function  : Find adjacent vertices of a mesh vertex classified on 
              the closure of a given entity
-------------------------------------------------------------------------*/

#include <stdio.h>
#include "oldFMDB.h"
#include "MeshTools.h"

pPList V_adjVertices(pVertex v, pGEntity gent) {
  pGEntity gent2;
  pPList vedges, adjverts = PList_new();
  pEdge e;
  pVertex adjv;
  eType gtype;
  void *temp = 0;

  /* This may not work if small features have been removed */
  vedges = V_edges(v);
  temp = 0;
  while (e = PList_next(vedges,&temp)) {
    adjv = E_otherVertex(e,v);
    gent2 = V_whatIn(adjv);
    if (!gent || GEN_inClosure(gent,gent2))
      PList_append(adjverts,adjv);
  }
  PList_delete(vedges);

  if (!PList_size(adjverts)) {
    PList_delete(adjverts);
    return 0;
  }
  else
    return adjverts;
}
