/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Pascal J. Frey
  Creation  : June, 95
  Modifi.   : 
  Function  :
    return coordinates of vertices of a region.
-------------------------------------------------------------------------*/
#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

void R_coord(pRegion rgn,dArray *xyz) {
  pPList  list = R_vertices(rgn,1);
  pEdge   edge;
  pVertex vtx;
  pPoint  pnt;
  int     i=0,j,n;
  void   *tmp=0;

  /* points of vertices */
  while (vtx=(pVertex)PList_next(list,&tmp)) {
    V_coord(vtx,xyz[i]);
    i++;
  }
  PList_delete(list);
}

#ifdef __cplusplus
}
#endif
