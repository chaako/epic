/* -------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Tools
  Author(s) : J. Wan
  Creation  : August, 1999
  Function  :
              Compute the intersection between two edges. If there
              exists intersection, return 1 else 0. The details of intersection
              are returned via IntersectionData.
-------------------------------------------------------------------------*/

#include "MeshTools.h"
#include "oldFMDB.h"
#include "Defines.h"
#include <math.h>

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
#endif

/* Compute the intersection points when the edges are colinear */
int M_intersectColinearEdges (pEdge edge1, int ClosureFlag1, pEdge edge2, int ClosureFlag2, pVertex L1_vertex[2], pVertex L2_vertex[2], double L1_xyz[2][3], double L2_xyz[2][3], double tol, IntersectionData *idata, int NumExistingIntPts)
{
  double LL_vector[4][3], vol, myTol=tol*tol;
  int i,j;
  int int_Num=0, int_Type1[2], int_Type2[2], int_EnclCnt1=0, int_EnclCnt2=0;
  double int_XYZ[3];
  pEntity int_Ent1, int_Ent2;

  /* Intersection Type:
     0: vertex[0] involed
     1: vertex[1] involed
     2: edge involed
   */

  /*
    The following cumputes the vectors as:
    LL_vector[0]: L1_xyz[0], L2_xyz[0]
    LL_vector[1]: L1_xyz[0], L2_xyz[1]
    LL_vector[2]: L1_xyz[1], L2_xyz[0]
    LL_vector[3]: L1_xyz[1], L2_xyz[1]
   */

  for (i=0; i<2; i++)
    for (j=0; j<2; j++)
      diffVt (L1_xyz[i], L2_xyz[j], LL_vector[2*i+j]);
  
  /* Check if the ends of edges coincide */

  vol =dotProd (LL_vector[0], LL_vector[1]);  
  if (fabs(vol) < myTol) {    /* L1_xyz[0] falls on L2_xyz[0] or L2_xyz[1] */
    vol =dotProd (LL_vector[0], LL_vector[0]);
    if (vol<myTol)            /* L1_xyz[0] falls on L2_xyz[0] */
      {
	int_Type1[int_Num]=0;
	int_Type2[int_Num]=0;
	int_Num ++;
      }
    else                      /* L1_xyz[0] falls on L2_xyz[1] */
      {
	int_Type1[int_Num]=0;
	int_Type2[int_Num]=1;
	int_Num ++;
      }
  } else if (vol<0) {         /* L1_xyz[0] falls between L2_xyz[0] and L2_xyz[1] */
    int_Type1[int_Num]=0;
    int_Type2[int_Num]=2;
    int_Num ++;
  } 
  /* else L1_xyz[0] falls outside L2_xyz[0] and L2_xyz[1] */


  vol =dotProd (LL_vector[2], LL_vector[3]); 
  if (fabs(vol) < myTol) {    /* L1_xyz[1] falls on L2_xyz[0] or L2_xyz[1] */
    vol =dotProd (LL_vector[2], LL_vector[2]);
    if (vol<myTol)            /* L1_xyz[1] falls on L2_xyz[0] */
      {
	int_Type1[int_Num]=1;
	int_Type2[int_Num]=0;
	int_Num ++;
      }
    else                      /* L1_xyz[1] falls on L2_xyz[1] */
      {
	int_Type1[int_Num]=1;
	int_Type2[int_Num]=1;
	int_Num ++;
      }
  } else if (vol<0) {         /* L1_xyz[1] falls between L2_xyz[0] and L2_xyz[1] */
    int_Type1[int_Num]=1;
    int_Type2[int_Num]=2;
    int_Num ++;
  } 
  /* else L1_xyz[1] falls outside L2_xyz[0] and L2_xyz[1] */

  /* DO not consider efficiency at this time */
  /* if (idata->nbr==2) return 1;*/

  vol =dotProd (LL_vector[0], LL_vector[2]);
  if (vol<-myTol)           /* L2_xyz[0] between L1_xyz[0] and L1_xyz[1] */
    {
      int_Type1[int_Num]=2;
      int_Type2[int_Num]=0;
      int_Num ++;
    }

  /* DO not consider effiiency at this time */
  /* if (idata->nbr==2) return 1; */

  vol =dotProd (LL_vector[1], LL_vector[3]);
  if (vol<-myTol)           /* If vol[3]<0, then L2_xyz[1] between L1_xyz[0] and L1_xyz[1] */
    {
      int_Type1[int_Num]=2;
      int_Type2[int_Num]=1;
      int_Num ++;
    }
  
  /* Now apply the closure constraints and update the intersection information */
  switch (int_Num) {
  case 1:
      if (ClosureFlag1 && ClosureFlag2) {
	M_updateIntersectionData (idata, L1_vertex[int_Type1[0]], L2_vertex[int_Type2[0]], L1_xyz[int_Type1[0]], myTol);

	/* The resulted intersection is a vertex */
	idata->dim =0;
	return 1;
      }
      /* Otherwise, no intersection and return 0 */
      break;
  case 2:
      if (ClosureFlag1 && ClosureFlag2) {
	for (i=0; i<2; i++) {
	  switch (int_Type1[i]) {
	  case 0:
	  case 1:
	    int_Ent1 =L1_vertex[int_Type1[i]];
	    int_EnclCnt1 ++;
	    for (j=0; j<3; j++)
	      int_XYZ[j] =L1_xyz[int_Type1[i]][j];
	    break;
	  case 2:
	    int_Ent1 =edge1;
	    for (j=0; j<3; j++)
	      int_XYZ[j] =L2_xyz[int_Type2[i]][j];
	    break;
	  }

	  switch (int_Type2[i]) {
	  case 0:
	  case 1:
	    int_Ent2 =L2_vertex[int_Type2[i]];
	    int_EnclCnt2 ++;
	    break;
	  case 2:
	    int_Ent2 =edge2;
	    break;
	  }
	  M_updateIntersectionData (idata, int_Ent1, int_Ent2, int_XYZ, myTol);
	}
      }

      else if (!ClosureFlag1 && ClosureFlag2) {
	for (i=0; i<2; i++) {
	  int_Ent1 =edge1;
	  switch (int_Type1[i]) {
	  case 0:
	  case 1:
	    for (j=0; j<3; j++)
	      int_XYZ[j] =L1_xyz[int_Type1[i]][j];
	    break;
	  case 2:
	    for (j=0; j<3; j++)
	      int_XYZ[j] =L2_xyz[int_Type2[i]][j];
	    break;
	  }

	  switch (int_Type2[i]) {
	  case 0:
	  case 1:
	    if (int_Type1[i]==2) {
	      int_Ent2 =L2_vertex[int_Type2[i]];
	      int_EnclCnt2 ++;
	    }
	    else
	      int_Ent2 =edge2;
	    break;
	  case 2:
	      int_Ent2 =edge2;
	    break;
	  }
	  M_updateIntersectionData (idata, int_Ent1, int_Ent2, int_XYZ, myTol);
	}	
      }

      else if (ClosureFlag1 && !ClosureFlag2) {
	for (i=0; i<2; i++) {
	  int_Ent2 =edge2;
	  switch (int_Type2[i]) {
	  case 0:
	  case 1:
	    for (j=0; j<3; j++)
	      int_XYZ[j] =L2_xyz[int_Type2[i]][j];
	    break;
	  case 2:
	    for (j=0; j<3; j++)
	      int_XYZ[j] =L1_xyz[int_Type1[i]][j];
	    break;
	  }

	  switch (int_Type1[i]) {
	  case 0:
	  case 1:
	    if (int_Type2[i]==2) {
	      int_Ent1 =L1_vertex[int_Type1[i]];
	      int_EnclCnt1 ++;
	    }
	    else
	      int_Ent1 =edge1;
	    break;
	  case 2:
	      int_Ent1 =edge1;
	    break;
	  }
	  M_updateIntersectionData (idata, int_Ent1, int_Ent2, int_XYZ, myTol);
	}	
      }

      else {  /* !ClosureFlag1 && !ClosureFlag */

	for (i=0; i<2; i++) {
	  int_Ent1 =edge1;
	  switch (int_Type1[i]) {
	  case 0:
	  case 1:
	    for (j=0; j<3; j++)
	      int_XYZ[j] =L1_xyz[int_Type1[i]][j];
	    break;
	  case 2:
	    for (j=0; j<3; j++)
	      int_XYZ[j] =L2_xyz[int_Type2[i]][j];
	    break;
	  }

	  int_Ent2 =edge2;	    
	  M_updateIntersectionData (idata, int_Ent1, int_Ent2, int_XYZ, myTol);
	}		
      }

      if (!NumExistingIntPts) {
	/* add the enclosed intersected entities into IntersectionData */
	if (int_EnclCnt1==2) /* && !inList (idata->boundedEntList,edge1)) */
	  PList_appUnique (idata->boundedEntList, edge1);
	if (int_EnclCnt2==2) /* && !inList (idata->boundedEntList,edge2)) */
	  PList_appUnique (idata->boundedEntList, edge2);
      }

      /* The resulted intersection is an edge */
      idata->dim =1;
      

      return 1;
      break;
  }
  return 0;

}

/* Compute the intersection points when the edges are colinear */
int M_intersectNonColinearEdges (pEdge edge1, int ClosureFlag1, pEdge edge2, int ClosureFlag2, pVertex L1_vertex[2], pVertex L2_vertex[2], double L1_xyz[2][3], double L2_xyz[2][3], double tol, IntersectionData *idata)
{
  double L_vector[2][3], L_normal[3], vol[5], myTol =tol*tol;
  double MaxVal_inNormal, tmp;
  double A[2][2], B[2], Scale, int_xyz[3];
  int i, j, MaxDim_inNormal=0;
  pEntity int_ent1, int_ent2;
 
  diffVt (L1_xyz[1], L1_xyz[0], L_vector[0]);
  diffVt (L2_xyz[1], L2_xyz[0], L_vector[1]);
  crossProd (L_vector[0], L_vector[1], L_normal);
  
  MaxVal_inNormal =fabs (L_normal[0]);
  for (i=1; i<3; i++) {
    if ((tmp=fabs (L_normal[i])) > MaxVal_inNormal) {
      MaxDim_inNormal =i;
      MaxVal_inNormal =tmp;
    }
  }
  
  for (i=j=0; i<3; i++) {
    if (i==MaxDim_inNormal) continue;
    A[j][0] =L_vector[0][i];
    A[j][1] =-L_vector[1][i];
    B[j] =L2_xyz[0][i] - L1_xyz[0][i];
    j ++;
  }
  
  tmp =A[0][0]*A[1][1] - A[0][1]*A[1][0];
  if (fabs (tmp) <tol)
    return -1;

  /* Compute the Scale parameter on edge1 */
  Scale =(A[1][1]*B[0] - A[0][1]*B[1]) / tmp;
  
  for (i=0; i<3; i++)
    int_xyz[i] =L1_xyz[0][i] + Scale * L_vector[0][i];

  /* Check if the intersection point falls within the edges */
  /* Check edge1 first */
  for (i=0; i<2; i++) {
    diffVt (int_xyz, L1_xyz[i], L_vector[i]);
    vol[i] =dotProd (L_vector[i], L_vector[i]);
  }
  vol[4] =dotProd (L_vector[0], L_vector[1]);
  if (vol[4]>0.0 && vol[0] > myTol && vol[1] > myTol)  /* Intersection point falls outside edge1 */
    return 0;


  /* Then check edge2 */
  for (i=0; i<2; i++) {
    diffVt (int_xyz, L2_xyz[i], L_vector[i]);
    vol[i+2] =dotProd (L_vector[i], L_vector[i]);
  }
  vol[4] =dotProd (L_vector[0], L_vector[1]);
  if (vol[4]>0.0 && vol[2] > myTol && vol[3] > myTol)  /* Intersection point falls outside edge2 */
    return 0;

  /* Update the intersection data based on Closure Setting*/
  if (vol[0] <= myTol)        /* Intersect at L1_xyz[0] */
    {
      if (!ClosureFlag1) return 0;
      int_ent1 = L1_vertex[0];
    }
  else if (vol[1] <= myTol)   /* Intersect at L1_xyz[1] */
    {
      if (!ClosureFlag1) return 0;
      int_ent1 = L1_vertex[1];
    }
  else
    int_ent1 = edge1;

  if (vol[2] <= myTol)        /* Intersect at L2_xyz[0] */
    {
      if (!ClosureFlag2) return 0;
      int_ent2 = L2_vertex[0];
    }
  else if (vol[3] <= myTol)   /* Intersect at L2_xyz[1] */
    {
      if (!ClosureFlag2) return 0;
      int_ent2 = L2_vertex[1];
    }
  else
    int_ent2 = edge2;

  M_updateIntersectionData (idata, int_ent1, int_ent2, int_xyz, myTol);

  /* the resulted intersection is a vertex */
  idata->dim =0;

  return 1;
}

/* The subroutine is used to check the intersection point between two line segments,
   given that the segments are coplanar and not colinear. */
int M_intersectEdges (pEdge edge1, int ClosureFlag1, pEdge edge2, int ClosureFlag2, IntersectionData *idata)
{
  pVertex L1_vertex[2], L2_vertex[2];
  double L1_xyz[2][3], L2_xyz[2][3];
  double L_vector[2][3], L_normal[2][3], vol[4], tol, myTol;
  int i, j, ok;
  int NumExistingIntPts;

 
  tol =M_getTolerance ();
  NumExistingIntPts =idata->nbr;

  for (i=0; i<2; i++) {
    L1_vertex[i] =E_vertex (edge1, i);
    V_coord (L1_vertex[i], L1_xyz[i]);
    L2_vertex[i] =E_vertex (edge2, i);
    V_coord (L2_vertex[i], L2_xyz[i]);
  }
  
  /* Computes the vector and concerned values */
  diffVt (L1_xyz[1], L1_xyz[0], L_vector[0]);
  vol[2] =dotProd (L_vector[0], L_vector[0]);

  for (i=0; i<2; i++) {
    diffVt (L2_xyz[i], L1_xyz[0], L_vector[1]);
    crossProd (L_vector[0], L_vector[1], L_normal[i]);
    vol[i] =dotProd (L_normal[i], L_normal[i]);
  }

  myTol =tol*tol*vol[2];
  
  /* First check if the edges are colinear */
  if (vol[0] <= myTol && vol[1] <= myTol) {
    /* The edges are colinear */
    return M_intersectColinearEdges (edge1, ClosureFlag1, edge2, ClosureFlag2, L1_vertex, L2_vertex, 
				     L1_xyz, L2_xyz, tol, idata, NumExistingIntPts);
  }

  /* Then check if the edges do cross each other */
  vol[3] =dotProd (L_normal[0], L_normal[1]);
  if (vol[3] > 0 && vol[0] > myTol && vol[1] > myTol)
    /* One edge is on a side of the other edge, No intersection points */
    return 0;

  /* At last, compute the intersection point when the edges or their extended line cross each other*/
  ok =M_intersectNonColinearEdges (edge1, ClosureFlag1, edge2, ClosureFlag2, L1_vertex, L2_vertex, 
				   L1_xyz, L2_xyz, tol, idata);
  if (ok==-1)
    MT_ErrorHandler ("M_IntersectEdges", "pb ", FATAL);
  
  return ok;
}
