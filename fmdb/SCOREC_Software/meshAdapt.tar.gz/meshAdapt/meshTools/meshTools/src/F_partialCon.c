/*---------------------------------------------------------------------------    Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC
 
   Project  : MeshTools
   Author(s): Pascal J. Frey
   Creation : Feb., 95
   Modif.   :
   Function :
     checks if a mesh face is partially connected.
---------------------------------------------------------------------------*/
#include "oldFMDB.h"
#include "MeshTools.h"
#include "Defines.h"
#include "modeler.h"

#ifdef __cplusplus
extern "C" {
#endif

int F_partialCon(pFace face) {
  int  side,nbr,gnbr;
  pGEntity fobj;

  /* get the number of mesh regions connected */
  nbr = 0;
  if (F_region(face,0)) {
    side = 0; 
    nbr++;
  }
  if (F_region(face,1)) {
    side = 1; nbr++;
  }
  if (F_whatInType(face)==Tface) {
    switch (nbr) {
    case 0:
      /* check if model face connected to at least 1 region */
      return( GF_region((pGFace)F_whatIn(face),0) || GF_region((pGFace)F_whatIn(face),1) ) ;
    case 1:
      /* side is side of mesh region w/r face */
      fobj = F_whatIn(face);
      if (GF_region((pGFace) fobj,side))
	return(1);
      else
	return(0);
    case 2:
      return(0);
    }
  }
  else if (GEN_type(F_whatIn(face))==Tregion) {
    if (!nbr)
      MT_ErrorHandler("wrong classification","F_partialCon",WARN);
    return(nbr==1);
  }
  return(0);
}

#ifdef __cplusplus
}
#endif
