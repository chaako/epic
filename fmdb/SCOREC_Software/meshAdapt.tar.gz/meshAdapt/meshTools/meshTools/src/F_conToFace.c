#include "oldFMDB.h"

#ifdef __cplusplus
extern "C" {
#endif

int F_conToFace(pFace face1, pFace face2) {
  pPList fverts, fedges;
  pEdge edge;
  pVertex vtx;
  void *temp;

  temp = 0;
  fverts = F_vertices(face1,1);
  while (vtx = PList_next(fverts,&temp))
    if (F_inClosure(face2,vtx)) {
      PList_delete(fverts);
      return 1;
    }
  PList_delete(fverts);

  temp = 0;
  fedges = F_edges(face1,0,0);
  while (edge = PList_next(fedges,&temp))
    if (F_inClosure(face2,edge)) {
      PList_delete(fedges);
      return 1;
    }
  PList_delete(fedges);

  return 0;
}

#ifdef __cplusplus
}
#endif
