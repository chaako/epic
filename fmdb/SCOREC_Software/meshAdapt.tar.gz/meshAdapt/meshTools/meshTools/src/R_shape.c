#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------------------------------------------------------
  
----------------------------------------------------------------------------*/
int R_shape(pRegion rgn,double *shape)
{
  double xyz[10][3] ;

  /* get the vertices coordinates */
  R_coord(rgn,xyz) ;

  return XYZ_shape(xyz,shape) ;
}

#ifdef __cplusplus
}
#endif

