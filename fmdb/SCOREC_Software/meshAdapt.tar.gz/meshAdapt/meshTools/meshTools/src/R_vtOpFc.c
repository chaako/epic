/* Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1991, RPI-SCOREC
 
   Project: OCTREE
 
   Authors/Dates:
   Pascal J. Frey, Feb. 95
 
   Functionality:
   Given a region and a vertex, get the opposite face (only for tets)

   Argument Variable(s):
   Name  Type In/Out Description
 |------|----|------|-----------------------------------------------------|
*/
#include "oldFMDB.h"

#ifdef __cplusplus
extern "C" {
#endif

pFace R_vtOpFc(pRegion rgn,pVertex vtx)
{
  pPList vlist ;
  pFace  face ;
  int    i; 

  if ( R_numFaces(rgn)>4 )
    return((pFace)0) ;
  for ( i=0 ; i<R_numFaces(rgn) ; i++ ) {
    face = R_face(rgn,i) ;
    vlist = F_vertices(face,1) ;
    if ( !PList_inList(vlist,vtx) ) {
      PList_delete(vlist) ;
      return(face) ;
    }
    PList_delete(vlist) ;
  }
  return((pFace)0) ;
}

#ifdef __cplusplus
}
#endif
