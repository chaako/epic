#include "MeshTools.h"
/*--------------------------------------------------------------------------
   Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project  : Mesh Tools
   Author(s): Kaan Karamete
   Creation : Feb 99
   Function : checks if a given quad element is near flat or negative volume
---------------------------------------------------------------------------*/
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

int XYZ_checkFlatQuad(dArray *xyz, double* normal) {

int i;
double d, tol;
 
  tol=M_getTolerance();

  for(i=0;i<8;++i){

    switch(i){
    case 0 :
      d=P_distToLine(xyz[3],xyz[0],xyz[1],normal);
      break;
    case 1:  
      d=P_distToLine(xyz[2],xyz[0],xyz[1],normal);
      break;
    case 2 :
      d=P_distToLine(xyz[0],xyz[1],xyz[2],normal);
      break;
    case 3: 
      d=P_distToLine(xyz[3],xyz[1],xyz[2],normal);
      break;
    case 4:
      d=P_distToLine(xyz[0],xyz[2],xyz[3],normal);
      break;
    case 5:
      d=P_distToLine(xyz[1],xyz[2],xyz[3],normal);
      break;
    case 6:
      d=P_distToLine(xyz[2],xyz[3],xyz[0],normal);
      break;
    case 7:
      d=P_distToLine(xyz[1],xyz[3],xyz[0],normal);
      break;
      
    }


    if(d<=0.0 || d<tol*tol) 
      return(1);
  }

 return(0);

}

#ifdef __cplusplus
}
#endif

