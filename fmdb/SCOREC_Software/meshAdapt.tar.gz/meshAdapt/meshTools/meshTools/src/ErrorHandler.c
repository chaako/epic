/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Saikat Dey
  Creation  : Jan., 95
  Modifi.   : Pascal J. Frey / March, 95
              de Cougny (ifdef MPI)
  Function  :
    standard error handler for mesh database routines.
-------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef sun4_5
 #include <sys/systeminfo.h>
 #include <sys/types.h>
 #include <unistd.h>
#endif

#include <time.h>
#include "Defines.h"
#include "MeshTools.h"

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifndef SI_SYSNAME
#define SI_SYSNAME              1    /* return name of operating system */
#define SI_HOSTNAME             2    /* return name of node           */
#define SI_RELEASE              3    /* return release of operating system*/
#define SI_VERSION              4    /* return version field of utsname */
#define SI_MACHINE              5    /* return kind of machine        */
#define SI_ARCHITECTURE         6    /* return instruction set arch   */
#define SI_HW_SERIAL            7    /* return hardware serial number */
#define SI_HW_PROVIDER          8    /* return hardware manufacturer  */
#define SI_SRPC_DOMAIN          9    /* return secure RPC domain      */
#endif

static FILE  *_errfd;                /* error handler file descriptor */
static double _elpstime;             /* total time                    */
MarkID MT_cnst = 0;
extern int forcelink;

void MT_ErrorHandler(char *msg,char *fct,int severity) {
  static char *oldMsg = '\0';
  static int  _errorcnt=0;
  int pid=0;
  char scall[256];

  if (oldMsg && !strcmp(oldMsg,msg)) {
    _errorcnt++;
    return;
  }

  if (!_errfd)
    _errfd = stderr;
  switch (severity) {
  case WARN: 
    fprintf(_errfd,"*** Warning:\n\t%s: %s\n",fct,msg);
    fflush(_errfd);
    break;
  case ERROR:
    fprintf(_errfd,"***** Error:\n\t%s: %s\n",fct,msg);
    fflush(_errfd);
    break;
  case FATAL:
    fprintf(stderr,"Fatal Error:\n\t%s: %s\n",fct,msg);

#ifdef sun4_5
    fprintf(stderr,"Stack Trace:\n\n");
    pid = getpid();
    sprintf(scall,"/usr/proc/bin/pstack %d",pid);
    system(scall);
    fprintf(stderr,"\n");
#endif

    #ifdef MPI
    MPI_Abort(MPI_COMM_WORLD,-1);
    #else
    exit(2);
    #endif
  case MESSG:
    fprintf(_errfd,"%s: %s\n",fct,msg);
    fflush(_errfd);
    break;
  default:
    fprintf(_errfd,"%s: %s\n",fct,msg);
    fflush(_errfd);
  }

  if (oldMsg)
    free(oldMsg);
  oldMsg = (char*)malloc(sizeof(char)*(strlen(msg)+1));
  strcpy(oldMsg,msg);
  _errorcnt=1;

}

int MT_init(char *errfile) {
  char machine[256],os[256],release[256];
  int ok;
  static time_t t;

  if (!errfile || !strlen(errfile))
    _errfd = stderr;
  else if (!(_errfd=fopen(errfile,"w"))) {
    fprintf(stderr,"could not open file.\n");
    fflush(_errfd);
    return(0);
  }
#ifdef sun4_5
  ok=sysinfo(SI_HOSTNAME,machine,256);
  if (ok!=-1)
    sysinfo(SI_SYSNAME,os,256);
  if (ok!=-1)
    sysinfo(SI_RELEASE,release,256);
  if (ok!=-1) {
    /* print info. about machine architecture */
    fprintf(_errfd,"\nMachine name: %s [%s,Ver. %s]\n",machine,os,release);
    fflush(_errfd);
  }
#endif
  t = time(0);
  fprintf(_errfd,"Date & time : %s\n\n",(char *)ctime(&t));
  fflush(_errfd);
  
  /* get Cpu time */
  _elpstime = getElapsedTime();
  MT_cnst = MD_registerMark("cnst",5,0);

  /* Fool the linker into loading the following debugging functions */
  if (forcelink) {
    M_info(0);
    EN_info(0);
  }

  return(1);
}

void MT_exit() {
  _elpstime = getElapsedTime()-_elpstime;
  fprintf(_errfd,"\nTotal elapsed time: %15.3f (sec.)\n",_elpstime);
  fflush(_errfd);
  fclose(_errfd);
  /* reset the standard error file */
  _errfd=stderr;
}

#ifdef __cplusplus
}
#endif
