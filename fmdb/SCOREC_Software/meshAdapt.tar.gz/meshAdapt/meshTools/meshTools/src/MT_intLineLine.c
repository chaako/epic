/*
Intersect line segment with line segment
Both line segments on same plane
Can return up to 4 intersections (see MT_intLineLine3)
USE LEVEL=2 FOR COMPLETE CHECK
*/
#include "MeshTools.h"

void MT_intLineLine(
 double L_XYZ[2][3],
 double l_xyz[2][3],
 double tol,
 int level,
 int *int_nbr,
 double int_xyz[4][3]
)

{

 double LVEC[3];
 double Lvec0[3];
 double Lvec1[3];
 double vec0[3];
 double vec1[3];
 double dotProd_p;
 int end;
 double vecs[2][3];
 double lvec[3];
 double normal[3];
 int max_dim;
 double max_val;
 int dim;
 int ind;
 double A[2][2];
 double B[2];
 double den;
 double s;
 double t;
 double LVEC_norm2;
 double vec0_norm2;
 double vec1_norm2;
 int nbr;
 double lvec_norm2;
 double lVEC0[3];
 double lVEC1[3];
 int int_nbr2;
 double int_xyz2[3];
 int j;
 int int_ind2;

 diffVt(L_XYZ[1],L_XYZ[0],LVEC);
 LVEC_norm2= dotProd(LVEC,LVEC);
 diffVt(l_xyz[0],L_XYZ[0],Lvec0);
 diffVt(l_xyz[1],L_XYZ[0],Lvec1);
 crossProd(LVEC,Lvec0,vec0);
 vec0_norm2= dotProd(vec0,vec0);
 crossProd(LVEC,Lvec1,vec1);
 vec1_norm2= dotProd(vec1,vec1);

 dotProd_p= dotProd(vec0,vec1);

 if ( vec0_norm2 <= tol*tol*LVEC_norm2 &&
      vec1_norm2 <= tol*tol*LVEC_norm2 ) {

    /*
    Both ends of l within tol of L's line
    */

    /*
    Both line segments colinear
    */

    if ( level == 1 ) {

       /*
       In the context of face removal validity checks,
       should lead to a no intersection assuming the check between
       new region and nearby verts has been performed
       */

       *int_nbr= 0;
       return;
    }

    /*
    Do the intersection checks along line
    */

    MT_intLineLine3(L_XYZ,l_xyz,tol,int_nbr,int_xyz);
    return;
 }

 /*
 Line segments not colinear
 */

 if ( dotProd_p > 0.0 &&
    !(vec0_norm2 <= tol*tol*LVEC_norm2) &&
    !(vec1_norm2 <= tol*tol*LVEC_norm2) ) {

    /*
    l on 1 side of L
    Neither end 0 of l nor end 1 of l within tol's of L's line
    */

    /*
    Both ends of l on left side of L
    No intersection
    */

    *int_nbr= 0;
    return;
 }

 /*
 Go through situation
 */

 diffVt(l_xyz[1],l_xyz[0],lvec);
 lvec_norm2= dotProd(lvec,lvec);
 diffVt(L_XYZ[0],l_xyz[0],lVEC0);
 diffVt(L_XYZ[1],l_xyz[0],lVEC1);
 crossProd(lvec,lVEC0,vec0);
 vec0_norm2= dotProd(vec0,vec0);
 crossProd(lvec,lVEC1,vec1);
 vec1_norm2= dotProd(vec1,vec1);

 dotProd_p= dotProd(vec0,vec1);

 if ( vec0_norm2 <= tol*tol*lvec_norm2 &&
      vec1_norm2 <= tol*tol*lvec_norm2 ) {

    /*
    Both ends of L within tol of l's line
    */

    /*
    Both line segments colinear
    */

    /*
    In the context of face removal validity checks,
    should lead to a no intersection assuming the check between
    new region and nearby verts has been performed
    */

    *int_nbr= 0;
    return;
 }

 /*
 Line segments not colinear
 */

 if ( dotProd_p > 0.0 &&
    !(vec0_norm2 <= tol*tol*lvec_norm2) &&
    !(vec1_norm2 <= tol*tol*lvec_norm2) ) {

    /*
    L on 1 side of l
    Neither end 0 of L nor end 1 of L within tol's of l's line
    */

    /*
    Both ends of L on left side of l
    No intersection
    */

    *int_nbr= 0;
    return;
 }

 /*
 The 2 line segments should crossProd each other
 Note that they may not, due to that distance tolerance thing
 */

 MT_intLineLine2(L_XYZ,l_xyz,&int_nbr2,int_xyz2);

 if ( int_nbr2 != 1 )
  MT_ErrorHandler("MT_intLineLine","pb ",FATAL);

 diffVt(L_XYZ[1],L_XYZ[0],LVEC);
 diffVt(int_xyz2,L_XYZ[0],vec0);
 vec0_norm2= dotProd(vec0,vec0); 
 diffVt(int_xyz2,L_XYZ[1],vec1);
 vec1_norm2= dotProd(vec1,vec1); 
 dotProd_p= dotProd(vec0,vec1);
 if ( dotProd_p > 0.0 &&
    !(vec0_norm2 <= tol*tol) &&
    !(vec1_norm2 <= tol*tol) ) {
    *int_nbr= 0;
    return;
 }
 diffVt(l_xyz[1],l_xyz[0],lvec); 
 diffVt(int_xyz2,l_xyz[0],vec0); 
 vec0_norm2= dotProd(vec0,vec0);
 diffVt(int_xyz2,l_xyz[1],vec1);
 vec1_norm2= dotProd(vec1,vec1);
 dotProd_p= dotProd(vec0,vec1);
 if ( dotProd_p > 0.0 &&
    !(vec0_norm2 <= tol*tol) &&
    !(vec1_norm2 <= tol*tol) ) {
    *int_nbr= 0;
    return;
 }

 /*
 Ok,
 store intersection into passed var
 */

 *int_nbr= 1;
 for ( j= 0 ; j< 3 ; j++ )
  int_xyz[0][j]= int_xyz2[j];

}
