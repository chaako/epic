/*--------------------------------------------------------------------------
   Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project  : Mesh Tools
   Author(s): Kaan Karamete
   Creation : Feb 99
   Function : checks if a given tri element is near flat or negative volume
---------------------------------------------------------------------------*/
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

int XYZ_checkFlatTri(dArray *xyz, double* normal) {

int i;
double d, tol;
 
  tol=M_getTolerance();

  d=P_distToLine(xyz[2],xyz[0],xyz[1],normal);
  if(d<=0.0 || d<tol*tol) 
    return(1);
  
  d=P_distToLine(xyz[0],xyz[1],xyz[2],normal);
  if(d<=0.0 || d<tol*tol) 
    return(1);
  
  d=P_distToLine(xyz[1],xyz[2],xyz[0],normal);
  if(d<=0.0 || d<tol*tol) 
    return(1);
 
 return(0);

}

#ifdef __cplusplus
}
#endif

