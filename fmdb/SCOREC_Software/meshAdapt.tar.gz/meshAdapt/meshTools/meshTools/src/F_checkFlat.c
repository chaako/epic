#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------------------------------------------------------
  checks if a given region is near flat or negative volume
----------------------------------------------------------------------------*/
int F_checkFlat(pFace face,double* normal)
{
  double xyz[3][3] ;

  /* get the vertices coordinates */
  F_coord(face,xyz) ;

  return XYZ_checkFlatTri(xyz,normal) ;
}

#ifdef __cplusplus
}
#endif

