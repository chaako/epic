#include "oldFMDB.h"

/* return list of edges connected to a vertex */

#ifdef __cplusplus
extern "C" {
#endif

pPList V_edges2(pVertex v)
{
  int i ;
  pPList elist = PList_new();

  for(i=0; i<V_numEdges(v); i++)
    PList_append(elist,V_edge(v,i));

  return elist ;    
}

#ifdef __cplusplus
}
#endif


