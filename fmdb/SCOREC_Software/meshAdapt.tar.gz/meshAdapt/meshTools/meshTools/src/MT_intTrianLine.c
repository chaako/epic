/*
Intersect triangle with line segment
Can return up to 8 intersections
see MT_intTrianLine2 (case when l is a side of t)
USE LEVEL=2 FOR COMPLETE CHECK !
*/

#include "MeshTools.h"

void MT_intTrianLine(
 double t_xyz[3][3],
 double l_xyz[2][3],
 double tol,
 int level,
 int *int_nbr,
 double int_xyz[8][3]
)

{

 double tvec1[3];
 double tvec2[3];
 double tlvec0[3];
 double tlvec1[3];
 double vol0;
 double vol1;
 int side;
 double side_vec[3];
 double vols[3];
 int sign;
 double lvec[3];
 double normal[3];
 double den;
 double s;
 int i;
 double int_xyz2[4][3]; 
 double tlvec2[3];
 double tnormal[3];
 double tnormal_norm2;
 double tnormal0[3];
 double tnormal0_norm2;
 double vol;
 double tnormal1[3];
 double tnormal1_norm2;
 int flag;
 int count;
 int j;
 double L_XYZ[2][3];
 int int_nbr2;
 double vec[3];
 double norm2;
 double min_norm2;
 double dotProd_p;
 double vec0[3];
 double vec1[3];
 int int_ind2;

 diffVt(t_xyz[1],t_xyz[0],tvec1);
 diffVt(t_xyz[2],t_xyz[0],tvec2);
 diffVt(l_xyz[0],t_xyz[0],tlvec0);
 diffVt(l_xyz[1],t_xyz[0],tlvec1);

 crossProd(tvec1,tvec2,tnormal);
 tnormal_norm2= dotProd(tnormal,tnormal);
 vol0= dotProd(tnormal,tlvec0);
 vol1= dotProd(tnormal,tlvec1);

 if ( vol0*vol0 <= tol*tol*tnormal_norm2 &&
      vol1*vol1 <= tol*tol*tnormal_norm2 ) {

    /*
    Distances from both ends of l to t's plane < tol
    */
 
    /*
    Triangle and line segment coplanar
    Call planar case routine
    */

    MT_intTrianLine2(t_xyz,l_xyz,tol,level,int_nbr,int_xyz);
    return;
 }

 if ( vol0*vol1 > 0.0 &&
    !(vol0*vol0 <= tol*tol*tnormal_norm2) &&
    !(vol1*vol1 <= tol*tol*tnormal_norm2) ) {

    /*
    l on 1 side of triangle
    Neither end 0 of l or end 1 of l within tol of t's plane
    */

    /*
    Line segment is on 1 side of triangle
    No intersection
    */

    *int_nbr= 0;
    return;
 }

 /*
 Go through situtation
 */

 *int_nbr= 0;

 /*
 Initialize to end 0 of l under end 1 of l
 when looking at plane's triangle
 */

 flag= 1;
 if ( vol0 == 0.0 ) {
    if ( vol1 < 0.0 ) {
       flag= 0;
    }
 }
 else if ( vol0 < 0.0 ) {
    if ( vol1 < 0.0 ) {
       if ( (-vol0) < (-vol1) ) {
          flag= 0;
       }
    }
 }
 else if ( vol0 > 0.0 ) {
    if ( vol1 > 0.0 ) {
       if ( vol0 > vol1 ) {
          flag= 0;
       }
    }
    if ( vol1 == 0.0 ) {
       flag= 0;
    }
    if ( vol1 < 0.0 ) {
       flag= 0;
    }
 }

 count= 0;
 for ( side= 0 ; side< 3 ; side++ ) {
    for ( j= 0 ; j< 3 ; j++ )
     L_XYZ[0][j]= t_xyz[side][j];
    for ( j= 0 ; j< 3 ; j++ )
     L_XYZ[1][j]= t_xyz[(side+1)%3][j];
    diffVt(L_XYZ[1],L_XYZ[0],side_vec);

    diffVt(l_xyz[0],L_XYZ[0],tlvec0);
    crossProd(side_vec,tlvec0,tnormal0);
    tnormal0_norm2= dotProd(tnormal0,tnormal0);
    diffVt(l_xyz[1],L_XYZ[0],tlvec1);
    crossProd(side_vec,tlvec1,tnormal1);
    tnormal1_norm2= dotProd(tnormal1,tnormal1);

    vol0= dotProd(tnormal0,tlvec1);
    vol1= dotProd(tnormal1,tlvec0);
    if ( vol0*vol0 <= tol*tol*tnormal0_norm2 ||
         vol1*vol1 <= tol*tol*tnormal1_norm2 ) {

       /*
       End 0 of l is within tol of opposite face's plane
       or
       End 1 of l is within tol of opposite face's plane
       */

       /*
       t's side and l coplanar
       */

       count++;

       MT_intLineLine(L_XYZ,l_xyz,tol,level,&int_nbr2,int_xyz2);
       for ( int_ind2= 0 ; int_ind2< int_nbr2 ; int_ind2++ ) {
          for ( j= 0 ; j< 3 ; j++ )
           int_xyz[*int_nbr][j]= int_xyz2[int_ind2][j];
          (*int_nbr)++;
       }
       continue;
    }

    /*
    t's side and l not coplanar
    */

    vol= vol0;
    vol= -vol1;
    if ( (flag == 1 && vol <= 0.0) ||
         (flag == 0 && vol >= 0.0) ) {

       /*
       Line passes through away from triangle
       No intersection
       */

       *int_nbr= 0;
       return;
    }
 }

 if ( count > 0 ) {

    /*
    Should be all set !
    */

    return;
 }

 /*
 We have general case intersection
 just have to figure out where
 */

 *int_nbr= 1;

 crossProd(tvec1,tvec2,normal);
 diffVt(l_xyz[1],l_xyz[0],lvec);
 den= dotProd(lvec,normal);
 diffVt(l_xyz[0],t_xyz[0],tlvec0);
 s= -dotProd(tlvec0,normal) / den;

 for ( i= 0 ; i< 3 ; i++ )
  int_xyz[0][i]= l_xyz[0][i]+s*lvec[i];

}
