/*--------------------------------------------------------------------------
   Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project  : Mesh Tools
   Author(s): K. Karamete
   Creation : June 1999
   Function : checks if a given element is near flat or negative volume
---------------------------------------------------------------------------*/
#include "MeshTools.h"
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif

int XYZ_checkFlat(dArray *xyz) 
{
double tol;
  tol=M_getTolerance();	
  	
  return(XYZ_checkFlatTet(xyz,tol));
}

#ifdef __cplusplus
}
#endif


