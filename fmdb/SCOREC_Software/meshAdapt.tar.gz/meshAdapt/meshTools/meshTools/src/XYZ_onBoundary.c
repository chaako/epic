/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Optimization
  Author(s) : Kaan, J. Wan
  Creation  : July 99
  Modifi.   :
  Function  : Find out the lowest-level containing entity of a point.
	      If the point (vxyz) in on the boundary of the entity, 
              return the boundary entity; if the point is inside the 
   	      entity; if the point is inside the entity, return the
   	      entity; otherwise, return 0(nil)
 
-------------------------------------------------------------------------*/

#include "MeshTools.h"
#include "oldFMDB.h"
#include <math.h>


pEntity XYZ_onBoundary (double vxyz[3],pEntity entity, double tol)
{
  pPList vlist, elist, flist;
  int i,j,num, orient;
  double v[3], x[2][3];
  pRegion region;
  pFace face;
  pEdge edge;
  pVertex vertex;
  double xyz[4][3],xpro[3],snorm, d, normal[3];
  
  switch(EN_type(entity)){
    
  case Tface:
    face =(pFace) entity;

   /* The function checks if the point is within the face before going to 
      check the boundary. If the point is outside the face, return 0*/

    vlist=F_vertices(face,1);
    for(j=0;j<3;++j)
      V_coord(PList_item(vlist,j),xyz[j]);
    P_projOnTriPlane(xyz,vxyz,xpro,normal,&snorm);
    
    /* if the point is judgeed too far away the triangle plane, return 0 */
    if (fabs(snorm)>tol) {
      PList_delete (vlist);
      return (pEntity) 0;
    }

    for (i=0; i<3; i++) {
      edge=F_edge(face,i);
      orient=F_edgeDir(face,i);
      V_coord(E_vertex(edge,1-orient),x[0]);
      V_coord(E_vertex(edge,orient),x[1]);
      d=P_distToLine(xpro,x[0],x[1],normal);
      
      /* if the point is outside the face, return 0 */
      if(d < -(tol*tol)) {
	PList_delete (vlist);
	return (pEntity) 0;
      }
    }

    /* First check if the point is on a vertex */
    for(i=0;i<PList_size(vlist);++i){
      vertex=PList_item(vlist,i);
      V_coord(vertex,xyz[i]);
      diffVt(xyz[i],vxyz,v);
      if(dotProd(v,v)<tol*tol){
	PList_delete(vlist);
	return (pEntity)vertex;
      }
    }
    PList_delete(vlist);
    
    /* Then check if the point is on an edge */
    num =F_numEdges (face);
    for (i=0; i<num; ++i) {
      edge =F_edge (face, i);
      for (j=0; j<2; j++) {
	vertex =E_vertex (edge, j);
	V_coord (vertex, xyz[j]);
      }
      d =P_distToLine (vxyz, xyz[0], xyz[1],0);
      if(d<tol*tol)
	return (pEntity)edge;
    }
    
    /* When the point is inside the face, return the face */
    return (pEntity)face;
    
  case Tregion:
    region =(pRegion)entity;

    /* The function checks if the point is within the region before going
       to check the boundary. If the point is outside the region, return 0*/
    for (i=0; i<4; i++) {
      face=R_face(region,i);
      orient=R_faceDir(region,i);
      vlist=F_vertices(face,!orient);
      for(j=0;j<3;++j)
	V_coord(PList_item(vlist,j),xyz[j]);
      PList_delete(vlist);
      d=P_distToPlane (vxyz, xyz[0],xyz[1],xyz[2],&snorm);
      
      /* if the point is outside the region, return 0 */
      if(d<-tol*sqrt(snorm))
	return (pEntity) 0;
    }

    /*  First check if the point is on a vertex */
    vlist=R_vertices(region,1); 
    for(i=0;i<PList_size(vlist);++i){
      vertex=PList_item(vlist,i);
      V_coord(vertex,xyz[i]);
      diffVt(xyz[i],vxyz,v);
      if(dotProd(v,v)<tol*tol){
	PList_delete(vlist);
	return (pEntity)vertex;
      }
    }
    PList_delete (vlist);
    
    /* Then check if the point is on an edge */
    elist=R_edges (region,1);
    for (i=0; i<PList_size (elist); ++i) {
      edge =PList_item (elist, i);
      for (j=0; j<2; j++) {
	vertex =E_vertex (edge, j);
	V_coord (vertex, xyz[j]);
      }
      d =P_distToLine (vxyz, xyz[0], xyz[1],0);

      if(d<tol*tol){
	PList_delete(elist);
	return (pEntity)edge;
      } 
    }
    PList_delete(elist);

    /* Thirdly check if the point is in a face */ 
    num =R_numFaces (region);
    for (i=0; i<num; ++i) {
      face =R_face (region, i);
      vlist =F_vertices (face,1);
      for (j=0; j<PList_size (vlist); ++j) {
	vertex =PList_item (vlist, j);
	V_coord (vertex, xyz[j]);
      }
      PList_delete (vlist);
      d =P_distToPlane (vxyz, xyz[0], xyz[1], xyz[2], &snorm);
      if(d*d<tol*tol*snorm)
	return (pEntity)face;
    }
    
    /* When the point is inside the region, return it */
    return((pEntity)entity);
  }
}
