#include "oldFMDB.h"

#ifdef __cplusplus
extern "C" {
#endif

pPList R_verticesLeft(pRegion region) {
  pPList llist, list=R_vertices(region,1);
  static int mymap[4] = {0,2,1,3};
  int i ;

  if( R_numFaces(region) == 4 ) {
    llist = PList_new();
    for(i=0; i < 4; i++)     
      PList_append(llist,PList_item(list,mymap[i]));
    PList_delete(list);
    return llist;
  } else
    return list ;
}

#ifdef __cplusplus
}
#endif
