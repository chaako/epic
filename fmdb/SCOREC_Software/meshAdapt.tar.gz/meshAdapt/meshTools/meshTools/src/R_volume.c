#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------------------------------------------------------
  NOTE: This will return the volume of the linear tet
----------------------------------------------------------------------------*/
double R_volume(pRegion rgn)
{
  double xyz[10][3] ;

  /* get the vertices coordinates */
  R_coord(rgn,xyz) ;

  return XYZ_volume(xyz) ;
}

#ifdef __cplusplus
}
#endif

