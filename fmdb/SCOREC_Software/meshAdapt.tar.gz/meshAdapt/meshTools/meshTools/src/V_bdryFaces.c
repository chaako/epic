/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Rao Garimella
  Creation  : May 96
  Modifi.   :
  Function  : Get mesh faces of vertex that are classified on the boundary
-------------------------------------------------------------------------*/
#include "oldFMDB.h"
#include "modeler.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

pPList V_bdryFaces(pVertex v) {
  int i, j, ne = V_numEdges(v), nf;
  pFace face;
  pEdge edge;
  pPList vflist = 0;
  void *temp = 0;
  int mkid = MT_getMarkID();

  for (i = 0; i < ne; i++) {

    edge = V_edge(v, i);
    if (E_whatInType(edge) == Gregion)
      continue;

    nf = E_numFaces(edge);
    for (j = 0; j < nf; j++) {
      face = E_face(edge, j);

      if (F_whatInType(face) == Gface && !MT_isMarked(face,mkid)) {
	if (!vflist)
	  vflist = PList_new();
	PList_append(vflist, face);
	MT_setMark(face,mkid);
      }
    }

  }

  if (vflist) 
    MT_unMarkList(vflist,mkid);

  MT_freeMarkID(mkid);

  return vflist;
}

#ifdef __cplusplus
}
#endif


