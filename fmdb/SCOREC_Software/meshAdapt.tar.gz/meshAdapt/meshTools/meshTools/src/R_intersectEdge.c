/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Tools
  Author(s) : J. Wan
  Creation  : August, 1999
  Function  :
              Compute the intersection between an edge and a region. 
	      If there exists intersection, return 1 else 0. The 
	      details of intersection are returned via IntersectionData.
-------------------------------------------------------------------------*/

#include "MeshTools.h"
#include "oldFMDB.h"
#include "Defines.h"
#include <math.h>

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
#endif

/* checks if the vertex is within the region;
   If the vertex is inside the region, return 1 else 0*/
int IntXYZ_insideRegion (double int_xyz[3], pRegion reg, double tol) 
{
  pPList vlist;
  int i,j, orient;
  pFace face;
  double xyz[4][3], snorm, d;

  for (i=0; i<4; i++) {
    face=R_face(reg,i);
    orient=R_faceDir(reg,i);
    vlist=F_vertices(face,!orient);
    for(j=0;j<3;++j)
      V_coord(PList_item(vlist,j),xyz[j]);
    PList_delete(vlist);
    d=P_distToPlane (int_xyz, xyz[0],xyz[1],xyz[2],&snorm);
    
    /* if the point is outside the region, return 0 */
    if(d<=0)
      return 0;
  }
  return 1;
}

void RE_closureControlSub10 (pEntity int_Ent1[], pEntity int_Ent2[], IntersectionData *idata, pEdge edge, pEntity thisEnt)
{
  int i, num_tmp=0;

  num_tmp =0;
  for (i=0; i<2; i++) {
    if (EN_type (int_Ent2[i])==Tvertex)
      int_Ent1[i] =thisEnt;
    else num_tmp ++;
  }
  if (num_tmp==2)
    PList_append (idata->boundedEntList, thisEnt);
}

int R_intersectEdge (pRegion reg, int ClosureFlag1, pEdge edge, int ClosureFlag2, IntersectionData *idata)
{
  double int_xyz[2][3], tol, tol2;
  int i, j, CaseID, num_int, num_tmp, found_face;
  pVertex vertex;
  pEdge tmp_edge;
  pFace face;
  int NumExistingIntPts;
  struct IntDescription *thisDescription;
  pEntity int_Ent1[2], int_Ent2[2];


  /* Initialize */
  tol =M_getTolerance();
  tol2 =tol*tol;

  /* Record the procedure: 
     1) if the routine is called independently, NumExistingIntPts=0
     2) if the routine is called embeddedly, NumExistingIntPts may Nonzero */
  NumExistingIntPts =idata->nbr;

  /* Compute the intersections between the faces of reg and the edge */
  /* Up to two intersection bounding pts may exist */
  for (i=0; i<4; i++) {
    face =R_face (reg, i);
    F_intersectEdge (face, 1, edge, 1, idata);
    if (idata->nbr==2) break;
  }


  /* Check if there is another bounding pt if not two have been found */
  CaseID =idata->nbr;
  switch (CaseID) {
  case 0:    /* the edge is inside or outside the region */ 
    vertex =E_vertex (edge, 0);
    V_coord (vertex, int_xyz[0]);
    if (IntXYZ_insideRegion (int_xyz[0], reg, tol2)) {
      M_updateIntersectionData (idata, reg, vertex, int_xyz[0], tol2);
      vertex =E_vertex (edge, 1);
      V_coord (vertex, int_xyz[0]);
      M_updateIntersectionData (idata, reg, vertex, int_xyz[0], tol2);

    }
    else return 0;  /* No intersection */
    break;

  case 1:    /* look for another intersection bounding pt */
    for (i=0; i<2; i++) {
      vertex =E_vertex (edge, i);
      V_coord (vertex, int_xyz[0]);
      if (xyz_inIntersectionData (idata, int_xyz[0], tol2)==0) {
	/* This vertex is not in intersectionData */
	if (IntXYZ_insideRegion (int_xyz[0], reg, tol2)) {
	  M_updateIntersectionData (idata, reg, vertex, int_xyz[0], tol2);
	  break;   /* So far, two bounding pts have been found */
	}
      }
    }
    break;
  }

  /* When it is called as a subroutine of another complex intersection routine,
     do not apply closure control */
  if (NumExistingIntPts) return 1;

  /* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  /* Start to implement closure control and append bounded ents */
  /* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

  thisDescription =idata->Description;
  
  /* First retrieve the intersection bounding points into array */
  for (i=0; i<idata->nbr; i++) {
    int_Ent1[i] =thisDescription->IntEnt1;
    int_Ent2[i] =thisDescription->IntEnt2;
    for (j=0; j<3; j++)
      int_xyz[i][j] =thisDescription->xyz[j];
    thisDescription =thisDescription->next;
  }
  num_int =idata->nbr;
 
  /* Initialize the intersectionData */
  M_intersectionData_delete (*idata);
  *idata =M_intersectionData_new ();



  switch (CaseID) {
  case 0:    /* Edge is inside the region */
    if (ClosureFlag2) {
      PList_append (idata->boundedEntList, edge);
    } else {            /* ClosureFlag2 =0 */
      int_Ent2[0] =edge;
      int_Ent2[1] =edge;
    }
    for (i=0; i<2; i++)
      M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);
    break;

  case 1:    /* One bounding pt on boundary of reg, another one may exist or not */
    switch (num_int) {
    case 1:   /* Total one bounding pt, it is on the boundary of the ents */
      if (ClosureFlag1 && ClosureFlag2)
	M_updateIntersectionData (idata, int_Ent1[0], int_Ent2[0], int_xyz[0], -1);
      else
	return 0;
      break;
    case 2:   /* Total two bounding pts, one on boundary of reg, one inside */
      if (ClosureFlag1) {
	if (ClosureFlag2) {   /* Full closure case */
	  if (EN_type (int_Ent2[0])==Tvertex)
	    PList_append (idata->boundedEntList, edge);

	} else {              /* half closure case, ClosureFlag1 =1, ClosureFlag2 =0 */
	  int_Ent2[0] =edge;
	  int_Ent2[1] =edge;
	}
      }

      else {                  /* ClosureFlag1 =0 */
	if (ClosureFlag2) {   /* half closure case, ClosureFlag1 =0, ClosureFlag2 =1 */
	  int_Ent1[0] =reg;
	  int_Ent2[0] =edge;

	} else {              /* Non closure case */
	  int_Ent1[0] =reg;
	  int_Ent2[0] =edge;
	  int_Ent2[1] =edge;
	}
      }

      for (i=0; i<2; i++)
	M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);   
      break;
    }
    break;

  case 2:   /* Two bounding pts are on boundary of reg */

    if (ClosureFlag1) {     /* ClosureFlag1 =1 */

      if (ClosureFlag2) {   /* Full closure case */
	/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

	switch (EN_type (int_Ent1[0])) {

	case Tvertex:   /* 1st pt located on a vertex */

	  switch (EN_type (int_Ent1[1])) {
	    
	  case Tvertex:   /* 1st pt on a vertex, 2nd pt on a vertex */
	    /* Edge is coincided with a whole edge of reg */
	    PList_append (idata->boundedEntList, M_boundedEdgeOnRegion (reg, int_Ent1[0], int_Ent1[1]));
	    break;

	  case Tedge:     /* 1st pt on a vertex, 2nd pt on an edge */
	    /* to check if Edge is coincided with a part of an edge */
	    if (int_Ent1[0]!=E_vertex (int_Ent1[1],0) && int_Ent1[0]!=E_vertex (int_Ent1[1],1)) {

	      /* Edge lies on a face of reg */

	      /* to locate the face */
	      num_tmp =0;
	      found_face =0;
	      
	      for (i=0; i<4 && num_tmp<2 && found_face==0; i++) {
		face =R_face (reg, i);
		
		/* First search for the faces contain the edge */
		for (j=0; j<3; j++) {
		  if (int_Ent1[1]==F_edge (face, j)) {
		    /* The face uses the edge */
		    num_tmp ++;
		    
		    /* Then check if the face also contains the vertex */
		    if (int_Ent1[0]==F_edOpVt(face, int_Ent1[1])) {
		      found_face =1;
		      PList_append (idata->boundedEntList, face);
		      break;
		    }
		  }
		}
		
	      }
	    }
	    break;
	    
	  case Tface:   /* 1st on a vertex, 2nd pt on a face */
	    /* to find if reg is bounded*/
	    if (int_Ent1[1] ==R_vtOpFc (reg, int_Ent1[0]))
		PList_append (idata->boundedEntList, reg);
	    break;

	  }  /* end of switch */
	  break;

	case Tedge:   /* 1st pt located on an edge */
	  
	  switch (EN_type (int_Ent1[1])) {
	    
	  case Tvertex:     /* 1st pt on an edge, 2nd pt on a vertex */
	    /* to check if Edge is coincided with a part of an edge */
	    if (int_Ent1[1]!=E_vertex (int_Ent1[0],0) && int_Ent1[1]!=E_vertex (int_Ent1[0],1)) {

	      /* Edge lies on a face */

	      /* to locate the face */
	      num_tmp =0;
	      found_face =0;
	      
	      for (i=0; i<4 && num_tmp<2 && found_face==0; i++) {
		face =R_face (reg, i);

		/* First search for the faces contain the edge */
		for (j=0; j<3; j++) {
		  if (int_Ent1[0]==F_edge (face, j)) {

		    /* The face contain the edge */
		    num_tmp ++;
		    
		    /* Then check if the face also contains the vertex */
		    if (int_Ent1[1]==F_edOpVt(face, int_Ent1[0])) {
		      found_face =1;
		      PList_append (idata->boundedEntList, face);
		      break;
		    }
		  }
		}
	      } 
	    }
	    break;

	  case Tedge:    /* 1st pt on an edge, 2nd pt on an edge */
	    /* to check if Edge lies on an edge of reg */
	    if (int_Ent1[0]!=int_Ent1[1]) {

	      /* Edge crosses a face of reg or reg itself*/
	      found_face =0;
	      for (i=0; i<4 && found_face==0; i++) {
		num_tmp =0;
		face =R_face (reg, i);
		for (j=0; j<3; j++) {
		  tmp_edge =F_edge (face, j);
		  if (tmp_edge==int_Ent1[0] || tmp_edge==int_Ent1[1])
		    num_tmp ++;

		  /* check if Edge lies in a face */
		  if (num_tmp==2) {
		    found_face =1;
		    PList_append (idata->boundedEntList, face);
		    break;
		  }
		}
	      }
	      
	      if (found_face==0) /* Edge does lies in a face */
		PList_append (idata->boundedEntList, reg);
	    }
	    break;
	    
	  case Tface:   /* 1st pt on an edge, 2nd pt in a face */
	    /* Check if the face contains the edge (containing 1st pt) */
	    found_face =0;
	    for (i=0; i<3; i++)
	      if (int_Ent1[0]==F_edge (int_Ent1[1],i)) {
		found_face =1;
		break;
	      }

	    if (found_face==0)
	      PList_append (idata->boundedEntList, reg);
	    break;

	  }   /* end of switch */
	  break;
	  
	case Tface:   /* 1st pt located on a face */
	  
	  switch (EN_type (int_Ent1[1])) {
	  case Tvertex:     /* 1st pt in a face, 2nd pt on a vertex */
	    if (int_Ent1[1]==R_fcOpVt (reg, int_Ent1[0]))
	      PList_append (idata->boundedEntList, reg);
	    break;
	    
	  case Tedge:       /* 1st pt in a face, 2nd pt on an edge */

	    /* check if Edge lies in a face */
	    found_face =0;
	    for (i=0; i<3; i++) {
	      if (int_Ent1[1]==F_edge (int_Ent1[0],i)) {
		found_face =1;
		break;
	      }
	    }	      

	    if (found_face==0)
	      PList_append (idata->boundedEntList, reg);
	    break;
	    
	  case Tface:       /* 1st pt in a face, 2nd pt in a face */
	    if (int_Ent1[0]!=int_Ent1[1])
	      PList_append (idata->boundedEntList, reg);
	    break;

	  }  /* end of switch */
	  break;
	}
	
	if (EN_type (int_Ent2[0])==Tvertex && EN_type (int_Ent2[1])==Tvertex)
	  PList_append (idata->boundedEntList, edge);
	
      } else {              /* half closure case, ClosureFlag1 =1, ClosureFlag2 =0 */
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	switch (EN_type (int_Ent1[0])) {

	case Tvertex:   /* 1st pt located on a vertex */

	  switch (EN_type (int_Ent1[1])) {
	    
	  case Tvertex:   /* 1st pt on a vertex, 2nd pt on a vertex */
	    /* Edge is coincided with a whole edge of reg */
	    tmp_edge =M_boundedEdgeOnRegion (reg, (pVertex)int_Ent1[0], int_Ent1[1]);

	    RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, tmp_edge);

	    break;

	  case Tedge:     /* 1st pt on a vertex, 2nd pt on an edge */
	    /* to check if Edge is coincided with a part of an edge */
	    if (int_Ent1[0]!=E_vertex (int_Ent1[1],0) && int_Ent1[0]!=E_vertex (int_Ent1[1],1)) {

	      /* Edge lies on a face of reg */

	      /* to locate the face */
	      num_tmp =0;
	      found_face =0;
	      
	      for (i=0; i<4 && num_tmp<2 && found_face==0; i++) {
		face =R_face (reg, i);
		
		/* First search for the faces contain the edge */
		for (j=0; j<3; j++) {
		  if (int_Ent1[1]==F_edge (face, j)) {
		    /* The face uses the edge */
		    num_tmp ++;
		    
		    /* Then check if the face also contains the vertex */
		    if (int_Ent1[0]==F_edOpVt(face, int_Ent1[1])) {
		      found_face =1;
		      RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, face);	
		      break;
		    }
		  }
		}
	      }

	    } else {  /* Edge is partially coincided with a edge */
	      if (EN_type (int_Ent2[0])==Tvertex)
		int_Ent1[0] =int_Ent1[1];
	    }
	    break;
	    
	  case Tface:   /* 1st on a vertex, 2nd pt on a face */
	    /* to find if reg is bounded*/
	    if (int_Ent1[1] ==R_vtOpFc (reg, int_Ent1[0]))
	      RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, reg);	
	    else 	      
	      if (EN_type (int_Ent2[0])==Tvertex)
		int_Ent1[0] =int_Ent1[1];
	    break;

	  }  /* end of switch */
	  break;

	case Tedge:   /* 1st pt located on an edge */
	  
	  switch (EN_type (int_Ent1[1])) {
	    
	  case Tvertex:     /* 1st pt on an edge, 2nd pt on a vertex */
	    /* to check if Edge is coincided with a part of an edge */
	    if (int_Ent1[1]!=E_vertex (int_Ent1[0],0) && int_Ent1[1]!=E_vertex (int_Ent1[0],1)) {

	      /* Edge lies on a face */

	      /* to locate the face */
	      num_tmp =0;
	      found_face =0;
	      
	      for (i=0; i<4 && num_tmp<2 && found_face==0; i++) {
		face =R_face (reg, i);

		/* First search for the faces contain the edge */
		for (j=0; j<3; j++) {
		  if (int_Ent1[0]==F_edge (face, j)) {

		    /* The face contain the edge */
		    num_tmp ++;
		    
		    /* Then check if the face also contains the vertex */
		    if (int_Ent1[1]==F_edOpVt(face, int_Ent1[0])) {
		      found_face =1;
		      RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, face);	
		      break;
		    }
		  }
		}
	      } 
	    } else {  /* Edge is partially coincided with a edge */
	      if (EN_type (int_Ent2[1])==Tvertex)
		int_Ent1[1] =int_Ent1[0];
	    }
	    break;

	  case Tedge:    /* 1st pt on an edge, 2nd pt on an edge */
	    /* to check if Edge lies on an edge of reg */
	    if (int_Ent1[0]!=int_Ent1[1]) {

	      /* Edge crosses a face of reg or reg itself*/
	      found_face =0;
	      for (i=0; i<4 && found_face==0; i++) {
		num_tmp =0;
		face =R_face (reg, i);
		for (j=0; j<3; j++) {
		  tmp_edge =F_edge (face, j);
		  if (tmp_edge==int_Ent1[0] || tmp_edge==int_Ent1[1])
		    num_tmp ++;

		  /* check if Edge lies in a face */
		  if (num_tmp==2) {
		    found_face =1;
		    RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, face);	
		    break;
		  }
		}
	      }
	      
	      if (found_face==0) /* Edge does lies in a face */
		RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, reg);	

	    } 

	    break;
	    
	  case Tface:   /* 1st pt on an edge, 2nd pt in a face */
	    /* Check if the face contains the edge (containing 1st pt) */
	    found_face =0;
	    for (i=0; i<3; i++)
	      if (int_Ent1[0]==F_edge (int_Ent1[1],i)) {
		found_face =1;
		if (EN_type (int_Ent2[0])==Tvertex)
		  int_Ent1[0] =int_Ent1[1];

		break;
	      }

	    if (found_face==0)
	      RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, reg);	

	    break;

	  }   /* end of switch */
	  break;
	  
	case Tface:   /* 1st pt located on a face */
	  
	  switch (EN_type (int_Ent1[1])) {
	  case Tvertex:     /* 1st pt in a face, 2nd pt on a vertex */
	    if (int_Ent1[1]==R_fcOpVt (reg, int_Ent1[0]))
	      RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, reg);	
	    else {
	      if (EN_type (int_Ent2[1])==Tvertex)
		int_Ent1[1] =int_Ent1[0];
	    }
	    break;
	    
	  case Tedge:       /* 1st pt in a face, 2nd pt on an edge */

	    /* check if Edge lies in a face */
	    found_face =0;
	    for (i=0; i<3; i++) {
	      if (int_Ent1[1]==F_edge (int_Ent1[0],i)) {
		found_face =1;
		if (EN_type (int_Ent2[1])==Tvertex)
		  int_Ent1[1] =int_Ent1[0];
		break;
	      }
	    }	      

	    if (found_face==0)
	      RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, reg);	
	    break;
	    
	  case Tface:       /* 1st pt in a face, 2nd pt in a face */
	    if (int_Ent1[0]!=int_Ent1[1])
	      RE_closureControlSub10 (int_Ent1, int_Ent2, idata, edge, reg);
	    break;

	  }  /* end of switch */
	  break;
	}
	int_Ent2[0] =edge;
	int_Ent2[1] =edge;
      }

    }   /* end of ClosureFlag1 =1 */

    else {                  /* ClosureFlag1 =0 */

      /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
      switch (EN_type (int_Ent1[0])) {
	
      case Tvertex:   /* 1st pt located on a vertex */
	
	switch (EN_type (int_Ent1[1])) {
	  
	case Tvertex:   /* 1st pt on a vertex, 2nd pt on a vertex */
	case Tedge:     /* 1st pt on a vertex, 2nd pt on an edge */
	  return 0;
	  
	case Tface:   /* 1st on a vertex, 2nd pt on a face */
	  /* to find if reg is bounded*/
	  if (int_Ent1[1] !=R_vtOpFc (reg, int_Ent1[0]))
	    return 0;
	  break;
	  
	}  /* end of switch */
	break;

      case Tedge:   /* 1st pt located on an edge */
	  
	switch (EN_type (int_Ent1[1])) {
	  
	case Tvertex:     /* 1st pt on an edge, 2nd pt on a vertex */
	  return 0;

	case Tedge:    /* 1st pt on an edge, 2nd pt on an edge */
	  /* to check if Edge lies on an edge of reg */
	  if (int_Ent1[0]!=int_Ent1[1]) {
	    
	    /* Edge crosses a face of reg or reg itself*/
	    for (i=0; i<4; i++) {
	      num_tmp =0;
	      face =R_face (reg, i);
	      for (j=0; j<3; j++) {
		tmp_edge =F_edge (face, j);
		if (tmp_edge==int_Ent1[0] || tmp_edge==int_Ent1[1])
		  num_tmp ++;

		/* check if Edge lies in a face */
		if (num_tmp==2) return 0;
	      }
	    }
	  }
	  else return 0;

	  break;
	  
	case Tface:   /* 1st pt on an edge, 2nd pt in a face */
	  /* Check if the face contains the edge (containing 1st pt) */
	  found_face =0;
	  for (i=0; i<3; i++)
	    if (int_Ent1[0]==F_edge (int_Ent1[1],i)) 
	      return 0;
	  
	  break;
	  
	}   /* end of switch */
	break;
	  
      case Tface:   /* 1st pt located on a face */
	
	switch (EN_type (int_Ent1[1])) {
	case Tvertex:     /* 1st pt in a face, 2nd pt on a vertex */
	  if (int_Ent1[1]!=R_fcOpVt (reg, int_Ent1[0]))
	    return 0;
	  
	  break;
	    
	case Tedge:       /* 1st pt in a face, 2nd pt on an edge */
	  
	  /* check if Edge lies in a face */
	  for (i=0; i<3; i++)
	    if (int_Ent1[1]==F_edge (int_Ent1[0],i))
	      return 0;
	    
	  break;
	    
	case Tface:       /* 1st pt in a face, 2nd pt in a face */
	  if (int_Ent1[0]==int_Ent1[1])
	    return 0;
	  break;

	}  /* end of switch */
	break;
      }
    }
    
    for (i=0; i<2; i++)
      M_updateIntersectionData (idata, int_Ent1[i], int_Ent2[i], int_xyz[i], -1);
  }

  /* Calculate the dim of the intersection */
  if (idata->nbr) {
    idata->dim =idata->nbr-1;
    return 1;
  }
  return 0;
}


















