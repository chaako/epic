/* Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1991, RPI-SCOREC

   Project: OCTREE

   Authors/Dates:
   Pascal J. Frey / November 1994

   Functionality:
   append list2 to list1, then delete the second list
   (check for duplicate, if flag set to 1)

   Argument Variable(s):
   Name  Type In/Out Description
 |------|----|------|-----------------------------------------------------|
*/
#include <stdio.h>
#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

void PList_app2Lst(pPList *list1,pPList list2,int checkDuplicate)
{
  void *temp,*data ;

  if ( *list1==NULL ) {
    *list1 = PList_new() ;
    checkDuplicate = 0 ;
  }

  temp = 0 ;
  while (data = PList_next(list2,&temp)) {
    if (checkDuplicate) {
      PList_appUnique(*list1,data) ;
    }
    else
      PList_append(*list1,data) ;
  }
}
 
#ifdef __cplusplus
}
#endif

