#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif


/*---------------------------------------------------------------------------
  returns the cosine of smallest and largest dihedral angle in a tetra.
---------------------------------------------------------------------------*/
int R_smlDhdTrg(pRegion rgn,double target,double *sml)
{
  double  xyz[4][3] ;

  /* get the vertices coordinates */
  R_coord(rgn,xyz) ;
  /* get the smallest dihedral angle */
  return XYZ_smlDhdTrg(xyz,target,sml) ;
}

#ifdef __cplusplus
}
#endif

