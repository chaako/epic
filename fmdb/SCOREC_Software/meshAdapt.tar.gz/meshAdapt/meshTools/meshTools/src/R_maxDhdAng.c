/* Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project:

   Authors/Dates:
   Rao Garimella, Feb 95

   Functionality:
   Return the maximum dihedral angle of an element (currently works only
   with tetrahedrons)

   Argument Variable(s):
   Name  Type In/Out Description
 |------|----|------|-----------------------------------------------------|
*/
#include <math.h>
#include "oldFMDB.h"
#include "Defines.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

double R_maxDhdAng(pRegion reg) {
  pVertex vert;
  pPoint point;

  double xyz[4][3];
  int i;
  void *temp = 0;
  pPList vlist;

  vlist = R_vertices(reg,1);
  temp = 0; i = 0;
  while (vert = PList_next(vlist,&temp)) {
    V_coord(vert,xyz[i]);
    i++;
  }
  PList_delete(vlist);

  /* worstMax.. returns cos of the dihedral angle normalized [0..1] */  
  return (2.0*worstMaxDhd(xyz)-1);

} /* R_maxDhdAng */

#ifdef __cplusplus
}
#endif
