/*
Determines if a point is in or out of triangle
Point and triangle must be coplanar
*/
/* Rewritten by B. Kaan Karamete July 7 1998. */

#include "MeshTools.h"

#define FALSE 0
#define TRUE  1

int MT_isPtInTrian(
 double tri_xyz[3][3],
 double p_xyz[3],
 double tol
)

{

 int status;
 int side,nn;
 double tvec[3][3];
 double tvec2[3];
 double pvec[3][3];
 double normal[3];
 double area[3];
 double magN,magV;
 
 status= FALSE;

 for ( side= 0 ; side< 3 ; side++ ) {
   diffVt(tri_xyz[(side+1)%3],tri_xyz[side],tvec[side]);
   diffVt(p_xyz,tri_xyz[side],pvec[side]);
 }
 /* use enlarged computation */
   
 diffVt(tri_xyz[2],tri_xyz[0],tvec2);
 crossProd(tvec[1],tvec2,normal);

 magN=vecMag(normal);
 nn=0;
 for(side=0;side<3;side++){
   crossProd(tvec[side],pvec[side],area);
   magV=vecMag(tvec[side]);
   
   if(dotProd(area,normal)< - ( tol * magV * magN)){
     ++nn;
   }
   else
    if( dotProd(area,normal) < 0.0 && dotProd(tvec[side],pvec[side])< 0.0 &&
        vecMag(pvec[side])>tol) {
      ++nn;
    }
   else 
     --nn;
   if(abs(nn)<(side+1)){
     status=FALSE;
     return(status);
   }
 }


 status=TRUE;

 return(status);

}
