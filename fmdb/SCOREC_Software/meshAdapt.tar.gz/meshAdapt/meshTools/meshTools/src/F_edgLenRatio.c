/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Pascal J. Frey
  Creation  : Aug., 95
  Modifi.   : Pascal Frey, Oct. 3, 95
  Function  :
    Return the maximum edge length ratio of a face.
-------------------------------------------------------------------------*/
#include <math.h>
#include "oldFMDB.h"
#include "MeshTools.h"

#ifdef __cplusplus
extern "C"
#endif

double F_edgLenRatio(int nbr_vtx,dArray *xyz) {
  double v[3],d,min_len,max_len;
  int    i,j;

  for (i=0; i<nbr_vtx; i++) {
    j = (i+1)%nbr_vtx;
    v[0]= xyz[i][0]-xyz[j][0];
    v[1]= xyz[i][1]-xyz[j][1];
    v[2]= xyz[i][2]-xyz[j][2];
    d = dotProd(v,v);
    if (!i)
      min_len = max_len = d;
    else {
      if (d<min_len)
	min_len=d;
      if (d>max_len)
	max_len=d;
    }
  }
  return sqrt(max_len/min_len);
}

#ifdef __cplusplus
}
#endif
