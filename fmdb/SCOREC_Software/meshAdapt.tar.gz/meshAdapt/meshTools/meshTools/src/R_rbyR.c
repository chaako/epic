/* Scientific Computation Research Center, RPI, Troy NY
   (C) Copyright 1995, RPI-SCOREC

   Project: 

   Authors/Dates:
   Rao Garimella, Feb 1995

   Functionality:
   Return the ratio of the inscribed to circumscribed radius of a tetrahedron

   Argument Variable(s):
   Name  Type In/Out Description
 |------|----|------|-----------------------------------------------------|
*/

#ifdef __cplusplus
extern "C" {
#endif

#include <math.h>
#include "oldFMDB.h"
#include "Defines.h"
#include "MeshTools.h"


double R_rbyR(pRegion reg) {

  return (3.0*R_inscrRad(reg)/R_circumRad(reg));

} /* R_rbyR */

#ifdef __cplusplus
}
#endif
