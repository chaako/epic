#include "MeshTools.h"

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------------------------------------------------------
  checks if a given region is near flat or negative volume
----------------------------------------------------------------------------*/
int R_checkFlat(pRegion rgn)
{
  double xyz[4][3] ;
  double tol;

  R_coord(rgn,xyz) ;

  tol=M_getTolerance();

  return XYZ_checkFlatTet(xyz,tol) ;
}

#ifdef __cplusplus
}
#endif

