#ifndef __MeshTools
#define __MeshTools

//#include "MSops.h"
#include "MeshEntTools.h"
#include "MeshAdjTools.h"
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif


struct IntDescription {
  double xyz[3];               /* Coordinates of this intersection boundary point */
  pEntity IntEnt1;             /* Lowest-level entity on Ent1 involved in this intersection */
  pEntity IntEnt2;             /* Lowest-level entity on Ent2 involved in this Intersection */
  struct IntDescription *next; /* Pointer to Description for next intersection boundary*/
  struct IntDescription *prev; /* Pointer to Description for previous intersection
                                  boundary. Used for memory management */
}; /* IntDescription; */


typedef struct {
  int dim;                     /* Dimension of the resulted intersected entity */
  int nbr;                     /* Number of the intersection boundary points*/
  struct IntDescription *Description;  /* Descriptions for intersection boundary points */
  pPList boundedEntList;       /* List of the bounded intersected entities */
} IntersectionData;


typedef pPList pPQueue ;

/* error/warning codes */
enum MT_ErrorCode {WARN=3000,ERROR,FATAL,MESSG} ;

/* constraints for mesh modifications */
typedef enum opType {
  SWAP, COLAPS, SPLIT, MOVE, DELETE
} opType;


  /*
    the mesh modifications we currently support 
    ensure to be consistent with what in LocMeshMod.h of templateRefine 
  */
  typedef enum modType{
    ECOLAPS=0, 
    FSWAP, 
    ESWAP, 
    MOTION, 
    RCOLAPS, 
    ESPLIT, 
    R_REFINE,
    F_REFINE,
    E_REFINE,
    RCOLAPS_2, 
    SPLTCLPS,
    LECOLAPS,
    LESWAP,
    TOPGESPLIT,
    RSHAPE 
  } modType;
  
  pPList CB_F_regions(pFace oldFace,pPList newRgns); 
  
  /* callback functions activated by Local mesh modifications */
  typedef void (*CBFunction)(pPList, pPList, void *,modType, pEntity);
  typedef void (*CBFunc_move)(pVertex, double *, void *);

/* the mesh tools error handler */
int  MT_init(char *);
void MT_exit(void);
double getElapsedTime(void);
void MT_ErrorHandler(char *, char *, int );

/*************************************************/
/*  Debugging utilities                          */
/*************************************************/
void M_info(pMesh);
void EN_info(pEntity);
void R_info(pRegion);
void F_info(pFace);
void E_info(pEdge);
void V_info(pVertex);
void PList_printx(pPList);

/*************************************************/
/* MeshTools marking utilities                   */
/*************************************************/
int  MT_getMarkID(void);
void MT_freeMarkID(int markID);
void MT_setMark(pEntity ent, int markID);
void MT_setMarkList(pPList list, int markID);
void MT_unMark(pEntity ent, int markID);
void MT_unMarkList(pPList list, int markID);
int  MT_isMarked(pEntity ent, int markID);

/************************************************/
/* Global Mesh Tolerance computation & retrieve */
/************************************************/
void M_setTolerance (pMesh mesh);
double M_getTolerance ();

/*************************************************/
/* prototypes for PQueue utility functions */
/*************************************************/
pPQueue PQueue_new(void); 
void PQueue_delete(pPQueue); 
void PQueue_reset(pPQueue); 
void PQueue_push(pPQueue, pEntity); 
void PQueue_remItem(pPQueue, pEntity); 
void PQueue_pushUnique(pPQueue, pEntity); 
pEntity PQueue_pop(pPQueue); 
int PQueue_size(pPQueue q); 

/*************************************************/
/* List operators */
/*************************************************/
void PList_app2Lst(pPList *list1,pPList list2,int checkDuplicate) ;
void PList_subCom( pPList *list1, pPList list2) ;
pPList PList_nextN(pPList, void **, int);
pPList PList_subList(pPList, int, int);

/*************************************************/
/* List based operators for attaching and removing data */
/*************************************************/
void ENList_attachDataI(pPList list, char *tag, int i, int check);
void ENList_attachDataP(pPList l, char *tag, void *p, int chkUniq);
void ENList_removeData(pPList list, char *tag);

/*************************************************/
/* Adjacency queries */
/*************************************************/
int EN_inClosure(pEntity, pEntity);


pPList V_edges(pVertex v);
pPList V_bdryFaces(pVertex v);
pPList E_bdryFaces(pEdge e);
pPList V_adjVertices(pVertex v, pGEntity gent);

/*  void edgesToVerts(pEdge edges[3], pVertex verts[3]); */
pPList E_faces1(pEdge ) ;  
/*  void E_reorder(pEdge*, int*, int); */
pFace E_otherSFace(pEdge,pFace);



pEdge facGtOppEdg(pFace face, pVertex vert);
int F_conToFace(pFace , pFace ) ;
pPList F_faces(pFace ) ;
pPList F_elist(pFace,pEdge);

pVertex R_fcOpVt(pRegion rgn, pFace face);
pFace   R_vtOpFc(pRegion ,pVertex ) ;
pEdge R_gtOppEdg(pRegion region, pEdge edge);
pPList R_verticesLeft(pRegion); /* vertices of tet in Left handed system */

/* Get model faces connected to model entity that mesh entity is */
/* classified on. Do this based on mesh info rather than model   */
/* info to account for small feature removal                     */
pPList V_gfaces(pVertex v);
pPList E_gfaces(pEdge e);


/*************************************************/
/* Element quality evaluation, mesh statistics, element coordinates... */
/*************************************************/
int M_checkAdj(pMesh mesh);
int F_regionValid(pFace face);
/* int E_facesConsistent(pEdge edge);  */
/* int F_edgeDir_2(pFace face, pEdge edge); */
int F_partialCon(pFace face);
void M_writeSTS(pMesh mesh, int ntimes, char **timetxt, double *times,
		 char *fname, char *mname);
void M_writeFSTS(pMesh mesh, int ntimes, char **timetxt, double *times,
                 char *fname, char *mname); 
/*
Converts  triangular surface mesh into triangular and quad mesh faces by
merging the best diagonals if possible 
*/

void M_convert2Mixed(pMesh mesh);

/*Converts mixed surface meshes into quad mesh by splitting at the mid point
  of edges; split point is not snapped on the model */

void M_convert2Quad(pMesh mesh);

/* 
edge array of size n and face edge use direction array are reordered 
to comply with the directions 
*/

double E_lengthSq(pEdge edge);
double VV_distance2(pVertex v1, pVertex v2);
double XYZ_distance2(double [3], double [3]);
void R_coord(pRegion rgn,dArray *xyz);
void R_coordLeft(pRegion rgn,dArray *xyz);
void F_coord(pFace face, dArray *xyz);

int V_parOnGEnt(pVertex v, pGEntity g, double *p);

void R_dihedral(pRegion reg, double *small, double *big) ;
int R_bigDhdTrg(pRegion reg, double target, double *big) ;
int R_smlDhdTrg(pRegion reg, double target, double *sml) ;
double R_maxDhdAng(pRegion reg);
double R_minDhdAng(pRegion reg);
void XYZ_dihedral(dArray *xyz, double *small, double *big) ;
void XYZ_dhdAngs(double xyz[4][3], double *cosAngs);
int XYZ_bigDhdTrg(dArray *xyz, double target, double *big) ;
int XYZ_smlDhdTrg(dArray *xyz, double target, double *sml) ;
/* This is more efficient function than XYZ_bigDhdTarget */
int XYZ_isBigDhdBetter(dArray *xyz, double target, double *big);
double worstMinDhd(dArray *xyz);
double worstMaxDhd(dArray *xyz);

int F_angles(pFace face, double *normal, double *cosangs);
int XYZ_FAngles(dArray *xyz, double *normal, double *cosangs);
int F_angle(double xyz[3][3],double *,double *);
void F_normalVector(pFace face, int dir, double* normal);

double R_aspectRatio(pRegion reg) ;
double R_circumRad(pRegion reg) ;
double R_edgLenRatio(pRegion reg) ;
double R_inscrRad(pRegion reg);
double R_rbyR(pRegion reg);
double R_volume(pRegion);
int R_shape(pRegion,double *);

int XYZ_shape(dArray *xyz,double *);
int XYZ_shapeMeasure(dArray *xyz,double *shape);
double XYZ_rbyR(dArray *xyz) ;
double XYZ_rbyR2(dArray *xyz) ;
double XYZ_inscrRad(dArray *xyz) ;
double XYZ_circumRad(dArray *xyz) ;
double XYZ_circumRad2(dArray *xyz) ;
double XYZ_edgLenRatio(dArray *xyz);
double XYZ_edgLenRatio2(dArray *xyz);
double XYZ_aspectRatio(dArray *xyz);
double XYZ_aspectRatio2(dArray *xyz);
double XYZ_distance2(double [3],double [3]);
int XYZ_checkFlat(dArray *xyz);

double F_edgLenRatio(int, dArray *);


double **dMatAlloc(int m, int n);
double **dMatFree(double **);


int E_rgnLocalId(pRegion r, pEdge e); /* local edge mapping for region */

/*************************************************/
/* Entity creation/destruction */
/*************************************************/

pVertex MM_newCopyVP(pMesh mesh, pVertex v);
pEdge   MM_newCopyE(pMesh mesh, pEdge e, pVertex *v0, pVertex *v1);


pPList del_fConRegs (pMesh mesh, pPList delRegs, int preserve);
pPList del_eConFaces (pMesh mesh, pPList delfs, int preserve);

void V_CrtEdges(pMesh OM_mesh,pPList verts,pVertex vert);
pPList del_E_faces(pMesh OM_mesh,pEdge edge);
pPList del_E_regions(pMesh OM_mesh, pEdge edge);
void del_V_Regions(pMesh OM_mesh, pVertex vert, pPList regions, pPList *faces, 
                   pPList *edges, pPList *verts);
void del_F_regions(pMesh OM_mesh, pFace face, pPList flist, 
                     pPList elist, pPList vlist);


/*************************************************/
/* Computational geometry stuff                  */
/*************************************************/
/* checks if the region is valid or not */
int R_checkFlat(pRegion rgn); 

/*checks if the face is valid or not */
int F_checkFlat(pFace, double *);

/* checks the perpendicular distance of each vertex to the opposite plane; 
   valid for tet meshes only. 
*/
int XYZ_checkFlatTet(dArray*, double);

/* checks the perpendicular distance of each vertex to its opposite edge;
valid for tri meshes only 
*/
int XYZ_checkFlatTri(dArray*, double *);

  /* checks the validity of quad elements */ 
int XYZ_checkFlatQuad(dArray*,double *);

/*finds the perpendicular distance of a point to a plane */
double P_distToPlane (double* pxyz, double* v0, double* v1, double* v2, double *snorm);

/*finds perpendicular distance of a point to a line */
double P_distToLine(double *pxyz, double *v0, double *v1, double *normal);

/* locates the entity within which the vertex falls */
int XYZ_locate(double px[3], pEntity* seed, double tol);

/* Find out the lowest-level containing entity of a point.
              If the point (vxyz) in on the boundary of the entity, 
              return the boundary entity; if the point is inside the 
              entity; if the point is inside the entity, return the
              entity; otherwise, return 0(nil) */
pEntity XYZ_onBoundary(double vxyz[3],pEntity entity,double tol);

/* general case - with few restrictions - see code */
void MT_intTrianLine(double t_xyz[3][3], double l_xyz[2][3], double tol,
		   int level, int *int_nbr, double int_xyz[][3]);

/* Coplanar case */
void MT_intTrianLine2(double t_xyz[3][3], double l_xyz[2][3], double tol,
		   int level, int *int_nbr, double int_xyz[][3]);

/* general case */
void MT_intLineLine(double L_XYZ[2][3], double l_xyz[2][3], double tol,
		    int level,int *int_nbr, double intxyz[][3]);

/* coplanar case */
void MT_intLineLine2(double L_XYZ[2][3], double l_xyz[2][3],
		    int *int_nbr, double intxyz[3]);

void P_projOnTriPlane(double fxyz[3][3], double pxyz[3], double *proxyz, double normal[3], double *distance);


/* ======= Intersection routines begin ======== */
/* Check if xyz is in the intersectionData */
int xyz_inIntersectionData (IntersectionData *idata, double xyz[3], double Tol);

/* Update the intersectionData */
void M_updateIntersectionData (IntersectionData *idata, pEntity ent1, pEntity ent2, double int_xyz[3], double tol2);

/* Look for the edge bounded by two vertices */
pEdge M_boundedEdgeOnFace (pFace face, pVertex vertex1, pVertex vertex2);
pEdge M_boundedEdgeOnRegion (pRegion reg, pVertex vertex1, pVertex vertex2);

pFace M_boundedFaceOnRegion (pRegion reg, pEntity ent0, pEntity ent1);

/* Create intersectionData */
IntersectionData M_intersectionData_new ();

/* Delete intersectionData */

void M_intersectionData_delete (IntersectionData idata);

/* For intersection between two edges */
int M_intersectEdges (pEdge edge1, int ClosureFlag1, pEdge edge2, int ClosureFlag2, IntersectionData *idata);

/* For intersection between an edge and a face */
int F_intersectEdge (pFace face, int ClosureFlag1, pEdge edge, int ClosureFlag2, IntersectionData *idata);

/* For intersection between two straight-edged faces */
int M_intersectFaces (pFace face1, int ClosureFlag1, pFace face2, int ClosureFlag2, IntersectionData *idata);

/* For intersection between a ray and a finite plane */
int M_intersectRay3XYZ (double start[3],  double dir[3], double F_xyz[3][3], double int_xyz[3], int *infinite);
int M_intersectLine3XYZ(double[3], double[3], double[3][3], double[3], int*);

/* For intersection between a ray and a finite line */
int M_intersectRay2XYZ (double start[3],  double dir[3], double L_xyz[2][3], double int_xyz[3], int *infinite);

/* For intersection between an edge and a region */
int R_intersectEdge (pRegion reg, int ClosureFlag1, pEdge edge, int ClosureFlag2, IntersectionData *idata);

/* For intersection between a face and a region */
int R_intersectFace (pRegion reg, int ClosureFlag1, pFace face, int ClosureFlag2, IntersectionData *idata);

/* For intersection between two regions */
int M_intersectRegions (pRegion reg1, int ClosureFlag1, pRegion reg2, int ClosureFlag2, IntersectionData *idata);

/*************************************************/
/* vector calculations/numerical comparisons:  may be put in a separate lib */
/*************************************************/
int sameSign(double x, double y);
double det3Mat(double *,double *,double *);
double det(int, double **);
double vecMag(double []);
void negVt(double []);
int C_equal(double real1,double real2);
int C_gequal(double real1,double real2);
int C_lequal(double real1,double r2);
int C_raneql(double real1,double real2,double tolran);
int C_requal(double real1,double real2,double range);
int C_rgequal(double real1,double real2, double r3);
int C_rlequal(double real1,double real2, double r3);
int C_rnleql(double , double ,double );

#ifdef __cplusplus
}

#endif

#endif


#ifndef __cplusplus

int GEN_inClosure(pGEntity, pGEntity);

#endif
