source env.pglt

echo "STARTING BUILD OPTIMIZED MESHADAPT WITH DOWNLOADING AND INSTALLING FMDB, IPCOMMAN and PARASOLID MODEL"

cd $DEVROOT
svn co http://redmine.scorec.rpi.edu/svn/fmdb/trunk FMDB/.
svn co http://redmine.scorec.rpi.edu/svn/ipcomman/trunk ipcomman/ipcomman/.
svn co http://redmine.scorec.rpi.edu/svn/mctk/trunk/parasolidModel/parasolidModel/ mctk/parasolidModel/parasolidModel/.
svn co http://redmine.scorec.rpi.edu/svn/buildutil/trunk Util/buildUtil/.

cd ipcomman/ipcomman
gmake -f Makefile.scorec distclean
gmake -f Makefile.scorec setup
gmake -f Makefile.scorec

cd ../../mctk/parasolidModel/parasolidModel
gmake distclean
gmake setup
gmake

cd ../../../FMDB/FMDB/FMDB
gmake -f Makefile.scorec distclean
gmake -f Makefile.scorec setup
cd ../../SCORECModel/SCORECModel
gmake -f Makefile.scorec distclean
gmake -f Makefile.scorec setup
cd ../../SCORECUtil/SCORECUtil
gmake -f Makefile.scorec distclean
gmake -f Makefile.scorec setup

cd ../../../meshAdapt/meshAdapt/meshAdapt
gmake -f Makefile.scorec distclean
gmake -f Makefile.scorec setup
cd ../../meshTools/meshTools/
gmake -f Makefile.scorec distclean
gmake -f Makefile.scorec setup

cd ../../../FMDB/FMDB/FMDB
gmake -f Makefile.scorec
cd ../../SCORECModel/SCORECModel
gmake -f Makefile.scorec
cd ../../SCORECUtil/SCORECUtil
gmake -f Makefile.scorec

cd ../../../meshAdapt/meshAdapt/meshAdapt
gmake -f Makefile.scorec
cd ../../meshTools/meshTools/
gmake -f Makefile.scorec

echo "FINISH BUILDING LIBRARIES"
