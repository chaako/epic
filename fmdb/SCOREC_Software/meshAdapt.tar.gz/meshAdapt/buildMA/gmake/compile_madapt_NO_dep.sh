source env.dat

echo "STARTING BUILD OPTIMIZED MESHADAPT ASSUMING ALL THE DEPENDENCIES ARE IN PLACE"

cd $DEVROOT/meshAdapt/meshAdapt/meshAdapt
gmake -f Makefile.scorec distclean
gmake -f Makefile.scorec setup
cd ../../meshTools/meshTools/
gmake -f Makefile.scorec distclean
gmake -f Makefile.scorec setup

cd ../../meshAdapt/meshAdapt/meshAdapt
gmake -f Makefile.scorec
cd ../../meshTools/meshTools/
gmake -f Makefile.scorec

echo "FINISH BUILDING LIBRARIES"
