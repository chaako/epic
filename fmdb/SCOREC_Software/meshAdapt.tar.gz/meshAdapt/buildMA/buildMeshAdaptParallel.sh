#!/bin/bash -ex

export SCRIPT_HOME=$PWD

if [ "$MPI_HOME" ]
then
  echo "MPI_HOME specified as: $MPI_HOME"
else
  export MPI_HOME=/usr/local/openmpi64/latest/
  export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$MPI_HOME/lib
  echo "MPI_HOME not specified... default value set as: $MPI_HOME"
  echo "If this is not the correct MPI install directory, where bin/mpirun, bin/mpicxx, bin/mpicc and lib/<MPI LIBRARIES> exist, then MPI_HOME must be specified in the environment prior to script execution."
fi

source $SCRIPT_HOME/auxillaryBuildScripts/setInstallDir.sh
set_install_dir $INSTALL_TARGET

if [ "x$CREATE_TARBALLS" == "x1" ]
then
  echo "CREATE_TARBALLS specified as: $CREATE_TARBALLS"
  echo "creating tarballs for distribution"
fi

source $SCRIPT_HOME/auxillaryBuildScripts/disableSharedLibs.sh
disable_shared_libs $DISABLE_SHARED_LIBS


if [ "x$PARMETIS_HOME" != "x" ]
then 
  echo "assuming parmetis is installed in $PARMETIS_HOME"
else 
  source $SCRIPT_HOME/auxillaryBuildScripts/downloadAndBuildParmetis.sh
  cd $SCRIPT_HOME
  download_and_build_parmetis 
fi

if [ "x$ZOLTAN_HOME" != "x" ]
then 
  echo "assuming parmetis is installed in $PARMETIS_HOME"
else 
  source $SCRIPT_HOME/auxillaryBuildScripts/downloadAndBuildZoltan.sh
  cd $SCRIPT_HOME
  download_and_build_zoltan $PARMETIS_HOME
  if [ $? == 1 ] 
  then 
    echo "Zoltan build failed... exiting"
    exit
  fi
fi

echo "Creating a directory for SCOREC software"
cd $SCRIPT_HOME
if [ ! -e SCOREC_Software ]; then 
   mkdir SCOREC_Software
   cd SCOREC_Software
   echo "attempting to install SCOREC software components to $INSTALL_TARGET ..."
   echo "downloading the source trees from the SCOREC SVN to the SCOREC_Software directory"
   svn co http://redmine.scorec.rpi.edu/svn/meshadapt/trunk meshAdapt
   svn co http://redmine.scorec.rpi.edu/svn/fmdb/software/trunk/FMDB/FMDB fmdb
   svn co http://redmine.scorec.rpi.edu/anonsvn/gmi/trunk gmi
   svn co http://redmine.scorec.rpi.edu/svn/fmdb/software/trunk/SCORECUtil/SCORECUtil scorecutil
   svn co http://redmine.scorec.rpi.edu/anonsvn/siter/trunk siter
   svn co http://redmine.scorec.rpi.edu/svn/buildutil/trunk/GNUautoTools/m4Macros m4
   svn co http://redmine.scorec.rpi.edu/svn/ipcomman/trunk ipcomman
else
   cd SCOREC_Software
fi
echo "setting variables for SCOREC software"
export SCOREC_SOFTWARE=$PWD
M4=$SCOREC_SOFTWARE/m4
SITER=$SCOREC_SOFTWARE/siter
SCORECUTIL_SRC=$SCOREC_SOFTWARE/scorecutil
SCORECUTIL=$INSTALL_TARGET
GMI_SRC=$SCOREC_SOFTWARE/gmi
GMI=$INSTALL_TARGET
FMDB_SRC=$SCOREC_SOFTWARE/fmdb
FMDB=$INSTALL_TARGET
IPCOMMAN_SRC=$SCOREC_SOFTWARE/ipcomman
IPCOMMAN=$INSTALL_TARGET
MESHADAPT_SRC=$SCOREC_SOFTWARE/meshAdapt
MESHADAPT=$INSTALL_TARGET
MESHADAPT_MESHMODEL_TESTSRC=$MESHADAPT_SRC/meshAdapt/meshAdapt/test/meshModel
MESHADAPT_MESHMODEL_TEST=$INSTALL_TARGET

source $SCRIPT_HOME/auxillaryBuildScripts/runAutoreconf.sh
source $SCRIPT_HOME/auxillaryBuildScripts/createTarballs.sh

echo "Building IpComMan"
if [ ! -e $INSTALL_TARGET/include/IPComMan.h ] || 
   [ ! -e $INSTALL_TARGET/lib/libipcomman.a  ];   then
   cd $IPCOMMAN_SRC
   run_autoreconf $SCOREC_SVN  
   ./configure $SHARED_LIBS --with-mpi=$MPI_HOME --prefix=$IPCOMMAN
   make
   make install
fi 

echo "Building GMI"
if [ ! -e $INSTALL_TARGET/include/SGModel.h    ] || 
   [ ! -e $INSTALL_TARGET/lib/libSCORECModel.a ];   then
   cd $GMI_SRC
   run_autoreconf $SCOREC_SVN  
   ./configure  $SHARED_LIBS CXXFLAGS="-DFMDB_PARALLEL" CFLAGS="-DFMDB_PARALLEL" --enable-meshmodel --with-scorecutil=$SCORECUTIL_SRC --with-fmdb=$FMDB_SRC --with-iterators=$SITER --prefix=$GMI
   make -j 4
   make install
fi

echo "Building SCORECUtil"
if [ ! -e $INSTALL_TARGET/include/SCUtil.h ]       ||  
   [ ! -e $INSTALL_TARGET/lib/libSCORECUtil.a ];   then
   cd $SCORECUTIL_SRC
   run_autoreconf $SCOREC_SVN  
   ./configure $SHARED_LIBS CXXFLAGS="-DFMDB_PARALLEL" CFLAGS="-DFMDB_PARALLEL"  --with-gmi=$GMI --with-fmdb=$FMDB_SRC --with-iterators=$SITER --prefix=$SCORECUTIL
   make -j 4
   make install
fi

echo "Building FMDB"
cd $FMDB_SRC
if [ ! -e $INSTALL_TARGET/include/FMDB.h ] || 
   [ ! -e $INSTALL_TARGET/lib/libFMDB.a  ];   then
   run_autoreconf $SCOREC_SVN  
   ./configure $SHARED_LIBS  CXXFLAGS="-DFMDB_PARALLEL" CFLAGS="-DFMDB_PARALLEL" --with-mpi=$MPI_HOME --with-gmi=$GMI --with-ipcomman=$IPCOMMAN --with-scorecutil=$SCORECUTIL --with-iterators=$SITER --with-zoltan=$ZOLTAN_HOME --with-parmetis=$PARMETIS_HOME --prefix=$FMDB
   make -j 4
   make install
fi

echo "Building MeshAdapt"
cd $MESHADAPT_SRC
run_autoreconf $SCOREC_SVN  
./configure $SHARED_LIBS CXXFLAGS="-DFMDB_PARALLEL" CFLAGS="-DFMDB_PARALLEL" --with-mpi=$MPI_HOME --enable-meshmodel --with-gmi=$GMI --with-fmdb=$FMDB --with-scorecutil=$SCORECUTIL --with-iterators=$SITER --with-ipcomman=$IPCOMMAN --with-zoltan=$ZOLTAN_HOME --with-parmetis=$PARMETIS_HOME --prefix=$MESHADAPT
make -j 4
make install

echo "Building MeshAdapt MeshModel Test"
cd $MESHADAPT_MESHMODEL_TESTSRC
run_autoreconf $SCOREC_SVN  
./configure $SHARED_LIBS CXXFLAGS="-DFMDB_PARALLEL" CFLAGS="-DFMDB_PARALLEL" --with-mpi=$MPI_HOME --with-meshadapt=$MESHADAPT --with-gmi=$GMI --with-fmdb=$FMDB --with-scorecutil=$SCORECUTIL --with-iterators=$SITER --with-ipcomman=$IPCOMMAN --with-zoltan=$ZOLTAN_HOME --with-parmetis=$PARMETIS_HOME --prefix=$MESHADAPT_MESHMODEL_TEST
make -j 4
make install

if [ "x$CREATE_TARBALLS" == "x1" ]; then
  echo "Creating SCUtil Tarball"
  cd $SCOREC_SOFTWARE
  tar --exclude=".svn" -czf siter.tar.gz siter

  mkdir SCUtil
  mv $SCORECUTIL_SRC/*.tar.gz SCUtil
  mv $SCOREC_SOFTWARE/siter.tar.gz SCUtil
  tar -czf SCUtil.tar.gz SCUtil
fi

