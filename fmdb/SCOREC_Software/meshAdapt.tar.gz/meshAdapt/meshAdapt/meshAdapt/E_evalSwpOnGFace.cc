/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Rao Garimella
  Creation  : Feb 96
  Modifi.   : 
  Function  : 
    Evaluate if the faces created by swapping an edge classified on a model 
    face and not connected to any mesh regions are valid
    Procedure uses comparison of model face to mesh face normal to see if
    mesh faces are inside out. Since it is known that is not the most robust
    way of checking validity, this routine may be rewritten sometime 
    AND ITS ARGUMENTS MIGHT CHANGE
-------------------------------------------------------------------------*/
#include <stdio.h>
#include <math.h>
#include "FMDB.h"
#include "Macros.h"
#include "modeler.h"
#include "fromMeshTools.h"

int E_evalSwpOnGFace(pEdge swpedge, pGEntity GFace, double *normal) {
  pFace f[2], tmpf;
  pVertex v[2], fv[6];
  int i,j;
  double sml, big, xyz[3][3], cosangs[3];


  /* If edge classified on model edge, no can do! */
  if (E_whatIn(swpedge) != GFace)
    return 0; 

  /* If it is not a 2-manifold situation, cannot swap either */
  if (E_numFaces(swpedge) != 2)
    return 0;

  /* Get faces connected to edge such that prediction of */
  /* vertices of the new faces will be easy              */
  for (i = 0; i < 2; i++)
    f[i] = E_face(swpedge,i);
  if (!F_dirUsingEdge(f[0],swpedge)) {
    tmpf = f[0];
    f[0] = f[1];
    f[1] = tmpf;
  }

  /* Vertices of new faces in correct order */
  for (i = 0; i < 2; i++)
    fv[i] = fv[!i+3] = F_edOpVt(f[i],swpedge);
  fv[2] = E_vertex(swpedge,1); fv[5] = E_vertex(swpedge,0);

  for (i = 0; i < 2; i++) {
    for (j = 0; j < 3; j++)
      V_coord(fv[3*i+j],xyz[j]);
    if (!XYZ_FAngles(xyz,normal,cosangs))
      return 0;
    big = MIN(cosangs[0],MIN(cosangs[1],cosangs[2]));
    if (C_equal(fabs(big),1.0))
      return 0;
  }

  /* We also have to check if the swap will create two coincident faces.
     Can happen in some situations when an face already exists between
     the vertices of a to-be-created face - e.g. at a model vertex
     where two model faces share two model edges
     */

  if (F_exists(Tvertex,fv[0],fv[1],fv[2],0))
    return 0;

  if (F_exists(Tvertex,fv[3],fv[4],fv[5],0))
    return 0;
  
  return 1;
}


