#include "LayerEdgeSwapMod.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "Eswap.h"
#include "Macros.h"
#include "fromMeshTools.h"
#include "mEntity.h"
#include "FMDB_cint.h"
#include <stdio.h>

using std::cout;
using std::endl;
using std::cerr;

#ifdef MVTK
#include "mvtk.h"
#endif

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif

/*
  In evaluation, u must call the functions in an order as follows
    topoCheck();
    geomCheck();   -> check geometric similarity and calculate shape info
    sizeCheck();   -> calculate size info

  To perform the modification, call routine apply();  

  return 1: TRUE or SUCCESS
         0: FALSE or FAIL

  History: 10/05/99  Created. 
           03/07/01  Add valid(), worstShape(), maxminEdgeLength()  
	   06/18/01  add sizeCheck() 
	   08/14/01  add the option to control volume conservation
	   09/26/01  deny the edge swap if it creates an edge spanning more than 
                     MAX_PERIODIC_SPAN*period;    
           04/12/02  support 2D application and evaluation for AOMD 
*/

int layerEdgeSwapMod::topoCheck() 
{    

  if(E_whatInType(edge)==Gedge)
    return 0;

  pEdge edg;
  for(int iList=0; iList<listSize; iList++) {
    edg = edges[iList];
    if (!EN_okTo(SWAP,(pEntity)edg))
      return 0;
#ifdef MA_PARALLEL
    if( EN_onCB((pEntity)edg) )
      return 0;
#endif
  }

  if(E_whatInType(edge)==Gface) {
    int n1 = 0;
    pGEntity gface = E_whatIn(edge);
    if (GF_region((pGFace)gface,0)) n1++;
    if (GF_region((pGFace)gface,1)) n1++;
    if (n1 == 2) {
//**      cout<<"\nError in layerEdgeSwapMod::topoCheck()"<<endl;
//**      cout<<"zero level layer edge classified on non-manifold face"<<endl;
//**      exit(0);
    }
  }
  else {
    cout<<"\nWarning in layerEdgeSwapMod::topoCheck()"<<endl;
    cout<<"zero level layer edge NOT classified on model face\n"<<endl;
    return 0;
  }


  std::vector<pRegion> VecRgn;
  E_nonBLRegions(interfaceEdge, VecRgn);
  for (int iRgn = 0; iRgn < VecRgn.size(); ++iRgn)
    if (VecRgn[iRgn]->getType() != TET)
      return 0;

  // cannot handle transition elements as of now
  // check for the total number of layers 
  // at nodes of the two layer faces
  vector<pFace> faces;
  E_layerFaces(edge, faces);
  int numFaces = faces.size();
  int level[3];
  pPList vlist;
  // must be 2 (cannot swap an edge classified on model edge)
  // can be 1 due to partial BL mesh on a surface
  for(int iFace=0; iFace<numFaces; iFace++) {
    vlist = F_vertices(faces[iFace],1);
    // assuming layer face to be triangular
    for(int iVert=0; iVert<3; iVert++)
    {
      vector<pVertex> otherVtxStack;
      /// This is somewhat expensive, look at other alternatives.
      BL_getGrowthCurveNodes((pVertex)PList_item(vlist,iVert), otherVtxStack);

      level[iVert]=otherVtxStack.size()-1; //V_totNumLayers((pVertex)PList_item(vlist,iVert));
    }
    PList_delete(vlist);

    if( level[0]!=level[1] || 
	level[0]!=level[2] ) {
      // cout<<"\nError in layerEdgeSwapMod::topoCheck()"<<endl;
      // cout<<"transition elements NOT supported [iFace="<<iFace<<"]"<<endl;
      // exit(0);
      return 0;
    }
  }

  // n is needed for the top most edge of the stack
  // i.e., at the interface of bdry. layer and interior volume mesh
  n=fromMeshTools::E_numSwpCfg(interfaceEdge);
  if(!n)
    return 0;

  return 1;
}

int layerEdgeSwapMod::geomCheck()
{ 
  pMSize pmt[3], PMT[4];
  pRegion region;
  pVertex vt;
//  pPList verts;
  std::vector<pVertex> *verts;
//  double origin[3];
  double xyz[3][3], XYZ1[4][3];
  double shape_1, shape_tmp, optimum, worst, worst_tmp;
  int num, i, j, k, flag;
  void *temp;

  if ( n==-1 )
    std::cout<<"Error: please do topoCheck() before geomCheck()"<<endl;
  
  // check parametric span if on periodic model face
  // this is done for zero level edge and interface (top most) edge
  if( model_type==PARAM ) {
    if( !adaptUtil::E_swpCheckPer(edge) )
      return 0;
    if( !adaptUtil::E_swpCheckPer(interfaceEdge) )
      return 0;
  }

  results->reset();

//   // this is not true if case we have surface and volume mesh together
//   if( M_numRegions(mesh)==0 ) 
//     return geomCheck2D();

//   if( vertMv ) {
//     // make the move
//     V_coord(vertMv,origin);
//     adaptUtil::move_vertex(vertMv,target);

//     // determine the validity of tets hooked on the moving vertex but not in
//     // the polyhedron associated with swap
//     // Although the validity requirement is only positive volume, we calculate 
//     // element shape here to avoid repeated calculation
//     pPList vrlist=V_regions(vertMv);
//     temp=0;
//     while(region=(pRegion)PList_next(vrlist,&temp)) {
//       if(R_inClosure(region,(pEntity)edge)) continue;

//       // calculate shape and check acceptability
//       if( ! shpMeasure->R_shape(region, &shape_1) ) {
// 	adaptUtil::move_vertex(vertMv,origin); 
// 	PList_delete(vrlist); 
// 	return 0;
//       }

//       if( shape_1 < results->getWorstShape() )
// 	results->setWorstShape(shape_1);
//     }
//     PList_delete(vrlist);
//   }

  // get the four concerned growth curves
  // GCs[0] - v0 of edge, GCs[1] - v1 of edge
  // GCs[2] - opp. vt. of face using edge negatively
  // GCs[3] - opp. vt. of face using edge positively
  // cannot handle transition elements as of now
  // check for the total number of layers 
  // at nodes of the two layer faces
  // edge at corner (i.e., on model edge) 
  // cannot be swapped as it will violate
  // topological compatibility with the model
  // hence for any other layer edge at zero level 
  // only possibility is two layer faces

  // normal is used in shpMeasure->XYZ_shape() for triangles
  double normal[3]; 
  vector<pVertex> GCs[4];
//  GCs[0] = V_growthCurve(E_vertex(edge,0));
//  GCs[1] = V_growthCurve(E_vertex(edge,1));
  BL_getGrowthCurveNodes(E_vertex(edge,0), GCs[0]);
  BL_getGrowthCurveNodes(E_vertex(edge,1), GCs[1]);

  pFace fc;
  vector<pFace> faces;
  E_layerFaces(edge, faces);
  int numFaces = faces.size();
  int level[3];
  pPList vlist;
  // must be 2 (cannot swap an edge classified on model edge)
  // can be 1 due to partial BL mesh on a surface
  for(int iFace=0; iFace<numFaces; iFace++) {
    fc = faces[iFace];
    
    if(iFace==0)
      F_normalVector(fc,1,normal);

    int iGC=2;
    if(F_dirUsingEdge(fc,edge))
      iGC=3;
//    GCs[iGC]=V_growthCurve(F_edOpVt(fc,edge));
    BL_getGrowthCurveNodes(F_edOpVt(fc,edge), GCs[iGC]);

    vlist = F_vertices(fc,1);
    // assuming layer face to be triangular
    for(int iVert=0; iVert<3; iVert++)
    {
      vector<pVertex> otherVtxStack;
      /// This is somewhat expensive, look at other alternatives.
      BL_getGrowthCurveNodes((pVertex)PList_item(vlist,iVert), otherVtxStack);

      level[iVert]=otherVtxStack.size()-1;
    }
    PList_delete(vlist);

    if( level[0]!=level[1] &&
	level[0]!=level[2] ) {
      cout<<"\nError in layerEdgeSwapMod::geomCheck()"<<endl;
      cout<<"transition elements NOT supported [iFace="<<iFace<<"]"<<endl;
      exit(0);
    }
  }

  // calculate the volume of original prisms w.r.t. swap of "edge"
  // and also the volume of original polyhedron at interface
  // w.r.t. swap of interface edge (top most edge) includes non-BL elements
  double origVol[2]= {0.,0.}, newVol[2]={0.,0.};
  double iTol = M_getTolerance();
  if( checkVolume ) {
    pPList erlist1 = E_regions(edge);
    temp=0;
    while( region = (pRegion)PList_next(erlist1, &temp) )
	origVol[0] += R_Volume2(region);    
    PList_delete (erlist1);
    
    pPList erlist2 = E_regions (interfaceEdge);
    temp=0;
    while( region = (pRegion)PList_next(erlist2, &temp) ) {
      if(!EN_isBLEntity(region)) 
	origVol[1] += R_Volume2(region);
    }
    PList_delete (erlist2);
  }

  // compute the volume of the new prisms w.r.t. swap of "edge"
  // The volume of newly created regions should be no less than a tolerance, difened as 1e-16. It should not be negative in any case.
  newVol[0] = 0.;
  double dNewVolEach;
  int iLvlChk[2] = {0, GCs[0].size()-2};
  int counter = 0;
  int orderGCs[3];
  // fit three tets in a prism
  // (diagonal edges of a prism are : V0-V4, V1-V5 and V5-V0)
  int tetVerts[3][4] = {0,1,2,5, 0,1,5,4, 0,4,5,3};

  pVertex vts[6];
  for (int iLvl = 0; iLvl < 2; ++iLvl)
  {
    for(j=0; j<2; j++)
    {
      counter=0;
      if(j)
      {
        if (!iLvl)
        {
          orderGCs[0]=3; orderGCs[1]=1; orderGCs[2]=2;
        }
        else
        {
          orderGCs[0]=2; orderGCs[1]=3; orderGCs[2]=1;
        }
      }
      else
      {
        if (!iLvl)
        {
          orderGCs[0] = 2; orderGCs[1] = 0; orderGCs[2] = 3;
        }
        else
        {
          orderGCs[0] = 3; orderGCs[1] = 2; orderGCs[2] = 0;
        }
      }

      for(int iList = iLvlChk[iLvl]; iList < iLvlChk[iLvl] + 2; ++iList)
	for(k=0; k<3; k++)
	  vts[counter++]=GCs[orderGCs[k]][iList];

      // three tets in a prism
      // compute volume of prism by adding volume of three tets
      dNewVolEach = 0.;
      for(int iTet=0; iTet<3; iTet++) 
      {
	for(int iVert=0; iVert<4; iVert++) 
        {
	  V_coord(vts[tetVerts[iTet][iVert]],XYZ1[iVert]);
	}
        dNewVolEach += XYZ_volume(XYZ1);
        if (iLvl == 0)
          newVol[0] += dNewVolEach;
      }
      if (dNewVolEach < iTol)
        return 0;
    }
  }

  if( checkVolume ) {
    // see if it will cause volume change (for edge)
    if( ABS(origVol[0]-newVol[0])/origVol[0] > dV_limit ) {
//      cout<<"\n\n check this volume change due to \"edge\" swap\n\n"<<endl;
      return 0;
    }
  }

  // determine the validity of layer faces 
  // associated with each layer edge swap (in the stack)
  // i.e., by using shpMeasure->XYZ_shape() for triangles

  worst_tmp=BIG_NUMBER;
  int orderOfGCs[3] = {0,2,3};
  // loop over all the layer edges (i.e., whole stack)
  // ---> OR may be we need to check this for "edge" and interface edge
  // ---> OR just "edge" as interface edge would be checked later anyways
  for(int iList=0; iList<listSize; iList++) {
    
    for(j=0; j<2; j++) {
      if(j)
	{ orderOfGCs[0]=3; orderOfGCs[1]=2; orderOfGCs[2]=1; }

      for(k=0; k<3; k++) {
	vt = GCs[orderOfGCs[k]][iList];
	
	V_coord(vt,xyz[k]);
	pmt[k]=pSizeField->getSize(vt);
      }

      // used for checking validity of layer faces (triangles)
      // this is to check if any layer faces are inverted
      if( ! shpMeasure->XYZ_shape(xyz,pmt,normal,&shape_tmp) )
	{ return 0; }

      if(shape_tmp < worst_tmp)   
	worst_tmp=shape_tmp;
    }
    // OK, we have a valid configuration here
  } // loop over list "edges" ends

  // loop over all possible configurations, find the one of best element shape
  // for swap of interface edge
  // also compute the volume of new polyhedron at interface
  // w.r.t. swap of interface edge (top most edge) includes non-BL elements
  optimum=0.;
  for(i=0;i<n;i++) {
      newVol[1] = 0.;
      verts=fromMeshTools::E_swpCfgVerts(interfaceEdge,i);
    
      if( !verts ) 
	continue;
      num=verts->size()/4;

      // this is a special case (see E_swp2Fac.c in meshTools) 
      // it is the same as 2->2 RegionCollapse operator 
      if( !num ) {
	cout<<"\nError in layerEdgeSwapMod::geomCheck()"<<endl;
	cout<<"special case of E_swp2Fac detected in bdry. layer mesh"<<endl;
	delete verts;
	exit(0);
      }

      // loop over regions that will be created for this specific configure
      // calculate the worst shape
      flag=0;
      worst=BIG_NUMBER;
      std::vector<pVertex>::iterator vtIter=verts->begin();
      for(j=0; j<num; j++) {	
	for(k=0;k<4;k++) {
	  vt=*vtIter;
	  vtIter++;
	  V_coord(vt,XYZ1[k]);
	  PMT[k]=pSizeField->getSize(vt); 
	}

	// compute the sum of volume of the new regions 
	// (only non-BL included)
	if( checkVolume) 
	  newVol[1] += XYZ_volume(XYZ1);

	// calculate shape and check acceptability
	if( ! shpMeasure->XYZ_shape(XYZ1,PMT,&shape_1) )
	  { flag=1; break; }
	
	// find the worst element shape of this configuration
	if(shape_1 < worst)   
	  worst=shape_1;
      }
      delete verts;      
      
      if(flag) 
	continue;
      
      // OK, we have a valid configuration here
      
      // see if it will cause volume change (for interface edge)
      if( checkVolume )
	if( ABS(origVol[1]-newVol[1])/origVol[1] > dV_limit ) {
//	  cout<<"\n\n check this volume change due to \"interface edge\" swap\n\n"<<endl;
	  return 0;
	}
   
      // if it is the one with "the worst shape" best so far, remember it
      if(worst>optimum)
	{  optimum=worst;  conf=i; }
    }

//   // undo the vertex motion
//   if( vertMv )  
//     adaptUtil::move_vertex(vertMv,origin);

  // if "optimum" unchanges, there is no valid 
  // swap configuration for interface edge
  // if( optimum<=M_getTolerance() )  
  if(optimum<QUALITYFRACTION*QUALITYTHRESHOLD)
    return 0;

  // consider minimum of interface elements and layer faces
  if(optimum*optimum > worst_tmp*worst_tmp*worst_tmp)
    optimum = worst_tmp*sqrt(worst_tmp);

  // combine the two worst element shape
  if( optimum<results->getWorstShape() )
    results->setWorstShape(optimum);

  // check geometric similarity if the edge is on model face
  if( model_type==PARAM ) {
    if( E_whatInType(edge)==Gface ) {
      pFace face;
      pPList F_verts, tmplist; 
      pVertex vts[2];
      // the two vertices should be available in the swap structure
      j=0;
      for( i=0; i<E_numFaces(edge); i++ ) {
	face=E_face(edge,i);
	if( F_whatInType(face)==Gface ) 
	  vts[j++]=F_edOpVt(face,edge);
	if( j==2 ) break;
      }
      
      pGFace gface=(pGFace)F_whatIn(face);
      F_verts=PList_new();
      tmplist=adaptUtil::F_verticesOutofMesh(face);
      flag=0;
      for( i=0; i<2; i++ ) {
	temp=0; 
	while( vt=(pVertex)PList_next(tmplist,&temp) ) 
	  if( vt==E_vertex(edge,i) )
	    PList_append(F_verts,(pEntity)vts[0]);
	  else
	    PList_append(F_verts,(pEntity)vt);
	if( adaptUtil::F_checkGeoSim(&F_verts,gface)!=1 ) 
	  { flag=1; break; }
	PList_clear(F_verts);
      }
      
      PList_delete(tmplist);
      PList_delete(F_verts);
      if( flag ) return 0;
    }

    if( E_whatInType(interfaceEdge)==Gface ) {
      pFace face;
      pPList F_verts, tmplist; 
      pVertex vts[2];
      // the two vertices should be available in the swap structure
      j=0;
      for( i=0; i<E_numFaces(interfaceEdge); i++ ) {
	face=E_face(interfaceEdge,i);
	if( F_whatInType(face)==Gface ) 
	  vts[j++]=F_edOpVt(face,interfaceEdge);
	if( j==2 ) break;
      }
      
      pGFace gface=(pGFace)F_whatIn(face);
      F_verts=PList_new();
      tmplist=adaptUtil::F_verticesOutofMesh(face);
      flag=0;
      for( i=0; i<2; i++ ) {
	temp=0; 
	while( vt=(pVertex)PList_next(tmplist,&temp) ) 
	  if( vt==E_vertex(interfaceEdge,i) )
	    PList_append(F_verts,(pEntity)vts[0]);
	  else
	    PList_append(F_verts,(pEntity)vt);
	if( adaptUtil::F_checkGeoSim(&F_verts,gface)!=1 ) 
	  { flag=1; break; }
	PList_clear(F_verts);
      }
      
      PList_delete(tmplist);
      PList_delete(F_verts);
      if( flag ) return 0;
    }
  }

  return 1;
}


// int layerEdgeSwapMod::geomCheck(pVertex v1, pVertex v2)
// { 
//   pMSize pmt[4];
//   pVertex vt;
//   std::vector<pVertex> *verts;
//   double xyz[4][3];
//   double shape_1, optimum, worst;
//   int num, i, j, k, flag, okCfg, flagCfg;

//   if ( n==-1 )
//     std::cout<<"Error: please do topoCheck() before geomCheck()"<<endl;  
//   if ( vertMv )
//     std::cout<<"Error: not implemented yet (layerEdgeSwapMod::geomCheck(v1,v2)"<<endl;

//   // check parametric span if on periodic model face
//   if( model_type==PARAM ) {
//     if( !adaptUtil::E_swpCheckPer(edge) )
//       return 0;
//   }
//   results->reset();

//   if( M_numRegions(mesh)==0 ) 
//     return geomCheck2D();
  
//   // determine the validity of tets associated with swap


//   // loop over all possible configurations, find the one of best element shape
//   optimum=0.0;
//   for(i=0;i<n;i++) {
//     verts=fromMeshTools::E_swpCfgVerts(edge,i);
//     if( !verts ) 
//       continue;
//     //num=PList_size(verts)/4;
//     num=verts->size()/4;

//     // this is a special case (see E_swp2Fac.c in meshTools) 
//     // It is the same as 2->2 RegionCollapse operator 
//     // Always can be applied     -li 8/14/01
//     if( !num ) {
//       delete verts;
//       break;
//     }

//     // loop over regions that will be created for this specific configure
//     // calculate the worst shape
//     flag=0;
//     okCfg=0;
//     worst=BIG_NUMBER;
//     std::vector<pVertex>::iterator vtIter=verts->begin();
//     for(j=0;j<num;j++) {
//       flagCfg=0;
//       // get vertex coordintes assuming the vertex moved
//       for(k=0;k<4;k++) {
//         vt=*vtIter;
//         vtIter++;
// 	V_coord(vt,xyz[k]);
// 	if( vt==v1 )  ++flagCfg;
// 	if( vt==v2 )  ++flagCfg; 
// 	pmt[k]=pSizeField->getSize(vt);
//       }
//       if( flagCfg==2 ) okCfg=1;

//       // calculate shape and check acceptability
//       if( ! shpMeasure->XYZ_shape(xyz, pmt,&shape_1) )
// 	{ flag=1; break; }

//       // find the worst element shape of this configuration
//       if(shape_1 < worst)   
// 	worst=shape_1;
//     }
//     delete verts;

//     if( !okCfg )
//       // this configuration has the desired edge
//       continue;

//     if(flag) 
//       continue;
      
//     // OK, we have a valid configuration here

//     // if it is the one with "the worst shape" best so far, remember it
//     if(worst>optimum)
//       {  optimum=worst;  conf=i; }
//   }

//   // if "optimum" unchanges, there is no valid swap configuration
//   if( optimum<=M_getTolerance() )  
//     return 0;

//   // combine the two worst element shape
//   if( optimum<results->getWorstShape() )
//     results->setWorstShape(optimum);

//   return 1;
// }


// int layerEdgeSwapMod::geomCheck2D()
// {
//   pMSize pmt[3];
//   pFace face;
//   pVertex vts[2],vt;
//   double xyz[3][3];
//   double shape_1, worst=BIG_NUMBER;;
//   int i,j, flag;
//   void *temp;

//   if( vertMv ) {
//     std::cerr<<" A pre vertex motion is not supported (geomCheck2D)\n"<<endl;
//     return 0;
//   }

//   // ensure no region attached 
// #ifdef DEBUG
//   pPList erlist=E_regions(edge);
//   if( PList_size(erlist) != 0 ) {
//     PList_delete(erlist);
//     std::cerr<<" there are attached regions (geomCheck2D)\n"<<endl;
//     return 0;
//   }
//   PList_delete(erlist);
// #endif

//   // find the vertices opposite to 'edge' 
//   if( E_numFaces(edge) != 2 )
//     {
//       printf("Error: should first check topological validity (layerEdgeSwapMod::geomCheck2D)\n");
//       return 0;
//     }

//   for( i=0; i<E_numFaces(edge); i++ ) {
//     face=E_face(edge,i);
//     vts[i]=F_edOpVt(face,edge);
//   }

//   pPList tmplist=F_vertices(face,1);

//   // in case there is parametric space
//   if( model_type==PARAM ) {
//     pGFace gface=(pGFace)F_whatIn(face);
//     pPList F_verts=PList_new();

//     flag=0;
//     for( i=0; i<2; i++ ) {
//       // check geometric similarity
//       temp=0; 
//       while( vt=(pVertex)PList_next(tmplist,&temp) ) 
// 	if( vt==E_vertex(edge,i) )
// 	  PList_append(F_verts,(pEntity)vts[0]);
// 	else
// 	  PList_append(F_verts,(pEntity)vt);
//       if( adaptUtil::F_checkGeoSim(&F_verts,gface)!=1 ) 
// 	{ flag=1; break; }
//       // calculate the worst element shape
//       temp=0; j=0;
//       while( vt=(pVertex)PList_next(F_verts,&temp) )
// 	{
// 	  pmt[j]=pSizeField->getSize(vt);
// 	  V_coord(vt,xyz[j++]);
// 	}
//       PList_clear(F_verts);
//       if( ! shpMeasure->XYZ_shape(xyz,pmt,0,&shape_1) )
// 	{ flag=1; break; } 
//       if(shape_1 < worst)   
// 	worst=shape_1;
//     }
//     PList_delete(tmplist);
//     PList_delete(F_verts);
//     if( flag ) 
//       return 0;
//   }

//   else {    // no parametric space
//     double area, area1, normal[3], normal1[3];

//     // determine the normal
//     F_normalVector(E_face(edge,0),1,normal);
//     F_normalVector(E_face(edge,1),1,normal1);
//     area = dotProd(normal,normal);
//     area1 = dotProd(normal1,normal1);
//     if( MAX(area, area1) < M_getTolerance()*M_getTolerance() )
//       { printf("Error: an edge bounded by two sliver faces\n"); return 0; }
//     if( area < area1 )
//       {
// 	normal[0]=normal1[0];
// 	normal[1]=normal1[1];
// 	normal[2]=normal1[2];
//       }

//     // check the validity with respect to the normal
//     flag=0;
//     for( i=0; i<2; i++ ) {
//       temp=0; j=0;
//       while( vt=(pVertex)PList_next(tmplist,&temp) ) {
// 	if( vt==E_vertex(edge,i) )
// 	  {
// 	    pmt[j]=pSizeField->getSize(vts[0]);
// 	    V_coord(vts[0],xyz[j++]);
// 	  }
// 	else
// 	  {
// 	    pmt[j]=pSizeField->getSize(vt);
// 	    V_coord(vt,xyz[j++]);
// 	  }
//       }

//       if( ! shpMeasure->XYZ_shape(xyz,pmt,normal,&shape_1) )
// 	{ flag=1; break; } 
//       if(shape_1 < worst)   
// 	worst=shape_1;
//     }
//     PList_delete(tmplist);
//     if( flag ) 
//       return 0;
//   }

//   results->setWorstShape(worst);
//   return 1;
// }



/*
  calculate the max/min size after the modification is applied

  return 0:  size not acceptable
         1:  acceptable
*/
int layerEdgeSwapMod::sizeCheck()
{
  double max, min;
  double maxSwap, minSwap;
  double tmp, ratio=0.0;
//   int i;
//   pEdge eg;
//   double origin[3];
  
  // initialization
  min=BIG_NUMBER; 
  max=0.0;
  
//   // make the move
//   if( vertMv ) {
//     V_coord(vertMv,origin);
//     adaptUtil::move_vertex(vertMv,target);
    
//     // consider edges connected to the moving vertex
//     for(i=0;i<V_numEdges(vertMv);i++) {
//       eg=V_edge(vertMv,i);
//       if( eg==edge ) continue;
//       tmp=pSizeField->lengthSq(eg);
//       if( min>tmp ) min=tmp;
//       if( max<tmp ) max=tmp;
//     }
//   }
  
//   // consider the new edges created after swap
//   if( M_numRegions(mesh)==0 ) {
//     // 2D
//     if( E_numFaces(edge)!=2 )
//       { printf("Info: should first check topological validity \n"); return 0;}
//     pVertex vv[2];
//     pFace face;
//     for( i=0; i<2; i++ ) {
//       face=E_face(edge,i);
//       vv[i]=F_edOpVt(face,edge);
//     }
//     maxSwap=pSizeField->lengthSq(vv[0],vv[1]);
//     minSwap=maxSwap;
//   }
//   else 
  {
    // 3D
    if( E_swpNewEdges(&maxSwap, &minSwap)==-1 )
      std::cout<<"Error: layerEdgeSwapMod::maxminEdgeLength()"<<endl;
  }
  
  if( maxSwap > max ) max=maxSwap;
  if( minSwap < min ) min=minSwap;

  // get size of the edge before swap
  tmp = pSizeField->lengthSq(interfaceEdge);
  ratio=maxSwap/tmp;

  vector<pVertex> VtxStack;
  /// This is somewhat expensive, look at other alternatives.
  BL_getGrowthCurveNodes(E_vertex(edge,0), VtxStack);
  int level=VtxStack.size()-1;

  BL_getGrowthCurveNodes(E_vertex(edge,1), VtxStack);
  int level2 = VtxStack.size()-1;

//  int level = V_totNumLayers(E_vertex(edge,0));
  if(level != level2) {
    cout<<"\nError in layerEdgeSwapMod::sizecheck()"<<endl;
    cout<<"level of vertices of \"edge\" NOT equal"<<endl;
    cout<<"transition elements NOT supported as of now"<<endl;
    exit(0);
  }

  vector<pVertex> GCs[2];
  pFace fc;
  pVertex vts[2];
  vector<pFace> faces; 
  E_layerFaces(edge, faces);
  int numFaces = faces.size();
  // must be 2 (cannot swap an edge classified on model edge)
  // can be 1 due to partial BL mesh on a surface
  for(int iFace=0; iFace<numFaces; iFace++) {
    fc = faces[iFace];
    vts[iFace] = F_edOpVt(fc,edge);
//    GCs[iFace] = V_growthCurve(vts[iFace]);
    BL_getGrowthCurveNodes(vts[iFace], GCs[iFace]);

//    if(level!=V_totNumLayers(vts[iFace])) {
    if(level!=GCs[iFace].size()-1) {
      cout<<"\nError in layerEdgeSwapMod::sizecheck()"<<endl;
      cout<<"level of GCs["<<iFace<<"] is NOT equal level of \"edge\""<<endl;
      cout<<"transition elements NOT supported as of now"<<endl;
      exit(0);      
    }
  }

  double LL;
  for(int iList=0; iList<listSize; iList++) {
    vts[0]=GCs[0][iList];
    vts[1]=GCs[1][iList];
    LL = pSizeField->lengthSq(vts[0],vts[1]);
    if(LL > max) max=LL;
    if(LL < min) min=LL;
    
    tmp = pSizeField->lengthSq(edges[iList]);
    if(ratio<LL/tmp)
      ratio=LL/tmp;
  }

  results->setMaxSize(max);
  results->setMinSize(min);
  results->setMaxRatioSquare(ratio);
  
//   // move back
//   if( vertMv ) 
//     adaptUtil::move_vertex(vertMv,origin);
  return 1;
}


void layerEdgeSwapMod::getAffectedRgns(pPList *l)
{
  *l=E_regions(edge);

  for(int iList=0; iList<listSize; iList++) {
    pPList erlist=E_regions(edges[iList]);
    PList_appPListUnique(*l,erlist);
    PList_delete(erlist);
  }

//   if( vertMv ) {
//     pPList vrlist=V_regions(vertMv);
//     pRegion region;
//     void *iter=0;
//     while( region=(pRegion)PList_next(vrlist,&iter) )
//       PList_appUnique(*l, region);
//     PList_delete(vrlist);
//   }
}


int layerEdgeSwapMod::apply()
{
  pPList newRegs;
  apply( &newRegs );
  PList_delete(newRegs);

  edges.clear();

  return 1;
}


int layerEdgeSwapMod::apply(pPList *newRegs)
{

//   if( vertMv ) {
//     adaptUtil::move_vertex(vertMv,target,CB_move,userData_CB_move);
// #ifdef DEBUG
//     pPList mvRgns=V_regions(vertMv);
//     pPList edRgns=E_regions(edge);
//     iter=0;
//     while( region=(pRegion)PList_next(mvRgns,&iter) ) {
//       if( ! PList_inList(edRgns,region) )
// 	if( R_Volume2(region) < 2.e-16 ) {
// 	  printf("Error: 1. region %p: R_Volume2=%12.5e [rTopoType=%d] (layerEdgeSwapMod::apply())\n",
// 		 region,R_Volume2(region),R_topoType(region));
// 	}
//     }
//     PList_delete(mvRgns);
//     PList_delete(edRgns);
// #endif
//   }

  fromMeshTools::Layer_E_swap(mesh, edges, conf, function_CB, userData_CB, newRegs); 

#ifdef DEBUG
  pRegion region;
  void *iter;
  iter=0;

  int iNeg = 0;
  while( region=(pRegion)PList_next(*newRegs,&iter) ) {
    if( R_Volume2(region) < 2.e-16 )
    {
      iNeg = 1;
      printf("Error: 2. region %p: R_Volume2=%.12e [rTopoType=%d] (layerEdgeSwapMod::apply())\n",
	     region,R_Volume2(region),region->getType());

      pPList rverts = R_vertices(region, 0);
      pVertex pVertexVtx;
      for (int iVtx = 0; iVtx < PList_size(rverts); ++iVtx)
      {
        pVertexVtx = (pVertex)PList_item(rverts, iVtx);
      }
    }
  }
/*  
  if (iNeg)
  {
    iter=0;
    std::vector<pRegion> VecBLRegs;
    while( region=(pRegion)PList_next(*newRegs,&iter) ) {
      if (EN_levelInBL(region) == 9 || EN_levelInBL(region) == 10)
        VecBLRegs.push_back(region);
    }
    write_3Dpart_vtu("RegsOnTopSwapped", VecBLRegs);
  }
*/
#endif

  return 1;
}

/*
  calculate max/min edge length square of new edges of the c'th swap configuration
  return the number of new edges    
*/
//extern "C" SwapConfig sc;
extern SwapConfig sc;

int layerEdgeSwapMod::E_swpNewEdges(double *maxlen, double *minlen)
{
  pVertex rvert[8];
  int     i,j,t,c2;
  double LL;

  *maxlen=0;
  *minlen=1e14;

  /* check if swap configuration already available */
  if (sc.edge != interfaceEdge)
    if (!fromMeshTools::E_numSwpCfg(interfaceEdge))
      return -1;

  if (!conf && !sc.nbr_triangles) {
    /* This is the special case where only configuration is valid       */
    /* unless the resulting mesh will violate topological compatibility */
    /* (this is checked during the actual swap operation)               */
    // return 1;

    cout<<"\nError in layerEdgeSwapMod::E_swpNewEdges()"<<endl;
    cout<<"special case of E_swp2Fac detected in bdry. layer mesh"<<endl;
    exit(0);
  }

  if (conf >= sc.nbr_trianguls)
    return -1;

  /* Have to find the c'th *topologically valid* configuration */
  for (c2 = 0, j = -1; c2 < sc.nbr_trianguls; c2++) {
    if (sc.topoValidCfg[c2]) j++;
    if (j == conf) break;
  }

  /* evaluate the triangles of the c'th configuration */
  for (j=0; j < sc.nbr_triangles_2; j++) {
    t = sc.trianguls[c2][j];

    for(i=0;i<3;i++)
      rvert[i] = sc.pverts[sc.triangles[t][i]];

    for(i=0; i<3; i++)
      if(!E_exists(rvert[i],rvert[(i+1)%3])) {
	LL = pSizeField->lengthSq(rvert[i],rvert[(i+1)%3]);
        if(LL > *maxlen)   *maxlen=LL;
	if(LL < *minlen)   *minlen=LL;
      }
  }

  /* it could return 0 if no new edge after swap */
  /* note when this happen, maxlen and minlen are initialized, but not assigned a value */
  return sc.nbr_triangles_2-1;
}
