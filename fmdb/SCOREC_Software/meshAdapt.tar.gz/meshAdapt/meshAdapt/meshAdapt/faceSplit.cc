#include <iostream>
#include <set>

#include "FMDB_Internals.h"
#include "templateRefine.h"

using std::cout;
using std::endl;

using std::set;

int countQFaces;

int meshTemplate::EN_getSplitID(pEntity entity) 
{
  int id;
  if(!EN_getDataInt((pEntity)entity,split_id,&id))
    id = EN_id(entity);
  return id;
}

void meshTemplate::EN_setSplitID(pEntity entity, int id) 
{
  if(!EN_getDataInt((pEntity)entity,split_id,&id))
    EN_attachDataInt(entity,split_id,id);
  else
    EN_modifyDataInt(entity,split_id,id);
}

pVertex meshTemplate::F_oppVtxToEdge(pFace face, pEdge edge) {
  if(F_numEdges(face)!=3) {
    cout<<"\nError in F_oppVtxToEdge()..."<<endl;
    cout<<"face is NOT a tri."<<endl;
    exit(0);
  }

  int offset = -1;
  for(int iEdge=0; iEdge<3; iEdge++) {
    if(edge==F_edge(face,iEdge)) {
      offset = iEdge;
      break;
    }
  }

  if(offset==-1) {
    cout<<"\nError in F_oppVtxToEdge()..."<<endl;
    cout<<"could NOT find edge in tri."<<endl;
    exit(0);
  }

  offset = (offset+1)%3;
  return E_vertex(F_edge(face,offset),F_edgeDir(face,offset));
}

pVertex meshTemplate::F_getFirstVtx(pFace face) {
  pPList fverts = F_vertices(face,1);
  pVertex firstVtx = (pVertex)PList_item(fverts,0);
  PList_delete(fverts);
  return firstVtx;
}

pEdge meshTemplate::F_commonEdge(pFace face1, pFace face2) {

  int numEdges;
  pEdge edge, cedge = 0;
  set<pEdge> edges1;

  numEdges = F_numEdges(face1);
  for(int iEdge=0; iEdge<numEdges; iEdge++)
    edges1.insert(F_edge(face1,iEdge));

  numEdges = F_numEdges(face2);
  for(int iEdge=0; iEdge<numEdges; iEdge++) {
    edge = F_edge(face2,iEdge);
    if(edges1.find(edge)!=edges1.end()) {
      cedge = edge;
      break;
    }
  }

  return cedge;
}

pVertex meshTemplate::F_getMaxIDVtx(pFace face) {
  int maxID = -1000000000, id;
  pVertex maxIDVtx =0, fvert;
  void *temp =0; 
  pPList fverts = F_vertices(face,1);
  while(fvert = (pVertex)PList_next(fverts,&temp)) {
    id = EN_id((pEntity)fvert);
    if(id>maxID) {
      maxID = id;
      maxIDVtx = fvert;
    }
  }
  PList_delete(fverts);
  return maxIDVtx;
}

pFace meshTemplate::R_wedgeOppTriFace(pRegion region, pFace face) {

  if(region->getType() != PRISM) {
    cout<<"\nError in R_wedgeOppTriFace()..."<<endl;
    cout<<"region is NOT a wedge\n"<<endl;     exit(0);
  }

  if(!R_inClosure(region,(pEntity)face)) {
    cout<<"\nError in R_wedgeOppTriFace()..."<<endl;
    cout<<"face is NOT in closure of the region\n"<<endl;
    exit(0);
  }

  if(F_numEdges(face)!=3) {
    cout<<"\nError in R_wedgeOppTriFace()..."<<endl;
    cout<<"face is NOT a tri.\n"<<endl;
    exit(0);
  }

  int mapFaceInd[2] = {0,4};   pFace oface = 0;
  for(int iFace=0; iFace<2; iFace++) {
    if(face==R_face(region,mapFaceInd[iFace])) {
      oface = R_face(region,mapFaceInd[1-iFace]);
      break;
    }
  }

  return oface;
}

int meshTemplate::check_is_face_split(pFace face) 
{
  pPList plist;
  if(EN_getDataPtr((pEntity)face,ptr_reff,(void **)&plist))
    return 1;
  else
    return 0;

  return 0;
}


pVertex meshTemplate::getMinVtxIdByOwner(pEdge edge)
{
  int iOwnerPart[2];
  FMDB_Ent_GetOwnPartID(E_vertex(edge,0), pmesh, &iOwnerPart[0]);
  FMDB_Ent_GetOwnPartID(E_vertex(edge,1), pmesh, &iOwnerPart[1]);

  /// Compare owners first using the following logic: minimum owner has the priority
  if (iOwnerPart[0] < iOwnerPart[1])
    return E_vertex(edge,0);
  else if (iOwnerPart[0] > iOwnerPart[1])
    return E_vertex(edge,1);
  else /// (iOwnerPart[0] == iOwnerPart[1])
  {
    if(EN_getSplitID((pEntity)E_vertex(edge,0))<EN_getSplitID((pEntity)E_vertex(edge,1)))
      return E_vertex(edge,0);
    else
      return E_vertex(edge,1);
  }
}

pPList meshTemplate::get_tri_faces_of_quad(pFace face, pEdge edge, pVertex vertex) 
{
  pPList plist;
  if(EN_getDataPtr((pEntity)face,ptr_reff,(void **)&plist))
    return plist;

  if(vertex && !F_inClosure(face,(pEntity)vertex)) {
    cout<<"\nError in get_tri_faces_of_quad()..."<<endl;
    cout<<"vertex is NOT in closure of the face\n"<<endl;
    exit(0);
  }

  if(edge && !F_inClosure(face,(pEntity)edge)) {
    cout<<"\nError in get_tri_faces_of_quad()..."<<endl;
    cout<<"edge is NOT in closure of the face\n"<<endl;
    exit(0);
  }

    countQFaces++;

    plist = PList_new();

    pGEntity g_entity = F_whatIn(face);

    pEdge edges[5];   // five edges to create two new tri. faces
    pEdge f_edges[3]; // three edges to create a new tri. face
    int f_dirs[3];

    pFace faces[2]; // two new faces

    int offset, offset_edirs[4];
    pVertex minIDVtx, otherVtx;

    if(vertex)
      minIDVtx = vertex;
    else {
      if(!edge) {
        cout<<"\nError in get_tri_faces_of_quad()..."<<endl;
        cout<<"edge or vertex is NOT specified for unsplit quad. face\n"<<endl;
        exit(0);
      }

      minIDVtx = getMinVtxIdByOwner(edge);
    }

    pPList fverts = F_vertices(face,1);
    for(int iVert=0; iVert<4; iVert++) {
      if(minIDVtx==(pVertex)PList_item(fverts,iVert)) {
	offset = iVert;
	otherVtx = (pVertex)PList_item(fverts,(offset+2)%4);
	for(int iEdge=0; iEdge<4; iEdge++) {
	  int index = (iEdge+offset)%4;
	  edges[iEdge] = F_edge(face,index);
	  offset_edirs[iEdge] = F_edgeDir(face,index);
	}
	break;
      }
    }

    edges[4] = M_createE(pmesh, minIDVtx, otherVtx, g_entity);

    f_edges[0] = edges[4]; f_edges[1] = edges[0]; f_edges[2] = edges[1];
    f_dirs[0] = 0; f_dirs[1] = offset_edirs[0]; f_dirs[2] = offset_edirs[1];
    faces[0] = M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    f_edges[0] = edges[4]; f_edges[1] = edges[2]; f_edges[2] = edges[3];
    f_dirs[0] = 1; f_dirs[1] = offset_edirs[2]; f_dirs[2] = offset_edirs[3];
    faces[1] = M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    PList_append(plist,(void *)edges[4]);
    PList_append(plist,(void *)faces[0]);
    PList_append(plist,(void *)faces[1]);
    EN_attachDataPtr((pEntity)face,ptr_reff,(void *)plist);

#ifdef MA_PARALLEL
#ifdef AOMD_ 
    pmEntity* mCB;
    mCB = EN_getCommonBdry((pEntity)face);
    if( ! mCB )
      return plist;

    // set common boundary information first
    EN_setCommonBdry((pEntity)edges[4], mCB);
    EN_setCommonBdry((pEntity)faces[0], mCB);
    EN_setCommonBdry((pEntity)faces[1], mCB);

    entities_to_update.push_back((pEntity)face);
#endif  // PAOMD
#endif  // MA_PARALLEL

    return plist;
}

void meshTemplate::delete_face(pFace face) 
{

  if(!F_region(face,0) && !F_region(face,1)) 
  {
    pPList plist;
    if(EN_getDataPtr((pEntity)face,ptr_reff,(void **)&plist)) 
    {
      EN_deleteData((pEntity)face,ptr_reff);
      PList_delete(plist);
    }

    M_removeFace(pmesh, face);
  }

}
