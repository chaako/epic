#ifndef _H_ADAPTUTIL
#define _H_ADAPTUTIL

#include "AdaptTypes.h"
#include "MeshTools.h"
#include "scorecSSList.h"
#include "PList.h"
#include <iostream>
#include <vector>
#include <string>

#define UPPERLENSQBOUND 2.25
#define LOWERLENSQBOUND 0.25

#define SNAP_UPPERLENSQBOUND 2.25
#define SNAP_LOWERLENSQBOUND 0.25

#define QUALITYTHRESHOLD 0.027
#define FACE_QUALITYTHRESHOLD 0.04

#define QUALITYFRACTION 0.001
#define SNAP_QUALITYFRACTION 0.001

#define THICKNESSGRADEFACTORAROUNDGC 0.2
#define THICKNESSGRADEFACTORONGC 1.5

using std::vector; 

namespace adaptUtil {

#ifdef AOMD_
#ifdef MA_PARALLEL
  void M_checkRemoteCopies(pMesh);
  void EN_sendRemoteCopy(pMesh,pEntity);
  void checkFace(pMesh mesh);
#endif
#endif
  // output
  void Info(int, std::string);  
  void Info(std::string, int);
  void Info(double, std::string);
  void Info(std::string);
  void Error(std::string);
  void Warning(std::string);

  // functions related to the parametric space
  void M_checkPar(pMesh,int);
  int V_checkPar(pVertex,int);
  int V_reparamOnGFace(pVertex vert, pGFace gf, double *par);
  int V_reparamOnGEdge(pVertex vert, pGEdge ge, double *par);
  int V_getNormal(pGFace,pVertex,double *);
  int F_fixPeriodicParams(pGFace gface, double tol, double[3][3]);
  int F_checkGeoSim(pPList *F_vertices, pGFace gface);
  int F_checkGeoSim(pFace face);
  int F_checkGeoSim(pFace face, pMeshDataId ptr_geoSim);
  pPList F_verticesOutofMesh(pFace);
  int Par_checkGeoSim(pGFace, double, double[3][3]);
  void M_checkGeoSim(pMesh);
  int ifDegenerated(pGFace, double *, double);
  int E_swpCheckPer(pEdge);
  int R_countLongLengthSq(pRegion region,pSField pSizeField, double upperBoundSq);
  double R_maxTominLengthSq(pRegion,pSField);
  void ProcessNewBdryVertex(pMesh,pVertex);

  // with respect to vertex motion and visible region calculation
  int VisibleRegion(pVertex, SCOREC::Util::scorecSSList<double *> &);
  void DeleteVisibleRegion(SCOREC::Util::scorecSSList<double *> &);
  int isDuplicated(double *, SCOREC::Util::scorecSSList<double *> &, double );
  void move_vertex(pVertex,double[3]);
  void move_vertex(pVertex,double *, CBFunc_move, void *);
  double V_worstShp(pShapeBase,pVertex);
  double E_worstShp(pShapeBase, pPList, pEdge);
  
  // cavity retriangulation related
  void V_bdryfacesOngface(pVertex,pGEntity,pPList *);
  pGEntity V_AdjGRegion(pVertex);
  int RemoveAVertex(pMesh, pSField, pVertex, int, int, pPList, CBFunction, void *);
  pPList R_adjRegions(pRegion);
  int isCavityClosed(pPList *);
  int ifNeedExpand(pFace,pEdge,double *);
  pFace F_getFmFaces(pPList &, pEdge);
  pFace F_getFmFaces(SCOREC::Util::scorecSSList<pFace> &, pEdge);
  double P_sqrDistToSegment(double Lxyz0[3],double Lxyz1[3], double pxyz[3]);
  double V_sqrDistToFace(pVertex,  pFace);
  double V_sqrDistToFace_2(pVertex,  pFace);
  double P_sqrDistToTri(double[3], double[3], double[3], double[3]);
  double M_sqrDistEdges(pEdge,pEdge);
  double XYZ_sqrDistSegments(double[3], double[3], double[3], double[3]);
  
  // mesh size field related
  void M_checkRatio(pMesh mesh);
  void M_checkSize(pMesh mesh,pSField,double &max,double &min);
  void M_checkSizeBL(pMesh mesh,pSField,double &max,double &min);
  void R_info(pRegion, MeanRatio *, pSField);
  long eigen (double[3][3], double[3][3], double[3]);
  double trace (double[3][3]);
  double trace2 (double[3][3]);
  double det (double[3][3]);
  long FindCubicRoots(const double[4], double[3]);
  long FindQuadraticRoots(const double, const double, double[3]);
  long NullSpace(const double *, double *, double, long);
  int checkUnitaryOthoganal(double e[3][3]);

  // others
  pMesh copyRegions(pPList, pEntity, pEntity);
  pMesh copyRegions(pPList, vector<pEntity>, vector<pEntity>&, pSField); 

  double E_lengthSq(pEdge edge);
  double E_dOverH(pEdge edge, double xyz[3]);
  pFace F_exists_2(pEdge edge, pVertex vertex);
  void maxminEdgeLength(pSField, pVertex vd, double *max, double *min);
  double ParOnLinearEdge(double[2][3], double[3]);
  pRegion F_otherRgn(pFace, pRegion);
  int XYZ_InClosureOfLine(double[3], double[2][3]);
  int V_wrtFace(double*, const pVertex &, const pFace &);
  int XYZ_wrtFace(pFace face, double *xyz);
  int RelativeDirection(double *, double *);
  int RelativeDirection(double *n1, double *n2, double flatAngle);
  pEdge CommonEdge(pFace, pFace);
  pFace E_otherBdryFace(pEdge, pFace);
  int V_numGFaces(pVertex);

  // Calculate the mesh size associated with vertex. called from MA_Vtx_Size() defined in MA.h
  int Vtx_Size(pVertex pVertexVtx, double dAnisoSize[3][3]);

/*    void M_checkConn_2(pMesh mesh); */
/*    void M_checkConn(pMesh,SSList<pVertex> *); */
/*    void improveConn(pMesh, pSField, SSList<pVertex> *); */
  int V_getSwapEdges(pVertex,pPList *);
  pEdge getLongestEdge(pPList edlist, pSField field);
  double F_volumeRatio(pFace);
  int F_ratio2(pFace face, double &lenRatio, double &alpha);
  int E_volumeRatio(pEdge,double *,double *, double *);
  double V_worstVolumeRatio(pVertex, std::vector<pFace> *);
  void M_connectivityAnalysis(pMesh);

  void centroidOfMRegion(pRegion rgn, double *cent);
  void centroidOfMFace(pFace face, double *cent);
  void centroidOfMEdge(pEdge edge, double *cent);
  void centroidOfMVertex(pVertex vertex, double *cent);
  void centroidOfCavity(pVertex vertex, double *cent);
  void centroidOfCavity2(pEdge edge, double *cent);

  int getTetInfo(pRegion,pFace,pVertex,int,pEntity[4],double[4],double[3]);
  int F_longestEdge(pSField, pFace, pEdge *, double *);
  double V_shortestLength(pVertex);
  void P_projOnTriPlane(double fxyz[3][3], double pxyz[3], double *proxyz);
  int indexOfMin(double, double, double);
  int evalEswp(pEswapMod, pMeshMod *, double *, double);
  int evalSpltClps(pEsplitClpsMod, pMeshMod *, double *, double);
  int evalEclps(pSField,pEclpsMod, pMeshMod *, double *,double);
  double F_angleToGNormal(pFace);
  double F_angleToGNormal(pVertex, pVertex, pVertex, pGFace);
  void E_swpGetOriAngles(pEdge,double *,double *);

  pPList getCavityClosure(pPList,pMeshDataId);
  pPList R_edAdjFcs(pRegion,pEdge);

  template <class T> void PList_appSSList(pPList *, SCOREC::Util::scorecSSList<T> *, int);
  template <class T> void SSList_appPList(SCOREC::Util::scorecSSList<T> *, pPList *,int);
 
  struct bptxyz
  {
    double xyz[3];
  };

 
 //info & debug use
  void R_edgesInfo(pRegion, pSField);
  void viewMetricField(pMesh, pSField);
  void G_info(pGModel);
  int GF_inClosure(pGFace, pGEntity); 
  double GE_Tolerances(pGEdge);
  double GF_Tolerances(pGFace);
  void GF_info(pGFace);
  void F_shapeInfo(pFace);
  void M_checkShape(pMesh,pSField);
  void M_checkShape2D(pMesh, pSField);
  void ifMeshDataIdCleaned(pMesh, pMeshDataId);

  int isfacefront(pFace,pGModel,pGRegion *);
  int ValidCheck(pVertex, pVertex, double[3]);
  int ValidCheck(pVertex);
  
  template <class T> void SSList_printx(SCOREC::Util::scorecSSList<T> &);

  template <class T>
  void PList_appSSList(pPList *list1,SCOREC::Util::scorecSSList<T> *list2,int checkDuplicate) {
    T ent;
    
    if ( *list1==NULL ) {
      *list1 = PList_new() ;
      checkDuplicate = 0 ;
    }

    SCOREC::Util::scorecSSListIter<T> iter(*list2);
    while( iter(ent) ) {
      if (checkDuplicate) {
	PList_appUnique(*list1,ent) ;
      }
      else
	PList_append(*list1,ent) ;
    }
    return;
  }

  template <class T>
  void SSList_appPList(SCOREC::Util::scorecSSList<T> *list1, pPList *list2,int checkDuplicate) {
    void *temp=0;
    T ent;

    while( ent=(T)PList_next(*list2,&temp) ) {
      if (checkDuplicate) {
	(*list1).appendUnique(ent);
      }
      else
	(*list1).append(ent);
    }
    return;
  }

  template <class T>
  void SSList_appSSList(SCOREC::Util::scorecSSList<T> *list1, SCOREC::Util::scorecSSList<T> *list2,int checkDuplicate) {
    void *temp=0;
    T ent;

    SCOREC::Util::scorecSSListIter<T> iter(*list2);
    while( iter(ent) ) {
      if (checkDuplicate) {
	(*list1).appendUnique(ent);
      }
      else
	(*list1).append(ent);
    }
    return;
  }

  template <class T>
  void SSList_printx(SCOREC::Util::scorecSSList<T> &inputlist) {
    SCOREC::Util::scorecSSListIter<T> iter(inputlist);
    T ent;
    
    std::cout<<"present list size: "<<inputlist.size()<<std::endl;
    std::cout<<"entities in list: ";
    while(iter(ent))
      std::cout<<ent<<" ";
    std::cout<<std::endl;
    return;
  }  

}

#endif

