#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <fstream>
#include <iostream>

#ifdef PARALLEL
#include "ParUtil.h"
#endif

#ifdef PARASOLID
#include "parasolid_kernel.h"
#include "MeshSimParasolid.h"
#endif

#ifdef AOMD_
#include "AOMD.h"
#include "AOMD_Internals.h"
#include "MeshTools.h"
#endif

//  int CB_count=0;

//  extern "C" void myCallback(pPList oldCavity, pPList newcavity,void *userdata, 
//  			   modType type, pEntity ent)
//  {
//    CB_count++;
//    if( ent )
//      printf("modType=%d   EN_type=%d   address=%p\n",type, EN_type(ent), ent);
//    else
//      printf("modType=%d\n",type);

//    PList_printx(oldCavity);
//    PList_printx(newcavity);
//  }

/* size field for plate.sms  */
//  int setSizeField(pMesh mesh,pMField pSizeField)
//  {
//    pVertex vt;
//    double size, xyz[3];
//    VIter vit=M_vertexIter(mesh);
//    while( vt=VIter_next(vit) ) {
//      V_coord(vt,xyz);
//      if( xyz[1]<=2.0 )
//        size=1-0.475*xyz[1];
//      else if( xyz[1]<=4.5 )
//        size=pow(20.,(2*xyz[1]-9.)*.2);
//      else if( xyz[1]<=7.0 )
//        size=pow(5.,(9.0-2.0*xyz[1])*.2);
//      else 
//        size=.2+0.8*pow((xyz[1]-7)*0.5,4.);
//      pSizeField->setSize((pEntity)vt,size);
//    }
//    VIter_delete (vit);

//    pSizeField->smooth(2.0);
//  }
 

/* size field for cube.msh */
int setSizeField(pMesh mesh, pMField pSizeField)
{
  double L = 10.0;
  double R = 0.8;

  pVertex vt;
  double size, xyz[3];
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    double circle= fabs(xyz[0] * xyz[0] +
      xyz[1] * xyz[1] +
      xyz[2] * xyz[2] - R*R);
    size = .1 * fabs(1. - exp (-circle*L)) + 1.e-3;
    pSizeField->setSize((pEntity)vt,size);
  }
  VIter_delete (vit);
  return 1;
}


int main(int argc, char* argv[])
{  

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->init (argc,argv);
#endif

 if ( argc!=3 ) { 
   cerr<<"Usage: "<<argv[0]<<" meshfile "<<" <# of iterations> "<<endl;
  return 0;
 }
 
  char model_file[256];
  char mesh_file[256];
  char outmesh[256];
  char without_extension[256];

  snprintf(without_extension,strlen(argv[1])-3,"%s",argv[1]);
  sprintf(mesh_file,"%s",argv[1]);

  MS_init();

#ifdef PARASOLID
  sprintf(model_file,"%s.xmt_txt",without_extension);
  pGModel model=GM_createFromParasolidFile(model_file);
#endif
#ifdef NOMODEL
  sprintf(model_file,"%s.xmt_txt",without_extension);
  pGModel model=GM_createFromParasolidFile(model_file);
#endif

  pMesh mesh=MS_newMesh(model);
  pMField field=new metricField(mesh);
  M_load(mesh,mesh_file);

#ifdef AOMD_
  M_SetRepresentationToOneLevel(mesh);
#endif

  //  AdaptUtil::M_checkShape(mesh);

  MeshAdapt rdr(mesh,field,0,1);  // snap off; do refinement only
  //  rdr.setCallback(myCallback,0);

//    VIter vit=M_vertexIter(mesh);
//    pVertex vt;
//    while( vt=VIter_next(vit) )
//      rdr.setConstraint((pEntity)vt);
//    VIter_delete (vit);

//    EIter eit=M_edgeIter(mesh);
//    pEdge edge;
//    while( edge=EIter_next(eit) )
//      rdr.setConstraint((pEntity)edge);
//    EIter_delete (eit);

//    RIter rit=M_regionIter(mesh);
//    pRegion rgn;
//    while( rgn=RIter_next(rit) )
//      rdr.setConstraint((pEntity)rgn);
//    RIter_delete (rit);

//    pGFace gf;
//    gf=(pGFace)GM_entityByTag(model, Gface, 130);
//    rdr.setConstraint((pGEntity)gf);
//    gf=(pGFace)GM_entityByTag(model, Gface, 2);
//    rdr.setConstraint((pGEntity)gf);

  rdr.run_2(atoi(argv[2]),1, setSizeField);

  sprintf(outmesh,"%s-refined",without_extension);
  M_writeSMS(mesh,outmesh,2);
  
  M_delete(mesh);
  GM_delete(model);
  MS_exit();    

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->Finalize();
#endif
  return 1;
} 


