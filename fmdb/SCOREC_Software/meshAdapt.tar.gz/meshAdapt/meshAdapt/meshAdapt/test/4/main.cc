#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "parasolid_kernel.h"
#include "PWLinearSField.h"
#include <stdlib.h>
#include <stdio.h>


#include <math.h>
#include <fstream>
#include <iostream>

#ifdef PARALLEL
#include "ParUtil.h"
#endif

#ifdef AOMD_
#include "AOMD.h"
#include "AOMD_Internals.h"
#include "MeshTools.h"
#include "modelerParasolid.h"
#else
#include "SimParasolidKrnl.h"
#endif


// anisotropic field one - no rotation, but with jumps
//  void setSizeField(pMesh mesh, pMField field, double lower, double up)
//  {
//    pVertex vt;
//    double xyz[3],h[3], dirs[3][3];
//    VIter vit=M_vertexIter(mesh);
//    while( vt=VIter_next(vit) ) {
//      V_coord(vt,xyz);

//      dirs[0][0]=1.0;
//      dirs[0][1]=0.0;
//      dirs[0][2]=0.0;
//      dirs[1][0]=0.0;
//      dirs[1][1]=1.0;
//      dirs[1][2]=0.0;
//      dirs[2][0]=0;
//      dirs[2][1]=0;
//      dirs[2][2]=1.;
    
//      if( xyz[0]<lower  ||  xyz[0]>up )
//        h[0]=0.1;
//      else
//        h[0]=0.005;
    
//      if( xyz[1]<lower  ||  xyz[1]>up )
//        h[1]=0.1;
//      else
//        h[1]=0.005;
    
//      h[2] = 1.0;

//      field->setMetric((pEntity)vt,dirs,h);

//    }
//    VIter_delete (vit);
//  }


// anisotropic size field two: with rotation
double R; 
double L;
int setSizeField(pMesh mesh, pSField field, void *)
{
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], norm;
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    double circle= fabs(xyz[0] * xyz[0] +
      xyz[1] * xyz[1] +
      xyz[2] * xyz[2] - R*R);
    h[0] = .1 * fabs(1. - exp (-circle*L)) + 1.e-3;
    h[1] = .1;
    h[2] = 1.0;

    norm=sqrt(xyz[0]*xyz[0]+xyz[1]*xyz[1]);
    dirs[0][0]=xyz[0]/norm;
    dirs[0][1]=xyz[1]/norm;
    dirs[0][2]=0;
    dirs[1][0]=-1.0*xyz[1]/norm;
    dirs[1][1]=xyz[0]/norm;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.;

    ((PWLinearSField *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);
  return 1;
}


int main(int argc, char* argv[])
{  

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->init (argc,argv);
#endif

 if ( argc!=3 ) { 
   printf("Usage: %s  meshfile <# of iterations>\n",argv[0]);
   return 0;
 }
 
  char model_file[256];
  char mesh_file[256];
  char outmesh[256];
  char without_extension[256];

  snprintf(without_extension,strlen(argv[1])-3,"%s",argv[1]);
  sprintf(mesh_file,"%s",argv[1]);

  MS_init();

  sprintf(model_file,"%s.xmt_txt",without_extension);
  pGModel model=GM_createFromParasolidFile(model_file);
  pMesh mesh=MS_newMesh(model);
  pSField field=new PWLinearSField(mesh);
  M_load(mesh,mesh_file);

#ifdef AOMD_
  M_SetRepresentationToOneLevel(mesh);
#endif

  meshAdapt rdr(mesh,field,0,1);  // snap off; do refinement only
  //  rdr.setCallback(myCallback,0);
  L = 2;
  R = 0.45;
  rdr.run(atoi(argv[2]),1, setSizeField);

  sprintf(outmesh,"%s-refined",without_extension);
  M_writeSMS(mesh,outmesh,2);
  
  delete field;
  M_delete(mesh);
  GM_delete(model);
  MS_exit();    

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->Finalize();
#endif
  return 1;
} 


