#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "visUtil.h"
#include "PWLinearSField.h"
#include "fromMeshTools.h"
#include <stdlib.h>
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>
#include <strstream>

#ifdef MA_PARALLEL
#include "ParUtil.h"
#include "mpi.h"
#endif

// #include "parasolid_kernel.h"
// #include "modelerParasolid.h"

#include "modelerDiscrete.h"
#include "DiscreteModel.h"

#include "M_writeVTKFile.h"

#ifdef AOMD_
#include "FMDB.h"
//#include "mAOMD.h"
#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#include "MeshTools.h"
#include "SF_MigrationCallbacks.h"
#endif

#include "BLUtil.h"
#include "FMDB_EntGrp.h"

// #define FILE "/users/xli/stop.check"

using std::endl; using std::cout;
using std::cerr;
using std::strstream;

extern pMeshDataId blEdgeTypeID, blFaceTypeID, blRegionTypeID;

int sizefield(pMesh,pSField,void *);
int planarShock(pMesh,pSField);
int cylindericalShock(pMesh,pSField);
int sphericalShock(pMesh, pSField);
int ellipsoidalShock(pMesh, pSField);
int twoSphericalShocks(pMesh,pSField);
int twoSphericalShocksBIG(pMesh,pSField);
void uniformRefine(pMesh, meshAdapt*);
int platemetric(pMesh , pSField);
int uniform(pMesh , pSField);
int planar_uni(pMesh , pSField);
int planarShockBL(pMesh mesh, pSField field);
int planarShockBLThickness(pMesh mesh, pSField field);
int airbubbles(pMesh,pSField);
int airbubbles_80(pMesh,pSField);
int movingbubbles(pMesh,pSField);
int channel(pMesh mesh, pSField field);
int parabol(pMesh mesh, pSField field);
void M_meditWrite2d(pMesh, char*); 
void M_meditWrite3d(pMesh, char*);

int sf;  // size field indicator
double nSplit;
double uniformSize;
double global_len[2];

  extern "C" void trace_start(void);               // Added by Alex for MPI trace on 02.21.2008
  extern "C" void trace_stop(void);
  extern "C" void summary_start(void);
  extern "C" void summary_stop(void);


void
catchDebugger() {
  static volatile int debuggerPresent =0;
  while (!debuggerPresent ); // assign debuggerPresent=1 or set debuggerPresent=1
}

int main(int argc, char* argv[])
{ 
#ifdef MA_PARALLEL 
  ParUtil::Instance()->init (argc,argv);
#endif

#ifdef DEBUG 
#ifdef MA_PARALLEL
  int myrank = ParUtil::Instance()->rank();
  int str_len = 0;
  char *strCatchDebugger = 0;
  if(myrank==0) {
    strCatchDebugger = getenv("catchDebugger");
    if ( strCatchDebugger )
      str_len = strlen(strCatchDebugger)+1;
  }
  MPI_Bcast( &str_len, 1, MPI_INT, 0, MPI_COMM_WORLD );
  if(str_len) {
    if(myrank!=0)
      strCatchDebugger = new char[str_len];
    MPI_Bcast( strCatchDebugger, str_len, MPI_CHAR, 0, MPI_COMM_WORLD );
  }

  if ( strCatchDebugger ) {

    if(myrank==0)
      printf(" Debugger Process initiating\n");
    
    int processid = getpid();    
    printf("\n [%d] process ID : %d\n",myrank,processid);

    int processchild = fork();
    char exec_string[512];
    sprintf(exec_string,"xterm -e gdb -pid %d %s\n",processid,argv[0]);
    if( processchild == 0 ) {
      system( exec_string );
      exit(0);
    }
    else if( processchild==-1 )
      printf(" \nerror in fork while creating child process...\n");
    if( processchild != 0 )
      printf(" child process [pid=%d] : %s\n",processchild,exec_string);

    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    if(myrank!=0)
      delete [] strCatchDebugger;
    catchDebugger();
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  }
#endif
#endif
  
  if ( argc < 4 ) { 
    printf("Usage: %s filename sizefield nSplit \n\n",argv[0]);
    // printf("Usage: %s filename sizefield iterations \n\n",argv[0]);
    printf("filename: a mesh file name for a cubic domain from (0,0,0)->(1,1,1)\n");
    printf("          torusHoles.sms - 2D model to test AOMD only\n");
    printf("sizefield: An integer to indicate a defined mesh size field:\n");
    printf("           1 - a planar shock at x=0.5 \n");
    printf("           2 - a cylinderical shock centered at x=0 \n");
    printf("           3 - a spherical shock \n");
    printf("           4 - two spherical shocks \n");
    printf("           5 - an ellipsoidal shock \n");
    printf("           6 - two spherical shocks BIG \n");
    printf("nSplit: the number of doublings in mesh size in each direction\n\n"); 
    // printf("iteration: the iterations allowed in case adapation is not converged\n\n"); 
    return 0;
  }

  
  char test_dir[1024];
  char model_file[1024];
  char mesh_file[1024];
  char outmesh[1024];
  char without_extension[256];
  
  strcpy(test_dir,argv[1]);
  strcpy(model_file,test_dir);
  strcat(model_file,"geom.dmg");
  sf=atoi(argv[2]);
  nSplit = atof(argv[3]);
  int niter= 200; // atoi(argv[3]);

  MS_init();
//  pGModel model=GM_createFromParasolidFile(model_file);
  pGModel model =GM_createFromDmgFile(model_file);
//  pGModel model = 0;

  pMesh mesh=MS_newMesh(model);
//  pSField field=new PWLsfield(mesh);
//  sprintf(mesh_file,"geom_uni.sms");                                    // Mod by Alex to test uniform mesh on 02.18
  double t1=ParUtil::Instance()->wTime();

//  int predLB = 0;  // load Predictive LB'ed mesh

//  int NP_size;                            // Modified by Alex 01.22.08 to load partitioned mesh already
//  MPI_Comm_size(MPI_COMM_WORLD,&NP_size);

/*
  if(NP_size < 2)
  	M_load(mesh,mesh_file);
  else{
	char mFile[32], nProc[4];
        strcpy(mFile,"mesh_uni_17m/geom_uni_");
//        strcpy(mFile,"mesh_1k_proc_18k/geom.sms");
        sprintf(nProc,"%d",NP_size);
        strcat(mFile,nProc);
        if(predLB)
          strcat(mFile,"_PLB_.sms");
        else
          strcat(mFile,"_.sms");
11	PM_load(mesh,mFile);
  }
*/

  char nProc[8];
  strcpy(mesh_file,test_dir);

  if (P_size() > 1)
  {
    sprintf(nProc,"%d",P_size());
//  sprintf(nProc,"%d",1024);
    strcat(mesh_file,nProc);  
    strcat(mesh_file,"/geom.sms");
    PM_load(mesh,mesh_file);
  }
  else
  {
    strcat(mesh_file,"/geom.sms");
    M_load(mesh,mesh_file);
  }

//PM_write(mesh,"mesh_out");
//MPI_Barrier(MPI_COMM_WORLD);
//exit(0);

//strcat(mesh_file,"/geom.sms");
//AOMD_Util::Instance()->import(mesh_file, mesh);
//AOMD_Util::Instance()->import("mesh_out.sms", mesh);
//PM_load(mesh,"mesh_init.sms");
//PM_load(mesh,mesh_file);

//M_verify(mesh);
//M_checkAdj(mesh);
//M_writeVTKFile(mesh,"mesh_init");

//exit(0); 

//  printf("Constructing BLs...\n");

  /// This condition is hard-coded specificly for loading the mesh on 1 part and repartitioning it later. Something has to be done about that
//  if (!P_pid())
//    constructBLs(mesh);

//  if (!M_numEntGrps(mesh))
//    printf("PID %d has no EGs!!!!\n",P_pid());

/*
  zoltanCB zlb1;
  M_loadbalance(mesh, zlb1);


std::vector<pMesh> meshes;
meshes.push_back(mesh);
PM_write2(meshes,"geom.sms");
return 0;
*/

  /// This condition is hard-coded specificly for loading the mesh on 1 part and repartitioning it later. Something has to be done about that
//  if (P_pid())
//    constructBLs(mesh);

//PM_write(mesh,"mesh_init_noEGs");
//PM_write(mesh,"mesh_init");
//exit(0);

//  Mesh_InitBLs(mesh, model);
//  M_categorizeBLEntities(mesh);
//  M_unifyBLInterfaceOnCB(mesh);

//  M_assignBLLevelsToAllBLEnts(mesh);

//char vtkfiles[256];
//sprintf(vtkfiles,"mesh_init");
//M_writeVTKFile(mesh,"mesh_init");

 // int MRM[4][4] = {{ 1, 1, 1, 1},
  //                 { 1, 1, 1, 1},
  //                 { 1, 1, 1, 1},
  //                 { 1, 1, 1, 1}};
  // M_load_MRM(mesh,mesh_file,MRM);
  //  AOMD_Util::Instance()->import(mesh_file, mesh);  // for greedy MRM only

//  M_printNumEntities(mesh);
   double t2=ParUtil::Instance()->wTime();
   double t_load_madapt = t2 - t1;
/// cout<<"Proc"<<P_pid()<<": here is the mesh with dim "<<M_getMaxDim(mesh)<<endl;  
  if (P_pid()==0)
  { 
    std::cout<<"\n# mesh load = "<<P_size()<<"\n";
    std::cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
  }

//   char vtkfile[256];
//   sprintf(vtkfile,"vtkfiles");
//   M_writeVTKFile(mesh,vtkfile);

  // write the initial mesh in medit format
  //sprintf(outmesh,"%s",without_extension);
  //if( M_numRegions(mesh)!=0 ) 
  //  M_meditWrite3d(mesh,outmesh);
  //else 
  //  M_meditWrite2d(mesh,outmesh);

  //  M_checkAdj(mesh);
  //  adaptUtil::M_checkPar(mesh,0);

  EIter eit=M_edgeIter(mesh);
  pEdge edge;
  int numEdges = 0;
  double local_uniformSize = 0., local_len[2] = {1.0e10, 0.};
  while( edge=EIter_next(eit) ) {
    numEdges++;
    double len = sqrt(E_lengthSq(edge));
    local_uniformSize += len;
    if(len<local_len[0])
      local_len[0] = len;
    if(local_len[1]<len)
      local_len[1] = len;
 
    //printf("size = %f\n",sqrt(E_lengthSq(edge)));
  }
  EIter_delete(eit);
  local_uniformSize = local_uniformSize/numEdges; //sqrt(local_uniformSize)/numEdges;

#ifdef MA_PARALLEL
  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Allreduce(&local_uniformSize,&uniformSize,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
  //double global_len[2];
  local_len[1] *= -1.;
  MPI_Allreduce(local_len,global_len,2,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  local_len[1] *= -1.;
  global_len[1] *= -1.;
#else
  global_len[0] = local_len[0];
  global_len[1] = local_len[1];
#endif
  uniformSize /= P_size();
  if (P_pid()==0) 
    printf("min., avg., max. (sizes) = %f, %f, %f\n",global_len[0],uniformSize,global_len[1]);
  uniformSize = global_len[0]/2.25;//0.018;//0.004050;//0.003601;//global_len[0]/2.25;

  uniformSize = 0.1;

  if (P_pid()==0) 
    printf("uniformsize: %f\n\n",uniformSize);

  pMeshDataId fakeID = MD_newMeshDataId("fake ID");


//M_checkAdj(mesh);
//M_verify(mesh);
M_printNumEntities(mesh);

//  meshAdapt *rdr = new meshAdapt(mesh, Analytical, 2);  // snap on
  meshAdapt *rdr = new meshAdapt(mesh, Analytical, 1);
//  meshAdapt *rdr= new meshAdapt(mesh,field,0,0);  // snap off;
//  meshAdapt *rdr= new meshAdapt(mesh,NULL,0,1);
  
//  uniformRefine(mesh, rdr); 
 
  rdr -> setAlphaFactor(0.64);

  int predLBflag = 0;
  rdr->SetPreLBFlag(predLBflag); // turn on Predictiv_length_10_size_27m LB

  myTimer tt;
  t1=ParUtil::Instance()->wTime();
  if (!predLBflag)
  {
//    trace_start();
//    summary_start();
  }

//  rdr->run(1,1, sizefield);                   // Modified by Alex to debug on 02.05.08, should be niter instead of 1
for (int i = 0; i < 1; i++)
{
  rdr->run(5,1, sizefield);
//  rdr->run(atoi(argv[3]),1, sizefield);                     
}
//M_writeVTKFile(mesh,"mesh_out");
//M_printNumEntities(mesh);
//M_checkAdj(mesh);
//M_verify(mesh);

//  summary_stop();
//  trace_stop();
  t2=ParUtil::Instance()->wTime();

  //for (int i = 0; i < 1000000; i++);
  //MPI_Barrier(MPI_COMM_WORLD);

  t_load_madapt += t2 - t1;
  
  //  uniformRefine(mesh, rdr);
  delete rdr;
//  delete field;

  eit=M_edgeIter(mesh);
  numEdges = 0;
  local_uniformSize = 0.; local_len[0] = 1.0e10;  local_len[1] =  0.;
  while( edge=EIter_next(eit) ) {
    numEdges++;
    double len = sqrt(E_lengthSq(edge));
    local_uniformSize += len;
    if(len<local_len[0])
      local_len[0] = len;
    if(local_len[1]<len)
      local_len[1] = len;
  }
  EIter_delete(eit);
  local_uniformSize = local_uniformSize/numEdges; //sqrt(local_uniformSize)/numEdges;

#ifdef MA_PARALLEL
  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Allreduce(&local_uniformSize,&uniformSize,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
  //double global_len[2];
  local_len[1] *= -1.;
  MPI_Allreduce(local_len,global_len,2,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  local_len[1] *= -1.;
  global_len[1] *= -1.;
#else
  global_len[0] = local_len[0];
  global_len[1] = local_len[1];
#endif

  uniformSize /= P_size();
  if (P_pid()==0)
    printf("min., avg., max. (sizes) = %f, %f, %f\n",global_len[0],uniformSize,global_len[1]);


  MD_deleteMeshDataId(fakeID);

  // if (P_pid()==0) {
  //   printf("Total clock time: %f\n",tt.elapsedCPU());
  // }  
//  sprintf(outmesh,"%s-refined.sms",without_extension);
//    adaptUtil::M_checkShape(mesh,field);
#ifndef MA_PARALLEL
  M_checkAdj(mesh);
#endif

  //  visUtil::writeDX(mesh,field);
#ifndef MA_PARALLEL
  M_writeSMS(mesh,outmesh);
//#else
//  sprintf(outmesh,"part%d.msh",M_Pid());
//  std::ofstream o (outmesh);
//  AOMD_Util::Instance()->exportDGFile(o,mesh);
//  o.close();
#endif


  if (P_pid()==0)
  { 
    std::cout<<"\n# adaptation = "<<P_size()<<"\n";
    std::cout<<"TIME = "<<t2-t1<<" (sec)\n\n";

    std::cout<<"\n# meshload + adaptation = "<<P_size()<<"\n";
    std::cout<<"TIME = "<<t_load_madapt<<" (sec)\n\n";
    
  }
/*
  zoltanCB zlb;
  if (P_size() == 0)
    zlb.setAlgorithm(pmZoltanCallbacks::PARMETIS);
  else
    zlb.setParAlgorithm(pmZoltanCallbacks::AdaptiveRepart);
  double t3=ParUtil::Instance()->wTime();
  M_loadbalance(mesh,zlb);
  double t4=ParUtil::Instance()->wTime();

  // M_verify(mesh);  // add on 1217
  // M_checkAdj(mesh);

  if (P_pid()==0)
  { 
    std::cout<<"\n# loadbalance = "<<P_size()<<"\n";
    std::cout<<"TIME = "<<t4-t3<<" (sec)\n\n";
  }
*/
  M_printNumEntities(mesh);

//  M_writeSMS(mesh,"mesh_out.sms",2);                           
/*
  char out_dir[1024];
  strcpy(out_dir,argv[4]);
  strcpy(outmesh,out_dir);
  sprintf(nProc,"%d",P_size());
  strcat(outmesh,nProc);
  strcat(outmesh,"/geom.sms");
  PM_write(mesh,outmesh);
*/
//  strcpy(outmesh,test_dir);
//  strcat(outmesh,"out/mesh_out");
//  M_writeVTKFile(mesh,outmesh);
/*
  char vtkfile[256];
  sprintf(vtkfile,"mesh_out");
  t3=ParUtil::Instance()->wTime();
  M_writeVTKFile(mesh,vtkfile);
//  PM_write(mesh,"mesh_out.sms");
  t4=ParUtil::Instance()->wTime();

  if (P_pid()==0)
  { 
    std::cout<<"\n# write out VTK files = "<<P_size()<<"\n";
    std::cout<<"TIME = "<<t4-t3<<" (sec)\n\n";
  }
*/
  M_delete(mesh);
  GM_delete(model);
  MS_exit();    

#ifdef MA_PARALLEL
  ParUtil::Instance()->Finalize();
#endif
  return 1;
} 


int sizefield(pMesh mesh, pSField field, void *)
{
  switch( sf ) {
  case 1: planarShock(mesh,field); break;
  case 2: cylindericalShock(mesh,field); break;
  case 3: sphericalShock(mesh,field); break;
  case 4: twoSphericalShocks(mesh,field); break;
  case 5: ellipsoidalShock(mesh,field); break;
  case 6: twoSphericalShocksBIG(mesh,field); break;
  case 7: platemetric(mesh,field); break;
  case 8: uniform(mesh,field); break;
  case 9: planar_uni(mesh,field); break;
  case 10: planarShockBL(mesh, field); break;
  case 11: planarShockBLThickness(mesh, field); break;
  case 12: airbubbles(mesh,field);break;
  case 13: movingbubbles(mesh,field);break;
  case 14: airbubbles_80(mesh,field);break;
  case 15: channel(mesh, field); break;
  case 16: parabol(mesh, field); break;
  default:
    printf("Error: mesh size field not defined\n");
    exit(0);
  }
  return 1;
}


int planarShock(pMesh mesh,pSField field)
{
  double R=.5;
  double L=1.;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3];
  double maxxyz[3] = {-1.e10,-1.e10,-1.e10}, minxyz[3] = {1.e10, 1.e10, 1.e10};
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    for(int iComp=0; iComp<3; iComp++) {
      if(xyz[iComp]>maxxyz[iComp])
	maxxyz[iComp] = xyz[iComp];
      if(xyz[iComp]<minxyz[iComp])
        minxyz[iComp] = xyz[iComp];
    }
  }
  VIter_reset(vit);

  double length[3];
  for(int iComp=0; iComp<3; iComp++)
    length[iComp] = maxxyz[iComp] - minxyz[iComp];

  cout << " length [x,y,z] " << length[0] << " " << length[1] << " " << length[2] << endl;

  VIter_reset(vit);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle0= fabs(xyz[0] - R);
//      h[0] = .25 * fabs(1. - exp (-circle0*L)) + 2.5e-3; // 0.02;  //1.e-3;
//      h[1] = .25; //* fabs(1. - exp (-circle1*L)) + 1.e-3;
//      h[2] = .25;

    double circle0 = fabs(xyz[0] - R);
    h[2] = 0.4;
    h[1] = 0.4;
    h[0] = 0.4 * fabs(1. - exp (-circle0*L)) + 0.007;

    for(int i=0; i<3; i++)
      h[i] /= nSplit;

    dirs[0][0]=1.0;
    dirs[0][1]=0.0;
    dirs[0][2]=0;
    dirs[1][0]=0.0;
    dirs[1][1]=1.0;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.;
    
    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }

  VIter_delete (vit);
  //double beta[]={1.2,1.2,1.2};
  double beta[]={1.5,1.5,1.5};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}


int cylindericalShock(pMesh mesh, pSField field)
{  
  double R=.3; //.62;
  double R2 = R*R;
  double L=2.;
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], norm;
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle= fabs(xyz[0] * xyz[0] +
//        xyz[1] * xyz[1] +
//        xyzi[2] * xyz[2] - R*R);    

    double circle = xyz[2] * xyz[2] + (xyz[1]+0.022) * (xyz[1]+0.022);
    double diff = circle - R2;
    int num_cyl = 5;
    double h_out = 0.085;
    if ((fabs(xyz[0]) < 0.045) && (diff < 0))
    {
      double rat = fabs(circle)/R2;
      if (rat >= 1/2)
      {
        h[0] = h[1] = h[2] = h_out/2;
      }
      else if (rat >= 1/7)
      {
        h[0] = h[1] = h[2] = h_out/8;
      }
      else if (rat >= 1/16)
      {
        h[0] = h[1] = h[2] = h_out/64;
      }
      else
      {
        h[0] = h[1] = h[2] = h_out/256;
      }
    }
    else
    {
      h[0] = 1;
      h[1] = 1;
      h[2] = 1;  
    }
/*
//    double circle= fabs(xyz[0] * xyz[0] + (xyz[1]+0.022) * (xyz[1]+0.022) - R*R);
    h[0] = .0004 * fabs(1. - exp (-circle*L)) + 0.00017;
    h[1] = .0004 * fabs(1. - exp (-circle*L)) + 0.00017;
    h[2] = .0004 * fabs(1. - exp (-circle*L)) + 0.00017;
*/
//    h[0] = .14 * fabs(1. - exp (-circle*L)) + 0.0017;
//    h[1] = .14;
//    h[2] = .14;
/*
   for(int i=0; i<3; i++)
      h[i] /= 2.;//pow(2.,nSplit);


    norm=sqrt(xyz[0]*xyz[0]+xyz[1]*xyz[1]);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=0;
	dirs[1][0]=-1.0*xyz[1]/norm;
	dirs[1][1]=xyz[0]/norm;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }
    else
      {
*/
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
//      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);
  return 1;
}


int sphericalShock(pMesh mesh, pSField field)
{  
  double R0=1.; //.62;
  double L=3.;
  double center[]={1.0, 0.0, 0.0};
  double tol=0.01;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, norm;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=dotProd(xyz,xyz);

    h[0] = .125 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.00125;
    h[1] = .125;
    h[2] = .124;

    for(int i=0; i<3; i++)
      h[i] *= nSplit; 

    norm=sqrt(R);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	if( xyz[0]*xyz[0] + xyz[1]*xyz[1] > tol*tol ) {
	  dirs[1][0]=-1.0*xyz[1]/norm;
	  dirs[1][1]=xyz[0]/norm;
	  dirs[1][2]=0;
	} else {
	  dirs[1][0]=-1.0*xyz[2]/norm;
	  dirs[1][1]=0;
	  dirs[1][2]=xyz[0]/norm;
	}
	crossProd(dirs[0],dirs[1],dirs[2]);
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);  
  double beta[]={2.5,2.5,2.5};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}



int ellipsoidalShock(pMesh mesh, pSField field)
{  
  // for the cube and torus
  //double aa = 0.62*0.62;
  //double bb = 1.*1.;//1.2*1.2;
  //double cc = 0.3*0.3;//0.2*0.2;
  // for the pipe
  double aa = 1.2*1.2;
  double bb = 2.*2.;
  double cc = 0.6*0.6;

  double L=3.;
  double tol=0.01;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], normal[3], center[3];
  double R, norm, xx, yy, zz;

  center[0] = center[1] = 0.25;
  //center[2] = 0.5;
  center[2] = 1.;
  
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    xx = xyz[0]-center[0];
    yy = xyz[1]-center[1];
    zz = xyz[2]-center[2];
    
    R = xx*xx/aa + yy*yy/bb + zz*zz/cc;
    
    // for the cube and torus
    //h[0] = .125 * fabs(1. - exp (-fabs(R-1)*L)) + 0.0125; 
    //h[1] = .125;
    //h[2] = .124 * fabs(1. - exp (-fabs(R-1)*L)) + 0.0125;
    // for the pipe
    h[0] = .5 * fabs(1. - exp (-fabs(R-1)*L)) + 0.005; 
    h[1] = .5;
    h[2] = .51 * fabs(1. - exp (-fabs(R-1)*L)) + 0.05;

    normal[0] = 2.0*xx/aa;
    normal[1] = 2.0*yy/bb;
    normal[2] = 2.0*zz/cc;

    norm = sqrt(dotProd(normal,normal));
    if( norm>tol ) 
      {
	dirs[0][0] = normal[0]/norm;
	dirs[0][1] = normal[1]/norm;
	dirs[0][2] = normal[2]/norm;

	if( normal[0]*normal[0] + normal[1]*normal[1] > tol*tol ) {
	  dirs[1][0] = -normal[1]/norm;
	  dirs[1][1] = normal[0]/norm;
	  dirs[1][2] = 0.;
	} 
	else {
	  dirs[1][0] = -normal[2]/norm;
	  dirs[1][1] = 0.;
	  dirs[1][2] = normal[0]/norm;
	}
	crossProd(dirs[0],dirs[1],dirs[2]);
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.;
	dirs[0][2]=0.;
	dirs[1][0]=0.;
	dirs[1][1]=1.0;
	dirs[1][2]=0.;
	dirs[2][0]=0.;
	dirs[2][1]=0.;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);  
  double beta[]={2.5,2.5,2.5};
  ((PWLsfield *)field)->anisoSmooth(beta);

  return 1;
}


int twoSphericalShocks(pMesh mesh, pSField field)
{  
  double R0=1.; //.707;
  double L=3.;
  double center[]={1.0, 0.0, 0.0};
  double beta[]={2.0, 2.0, 2.0};
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, RR, norm, norm2;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=dotProd(xyz,xyz);
    RR= fabs((xyz[0]-1.0) * (xyz[0]-1.0) +
	     xyz[1] * xyz[1] +
	     xyz[2] * xyz[2] );    
/*
    h[0] = .140 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.005; //0.003 
    h[1] = .139 * fabs(1. - exp (-fabs(RR-R0)*L)) + 0.005; //0.003
    h[2] = .138;
*/

    h[0] = (.02 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.005)*2;
    h[1] = (.02 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.005)*2;
    h[2] = (.02 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.005)*2;

    norm=sqrt(R);
    norm2=sqrt(RR);
    if( norm>tol && norm2>tol) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	dirs[1][0]=(xyz[0]-1.0)/norm2;
	dirs[1][1]=xyz[1]/norm2;
	dirs[1][2]=xyz[2]/norm2;
	crossProd(dirs[0],dirs[1],dirs[2]);

	if( xyz[1]*xyz[1] + xyz[2]*xyz[2] < tol )
	  {
	    if( xyz[0]>0.5 ) {
	      dirs[0][0]=1.0;
	      dirs[0][1]=0.0;
	      dirs[0][2]=0;
	      dirs[1][0]=0.0;
	      dirs[1][1]=1.0;
	      dirs[1][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    } else {
	      dirs[1][0]=1.0;
	      dirs[1][1]=0.0;
	      dirs[1][2]=0;
	      dirs[0][0]=0.0;
	      dirs[0][1]=1.0;
	      dirs[0][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    }

//  	    if( h[0] > h[1] ) {
//  	      double tmp=h[0];
//  	      h[0]=h[1];
//  	      h[1]=tmp;
//  	    }
	  }
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);

  //  AdaptUtil::viewMetricField(mesh,field );

  //  field->smooth_aniso(beta);
  return 1;
}


int twoSphericalShocksBIG(pMesh mesh, pSField field)
{  
  double R0 = 1.;//.707;
  double R1 = 1.;//25;
  double L0 = 0.75;  //1.; //0.5;
  double L1 = 3.;
  double tol=1.e-10;

  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, RR, norm, norm2;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R  = dotProd(xyz,xyz);
    RR = fabs((xyz[0]-1.0) * (xyz[0]-1.0) +
	     xyz[1] * xyz[1] + xyz[2] * xyz[2] );    

    h[0] = .140 * fabs(1. - exp (-fabs(R -R0)*L0)) + 0.008;//0.004;
    h[1] = .139 * fabs(1. - exp (-fabs(RR-R1)*L1)) + 0.002;//0.001;
    h[2] = .138;

    norm=sqrt(R);
    norm2=sqrt(RR);
    if( norm>tol && norm2>tol) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
        dirs[1][0]=(xyz[0]-1.0)/norm2;
        dirs[1][1]=xyz[1]/norm2;
        dirs[1][2]=xyz[2]/norm2;
	crossProd(dirs[0],dirs[1],dirs[2]);

	if( xyz[1]*xyz[1] + xyz[2]*xyz[2] < tol )
	  {
	    if( xyz[0]>0.5 ) {
	      dirs[0][0]=1.0;
	      dirs[0][1]=0.0;
	      dirs[0][2]=0;
	      dirs[1][0]=0.0;
	      dirs[1][1]=1.0;
	      dirs[1][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    } else {
	      dirs[1][0]=1.0;
	      dirs[1][1]=0.0;
	      dirs[1][2]=0;
	      dirs[0][0]=0.0;
	      dirs[0][1]=1.0;
	      dirs[0][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    }

	  }
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);

  //  AdaptUtil::viewMetricField(mesh,field );

  //double beta[]={2.0, 2.0, 2.0};
  //  field->smooth_aniso(beta);
  return 1;
}




void uniformRefine(pMesh pm, meshAdapt *pAdapt)
{
  EIter eit=M_edgeIter(pm);
  pEdge edge;
  while( edge=EIter_next(eit) ) {
    pAdapt->setAdaptLevel(edge,1);
  }
  EIter_delete(eit);
  pAdapt->run(1,0,0);
  return;
}


int platemetric(pMesh mesh,  pSField field)
{
  pVertex vt;
  double h[3], dirs[3][3];
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
//    h[2]=1.;
//    h[1]=0.1;
//    h[0]=0.1;

    h[2] = 0.2;
    h[0] = 0.2;
    double coor[3];
    V_coord(vt,coor);
 //   if ( fabs(coor[1]) > 0.43963714) 
 //     h[1] = 0.016127;  
 //   else 
 //     h[1] = -0.35*fabs(coor[1])+0.17;
    if ( fabs(coor[1]) > 0.4801) 
      h[1] = 0.016127;  
    else 
      h[1] = -0.32*fabs(coor[1])+0.17;

    dirs[0][0]=1.0;
    dirs[0][1]=0.;
    dirs[0][2]=0.;
    dirs[1][0]=0.;
    dirs[1][1]=1.0;
    dirs[1][2]=0.;
    dirs[2][0]=0.;
    dirs[2][1]=0.;
    dirs[2][2]=1.;
    
    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }

  VIter_delete (vit);
  //double beta[]={1.3,1.3,1.3};
  //((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}

int uniform(pMesh mesh,  pSField field)
{
  pVertex vt;
  double h[3], dirs[3][3], xyz[3];
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
   
    h[0] = uniformSize/nSplit;//1./nSplit; //uniformSize/nSplit;   
    h[1] = uniformSize/nSplit;//1./nSplit; //uniformSize/nSplit;   
    h[2] = uniformSize/nSplit;//1./nSplit; //uniformSize/nSplit;   

    dirs[0][0]=1.0;
    dirs[0][1]=0.;
    dirs[0][2]=0.;
    dirs[1][0]=0.;
    dirs[1][1]=1.0;
    dirs[1][2]=0.;
    dirs[2][0]=0.;
    dirs[2][1]=0.;
    dirs[2][2]=1.0;

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }

  VIter_delete (vit);
  double beta[]={1.5,1.5,1.5};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}


/* Kind of  planar shock to test uniform mesh */
int planar_uni(pMesh mesh,pSField field)
{
  double R=.5;
  double L=9.;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3];
  double maxxyz[3] = {-1.e10,-1.e10,-1.e10}, minxyz[3] = {1.e10, 1.e10, 1.e10};
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    for(int iComp=0; iComp<3; iComp++) {
      if(xyz[iComp]>maxxyz[iComp])
        maxxyz[iComp] = xyz[iComp];
      if(xyz[iComp]<minxyz[iComp])
        minxyz[iComp] = xyz[iComp];
    }
  }
  VIter_reset(vit);

  double length[3];
//  double ctr[3];
  for(int iComp=0; iComp<3; iComp++)
  {
    length[iComp] = maxxyz[iComp] - minxyz[iComp];
//    ctr[iComp] = (maxxyz[iComp] + minxyz[iComp])/2.;//*3./5.;
  }
/* 
  if (P_size() > 1)
  {
    double global_max[3], global_min[3];
    MPI_Allreduce(maxxyz, global_max, 3, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(minxyz, global_min, 3, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
    for(int iComp=0; iComp<3; iComp++)
    {
      ctr[iComp] = (global_max[iComp] + global_min[iComp])/2.;//*3./5.;
    }
  }
*/
  //cout << " length [x,y,z] " << length[0] << " " << length[1] << " " << length[2] << endl;

  double cut;
  VIter_reset(vit);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle0= fabs(xyz[0] - R);
//      h[0] = .25 * fabs(1. - exp (-circle0*L)) + 2.5e-3; // 0.02;  //1.e-3;
//      h[1] = .25; //* fabs(1. - exp (-circle1*L)) + 1.e-3;
//      h[2] = .25;

    //double circle0 = fabs(xyz[0] - R);
//    cut = fabs(ctr[0] - xyz[0]);// + R;
    cut = fabs(xyz[0]);
/*    if (xyz[0] > -0.0005 && xyz[0] < 0.0005)
    {
      h[0] = global_len[0]/2.5;// * fabs(1. - exp (cut*L)) + 0.007;
      h[1] = global_len[0]/2.5;
      h[2] = global_len[0]/2.5;
    }
    else
    {
      h[0] = global_len[1]*8.5 * fabs(1. - exp (cut*L)) + 0.007;
      h[1] = global_len[1]*8.5;// * fabs(1. - exp (cut*L)) + 0.007;
      h[2] = global_len[1]*8.5;// * fabs(1. - exp (cut*L)) + 0.007;
    }
*/

/*
    h[0] = global_len[0]/2 * fabs(1. - exp (cut*L)) + 5e-3;
    h[1] = global_len[0]/2 * fabs(1. - exp (cut*L)) + 5e-3;//global_len[0]/2.5;
    h[2] = global_len[0]/2 * fabs(1. - exp (cut*L)) + 5e-3;//global_len[0]/2.5;
*/

    h[0] = global_len[1]*8.5 * fabs(1. - exp (cut*L)) + 0.003;
    h[1] = global_len[1]*8.5 * fabs(1. - exp (cut*L)) + 0.003;//global_len[0]/2.5;
    h[2] = global_len[1]*8.5 * fabs(1. - exp (cut*L)) + 0.003;//global_len[0]/2.5;

/*
    h[0] = global_len[1]*20.5 * fabs(1. - exp (-cut*100)) + global_len[1]*8.5;
    h[1] = global_len[1]*20.5 * fabs(1. - exp (-cut*100)) + global_len[1]*8.5;//global_len[0]/2.5;
    h[2] = global_len[1]*20.5 * fabs(1. - exp (-cut*100)) + global_len[1]*8.5;//global_len[0]/2.5;
*/
/*
    h[2] = 0.4;
    h[1] = 0.4;
    h[0] = 0.4 * fabs(1. - exp (cut*L)) + 0.007;
*/

    for(int i=0; i<3; i++)
      h[i] /= nSplit;

    dirs[0][0]=1.0;
    dirs[0][1]=0.0;
    dirs[0][2]=0;
    dirs[1][0]=0.0;
    dirs[1][1]=1.0;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.;

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }

  VIter_delete (vit);
  //double beta[]={1.2,1.2,1.2};
  double beta[]={1.5,1.5,1.5};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}

int planarShockBL(pMesh mesh, pSField field)
{
  double size[3];
  double dirs[3][3];
  double xyz[3];

  double R0, Gamma;
  double location;
  R0 = 0.5;
  Gamma = 2.5;

  double p[4] = {-1.7389,-0.1000,0.5610,0.0049};

  double sizeAtLevel[6] = {0.02,0.02,0.04,0.05,0.085,0.1175};

  pVertex vertex;
  VIter vit = M_vertexIter(mesh);
  while(vertex = VIter_next(vit)) {

    V_coord(vertex,xyz);
    location = fabs(xyz[0] - R0);

    size[0]=0.2*fabs(1. - exp(-location*Gamma)) + 0.01;

    if(fabs(0.5-fabs(xyz[1]))<=0.2) {
      double y = fabs(0.5-fabs(xyz[1]));

      size[1] = p[0]*y*y*y + p[1]*y*y + p[2]*y + p[3] + 0.0051;
      size[1] = size[1] + 0.2*xyz[0]*size[1];

      size[1] = 0.05 + 0.02*xyz[0]*xyz[0];
    }
    else
      size[1] = 0.05 + 0.02*xyz[0]*xyz[0];

    size[2]=0.2;

    dirs[0][0]=1.;
    dirs[0][1]=0.;
    dirs[0][2]=0.;
    dirs[1][0]=0.;
    dirs[1][1]=1.;
    dirs[1][2]=0.;
    dirs[2][0]=0.;
    dirs[2][1]=0.;
    dirs[2][2]=1.;

    ((PWLsfield *)field)->setSize((pEntity)vertex,dirs,size);
  }
  VIter_delete(vit);

  return 1;
}


int planarShockBLThickness(pMesh mesh, pSField field)
{
  double size[3];
  double dirs[3][3];
  double xyz[3];

  double R0, Gamma;
  double location;
  R0 = 0.5;
  Gamma = 2.5;

  double p[4] = {-1.7389,-0.1000,0.5610,0.0049};

  double sizeAtLevel[6] = {0.005,0.008,0.013,0.02,0.03,0.042};
//  double sizeAtLevel[6] = {0.02,0.02,0.04,0.05,0.085,0.1175};

  pVertex vertex;
  VIter vit = M_vertexIter(mesh);
  while(vertex = VIter_next(vit)) {

    V_coord(vertex,xyz);
    location = fabs(xyz[0] - R0);

    size[0]=0.2*fabs(1. - exp(-location*Gamma)) + 0.01;

    if(fabs(0.5-fabs(xyz[1]))<=0.2) {
      double y = fabs(0.5-fabs(xyz[1]));

      size[1] = p[0]*y*y*y + p[1]*y*y + p[2]*y + p[3] + 0.0051;
      size[1] = size[1] + 0.2*xyz[0]*size[1];

//      size[1] = 0.05 + 0.02*xyz[0]*xyz[0];
    }
    else
    {

      if (V_typeInBL(vertex))
      {
        size[1] = sizeAtLevel[EN_levelInBL((pEntity)vertex)];
      }
      else
      {
        size[1] = 0.05 + 0.02*xyz[0]*xyz[0];
      }
    }


    size[2]=0.2;

    dirs[0][0]=1.;
    dirs[0][1]=0.;
    dirs[0][2]=0.;
    dirs[1][0]=0.;
    dirs[1][1]=1.;
    dirs[1][2]=0.;
    dirs[2][0]=0.;
    dirs[2][1]=0.;
    dirs[2][2]=1.;

    ((PWLsfield *)field)->setSize((pEntity)vertex,dirs,size);
  }
  VIter_delete(vit);

  return 1;
}


int airbubbles(pMesh mesh,  pSField field)
{
  double R0=0.15;
  double L=5, Length = 10.0;
  double vel=0.05;
  double center[7][3];
  int itime = 1;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, norm, distance[3];
  int flag;
  VIter vit=M_vertexIter(mesh);

  //initial position
  for(int i=0;i<7;i++){
    center[i][2] = (i-1)*2;//z coordinate
    center[i][0]=0.0;//x coordinate
    center[i][1]= 0.0; //y
  }

  //new position
  double minPos=Length, maxPos=0.0;
  for(int i=1;i<=5;i++){
    center[i][2] = center[i][2]+itime*vel-int((center[i][2]+itime*vel)/Length)*Length;
    if(center[i][2]>maxPos) maxPos=center[i][2];
    if(center[i][2]<minPos) minPos=center[i][2];
  }

  center[0][2]=maxPos-Length;
  center[6][2]=minPos+Length;

  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    flag = -1;
    for(int i=0;i<7;i++){
      for(int j=0;j<3;j++)
        distance[j]=xyz[j]-center[i][j];
      R = sqrt(dotProd(distance,distance));
      if(R<=2*R0){
        flag = 1;
        break;
      }
    }
    if(flag==1)
        h[0]=h[1]=h[2]=(.05 * (1. - exp (-fabs(R-R0)*L)) + 0.005)/3;
    else{
        h[0] = .06276/3;
        h[1] = .06276/3;
        h[2] = .06276/3;
    }

    dirs[0][0]=1.0;
    dirs[0][1]=0.0;
    dirs[0][2]=0;
    dirs[1][0]=0.0;
    dirs[1][1]=1.0;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.0;

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
    VIter_delete (vit);
//    double beta[]={1.5,1.5,1.5};
    //  ((PWLsfield *)field)->anisoSmooth(beta);

  return 1;
}

int airbubbles_80(pMesh mesh,  pSField field)
{
  double R0=0.15;
  double L=5;
  double center[82][3];
  double tol=0.001;
  double tol2 = 1e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, norm, distance[3];
  int flag;
  VIter vit=M_vertexIter(mesh);

  for(int i=0;i<41;i++){
    center[i*2][2] = center[i*2+1][2]=i*2;//z coordinate
    center[i*2][0]=center[i*2+1][0]=0.0;//x coordinate
    center[i*2][1]= 1.0; //y
    center[i*2+1][1] = -1.0; //y
  }

  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    flag = -1;
    for(int i=0;i<82;i=i+1){
      for(int j=0;j<3;j++)
        distance[j]=xyz[j]-center[i][j];
      R = sqrt(dotProd(distance,distance));
      if(R<=2*R0){
        flag = 1;
        break;
      }
    }

    if(flag==1)
        h[0]=h[1]=h[2]=0.6*(.05 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.005);
    else{
        h[0] = .06276/2*0.6;
        h[1] = .06276/2*0.6;
        h[2] = .06276/2*0.6;
    }
    dirs[0][0]=1.0;
    dirs[0][1]=0.0;
    dirs[0][2]=0;
    dirs[1][0]=0.0;
    dirs[1][1]=1.0;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.0;

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
    VIter_delete (vit);
//    double beta[]={1.5,1.5,1.5};
    //  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}

int movingbubbles(pMesh mesh,  pSField field)
{
  double R0=0.15;
  double L=5, Length = 10.0;
  double vel=0.05;
  double center[7][3];
  int itime = 1;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, norm, distance[3];
  int flag;
  VIter vit=M_vertexIter(mesh);

  //initial position
  for(int i=0;i<7;i++){
    center[i][2] = (i-1)*2;//z coordinate
    center[i][0]=0.0;//x coordinate
    center[i][1]= 0.0; //y
  }

  //new position
  double minPos=Length, maxPos=0.0;
  for(int i=1;i<=5;i++){
    center[i][2] = center[i][2]+itime*vel-int((center[i][2]+itime*vel)/Length)*Length;
    if(center[i][2]>maxPos) maxPos=center[i][2];
    if(center[i][2]<minPos) minPos=center[i][2];
  }

  center[0][2]=maxPos-Length;
  center[6][2]=minPos+Length;

  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    flag = -1;
    for(int i=0;i<7;i++){
      for(int j=0;j<3;j++)
        distance[j]=xyz[j]-center[i][j];
      R = sqrt(dotProd(distance,distance));
      if(R<=2*R0){
        flag = 1;
        break;
      }
    }

    if(flag==1)
        h[0]=h[1]=h[2]=(.05 * (1. - exp (-fabs(R-R0)*L)) + 0.005)/3;
    else{
        h[0] = .06276/3;
        h[1] = .06276/3;
        h[2] = .06276/3;
    }

    dirs[0][0]=1.0;
    dirs[0][1]=0.0;
    dirs[0][2]=0;
    dirs[1][0]=0.0;
    dirs[1][1]=1.0;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.0;

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
    VIter_delete (vit);
//    double beta[]={1.5,1.5,1.5};
    //  ((PWLsfield *)field)->anisoSmooth(beta);

  return 1;
}


int channel(pMesh mesh, pSField field)
{
  double size[3];
  double dirs[3][3];

  double p[4] = {-1.7389,-0.1000,0.5610,0.0049};

  double xyz[3];
  pVertex vertex;
  VIter vit = M_vertexIter(mesh);
  while(vertex = VIter_next(vit)) {
    V_coord(vertex,xyz);

    size[0]=0.2;

    size[1] = 0.05 + 0.02*xyz[0]*xyz[0];

    size[2]=0.2;

    dirs[0][0]=1.;
    dirs[0][1]=0.;
    dirs[0][2]=0.;
    dirs[1][0]=0.;
    dirs[1][1]=1.;
    dirs[1][2]=0.;
    dirs[2][0]=0.;
    dirs[2][1]=0.;
    dirs[2][2]=1.;

    ((PWLsfield *)field)->setSize((pEntity)vertex,dirs,size);
  }
  VIter_delete(vit);

  return 1;
}


int parabol(pMesh mesh, pSField field)
{
  double size[3];
  double dirs[3][3];

//  double xyz[3], R, coeff[3] = {0.1, 3., 0.3};  Error with this sf!
  double xyz[3], R, coeff[3] = {0.012, 3, 1};
  pVertex vertex;
  VIter vit = M_vertexIter(mesh);
  while(vertex = VIter_next(vit)) {
    V_coord(vertex,xyz);

//    R = -((xyz[0] * xyz[0] + xyz[1] * xyz[1]) - coeff[2]);
    R = -((xyz[0] * xyz[0]) - coeff[2]);
    size[0] = .3 - coeff[0]*(1 + exp(R * coeff[1]));

    size[1] = .3 - coeff[0]*(1 + exp(R * coeff[1]));

    size[2] = .3 - coeff[0]*(1 + exp(R * coeff[1]));

    dirs[0][0]=1.;
    dirs[0][1]=0.;
    dirs[0][2]=0.;
    dirs[1][0]=0.;
    dirs[1][1]=1.;
    dirs[1][2]=0.;
    dirs[2][0]=0.;
    dirs[2][1]=0.;
    dirs[2][2]=1.;

    ((PWLsfield *)field)->setSize((pEntity)vertex,dirs,size);
  }
  VIter_delete(vit);

  return 1;
}

// ***** add medit save for the output *****

void M_meditWrite2d(pMesh theMesh, char *name) 
{
  char fName[256];
  sprintf(fName,"%s.mesh",name);
  if (P_pid()==0) cout << "\n-- Writing Data File: " << fName << endl;

// Declaration
  std::ofstream ofs(fName);
  double coor[3];
  int nbTriangles, nbEdges, nbVertices;

  pVertex vertex;
  pFace triangle;
  pEdge edge; 

  pGModel model = M_model(theMesh); // recuperation du modele
  pGEdge gedge;  // model edge
  
  pMeshDataId nodalId = MD_newMeshDataId("meshId");

// Compte chaque entite
  nbTriangles = M_numFaces(theMesh);
  nbVertices  = M_numVertices(theMesh);

// nb de edge classifie sur un modele edge
  nbEdges = 0;
  GEIter geIter = GM_edgeIter(model);
  while(gedge=GEIter_next(geIter)) // boucle sur les model edges
  {
    nbEdges += M_numClassifiedEdges(theMesh,(pGEntity)gedge);
  }
  GEIter_reset(geIter);


// ----- Extraction et Ecriture du .mesh -----  
  ofs << "MeshVersionFormatted 1\n\n";
  ofs << "Dimension\n";
  ofs << "2\n";
  ofs << "#Mesh converted with meditWrite\n\n";


// Write Vertices
#ifndef MA_PARALLEL
  cout << "Number of given Vertices\t" << nbVertices << "\n";
#endif
  if (nbVertices > 0 )
  {
    ofs << "Vertices\n" << nbVertices << endl;
    
    VIter vIter = M_vertexIter(theMesh);
    int i = 1;
    while(vertex=VIter_next(vIter)) // boucle sur les vertex
    {
      V_coord(vertex,coor); // extrait les coor du vertex
//      EN_setID((pEntity)vertex,i);   // definit le num du vertex
//    fct de AOMD dans AOMD/cint/AOMDInternals.h
      EN_attachDataInt(pEntity(vertex), nodalId, i); // definit le num du vertex
      ofs << coor[0] << " " << coor[1] << " 0\n"; 
      i++;
    }

    VIter_delete(vIter); // destructeur de l'iterateur
  }
  else
    cout << "Error : no vertices !!!";

// Write Triangles
#ifndef MA_PARALLEL
  cout << "Number of given Triangles\t" << nbTriangles << "\n";
#endif

  if (nbTriangles > 0 )
  {
    ofs << "\n\nTriangles\n";
    ofs << nbTriangles << endl;
    
    FIter fIter = M_faceIter(theMesh);
    pPList listVertex;

    while(triangle=FIter_next(fIter)) // boucle sur les triangles
    {
      listVertex = F_vertices(triangle,1);
//    Attention preciser avant le type de la sortie (en anglais CAST)
//    on ne peut le faire que sur des pointeurs
      for (int i=0; i<3; ++i)
      {
        pEntity entity = (pEntity)PList_item(listVertex,i);
//        ofs << EN_id(entity) << " "; // EN_id ne prend que des pEntity
	int numNode;
	EN_getDataInt(entity, nodalId, &numNode);
	ofs << numNode << " "; 
      }
      ofs << " 0\n";
      PList_delete(listVertex);
    }

    FIter_delete(fIter); // destructeur de l'iterateur
  }
  else
    cout << "Error : no triangles !!!";


// Write Edges
#ifndef MA_PARALLEL
  cout << "Number of given Edges\t\t" << nbEdges << "\n";
#endif

  if ( nbEdges > 0 )
  {
    ofs << "\nEdges\n";
    ofs << nbEdges << endl;

    while(gedge=GEIter_next(geIter)) // boucle sur les model edges
    {
      EIter eIter = M_classifiedEdgeIter(theMesh,(pGEntity)gedge,0); 
      while(edge=EIter_next(eIter)) // boucle sur les edges du model edge
      {
	pVertex is1 = E_vertex(edge,0);
	pVertex is2 = E_vertex(edge,1);
//	ofs << EN_id((pEntity)is1) << " " << EN_id((pEntity)is2) << " ";
        int numNode1, numNode2;
        EN_getDataInt((pEntity)is1, nodalId, &numNode1);
        EN_getDataInt((pEntity)is2, nodalId, &numNode2);
        ofs << numNode1 << " " << numNode2 << " "; 

        ofs << GEN_tag((pGEntity)gedge) << "\n";
      }
      EIter_delete(eIter); // destructeur de l'iterateur

    }

    GEIter_delete(geIter); // destructeur de l'iterateur

  }
  else {
//    cout << "Error : no edges !!!";
    ofs << "\nEdges\n";
    ofs << 0 << endl;
  }
  

// Write Ridges
  ofs << "\nRidges\n";
  ofs << nbEdges << endl;
  for (int i=0; i<nbEdges; ++i)
  {
    ofs << i+1 << endl;
  }

// Write Corners
  ofs << "\nCorners\n";
  int nbCorners=0;
  VIter vIter1 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter1))       // boucle sur les vertex
  {
    // si Type=0 => c'est un corner car entity geom est un vertex
    if ( !V_whatInType(vertex) ) // => si corner
      nbCorners++;
  }
  VIter_reset(vIter1);                 // met a zero l'iterateur
  ofs << nbCorners << endl;

#ifndef MA_PARALLEL
  cout << "Number of given Corners\t\t" << nbCorners << "\n";
#endif

// Bcle sur les sommets et prise en compte de ceux aillant un tag dans le modele
//  VIter vIter1 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter1))       // boucle sur les vertex
  {
    // si Type=0 => c'est un corner car entity geom est un vertex
    if ( !V_whatInType(vertex) ) // => si corner
    {
      int numNode;
      EN_getDataInt((pEntity)vertex, nodalId, &numNode);
      ofs << numNode << endl;
    }
  }
  VIter_delete(vIter1);                 // efface l'iterateur


//--- efface toutes nodalId  
  VIter vIter2 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter2))       // boucle sur les vertex
  {
    EN_deleteData((pEntity)vertex, nodalId);
  }
  VIter_delete(vIter2);                 // efface l'iterateur
  
  MD_deleteMeshDataId(nodalId);
//--- fin efface


  ofs << "\nEnd\n";
  ofs.close();

}




// On peut declarer les variables localements, car elles
// sont detruitent a la sortie d'un BLOC

void M_meditWrite3d(pMesh theMesh, char *name) 
{
  char fName[256];
  sprintf(fName,"%s.mesh",name);
  if (P_pid()==0) cout << "\n  -- Writing Data File: " << fName << endl;

// Declaration
  std::ofstream ofs(fName);
  double coor[3];
  int nbTriangles, nbEdges, nbVertices, nbTetras;

  pVertex vertex;
  pFace   triangle;
  pEdge   edge; 
  pRegion tetra;

  pGModel model = M_model(theMesh); // recuperation du modele
  pGFace gface;  // model triangle
  pGEdge gedge;  // model edge

  pMeshDataId nodalId = MD_newMeshDataId("meshId");
  
// ----- Compte chaque entite -----
  nbTetras   = M_numRegions(theMesh);
  nbVertices = M_numVertices(theMesh);


  // nb de triangle sur la peau
  nbTriangles = 0;
  GFIter gfIter = GM_faceIter(model);
  while(gface=GFIter_next(gfIter)) // boucle sur les model faces
  {  
    nbTriangles += M_numClassifiedFaces(theMesh,(pGEntity)gface);
  }
//  cout << "\nNbr de triangles classifiees =" << nbTriangles << endl;
  GFIter_reset(gfIter);
  
  // nb de edge classifie sur un modele edge
  nbEdges = 0;
  GEIter geIter = GM_edgeIter(model);
  while(gedge=GEIter_next(geIter)) // boucle sur les model edges
  {
    nbEdges += M_numClassifiedEdges(theMesh,(pGEntity)gedge);
  }
//  cout << "\nNbr de edges classifiees =" << nbEdges << endl;
  GEIter_reset(geIter);

  

// ----- Extraction et Ecriture du .mesh -----  
  ofs << "MeshVersionFormatted 1\n\n";
  ofs << "Dimension\n";
  ofs << "3\n";
  ofs << "#Mesh converted with M_writeMEDIT\n\n";

// Write Vertices
#ifndef MA_PARALLEL
  cout << "Number of given Vertices\t" << nbVertices << "\n";
#endif

  if (nbVertices > 0 )
  {
    ofs << "Vertices\n" << nbVertices << endl;
    
    VIter vIter = M_vertexIter(theMesh);
    int i = 1;
    while(vertex=VIter_next(vIter)) // boucle sur les vertex
    {
      V_coord(vertex,coor);          // extrait les coor du vertex
//      EN_setID((pEntity)vertex,i);   // definit le num du vertex
//    fct de AOMD dans AOMD/cint/AOMDInternals.h
      EN_attachDataInt(pEntity(vertex), nodalId, i); // definit le num du vertex
      ofs << coor[0] << " " << coor[1] << " " << coor[2] << " 0\n";
      i++;
    }

    VIter_delete(vIter); // destructeur de l'iterateur
  }
  else
    cout << "/nError : no vertices !!!/n";


// Write Triangles
#ifndef MA_PARALLEL
  cout << "Number of given Triangles\t" << nbTriangles << "\n";
#endif

  if (nbTriangles > 0 )
  {
    ofs << "\n\nTriangles\n";
    ofs << nbTriangles << endl;

    while(gface=GFIter_next(gfIter)) // boucle sur les model triangles
    {
      FIter fIter = M_classifiedFaceIter(theMesh,(pGEntity)gface,0);
      pPList listVertex;
      while(triangle=FIter_next(fIter)) // boucle sur les tri du model tri
      {
        listVertex = F_vertices(triangle,1);
	for (int i=0; i<3; ++i)
	{
	  pEntity entity = (pEntity)PList_item(listVertex,i);
//	  ofs << EN_id(entity) << " "; // EN_id ne prend que des pEntity
          int numNode;
          EN_getDataInt(entity, nodalId, &numNode);
          ofs << numNode << " "; 
	}
        ofs << GEN_tag((pGEntity)gface) << "\n";
        PList_delete(listVertex);
      }
      FIter_delete(fIter); // destructeur de l'iterateur

    }
    GFIter_delete(gfIter); // destructeur de l'iterateur

  }
  else {
//    cout << "\nError : no triangles !!!\n";
    ofs << "\n\nTriangles\n";
    ofs << 0 << endl;
  }


// Write Tetrahedra
#ifndef MA_PARALLEL
  cout << "Number of given Tetrahedra\t" << nbTetras << "\n";
#endif

  if (nbTetras > 0 )
  {
    ofs << "\nTetrahedra\n";
    ofs << nbTetras << endl;
    
    RIter rIter = M_regionIter(theMesh);
    pPList listVertex;

    while(tetra=RIter_next(rIter)) // boucle sur les tetras
    {
      listVertex = R_vertices(tetra,1);
//    Attention preciser avant le type de la sortie (en anglais CAST)
//    on ne peut le faire que sur des pointeurs
      for (int i=0; i<4; ++i)
      {
        pEntity entity = (pEntity)PList_item(listVertex,i);
//        ofs << EN_id(entity) << " "; // EN_id ne prend que des pEntity
	int numNode;
	EN_getDataInt(entity, nodalId, &numNode);
	ofs << numNode << " "; 
      }
      ofs << " 0\n";
      PList_delete(listVertex);
    }

    RIter_delete(rIter); // destructeur de l'iterateur
  }
  else
    cout << "/nError : no tetrahedra !!!/n";
  


// Write Edges
#ifndef MA_PARALLEL
  cout << "Number of given Edges\t\t" << nbEdges << "\n";
#endif
  
  if ( nbEdges > 0 )
  {
    ofs << "\nEdges\n";
    ofs << nbEdges << endl;
    
    while(gedge=GEIter_next(geIter)) // boucle sur les model edges
    {
      EIter eIter = M_classifiedEdgeIter(theMesh,(pGEntity)gedge,0); 
      while(edge=EIter_next(eIter)) // boucle sur les edges du model edge
      {
	pVertex is1 = E_vertex(edge,0);
	pVertex is2 = E_vertex(edge,1);
//	ofs << EN_id((pEntity)is1) << " " << EN_id((pEntity)is2) << " ";
        int numNode1, numNode2;
        EN_getDataInt((pEntity)is1, nodalId, &numNode1);
        EN_getDataInt((pEntity)is2, nodalId, &numNode2);
        ofs << numNode1 << " " << numNode2 << " "; 

        ofs << GEN_tag((pGEntity)gedge) << "\n";
      }
      EIter_delete(eIter); // destructeur de l'iterateur

    }


  }
  else {
//    cout << "Error : no edges !!!";
    ofs << "\nEdges\n";
    ofs << 0 << endl;
  }
  GEIter_delete(geIter); // destructeur de l'iterateur

// Write Ridges
//  cout << "\nWrite Ridges\n";
  ofs << "\nRidges\n";
  ofs << nbEdges << endl;
  for (int i=0; i<nbEdges; ++i)
  {
    ofs << i+1 << endl;
  }


// Write Corners
  ofs << "\nCorners\n";
  int nbCorners=0;
  VIter vIter1 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter1))       // boucle sur les vertex
  {
    // si Type=0 => c'est un corner car entity geom est un vertex
    if ( !V_whatInType(vertex) ) // => si corner
      nbCorners++;
  }
  VIter_reset(vIter1);                 // met a zero l'iterateur
  ofs << nbCorners << endl;

#ifndef MA_PARALLEL
  cout << "Number of given Corners\t\t" << nbCorners << "\n";
#endif

// Bcle sur les sommets et prise en compte de ceux aillant un tag dans le modele
//  VIter vIter1 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter1))       // boucle sur les vertex
  {
    // si Type=0 => c'est un corner car entity geom est un vertex
    if ( !V_whatInType(vertex) ) // => si corner
    {
      int numNode;
      EN_getDataInt((pEntity)vertex, nodalId, &numNode);
      ofs << numNode << endl;
    }
  }
  VIter_delete(vIter1);                 // efface l'iterateur

/* NE MARCHE PAS CAR AOMD RAJOUTE DES CORNERS N'APPARTENANT PAS AU MODELE
   AFIN DE MIEUX DEFINIR LES COURBE
  int nbCorners = GM_numVertices(model);
  pGVertex corner;  
  GVIter gvIter = GM_vertexIter(model);
  while(corner=GVIter_next(gvIter)) // boucle sur les model vertices
  {
    vertex = M_classifiedVertex(theMesh,corner);
//    ofs << EN_id((pEntity)vertex) << endl;
    int numNode;
    EN_getDataInt((pEntity)vertex, nodalId, &numNode);
    ofs << numNode << endl; 

  }
  GVIter_delete(gvIter);

FAUX AUSSI
  pGVertex gvertex;
 int nbCorners = M_numClassifiedVertices(theMesh,(pGEntity)gvertex);
*/


//--- efface toutes nodalId  
  VIter vIter2 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter2))       // boucle sur les vertex
  {
    EN_deleteData((pEntity)vertex, nodalId);
  }
  VIter_delete(vIter2);                 // efface l'iterateur
  
  MD_deleteMeshDataId(nodalId);
//--- fin efface
  
  if (P_pid()==0) cout << endl;
  ofs << "\nEnd\n";
  ofs.close();

}


