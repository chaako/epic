#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "visUtil.h"
#include "PWLinearSField.h"
#include "analyticalSField.h"
#include "MeshSize.h"
#include "fromMeshTools.h"
#include <stdlib.h>
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>

#ifdef PARALLEL
#include "ParUtil.h"
#include "pmMigrationCallbacks.h"
#endif

#include "parasolid_kernel.h"
#ifdef AOMD_
#include "modelerParasolid.h"
#else
#include "SimParasolidKrnl.h"
#endif

#ifdef AOMD_
#include "AOMD.h"
#include "mAOMD.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "MeshTools.h"
#endif
#include "visUtilDX.h"
#include "DXParameters.h"

#define FILE "/medusa/seole/pAdapt2/stop.check"

extern "C" int readLicenseFile(char *filename);
int PWL_SField(pMesh, pSField, void *);
int PWL_torusHoles(pMesh, pSField);
int PWL_bearing(pMesh, pSField);
int PWL_hubsection(pMesh, pSField);
int PWL_sphere(pMesh, pSField);
int PWL_cannon2D(pMesh, pSField);
int PWL_pipe(pMesh, pSField);
int PWL_pig4(pMesh, pSField);
pMSize AnExp_SField(double[3]);
pMSize AnExp_torusHoles(double[3]);
pMSize AnExp_bearing(double[3]);
pMSize AnExp_hubsection(double[3]);
pMSize AnExp_pipe(double[3]);
pMSize AnExp_pig4(double[3]);

#define PI 3.141596

char without_extension[256];

double min(double x, double y) {
  if( x<y )
    return x;
  else
    return y;
}

double max(double x, double y) {
  if( x<y )
    return y;
  else
    return x;
}


int main(int argc, char* argv[])
{  

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->init (argc,argv);
  if (AOMD::ParUtil::Instance()->master())
    system("rm part*");
#endif

  if ( argc!=5 ) { 
    printf("Usage: %s filename iterations SFieldType\n",argv[0]);
    printf("filename:\n");
    printf("         torusHoles (torus with four holes)\n");
    printf("         bearing \n");
    printf("         hubsection \n");
    printf("         sphere \n");
    printf("         pipe \n");
    printf("         cannon2D \n");
    printf("         pig4 \n");
    printf("iteration: \n");
    printf("         the iterations allowed in case adapation is not converged\n"); 
    printf("SFieldType:\n");
    printf("         PWL - Piece-Wise Linear field attached to current mesh\n");
    printf("         AnExp - Analytical Expressions \n");
    return 0;
  }
  
#ifdef PARALLEL
 int i;
 printf("My processor ID: %d\n",M_Pid());
 if(AOMD::ParUtil::Instance()->master())
  {
     std::cout<<"enter (0/1) ";
     std::cin>>i;
  }
 
 printf("I am waiting\n");
 M_sync();

#endif
  
  char model_file[256];
  char mesh_file[256];
  char outmesh[256];
  
  snprintf(without_extension,strlen(argv[1])-3,"%s",argv[1]);
  sprintf(mesh_file,"%s",argv[1]);
  sprintf(model_file,"%s.xmt_txt",without_extension);

  MS_init();
  pGModel model=GM_createFromParasolidFile(model_file);
/*
 
  if(M_Pid()==0)
    {
      int result;
      struct stat Buffer;
      result = stat(FILE,&Buffer);
      
      while (result != 0) {
	std::cout << result << std::endl;
	sleep(1);
	result = stat(FILE,&Buffer);
      }
      std::cout << "Stat found file" << std::endl; 
    }

*/
  pMesh mesh=MS_newMesh(model);
#ifdef AOMD_
  M_setRepresentationFlag(mesh,1);
#endif
  double t1=P_wtime();
  M_load(mesh,mesh_file);

  myTimer tt;
  tt.reset();

  pSField field;
  if( strcmp(argv[3],"PWL") == 0 )
    {
      field=new PWLsfield(mesh);
      meshAdapt rdr(mesh,field,2,0);   
      rdr.run(atoi(argv[2]),1,PWL_SField);
    }
  else if( strcmp(argv[3],"AnExp") == 0 )
    {
      field=new analyticalSField(AnExp_SField);
      meshAdapt rdr(mesh,field,2,0); 
      rdr.setQualityCheckThreshold(0.2);
      rdr.run(atoi(argv[2]),0,0);
    }
  double t2=P_wtime();
  printf("Total clock time: %f\n",tt.elapsedCPU());

  sprintf(outmesh,"%s-refined.sms",without_extension);
#ifndef PARALLEL
  M_writeSMS(mesh,outmesh,2);
#else
//  sprintf(outmesh,"part%d.sms",M_Pid());
//  M_writeSMS(mesh,outmesh,2);
  DXParameters DXPar;
  DXPar.setTagprocessorID(true);
  char outputPath[256]="/users/seole/dx";
  writeDX(mesh,&DXPar,argv[4],outputPath);
#endif

  M_printNumEntities(mesh);
  if (P_pid()==0)
  { 
    std::cout<<"\n# partitions = "<<P_size()<<"\n";
    std::cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
  }  

  delete field;
  M_delete(mesh);
  GM_delete(model);
  MS_exit();    

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->Finalize();
#endif
  return 1;
} 


int PWL_SField(pMesh mesh, pSField field, void *)
{
  if( strcmp( without_extension,"torusHoles" ) == 0 )
    PWL_torusHoles(mesh,field);
  else if( strcmp( without_extension,"bearing" ) == 0 )
    PWL_bearing(mesh,field);
  else if( strcmp( without_extension,"hubsection" ) == 0 )
    PWL_hubsection(mesh,field);
  else if( strcmp( without_extension,"sphere" ) == 0 )
    PWL_sphere(mesh,field);
  else if( strcmp( without_extension,"cannon2D" ) == 0 )
    PWL_cannon2D(mesh,field);
  else if( strcmp( without_extension,"pipe" ) == 0 )
    PWL_pipe(mesh,field);
  else if( strcmp( without_extension,"pig4" ) == 0 )
    PWL_pig4(mesh,field);
  else
    printf("mesh size field not specified!!!\n");

  return 1;
}

pMSize AnExp_SField(double xyz[3])
{
  if( strcmp( without_extension,"torusHoles" ) == 0 )
    return AnExp_torusHoles(xyz);
  else if( strcmp( without_extension,"bearing" ) == 0 )
    return AnExp_bearing(xyz);
  else if( strcmp( without_extension,"hubsection" ) == 0 )
    return AnExp_hubsection(xyz);
  else if( strcmp( without_extension,"pipe" ) == 0 )
    return AnExp_pipe(xyz);
  else if( strcmp( without_extension,"pig4" ) == 0 )
    return AnExp_pig4(xyz);
  else
    printf("mesh size field not specified!!!\n");

  return 0;
}


// isotropic field for torushole model
int PWL_torusHoles(pMesh mesh, pSField field)
{
  pVertex vt;
  double minSize=0.05, h;
  double r, xyz[3];
  VIter vit=M_vertexIter(mesh);

  while( (vt=VIter_next(vit)) ) {
    V_coord(vt,xyz);
    r=sqrt(xyz[1]*xyz[1]+xyz[2]*xyz[2]);
    h=minSize*(-4.0*exp(0.4-2.*r)+5.0);
    if( r<= 0.2 )
      h=minSize;
    field->setSize((pEntity)vt,h);
  }

  VIter_delete (vit);
  return 1;
}

pMSize AnExp_torusHoles(double xyz[3])
{
  double minSize=0.05, h;
  double r;

  r=sqrt(xyz[1]*xyz[1]+xyz[2]*xyz[2]);
  h=minSize*(-4.0*exp(0.4-2.*r)+5.0);
  if( r<= 0.2 )
    h=minSize;
  return new MeshSize(h);
}


int PWL_bearing(pMesh mesh, pSField field)
{
  pVertex vt;
  double sizeHole, r, size;
  double xyz[3];
  double ns=0.75;
  VIter vit=M_vertexIter(mesh);

  while( vt=VIter_next(vit) ) {
    sizeHole=999999999;
    V_coord(vt,xyz);
    if( xyz[2]<0.01386 || xyz[2]>0.0762 ) {
      r=sqrt(xyz[1]*xyz[1]+xyz[0]*xyz[0]);
      sizeHole=0.005*(8.-7.*exp(50*(0.003175-r)));
    }
    size=0.002*ns*(4.+3.0*cos(3.141596*(xyz[2]+0.003429)/0.04845));
    if( size > sizeHole ) size=sizeHole;
    field->setSize((pEntity)vt,size);
  }

  VIter_delete (vit);
  return 1; 
}


pMSize AnExp_bearing(double xyz[3])
{
  double sizeHole, r, size;
  double ns=0.75;

  sizeHole=999999999;
  if( xyz[2]<0.01386 || xyz[2]>0.0762 ) 
    {
      r=sqrt(xyz[1]*xyz[1]+xyz[0]*xyz[0]);
      sizeHole=0.005*(8.-7.*exp(50*(0.003175-r)));
    }
  size=0.002*ns*(4.+3.0*cos(3.141596*(xyz[2]+0.003429)/0.04845));
  if( size > sizeHole ) 
    size=sizeHole;

  return new MeshSize(size);
}


int PWL_hubsection(pMesh mesh, pSField field)
{
  pVertex vt;
  double ns=8.;
  double r1,r2,r3,min,xyz[3],size;
  VIter vit=M_vertexIter(mesh);
  
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    // distances to two bigger holes
    r1=sqrt(xyz[0]*xyz[0]+(xyz[1]-0.122)*(xyz[1]-0.122));
    r2=sqrt((xyz[0]+0.116)*(xyz[0]+0.116)+(xyz[1]-0.0377)*(xyz[1]-0.0377));
    // distance to one of the small holes
    r3=sqrt((xyz[0]+0.137)*(xyz[0]+0.137)+(xyz[1]-0.1668)*(xyz[1]-0.1668));

    min=PI*0.01191*0.1*(-9.0*exp(ns*(0.01191-r1))+10.0);
    size=PI*0.01191*0.1*(-9.0*exp(ns*(0.01191-r2))+10.0);
    if( min > size ) 
      min=size;
    size=PI*0.004806*0.1*(-29.0*exp(ns*(0.004806-r3))+30.0);
    if( min > size ) 
      min=size;
    field->setSize((pEntity)vt,min);
  }
  VIter_delete(vit);
  return 1;
}


pMSize AnExp_hubsection(double xyz[3])
{
  double ns=8.;
  double r1,r2,r3,min,size;
  
  // distances to two bigger holes
  r1=sqrt(xyz[0]*xyz[0]+(xyz[1]-0.122)*(xyz[1]-0.122));
  r2=sqrt((xyz[0]+0.116)*(xyz[0]+0.116)+(xyz[1]-0.0377)*(xyz[1]-0.0377));
  // distance to one of the small holes
  r3=sqrt((xyz[0]+0.137)*(xyz[0]+0.137)+(xyz[1]-0.1668)*(xyz[1]-0.1668));

  min=PI*0.01191*0.1*(-9.0*exp(ns*(0.01191-r1))+10.0);
  size=PI*0.01191*0.1*(-9.0*exp(ns*(0.01191-r2))+10.0);
  if( min > size ) 
    min=size;
  size=PI*0.004806*0.1*(-29.0*exp(ns*(0.004806-r3))+30.0);
  if( min > size ) 
    min=size;

  return new MeshSize(min);
}


int PWL_sphere(pMesh mesh, pSField field)
{  
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R;

  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=sqrt(dotProd(xyz,xyz));

    if( R > 0.48 )
      h[0]=0.005;
    else
      h[0]=0.025;
    h[1] = .05;
    h[2] = .05;

    dirs[0][0]=xyz[0]/R;
    dirs[0][1]=xyz[1]/R;
    dirs[0][2]=xyz[2]/R;
    dirs[1][0]=-1.0*xyz[1]/R;
    dirs[1][1]=xyz[0]/R;
    dirs[1][2]=0;
    crossProd(dirs[0],dirs[1],dirs[2]);
   
    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);
  
  double beta[]={1.2,1.2,1.2};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}

int PWL_cannon2D(pMesh mesh, pSField field)
{  
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R;

  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);

    if( fabs(xyz[1]) < 0.06 ) {
      
      if( xyz[2] > -5.0 ) {
	((PWLsfield *)field)->setSize((pEntity)vt,0.033);
      }
      else if( xyz[2] > -5.5 )
	((PWLsfield *)field)->setSize((pEntity)vt,0.01);
      else
	((PWLsfield *)field)->setSize((pEntity)vt,0.5);
    }
    else
      ((PWLsfield *)field)->setSize((pEntity)vt,0.5);
  }
  VIter_delete (vit);
  
  double beta[]={1.1,1.1,1.1};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}


int PWL_pipe(pMesh mesh, pSField field)
{  
  pVertex vt;
  double xyz[3];

  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    field->setSize((pEntity)vt,AnExp_pipe(xyz));
  }
  VIter_delete (vit);
  
//    double beta[]={1.6,1.6,1.6};
//    ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}

pMSize AnExp_pipe(double xyz[3])
{
  double rSq,r;
  double h[3], dirs[3][3];
  
  rSq = xyz[0]*xyz[0] + xyz[1]*xyz[1];

  h[1] = .2;
  h[0] = h[1]*(1-exp(2.*(rSq-1))) + 0.003;
  h[2] = h[1];
  
  if( h[0] < 0.003 )
    h[0]=0.003;

  r=sqrt(rSq);
  dirs[0][0]=xyz[0]/r;
  dirs[0][1]=xyz[1]/r;
  dirs[0][2]=0.0;
  dirs[1][0]=-1.0*xyz[1]/r;
  dirs[1][1]=xyz[0]/r;
  dirs[1][2]=0;
  dirs[2][0]=0.0;
  dirs[2][1]=0.0;
  dirs[2][2]=1.0;

  return new MeshSize(dirs,h);
}


int PWL_pig4(pMesh mesh, pSField field)
{  
  pVertex vt;
  double x[3],v[3],size;
  double c[]={-15.79, -28.49, 3.89};

  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,x);
    diffVt(x,c,v);
    size=min(0.03, max(0.0015,0.0001*(v[0]*v[0] + v[1]*v[1] + v[2]*v[2])));
    field->setSize((pEntity)vt,size);
  }
  VIter_delete (vit);
  
  return 1;
}

pMSize AnExp_pig4(double xyz[3])
{
  double v[3],h;
  double c[]={-16.08, -29.77, 4.832};

  diffVt(xyz,c,v);
  h = min(0.03, 2.5*max(0.0015,0.000075*(v[0]*v[0] + v[1]*v[1] + v[2]*v[2])));

  return new MeshSize(h*104.5);
}


