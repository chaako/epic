/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/* ****************************************************************************
 *
 *  test/M_writeDX/main.cc
 *  Created by E. Seegyoung Seol on Wed Jul 06 2005, 14:04:31 EDT
 *
 *  File Contents: test model/mesh loading.
 *
 *************************************************************************** */

#include <stdio.h>
#include <iostream>
#include <fstream>
#include "AOMD.h"
#include "AOMD_cint.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mAOMD.h"
#include "mPoint.h"
#include "ParUtil.h"
#include <assert.h>
#include "AOMD_Internals.h"
#include "visUtilDX.h"
#include "DXParameters.h"
#include "AcisModel.h"
#include "parasolid_kernel.h"
#include "modelerParasolid.h"

int main ( int argc, char *argv[])
{
  if (argc<4)
    cout<<"\n* Usage: main model_file/NULL mesh_file dx_path\n\n";
    
  AOMD::ParUtil::Instance()->init(argc,argv);  

  pGModel model=0;
  pMesh mesh;
  char ext[6];
  strcpy(ext,argv[1]+(strlen(argv[1])-4));
  if(!strcmp(ext,".sat"))
  {
    model=new AcisModel(argv[1],0);      
    mesh=MS_newMesh(model);
  }
  else 
  if (!strcmp(ext,"_txt"))
  {
    model=GM_createFromParasolidFile(argv[1]);
    mesh = MS_newMesh(model);
  }
  else
    mesh = MS_newMesh(0);

  M_load(mesh,argv[2]);

  DXParameters DXPar;
  DXPar.setTagprocessorID(true);
  char outputPath[256]="/users/seole/dx";
  writeDX(mesh,&DXPar,argv[3],outputPath);
    
  AOMD::ParUtil::Instance()->Finalize();
  return 0;
}




