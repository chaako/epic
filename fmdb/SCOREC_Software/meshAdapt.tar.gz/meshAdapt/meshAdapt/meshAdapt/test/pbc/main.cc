#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "visUtil.h"
#include "PWLinearSField.h"
#include "fromMeshTools.h"
#include <stdlib.h>
#include <stdio.h>
#include "M_writeVTKFile.h"
#include "mMesh.h"
#include "modeler.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>
#include <set>

#include "ParUtil.h"

#include "pbcOnGFace.h"
#include "pbcOnGEdge.h"
#include "pbcOnGVertex.h"

#include "parasolid_kernel.h"
#ifdef AOMD_
#include "modelerParasolid.h"
#else
#include "SimParasolidKrnl.h"
#endif

#ifdef AOMD_
#include "AOMD.h"
#include "mAOMD.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "MeshTools.h"
#ifdef PARALLEL
#include "SF_MigrationCallbacks.h"
#endif
#endif

#define FILE "/users/xli/stop.check"

extern "C" int readLicenseFile(char *filename);
int sizefield(pMesh,pSField,void *);
int planarShock(pMesh,pSField);
int cylindericalShock(pMesh,pSField);
int sphericalShock(pMesh, pSField);
int twoSphericalShocks(pMesh,pSField);
void uniformRefine(pMesh,meshAdapt &);

int sf;  // size field indicator
using std::cout;
int num_edge;   // number of marked edges in a triangle

void buildModelPbc(pGModel model, char* pbc_file);
void printMatchInfo(pEntity ent);
void printMatchingEnts(pMesh mesh, pGModel model, set<pVertex>& vertices);
void checkMatchInfo (pEntity ent);
void checkMatchVertex (pVertex vtx); 
void checkMatchEdge (pEdge edge);
void checkMatchFace (pFace face);

int main(int argc, char* argv[])
{  
#ifdef PARALLEL
  AOMD::ParUtil::Instance()->init (argc,argv);
  if (AOMD::ParUtil::Instance()->master())
    system("rm part*");
#endif
  
//   if ( argc!=4 ) { 
//     printf("Usage: %s filename sizefield iterations \n\n",argv[0]);
//     printf("filename: a mesh file name for a cubic domain from (0,0,0)->(1,1,1)\n");
//     printf("          carre - 2D model to test AOMD only\n");
//     printf("          cube2 - a structured mesh with 26 nodes 32 elements\n");
//     printf("          cube1 - an unstructured mesh with 824 nodes 3748 elements\n");
//     printf("sizefield: An integer to indicate a defined mesh size field:\n");
//     printf("           1 - a planar shock at x=0.5 \n");
//     printf("           2 - a cylinderical shock centered at x=0 \n");
//     printf("           3 - a spherical shock \n");
//     printf("           4 - two spherical shocks \n");
//     printf("iteration: the iterations allowed in case adapation is not converged\n\n"); 
//     return 0;
//   }

#ifdef PARALLEL
/*
  int i;
  printf("My processor ID: %d\n",M_Pid());
  if(AOMD::ParUtil::Instance()->master())
   {
      cout<<"enter (0/1) ";
      std::cin>>i;
   }
  
  printf("I am waiting\n");
    // sleep(10);
  M_sync();
*/
#endif
  
  char model_file[256];
  char mesh_file[256];
  char outmesh[256];
  char without_extension[256];
  
  snprintf(without_extension,strlen(argv[1])-3,"%s",argv[1]);
  sprintf(mesh_file,"%s",argv[1]);
  sprintf(model_file,"%s.xmt_txt",without_extension);
  // sf=atoi(argv[3]);
  sf=0; 
  num_edge = atoi(argv[3]);
 
  MS_init();
  pGModel model=GM_createFromParasolidFile(model_file);

  // set up the pbc model info 
  GM_loadPbc(model, argv[2]);
  
  pMesh mesh=MS_newMesh(model);
  pSField field=new PWLsfield(mesh);
  double t1=AOMD::ParUtil::Instance()->wTime();
  M_load(mesh,mesh_file);
  
  std::set<pVertex> vertices; 
  printMatchingEnts(mesh, model, vertices); 
  // M_writeVTKFile(mesh, mesh_file);
  
#ifndef PARALLEL
  M_checkAdj(mesh);
  adaptUtil::M_checkPar(mesh,0);
#endif
  M_verify(mesh);

  //  meshAdapt rdr(mesh,field,2,0);
  meshAdapt*  rdr=new meshAdapt(mesh,0,0,1);  // snap off;

  myTimer tt;
  //  rdr.run(niter,1, sizefield);
  double t2=AOMD::ParUtil::Instance()->wTime();
  
  int num = atoi(argv[4]);
  for(int i=0; i< num; i++) {
    uniformRefine(mesh, *rdr);
    sprintf(outmesh,"%s-refined%d.sms",without_extension, i);
    M_writeSMS(mesh,outmesh,2);
    // M_writeVTKFile(mesh, outmesh);
    
    // std::set<pVertex> vertices; 
    printMatchingEnts(mesh, model, vertices); 
  }
  
  if (P_pid()==0)
   printf("Total clock time: %f\n",tt.elapsedCPU());

  delete field;
  delete rdr; 

  
  M_checkAdj(mesh);
  // adaptUtil::M_checkPar(mesh,0);
  // adaptUtil::M_checkShape(mesh,field);

  M_printNumEntities(mesh);
  if (P_pid()==0)
  { 
    cout<<"\n# partitions = "<<P_size()<<"\n";
    cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
  }  

  M_delete(mesh);
  GM_delete(model);

  MS_exit();    

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->Finalize();
#endif
  return 1;
} 


int sizefield(pMesh mesh, pSField field, void *)
{
  switch( sf ) {
  case 1: planarShock(mesh,field); break;
  case 2: cylindericalShock(mesh,field); break;
  case 3: sphericalShock(mesh,field); break;
  case 4: twoSphericalShocks(mesh,field); break;
  default:
    printf("Error: mesh size field not defined\n");
    exit(0);
  }
  return 1;
}


int planarShock(pMesh mesh,pSField field)
{
  double R=.5;
  double L=1.;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3];
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle0= fabs(xyz[0] - R);
//      h[0] = .25 * fabs(1. - exp (-circle0*L)) + 2.5e-3; // 0.02;  //1.e-3;
//      h[1] = .25; //* fabs(1. - exp (-circle1*L)) + 1.e-3;
//      h[2] = .25;

    double circle0= fabs(xyz[0] - R);
    h[2]=0.4;
    h[1]=0.4;
    h[0]=.4 * fabs(1. - exp (-circle0*L)) + 0.007;

    dirs[0][0]=1.0;
    dirs[0][1]=0.0;
    dirs[0][2]=0;
    dirs[1][0]=0.0;
    dirs[1][1]=1.0;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.;
    
    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }

  VIter_delete (vit);
  double beta[]={1.2,1.2,1.2};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}


int cylindericalShock(pMesh mesh, pSField field)
{  
  double R=.62;
  double L=2.;
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], norm;
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle= fabs(xyz[0] * xyz[0] +
//        xyz[1] * xyz[1] +
//        xyz[2] * xyz[2] - R*R);    
    double circle= fabs(xyz[0] * xyz[0] +
      xyz[1] * xyz[1] - R*R);
    h[0] = .14 * fabs(1. - exp (-circle*L)) + 0.17e-2;
    h[1] = .14;
    h[2] = .14;

    norm=sqrt(xyz[0]*xyz[0]+xyz[1]*xyz[1]);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=0;
	dirs[1][0]=-1.0*xyz[1]/norm;
	dirs[1][1]=xyz[0]/norm;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);
  return 1;
}


int sphericalShock(pMesh mesh, pSField field)
{  
  double R0=.62;
  double L=3.;
  double center[]={1.0, 0.0, 0.0};
  double tol=0.01;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, norm;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=dotProd(xyz,xyz);

    h[0] = .125 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.00125;
    h[1] = .125;
    h[2] = .124;

    norm=sqrt(R);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	if( xyz[0]*xyz[0] + xyz[1]*xyz[1] > tol*tol ) {
	  dirs[1][0]=-1.0*xyz[1]/norm;
	  dirs[1][1]=xyz[0]/norm;
	  dirs[1][2]=0;
	} else {
	  dirs[1][0]=-1.0*xyz[2]/norm;
	  dirs[1][1]=0;
	  dirs[1][2]=xyz[0]/norm;
	}
	crossProd(dirs[0],dirs[1],dirs[2]);
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);  
  double beta[]={2.5,2.5,2.5};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}


int twoSphericalShocks(pMesh mesh, pSField field)
{  
  double R0=.707;
  double L=3.;
  double center[]={1.0, 0.0, 0.0};
  double beta[]={2.0, 2.0, 2.0};
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, RR, norm, norm2;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=dotProd(xyz,xyz);
    RR= fabs((xyz[0]-1.0) * (xyz[0]-1.0) +
	     xyz[1] * xyz[1] +
	     xyz[2] * xyz[2] );    

    h[0] = .140 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.003;
    h[1] = .139 * fabs(1. - exp (-fabs(RR-R0)*L)) + 0.003;
    h[2] = .138;

    norm=sqrt(R);
    norm2=sqrt(RR);
    if( norm>tol && norm2>tol) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	dirs[1][0]=(xyz[0]-1.0)/norm2;
	dirs[1][1]=xyz[1]/norm2;
	dirs[1][2]=xyz[2]/norm2;
	crossProd(dirs[0],dirs[1],dirs[2]);

	if( xyz[1]*xyz[1] + xyz[2]*xyz[2] < tol )
	  {
	    if( xyz[0]>0.5 ) {
	      dirs[0][0]=1.0;
	      dirs[0][1]=0.0;
	      dirs[0][2]=0;
	      dirs[1][0]=0.0;
	      dirs[1][1]=1.0;
	      dirs[1][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    } else {
	      dirs[1][0]=1.0;
	      dirs[1][1]=0.0;
	      dirs[1][2]=0;
	      dirs[0][0]=0.0;
	      dirs[0][1]=1.0;
	      dirs[0][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    }

//  	    if( h[0] > h[1] ) {
//  	      double tmp=h[0];
//  	      h[0]=h[1];
//  	      h[1]=tmp;
//  	    }
	  }
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);

  //  AdaptUtil::viewMetricField(mesh,field );

  //  field->smooth_aniso(beta);
  return 1;
}


void uniformRefine(pMesh pm, meshAdapt &pAdapt)
{
  EIter eit=M_edgeIter(pm);
  pEdge edge;
  pGEntity gent;
  pFace face; 
  int count=0; 
//   cout<<"\nMarked edges: ";
  while( edge=EIter_next(eit) ) { 

//     gent=E_whatIn(edge);
//     int tag = GEN_tag(gent);
//     if(tag==22) {
//       //  pAdapt.setAdaptLevel(edge,1);
//       for(int j=0; j<E_numFaces(edge); j++) {
// 	face = E_face(edge, j);
// 	gent = F_whatIn(face); 
// 	if(GEN_tag(gent)==27)
// 	  break; 
//       }
      
//       // cout<<"Marked edges: "; 
//       for(int i=0; i< num_edge; i++) {
// 	pEdge tmpEdge = F_edge(face, i);
// 	pAdapt.setAdaptLevel(tmpEdge,1);
// 	cout<<EN_getUid(tmpEdge)<<" ";
//       }
//       cout<<endl; 
//     }
 
    if( count% num_edge ==0 ){
      pVertex vtx[2]; 
        int flag=0; 
        for(int i=0; i<2; i++) {
          vtx[i]=E_vertex(edge, i);
          double xyz[3]; 
          V_coord(vtx[i], xyz);  
          if(xyz[2]<=1)
            flag++; 
        }

     if(flag==2){
       pAdapt.setAdaptLevel(edge,1);
   //    cout<<EN_getUid(edge)<<" ";
     }
    }
      count++; 
  }
  EIter_delete(eit);
 //  cout<<endl; 
  pAdapt.run(1,0,0);
  return;
}


void printMatchingEnts(pMesh mesh, pGModel model, set<pVertex>& vertices)      
{
  // check whether the model is periodic
  int flag = GM_pbc(model);
  if(!flag) {
    cout<<"The model does not have pbc." <<endl;
    return; 
  }

  // int mypid = P_pid(); 

  cout<<"********* MATCHING ENTITY INFO ***********"<<endl; 

    // Traverse all of the pbcf
  PbcOnGFIter pbcfiter = GM_pbcOnGFaceIter(model);
  pbcOnGFace *pbcgf;
  //  int count = 0;
  while(pbcgf = PbcOnGFIter_next(pbcfiter)) {
    std::vector<pGFace> gf; 
    pbcgf->get_pbcFaces(gf); 
    
    std::vector<pGFace>::iterator gfiter = gf.begin(), gfitend = gf.end();
    
    while(gfiter != gfitend) {
      
      FIter fiter = M_classifiedFaceIter(mesh, *gfiter, 0);
      pFace face; 
      while(face=FIter_next(fiter)) {
	if(face!=0) {
	  assert(EN_isMatchingEnt(face)!=0);
	  printMatchInfo(face);
	  checkMatchInfo(face);
	}
      }
      FIter_delete(fiter);
      
      EIter eiter = M_classifiedEdgeIter(mesh, *gfiter, 0);
      pEdge edge;  
      while(edge=EIter_next(eiter)) {
	if(edge!=0) {
	  assert(EN_isMatchingEnt(edge)!=0);
	  printMatchInfo(edge);
	  checkMatchInfo(edge);
	}
      }
      EIter_delete(eiter);
      
      VIter viter = M_classifiedVertexIter(mesh, *gfiter, 0);
      pVertex vtx; 
      while(vtx = VIter_next(viter)){ 
	if(vtx!=0) {
	  assert(EN_isMatchingEnt(vtx)!=0);
	  printMatchInfo(vtx);
	  checkMatchInfo(vtx);
	  vertices.insert(vtx);
	}   
      }
      VIter_delete(viter);
      
      gfiter ++;
    }
  }
  PbcOnGFIter_delete(pbcfiter);

  // Traverse all of the pbce
  PbcOnGEIter pbceiter = GM_pbcOnGEdgeIter(model);
  pbcOnGEdge *pbcge;
  while(pbcge = PbcOnGEIter_next(pbceiter)) {
    std::vector<pGEdge> ge;
    pbcge->get_pbcEdges(ge);
        
    std::vector<pGEdge>::iterator geiter = ge.begin(), geitend = ge.end();
    while(geiter != geitend) {
     
      EIter eiter = M_classifiedEdgeIter(mesh, *geiter, 0);
      pEdge edge; 
      while(edge=EIter_next(eiter)) {
	if(edge!=0) {
	  assert(EN_isMatchingEnt(edge)!=0);
	  printMatchInfo(edge);
	  checkMatchInfo(edge);
	}
      }
      EIter_delete(eiter);
      
      VIter viter = M_classifiedVertexIter(mesh, *geiter, 0);
      pVertex vtx; 
      while(vtx = VIter_next(viter)){ 
	if(vtx!=0) {
	  assert(EN_isMatchingEnt(vtx)!=0);
	  printMatchInfo(vtx);
	  checkMatchInfo(vtx);
	  vertices.insert(vtx);
	}   
      }
      VIter_delete(viter);
      
      geiter ++;
    }
  }
  PbcOnGEIter_delete(pbceiter);

  
  //Traverse all of the pbcv
  PbcOnGVIter pbcviter = GM_pbcOnGVertexIter(model);
  pbcOnGVertex *pbcgv;
  while(pbcgv = PbcOnGVIter_next(pbcviter)) {
    std::vector<pGVertex> gv;
    pbcgv->get_pbcVertices(gv);
    
    std::vector<pGVertex>::iterator gviter = gv.begin(), gvitend = gv.end();
    while(gviter != gvitend) {
      
      pVertex vtx =  M_classifiedVertex(mesh, *gviter);
      if(vtx!=0) {
	assert(EN_isMatchingEnt(vtx)!=0);
	printMatchInfo(vtx);
	checkMatchInfo(vtx);
	vertices.insert(vtx);
      }
      gviter ++;
    }
    
  }
  PbcOnGVIter_delete(pbcviter);
  
  cout<<"******************************************"<<endl; 

}

void printMatchInfo(pEntity ent)
{
  pPList mlist = EN_getMatchingEnts(ent, 0);  
  
  //  int mypid = P_pid(); 
  cout<<"* "<<EN_getUid(ent)<<" ";  
  if(ent->getLevel()==0) {
    double xyz[3]; 
    V_coord((pVertex)ent, xyz);
    cout<<"("<<xyz[0]<<","<<xyz[1]<<","<<xyz[2]<<")"; 
  }
  cout<<": "; 
  void* it=0; 
  pEntity e; 
  while(e = (pEntity)PList_next(mlist, &it)){
    cout<<" "<<EN_getUid(e); 
  }
  cout<<endl; 
  // PList_delete(mlist);
}


void checkMatchInfo(pEntity ent)
{
  switch ( ent->getLevel()) {

  case 0 : 
    checkMatchVertex((pVertex)ent);
    break;

  case 1 : 
    checkMatchEdge((pEdge)ent);
    break;
    
  case 2 :
    checkMatchFace((pFace)ent);
    break;
    
  default : 
    cout<<"The matched entity dimension is not correct. "<<endl; 
  }
}
  

void checkMatchVertex(pVertex vtx)
{
  double xyz[3]; 
  V_coord(vtx, xyz);

  pPList mlist = EN_getMatchingEnts(vtx,0); 
  void* it=0; 
  pVertex v; 
  while(v=(pVertex)PList_next(mlist, &it)){
    double loc[3];
    V_coord(v, loc);
    double dis[3]; 
    for(int i=0; i<3; i++)  
     dis[i] = abs(xyz[i]-loc[i]);  
    
    int icount=0, jcount=0; 
    for(int i=0; i<3; i++) {          // icount=0, the same edge; icount=1, one pbc; icount=2, 2 pbcs.  
      if(dis[i]==2) 
	 icount++;   
      if(dis[i]==0.0)
	 jcount++; 
   }
 
    if (!(icount==1 && jcount==2))             // This geometric check is not proper for the sector model.  
      cout<<"The matched vertex info is not correct. "<<endl; 
   }
  // PList_delete(mlist);
}

void checkMatchEdge(pEdge edge){
  
  pVertex srcVtx[2]; 
  pPList srcVList[2]; 
  int flag[2]; 
  flag[0]=0; 
  flag[1]=0; 

  for(int i=0; i<2; i++){
    srcVtx[i]  = E_vertex(edge, i);
    if(EN_isMatchingEnt(srcVtx[i]))  
      srcVList[i]= EN_getMatchingEnts(srcVtx[i],0);
    else {
      srcVList[i]=PList_new(); 
      PList_append(srcVList[i], (void*)srcVtx[i]);
      flag[i]=1; 
    }
  }
  
  pPList mlist = EN_getMatchingEnts(edge, 0);
  void* it=0; 
  pEdge e;
  pVertex v[2]; 
  while(e=(pEdge)PList_next(mlist, &it)){
    
    for(int i=0; i<2; i++)
      v[i]=E_vertex(e, i);
    
    int f1 = PList_inList(srcVList[0], (void*)v[0]); 
    int f2 = PList_inList(srcVList[1], (void*)v[1]);
    int f3 = PList_inList(srcVList[0], (void*)v[1]);
    int f4 = PList_inList(srcVList[1], (void*)v[0]); 
    
    if(!((f1&&f2)||(f3&&f4)) )
      cout<<"The matched edge info of is not correct. "<<endl; 
  }
//   PList_delete(mlist);

  for(int i=0; i<2; i++) {
    if(flag[i])
      PList_delete(srcVList[i]);
  }
}

void checkMatchFace(pFace face)
{
  int ne = F_numEdges(face);

  pVertex srcVtx[3]; 
  pPList srcVList[3]; 
  pEdge srcEd[3]; 
  pPList srcEList[3]; 
  int vflags[3];
  int eflags[3]; 
 
  for(int i=0; i<ne; i++){
    vflags[i]=0; 
    eflags[i]=0; 

    srcVtx[i]  = F_vertex(face, i); 
    if(EN_isMatchingEnt(srcVtx[i]))
      srcVList[i]= EN_getMatchingEnts(srcVtx[i], 0);
    else {
      srcVList[i]=PList_new(); 
      PList_append(srcVList[i], (void*)srcVtx[i]);
      vflags[i]=1; 
    }
    
    srcEd[i] = F_edge(face,i);
    if(EN_isMatchingEnt(srcEd[i]))
      srcEList[i]=EN_getMatchingEnts(srcEd[i], 0);
    else {
      srcEList[i]=PList_new(); 
      PList_append(srcEList[i], (void*)srcEd[i]);
      eflags[i]=1; 
    }
  }
  
  // define entities' matching order 
  int fme[6][3]= {{0,1,2}, {2,0,1}, {1,2,0}, {2,1,0}, {1,0,2}, {0,2,1}}; 
  int fmv[6][3]= {{0,1,2}, {2,0,1}, {1,2,0}, {0,2,1}, {2,1,0}, {1,0,2}}; 
  
  pPList mlist = EN_getMatchingEnts(face, 0);
  void* it=0; 
  pFace f;
  pVertex v[3];
  pEdge e[3]; 
  while(f=(pFace)PList_next(mlist, &it)){
    
    for(int i=0; i<ne; i++){
      v[i]=F_vertex(f, i);
      e[i]=F_edge(f,i);
    }
    
    int flag=0; 
    for(int j=0; j<6; j++) 
      {
	int fv[3];
	int fe[3]; 
	for(int k=0; k<3; k++) {
	  fv[k] = PList_inList(srcVList[k], (void*)v[fmv[j][k]]);
	  fe[k] = PList_inList(srcEList[k], (void*)e[fme[j][k]]);
	}
	
	if((fv[0] && fv[1] && fv[2]) && (fe[0] && fe[1] && fe[2])) {
	  flag=1; 
	  break; 
	}
      }
    
    if(flag==0) {
      cout<<"The matched face info of is not correct. "<<endl; 
      cout<<"matched face: "<<EN_getUid(face)<<", "<<EN_getUid(f)<<endl;
      break; 
    }
  }
//   PList_delete(mlist);
  
  for(int i=0; i<ne; i++){
    if(vflags[i])
      PList_delete(srcVList[i]);
    if(eflags[i])
      PList_delete(srcEList[i]);
  }
}



