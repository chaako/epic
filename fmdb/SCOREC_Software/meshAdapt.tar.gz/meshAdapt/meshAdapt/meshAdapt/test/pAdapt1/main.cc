#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "visUtil.h"
#include "PWLinearSField.h"
#include "fromMeshTools.h"
#include <stdlib.h>
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>

#include "ParUtil.h"

#include "parasolid_kernel.h"
#ifdef AOMD_
#include "modelerParasolid.h"
#else
#include "SimParasolidKrnl.h"
#endif

#ifdef AOMD_
#include "AOMD.h"
#include "mAOMD.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "MeshTools.h"
#ifdef PARALLEL
#include "SF_MigrationCallbacks.h"
#endif
#endif

#define FILE "/users/xli/stop.check"

extern "C" int readLicenseFile(char *filename);
int sizefield(pMesh,pSField,void *);
int planarShock(pMesh,pSField);
int cylindericalShock(pMesh,pSField);
int sphericalShock(pMesh, pSField);
int twoSphericalShocks(pMesh,pSField);
void uniformRefine(pMesh,meshAdapt &);


int sf;  // size field indicator
using std::cout;


int main(int argc, char* argv[])
{  
#ifdef PARALLEL
  AOMD::ParUtil::Instance()->init (argc,argv);
  if (AOMD::ParUtil::Instance()->master())
    system("rm part*");
#endif
  
  if ( argc!=4 ) { 
    printf("Usage: %s filename sizefield iterations \n\n",argv[0]);
    printf("filename: a mesh file name for a cubic domain from (0,0,0)->(1,1,1)\n");
    printf("          carre - 2D model to test AOMD only\n");
    printf("          cube2 - a structured mesh with 26 nodes 32 elements\n");
    printf("          cube1 - an unstructured mesh with 824 nodes 3748 elements\n");
    printf("sizefield: An integer to indicate a defined mesh size field:\n");
    printf("           1 - a planar shock at x=0.5 \n");
    printf("           2 - a cylinderical shock centered at x=0 \n");
    printf("           3 - a spherical shock \n");
    printf("           4 - two spherical shocks \n");
    printf("iteration: the iterations allowed in case adapation is not converged\n\n"); 
    return 0;
  }

#ifdef PARALLEL
/*
  int i;
  printf("My processor ID: %d\n",M_Pid());
  if(AOMD::ParUtil::Instance()->master())
   {
      cout<<"enter (0/1) ";
      std::cin>>i;
   }
  
  printf("I am waiting\n");
    // sleep(10);
  M_sync();
*/
#endif
  
  char model_file[256];
  char mesh_file[256];
  char outmesh[256];
  char without_extension[256];
  
  snprintf(without_extension,strlen(argv[1])-3,"%s",argv[1]);
  sprintf(mesh_file,"%s",argv[1]);
  sprintf(model_file,"%s.xmt_txt",without_extension);
  sf=atoi(argv[2]);
  int niter=atoi(argv[3]);

  MS_init();
  pGModel model=GM_createFromParasolidFile(model_file);
  /*
if(M_Pid()==0)
{
	//int w;
        //printf("type in a number: \n");
        //(void) scanf("%d", &w);

        int result;
        struct stat Buffer;
        result = stat(FILE,&Buffer);

        while (result != 0) {
                cout << result << endl;
                sleep(1);
                result = stat(FILE,&Buffer);
        }
        cout << "Stat found file" << endl;

}
*/

  pMesh mesh=MS_newMesh(model);
  pSField field=new PWLsfield(mesh);
  double t1=AOMD::ParUtil::Instance()->wTime();
  M_load(mesh,mesh_file);

#ifndef PARALLEL
  M_checkAdj(mesh);
  adaptUtil::M_checkPar(mesh,0);
#endif
  M_verify(mesh);

  //  meshAdapt rdr(mesh,field,2,0);
  meshAdapt rdr(mesh,field,0,0);  // snap off;

  myTimer tt;
  rdr.run(niter,1, sizefield);
  double t2=AOMD::ParUtil::Instance()->wTime();
  
  //  uniformRefine(mesh, rdr);
if (P_pid()==0)
{ printf("Total clock time: %f\n",tt.elapsedCPU());

}  
  sprintf(outmesh,"%s-refined.sms",without_extension);

#ifndef PARALLEL
  M_checkAdj(mesh);
  adaptUtil::M_checkPar(mesh,0);
  adaptUtil::M_checkShape(mesh,field);
#endif
  M_verify(mesh);
  //  visUtil::writeDX(mesh,field);
#ifndef PARALLEL
  M_writeSMS(mesh,outmesh,2);
#else
//  sprintf(outmesh,"part%d.msh",M_Pid());
//  std::ofstream o (outmesh);
//  AOMD::AOMD_Util::Instance()->exportDGFile(o,mesh);
//  o.close();
#endif
  M_printNumEntities(mesh);
  if (P_pid()==0)
  { 
    cout<<"\n# partitions = "<<P_size()<<"\n";
    cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
  }  
  delete field;
  M_delete(mesh);
  //  GM_delete(model);
  MS_exit();    

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->Finalize();
#endif
  return 1;
} 


int sizefield(pMesh mesh, pSField field, void *)
{
  switch( sf ) {
  case 1: planarShock(mesh,field); break;
  case 2: cylindericalShock(mesh,field); break;
  case 3: sphericalShock(mesh,field); break;
  case 4: twoSphericalShocks(mesh,field); break;
  default:
    printf("Error: mesh size field not defined\n");
    exit(0);
  }
  return 1;
}


int planarShock(pMesh mesh,pSField field)
{
  double R=.5;
  double L=1.;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3];
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle0= fabs(xyz[0] - R);
//      h[0] = .25 * fabs(1. - exp (-circle0*L)) + 2.5e-3; // 0.02;  //1.e-3;
//      h[1] = .25; //* fabs(1. - exp (-circle1*L)) + 1.e-3;
//      h[2] = .25;

    double circle0= fabs(xyz[0] - R);
    h[2]=0.4;
    h[1]=0.4;
    h[0]=.4 * fabs(1. - exp (-circle0*L)) + 0.007;

    dirs[0][0]=1.0;
    dirs[0][1]=0.0;
    dirs[0][2]=0;
    dirs[1][0]=0.0;
    dirs[1][1]=1.0;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.;
    
    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }

  VIter_delete (vit);
  double beta[]={1.2,1.2,1.2};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}


int cylindericalShock(pMesh mesh, pSField field)
{  
  double R=.62;
  double L=2.;
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], norm;
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle= fabs(xyz[0] * xyz[0] +
//        xyz[1] * xyz[1] +
//        xyz[2] * xyz[2] - R*R);    
    double circle= fabs(xyz[0] * xyz[0] +
      xyz[1] * xyz[1] - R*R);
    h[0] = .14 * fabs(1. - exp (-circle*L)) + 0.17e-2;
    h[1] = .14;
    h[2] = .14;

    norm=sqrt(xyz[0]*xyz[0]+xyz[1]*xyz[1]);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=0;
	dirs[1][0]=-1.0*xyz[1]/norm;
	dirs[1][1]=xyz[0]/norm;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);
  return 1;
}


int sphericalShock(pMesh mesh, pSField field)
{  
  double R0=.62;
  double L=3.;
  double center[]={1.0, 0.0, 0.0};
  double tol=0.01;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, norm;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=dotProd(xyz,xyz);

    h[0] = .125 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.00125;
    h[1] = .125;
    h[2] = .124;

    norm=sqrt(R);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	if( xyz[0]*xyz[0] + xyz[1]*xyz[1] > tol*tol ) {
	  dirs[1][0]=-1.0*xyz[1]/norm;
	  dirs[1][1]=xyz[0]/norm;
	  dirs[1][2]=0;
	} else {
	  dirs[1][0]=-1.0*xyz[2]/norm;
	  dirs[1][1]=0;
	  dirs[1][2]=xyz[0]/norm;
	}
	crossProd(dirs[0],dirs[1],dirs[2]);
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);  
  double beta[]={2.5,2.5,2.5};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}


int twoSphericalShocks(pMesh mesh, pSField field)
{  
  double R0=.707;
  double L=3.;
  double center[]={1.0, 0.0, 0.0};
  double beta[]={2.0, 2.0, 2.0};
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, RR, norm, norm2;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=dotProd(xyz,xyz);
    RR= fabs((xyz[0]-1.0) * (xyz[0]-1.0) +
	     xyz[1] * xyz[1] +
	     xyz[2] * xyz[2] );    

    h[0] = .140 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.003;
    h[1] = .139 * fabs(1. - exp (-fabs(RR-R0)*L)) + 0.003;
    h[2] = .138;

    norm=sqrt(R);
    norm2=sqrt(RR);
    if( norm>tol && norm2>tol) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	dirs[1][0]=(xyz[0]-1.0)/norm2;
	dirs[1][1]=xyz[1]/norm2;
	dirs[1][2]=xyz[2]/norm2;
	crossProd(dirs[0],dirs[1],dirs[2]);

	if( xyz[1]*xyz[1] + xyz[2]*xyz[2] < tol )
	  {
	    if( xyz[0]>0.5 ) {
	      dirs[0][0]=1.0;
	      dirs[0][1]=0.0;
	      dirs[0][2]=0;
	      dirs[1][0]=0.0;
	      dirs[1][1]=1.0;
	      dirs[1][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    } else {
	      dirs[1][0]=1.0;
	      dirs[1][1]=0.0;
	      dirs[1][2]=0;
	      dirs[0][0]=0.0;
	      dirs[0][1]=1.0;
	      dirs[0][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    }

//  	    if( h[0] > h[1] ) {
//  	      double tmp=h[0];
//  	      h[0]=h[1];
//  	      h[1]=tmp;
//  	    }
	  }
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);

  //  AdaptUtil::viewMetricField(mesh,field );

  //  field->smooth_aniso(beta);
  return 1;
}


void uniformRefine(pMesh pm, meshAdapt &pAdapt)
{
  EIter eit=M_edgeIter(pm);
  pEdge edge;
  while( edge=EIter_next(eit) ) {
    pAdapt.setAdaptLevel(edge,1);
  }
  EIter_delete(eit);
  pAdapt.run(1,0,0);
  return;
}
