#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "visUtil.h"
#include "MeshSize.h"
#include "PWLinearSField.h"
#include "fromMeshTools.h"
#include <stdlib.h>
#include <stdio.h>
#include <fstream.h>
#include <math.h>
#include<string.h>
#include "parasolid_kernel.h"
#include "SimParasolidKrnl.h"

#ifdef MVTK
#include "mvtk.h"
#endif

#define ABS(x) ((x) < 0 ? -(x) : (x))


typedef struct Hessian {
  double h[3];
  double dir[3][3];
};

typedef struct phCB {
  int ndof;
  pMeshDataId phSol;
};


extern "C" int readLicenseFile(char *filename);
extern "C" void GF_normal(pGFace f, double *par, double *xyz);

void attachSoln(char *solfile,pMesh mesh,pMeshDataId phSol,int ndof,int P);
void hessianToDX(pMesh mesh);
double maxLocalError(pVertex vertex, double H[3][3]);
double E_error(pEdge edge, double H[3][3]);
void correctBdryMeshSize(pMesh, pGModel, pSField);
// nshg    number of nodes
void errorread( char* fname, double* errvec, int nshg, int nvar );
void writeSoln(pMesh mesh, pMeshDataId phasta_solution, int ndof, int lstep);
void V_guessSol(pVertex vt, phCB *userdata);
void V_getHession(double *errvec, int i, int comp, int nshg, double T[3][3]);

extern "C" void phCallback(pPList oldRgns, pPList, void *userdata, 
			   modType modi, pEntity ent)
{
  int i;
  void *ptr;

  switch( modi ) {
  case ECOLAPS:
    // free the solution attached to the vertex to be collapsed
    if( EN_getDataPtr( ent,((phCB*)userdata)->phSol,&ptr ) )
      delete [] ((double *)ptr);
    break;

  case RCOLAPS:
    printf("Not Implemented 1. (phCallback)\n");
    break;

  case ESPLIT:
    V_guessSol((pVertex)ent,(phCB*)userdata);
    break;

  case E_REFINE:{
    pVertex vts[2];
    double t,exyz[2][3],loc[3];
    double* soln[2];

    pEdge edge=(pEdge)PList_item(oldRgns,0);
    for( i=0; i<2; i++ ) {
      vts[i] = E_vertex(edge,i);
      V_coord(vts[i],exyz[i]);
      if( !EN_getDataPtr((pEntity)vts[i],((phCB*)userdata)->phSol,&ptr) )
	printf("Error: no solution available (phCallback)\n");
      soln[i]=(double *)ptr;
    }

    V_coord((pVertex)ent,loc);
    t=adaptUtil::ParOnLinearEdge(exyz,loc);

    double* newsoln = new double [ ((phCB*)userdata)->ndof ];
    for (i=0; i < ((phCB*)userdata)->ndof; i++)
      newsoln[i] = (1.-t)*soln[0][i] + t*soln[1][i];

    if( t>1 || t<0 )
      printf("Error: t=%f (phCallback())\n",t);

    EN_attachDataPtr(ent,((phCB*)userdata)->phSol, (void *)newsoln );
    break;
  }

  case R_REFINE: {
    if( ent ) {
      double* vcc;
      double* soln = new double [ ((phCB*)userdata)->ndof ];
      
      for (i=0; i <((phCB*)userdata)->ndof; i++)
	soln[i]=0.0;
      
      pPList rverts=R_vertices((pRegion)PList_item(oldRgns,0),1);
      void *iter=0;
      pVertex vertex;
      while( vertex=(pVertex)PList_next(rverts,&iter) ) {
	if( !EN_getDataPtr((pEntity)vertex,((phCB*)userdata)->phSol,&ptr) )
	  printf("Error: no solution available (phCallback)\n");
	vcc = (double *)ptr;
	for( i=0; i<((phCB*)userdata)->ndof; i++ ) 
	  soln[i] += vcc[i];
      }
      PList_delete(rverts);
      
      for (i=0; i < ((phCB*)userdata)->ndof; i++)
	soln[i]=soln[i]/4.0;
      
      EN_attachDataPtr(ent, ((phCB*)userdata)->phSol, (void *)soln);
    }
    break;
  }
  }
  
  return;
}


// guess and attach the solution at vertex "vt" from its neigboring vertices
void V_guessSol(pVertex vt, phCB *userdata)
{ 
  pVertex vt_next;
  int ne,i, j;
  double* vcc;  
  void *tmp;
  double* soln = new double [ userdata->ndof ];

  for (i=0; i < userdata->ndof; i++)
    soln[i]=0.0;

  ne=V_numEdges(vt);
  for( i=0; i<ne; i++ ) {
    vt_next=E_otherVertex(V_edge(vt,i),vt);
    if( EN_getDataPtr((pEntity)vt_next,userdata->phSol,&tmp) ) {
      vcc=(double *)tmp;
      for (j=0; j < userdata->ndof; j++) 
	soln[j] += vcc[j];
    }
    else
      printf("Error: a vertex without solution attached (writeSoln)\n");
  }
  
  for (i=0; i < userdata->ndof; i++)
    soln[i]=soln[i]/double(ne);

  EN_attachDataPtr( (pEntity)vt, userdata->phSol, (void *) soln );
  return;
}



int main(int argc, char* argv[])
{  
  if ( argc < 5 ) {
    cout << "usage: " << argv[0] 
	 <<" modelname timestep u/v/w meanErrorReduceRatio [ ndof ]" << endl;
    exit( -1 );
  }
  int lstep=atoi(argv[2] );
  double factor=atof(argv[4]);
  int poly = 1;   // polynomial order
  int ndof =5;    // number of solution variables
  int nvar = 18;  // number of variables in error file
  int nshg;       // number of nodes
  if ( argc > 5 ) 
    ndof = atoi( argv[5] );

  char model_file[28];
  char mesh_file[28];
  char solution_file[28];
  char error_file[28];
  sprintf(solution_file,"restart.%i.0",lstep);
  sprintf(error_file,"error.%i.0",lstep);  
  //  sprintf(model_file,"JMWedge.xmt_txt");  
  //  sprintf(model_file,"finalPipe10.xmt_txt");
  sprintf(model_file,"%s.xmt_txt",argv[1]);  
  sprintf(mesh_file,"geom.sms");  

  // Input Data
  //  double hmin=0.05, hmax=2.;   // for quadratic solution
  //  double hmin=0.02, hmax=2.;   // for cubic solution
  //  double hmin=0.0005, hmax=0.02;   // for straight pipe - pipe
  double hmin=0.00001, hmax=0.3;     // for straight pipe - bar_2
  double tol=1.e-12;

#ifdef MVTK
  double c[]={0.0,0.0,0.0};
  mvtkLoad();
  mvtkInit();
  MS_init();
  readLicenseFile(NULL);
  SimParasolid_start(1);
  pGModel model=GM_createFromParasolidFile(model_file);
  mvtkShowModel(model, c, 1000, 2);
  mvtkActivate();
#else
  MS_init();
  readLicenseFile(NULL);
  SimParasolid_start(1);
  pGModel model=GM_createFromParasolidFile(model_file);
#endif
  
  pMesh mesh=MS_newMesh(model);
  M_setTolerance(mesh);
  M_load(mesh,mesh_file);
  
  // attaching the solution to the original coarse mesh
  pMeshDataId phasta_solution = MD_newMeshDataId("restart solution");
  attachSoln( solution_file, mesh,  phasta_solution, ndof, poly );

  // read hession
  nshg=M_numVertices(mesh);
  double *errvec = new double[nshg*nvar];
  errorread( error_file, errvec, nshg, nvar );
  
  Hessian *hess = new Hessian[nshg];
  double T[3][3];
  double maxEigenval=0;
  int i,j;

  VIter vit=M_vertexIter(mesh);
  pVertex vertex;
  double eloc;            // local error at a vertex
  double etot=0;          // total error for all vertices
  double emean;           // emean = etot / nv
  double elocmax=0;       // max local error
  double elocmin=1e20;    // min local error
  for( i=0; i<nshg; i++ ) {
    vertex=VIter_next(vit);

    V_getHession(errvec, i, atoi(argv[3]), nshg, T);

    // compute eigen values and eigen vectors
    adaptUtil::eigen (T,hess[i].dir,hess[i].h);
    hess[i].h[0] = ABS(hess[i].h[0]);
    hess[i].h[1] = ABS(hess[i].h[1]);
    hess[i].h[2] = ABS(hess[i].h[2]);

    if( hess[i].h[0] < tol ) {
      printf("Error: zero maximum eigenvalue !!!\n");
      printf("       %f %f %f\n", hess[i].h[0],
	     hess[i].h[1],hess[i].h[2]);
      printf("       %f %f %f %f %f %f\n\n",T[0][0], 
	     T[0][1],T[0][2],T[1][1],T[1][2],T[2][2]);
      continue;
    }
    
    // estimate relative interpolation error
    eloc=maxLocalError(vertex,T);
    etot += eloc;
    if( eloc>elocmax )  elocmax=eloc;
    if( eloc<elocmin )  elocmin=eloc;
  }
  printf("Info: Reading hessian... done...\n");

  emean =  etot / nshg;
  printf("\n info on relative interpolation error: ");
  printf("   total: %f\n",etot);
  printf("   mean:  %f\n",emean);
  printf("   max local: %f\n",elocmax);
  printf("   min local: %f\n",elocmin);

  eloc=emean*factor;
  printf("\n towards uniform local error distribution of %f\n", eloc);
  printf("   with max edge length=%f; min edge length=%f\n\n",hmax,hmin);
  
  // scale the hessian
  //  double errorSqRoot = hmin*sqrt(maxEigenval);
  pSField field=new PWLinearSField(mesh);
  VIter_reset(vit);
  i=0;
  while ( vertex=VIter_next(vit)) {
    for( j=0; j<3; j++ ) {
      if( hess[i].h[j] < tol )
	hess[i].h[j] = hmax;
      else {
	hess[i].h[j] = sqrt(eloc/hess[i].h[j]);
  	if( hess[i].h[j] > hmax )
  	  hess[i].h[j] = hmax;
	if( hess[i].h[j] < hmin )
	  hess[i].h[j] = hmin;
      }
    }

    ((PWLinearSField *)field)->setSize((pEntity)vertex,
				       hess[i].dir,hess[i].h);
    ++i;
  }
  delete [] hess;
  VIter_delete(vit);

  // correct mesh size at boundary
  //  correctBdryMeshSize(mesh, model, field);

  // correct mesh size field based on prior information
  //  void correctBdryMeshSizeByGeometry(pMesh mesh, pModel model, pSField);

  // smooth mesh size field
  double fact[]={1.4,1.4,1.4};
  ((PWLinearSField *)field)->anisoSmooth(fact);

  visUtil::writeDX(mesh,field);

  meshAdapt rdr(mesh,field,2,0);  // 2: parametric model, 1: mesh model, 0: snap off;

  // set up call back function
  phCB phData;
  phData.ndof=ndof;
  phData.phSol=phasta_solution;
  rdr.setCallback(phCallback,(void *)(&phData));

  // execute
  myTimer tt;
  rdr.run(20 ,0, 0);
  printf("Total clock time: %f\n",tt.elapsedCPU());

  // write out solution
  writeSoln(mesh, phasta_solution, ndof, lstep);
  MD_deleteMeshDataId( phasta_solution );

  printf(" Total # of elements: %d\n", M_numRegions(mesh));
  printf(" Total # of vertices: %d\n", M_numVertices(mesh));
  adaptUtil::M_checkShape(mesh,field);
  adaptUtil::M_checkRatio(mesh);

  M_writeSMS(mesh,"adapted.sms",2);

  delete field;
  M_delete(mesh);
  GM_delete(model);
  SimParasolid_stop(1);           
  MS_exit();    

  return 1;
} 


/*
  errvec: error vector.
          store the errvec vector in the format [u11,v11,w11,u12,v12,w12,
                                                 u13,v13,w13,u22,v22,w22,
                                                 u23,v23,w23,u33,v33,w33,
                                                 for the next node continues.......]
  i:      vertex number in the order of SMS format
  comp:   binary representation of Hessian vector (0<comp<9)
            1 1 1
            w v u
          that is:  u : 1
                    v : 4
                    w : 8
  T is the 3*3 tensor returned
*/
void V_getHession(double *errvec, int i, int comp, int nshg, double T[3][3])
{
  switch ( comp ) {
  case 1:   // u
    T[0][0]=errvec[i];
    T[0][1]=errvec[3*nshg+i];
    T[0][2]=errvec[9*nshg+i];
    T[1][1]=errvec[6*nshg+i];
    T[1][2]=errvec[12*nshg+i];
    T[2][2]=errvec[15*nshg+i];
    break;
  case 4:   // v
    T[0][0]=errvec[nshg+i];
    T[0][1]=errvec[4*nshg+i];
    T[0][2]=errvec[10*nshg+i];
    T[1][1]=errvec[7*nshg+i];
    T[1][2]=errvec[13*nshg+i];
    T[2][2]=errvec[16*nshg+i];
    break;
  case 8:   // w
    T[0][0]=errvec[2*nshg+i];
    T[0][1]=errvec[5*nshg+i];
    T[0][2]=errvec[11*nshg+i];
    T[1][1]=errvec[8*nshg+i];
    T[1][2]=errvec[14*nshg+i];
    T[2][2]=errvec[17*nshg+i];
    break;
  default:
    printf("Not implemented (V_getHession)\n");
  }

  T[1][0]=T[0][1];
  T[2][0]=T[0][2];
  T[2][1]=T[1][2];
  return;
}

void writeSoln(pMesh mesh, pMeshDataId phasta_solution, int ndof, int lstep)
{
  // compute again the mesh parameters for the fine mesh
  int nshg_fine = M_numVertices( mesh );
  
  // retrieving the solution
  
  double* soln;
  void *tmp;
  int vcounter=0;
  int i,j;
  VIter vIter = M_vertexIter( mesh );
  pVertex vertex;
  double* q = new double [ nshg_fine * ndof ];
  while ( vertex = VIter_next( vIter ) ) {
    if( !EN_getDataPtr((pEntity)vertex,phasta_solution,&tmp) )
      printf("Error: a vertex without solution attached (writeSoln)\n");
    soln=(double *)tmp;
    j=0;
    for( i=0; i< ndof; i++ ) {
      q[vcounter+j] = soln[i]; /*store the solution into q vector in the format 
				 [P(1),P(2).....P(nshg),
				 u(1),....u(nshg),
				 v(1),...v(nshg),
				 w(1),......,
				 T(1),.......]*/
      j=j+nshg_fine;
    }
    vcounter = vcounter+1; 
  }
  
  // writiing out the solution into a restart file
  
  int one=1;
  int magic_number = 362436;
  FILE* frest = fopen("restart_fine.out","w");
  
  /* writing the top ascii header for the restart file */
  
  fprintf(frest,"# PHASTA Initial Conditions File Version 1.0\n");
  fprintf(frest,"# format \"keyphrase : sizeofbinaryblock usual headers\"\n");
  fprintf(frest,"# Output generated by M2M3D version: 1.0\n");
  time_t timenow = time ( &timenow);
  fprintf(frest,"# %s\n", ctime( &timenow ));
  fprintf(frest,"byteorder magic number : < %d >\n",sizeof(int));
  fwrite((void *)&magic_number, sizeof(int), one, frest);
  fprintf(frest,"\n");
  
  /* writing the q array in binary format */
  
  fprintf(frest,"solution : < %d > %d %d %d \n", 
	  ( ndof * nshg_fine * sizeof(double) ) +sizeof(char),
	  nshg_fine, ndof, lstep);

  fwrite((void *)q, sizeof(double), ndof*nshg_fine,frest);
  
  delete [] q;
  fprintf(frest,"\n");
  fflush( frest );
  fclose( frest );
}


void hessianToDX(pMesh mesh)
{
  double dir[3][3];
  double h[3];
  double loc[3];
  double T[3][3];
  double grad[3];
  int i,j,k,l;
  pVertex vt;
  pRegion rgn;
  
  /*  
      nshgtot=number of vertices
      numvar is the number of solution variables (9 if hessian)
      nendx=4 since you only have tets
      neltot is the number of elements
  */
  int numvar=18, nendx=4;
  int nshgtot=M_numVertices(mesh);
  int neltot=M_numRegions(mesh);

  int nv, nv2;
  ifstream infile("whessian.dat");
  ifstream gradFile("wgradian.dat");
  infile >> nv;
  gradFile >> nv2;
  if( nv!=M_numVertices(mesh) || nv2!=nv ) {
    printf("Info: hession field not match the mesh\n");
    infile.close();
    gradFile.close();
    return;
  }

  float *qdx;    // postions of all vertices  
  int *iendx;    // connectivities
  float *xdx;    // data attached on vertices
  xdx = (float *) malloc( 3*nshgtot * sizeof(float));
  iendx = (int *) malloc( nendx*neltot * sizeof(int));
  qdx = (float *) malloc( numvar*nshgtot * sizeof(float));
  
  VIter vit=M_vertexIter(mesh);
  for( i=0; i<nshgtot; i++ ) {
    vt=VIter_next(vit);
    gradFile >> grad[0] >> grad[1] >>  grad[2]; 
    EN_setID((pEntity)vt,i+1);
    infile >> T[0][0] >> T[0][1] >> T[0][2] >> T[1][1] >> T[1][2] >> T[2][2];
    T[1][0]=T[0][1];
    T[2][0]=T[0][2];
    T[2][1]=T[1][2];

    // compute eigen values and eigen vectors
    adaptUtil::eigen (T,dir,h);
    h[0] = ABS(h[0]);
    h[1] = ABS(h[1]);
    h[2] = ABS(h[2]);

    qdx[i*numvar]=(float)T[0][0];
    qdx[i*numvar+1]=(float)T[0][1];
    qdx[i*numvar+2]=(float)T[0][2];
    qdx[i*numvar+3]=(float)T[1][1];
    qdx[i*numvar+4]=(float)T[1][2];
    qdx[i*numvar+5]=(float)T[2][2];
    for( k=0; k<3; k++) {
      for( l=0; l<3; l++ ) {
	j=3*k+l+6;
	qdx[i*numvar+j]=(float)h[k]*dir[k][l];
      }
    }
    qdx[i*numvar+15]=(float)grad[0];
    qdx[i*numvar+16]=(float)grad[1];
    qdx[i*numvar+17]=(float)grad[2];
  }
    
  // put vertex locations into array "xdx"
  VIter_reset(vit);
  for(i=0; i< nshgtot; i++) {
    vt=VIter_next(vit);
    V_coord(vt,loc);
    for(j=0; j < 3; j++)
      xdx[i*3+j]=(float)loc[j];
  }
  VIter_delete (vit);
  
  // put connectivity into array "iendx"
  RIter rit=M_regionIter(mesh);
  pPList rverts;
  void *iter;
  for(i=0; i< neltot; i++) {
    rgn=RIter_next(rit);
    rverts=R_vertices(rgn,1);
    iter=0;
    j=0;
    while( vt=(pVertex)PList_next(rverts,&iter) ) {
      iendx[i*nendx+j]=EN_id((pEntity)vt)-1;
      j++;
    }
    PList_delete(rverts);
  }
  RIter_delete(rit);
  
  // write the mesh and metric field
  visUtil::wrtc_(&numvar, &neltot, iendx,
		 &nshgtot, xdx, qdx,&nendx);
  
  free(xdx);
  free(iendx);
  free(qdx);
  infile.close();
  gradFile.close();
}


// max relative interpolation error at a vertex
double maxLocalError(pVertex vertex, double H[3][3])
{
  pEdge edge;
  double locE;
  double maxLocE=0;

  for(int i=0; i<V_numEdges(vertex); i++ ) {
    edge=V_edge(vertex,i);
    locE=E_error(edge,H);
    if( locE > maxLocE )
      maxLocE=locE;
  }

  return maxLocE;
}


// relative interpolation error along an edge
double E_error(pEdge edge, double H[3][3])
{
  double xyz[2][3], vec[3];
  double locE=0;
  int i,j;

  V_coord(E_vertex(edge,0),xyz[0]);
  V_coord(E_vertex(edge,1),xyz[1]);
  diffVt(xyz[0],xyz[1],vec);

  for( i=0; i<3; i++ )
    for( j=0; j<3; j++ ) 
      locE += H[i][j]*vec[i]*vec[j];

  return ABS(locE);
}

// correct mesh size at boundary
void correctBdryMeshSize(pMesh mesh, pGModel model, pSField field) 
{
  pGFace gf;
  pFace face;
  pRegion region;
  pVertex vertex, vertex_2;
  pPList verts;
  pMSize pT0, pT1;
  double norm[3], par[3];
  double lenSqNorm0, lenSqNorm1;
  void *iter;

  pGFace gent[3];
  gent[0] = (pGFace)GM_entityByTag(model,2,156);
  gent[1] = (pGFace)GM_entityByTag(model,2,900);
  gent[2] = (pGFace)GM_entityByTag(model,2,955);

  FIter fit=M_faceIter(mesh);
  while ( face=FIter_next(fit)) {
    if( F_whatInType(face) == Gregion )
      continue;
    region=F_region(face,0);
    if( !region )
      region=F_region(face,1);
    if( !region )
      printf("Error: no region attached to face (main.cc)");

    gf=(pGFace)F_whatIn(face);
    if( gf==gent[0] )  continue;
    if( gf==gent[1] )  continue;
    if( gf==gent[2] )  continue;

    vertex=R_fcOpVt(region,face);
    if( V_whatInType(vertex) != Gregion )
      continue;
    pT0=field->getSize(vertex);

    verts=F_vertices(face,1);
    iter=0;
    while( vertex_2=(pVertex)PList_next(verts,&iter) ) {
      if( V_whatInType(vertex_2) != Gregion )
	continue;
      adaptUtil::V_reparamOnGFace(vertex_2,gf,par);
      GF_normal(gf,par,norm);
      lenSqNorm0=pT0->dirLengthSq(norm);

      pT1=field->getSize(vertex_2);
      lenSqNorm1=pT1->dirLengthSq(norm);
      if( lenSqNorm1 >= 1.1*lenSqNorm0 ) {
	pMSize pS = new MeshSize(pT0); 
	field->setSize((pEntity)vertex_2,pS);
//        printf("...Info: boundary mesh size corrected  vertex=%d %f ->%f\n",EN_id((pEntity)vertex_2),lenSqNorm1,lenSqNorm0);
      }
    }
    PList_delete(verts);
  }

  FIter_delete(fit);
}

//  void correctBdryMeshSizeByGeometry(pMesh mesh, pModel model, pSField)
//  {
//    pGFace gf;
//    pMSize pT;
//    double par[3], norm[3];
//    double *d, h[3], e[3][3];
//    pGFace gent[2];
  
//    gent[0] = (pGFace)GM_entityByTag(model,2,15);
//    gent[1] = (pGFace)GM_entityByTag(model,2,9);

//    VIter_reset(vit);
//    while ( vertex=VIter_next(vit)) {
//      if( V_whatInType(vertex) != Gface )
//        continue;
//      gf = (pGFace)V_whatIn(vertex);
//      if( gf==gent[0] )
//        continue;
//      if( gf==gent[1] )
//        continue;
//      P_param2(V_point(vertex),&par[0],&par[1],(int*)&par[2]);
//      GF_normal(gf,par,norm);
//      printf("Normal: (%f  %f  %f)\n",norm[0],norm[1],norm[2]);

//      pT=field->getSize(vertex);
//      //    if( pT->dirLengthSq(norm) < 2.*hmin )
//      //      continue;
//      for( i=1; i<3; i++ ) {
//         h[i]=pT->size(i);
//         d=pT->eigenvector(i);
//         e[i][0]=d[0];
//         e[i][1]=d[1];
//         e[i][2]=d[2];
//      }
//      h[0]=hmin;
//      h[1]=hmax;
//      h[2]=hmax;
//      e[0][0]=norm[0];
//      e[0][1]=norm[1];
//      e[0][2]=norm[2];
//      ((PWLinearSField *)field)->setSize((pEntity)vertex,e,h);
//    }
//    VIter_delete(vit);
//  }



#define swap_char(A,B) { ucTmp = A; A = B ; B = ucTmp; }
static int swapbyteorder=0;

static int cscompare(const char* s1, const char* s2)
{
  while( *s1 == ' ') s1++;
  while( *s2 == ' ') s2++;
  while((*s1) && (*s2) &&(tolower(*(s1++))==tolower(*(s2++))))
    {
      while( *s1 == ' ') s1++;
      while( *s2 == ' ') s2++;
    }
  if (!(*s1) && !(*s2)) return 1;
  else return 0;
}

static void SwapArrayByteOrder(void* array, int nbytes, int nItems)
{
  int i,j;
  unsigned char  ucTmp;
  unsigned char* ucDst = (unsigned char*)array;

  for(i=0; i < nItems; i++) {
    for(j=0; j < (nbytes/2); j++)
      swap_char( ucDst[j] , ucDst[(nbytes - 1) - j] );
    ucDst += nbytes;
  }
}

void restart_sol(char* solfile, double *q, int nshg, int nvr)
{
  FILE* orest = fopen(solfile,"r");
  int swapbyteorder, nshgl, nvl,i,j;  
  double* qlocal;
  char *pch, header[255], inpLine[125];
  int lstep;
   
  int notdoneyet=1, rlen, skipsize, tmpint;

  
  fgets(inpLine, 125, orest);
  while(!feof(orest) && notdoneyet) { 
    if ( inpLine[0] != '\n') {
      rlen = strcspn(inpLine,"#"); 
      if ( rlen > 0) { /* ignore comment lines */

	// 	header = (char *) malloc( rlen+1);    
        strncpy(header,inpLine,rlen);
        header[rlen] = NULL;  /* add terminate character */
        
        /* tokenize and look for what we want */
        pch = strtok(header,":");
        if(cscompare(pch,"solution")){
          
          pch = strtok(NULL," ,;<>");
          skipsize = atoi(pch);
          
          pch = strtok(NULL," ,;<>");
          nshgl = atoi(pch);
          
          pch = strtok(NULL," ,;<>");
          nvl = atoi(pch);
          
          if ( nvl < nvr ) {
            fprintf( stderr, 
                     " Your restartfile has lesser number of solution variables\n");
            fprintf( stderr, " than you are trying to read. \n" );
            exit( 0 );
          }
          
          pch = strtok(NULL," ,;<>");
          lstep = atoi(pch);
          
          qlocal = (double *)malloc(sizeof(double)* nshgl * nvl);
          fread((void *)qlocal,sizeof(double),nshgl*nvl, orest);
          fscanf(orest,"\n");
          
          notdoneyet=0;
          break;
        } else if(cscompare(pch,"byteorder magic number")){
          
          fread((void *)&tmpint,sizeof(int),1,orest);
          if( 362436 != tmpint ) swapbyteorder=1;
          else swapbyteorder = 0;
          fscanf(orest,"\n");
          
        } else {
          
          pch = strtok(NULL," ,;<>");
          skipsize = atoi(pch);
          fseek(orest,skipsize,SEEK_CUR);
        }
	//        free( header ); 
      }
    }
    fgets(inpLine, 125, orest);  
  }	 
  
  
  fclose(orest);
  
  if(notdoneyet){
    fprintf(stderr,"could not find solution in restart file \n");
    exit(1);
  }
  if( swapbyteorder)
    SwapArrayByteOrder((void *)qlocal, sizeof(double), nshgl*nvl);
  
  /* copy the needed part into the array passed in */
  
  for(i=0; i < nvr; i++)
    for(j=0; j < nshg; j++)
      q[i*nshg+j] = qlocal[i*nshgl+j];
  
  /* destroying the local array */
  free(qlocal);
  
}



void errorread(char* solfile, double *q, int nshg, int nvr)
{
  FILE* orest = fopen(solfile,"r");
  int swapbyteorder, nshgl, nvl,i,j;  
  double* qlocal;
  char *pch, *header, inpLine[125];
  int lstep;
   
  int notdoneyet=1, rlen, skipsize, tmpint;
   
  fgets(inpLine, 125, orest);
  while(!feof(orest) && notdoneyet) { 
    if ( inpLine[0] != '\n') {
      rlen = strcspn(inpLine,"#"); 
      if ( rlen > 0) { /* ignore comment lines */
        header = (char *) malloc( rlen+1);
        strncpy(header,inpLine,rlen);
        header[rlen] = NULL;  /* add terminate character */
        
        /* tokenize and look for what we want */
        pch = strtok(header,":");
        if(cscompare(pch,"solution")){
          
          pch = strtok(NULL," ,;<>");
          skipsize = atoi(pch);
          
          pch = strtok(NULL," ,;<>");
          nshgl = atoi(pch);
          
          pch = strtok(NULL," ,;<>");
          nvl = atoi(pch);
          
          if ( nvl < nvr ) {
            fprintf( stderr, 
                     " Your restartfile has lesser number of solution variables\n");
            fprintf( stderr, " than you are trying to read. \n" );
            exit( 0 );
          }
          
          pch = strtok(NULL," ,;<>");
          lstep = atoi(pch);
          
          qlocal = (double *)malloc(sizeof(double)* nshgl * nvl);
          fread((void *)qlocal,sizeof(double),nshgl*nvl, orest);
          fscanf(orest,"\n");
          
          notdoneyet=0;
          break;
        } else if(cscompare(pch,"byteorder magic number")){
          
          fread((void *)&tmpint,sizeof(int),1,orest);
          if( 362436 != tmpint ) swapbyteorder=1;
          else swapbyteorder = 0;
          fscanf(orest,"\n");
          
        } else {
          
          pch = strtok(NULL," ,;<>");
          skipsize = atoi(pch);
          fseek(orest,skipsize,SEEK_CUR);
        }
      }
    }
    fgets(inpLine, 125, orest);  
  }	 
  
  
  fclose(orest);
  
  if(notdoneyet){
    fprintf(stderr,"could not find solution in restart file \n");
    exit(1);
  }
  if( swapbyteorder)
    SwapArrayByteOrder((void *)qlocal, sizeof(double), nshgl*nvl);
  
  /* copy the needed part into the array passed in */
  
  for(i=0; i < nvr; i++)
    for(j=0; j < nshg; j++)
      q[i*nshg+j] = qlocal[i*nshgl+j];
  
  /* destroying the local array */
  
  free(qlocal);
}


void attachSoln( char *solfile, 
                 pMesh mesh, 
                 pMeshDataId phSol,
                 int ndof, 
                 int P ) {
  int count,i;
  double *soln;
  int nem = (P > 1) ? (P - 1) : 0;
  int nfm = (P > 3) ? ((P-3)*(P-2)/2.0) : 0;
  int nrm = (P > 5) ? ((P-4)*(P-5)*(P-3)/6.0) : 0;
  if(P==3) nfm =1;
  
  int nshg = M_numVertices(mesh) + nem * M_numEdges(mesh)
    + nfm * M_numFaces(mesh) + nrm * M_numRegions(mesh);

  double* q_ji = new double[nshg*ndof];
  double* q = new double[nshg*ndof];
  
  // read solution file

  restart_sol( solfile, q_ji, nshg, ndof );

  // transpose the solution

  for(i = 0; i< nshg; i++)
      for( int j=0; j< ndof; j++)
          q[i*ndof+j] = q_ji[j*nshg+i];

  delete [] q_ji;

  /* attach the vertex coefficients */
  count = 0;
  pVertex vertex;
  VIter vIter = M_vertexIter( mesh );
  while (vertex = VIter_next( vIter ) ) {
    soln = new double[ndof];
    for (i=0; i < ndof; i++) soln[i] = q[count++];
    EN_attachDataPtr( (pEntity)vertex, phSol, (void *) soln );
  }
  VIter_delete( vIter );

  /* attach the edge coefficients */
  if (nem > 0){
    pEdge edge;
    EIter eIter = M_edgeIter( mesh );
    while (edge = EIter_next( eIter ) ) {
      soln = new double[ndof*nem];
      for (i=0; i < ndof*nem; i++) soln[i] = q[count++];
      EN_attachDataPtr( (pEntity)edge, phSol, (void *) soln );
    }
    EIter_delete( eIter );
  }
  
  /* attach face coefficients */
  if (nfm > 0){
    pFace face;
    FIter fIter = M_faceIter( mesh );
    while (face = FIter_next( fIter ) ) {
      soln = new double[ndof*nfm];
      for ( i=0; i < ndof*nfm; i++ ) soln[i] = q[count++];
      EN_attachDataPtr( (pEntity)face, phSol, (void *) soln );
    }
    FIter_delete( fIter );
  }
  /* attach region coefficients */
  if (nrm > 0) {
     cerr << " No code to attach Region Modes " << endl;
     exit ( -1 );
  }

  delete[] q;
}
