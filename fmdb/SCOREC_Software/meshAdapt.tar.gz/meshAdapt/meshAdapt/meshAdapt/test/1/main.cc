#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <fstream>
#include <iostream>

#ifdef AOMD_
#include "AOMD_Internals.h"
#include "MeshTools.h"
#endif


#include "parasolid_kernel.h"
#include "MeshSimParasolid.h"


extern "C" int readLicenseFile(char *filename);

int CB_count=0;

extern "C" void myCallback(pPList oldCavity, pPList newcavity,void *userdata)
{
  CB_count++;
  // PList_printx(oldCavity);
  // PList_printx(newcavity);
}


int main(int argc, char* argv[])
{  
  if ( argc!=2 ) {
    cerr << "Usages:" << argv[0]<<"  mesh" << endl;
    return 0;
  }

  pEdge edge;
  char model_file[256];
  char mesh_file[256];
  char outmesh[256];
  char without_extension[256];

  snprintf(without_extension,strlen(argv[1])-3,"%s",argv[1]);
  sprintf(mesh_file,"%s",argv[1]);
  sprintf(outmesh,"%s-refined",without_extension);

  MS_init();
  SimParasolid_start(1);
  sprintf(model_file,"%s.xmt_txt",without_extension);
  pGModel model=GM_createFromParasolidFile(model_file);

  pMesh mesh=MS_newMesh(model);
  M_load(mesh,mesh_file);

#ifdef AOMD_
  // create a representation that mimics
  // meshsim mesh datastructure.  
  M_SetRepresentationToOneLevel(mesh);
#endif

//    pRegion rgn;
//    RIter rgniter=M_regionIter(mesh);
//    while( rgn=RIter_next(rgniter) )
//      cout<<R_volume(rgn)<<endl;
//    RIter_delete(rgniter);

    //  M_checkAdj(mesh);

  // tag-driven procedure
  //    MeshAdapt rdr(mesh,1,1);  
  meshAdapt rdr(mesh,0,0,1);    // snap off  
  rdr.setCallback(myCallback,0);

  int n,i;
  int ne=M_numEdges(mesh);
  int *ind=new int[ne];
  for( i=0; i<ne; i++ )  ind[i]=0;
    srand(1001);
  for( i=0; i<ne; i++ ) {
    n=rand()%ne;
    ind[n]=1;
  }

  EIter editer=M_edgeIter(mesh);
  i=0; n=0;
  while( edge=EIter_next(editer) ) 
    //    if( ind[i++] ) {
      rdr.setAdaptLevel(edge,1);
  //        n++;
    }
  EIter_delete(editer);

  cout<< n <<" of "<<ne<<"mesh edges are marked for refinement"<<endl;
  delete[] ind;
    
  // do refinement
  cout<<"-------Begin refining and snapping-----"<<endl;
  rdr.run();
  cout << " refinement and snapping done !!!" << endl;
  cout << " call Callback function "<<CB_count<<" times"<<endl;

  M_writeSMS(mesh,outmesh,2);

  M_delete(mesh);
  GM_delete(model);
  MS_exit();    
  return 1;
} 




