#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "visUtil.h"
#include "PWLinearSField.h"
#include "fromMeshTools.h"
#include <stdlib.h>
#include <stdio.h>
#include <algorithm>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>

#ifdef PARALLEL
#include "ParUtil.h"
#endif

#include "parasolid_kernel.h"
#ifdef AOMD_
#include "modelerParasolid.h"
#else
#include "SimParasolidKrnl.h"
#endif

#ifdef AOMD_
#include "AOMD.h"
#include "mAOMD.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "MeshTools.h"
#ifdef PARALLEL
#include "SF_MigrationCallbacks.h"
#endif
#endif

//#define FILE "/medusa/osahni/stop.check"

extern "C" int readLicenseFile(char *filename);
int sizefield(pMesh,pSField,void *);
int planarShock(pMesh,pSField);
int cylindericalShock(pMesh,pSField);
int sphericalShock(pMesh, pSField);
int ellipsoidShock(pMesh, pSField);
int twoSphericalShocks(pMesh,pSField);
void uniformRefine(pMesh,meshAdapt &);


int sf;  // size field indicator
double t;

int main(int argc, char* argv[])
{  
#ifdef PARALLEL
  AOMD::ParUtil::Instance()->init (argc,argv);
  if (AOMD::ParUtil::Instance()->master())
    system("rm part*");
#endif
  
  if ( argc!=7 ) { 
    printf("Usage: %s model-file mesh-file sizefield iterations dt factor\n\n",argv[0]);
    printf("sizefield: An integer to indicate a defined mesh size field:\n");
    printf("           1 - a planar shock at x=0.5 \n");
    printf("           2 - a cylinderical shock centered at x=0 \n");
    printf("           3 - a spherical shock \n");
    printf("           4 - a ellipsoid shocks \n");
    printf("           5 - two spherical shocks \n");
    printf("iteration: the iterations allowed in case adapation is not converged\n\n"); 
    return 0;
  }

  char model_file[256];
  char mesh_file[256];
  char outmesh[256];
  char without_extension[256];
  
  snprintf(without_extension,strlen(argv[2])-3,"%s",argv[2]);
  sprintf(mesh_file,"%s",argv[2]);
  //sprintf(model_file,"%s.xmt_txt",without_extension);
  sprintf(model_file,"%s",argv[1]);
  sf=atoi(argv[3]);
  int niter=atoi(argv[4]);

  MS_init();
  pGModel model=GM_createFromParasolidFile(model_file);

/*if(M_Pid()==0)
{
        int result;
        struct stat Buffer;
        result = stat(FILE,&Buffer);

        while (result != 0) {
                cout << result << endl;
                sleep(1);
                result = stat(FILE,&Buffer);
        }
        cout << "Stat found file" << endl;

}*/
    
//MPI_Barrier(MPI_COMM_WORLD);
//printf("Passed the barrier in main\n");


  pMesh mesh=MS_newMesh(model);
  pSField field=new PWLsfield(mesh);

  double t1=AOMD::ParUtil::Instance()->wTime();
  M_load(mesh,mesh_file);

  double dt=atof(argv[5]);
  int factor=atoi(argv[6]);
  double tend=dt*factor;
  t=0.0;
  int itimestep=0;
  double totalt=0.0;
  while(t<=tend){
  double t1=AOMD::ParUtil::Instance()->wTime();
  meshAdapt rdr(mesh,field,0,0);  // snap off;

  myTimer tt;

/*  int notToConstrain[6] = {2,58,487,518,549,2535};
  std::sort(notToConstrain, notToConstrain + 6);

  pGFace gm_face;
  GFIter gm_face_iter=GM_faceIter(model);
  while(gm_face=GFIter_next(gm_face_iter)) {
  int ID=GEN_id((pGEntity)gm_face);
  if(!std::binary_search(notToConstrain, notToConstrain+6,ID))
      rdr.setConstraint((pGEntity)gm_face);
  }
  GFIter_delete(gm_face_iter);
*/  
  rdr.run(niter,1, sizefield);
  double t2=AOMD::ParUtil::Instance()->wTime();
  totalt+=t2-t1;
  //uniformRefine(mesh, rdr);
  int check=itimestep%1;
  //adaptUtil::M_checkShape(mesh,field);
#ifndef PARALLEL
  M_checkAdj(mesh);
#endif
  
  t=t+dt;
  ++itimestep;
  } // while
  
  M_printNumEntities(mesh);

  if (P_pid()==0)
  {
    cout<<"\n# partitions = "<<P_size()<<endl;
    cout<<"TIME = "<<totalt<<endl<<endl;
  }
  
  delete field;
  M_delete(mesh);
  GM_delete(model);
  MS_exit();    

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->Finalize();
#endif
  return 1;
} 


int sizefield(pMesh mesh, pSField field, void *)
{
  switch( sf ) {
  case 1: planarShock(mesh,field); break;
  case 2: cylindericalShock(mesh,field); break;
  case 3: sphericalShock(mesh,field); break;
  case 4: ellipsoidShock(mesh,field); break;
  case 5: twoSphericalShocks(mesh,field); break;
  default:
    printf("Error: mesh size field not defined\n");
    exit(0);
  }
  return 1;
}


int planarShock(pMesh mesh,pSField field)
{
  double R=.5;
  double L=1.;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3];
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle0= fabs(xyz[0] - R);
//      h[0] = .25 * fabs(1. - exp (-circle0*L)) + 2.5e-3; // 0.02;  //1.e-3;
//      h[1] = .25; //* fabs(1. - exp (-circle1*L)) + 1.e-3;
//      h[2] = .25;

    double circle0= fabs(xyz[0] - R);
    h[2]=0.4;
    h[1]=0.4;
    h[0]=.4 * fabs(1. - exp (-circle0*L)) + 0.007;

    dirs[0][0]=1.0;
    dirs[0][1]=0.0;
    dirs[0][2]=0;
    dirs[1][0]=0.0;
    dirs[1][1]=1.0;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.;
    
    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }

  VIter_delete (vit);
  //  field->smooth(2);
  return 1;
}


int cylindericalShock(pMesh mesh, pSField field)
{  
  double R=.62;
  double L=2.;
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], norm;
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle= fabs(xyz[0] * xyz[0] +
//        xyz[1] * xyz[1] +
//        xyz[2] * xyz[2] - R*R);    
    double circle= fabs(xyz[0] * xyz[0] +
      xyz[1] * xyz[1] - R*R);
    h[0] = .14 * fabs(1. - exp (-circle*L)) + 0.17e-2;
    h[1] = .14;
    h[2] = .14;

    norm=sqrt(xyz[0]*xyz[0]+xyz[1]*xyz[1]);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=0;
	dirs[1][0]=-1.0*xyz[1]/norm;
	dirs[1][1]=xyz[0]/norm;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);
  return 1;
}


int sphericalShock(pMesh mesh, pSField field)
{  
  double R0=0.1+t;
  double L=2.;//3.;
  double center[]={1.0, 0.0, 0.0};
  double tol=0.001;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, norm;
  double k=2.0;//0.5;
  double k1=0.125;//0.05;
  R0=R0*R0;
      
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);

    xyz[2]=xyz[2] - (-5.4711);
    R=dotProd(xyz,xyz);
  
    h[0] = k * fabs(1. - exp (-fabs(R-R0)*L)) + k1/100.;
    h[1] = k;
    h[2] = k;

    norm=sqrt(R);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	if( xyz[0]*xyz[0] + xyz[1]*xyz[1] > tol*tol*0.9 ) {
	  dirs[1][0]=-1.0*xyz[1]/norm;
	  dirs[1][1]=xyz[0]/norm;
	  dirs[1][2]=0;
	} else {
	  dirs[1][0]=-1.0*xyz[2]/norm;
	  dirs[1][1]=0;
	  dirs[1][2]=xyz[0]/norm;
	}
	crossProd(dirs[0],dirs[1],dirs[2]);
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);

  double beta[]={1.8,1.8,1.8};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}

int ellipsoidShock(pMesh mesh, pSField field)
{  
  double R0=1.0;//+10.0*t;
  double L=4.;
  //double center[]={1.0, 0.0, 0.0};
  double tol=0.001;
  double h[3], dirs[3][3], xyz[3], R, norm;
  double k=0.4;
  double k1=0.2;
  double a=0.2,b=0.4;
  R0=R0*R0;
      
  pVertex vt;
  VIter vit=M_vertexIter(mesh);  
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
  
    xyz[2]=xyz[2] - t;//- (-5.4711 - t);
    //R=dotProd(xyz,xyz);
    R=(xyz[0]*xyz[0]+xyz[1]*xyz[1])/(a*a)+xyz[2]*xyz[2]/(b*b);
    
    if(xyz[2] > 0.) h[0] = k * fabs(1. - exp (-fabs(R-R0)*L)) + k1/100.;
    else h[0] = k;
    
    h[1] = k;
    h[2] = k;

    norm=sqrt((xyz[0]*xyz[0]+xyz[1]*xyz[1])/(a*a*a*a)+xyz[2]*xyz[2]/(b*b*b*b));
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/(a*a*norm);
	dirs[0][1]=xyz[1]/(a*a*norm);
	dirs[0][2]=xyz[2]/(b*b*norm);
	if( xyz[0]*xyz[0] + xyz[1]*xyz[1] > tol*tol*0.9 ) {
	  dirs[1][0]=-1.0*xyz[1]/(a*a*norm);
	  dirs[1][1]=xyz[0]/(a*a*norm);
	  dirs[1][2]=0;
	} else {
	  dirs[1][0]=-1.0*xyz[2]/(b*b*norm);
	  dirs[1][1]=0;
	  dirs[1][2]=xyz[0]/(a*a*norm);
	}
	crossProd(dirs[0],dirs[1],dirs[2]);
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   
    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);

  }
  
  VIter_delete (vit);

  //double beta[]={1.8,1.8,1.8};
  //((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}

int twoSphericalShocks(pMesh mesh, pSField field)
{  
  double R0=.707;
  double L=3.;
  double center[]={1.0, 0.0, 0.0};
  double beta[]={2.0, 2.0, 2.0};
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, RR, norm, norm2;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=dotProd(xyz,xyz);
    RR= fabs((xyz[0]-1.0) * (xyz[0]-1.0) +
	     xyz[1] * xyz[1] +
	     xyz[2] * xyz[2] );    

    h[0] = .140 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.003;
    h[1] = .139 * fabs(1. - exp (-fabs(RR-R0)*L)) + 0.003;
    h[2] = .138;

    norm=sqrt(R);
    norm2=sqrt(RR);
    if( norm>tol && norm2>tol) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	dirs[1][0]=(xyz[0]-1.0)/norm2;
	dirs[1][1]=xyz[1]/norm2;
	dirs[1][2]=xyz[2]/norm2;
	crossProd(dirs[0],dirs[1],dirs[2]);

	if( xyz[1]*xyz[1] + xyz[2]*xyz[2] < tol*tol )
	  {
	    if( xyz[0]>0.5 ) {
	      dirs[0][0]=1.0;
	      dirs[0][1]=0.0;
	      dirs[0][2]=0;
	      dirs[1][0]=0.0;
	      dirs[1][1]=1.0;
	      dirs[1][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    } else {
	      dirs[1][0]=1.0;
	      dirs[1][1]=0.0;
	      dirs[1][2]=0;
	      dirs[0][0]=0.0;
	      dirs[0][1]=1.0;
	      dirs[0][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    }

//  	    if( h[0] > h[1] ) {
//  	      double tmp=h[0];
//  	      h[0]=h[1];
//  	      h[1]=tmp;
//  	    }
	  }
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);

  //  AdaptUtil::viewMetricField(mesh,field );

  //  field->smooth_aniso(beta);
  return 1;
}


void uniformRefine(pMesh pm, meshAdapt &pAdapt)
{
  EIter eit=M_edgeIter(pm);
  pEdge edge;
  while( edge=EIter_next(eit) ) {
    pAdapt.setAdaptLevel(edge,1);
  }
  EIter_delete(eit);
  pAdapt.run(1,0,0);
  return;
}
