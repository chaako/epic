#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "EdgeSwapMod.h"
#include "FaceSwapMod.h"
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include "Macros.h"

#ifdef AOMD_
#include "AOMD_Internals.h"
#include "MeshTools.h"
#endif

#ifdef PARASOLID
#include "parasolid_kernel.h"
#include "MeshSimParasolid.h"
#endif

extern "C" void myCallback(pPList oldCavity, pPList newcavity,void * /*userdata*/)
{
    PList_printx(oldCavity);
    PList_printx(newcavity);
    return;
}

int main(int argc, char* argv[])
{  
 if ( argc!=3 ) { 
  cerr<<"Usage: "<<argv[0]<<" mesh iteration"<<endl;
  return 0;
 }
 
  char model_file[256];
  char mesh_file[256];
  char outmesh[256];
  char without_extension[256];
  pEdge edge;
  pFace face;
  pRegion region;
  int i;

  snprintf(without_extension,strlen(argv[1])-3,"%s",argv[1]);
  sprintf(mesh_file,"%s",argv[1]);
  sprintf(outmesh,"%s-refined",without_extension);

  MS_init();

#ifdef PARASOLID
  sprintf(model_file,"%s.xmt_txt",without_extension);
  pGModel model=GM_createFromParasolidFile(model_file);
#endif
#ifdef NOMODEL
  sprintf(model_file,"%s.xmt_txt",without_extension);
  pGModel model=GM_createFromParasolidFile(model_file);
#endif

  pMesh mesh=MS_newMesh(model);
  M_load(mesh,mesh_file);

#ifdef AOMD_
  M_SetRepresentationToOneLevel(mesh);
#endif
  //  M_checkAdj(mesh);

  // set criteria to determine the application of mesh modifications
  meanRatio *shpMeasure=new meanRatio(0,ACPT_MEANRATIO);
  lengthSquare *sizMeasure=new lengthSquare(0,SIZE_UPPERBOUND,SIZE_LOWERBOUND);
  EvalResults *result=new EvalResults();

  // apply edge swap to improves worst shape
  int nswap;
  EdgeSwapMod eswp(mesh,0,shpMeasure,sizMeasure,result);
  eswp.setCallback(myCallback,0);
  eswp.setModelType(NOPARAM);

  EIter eit=M_edgeIter(mesh);
  for( i=0; i<atoi(argv[2]); i++ ) {
    nswap=0;

    while( edge=EIter_next(eit) )
      {
	eswp.setSwapEdge(edge);
	if( eswp.topoCheck() && eswp.geomCheck() ) {
	  if( result->getWorstShape() > AdaptUtil::E_worstShp(shpMeasure,edge) ) 
	    { 
	      eswp.apply(); 
	      nswap++;
	    }
	}
      }
    cout<<nswap<<" edge swap are performed"<<endl;
    EIter_reset(eit);
  } 
  EIter_delete(eit);

  // apply face swap to improves worst shape
  FaceSwapMod fswp(mesh,0,shpMeasure,sizMeasure,result);
  fswp.setCallback(myCallback,0);
  fswp.setModelType(NOPARAM);

  FIter fit=M_faceIter(mesh);
  for( i=0; i<atoi(argv[2]); i++ ) {
    nswap=0;

    while( face=FIter_next(fit) )
      {
	fswp.setSwapFace(face);
	if( fswp.topoCheck() && fswp.geomCheck() ) {
	  double tmp1, tmp2;
	  region=F_region(face,0);
	  if( region )
	    shpMeasure->get(region,&tmp1);
	  region=F_region(face,1);
	  if( region ) {
	    shpMeasure->get(region,&tmp2);
	    if( tmp2 < tmp1 )
	      tmp1=tmp2;
	  }
	  if( result->getWorstShape() > tmp1 ) 
	    { 
	      pPList newRgn=PList_new();
	      fswp.apply(&newRgn); 
	      PList_printx(newRgn);
	      PList_delete(newRgn);
	      nswap++;
	    }
	}
      }
    cout<<nswap<<" face swap are performed"<<endl;
    FIter_reset(fit);
  } 
  FIter_delete(fit);
  
  delete shpMeasure;
  delete sizMeasure;
  delete result;
  
  M_writeSMS(mesh,outmesh,2);
  M_delete(mesh);
  GM_delete(model);
  MS_exit();    

  return 1;
} 
