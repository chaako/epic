#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "visUtil.h"
#include "PWLinearSField.h"
#include "fromMeshTools.h"
#include <stdlib.h>
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>

//#ifdef PARALLEL
#include "ParUtil.h"
//#endif

#include "parasolid_kernel.h"
#ifdef AOMD_
#include "modelerParasolid.h"
#else
#include "SimParasolidKrnl.h"
#endif

#ifdef AOMD_
#include "AOMD.h"
#include "mAOMD.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "MeshTools.h"
#ifdef PARALLEL
#include "SF_MigrationCallbacks.h"
#endif
#endif

#define FILE "/users/xli/stop.check"

using std::endl; using std::cout;
using std::cerr;

extern "C" int readLicenseFile(char *filename);
int sizefield(pMesh,pSField,void *);
int planarShock(pMesh,pSField);
int cylindericalShock(pMesh,pSField);
int sphericalShock(pMesh, pSField);
int ellipsoidalShock(pMesh, pSField);
int twoSphericalShocks(pMesh,pSField);
int twoSphericalShocksBIG(pMesh,pSField);
void uniformRefine(pMesh,meshAdapt &);
int platemetric(pMesh , pSField);
void M_meditWrite2d(pMesh, char*); 
void M_meditWrite3d(pMesh, char*);


int sf;  // size field indicator


int main(int argc, char* argv[])
{  
#ifdef PARALLEL
  AOMD::ParUtil::Instance()->init (argc,argv);
  if (AOMD::ParUtil::Instance()->master())
    system("rm part*");
#endif
  
  if ( argc!=4 ) { 
    printf("Usage: %s filename sizefield iterations \n\n",argv[0]);
    printf("filename: a mesh file name for a cubic domain from (0,0,0)->(1,1,1)\n");
    printf("          torusHoles.sms - 2D model to test AOMD only\n");
    printf("or a mesh file name for a cylinder domain from [-1,1]x[-1,1]x[0,3]\n");
    printf("          pipe  - an unstructured mesh with 557 nodes 2400 elements\n");
    printf("sizefield: An integer to indicate a defined mesh size field:\n");
    printf("           1 - a planar shock at x=0.5 \n");
    printf("           2 - a cylinderical shock centered at x=0 \n");
    printf("           3 - a spherical shock \n");
    printf("           4 - two spherical shocks \n");
    printf("           5 - an ellipsoidal shock \n");
    printf("           6 - two spherical shocks BIG \n");
    printf("iteration: the iterations allowed in case adapation is not converged\n\n"); 
    return 0;
  }

#ifdef PARALLEL
/*
  int i;
  printf("My processor ID: %d\n",M_Pid());
  if(AOMD::ParUtil::Instance()->master())
   {
      cout<<"enter (0/1) ";
      std::cin>>i;
   }
  
  printf("I am waiting\n");
    // sleep(10);
  M_sync();
*/
#endif
  
  char model_file[256];
  char mesh_file[256];
  char outmesh[256];
  char without_extension[256];
  
  snprintf(without_extension,strlen(argv[1])-3,"%s",argv[1]);
  sprintf(mesh_file,"%s",argv[1]);
  sprintf(model_file,"%s.xmt_txt",without_extension);
  sf=atoi(argv[2]);
  int niter=atoi(argv[3]);

  MS_init();
  pGModel model=GM_createFromParasolidFile(model_file);
  /*
if(M_Pid()==0)
{
	//int w;
        //printf("type in a number: \n");
        //(void) scanf("%d", &w);

        int result;
        struct stat Buffer;
        result = stat(FILE,&Buffer);

        while (result != 0) {
                cout << result << endl;
                sleep(1);
                result = stat(FILE,&Buffer);
        }
        cout << "Stat found file" << endl;

}
*/

  pMesh mesh=MS_newMesh(model);
  pSField field=new PWLsfield(mesh);
  double t1=AOMD::ParUtil::Instance()->wTime();
  M_load(mesh,mesh_file);


  // write the initial mesh in medit format
  //sprintf(outmesh,"%s",without_extension);
  //if( M_numRegions(mesh)!=0 ) 
  //  M_meditWrite3d(mesh,outmesh);
  //else 
  //  M_meditWrite2d(mesh,outmesh);

  //  M_checkAdj(mesh);
  //  adaptUtil::M_checkPar(mesh,0);

  meshAdapt rdr(mesh,field,2,0);  // snap on
  //meshAdapt rdr(mesh,field,0,0);  // snap off;

  myTimer tt;
  rdr.run(niter,1, sizefield);
  double t2=AOMD::ParUtil::Instance()->wTime();
  
  //  uniformRefine(mesh, rdr);
if (P_pid()==0)
{ printf("Total clock time: %f\n",tt.elapsedCPU());

}  
  sprintf(outmesh,"%s-refined.sms",without_extension);
//    adaptUtil::M_checkShape(mesh,field);
#ifndef PARALLEL
  M_checkAdj(mesh);
#endif

  //  visUtil::writeDX(mesh,field);
#ifndef PARALLEL
  M_writeSMS(mesh,outmesh,2);
//#else
//  sprintf(outmesh,"part%d.msh",M_Pid());
//  std::ofstream o (outmesh);
//  AOMD::AOMD_Util::Instance()->exportDGFile(o,mesh);
//  o.close();
#endif

#ifdef PARALLEL
  sprintf(outmesh,"%s%dP",without_extension,M_Pid());
  if( M_getMaxNum(M_numRegions(mesh))!=0 ) 
    M_meditWrite3d(mesh,outmesh);
  else 
    M_meditWrite2d(mesh,outmesh);
#else
  sprintf(outmesh,"%s-refined",without_extension);
  if( M_numRegions(mesh)!=0 ) 
    M_meditWrite3d(mesh,outmesh);
  else 
    M_meditWrite2d(mesh,outmesh);
#endif

  M_printNumEntities(mesh);
  if (P_pid()==0)
  { 
    std::cout<<"\n# partitions = "<<P_size()<<"\n";
    std::cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
  }  
  delete field;
  M_delete(mesh);
  //  GM_delete(model);
  MS_exit();    

#ifdef PARALLEL
  AOMD::ParUtil::Instance()->Finalize();
#endif
  return 1;
} 


int sizefield(pMesh mesh, pSField field, void *)
{
  switch( sf ) {
  case 1: planarShock(mesh,field); break;
  case 2: cylindericalShock(mesh,field); break;
  case 3: sphericalShock(mesh,field); break;
  case 4: twoSphericalShocks(mesh,field); break;
  case 5: ellipsoidalShock(mesh,field); break;
  case 6: twoSphericalShocksBIG(mesh,field); break;
  case 7: platemetric(mesh,field); break;
  default:
    printf("Error: mesh size field not defined\n");
    exit(0);
  }
  return 1;
}


int planarShock(pMesh mesh,pSField field)
{
  double R=.5;
  double L=1.;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3];
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle0= fabs(xyz[0] - R);
//      h[0] = .25 * fabs(1. - exp (-circle0*L)) + 2.5e-3; // 0.02;  //1.e-3;
//      h[1] = .25; //* fabs(1. - exp (-circle1*L)) + 1.e-3;
//      h[2] = .25;

    double circle0 = fabs(xyz[0] - R);
    h[2] = 0.2;
    h[1] = 0.2;
    h[0] = 0.2 * fabs(1. - exp (-circle0*L)) + 0.003;

    dirs[0][0]=1.0;
    dirs[0][1]=0.0;
    dirs[0][2]=0;
    dirs[1][0]=0.0;
    dirs[1][1]=1.0;
    dirs[1][2]=0;
    dirs[2][0]=0;
    dirs[2][1]=0;
    dirs[2][2]=1.;
    
    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }

  VIter_delete (vit);
  //double beta[]={1.2,1.2,1.2};
  double beta[]={1.5,1.5,1.5};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}


int cylindericalShock(pMesh mesh, pSField field)
{  
  double R=1.; //.62;
  double L=2.;
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], norm;
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
//      double circle= fabs(xyz[0] * xyz[0] +
//        xyz[1] * xyz[1] +
//        xyz[2] * xyz[2] - R*R);    
    double circle= fabs(xyz[0] * xyz[0] +
      xyz[1] * xyz[1] - R*R);
    h[0] = .14 * fabs(1. - exp (-circle*L)) + 0.0015;
    h[1] = .14;
    h[2] = .14;

    norm=sqrt(xyz[0]*xyz[0]+xyz[1]*xyz[1]);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=0;
	dirs[1][0]=-1.0*xyz[1]/norm;
	dirs[1][1]=xyz[0]/norm;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);
  return 1;
}


int sphericalShock(pMesh mesh, pSField field)
{  
  double R0=1.; //.62;
  double L=3.;
  double center[]={1.0, 0.0, 0.0};
  double tol=0.01;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, norm;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=dotProd(xyz,xyz);

    h[0] = .125 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.00125;
    h[1] = .125;
    h[2] = .124;

    norm=sqrt(R);
    if( norm>tol ) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	if( xyz[0]*xyz[0] + xyz[1]*xyz[1] > tol*tol ) {
	  dirs[1][0]=-1.0*xyz[1]/norm;
	  dirs[1][1]=xyz[0]/norm;
	  dirs[1][2]=0;
	} else {
	  dirs[1][0]=-1.0*xyz[2]/norm;
	  dirs[1][1]=0;
	  dirs[1][2]=xyz[0]/norm;
	}
	crossProd(dirs[0],dirs[1],dirs[2]);
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);  
  double beta[]={2.5,2.5,2.5};
  ((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}



int ellipsoidalShock(pMesh mesh, pSField field)
{  
  // for the cube and torus
  //double aa = 0.62*0.62;
  //double bb = 1.*1.;//1.2*1.2;
  //double cc = 0.3*0.3;//0.2*0.2;
  // for the pipe
  double aa = 1.2*1.2;
  double bb = 2.*2.;
  double cc = 0.6*0.6;

  double L=3.;
  double tol=0.01;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], normal[3], center[3];
  double R, norm, xx, yy, zz;

  center[0] = center[1] = 0.25;
  //center[2] = 0.5;
  center[2] = 1.;
  
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    xx = xyz[0]-center[0];
    yy = xyz[1]-center[1];
    zz = xyz[2]-center[2];
    
    R = xx*xx/aa + yy*yy/bb + zz*zz/cc;
    
    // for the cube and torus
    //h[0] = .125 * fabs(1. - exp (-fabs(R-1)*L)) + 0.0125; 
    //h[1] = .125;
    //h[2] = .124 * fabs(1. - exp (-fabs(R-1)*L)) + 0.0125;
    // for the pipe
    h[0] = .5 * fabs(1. - exp (-fabs(R-1)*L)) + 0.005; 
    h[1] = .5;
    h[2] = .51 * fabs(1. - exp (-fabs(R-1)*L)) + 0.05;

    normal[0] = 2.0*xx/aa;
    normal[1] = 2.0*yy/bb;
    normal[2] = 2.0*zz/cc;

    norm = sqrt(dotProd(normal,normal));
    if( norm>tol ) 
      {
	dirs[0][0] = normal[0]/norm;
	dirs[0][1] = normal[1]/norm;
	dirs[0][2] = normal[2]/norm;

	if( normal[0]*normal[0] + normal[1]*normal[1] > tol*tol ) {
	  dirs[1][0] = -normal[1]/norm;
	  dirs[1][1] = normal[0]/norm;
	  dirs[1][2] = 0.;
	} 
	else {
	  dirs[1][0] = -normal[2]/norm;
	  dirs[1][1] = 0.;
	  dirs[1][2] = normal[0]/norm;
	}
	crossProd(dirs[0],dirs[1],dirs[2]);
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.;
	dirs[0][2]=0.;
	dirs[1][0]=0.;
	dirs[1][1]=1.0;
	dirs[1][2]=0.;
	dirs[2][0]=0.;
	dirs[2][1]=0.;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);  
  double beta[]={2.5,2.5,2.5};
  ((PWLsfield *)field)->anisoSmooth(beta);

  return 1;
}


int twoSphericalShocks(pMesh mesh, pSField field)
{  
  double R0=1.; //.707;
  double L=3.;
  double center[]={1.0, 0.0, 0.0};
  double beta[]={2.0, 2.0, 2.0};
  double tol=1.e-10;
  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, RR, norm, norm2;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R=dotProd(xyz,xyz);
    RR= fabs((xyz[0]-1.0) * (xyz[0]-1.0) +
	     xyz[1] * xyz[1] +
	     xyz[2] * xyz[2] );    

    h[0] = .140 * fabs(1. - exp (-fabs(R-R0)*L)) + 0.0015;
    h[1] = .139 * fabs(1. - exp (-fabs(RR-R0)*L)) + 0.0015;
    h[2] = .138;

    norm=sqrt(R);
    norm2=sqrt(RR);
    if( norm>tol && norm2>tol) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
	dirs[1][0]=(xyz[0]-1.0)/norm2;
	dirs[1][1]=xyz[1]/norm2;
	dirs[1][2]=xyz[2]/norm2;
	crossProd(dirs[0],dirs[1],dirs[2]);

	if( xyz[1]*xyz[1] + xyz[2]*xyz[2] < tol )
	  {
	    if( xyz[0]>0.5 ) {
	      dirs[0][0]=1.0;
	      dirs[0][1]=0.0;
	      dirs[0][2]=0;
	      dirs[1][0]=0.0;
	      dirs[1][1]=1.0;
	      dirs[1][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    } else {
	      dirs[1][0]=1.0;
	      dirs[1][1]=0.0;
	      dirs[1][2]=0;
	      dirs[0][0]=0.0;
	      dirs[0][1]=1.0;
	      dirs[0][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    }

//  	    if( h[0] > h[1] ) {
//  	      double tmp=h[0];
//  	      h[0]=h[1];
//  	      h[1]=tmp;
//  	    }
	  }
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);

  //  AdaptUtil::viewMetricField(mesh,field );

  //  field->smooth_aniso(beta);
  return 1;
}


int twoSphericalShocksBIG(pMesh mesh, pSField field)
{  
  double R0 = 1.;//.707;
  double R1 = 1.;//25;
  double L0 = 0.75;  //1.; //0.5;
  double L1 = 3.;
  double tol=1.e-10;

  pVertex vt;
  double h[3], dirs[3][3], xyz[3], R, RR, norm, norm2;
  VIter vit=M_vertexIter(mesh);
  R0=R0*R0;
  while( vt=VIter_next(vit) ) {
    V_coord(vt,xyz);
    R  = dotProd(xyz,xyz);
    RR = fabs((xyz[0]-1.0) * (xyz[0]-1.0) +
	     xyz[1] * xyz[1] + xyz[2] * xyz[2] );    

    h[0] = .140 * fabs(1. - exp (-fabs(R -R0)*L0)) + 0.004;
    h[1] = .139 * fabs(1. - exp (-fabs(RR-R1)*L1)) + 0.001;
    h[2] = .138;

    norm=sqrt(R);
    norm2=sqrt(RR);
    if( norm>tol && norm2>tol) 
      {
	dirs[0][0]=xyz[0]/norm;
	dirs[0][1]=xyz[1]/norm;
	dirs[0][2]=xyz[2]/norm;
        dirs[1][0]=(xyz[0]-1.0)/norm2;
        dirs[1][1]=xyz[1]/norm2;
        dirs[1][2]=xyz[2]/norm2;
	crossProd(dirs[0],dirs[1],dirs[2]);

	if( xyz[1]*xyz[1] + xyz[2]*xyz[2] < tol )
	  {
	    if( xyz[0]>0.5 ) {
	      dirs[0][0]=1.0;
	      dirs[0][1]=0.0;
	      dirs[0][2]=0;
	      dirs[1][0]=0.0;
	      dirs[1][1]=1.0;
	      dirs[1][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    } else {
	      dirs[1][0]=1.0;
	      dirs[1][1]=0.0;
	      dirs[1][2]=0;
	      dirs[0][0]=0.0;
	      dirs[0][1]=1.0;
	      dirs[0][2]=0;
	      dirs[2][0]=0;
	      dirs[2][1]=0;
	      dirs[2][2]=1.0;
	    }

	  }
      }
    else
      {
	dirs[0][0]=1.0;
	dirs[0][1]=0.0;
	dirs[0][2]=0;
	dirs[1][0]=0.0;
	dirs[1][1]=1.0;
	dirs[1][2]=0;
	dirs[2][0]=0;
	dirs[2][1]=0;
	dirs[2][2]=1.0;
      }   

    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }
  VIter_delete (vit);

  //  AdaptUtil::viewMetricField(mesh,field );

  //double beta[]={2.0, 2.0, 2.0};
  //  field->smooth_aniso(beta);
  return 1;
}




void uniformRefine(pMesh pm, meshAdapt &pAdapt)
{
  EIter eit=M_edgeIter(pm);
  pEdge edge;
  while( edge=EIter_next(eit) ) {
    pAdapt.setAdaptLevel(edge,1);
  }
  EIter_delete(eit);
  pAdapt.run(1,0,0);
  return;
}


int platemetric(pMesh mesh,  pSField field)
{
  pVertex vt;
  double h[3], dirs[3][3];
  VIter vit=M_vertexIter(mesh);
  while( vt=VIter_next(vit) ) {
//    h[2]=1.;
//    h[1]=0.1;
//    h[0]=0.1;

    h[2] = 0.2;
    h[0] = 0.2;
    double coor[3];
    V_coord(vt,coor);
 //   if ( fabs(coor[1]) > 0.43963714) 
 //     h[1] = 0.016127;  
 //   else 
 //     h[1] = -0.35*fabs(coor[1])+0.17;
    if ( fabs(coor[1]) > 0.4801) 
      h[1] = 0.016127;  
    else 
      h[1] = -0.32*fabs(coor[1])+0.17;

    dirs[0][0]=1.0;
    dirs[0][1]=0.;
    dirs[0][2]=0.;
    dirs[1][0]=0.;
    dirs[1][1]=1.0;
    dirs[1][2]=0.;
    dirs[2][0]=0.;
    dirs[2][1]=0.;
    dirs[2][2]=1.;
    
    ((PWLsfield *)field)->setSize((pEntity)vt,dirs,h);
  }

  VIter_delete (vit);
  //double beta[]={1.3,1.3,1.3};
  //((PWLsfield *)field)->anisoSmooth(beta);
  return 1;
}



// ***** add medit save for the output *****

void M_meditWrite2d(pMesh theMesh, char *name) 
{
  char fName[256];
  sprintf(fName,"%s.mesh",name);
  if (P_pid()==0) cout << "\n-- Writing Data File: " << fName << endl;

// Declaration
  std::ofstream ofs(fName);
  double coor[3];
  int nbTriangles, nbEdges, nbVertices;

  pVertex vertex;
  pFace triangle;
  pEdge edge; 

  pGModel model = M_model(theMesh); // recuperation du modele
  pGEdge gedge;  // model edge
  
  pMeshDataId nodalId = MD_newMeshDataId("meshId");

// Compte chaque entite
  nbTriangles = M_numFaces(theMesh);
  nbVertices  = M_numVertices(theMesh);

// nb de edge classifie sur un modele edge
  nbEdges = 0;
  GEIter geIter = GM_edgeIter(model);
  while(gedge=GEIter_next(geIter)) // boucle sur les model edges
  {
    nbEdges += M_numClassifiedEdges(theMesh,(pGEntity)gedge);
  }
  GEIter_reset(geIter);


// ----- Extraction et Ecriture du .mesh -----  
  ofs << "MeshVersionFormatted 1\n\n";
  ofs << "Dimension\n";
  ofs << "2\n";
  ofs << "#Mesh converted with meditWrite\n\n";


// Write Vertices
#ifndef PARALLEL
  cout << "Number of given Vertices\t" << nbVertices << "\n";
#endif
  if (nbVertices > 0 )
  {
    ofs << "Vertices\n" << nbVertices << endl;
    
    VIter vIter = M_vertexIter(theMesh);
    int i = 1;
    while(vertex=VIter_next(vIter)) // boucle sur les vertex
    {
      V_coord(vertex,coor); // extrait les coor du vertex
//      EN_setID((pEntity)vertex,i);   // definit le num du vertex
//    fct de AOMD dans AOMD/cint/AOMDInternals.h
      EN_attachDataInt(pEntity(vertex), nodalId, i); // definit le num du vertex
      ofs << coor[0] << " " << coor[1] << " 0\n"; 
      i++;
    }

    VIter_delete(vIter); // destructeur de l'iterateur
  }
  else
    cout << "Error : no vertices !!!";

// Write Triangles
#ifndef PARALLEL
  cout << "Number of given Triangles\t" << nbTriangles << "\n";
#endif

  if (nbTriangles > 0 )
  {
    ofs << "\n\nTriangles\n";
    ofs << nbTriangles << endl;
    
    FIter fIter = M_faceIter(theMesh);
    pPList listVertex;

    while(triangle=FIter_next(fIter)) // boucle sur les triangles
    {
      listVertex = F_vertices(triangle,1);
//    Attention preciser avant le type de la sortie (en anglais CAST)
//    on ne peut le faire que sur des pointeurs
      for (int i=0; i<3; ++i)
      {
        pEntity entity = (pEntity)PList_item(listVertex,i);
//        ofs << EN_id(entity) << " "; // EN_id ne prend que des pEntity
	int numNode;
	EN_getDataInt(entity, nodalId, &numNode);
	ofs << numNode << " "; 
      }
      ofs << " 0\n";
    }

    FIter_delete(fIter); // destructeur de l'iterateur
  }
  else
    cout << "Error : no triangles !!!";


// Write Edges
#ifndef PARALLEL
  cout << "Number of given Edges\t\t" << nbEdges << "\n";
#endif

  if ( nbEdges > 0 )
  {
    ofs << "\nEdges\n";
    ofs << nbEdges << endl;

    while(gedge=GEIter_next(geIter)) // boucle sur les model edges
    {
      EIter eIter = M_classifiedEdgeIter(theMesh,(pGEntity)gedge,0); 
      while(edge=EIter_next(eIter)) // boucle sur les edges du model edge
      {
	pVertex is1 = E_vertex(edge,0);
	pVertex is2 = E_vertex(edge,1);
//	ofs << EN_id((pEntity)is1) << " " << EN_id((pEntity)is2) << " ";
        int numNode1, numNode2;
        EN_getDataInt((pEntity)is1, nodalId, &numNode1);
        EN_getDataInt((pEntity)is2, nodalId, &numNode2);
        ofs << numNode1 << " " << numNode2 << " "; 

        ofs << GEN_tag((pGEntity)gedge) << "\n";
      }
      EIter_delete(eIter); // destructeur de l'iterateur

    }

    GEIter_delete(geIter); // destructeur de l'iterateur

  }
  else {
//    cout << "Error : no edges !!!";
    ofs << "\nEdges\n";
    ofs << 0 << endl;
  }
  

// Write Ridges
  ofs << "\nRidges\n";
  ofs << nbEdges << endl;
  for (int i=0; i<nbEdges; ++i)
  {
    ofs << i+1 << endl;
  }

// Write Corners
  ofs << "\nCorners\n";
  int nbCorners=0;
  VIter vIter1 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter1))       // boucle sur les vertex
  {
    // si Type=0 => c'est un corner car entity geom est un vertex
    if ( !V_whatInType(vertex) ) // => si corner
      nbCorners++;
  }
  VIter_reset(vIter1);                 // met a zero l'iterateur
  ofs << nbCorners << endl;

#ifndef PARALLEL
  cout << "Number of given Corners\t\t" << nbCorners << "\n";
#endif

// Bcle sur les sommets et prise en compte de ceux aillant un tag dans le modele
//  VIter vIter1 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter1))       // boucle sur les vertex
  {
    // si Type=0 => c'est un corner car entity geom est un vertex
    if ( !V_whatInType(vertex) ) // => si corner
    {
      int numNode;
      EN_getDataInt((pEntity)vertex, nodalId, &numNode);
      ofs << numNode << endl;
    }
  }
  VIter_delete(vIter1);                 // efface l'iterateur


//--- efface toutes nodalId  
  VIter vIter2 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter2))       // boucle sur les vertex
  {
    EN_deleteData((pEntity)vertex, nodalId);
  }
  VIter_delete(vIter2);                 // efface l'iterateur
  
  MD_deleteMeshDataId(nodalId);
//--- fin efface


  ofs << "\nEnd\n";
  ofs.close();

}




// On peut declarer les variables localements, car elles
// sont detruitent a la sortie d'un BLOC

void M_meditWrite3d(pMesh theMesh, char *name) 
{
  char fName[256];
  sprintf(fName,"%s.mesh",name);
  if (P_pid()==0) cout << "\n  -- Writing Data File: " << fName << endl;

// Declaration
  std::ofstream ofs(fName);
  double coor[3];
  int nbTriangles, nbEdges, nbVertices, nbTetras;

  pVertex vertex;
  pFace   triangle;
  pEdge   edge; 
  pRegion tetra;

  pGModel model = M_model(theMesh); // recuperation du modele
  pGFace gface;  // model triangle
  pGEdge gedge;  // model edge

  pMeshDataId nodalId = MD_newMeshDataId("meshId");
  
// ----- Compte chaque entite -----
  nbTetras   = M_numRegions(theMesh);
  nbVertices = M_numVertices(theMesh);


  // nb de triangle sur la peau
  nbTriangles = 0;
  GFIter gfIter = GM_faceIter(model);
  while(gface=GFIter_next(gfIter)) // boucle sur les model faces
  {  
    nbTriangles += M_numClassifiedFaces(theMesh,(pGEntity)gface);
  }
//  cout << "\nNbr de triangles classifiees =" << nbTriangles << endl;
  GFIter_reset(gfIter);
  
  // nb de edge classifie sur un modele edge
  nbEdges = 0;
  GEIter geIter = GM_edgeIter(model);
  while(gedge=GEIter_next(geIter)) // boucle sur les model edges
  {
    nbEdges += M_numClassifiedEdges(theMesh,(pGEntity)gedge);
  }
//  cout << "\nNbr de edges classifiees =" << nbEdges << endl;
  GEIter_reset(geIter);

  

// ----- Extraction et Ecriture du .mesh -----  
  ofs << "MeshVersionFormatted 1\n\n";
  ofs << "Dimension\n";
  ofs << "3\n";
  ofs << "#Mesh converted with M_writeMEDIT\n\n";

// Write Vertices
#ifndef PARALLEL
  cout << "Number of given Vertices\t" << nbVertices << "\n";
#endif

  if (nbVertices > 0 )
  {
    ofs << "Vertices\n" << nbVertices << endl;
    
    VIter vIter = M_vertexIter(theMesh);
    int i = 1;
    while(vertex=VIter_next(vIter)) // boucle sur les vertex
    {
      V_coord(vertex,coor);          // extrait les coor du vertex
//      EN_setID((pEntity)vertex,i);   // definit le num du vertex
//    fct de AOMD dans AOMD/cint/AOMDInternals.h
      EN_attachDataInt(pEntity(vertex), nodalId, i); // definit le num du vertex
      ofs << coor[0] << " " << coor[1] << " " << coor[2] << " 0\n";
      i++;
    }

    VIter_delete(vIter); // destructeur de l'iterateur
  }
  else
    cout << "/nError : no vertices !!!/n";


// Write Triangles
#ifndef PARALLEL
  cout << "Number of given Triangles\t" << nbTriangles << "\n";
#endif

  if (nbTriangles > 0 )
  {
    ofs << "\n\nTriangles\n";
    ofs << nbTriangles << endl;

    while(gface=GFIter_next(gfIter)) // boucle sur les model triangles
    {
      FIter fIter = M_classifiedFaceIter(theMesh,(pGEntity)gface,0);
      pPList listVertex;
      while(triangle=FIter_next(fIter)) // boucle sur les tri du model tri
      {
        listVertex = F_vertices(triangle,1);
	for (int i=0; i<3; ++i)
	{
	  pEntity entity = (pEntity)PList_item(listVertex,i);
//	  ofs << EN_id(entity) << " "; // EN_id ne prend que des pEntity
          int numNode;
          EN_getDataInt(entity, nodalId, &numNode);
          ofs << numNode << " "; 
	}
        ofs << GEN_tag((pGEntity)gface) << "\n";
      }
      FIter_delete(fIter); // destructeur de l'iterateur

    }
    GFIter_delete(gfIter); // destructeur de l'iterateur

  }
  else {
//    cout << "\nError : no triangles !!!\n";
    ofs << "\n\nTriangles\n";
    ofs << 0 << endl;
  }


// Write Tetrahedra
#ifndef PARALLEL
  cout << "Number of given Tetrahedra\t" << nbTetras << "\n";
#endif

  if (nbTetras > 0 )
  {
    ofs << "\nTetrahedra\n";
    ofs << nbTetras << endl;
    
    RIter rIter = M_regionIter(theMesh);
    pPList listVertex;

    while(tetra=RIter_next(rIter)) // boucle sur les tetras
    {
      listVertex = R_vertices(tetra,1);
//    Attention preciser avant le type de la sortie (en anglais CAST)
//    on ne peut le faire que sur des pointeurs
      for (int i=0; i<4; ++i)
      {
        pEntity entity = (pEntity)PList_item(listVertex,i);
//        ofs << EN_id(entity) << " "; // EN_id ne prend que des pEntity
	int numNode;
	EN_getDataInt(entity, nodalId, &numNode);
	ofs << numNode << " "; 
      }
      ofs << " 0\n";
    }

    RIter_delete(rIter); // destructeur de l'iterateur
  }
  else
    cout << "/nError : no tetrahedra !!!/n";
  


// Write Edges
#ifndef PARALLEL
  cout << "Number of given Edges\t\t" << nbEdges << "\n";
#endif
  
  if ( nbEdges > 0 )
  {
    ofs << "\nEdges\n";
    ofs << nbEdges << endl;
    
    while(gedge=GEIter_next(geIter)) // boucle sur les model edges
    {
      EIter eIter = M_classifiedEdgeIter(theMesh,(pGEntity)gedge,0); 
      while(edge=EIter_next(eIter)) // boucle sur les edges du model edge
      {
	pVertex is1 = E_vertex(edge,0);
	pVertex is2 = E_vertex(edge,1);
//	ofs << EN_id((pEntity)is1) << " " << EN_id((pEntity)is2) << " ";
        int numNode1, numNode2;
        EN_getDataInt((pEntity)is1, nodalId, &numNode1);
        EN_getDataInt((pEntity)is2, nodalId, &numNode2);
        ofs << numNode1 << " " << numNode2 << " "; 

        ofs << GEN_tag((pGEntity)gedge) << "\n";
      }
      EIter_delete(eIter); // destructeur de l'iterateur

    }

    GEIter_delete(geIter); // destructeur de l'iterateur

  }
  else {
//    cout << "Error : no edges !!!";
    ofs << "\nEdges\n";
    ofs << 0 << endl;
  }

// Write Ridges
//  cout << "\nWrite Ridges\n";
  ofs << "\nRidges\n";
  ofs << nbEdges << endl;
  for (int i=0; i<nbEdges; ++i)
  {
    ofs << i+1 << endl;
  }


// Write Corners
  ofs << "\nCorners\n";
  int nbCorners=0;
  VIter vIter1 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter1))       // boucle sur les vertex
  {
    // si Type=0 => c'est un corner car entity geom est un vertex
    if ( !V_whatInType(vertex) ) // => si corner
      nbCorners++;
  }
  VIter_reset(vIter1);                 // met a zero l'iterateur
  ofs << nbCorners << endl;

#ifndef PARALLEL
  cout << "Number of given Corners\t\t" << nbCorners << "\n";
#endif

// Bcle sur les sommets et prise en compte de ceux aillant un tag dans le modele
//  VIter vIter1 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter1))       // boucle sur les vertex
  {
    // si Type=0 => c'est un corner car entity geom est un vertex
    if ( !V_whatInType(vertex) ) // => si corner
    {
      int numNode;
      EN_getDataInt((pEntity)vertex, nodalId, &numNode);
      ofs << numNode << endl;
    }
  }
  VIter_delete(vIter1);                 // efface l'iterateur

/* NE MARCHE PAS CAR AOMD RAJOUTE DES CORNERS N'APPARTENANT PAS AU MODELE
   AFIN DE MIEUX DEFINIR LES COURBE
  int nbCorners = GM_numVertices(model);
  pGVertex corner;  
  GVIter gvIter = GM_vertexIter(model);
  while(corner=GVIter_next(gvIter)) // boucle sur les model vertices
  {
    vertex = M_classifiedVertex(theMesh,corner);
//    ofs << EN_id((pEntity)vertex) << endl;
    int numNode;
    EN_getDataInt((pEntity)vertex, nodalId, &numNode);
    ofs << numNode << endl; 

  }
  GVIter_delete(gvIter);

FAUX AUSSI
  pGVertex gvertex;
 int nbCorners = M_numClassifiedVertices(theMesh,(pGEntity)gvertex);
*/


//--- efface toutes nodalId  
  VIter vIter2 = M_vertexIter(theMesh);  // iterateur sur les vertex
  while(vertex=VIter_next(vIter2))       // boucle sur les vertex
  {
    EN_deleteData((pEntity)vertex, nodalId);
  }
  VIter_delete(vIter2);                 // efface l'iterateur
  
  MD_deleteMeshDataId(nodalId);
//--- fin efface
  
  if (P_pid()==0) cout << endl;
  ofs << "\nEnd\n";
  ofs.close();

}


