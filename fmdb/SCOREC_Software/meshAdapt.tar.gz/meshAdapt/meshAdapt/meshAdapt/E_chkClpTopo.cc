/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Optimization
  Author(s) : Pascal J. Frey
  Creation  : Oct 95
  Modifi.   : 
  Function  : Check if two vertices can be collapsed. 
-------------------------------------------------------------------------*/
#include "FMDB.h"
#include "fromMeshTools.h"

int E_chkClpTopo(pVertex vdel, pEdge edge) {
  pVertex v[2], vertd, vertr;
  int i;
  
  if (!EN_okTo(COLAPS,edge))
    return 0;

  v[0] = E_vertex(edge,0);
  v[1] = E_vertex(edge,1);

  for(i=0; i<2; i++) {
    vertd = v[i];
    vertr = v[1-i];
    if(vdel && (vdel!=vertd))
      continue;

   /* first see if collapsing is topologically possible */
    if(!E_chkColaps(&vertd,&vertr,edge))
      continue;

    /* now if the ends were swapped and vdel is fixed kick out */
    if(vdel && (vdel!=vertd))
      continue;

    if (!EN_okTo(COLAPS,vertd))
      continue;

    /* check faces after collapsing */
    if(E_chkColapsFcs(vertd,vertr,edge))
      return 1;
  }

  return 0;
}
 
