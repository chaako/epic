#ifndef H_SizeTypes
#define H_SizeTypes

typedef double dArray[3];

typedef class SFieldBase * pSField;
typedef class MeshSize * pMSize;
typedef pMSize (*sizeFunc)(dArray);

typedef class MeanRatio * pShapeBase;

typedef class locMeshMod * pMeshMod;
typedef class edgeSplitMod * pEsplitMod;
typedef class edgeCollapsMod * pEclpsMod;
typedef class edgeSwapMod * pEswapMod;
typedef class EsplitClpsMod * pEsplitClpsMod;

#endif
