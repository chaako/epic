#ifndef H_EDGERESHAPEMOD
#define H_EDGERESHAPEMOD

#include "FMDBInternals.h"
#include "LocMeshMod.h"
#include <map>
using std::map;

#ifdef CURVE

class edgeReShapeMod : public locMeshMod {


 public:
  edgeReShapeMod(const edgeReShapeMod &r) : locMeshMod(r.theMesh, 0, 0, r.results){}
  edgeReShapeMod(pMesh msh, pRegion region, int index, evalResults *rs): locMeshMod(msh, 0, 0, rs),theMesh(msh), theRegion(region), keyIndex(index) {}
  ~edgeReShapeMod() {}
  
  
  /* the common local modification interface */
  virtual int topoCheck() {return 0;}                 // dummy function
  virtual int geomCheck() ;
  virtual int sizeCheck() {return 0;}                 // dummy function
  virtual void getAffectedRgns(pPList *);
  virtual int apply(){return 0;}
  virtual int apply(pPList *);                        // dummy function
  virtual modType type() { return RSHAPE;}
  void setKeyEdge(pEdge edge) {keyEdge = edge;}
  pEdge getKeyEdge() {return keyEdge;}
  void setPoint(double *xyz) {new_xyz[0]=xyz[0]; new_xyz[1]=xyz[1]; new_xyz[2]=xyz[2];}
  void findKeyEdges(pPList *);
  void resetEdge();
  int computeMiddlePtTarget();
 private:
  pRegion theRegion;
  pMesh theMesh;
  pEdge keyEdge;
  int keyIndex;
  map<pEdge, int> keyDirs;
  double old_xyz[3], new_xyz[3];
  pPList newInvalidRegions;
  
};

#endif

#endif /* CURVE */
