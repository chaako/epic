#include "ParamsOnGFace.h"

ParamsOnGFace::ParamsOnGFace(int n, pGFace gf, double *p)
{
  np=1;
  gface=new pGFace[n];
  param=new double[3*n];

  gface[0]=gf;
  param[0]=*p;
  param[1]=*(p+1);
  param[2]=*(p+2);  
}


ParamsOnGFace::~ParamsOnGFace()
{
  delete[] gface;
  delete[] param;
}

/* return 1 if exist */
int ParamsOnGFace::ifGParamExist(pGFace gf)
{
  for( int i=0; i<np; i++ ) 
    if( gface[i]==gf ) return 1;
  return 0;
}


void ParamsOnGFace::append(pGFace gf, double *p)
{
  gface[np]=gf;
  param[np*3]=*p;
  param[np*3+1]=*(p+1);
  param[np*3+2]=*(p+2);
  ++np;
  return;
}

void ParamsOnGFace::appendUnique(pGFace gf, double *p)
{
  if( ifGParamExist(gf) ) return;
  append(gf,p);
  return;
}

/* return 1, if got the paramater; otherwise, 0 */
int ParamsOnGFace::getParam(pGFace gf, double *p) 
{
  for( int i=0; i<np; i++ ) 
    if( gface[i]==gf ) {
      *p=param[i*3];
      *(p+1)=param[i*3+1];
      *(p+2)=param[i*3+2];
      return 1;
    }
  return 0;
}
