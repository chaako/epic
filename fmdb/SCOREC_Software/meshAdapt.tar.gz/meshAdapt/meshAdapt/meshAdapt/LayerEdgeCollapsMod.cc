#include "LayerEdgeCollapsMod.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "fromMeshTools.h"
#include "Macros.h"

#include "mEntity.h"
#include "FMDB_cint.h"

#include <stdio.h>
#include <math.h>

using std::cout;
using std::endl;

int warnCounter = 0;

#ifdef MVTK
#include "mvtk.h"
#endif

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif

/*
  Three functions are provided to check validity and get size/shape information.
  You can call these three function in any order you want
  (1) TopoCheck() - check topological validity
  (2) GeomCheck() - check geometric validity, including similarity and negative volume
                    Since the big overlap in checking volume and claculating shape, here
                    we check shape directly and also collect demanded shape information
  (3) sizeCheck() - check the max/min size measure of new mesh edges after the modification
 
  To perform the modification, call routine apply() or apply(pPList);  

  return 1: TRUE or SUCCESS
         0: FALSE or FAIL due to negative volume
        -1:               due to messing up parametric space

  10/07/99    created   X. Li
  06/29/00    modified  X. Li
  03/05/01    added valid(), worstShape(), maxminEdgeLength & modified evaluate() 
  06/18/01    make use of desired size at vertices, and base class MeshModResults, 
              LocMeshMod and MeshMeasure  
  07/15/01    added calculating maximum ratio of edge size increase into checkSize() 
  08/14/01    added the option to check volume conservation      
  09/24/01    deny the edge collapse if (i) it creates an edge spanning more than 
              MAX_PERIODIC_SPAN*period; (ii) the vertex to be removed is at a degenerated
	      location       
  04/02/02    support callback function  
  04/11/02    support 2D evaluation and application 
  05/23/02    added private data "flag" and rules to prevent boundary mesh modifications 
  08/05/02    added option to control area/volume change for two-manifold model (3D only) 
  
*/

/* specific member functions for edge collapse */
void layerEdgeCollapsMod::setCollaps(pEdge e, pVertex d, pVertex r)
{
/*
  vd = V_getOriginatingNode(d);
  vr = V_getOriginatingNode(r);
  edgeDel=0;
  if(EN_levelInBL((pEntity)e)==0)
    edgeDel=e;
  else
    edgeDel=E_exists(vd,vr);
  if(!edgeDel) {
    cout<<"\nError in layerEdgeCollapsMod::setCollaps()"<<endl;
    cout<<"zero level layer edge not found"<<endl;
    exit(0);
  }
  pPList elist = GC_layerAndTransitionEdges(V_growthCurve(vd),
                                                V_growthCurve(vr));
  PList_clear(edges);
  PList_copy(edges,elist);
  PList_delete(elist);
  listSize=PList_size(edges);
  interfaceEdge=(pEdge)PList_item(edges,listSize-1);
  results->reset();
*/
  
  /// Assume for now that e, d and r are on the surface boundary
  edgeDel = e;
  vd = d;
  vr = r;
  BL_getHorizontalEdgesByEdge(edgeDel, edges);
  BL_getGrowthCurveNodes(vd, vd_GC);
  BL_getGrowthCurveNodes(vr, vr_GC);
  listSize = edges.size();
  topVd = vd_GC[vd_GC.size()-1];
  interfaceEdge = edges[listSize-1];
  results->reset();
}

void layerEdgeCollapsMod::setCollapsList(vector<pEdge> &elist, pVertex d, pVertex r)
{
/*
  vd = V_getOriginatingNode(d);
  vr = V_getOriginatingNode(r);
  PList_clear(edges); PList_copy(edges,elist); results->reset();
  if(!edgeDel)
    edgeDel=(pEdge)PList_item(edges,0);
  listSize=PList_size(edges);
  interfaceEdge=(pEdge)PList_item(edges,listSize-1);
*/
  vd = d;
  vr = r;
  edges.clear();
  for (vector<pEdge>::const_iterator eit = elist.begin(); eit != elist.end(); ++eit)
    edges.push_back(*eit);
  if(!edgeDel)
    edgeDel = edges[0];
  listSize = edges.size();
  BL_getGrowthCurveNodes(vd, vd_GC);
  BL_getGrowthCurveNodes(vr, vr_GC);
  topVd = vd_GC[vd_GC.size()-1];
  interfaceEdge = edges[listSize-1];
  results->reset();  
}


int layerEdgeCollapsMod::topoCheck()
{
  int typeD=V_whatInType(vd);

  if( typeD==Gvertex )
    return 0;

#ifdef MA_PARALLEL
  if( EN_onCB((pEntity)topVd) )
    return 0;
#endif

  /// In case of trimmed boundary layers
  if (!(listSize == vd_GC.size() || listSize == vr_GC.size()))
    return 0;
/*
  /// Also in case of trimmed boundary layers
  pFace pFaceQuadFace;
  pRegion pRegionRgn;
  for (int iFace = 0; iFace < E_numFaces(interfaceEdge); ++iFace)
  {
    pFaceQuadFace = E_face(interfaceEdge, iFace);
    if (F_typeInBL(pFaceQuadFace) == fVERTICAL_QUAD)
    {
      pRegionRgn = F_region(pFaceQuadFace, 0);
      if (EN_isBLEntity(pRegionRgn))
        pRegionRgn = F_region(pFaceQuadFace, 1);
      else
        return 0;
      if (pRegionRgn && !EN_isBLEntity(pRegionRgn))
        return 0;
      break;
    }
  }
*/

  /// Can't deal with the case where we have unstructured non-tets on the side of a boundary layer
  pRegion pRegionRgn;
  pPList vregs = V_regions(topVd);
  for (int iRgn = 0; iRgn < PList_size(vregs); ++iRgn)
  {
    pRegionRgn = (pRegion)PList_item(vregs, iRgn);
    if (!EN_isBLEntity(pRegionRgn) && pRegionRgn->getType() != TET)
    {
      PList_delete(vregs);
      return 0;
    }
  }
  PList_delete(vregs);

  vregs = V_regions(E_otherVertex(interfaceEdge,topVd));
  for (int iRgn = 0; iRgn < PList_size(vregs); ++iRgn)
  {
    pRegionRgn = (pRegion)PList_item(vregs, iRgn);
    if (!EN_isBLEntity(pRegionRgn) && pRegionRgn->getType() != TET)
    {
      PList_delete(vregs);
      return 0;
    }
  }
  PList_delete(vregs);


  if( flag )
    {
      // rules to prevent unexpected boundary mesh modification
      int typeR=V_whatInType(vr);
      switch (typeD)
	{
	case Gface: 
	  {
	    pPList eRgns=E_regions(edgeDel);
	    if( PList_size(eRgns)!=0 ) {
	      if( typeR!=Gregion )
		{ PList_delete(eRgns); return 0; }
	    }
	    PList_delete(eRgns);
	    break;
	  }
	case Gedge:
	  {
	    if( typeR==Gvertex || typeR==Gedge )
	      return 0;
	    break;
	  }
	}
    }

   // if(V_totNumLayers(vr)<V_totNumLayers(vd))
   //   return 0;

//   if(V_totNumLayers(vr)!=V_totNumLayers(vd))
  if (vd_GC.size() != vr_GC.size())  
    return 0;

  if(E_whatInType(edgeDel)==Gface) {
    int n1 = 0;
    pGEntity gface = E_whatIn(edgeDel);
    if (GF_region((pGFace)gface,0)) n1++;
    if (GF_region((pGFace)gface,1)) n1++;
    if (n1 == 2) {
//**      cout<<"\nError in layerEdgeCollapsMod::topoCheck()"<<endl;
//**      cout<<"zero level layer edge classified on non-manifold face"<<endl;
//**      exit(0);
    }
  }
//   else {
//     cout<<"\nWarning in layerEdgeCollapsMod::topoCheck()"<<endl;
//     cout<<"zero level layer edge NOT classified on model face\n"<<endl;
//     return 0;
//   }

  pVertex topVD = E_vertex(interfaceEdge,0);
  if(vd!=V_getOriginatingNode(topVD))
    topVD = E_vertex(interfaceEdge,1);

//   // cannot handle transition elements as of now
//   // check if any transition face is connected to vertex "topVD"
//   pPList faces = V_faces(topVD);
//   int numFaces = PList_size(faces);
//   for(int iFace=0; iFace<numFaces; iFace++) {
//     if(F_typeInBL((pFace)PList_item(faces,iFace))==fTRANSITION) {
//       PList_delete(faces);
//       return 0;
//     }
//   }
//   PList_delete(faces);

  pVertex vertr = vr, vertd = vd;
  /* first see if collapsing is topologically possible */
  if(!E_chkColaps(&vertd,&vertr,edgeDel))
    return 0;
  /* now if the ends were swapped and vertd is fixed kick out */
  if(vd!=vertd)
    return 0;
  // should this be done here and should we check for DELETE ??
  if (!EN_okTo(COLAPS,vertd)) 
    return 0;

   if(!vd_GC.size()) {
     pPList vregs = V_regions(vd);
     int numRegs = PList_size(vregs), foundBLReg = 0;
     for(int iReg=0; iReg<numRegs; iReg++) {
       if(R_isBLEntity((pRegion)PList_item(vregs,iReg))) {
         foundBLReg = 1;
         break;
       }
     }
     PList_size(vregs);
     if(foundBLReg) {
#ifdef DEBUG
       if(warnCounter<1) {
         cout<<" WARNING : currently zero level vertex (to be deleted) at BL interface with BL regions cannot be collapsed\n"<<endl;
         warnCounter++;
       }
#endif
       return 0;
     }
   }

  // return E_chkClpTopo(topVD,interfaceEdge);
  if(edgeDel!=interfaceEdge) {
//    if(EN_levelInBL((pEntity)topVD))
      return E_chkClpTopo(topVD,interfaceEdge);
//    else 
//      return fromMeshTools::E_chkClpTopoReduced(topVD,interfaceEdge);
  }
}


int layerEdgeCollapsMod::geomCheck()
{

/// MAYBE MAKES SENSE TO EXTRACT THE WHOLE NEEDED BL STRUCTURES IN THE CLASS ITSELF, VERY SIMILAR TO CAVITY EXTRACTION

  double mtol = M_getTolerance();

  pVertex vertex;
  pVertex curVD, curVR;
  pEdge curEdge;
  pFace face;
  pRegion region;
  void *temp2, *temp1;
  int type=V_whatInType(vd);
  int ok=0;
 
  // if Vd on Gface/GEdge, more geometric check is required
  if( type!=Gregion && model_type==PARAM ) {

    // check parametric span and degeneracy if on periodic Gface or Gedge
    if( type==Gface ) {
      double fpar[3];
      P_param2(V_point(vd),&fpar[0],&fpar[1],(int*)&fpar[2]);
      if( adaptUtil::ifDegenerated((pGFace)V_whatIn(vd),fpar,M_getTolerance())!=-1 ) {
	//	printf("return value of geomCheck() changed. Please check\n");
	return 0;
      }
      if( !GF_checkPeriodicSpan((pGFace)V_whatIn(vd)) ) {
	//	printf("return value of geomCheck() changed. Please check\n");
	return 0;
      }
    } else 
      if( !GE_checkPeriodicSpan((pGEdge)V_whatIn(vd)) ) {
	//	printf("return value of geomCheck() changed. Please check\n");
	return 0; 
      }

    // check geometric similarity
    pPList vfaces=V_bdryFaces(vd);
    pPList F_verts=PList_new();
    pPList tmplist;
    pGFace gface;
    
    temp1=0;
    while( face=(pFace)PList_next(vfaces, &temp1) ) {
      if(F_typeInBL(face)!=fLAYER)
	continue;
      if( F_inClosure(face,(pEntity)edgeDel) ) 
	continue;
      gface=(pGFace)F_whatIn(face);
      
      tmplist=adaptUtil::F_verticesOutofMesh(face);
      temp2=0; 
      while( vertex=(pVertex)PList_next(tmplist,&temp2) ) 
	if( vertex==vd )
	  PList_append(F_verts,(pEntity)vr);
	else
	  PList_append(F_verts,(pEntity)vertex);
      if( adaptUtil::F_checkGeoSim(&F_verts,gface)!=1 ) 
	{ ++ok; break; }
      PList_delete(tmplist);
      PList_clear(F_verts);
    }
    PList_delete(vfaces);
    PList_delete(F_verts);

    if( ok ) { 
      //      printf("rturn value of geomCheck() changed. Please check\n");
      return 0;
    }
  }

  pVertex topVD = E_vertex(interfaceEdge,0);
  if(vd!=V_getOriginatingNode(topVD))
    topVD = E_vertex(interfaceEdge,1);

  // min, intermediate and max levels for the cavity
  // (intermediate is max. level of nodes of the edge and could be max. (and min. too - trivial case) for the cavity)
  int totNumLayers, levels[3];

  totNumLayers = vd_GC.size()-1;
  // initialize all levels to tot. number of layers on vd
  for(int iLevel=0; iLevel<3; iLevel++)
    levels[iLevel] = totNumLayers;

  int higherToLower = 1;
  totNumLayers = vr_GC.size()-1;
  if(levels[1]<=totNumLayers) {
    higherToLower = 0;
    levels[1] = totNumLayers;
  }

  if(levels[1]+1!=listSize) {
    cout<<"\nError in layerEdgeCollapsMod::geomCheck()"<<endl;
    cout<<"intermediate level ["<<levels[1]<<"] is not compatible with listSize ["<<listSize<<"]"<<endl;
    exit(0);
  }

  pEdge lyrEdg;
  vector<pEdge> vLyrEdgs;
  V_layerEdges(vd, vLyrEdgs);
  int numLyrEdgs = vLyrEdgs.size();
  for(int iLyrEdg=0; iLyrEdg<numLyrEdgs; iLyrEdg++) {
    lyrEdg = vLyrEdgs[iLyrEdg];
    vector<pVertex> otherVtxStack;

    /// This is somewhat expensive, look at other alternatives.
    BL_getGrowthCurveNodes(E_otherVertex(lyrEdg,vd), otherVtxStack);

    totNumLayers = otherVtxStack.size()-1;//V_totNumLayers(E_otherVertex(lyrEdg,vd));
    if(levels[0]>totNumLayers)
      levels[0] = totNumLayers;
    if(levels[2]<totNumLayers)
      levels[2] = totNumLayers;
  }

//  pPList nodes = V_growthCurve(vd)->getNodesOnGC();
  int numNodesOnGC = vd_GC.size(); //PList_size(nodes);

//   // cannot handle transition elements as of now
//   // check if any transition face is connected to vertex "topVD"
//   pPList faces = V_faces(topVD);
//   int numFaces = PList_size(faces);
//   for(int iFace=0; iFace<numFaces; iFace++) {
//     if(F_typeInBL((pFace)PList_item(faces,iFace))==fTRANSITION) {
//       cout<<"\nError in layerEdgeCollapsMod::geomCheck()"<<endl;
//       cout<<"transition elements NOT supported [iFace="<<iFace<<"]"<<endl;
//       exit(0);
//     }
//   }
//   PList_delete(faces);

  // calculate the volume of original BL elements (including transition) w.r.t. collapse of "edgeDel"
  // and also the volume of original polyhedron at interface
  // w.r.t. collapse of interface edge (top most edge) that includes non-BL elements
  // also compute the volume of post edge collapse configuration (use this in validity check)
  pVertex vertexD, vertexR;
  pEdge cedge;
  double origVol[2]= {0.,0.}, newVol[2]={0.,0.};
  // in case numNodesOnGC is 1
  vertexD = vd; curVD = vd; vertexR = vr; curVR = vr; cedge = edgeDel; curEdge = edgeDel;
  for(int iList=1; iList<levels[0]+1; iList++) {

    if(iList<numNodesOnGC) {
      vertexD = vd_GC[iList-1];//(pVertex)PList_item(nodes,iList-1);
      curVD = vd_GC[iList];//(pVertex)PList_item(nodes,iList);

      cedge = edges[iList-1];//(pEdge)PList_item(edges,iList-1);
      vertexR = E_otherVertex(cedge,vertexD);
    }

    if(iList<listSize) {
      curEdge = edges[iList];//(pEdge)PList_item(edges,iList);
      curVR = E_otherVertex(curEdge,curVD);
    }

    vector<pRegion> BLRegs;
    V_BLRegions(curVD, iList, BLRegs);

    dArray x_y_z[6];
    pPList rverts;
    int numRVerts;
    pVertex vert;
    for (int iReg = 0; iReg < BLRegs.size(); ++iReg)
    {
      region = BLRegs[iReg];
      if(checkVolume)
	origVol[0] += R_Volume2(region);

      if(R_inClosure(region,(pEntity)curEdge))
	continue;

      rverts = R_vertices(region,1);
      numRVerts = PList_size(rverts);
      for(int iRVert=0; iRVert<numRVerts; iRVert++) {
	vert = (pVertex)PList_item(rverts,iRVert);

	if(vert==vertexD)
	  V_coord(vertexR,x_y_z[iRVert]);
	else if(vert==curVD)
	  V_coord(curVR,x_y_z[iRVert]);
	else
	  V_coord(vert,x_y_z[iRVert]);
      }
      PList_delete(rverts);

      double postVol = XYZ_volume2(x_y_z, region->getType());

      if(postVol<mtol) {
	return 0;
      }

      newVol[0] += postVol;
    }
  }

  if( checkVolume ) {
//     double x_y_z[4][3];
//     // fit three tets in a prism
//     // (diagonal edges of a prism are : V0-V4, V1-V5 and V5-V0)
//     int tetVerts[3][4] = {0,1,2,5, 0,1,5,4, 0,4,5,3};
//     pVertex vert, otherVd, otherVr, vts[6];
//     pPList rVerts;
//     pPList vrlist1 = V_regions(vd);
//     otherVd = E_otherVertex(V_growthEdge(vd,1),vd);
//     otherVr = E_otherVertex(V_growthEdge(vr,1),vr);
//     temp1=0;
//     while( region = (pRegion)PList_next(vrlist1, &temp1) ) {
//       origVol[0] += R_volume2(region);
      
//       if(!R_inClosure(region,(pEntity)edgeDel)) {
// 	rVerts = R_vertices(region,1);
	
// 	for(int iVert=0; iVert=6; iVert++) {
// 	  vert = (pVertex)PList_item(rVerts,iVert);	  
// 	  if(vert==vd)
// 	    vts[iVert] = vr;
// 	  else if(vert==otherVd)
// 	    vts[iVert] = otherVr;
// 	  else
// 	    vts[iVert] = (pVertex)PList_item(rVerts,iVert);
// 	}	
// 	PList_delete(rVerts);

// 	// three tets in a prism
// 	// compute volume of prism by adding volume of three tets
// 	for(int iTet=0; iTet<3; iTet++) {
// 	  for(int iVert=0; iVert<4; iVert++) {
// 	    V_coord(vts[tetVerts[iTet][iVert]],x_y_z[iVert]);
// 	  }
// 	  newVol[0] += XYZ_volume(x_y_z);
// 	} // loop over three tets fitted into prism
//       } // if region is not being deleted (doesn't contain edgeDel)
//     } // loop over regions connected to vd
//     PList_delete (vrlist1);
    
    if( ABS(origVol[0]-newVol[0])/origVol[0] > dV_limit ) {
//      cout<<"\n\n check this volume change due to \"0-level layer edge\" collapse\n\n"<<endl;
	return 0;
    }

    pPList vrlist2 = V_regions (topVD);
    temp1=0;
    while( region = (pRegion)PList_next(vrlist2, &temp1) ) {
      if(!R_isBLEntity(region)) 
	origVol[1] += R_Volume2(region);
    }
    PList_delete (vrlist2);
  }

  double shape_1, worstShapeLyrFcs=1.0e20, worstShape=1.0e20;

  // check that all elements in polyhedron/polygon have positive volume/area
  // Note that:
  // Since worst element shape usually needs to be calculated, which is 
  // somewhat overlapped with volume/area check, we calculate shape directly 

  // determine the validity of layer, and transition, faces 
  // associated with each layer edge collapse (in the stack)
  // i.e., by using shpMeasure->XYZ_shape() for triangles
  pPList fverts;
  vector<pFace> vLyrFcs;
  int i, foundCurEdge = 0;
  double xyz[3][3], v01[3], v02[3], nor[3];
  pMSize pmt[3];

  // loop over all the layer edges (i.e., whole stack)
  // ---> OR may be we need to check this for "edge" and interface edge
  // ---> OR just "edge" as interface edge would be checked later anyways

  // first loop
  for(int iList=0; iList<levels[0]+1; iList++) {
    curEdge = edges[iList];

    curVD = vd_GC[iList];
    curVR = E_otherVertex(curEdge,curVD);

    V_layerAndTransitionFaces(curVD, vLyrFcs);
//    V_layerFaces(curVD, vLyrFcs);
    temp1 = 0; foundCurEdge = 0;
    for (int iFace = 0; iFace < vLyrFcs.size(); iFace++)
    {
      face = vLyrFcs[iFace];
      if (F_inClosure(face,(pEntity)curEdge)) {
	foundCurEdge = 1;
	continue;
      }
      fverts = F_vertices(face,1);

      // compute the original normal
      temp2 = 0; i = 0;
      while (vertex = (pVertex)PList_next(fverts, &temp2))
	V_coord(vertex,xyz[i++]);
      diffVt(xyz[1],xyz[0],v01);
      diffVt(xyz[2],xyz[0],v02);
      crossProd(v01,v02,nor);

      temp2 = 0; i = 0;
      while (vertex = (pVertex)PList_next(fverts, &temp2)) {
	if (vertex == curVD) {
	  pmt[i]=pSizeField->getSize(curVR);
	  V_coord(curVR,xyz[i++]);
	}
	else {
	  pmt[i]=pSizeField->getSize(vertex);
	  V_coord(vertex,xyz[i++]);
	}
      } // loop over vertices of particular layer face
      PList_delete(fverts);

      // check validity and calculate shape
      if(!shpMeasure->XYZ_shape(xyz, pmt, nor, &shape_1)) {
	return 0;
      }

      // collect layer faces shape information of resulting local mesh
      if(shape_1 < worstShapeLyrFcs)
	worstShapeLyrFcs=shape_1;

    } // loop over layer faces connected to curVD

    if(!foundCurEdge) {
      cout<<"\nError in layerEdgeCollapsMod::geomCheck()"<<endl;
      cout<<"could NOT find current edge ["<<iList<<"] in 1st loop"<<endl;
      exit(0);
    }
  } /// loop over list "edges" ends

  int vdListSize = vd_GC.size();
  for(int iList=levels[0]+1; iList<levels[1]+1; iList++) 
  {
    curEdge = edges[iList];

    // if iList exceeds vdListSize curVD remains the
    // top most node for rest of the loop
    if(iList<vdListSize)
      curVD = vd_GC[iList];//(pVertex)PList_item(nodes,iList);
    curVR = E_otherVertex(curEdge,curVD);

    // list vLyrFcs contains layer and transition faces at level "iList"
    V_layerAndTransitionFaces(curVD,iList,vLyrFcs);

    temp1 = 0; foundCurEdge = 0;
    for (int iFace = 0; iFace < vLyrFcs.size(); iFace++)
    {
      face = vLyrFcs[iFace];
      if (F_inClosure(face,(pEntity)curEdge)) {
        foundCurEdge = 1;
        continue;
      }
      fverts = F_vertices(face,1);

      // compute the original normal
      temp2 = 0; i = 0;
      while (vertex = (pVertex)PList_next(fverts, &temp2))
        V_coord(vertex,xyz[i++]);
      diffVt(xyz[1],xyz[0],v01);
      diffVt(xyz[2],xyz[0],v02);
      crossProd(v01,v02,nor);

      temp2 = 0; i = 0;
      while (vertex = (pVertex)PList_next(fverts, &temp2)) {
        if (vertex == curVD) {
          pmt[i]=pSizeField->getSize(curVR);
          V_coord(curVR,xyz[i++]);
        }
        else {
          pmt[i]=pSizeField->getSize(vertex);
          V_coord(vertex,xyz[i++]);
        }
      } // loop over vertices of particular layer face
      PList_delete(fverts);

      // check validity and calculate shape
      if(!shpMeasure->XYZ_shape(xyz, pmt, nor, &shape_1)) {
        return 0;
      }

      // collect layer faces shape information of resulting local mesh
      if(shape_1 < worstShapeLyrFcs)
        worstShapeLyrFcs=shape_1;
    } // loop over layer faces connected to curVD

    if(!foundCurEdge) {
      cout<<"\nError in layerEdgeCollapsMod::geomCheck()"<<endl;
      cout<<"could NOT find current edge ["<<iList<<"] in 2nd loop"<<endl;
      exit(0);
    }
  } // loop over list "edges" ends

  // curVD and curVR remains the same (as the one from the last loop) over this loop
  for(int iList=levels[1]+1; iList<levels[2]+1; iList++) {

    // list vLyrFcs contains layer and transition faces at level "iList"
    V_layerAndTransitionFaces(curVD,iList,vLyrFcs);

    temp1 = 0;
    for (int iFace = 0; iFace < vLyrFcs.size(); iFace++)
    {
      face = vLyrFcs[iFace];
      if(F_inClosure(face,(pEntity)interfaceEdge))
        continue;

      fverts = F_vertices(face,1);

      // compute the original normal
      temp2 = 0; i = 0;
      while (vertex = (pVertex)PList_next(fverts, &temp2))
        V_coord(vertex,xyz[i++]);
      diffVt(xyz[1],xyz[0],v01);
      diffVt(xyz[2],xyz[0],v02);
      crossProd(v01,v02,nor);

      temp2 = 0; i = 0;
      while (vertex = (pVertex)PList_next(fverts, &temp2)) {
        if (vertex == curVD) {
          pmt[i]=pSizeField->getSize(curVR);
          V_coord(curVR,xyz[i++]);
        }
        else {
          pmt[i]=pSizeField->getSize(vertex);
          V_coord(vertex,xyz[i++]);
        }
      } // loop over vertices of particular layer face
      PList_delete(fverts);

      // check validity and calculate shape
      if(!shpMeasure->XYZ_shape(xyz, pmt, nor, &shape_1)) {
        return 0;
      }
      // collect layer faces shape information of resulting local mesh
      if(shape_1 < worstShapeLyrFcs)
        worstShapeLyrFcs=shape_1;

    } // loop over layer faces connected to curVD
  } // loop over list "edges" ends

  // consider interface region (need to work with interior volume mesh)
  pVertex topVR = E_otherVertex(interfaceEdge,topVD);
  pPList vregs, rverts;
  double XYZ1[4][3];
  pMSize PMT[4];
  newVol[1]=0.0;

  // estimate the worst shape of tets in the polyhedron at interface 
  // after collapse of layer edge at interface (i.e., top most edge)
  // also compute the volume of new polyhedron at interface (if requested)
  // w.r.t. collapse of interface edge (top most edge) non-BL elements included
  vregs = V_regions(topVD);
  temp1 = 0;
  while ( region = (pRegion)PList_next(vregs,&temp1) ) {
    if(!R_isBLEntity(region)) {
      if (R_inClosure(region,(pEntity)interfaceEdge)) 
	continue;
      rverts = R_vertices(region,1);
      
      temp2 = 0; i = 0;
      while (vertex = (pVertex)PList_next(rverts, &temp2)) {
	if (vertex == topVD) {
	  PMT[i]=pSizeField->getSize(topVR);
	  V_coord(topVR,XYZ1[i++]);
	}
	else {
	  PMT[i]=pSizeField->getSize(vertex);
	  V_coord(vertex,XYZ1[i++]);
	}
      }
      PList_delete(rverts);
      
      // check validity and calculate shape for acceptability
      if ( !shpMeasure->XYZ_shape(XYZ1, PMT, &shape_1) ) {
	PList_delete(vregs); 
	return 0;
      }
      
      // compute the sum volume/area of the new regions
      if(checkVolume) 
	newVol[1] += XYZ_volume (XYZ1);
      
      // collect shape information of resulting local mesh
      if(shape_1 < worstShape)
	worstShape=shape_1;   
    } // check for non-BL elements
  } // loop over regions connected to topVD
  PList_delete(vregs);
    
  // check volume change w.r.t. collapse of "edgeDel" and "interfaceEdge"
  if( checkVolume) {
    if( ABS(origVol[1]-newVol[1])/origVol[1] > dV_limit ) {
//      cout<<"\n\n check this volume change due to \"interface edge\" collapse\n\n"<<endl;
      return 0;
    }
  }

  if(worstShape*worstShape > worstShapeLyrFcs*worstShapeLyrFcs*worstShapeLyrFcs )
    worstShape = worstShapeLyrFcs*sqrt(worstShapeLyrFcs);

  results->setWorstShape(worstShape);

  if(worstShape<QUALITYFRACTION*QUALITYTHRESHOLD)
    return 0;

  return 1;
}


/*
  calculate max/min size, and max ratio after the modification is applied
*/ 
int layerEdgeCollapsMod::sizeCheck()
{
  pFace face;
  pEdge edge;
  int i,j;
  int mergeEdge, numEdges, numFaces;
  double tmp, size0, ratioSq;
  pMSize desireT0,desireT1 ;

  double maxSq=0.0;
  double minSq=1.0e20;
  double max_ratioSq;    // the ratio square of edge increase at max size
  double maxRatio_lenSq; // the edge size at max ratio 
  double maxRatioSq=0;    // the max ratio square of edge length increase 

  if( !pSizeField ){
    printf("WARNING: NULL metric field !!!");
    return 1;
  } 

  pVertex topVD = E_vertex(interfaceEdge,0);
  if(vd!=V_getOriginatingNode(topVD))
    topVD = E_vertex(interfaceEdge,1);
  pVertex topVR = E_otherVertex(interfaceEdge,topVD);
  
//   // cannot handle transition elements as of now
//   // check if any transition face is connected to vertex "topVD"
//   pPList faces = V_faces(topVD);
//   numFaces = PList_size(faces);
//   for(int iFace=0; iFace<numFaces; iFace++) {
//     if(F_typeInBL((pFace)PList_item(faces,iFace))==fTRANSITION) {
//       cout<<"\nError in layerEdgeCollapsMod::sizeCheck()"<<endl;
//       cout<<"transition elements NOT supported [iFace="<<iFace<<"]"<<endl;
//       exit(0);
//     }
//   }
//   PList_delete(faces);

  pVertex vertex;
  double coords[3], xyzR[3];
  pVertex curVD, curVR; // current vd and vr (at that level)
  pEdge curEdge;
  vector<pEdge> vLyrEdgs;
//  pPList nodes = V_growthCurve(vd)->getNodesOnGC();

  // loop over all the layer edges (i.e., whole stack)
  for(int iList=0; iList<listSize; iList++) {
    curEdge = edges[iList];//(pEdge)PList_item(edges,iList);
    if(E_typeInBL(curEdge)!=eLAYER)
      break;

    curVD = vd_GC[iList];//(pVertex)PList_item(nodes,iList);
    curVR = E_otherVertex(curEdge,curVD);
    
    desireT0 = pSizeField->getSize(curVR);
    V_coord(curVR,xyzR);

    V_layerEdges(curVD, vLyrEdgs);
    numEdges = vLyrEdgs.size();    
    for(int iEdge=0; iEdge<numEdges; iEdge++) {
      mergeEdge = 0;
      edge = vLyrEdgs[iEdge];//(pEdge)PList_item(vLyrEdgs,iEdge);
      if(edge==curEdge)
	continue;
      if(E_commonFace(curEdge,edge)) {
	mergeEdge = 1;
	continue;
      }

      vertex = E_vertex(edge,0);
      if(vertex==curVD)
	vertex = E_vertex(edge,1);
      V_coord(vertex,coords);
      desireT1 = pSizeField->getSize(vertex);
      tmp = pSizeField->lengthSq(xyzR,coords,desireT0,desireT1);
      size0 = pSizeField->lengthSq(edge);

      ratioSq = tmp/size0;

      if(minSq>tmp) 
	{ minSq=tmp; }
      if(maxSq<tmp)
	{ maxSq=tmp; max_ratioSq=ratioSq; }
      if(ratioSq>maxRatioSq)
	{ maxRatioSq=ratioSq; maxRatio_lenSq=tmp; }
    } // loop over layer edges around "curVD" ends
  } // loop over list "edges" ends
  
  V_coord(topVR,xyzR);

  // get info at the vertex to be retained
  desireT0=pSizeField->getSize(topVR);

  // estimate the size after collapse for interior edges
  numEdges = V_numEdges(topVD);
  for(i=0; i<numEdges; i++) {
    edge=V_edge(topVD,i);
    if(!E_typeInBL(edge)) {
      mergeEdge=0;
      numFaces = E_numFaces(interfaceEdge);
      for(j=0;j<numFaces; j++) {
	face=E_face(interfaceEdge,j);
	if(!F_typeInBL(face)) {
	  if( F_inClosure(face,(pEntity)edge) ) 
	    { mergeEdge=1; break;}
	}
      }
      if( mergeEdge )
	continue;

      vertex=E_vertex(edge,0);
      if(vertex == topVD) 
	vertex=E_vertex(edge,1);
    
      // calculate size of current edge after collapse virtually
      V_coord(vertex,coords);
    
      desireT1=pSizeField->getSize(vertex);
      tmp=pSizeField->lengthSq(xyzR,coords,desireT0,desireT1);

      // calculate size of current edge before collapse
      size0=pSizeField->lengthSq(edge);
      ratioSq=tmp/size0;
      
      // calculate max/min value
      if( minSq>tmp )
	{ minSq=tmp; }
      if( maxSq<tmp ) 
	{ maxSq=tmp; max_ratioSq=ratioSq; }
      if( ratioSq>maxRatioSq ) 
	{ maxRatioSq=ratioSq; maxRatio_lenSq=tmp; }
    }
  }
  
  results->setMaxSize(maxSq);
  results->setMinSize(minSq);
  results->setMaxRatioSquare(maxRatioSq);
  results->setSizeAtMaxRatio(maxRatio_lenSq);
  results->setRatioSquareAtMaxSize(max_ratioSq);

  return 1;
}

/* get the mesh regions to be affected by this collapse operation */
void layerEdgeCollapsMod::getAffectedRgns(pPList *l)
{
  *l=V_regions(vd);

  pVertex vtx;
  pPList vregs;
//  pPList nodes = V_growthCurve(vd)->getNodesOnGC();
  int numNodes = vd_GC.size();//PList_size(nodes);
  for(int iNode=0; iNode<numNodes; iNode++) {
    vtx = vd_GC[iNode];//(pVertex)PList_item(nodes,iNode);
    vregs = V_regions(vtx);
    PList_appPListUnique(*l,vregs);
    PList_delete(vregs);
  }
}

/* perform the collapse and the motion */
int layerEdgeCollapsMod::apply()
{
  pPList newRegs;
  apply( &newRegs );
  PList_delete(newRegs);
  return 1;
}


/*
  the same as above, but return the new regions of the polyhedron
*/
int layerEdgeCollapsMod::apply(pPList *newRegs)
{

  if( pSizeField ) {
//    pPList nodes = V_growthCurve(vd)->getNodesOnGC();
    int numNodes = vd_GC.size();//PList_size(nodes);
    for(int iNode=0; iNode<numNodes; iNode++) {
      pSizeField->deleteSize(vd_GC[iNode]);//((pEntity)PList_item(nodes,iNode));
    }
  }

  fromMeshTools::Layer_E_colaps(mesh,edges,vd,vr,function_CB,userData_CB,newRegs);

#ifdef DEBUG
  pRegion region;
  void *iter;
  iter=0;
  while( region=(pRegion)PList_next(*newRegs,&iter) ) {
    if( R_Volume2(region) < 2.e-16 )
      printf("Error: 2. region %d: R_volume2=%.12e [rTopoType=%d] (layerEdgeCollapsMod::apply())\n",
	     EN_id((pEntity)region),R_Volume2(region),region->getType());
  }
#endif
  return 1;
}


/*
  return 1. parametric span is acceptable
         0  span too much
*/
int layerEdgeCollapsMod::GF_checkPeriodicSpan(pGFace gf)
{

  // see if periodicity exists
  if( !GF_periodic(gf,0) && !GF_periodic(gf,1) )
    return 1;

  pEdge edge;
  pVertex otherVt;
  double parVr[3], par[3];
  double period, low, high, span;
  double tol=M_getTolerance();
  int i,j;

  adaptUtil::V_reparamOnGFace(vr,gf,parVr);

  for( i=0; i<V_numEdges(vd); i++ ) {
    edge=V_edge(vd,i);
    if( E_whatInType(edge)!=GEN_type(E_whatIn(edge)) )
      printf("something wrong\n");
    E_whatInType(edge);
    if( E_whatIn(edge) != (pGEntity)gf ) continue;
    if( edge==edgeDel ) continue;

    otherVt=E_otherVertex(edge,vd);
    adaptUtil::V_reparamOnGFace(otherVt,gf,par);

    for( j=0; j<2; j++ ) {

      if(GF_periodic(gf,j)) {

        if( adaptUtil::ifDegenerated(gf, par, tol) == (j+1)%2 )
          continue;
        if( adaptUtil::ifDegenerated(gf, parVr, tol) == (j+1)%2 )
          continue;

        GF_parRange(gf,j,&low,&high);
        period=high-low;
        span=ABS(parVr[j]-par[j]);
        if( (period*MAX_PERIODIC_SPAN<span) &&
            (period*(1-MAX_PERIODIC_SPAN)>span) )
          return 0;
      }
    }
  }

  return 1;
}


int layerEdgeCollapsMod::GE_checkPeriodicSpan(pGEdge ge)
{
  // see if a periodic model edge
  if( !GE_periodic(ge) )
    return 1;

  pEdge edge;
  pVertex otherVt;
  double par, par1;
  double span, period, low, high;
  int i;

  // check the mesh edge on model edge
  for( i=0; i<V_numEdges(vd); i++ ) {
     edge=V_edge(vd,i);
     if( edge == edgeDel ) continue;
     if( E_whatInType(edge)==Gedge ) break;
  }

  otherVt=E_otherVertex(edge,vd);
  adaptUtil::V_reparamOnGEdge(otherVt,ge,&par);
  adaptUtil::V_reparamOnGEdge(vr,ge,&par1);
  span=ABS( par-par1 );
  GE_parRange(ge,&low,&high);
  period=high-low;
  if( (period*MAX_PERIODIC_SPAN<span) &&
      (period*(1-MAX_PERIODIC_SPAN)>span) )
    return 0;

  // check mesh edges on model faces
  pPList gfs=GE_faces(ge);
  pGFace gf;
  void *iter=0;
  while( gf=(pGFace)PList_next(gfs,&iter) )
    if( ! GF_checkPeriodicSpan(gf) ) {
      PList_delete(gfs);
      return 0;
    }

  PList_delete(gfs);
  return 1;
}

