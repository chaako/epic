#include "EdgeCollapsMod.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "fromMeshTools.h"
#include "Macros.h"
#include "PList.h"
#include "FMDB_cint.h"
#include "BLUtil.h"
#include <stdio.h>
#include <math.h>
#include <iostream>

using std::cout;
using std::endl;


#ifdef MVTK
#include "mvtk.h"
#endif

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif

#ifdef CURVE
#include "curveUtil.h" // May 1, 2010, QLU
using namespace curveUtil;
#endif //CURVE
/*
  Modification of a given vertex motion followed by a given edge collapse
  The local mesh associated with this modification is one/two polyhedron(s)

  Three functions are provided to check validity and get size/shape information.
  You can call these three function in any order you want
  (1) TopoCheck() - check topological validity
  (2) GeomCheck() - check geometric validity, including similarity and negative volume
                    Since the big overlap in checking volume and claculating shape, here
                    we check shape directly and also collect demanded shape information
  (3) sizeCheck() - check the max/min size measure of new mesh edges after the modification
 
  To perform the modification, call routine apply() or apply(pPList);  

  return 1: TRUE or SUCCESS
         0: FALSE or FAIL due to negative volume
        -1:               due to messing up parametric space

  10/07/99    created   X. Li
  06/29/00    modified  X. Li
  03/05/01    added valid(), worstShape(), maxminEdgeLength & modified evaluate() 
  06/18/01    make use of desired size at vertices, and base class MeshModResults, 
              LocMeshMod and MeshMeasure  
  07/15/01    added calculating maximum ratio of edge size increase into checkSize() 
  08/14/01    added the option to check volume conservation      
  09/24/01    deny the edge collapse if (i) it creates an edge spanning more than 
              MAX_PERIODIC_SPAN*period; (ii) the vertex to be removed is at a degenerated
	      location       
  04/02/02    support callback function  
  04/11/02    support 2D evaluation and application 
  05/23/02    added private data "flag" and rules to prevent boundary mesh modifications 
  08/05/02    added option to control area/volume change for two-manifold model (3D only) 
  
*/
int edgeCollapsMod::topoCheck()
{
  int typeD=V_whatInType(vd);

  if( typeD==Gvertex )
    return 0;

#ifdef MA_PARALLEL
  if( EN_onCB((pEntity)vd) )
    return 0;
#endif


  if( flag )
    {
      // rules to prevent unexpected boundary mesh modification
      int typeR=V_whatInType(vr);
      switch (typeD)
	{
	case Gface: 
	  {
	    pPList eRgns=E_regions(edgeDel);
	    if( PList_size(eRgns)!=0 ) {
	      if( typeR!=Gregion )
		{ PList_delete(eRgns); return 0; }
	    }
	    PList_delete(eRgns);
	    break;
	  }
	case Gedge:
	  {
	    if( typeR==Gvertex || typeR==Gedge )
	      return 0;
	    break;
	  }
	}
    }

    /// Can't handle cases involving any topology other than tets
    int iValidRgn = 1;
    pVertex pVertexVtx[3] = {vd, vr, vertMv};
    pRegion pRegionRgn;
    int iNumVtx = 2;
    if (vertMv)
      iNumVtx = 3;
    for (int iVtx = 0; iVtx < iNumVtx; ++iVtx)
    {
      pPList vregs = V_regions(pVertexVtx[iVtx]);
      for (int iRgn = 0; iRgn < PList_size(vregs); ++iRgn)
      {
        pRegionRgn = (pRegion)PList_item(vregs, iRgn);
        if (pRegionRgn->getType() == PYRAMID)
        {
          iValidRgn = 0;
          PList_delete(vregs);
          break;
        }
      }
      if (iValidRgn)
        PList_delete(vregs);
      else
        break;
    }
    if (!iValidRgn)
      return 0;



  return E_chkClpTopo(vd,edgeDel);
}


int edgeCollapsMod::geomCheck()
{
  pVertex vertex;
  void *temp2, *temp1;
  int type=V_whatInType(vd);
  int ok=0;

  /// Check for the collapse which will result in connecting two different BLs. If this happens - do not collapse.
  pEdge pEdgeEdgeChk;
  /// If vertex R (vertex to which the edge is collpsed) is connected to a boundary layer, check for the vertexes of vertex D (the one which is deleted)
  if (EN_isBLEntity(vr))
  {
    for (int iEdge = 0; iEdge < V_numEdges(vd); ++iEdge)
    {
      pEdgeEdgeChk = V_edge(vd, iEdge);
      if (pEdgeEdgeChk == edgeDel)
        continue;

      if (EN_isBLEntity(E_otherVertex(pEdgeEdgeChk, vd)))
        return 0;
    }
  }
 
  // if Vd on Gface/GEdge, more geometric check is required
  if( type!=Gregion && model_type==PARAM ) {

    // check parametric span and degeneracy if on periodic Gface or Gedge
    if( type==Gface ) {
      double fpar[3];
      P_param2(V_point(vd),&fpar[0],&fpar[1],(int*)&fpar[2]);
      if( adaptUtil::ifDegenerated((pGFace)V_whatIn(vd),fpar,M_getTolerance())!=-1 ) {
	//	printf("return value of geomCheck() changed. Please check\n");
	return 0;
      }
      if( !GF_checkPeriodicSpan((pGFace)V_whatIn(vd)) ) {
	//	printf("return value of geomCheck() changed. Please check\n");
	return 0;
      }
    } else 
      if( !GE_checkPeriodicSpan((pGEdge)V_whatIn(vd)) ) {
	//	printf("return value of geomCheck() changed. Please check\n");
	return 0; 
      }

    // check geometric similarity
    pPList vfaces=V_bdryFaces(vd);
    pPList F_verts=PList_new();
    pPList tmplist;
    pFace face;
    pGFace gface;
    
    temp1=0;
    while( face=(pFace)PList_next(vfaces, &temp1) ) {
      if( F_inClosure(face,(pEntity)edgeDel) ) 
	continue;
      gface=(pGFace)F_whatIn(face);
      
      tmplist=adaptUtil::F_verticesOutofMesh(face);
      temp2=0; 
      while( vertex=(pVertex)PList_next(tmplist,&temp2) ) 
	if( vertex==vd )
	  PList_append(F_verts,(pEntity)vr);
	else
	  PList_append(F_verts,(pEntity)vertex);
      PList_delete(tmplist);
      if( adaptUtil::F_checkGeoSim(&F_verts,gface)!=1 ) 
	{ ++ok; break; }
      PList_clear(F_verts);
    }
    PList_delete(vfaces);
    PList_delete(F_verts);
    if( ok ) { 
      //      printf("return value of geomCheck() changed. Please check\n");
      return 0;
    }
  }


  // check that all elements in polyhedron/polygon have positive volume/area
  // Note that:
  // (1) present "E_evalColaps()" can not be used for the modification that
  //     includes the initial vertex motion since the mesh may be invalid
  // (2) Since worst element shape usually needs to be calculated, which is 
  //     somewhat overlapped with volume/area check, we calculate shape directly 
  pPList Vd_regs=V_regions(vd);
  double shape_1, worstShape=1.0e20;
  double xyzR[3];
  int i,j,m=1;

  if( vertMv && vertMv!=vd )
    m=2;      
  V_coord(vr,xyzR);

  if( PList_size(Vd_regs)==0 ) {
    // 2D situation
    pFace face;
    pPList vfcs, fverts;
    double xyz[3][3], v01[3], v02[3], nor[3];
    pMSize pmt[3];


    // estimate the worst shape of triangles in the polygon after collapse
    for(j=0; j<m; j++) {
      vfcs = (j) ? (V_faces(vertMv)) : (V_faces(vd)) ;
      temp1 = 0;
      while (face = (pFace)PList_next(vfcs,&temp1)) {
	if (F_inClosure(face,(pEntity)edgeDel)) 
	  continue;
	fverts = F_vertices(face,1);

	//  if( model_type==NOPARAM ) { 
	  // compute the original normal
	  temp2 = 0; i = 0;
	  while (vertex = (pVertex)PList_next(fverts, &temp2))
	    V_coord(vertex,xyz[i++]);
	  diffVt(xyz[1],xyz[0],v01);
	  diffVt(xyz[2],xyz[0],v02);
	  crossProd(v01,v02,nor);
	//  }

	temp2 = 0; i = 0;
	if(vertMv==vr)
	  while (vertex = (pVertex)PList_next(fverts, &temp2))
	    if(vertex==vd || vertex==vr) {
	      pmt[i]=pSizeField->getSize(vr);
	      xyz[i][0]=target[0]; 
	      xyz[i][1]=target[1];
	      xyz[i++][2]=target[2];
	    }
	    else {
	      pmt[i]=pSizeField->getSize(vertex);
	      V_coord(vertex,xyz[i++]);
	    }
	else
	  while (vertex = (pVertex)PList_next(fverts, &temp2))
	    if (vertex == vd) 
	      {
		pmt[i]=pSizeField->getSize(vr);
		V_coord(vr,xyz[i++]);
	      }
	    else if(vertex==vertMv)
	      { 
		pmt[i]=pSizeField->getSize(vertex);
		xyz[i][0]=target[0]; xyz[i][1]=target[1]; xyz[i++][2]=target[2];
	      }
	    else
	      {
		pmt[i]=pSizeField->getSize(vertex);
		V_coord(vertex,xyz[i++]);
	      }
	
	PList_delete(fverts);

	// calculate shape and check acceptability
	//	if( model_type==NOPARAM )
	  ok=shpMeasure->XYZ_shape(xyz, pmt, nor, &shape_1);
//  	else
//  	  ok=shpMeasure->XYZ_shape(xyz, pmt, 0, &shape_1);
	if ( !ok ) {
	  PList_delete(Vd_regs); 
	  PList_delete(vfcs);
	  return 0;
	}
	
	// collect shape information of resulting local mesh
	if(shape_1 < worstShape)
	  worstShape=shape_1;   
      }
      PList_delete(vfcs);
    }    
  } // end of 2D case

  else {
    // 3D edge collapse
    pRegion region;
    pPList vregs, rverts;
    double xyz[4][3];
    pMSize pmt[4];
    double newVol=0.0, oldVol=0.0;

#ifdef CURVE
    crShpInfo csi;  // May 1, 2010, QLU
    
    // estimate the worst shape of tets in the polyhedron after collapse
    if(quadratic == false) {   // check if curved, May 1, 2010, QLU
      // cout<<"Edge Collapse Mode ==> GeomCheck() ==> quadratic == false"<<endl;
#endif //CURVE
      for(j=0; j<m; j++) {
	// vregs = (j) ? (V_regions(vertMv)) : Vd_regs ;
	if(j) {
	  if(!EN_isBLEntity(vertMv))
	    vregs = V_regions(vertMv);
	  else {
	    if(!V_atBLInterface(vertMv)) {
	      cout<<"\nError in edgeCollapsMod::geomCheck()..."<<endl;
	      cout<<"vertMv is BL entity but not at BL interface"<<endl;
	      exit(0);
	    }
	    
	    vregs = PList_new();
	    
	    vector<pRegion> Vrgns;
	    V_nonBLRegions(vertMv, Vrgns);
	    for (int itReg = 0; itReg < Vrgns.size(); ++itReg)
	      {
		PList_append(vregs, Vrgns[itReg]);
	      }
	    
	    double f_xyz[3][3], v01[3], v02[3], nor[3];;
	    pMSize f_pmt[3];
	    pFace face;
	    vector<pFace> vLyrFaces;
	    V_layerFaces(vertMv, vLyrFaces);
	    pPList fverts;
	    int numFaces = vLyrFaces.size();
	    for(int iFace=0; iFace<numFaces; iFace++) {
	      face = vLyrFaces[iFace];
	      
	      fverts = F_vertices(face,1);
	      
	      // compute the original normal
	      temp1 = 0; i = 0;
	      while (vertex = (pVertex)PList_next(fverts, &temp1))
		V_coord(vertex,f_xyz[i++]);
	      diffVt(f_xyz[1],f_xyz[0],v01);
	      diffVt(f_xyz[2],f_xyz[0],v02);
	      crossProd(v01,v02,nor);
	      
	      temp1 = 0; i = 0;
	      if(vertMv==vr) {
		while (vertex = (pVertex)PList_next(fverts, &temp1)) {
		  if(vertex==vd || vertex==vr) {
		    f_pmt[i]=pSizeField->getSize(vr);
		    f_xyz[i][0]=target[0]; f_xyz[i][1]=target[1]; f_xyz[i++][2]=target[2];
		  }
		  else {
		    f_pmt[i]=pSizeField->getSize(vertex);
		    V_coord(vertex,f_xyz[i++]);
		  }
		}
	      }
	      else {
		while (vertex = (pVertex)PList_next(fverts, &temp1)) {
		  if (vertex == vd) {
		    f_pmt[i]=pSizeField->getSize(vr);
		    V_coord(vr,f_xyz[i++]);
		  }
		  else if(vertex==vertMv) {
		    f_pmt[i]=pSizeField->getSize(vertex);
		    f_xyz[i][0]=target[0]; f_xyz[i][1]=target[1]; f_xyz[i++][2]=target[2];
		  }
		  else {
		    f_pmt[i]=pSizeField->getSize(vertex);
		    V_coord(vertex,f_xyz[i++]);
		  }
		}
	      }
	      PList_delete(fverts);
	      
	      // check validity and calculate shape
	      if(!shpMeasure->XYZ_shape(f_xyz, f_pmt, nor, &shape_1)) {
		PList_delete(Vd_regs);
		if( j==1 ) PList_delete(vregs);
		return 0;
	      }
	    }
	  }
	}
	else
	  vregs = Vd_regs;
	
	temp1 = 0;
	while (region = (pRegion)PList_next(vregs,&temp1)) {
	  if (R_inClosure(region,(pEntity)edgeDel)) continue;
	  rverts = R_vertices(region,1);
	  
	  temp2 = 0; i = 0;
	  if(vertMv==vr)
	    while (vertex = (pVertex)PList_next(rverts, &temp2))
	      if(vertex==vd || vertex==vr)
		{ 
		  pmt[i]=pSizeField->getSize(vr);
		  xyz[i][0]=target[0]; xyz[i][1]=target[1]; xyz[i++][2]=target[2];
		}
	      else
		{
		  pmt[i]=pSizeField->getSize(vertex);
		  V_coord(vertex,xyz[i++]);
		}
	  else
	    while (vertex = (pVertex)PList_next(rverts, &temp2))
	      if (vertex == vd)
		{
		  pmt[i]=pSizeField->getSize(vr);
		  V_coord(vr,xyz[i++]);
		}
	      else if(vertex==vertMv)
		{ 
		  pmt[i]=pSizeField->getSize(vertex);
		  xyz[i][0]=target[0]; xyz[i][1]=target[1]; xyz[i++][2]=target[2];
		}
	      else
		{
		  pmt[i]=pSizeField->getSize(vertex);
		  V_coord(vertex,xyz[i++]);
		}
	  PList_delete(rverts);
	  
	  // calculate shape and check acceptability
	  if ( !shpMeasure->XYZ_shape(xyz, pmt, &shape_1) ) {
	    PList_delete(Vd_regs); 
	    if( j==1 ) PList_delete(vregs);
	    return 0;
	  }
	  
	  // compute the sum volume/area of the new regions
	  if( !j && checkVolume && V_whatInType(vd)!=Gregion ) 
	    newVol += XYZ_volume (xyz);
	  
	  // collect shape information of result local mesh
	  if(shape_1 < worstShape)
	    worstShape=shape_1;   
	}
	if( j==1 ) PList_delete(vregs);
      }
      
      
      // check volume change if case vd is on model edge/face
      if( checkVolume && V_whatInType(vd)!=Gregion ) {
	temp1 = 0;
	while (region = (pRegion)PList_next(Vd_regs,&temp1)) 
	  oldVol += R_volume (region);
	
	if( ABS(oldVol-newVol)/oldVol > dV_limit ) {
	  printf("...Info:  deny an edge collapse due to large volume change");
	  PList_delete(Vd_regs); 
	  return 0;
	}
      }
#ifdef CURVE
    }
    else if (quadratic == true) { // May 1, 2010, QLU
      // cout<<"Edge Collapse Mode ==> GeomCheck() ==> quadratic == true"<<endl;
      double params[2][2];
      double xyz[10][3];
      pEdge edge;
      pGEntity gent;
      pPoint pt;
      int numv_e = V_numEdges(vd);
      V_coord (vr, xyz[0]);
      
      // a.1) compute the parametric value(s) for vr
      if (model_type==PARAM) {
	gent =EN_whatIn (edgeDel);
	int gtype =EN_whatInType (edgeDel);
	
	switch (EN_whatInType (vr)) {
	case Tvertex:
	  // the remaining vertex is on a model vertex
	  switch (gtype) {
	  case Tedge:
	    // collapse along a model edge
	    params[0][0] =GE_vertexReparam((pGEdge)gent, (pGVertex)EN_whatIn(vr));
	    break;
	  case Tface:
	    // collapse within a model face
	    GF_vertexReparam((pGFace)gent, (pGVertex)EN_whatIn(vr), params[0]);
	    break;
	  }
	  break;
	  
	case Tedge:
	  // the remaining vertex is on a model edge
	  switch (gtype) {
	  case Tedge:
	    // collapse along a model edge
	    params[0][0] =P_param1 (V_point(vr));
	    break;
	  case Tface:
	    // collapse within a model face
	    GF_edgeReparam ((pGFace)gent, (pGEdge)EN_whatIn(vr), 
			    P_param1(V_point(vr)), 1, params[0]);
	    break;
	  }
	  break;
	  
	case Tface:
	  // the remaining vertex is on a model face and the collapse
	  // occurs within a model face
	  P_param2 (V_point (vr), &(params[0][0]), &(params[0][1]), 0);
	  break;
	}
      } // end if (model_type==PARAM)
      
      
	// a.2) compute the locations of the updated mid-side nodes
      for (int eiter = 0; eiter < numv_e; eiter++ ) {
	edge = V_edge(vd, eiter);
	
	if (edge==edgeDel)
	  continue;
	vertex =E_otherVertex (edge, vd);
	if (E_exists(vr, vertex))
	  continue;
	
	double mid_xyz[3];
	pt =P_new ();
	gent =EN_whatIn (edge);
	switch (EN_whatInType (edge)) {
	case Tedge:
	  // the merged edge will keep classified on the model edge
	  
	  if (model_type==PARAM) {
	    // compute the parametric value(s) for vertex
	    
	    switch (EN_whatInType (vertex)) {
	    case Tvertex:
	      // the other vertex is on a model vertex
	      params[1][0] =GE_vertexReparam((pGEdge)gent, (pGVertex)EN_whatIn(vertex));
	      break;
	      
	    case Tedge:
	      // the other vertex is on a model edge
	      params[1][0] =P_param1 (V_point(vertex));
	      break;
	    }
	    
	    // evaluate the physical coordinates by parametic value
	    double mid_param =(params[0][0]+params[1][0])/2.0;
	    GE_point((pGEdge)gent, mid_param, mid_xyz);
	    //FMDB_P_setParametricPos (pt, mid_param, 0, 0);
	    
	  } // end if (model_type==PARAM)
	  
	  else {
	    // for mesh model
	    
	    
	  } // end if for mesh model
	  break;
	  
	case Tface:
	  // the merged edge will keep classified on the model face
	  if (model_type==PARAM) {
	    // compute the parametric value(s) for vertex
	    
	    switch (EN_whatInType (vertex)) {
	    case Tvertex:
	      // the other vertex is on a model vertex
	      GF_vertexReparam((pGFace)gent, (pGVertex)EN_whatIn(vertex), params[1]);
	      break;
	      
	    case Tedge:
	      // the other vertex is on a model edge
	      GF_edgeReparam ((pGFace)gent, (pGEdge)EN_whatIn(vertex), 
			      P_param1(V_point(vertex)), 1, params[1]);
	      break;
	      
	    case Tface:
	      // the other vertex is on a model face
	      P_param2 (V_point (vertex), &(params[1][0]), &(params[1][1]), 0);
	      break;
	    }
	    
	    // evaluate the physical coordinates by parametic value
	    double mid_params[2];
	    mid_params[0] =(params[0][0]+params[1][0])/2.0;
	    mid_params[1] =(params[0][1]+params[1][1])/2.0;
	    GF_point((pGFace)gent, mid_params, mid_xyz);
	    //FMDB_P_setParametricPos (pt, mid_params[0], mid_params[1], 0);
	    
	  } // end if (model_type==PARAM)
	  
	  else {
	    // for mesh model
	    
	  } // end for mesh model
	  break;
	  
	case Tregion:
	  // we assume the new/updated interior edge to be straight-sided
	  V_coord (vertex, xyz[1]);
	  for (int i=0; i<3; i++)
	    mid_xyz[i] =(xyz[0][i]+xyz[1][i])/2.0;
	  break;
	}
	
	P_setPos(pt, mid_xyz[0], mid_xyz[1], mid_xyz[2]);
	
	// associate the new node with the other mesh vertex that bounds
	// the edge than vd
	newEdgeNodes[vertex] =pt;
      } // end loop of edges bounded by vd
      
      
	//    ==============================================================================
	// b) evaluate the quality of the new/updated elements
	//    ==============================================================================
      for (temp1=0; (region =(pRegion)PList_next(Vd_regs,&temp1)); ) {
	if (R_inClosure(region,(pEntity)edgeDel))
	  // skip those regions that tend to be deleted (which are bounded by edgeDel)
	  continue;
	
	// b.1) get the coodinates of the four mesh vertices
	//      (i=0 to i=3)
	
	pVertex v[4];  // only for case of interior edge being collapsed
	
	rverts = R_vertices(region,1);
	for (temp2=0, i=0; (vertex =(pVertex)PList_next(rverts, &temp2)); i++) {
	  if (vertex == vd) {
	    if(pSizeField)
	      pmt[i]=pSizeField->getSize(vr);
	    V_coord(vr,xyz[i]);
	    
	    v[i] =vr; // interior
	  }
	  else {
	    if(pSizeField)
	      pmt[i]=pSizeField->getSize(vertex);
	    V_coord(vertex,xyz[i]);
	    
	    v[i] =vertex; // interior
	  }
	}
	PList_delete(rverts);
	
	// b.2) get the coodinates of the six mid-side nodes
	//      (i=4 to i=9)
	pPList redges =R_edges (region,1);
	for (temp2=0; (edge =(pEdge)PList_next(redges, &temp2)); i++) {
	  
	  if (E_vertex (edge, 0)!=vd && E_vertex (edge, 1)!=vd) {
	    E_bezierCtrlPt(edge, xyz[i]);
	  }
	  else {
	    pVertex v =E_otherVertex (edge, vd);
	    if ((edge =E_exists(v, vr))) {
	      E_bezierCtrlPt(edge, xyz[i]);
	    }
	    else {
	      std::map<pVertex, pPoint>::iterator it =newEdgeNodes.find(v);
	      if (it!=newEdgeNodes.end()) {
		pt =newEdgeNodes[it->first];
		xyz[i][0] =P_x(pt);
		xyz[i][1] =P_y(pt);
		xyz[i][2] =P_z(pt);
	      }
	    }
	  }
	}
	PList_delete (redges);
	
	// calculate shape and check acceptability
	int index;
	if ( !HO_XYZ_isValid(xyz, &csi, region)) {
	  // the region is invalid
	  
	  PList_delete(Vd_regs);
	  
	  // delete the new edge nodes
	  for (std::map<pVertex, pPoint>::iterator it =newEdgeNodes.begin();
	       it!=newEdgeNodes.end(); it++)
	    P_delete (it->second);
	  
	  newEdgeNodes.clear ();
	  return 0;
	}
	
	//	printf ("\n     --- shape_1 =%lf", shape_1);
	// collect shape information of result local mesh
	if(csi.shape < worstShape)
	  worstShape=csi.shape;   
      }
      
      // clean up the new edge nodes, if any
      for (std::map<pVertex, pPoint>::iterator it =newEdgeNodes.begin();
        it!=newEdgeNodes.end(); it++)
        P_delete (it->second);
      newEdgeNodes.clear ();

    } // end of if quadratic == true
#endif //CURVE
  } // end of 3D case
  
  results->setWorstShape(worstShape);  
  PList_delete(Vd_regs); 
#ifndef CURVE
  if(worstShape<QUALITYFRACTION*QUALITYTHRESHOLD)
    return 0;
#endif
  return 1;
}


/*
  calculate max/min size, and max ratio of edge size increase after collapse
*/ 
int edgeCollapsMod::sizeCheck()
{
  pFace face;
  pEdge edge;
  int i,j;
  double tmp, size0, ratioSq;
  pMSize desireT0,desireT1 ;

  double maxSq=0.0;
  double minSq=1.0e20;
  double max_ratioSq;    // the ratio square of edge increase at max size
  double maxRatio_lenSq; // the edge size at max ratio 
  double maxRatioSq=0;    // the max ratio square of edge length increase 

  pVertex vertex;
  double coords[3], xyzR[3];

  if( !pSizeField ){
    printf("WARNING: NULL metric field !!!");
    return 1;
  } 

  V_coord(vr,xyzR);

  // get info at the vertex to be retained
  desireT0=pSizeField->getSize(vr);

  // estimate the size after collapse
  int mergeEdge;
  for(i=0;i<V_numEdges(vd);i++) {
    edge=V_edge(vd,i);
    if(edge==edgeDel) 
      continue;
    mergeEdge=0;
    for(j=0;j<E_numFaces(edgeDel); j++) {
      face=E_face(edgeDel,j);
      if( F_inClosure(face,(pEntity)edge) ) 
	{ mergeEdge=1; break;}
    }
    if( mergeEdge )
      continue;

    vertex=E_vertex(edge,0);
    if(vertex == vd) 
      vertex=E_vertex(edge,1);
    
    // calculate size of current edge after collapse virtually
    if(vertex == vertMv)
      { coords[0]=target[0]; coords[1]=target[1]; coords[2]=target[2]; }
    else
      V_coord(vertex,coords);
    
    desireT1=pSizeField->getSize(vertex);
    if(vertMv==vr)
      tmp=pSizeField->lengthSq(target,coords,desireT0,desireT1);
    else
      tmp=pSizeField->lengthSq(xyzR,coords,desireT0,desireT1);


    // calculate size of current edge before collapse
    size0=pSizeField->lengthSq(edge);
    ratioSq=tmp/size0;

    // calculate max/min value
    if( minSq>tmp )
      { minSq=tmp; }
    if( maxSq<tmp ) 
      { maxSq=tmp; max_ratioSq=ratioSq; }
    if( ratioSq>maxRatioSq ) 
      { maxRatioSq=ratioSq; maxRatio_lenSq=tmp; }
  }

  // calculate the size change due to a vertex motion if there is
  if( vertMv && vertMv!=vd ) {

    desireT0=pSizeField->getSize(vertMv);

    for(i=0;i<V_numEdges(vertMv);i++) {
      edge=V_edge(vertMv,i);
      if(edge==edgeDel) 
	continue;
      vertex=E_vertex(edge,0);
      if(vertex == vertMv)  
	vertex=E_vertex(edge,1);
      if(vertex == vd ) 
	continue;
      
      V_coord(vertex,coords);
      desireT1=pSizeField->getSize(vertex);
      tmp=pSizeField->lengthSq(target,coords,desireT0,desireT1);

      size0=pSizeField->lengthSq(edge);
      ratioSq=tmp/size0;

      if( minSq>tmp ) 
	{ minSq=tmp; }
      if( maxSq<tmp ) 
	{ maxSq=tmp; max_ratioSq=ratioSq; }
      if( ratioSq>maxRatioSq ) 
	{ maxRatioSq=ratioSq; maxRatio_lenSq=tmp; }
    }	  
  }
  
  results->setMaxSize(maxSq);
  results->setMinSize(minSq);
  results->setMaxRatioSquare(maxRatioSq);
  results->setSizeAtMaxRatio(maxRatio_lenSq);
  results->setRatioSquareAtMaxSize(max_ratioSq);

  return 1;
}

/* get the mesh regions to be affected by this collapse operation */
void edgeCollapsMod::getAffectedRgns(pPList *l)
{
  *l=V_regions(vd);

  if( vertMv && vertMv!=vd ) {
    pPList vrlist=V_regions(vertMv);
    pRegion region;
    void *iter=0;
    while( region=(pRegion)PList_next(vrlist,&iter) )
      PList_appUnique(*l, region);
    PList_delete(vrlist);
  }

  return;
}

/* perform the collapse and the motion */
int edgeCollapsMod::apply()
{
  pPList newRegs;
  apply( &newRegs );
  PList_delete(newRegs);
  return 1;
}


/*
  the same as above, but return the new regions of the polyhedron
*/

int edgeCollapsMod::apply(pPList *newRegs)
#ifdef MATCHING
{
  pPList newEds, newFcs; 
  apply( &newEds, &newFcs, newRegs); 
  PList_delete(newEds);
  PList_delete(newFcs);
  return 1; 
}

int edgeCollapsMod::apply(pPList* newEds, pPList* newFcs, pPList *newRegs)
#endif
{
#ifdef DEBUG
  pRegion region;
  pEntity ent;
  void *iter;
#endif

  if( vertMv && vertMv!=vd ) {
    adaptUtil::move_vertex(vertMv,target,CB_move,userData_CB_move);
#ifdef DEBUG
    pPList mvRgns=V_regions(vertMv);
    pPList vdRgns=V_regions(vd);
    iter=0;
    while( region=(pRegion)PList_next(mvRgns,&iter) ) {
      if( ! PList_inList(vdRgns,region) )
	if( R_Volume2(region) < 1.e-14 )
	  printf("Error: 1. region %d: R_volume=%f (edgeCollapsMod::apply())\n",
		 EN_id((pEntity)region),R_Volume2(region));
    }
    PList_delete(mvRgns);
    PList_delete(vdRgns);
#endif
  }

  if( pSizeField )
    pSizeField->deleteSize((pEntity)vd);
  // get edge point if any. May 1, 2010, QLU
  if(E_numPoints(edgeDel)){ 
    pPoint point = E_point(edgeDel, 0);
    P_delete(point);
  }
#ifndef MATCHING
  templatesUtil::Edge_colaps(mesh,edgeDel,vd,vr,function_CB,userData_CB,newRegs);
#else
  templatesUtil::Edge_colaps(mesh,edgeDel,vd,vr,function_CB,userData_CB,newEds, newFcs, newRegs);
#endif

#ifdef CURVE

#ifdef DEBUG
  if( pSizeField->type()==1 ){ // if PWLinear size field is given, check whether the 
                    // new vertices has size field attached
    void *tmp = 0;
    pRegion pNewRgn;
    pVertex pNewVtx;
    pPList rvlist;
    while(pNewRgn=(pRegion)PList_next(*newRegs, &tmp)){
      void *tmpVtx = 0;
      rvlist = R_vertices(pNewRgn, 1);
      while(pNewVtx=(pVertex)PList_next(rvlist, &tmpVtx)){
        assert(pSizeField->getSize(pNewVtx)); // assert new vertex has a size 
      }
    }
  }
#endif//DEBUG

  // May 1, 2010, QLU
  if (quadratic == true) { // && !newEdgeNodes.empty()) {
    // set new nodes on the edges that have been merged
    
    // set up new edge nodes if on model boundary
    if(model_type==PARAM){
      // cout<<"set up new edge nodes if on model boundary"<<endl;
      void *temp=0;
      pRegion newRgn;
      pEdge newEdge;
      pPList relist;
      while(newRgn=(pRegion)PList_next(*newRegs,&temp)){
	void *tempEdge=0;
	relist = R_edges(newRgn, 1);
	while(newEdge=(pEdge)PList_next(relist,&tempEdge)){
	  if(E_whatInType(newEdge) != 3 && !E_numPoints(newEdge)) {
	    double xyz[3];
	    double par[3];
	    templatesUtil::middlePoint(newEdge,0.5,xyz,par);
	    pPoint pt = P_new();
	    P_setPos(pt, xyz[0], xyz[1], xyz[2]);
	    E_setPoint(newEdge, pt);
	    FMDB_P_setParametricPos(pt, par[0], par[1], par[2]);
	  }
	}
      }
      //PList_delete(relist);
      
    }


    int numv_e = V_numEdges(vr);
    pEdge edge;
    pPoint pt;
    for (int iter=0; iter <numv_e; iter++) {
      edge = V_edge(vr, iter);
      std::map<pVertex, pPoint>::iterator it =newEdgeNodes.find(E_otherVertex (edge, vr));
      if (it!=newEdgeNodes.end()) {
	pt = newEdgeNodes[it->first];
	P_delete(pt);
      }
    }
    newEdgeNodes.clear ();
    
  }
#endif //CURVE

#ifdef DEBUG
  iter=0;
  while( ent =(pEntity)PList_next(*newRegs,&iter) ) {
    if(EN_type(ent) == 3) {
      if( R_Volume2((pRegion)ent) < 1.e-14 )
	printf("Error: 2. region %d: R_volume=%f (edgeCollapsMod::apply())\n",
	       EN_id((pEntity)ent),R_Volume2((pRegion)ent));
    }
  }
#endif
  return 1;
}

/*
  return 1. parametric span is acceptable
         0  span too much
*/
int edgeCollapsMod::GF_checkPeriodicSpan(pGFace gf) 
{

  // see if periodicity exists
  if( !GF_periodic(gf,0) && !GF_periodic(gf,1) ) 
    return 1;

  pEdge edge;
  pVertex otherVt;
  double parVr[3], par[3];
  double period, low, high, span;
  double tol=M_getTolerance();
  int i,j;

  adaptUtil::V_reparamOnGFace(vr,gf,parVr);

  for( i=0; i<V_numEdges(vd); i++ ) {
    edge=V_edge(vd,i);
    if( E_whatInType(edge)!=GEN_type(E_whatIn(edge)) )
      printf("something wrong\n");
    E_whatInType(edge);
    if( E_whatIn(edge) != (pGEntity)gf ) continue;
    if( edge==edgeDel ) continue;

    otherVt=E_otherVertex(edge,vd);
    adaptUtil::V_reparamOnGFace(otherVt,gf,par);

    for( j=0; j<2; j++ ) {

      if(GF_periodic(gf,j)) {

	if( adaptUtil::ifDegenerated(gf, par, tol) == (j+1)%2 )
	  continue;
	if( adaptUtil::ifDegenerated(gf, parVr, tol) == (j+1)%2 )
	  continue;

	GF_parRange(gf,j,&low,&high);
	period=high-low;
	span=ABS(parVr[j]-par[j]);
	if( (period*MAX_PERIODIC_SPAN<span) && 
	    (period*(1-MAX_PERIODIC_SPAN)>span) ) 
	  return 0;
      }
    }
  }
  
  return 1;
}

int edgeCollapsMod::GE_checkPeriodicSpan(pGEdge ge)
{
  // see if a periodic model edge
  if( !GE_periodic(ge) ) 
    return 1;
  
  pEdge edge;
  pVertex otherVt;
  double par, par1;
  double span, period, low, high;
  int i;

  // check the mesh edge on model edge
  for( i=0; i<V_numEdges(vd); i++ ) {
     edge=V_edge(vd,i);
     if( edge == edgeDel ) continue;
     if( E_whatInType(edge)==Gedge ) break;
  }

  otherVt=E_otherVertex(edge,vd);
  adaptUtil::V_reparamOnGEdge(otherVt,ge,&par);
  adaptUtil::V_reparamOnGEdge(vr,ge,&par1);
  span=ABS( par-par1 );
  GE_parRange(ge,&low,&high);
  period=high-low;
  if( (period*MAX_PERIODIC_SPAN<span) && 
      (period*(1-MAX_PERIODIC_SPAN)>span) ) 
    return 0;

  // check mesh edges on model faces
  pPList gfs=GE_faces(ge);
  pGFace gf;
  void *iter=0;
  while( gf=(pGFace)PList_next(gfs,&iter) )
    if( ! GF_checkPeriodicSpan(gf) ) {
      PList_delete(gfs);
      return 0; 
    }

  PList_delete(gfs);
  return 1;
}
