#ifndef _H_SizeBase
#define _H_SizeBase

#include "FMDB.h"
#include "AdaptTypes.h"


class SFieldBase 
{
 public:
  SFieldBase() {};
  virtual ~SFieldBase() {};

  virtual int type() = 0 ;

  // geometric computation
  virtual double lengthSq(pEdge) = 0;
  virtual double areaSq(pFace) = 0;
  virtual double volume(pRegion) = 0;

  virtual double lengthSq(dArray,dArray,pMSize) = 0;
  virtual double areaSq(dArray[3], pMSize, dArray) = 0;
  virtual double volume(dArray[4], pMSize) = 0;
  virtual double angleSq(dArray, dArray, pMSize) = 0;

  virtual double lengthSq(dArray,dArray,pMSize,pMSize) = 0;
  virtual double lengthSq(pVertex,pVertex) = 0;

  virtual void decomposeMetricTensor(pVertex, dArray) = 0;
  virtual pMSize decomposeMetricTensor(pMSize, dArray) = 0;

  // compute location of center point and its associated size
  virtual void center(pEdge, dArray, pMSize *) = 0;
  virtual double center(pVertex,pVertex,dArray,pMSize *) = 0;

#ifdef MATCHING
  virtual void center(pVertex,pVertex, double, dArray, pMSize *) = 0;
#endif  

  // set/delete the size at an entity
  virtual void setSize(pEntity, pMSize) = 0;
  virtual void setSize(pEntity, dArray[3], dArray) = 0;
  virtual void setSize(pEntity, double) = 0;
  virtual void deleteSize(pEntity) = 0;

  // get the size at a point/vertex 
  virtual pMSize getSize(dArray, pEntity) = 0;
  virtual pMSize getSize(dArray, pPList) = 0;
  virtual pMSize getSize(pVertex) = 0;
  virtual pMSize getSize(pEntity, dArray, dArray, pEntity) = 0;


  virtual void interpolate(pMSize,pMSize,double,pMSize *) = 0;
};

#endif
