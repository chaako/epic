#ifndef _H_EDGESPLIT
#define _H_EDGESPLIT

/* this class evaluate and apply and edge splitting operation

   Input: a mesh edge and a locaton to split the edge
          (note the split location may not on the edge)

   return: 1 - indicate the result mesh is acceptable wrt the 
               measure and threshold u specified
           0 - indicate not acceptable
     
   Comments:	  
 1.If the edge to be split is on model boundary, parameter values
   that match the XYZ location should be specified correctly. Otherwise,
   it is your duty to 
   calculate the correct parameter for the new vertex and move
   it to model boundary; 

 2.Topologically, edge splitting is always valid; If u pick the
   split location on the edge, geometrically, edge splitting is
   also always valid

 3.u can call member function geomCheck() and sizeCheck() in the 
   order u like

 4.When interpolating size info, we assume the split location is on
   the edge or very close to the edge

   Modification history:
     06/20/01  created by Xiangrong Li
*/

#include "LocMeshMod.h"
#include <map>
using std::map;

class edgeSplitMod: public locMeshMod
{
 public:
  edgeSplitMod(const edgeSplitMod &);  // copy constructor
  edgeSplitMod(pMesh, pSField, MeanRatio *, evalResults *); 
              //mesh  //sizefield // ??     // results container
  ~edgeSplitMod() {} // destructor

  /* the common local modification interface */
  virtual int topoCheck();   
  virtual int geomCheck();
  virtual int sizeCheck();
  virtual void getAffectedRgns(pPList *);
  virtual int apply();
  virtual int apply(pPList *);
  virtual modType type() { return ESPLIT; }

  /* specific member functions for edge split */
  void setSplitEdge(pEdge e) { edge=e; }
  void setSplitPos(double p[3],double *a);
  pVertex getNewVertex() { return v; }
  pEdge getSplitEdge() { return edge; }
  double getParam(int i) { return par[i]; }
#ifdef CURVE
  void setHighOrderEdPts(pVertex vt, double *xyz) {edpts[vt] = xyz;}
#endif

 private:
  pEdge edge;        // the edge to be split
  double xyz[3];     // the location of the new vertex
  double par[3];     // the parameter value in case at boundary
  pVertex v;         // the new vertex created in splitting
#ifdef CURVE
  map<pVertex, double*> edpts;
#endif
};

inline edgeSplitMod::edgeSplitMod(const edgeSplitMod &x):
  locMeshMod(x.mesh, x.pSizeField, x.shpMeasure, x.results) 
{
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;    
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;
  CB_move=x.CB_move;
  userData_CB_move=x.userData_CB_move;

  vertMv=x.vertMv;
  target[0]=x.target[0];
  target[1]=x.target[1];
  target[2]=x.target[2];

  edge=x.edge;
  xyz[0]=x.xyz[0];
  xyz[1]=x.xyz[1];
  xyz[2]=x.xyz[2];
  par[0]=x.par[0];
  par[1]=x.par[1];
  par[2]=x.par[2];
#ifdef CURVE
  quadratic = x.quadratic;
#endif //CURVE
}

inline edgeSplitMod::edgeSplitMod(pMesh p, pSField mf, MeanRatio *m,
				  evalResults *r):
  locMeshMod(p,mf,m,r), edge(0)
{
  xyz[0]=0.0;
  xyz[1]=0.0;
  xyz[2]=0.0;
  par[0]=0.0;
  par[1]=0.0;
  par[2]=0.0;
#ifdef CURVE
  quadratic=false;
#endif //CURVE
}

#endif



