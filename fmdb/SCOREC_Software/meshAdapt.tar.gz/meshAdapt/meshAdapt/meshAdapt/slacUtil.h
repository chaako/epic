
#include "scorecSSList.h"
#include "PList.h"
#include <iostream>
#include <vector>
#include <string>
#include <map>
//#include "mpi.h"
#include "mMesh.h"

using namespace std;

namespace slacUtil {
  void importNCDFBin(char *fName, pMesh theMesh, int mid_flag);
  void exportNCDFBin(pMesh inputMesh, pGModel model, const char *mname, const char *tagFname);
  void importNCDF(const char *fName, pMesh theMesh, int mid_flag);
  void exportNCDF(mPart *inputMesh, pGModel model, const char *mname, const char *tagFname);
  //* element shape measure used by SLAC acdtool based on Barry Joe's
#ifdef CURVE
  int SU_AspectRatio(pRegion region, double &shape);

  int SU_RadiusRatio(pRegion region, double &shape);
  int SU_XYZ_RadiusRatio(double (*)[3], double&);
#endif /*CURVE*/
  int SU_mesh_info(pMesh pMeshMesh, int &nbr_int_tet, int &nbr_ext_tet, int &nbr_surf_midpt, vector<pRegion> &, vector<pRegion> &);
  void buildMapping(char* CubitJournal, char* IDMap, char* BCID);
  /* slac exporting API for individual file */
  void exportPart(char* partfilename, pGModel model, pMesh inputMesh, map<int, int> &face_map, map<int, int> &region_map, int nproc, int rank);
  /* exporting summary file */
  void exportSummary(char* filename, unsigned long ntetra, unsigned long ncoords, int nfiles);
  /* parsing attribute file */
  void att_parse(char* attributefile, map<int, int> *face_map, map<int, int> *region_map);
  /* assign global ID , collective call*/
 
  //void PM_setEntityIds(pParMesh pm,int dimfilt,int pbsame,int thropt,int *tnid);
}
