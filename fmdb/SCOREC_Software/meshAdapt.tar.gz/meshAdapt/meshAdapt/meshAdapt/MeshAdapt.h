#ifndef _H_MSHADAPT
#define _H_MSHADAPT

#ifdef CURVE
#include "curveUtil.h"
#include "curveMesh.h"
#endif //CURVE

#include "snap.h"
#include "templateRefine.h"
#include "LayerEdgeCollapsMod.h"
#include "LayerEdgeSwapMod.h"
#include <vector>
#include <list>
#include <set>
#include <deque>

#ifdef MA_PARALLEL
#include "pmMigrationCallbacks.h"
//using AOMD::pmMigrationCallbacks;
#endif

typedef int (*adaptSFunc)(pMesh,pSField,void *);


/** \brief Type of the size field.
 *
 *  Application - the size field will be provided by the application (default).
 *  TagDriven - tag driven size field. 
 *  Analytical - analytical size field. 
 *
 */
typedef enum SizeFldType
{
  Application, TagDriven, Analytical, SF_TagDriven
} SizeFldType;


class meshAdapt
{
 public:
  meshAdapt(pMesh, pSField, int, int);
  meshAdapt(pMeshMdl pMeshInstance, int iSizeFld, int iModelType);
  ~meshAdapt();

  meshSnap* getSnapObj() {return pSnap;}
  meshTemplate *getRefObj() {return pRef;}

  /** \brief Mark the mesh entities for template refinement.
   *
   *
   *
   *  \param  edge         (In)  Edge which has to be marked / unmarked
   *  \param  level        (In)  Level of refinement. 
   *                               0: if tagged, remove the tag
   *                               1: bisect the mesh edge
   */
  void setAdaptLevel(pEdge edge, int level);


  /** \brief Lookup if the edge is tagged for refinement. 
   *
   *
   *
   *  \param  edge         (In)  Edge for which he lookup is being made
   *  \return                    The integer specifying the level of refinement
   */
  int getAdaptLevel(pEdge edge);


  int GetNumIt() { return iNumIt; }


  adaptSFunc GetSizeFldFunc() { return SizeFldFunc; }


  void SetSizeFldFunc(adaptSFunc Func) { SizeFldFunc = Func; }


  void SetNumIt(int iIt) { iNumIt = iIt; }


  /** \brief Set the callback function to be activated in local mesh modification.
   *
   *  CB for modifications but vertex motion.
   *
   *  \param  CB            (In)  Callback function
   *  \param  userData      (In)  User data
   */
  void setCallback (CBFunction CB, void *userData);


  /** \brief Set the callback function to be activated in local mesh modification.
   *
   *  Also sets callback to a snapping object. CB for vertex motion as well.
   *
   *  \param  CB            (In)  Callback function
   *  \param  userData      (In)  User data
   */
  void setCallback (CBFunc_move CB, void *userData);



  /** \brief Set checking volume/area change in mesh modification. 
   *
   *  
   *
   *  \param  v             (In)  Sets a volume limit 
   *  \param  a             (In)  Sets an area limit
   */
  void setVolumeCheck(double v, double a) { checkVolume=1; dV_limit=v; dA_limit=a; }


  /** \brief Constraint a mesh entity and all its downward entities.
   *
   *
   *
   *  \param  ent           (In)  
   */
  void setConstraint(pEntity ent);


  /** \brief Constraint a model entity and all its downward entities.
   *
   *
   *
   *  \param  gent          (In)
   */
  void setConstraint(pGEntity gent);


  /** \brief Set maximum allowed edge length with respect to mesh metric field.
   *
   *
   *
   *  \param  length        (In)
   */
  void setMaxLenRatioSq(double length);


  /** \brief Set the threshold below which elements are processed by realignmnet.
   *
   *
   *
   *  \param  threshold     (In)
   */
  void setQualityCheckThreshold(double threshold) { qualityThreshold=threshold; }


  /** \brief Set the predictive load balance flag.
   *
   *
   *
   *  \param  flag          (In)  0: no predictive load balance
   *                              1: execute predictive load balance
   */
  void SetPreLBFlag(int iFlag) { iPreLBFlag = iFlag; }


  int GetPreLBFlag(void) { return iPreLBFlag; }


  void SetSizeFldType(int iType) { iSizeFldType = iType; }


  int GetSizeFldType(void) { return iSizeFldType; }


  int SetBLTetrahedronization(int iFlag) { BLTetrahedronization = iFlag; }


  double SetTetrahedronization_AspectRatioLimit(double dLimit) { double dBLAspectRatioLimit = dLimit; }


  /** \brief ????? Set the factor which influences the calculation of the achieved size field.
   *
   *
   *
   *  \param  alphafactor   (In)
   */
  void setAlphaFactor(double alphafactor) {alphaFactor = alphafactor;}


  /** \brief Set pMeshDataId, mesh data tag, for the solution field.
   *
   *
   *
   *  \param  SolID         (In)  Solution id tag
   */
  void setSolutionID(pMeshDataId SolID){SolutionID = SolID;}


  /** \brief Set number of solution variables.
   *
   *
   *
   *  \param  nV            (In)  Number of solution variables.
   */
  void setnVar(int nV) {nVar = nV;}


  /** \brief Run the adapter.
   *
   *
   *
   *  \param  nIter         (In)  Specifies the maximum number of iterations.
   *  \param  sfFlag        (In)  Indicates if a size field function call is available
   *  \param  sizefd        (In)  The size field function call
   *  \param  userLB        (In)  
   */
  void run(int nIter,int sfFlag, adaptSFunc sizefd);
  #ifdef MA_PARALLEL
  void run(int nIter, int sfFlag, adaptSFunc sizefd, pmMigrationCallbacks& userLB);
  #endif

  int optimize(double);
//  int Laplace(double,int);

  /// Print out the mesh information on the PBC model entities
  void printoutPBC();

  /// Returns an existent size field
  pSField getSizeField() { return pSizeField; }

  void setSizeField(pSField SF) { delete pSizeField; pSizeField = SF; }

  void setMeshMdl(pMeshMdl pMI) {pMeshInst = pMI;}


  pMeshDataId GetFirstNodalSpacingID() { return firstLayerThicknessID; }

  void SetFirstLayerThicknessFlag(int iFirstLayerThicknessFlag);
  void SetFirstLayerThickness(pVertex pVertexVtx, double dFirstLayerThickness);
  void setThicknessGradeFactorOnGC(double value) { thicknessGradeFactorOnGC = value; }
  void setThicknessGradeFactorAroundGC(double value) { thicknessGradeFactorAroundGC = value; }


#ifdef CURVE
  ////////////////// temp added by QLU, Aug 15, 2010
//  int call_coarsen(double upperBoundSq, pmMigrationCallbacks& userLB){ return coarsen(upperBoundSq, userLB); }
  //////////////////

  //* APIs for Curved Mesh Adapt *// QLU Sep 14, 2010

  /* Public API's */

  curveMesh* CMA(){ return _pCrvMesh; }
 
  /** \brief Get the worst shaped region among all the regions of the local part
   *
   */
  pRegion CMA_GetTheWorstShapedRegion(){ return _TheWorstShapedRegion;}

  /** \brief Improve region shape by nodal smoothing
   *
   */
  int CMA_ImproveRegionBySmoothing(pRegion);

  /**
   */
  int CMA_TagEdgeWithLargeCurve();

  /** \brief Check whether the mesh has parametric coordinates
   *  
   */
  int CMA_CheckVtxParamCoords(int myrank);

  /** \brief Clear the vector of edges to be collapsed

   */
  int CMA_ClearEdgeVecToClps();

  /** \brief Clear the vector of edges to be splitted

   */
  int CMA_ClearEdgeVecToSplit();

  /** \brief Create the two vectors of edges to be splitted and collapsed respectively
   * \param  lower     Lower bound
   * \param  upper     Upper bound
   */
  int CMA_CreateEdgeVecs(double lower, double upper);

  /** \brief Fix the invalid regions by topological modifications
     
   */
  int CMA_FixInvalidRgnsByTopoMods(curveMesh*);

  /** \brief Fix the poorly shaped regions by topological modifications

   */
  int CMA_FixPoorRgnsByTopoMods(curveMesh*);

  /** \brief Set up the list of regions whose shape quality is below threshold
     
   */
  int CMA_GetRegionListBelowShape();

  int CMA_ProcessEdgeVecToClps();
  int CMA_ProcessEdgeVecToSplit();
  int CMA_SetRegionListBelowShape();

  /** \brief Output shape info of all regions of the local mesh
    
   */
  int CMA_ShapeInfo();
  int CMA_TestCrvEdgeSwap();
  int CMA_SetMyRank(int i);

  /** \brief Calculate the min, max and average of the length of all edges of the local mesh
 
   */
  int CMA_CalcMinMaxAve(double &Min, double &Max, double &Ave);

 /* start APIs from "fromCrvBranch.cc"  */
  int CMA_isEdgeClpsModValid(edgeCollapsMod *pEdgeClps, pRegion pRgn, double &dShape);

  pMeshDataId _SwapEdge; 
  pMeshDataId _SplitEdge;
  pMeshDataId _ClpsEdge;
#endif

 protected:
 
#ifdef CURVE

  int _iMyRank;

  // Internal functions for Curved Mesh Adapt // QLU Sep 14, 2010

  // mesh level api's 
  pMesh CrvMesh(){return pmesh;}  

  curveMesh* _pCrvMesh;

  // Internal variables for Curved Mesh Adapt // QLU Sep 14, 2010

  /// worst-shaped element
  pRegion _TheWorstShapedRegion;
  /// the worst shape
  double _TheWorstShape;
  /// Vector containing the long edges to be split
  vector<pEdge> _EdgeVecToSplit;
  /// Vector containing the long edges to be split
  vector<pEdge> _EdgeVecToClps;
#endif

  /// Input mesh.
  pMeshMdl pMeshInst;
  vector<pPart> pMeshParts;
  pPart pmesh;

  /// Size field object.
  pSField pSizeField; 

  pMeshDataId SolutionID;

  /// 1 indicates the vertex has been smoothed.
  pMeshDataId smoothed;

  int nVar;
  double upperLenSqBound, lowerLenSqBound;
  double qualityThreshold;
  double alphaFactor;

  /// Number of iterations.
  int iNumIt;

  /// Flag for predictive load balancing, 1 is to turn on predictive load balance.
  int iPreLBFlag;

  /// Type of the size field. Refer to the SizeFldType enumeration. 
  int iSizeFldType;

  /// Pointer to a size field function.
  adaptSFunc SizeFldFunc;

  /// Flag for the null mesh size field, set it to 1 if one is desired.
  int nullFieldFlag;

  /// Flag for BL adaptation, based on the number of BLs in the mesh.
  int BLAdaptFlag;

  /// Flag for understanding whether there are pyramids in the mesh
  int iMeshWithPyr;

  /// Flag for letting BLs be tetrahedronize if aspect ratio goes wrong
  int BLTetrahedronization;

  /// Maximum aspect ratio after which tetrahedranization is going to be applied to a boundary layer stack
  double dBLAspectRatioLimit;

//  pMeshDataId coarsenTested; // atteched indicates the edge has been tried coarsening
  pMeshDataId pbcId; // the mesh data Id to tag the source and target mesh edges and vertices
  std::vector<pEdge> srcEds, tgtEds; // the mesh edges on the source and target model edges
  std::vector<pVertex> srcVts, tgtVts; // the mesh vertices on the source and target model edges


  /// 1 - only do refinement driven by tagged mesh edges, 0 - do refinement/coarsening driven by values at mesh vertices.
  int iTagDrvnRef; 

  /// 0 - no model (not snap), 1 - mesh model (always snap), 2 - solid model (always snap)
  int model_type; 

  /// Set if respect volume/area change in applying local mesh modification: 0 - no volume/area control (default), 1 - respect volume/area changing.
  int checkVolume;
  double dV_limit, dA_limit;


  int isHmaxAlongThickness;
  double hmaxAlongThickness;

  double thicknessGradeFactorOnGC;
  double thicknessGradeFactorAroundGC;


  std::vector< std::pair<pVertex,double *> > *pSnapList; 

  /// Object for template refinement.
  meshTemplate *pRef;   

  /// Object for snapping.
  meshSnap *pSnap;      

  ///  callback function activated by mesh modifications, and the data set by the user and to be passed into.
  /// CB for modifications but vertex motion
  CBFunction function_CB; 
  void *userData_CB;    

  /// CB for vertex motion.
  CBFunc_move CB_move;       
  void *userData_CB_move;   

  MeanRatio *shpMeasure;
  evalResults *result;

  void setSnap(void);

  void clearSnap(void);

  
  /** \brief Tag edges for refinement.
   *
   *  Given a maximum allowed square edge length, the function tags for refinement all the edges 
   *  which square edge length is higher than the specified one.
   *
   *  \param  tSq           (In)  Square of the maximum length the edge length is desired to be.
   */
  int tagEdgesByField(double tSq);


  /** \brief Tag layer and transition edges for refinement.
   *
   *  Given a maximum allowed square edge length, the function tags for refinement all the
   *  BL layer edges (layer and transition) which square edge length is higher than the specified one.
   *
   *  \param  tSq           (In)  Square of the maximum length the edge length is desired to be.
   */
  int tagLayerEdgesInBLBySizeField(double tSq);

//  int tagLayerEdgesbyEdge(pEdge pEdgeEdge);


  int iCheckGetAdaptLvl(pEdge pEdgeEdge, double dLimit);
  int CheckAddTemplate(pEdge pEdgeInitEdge, pEdge pEdgeOppEdge, pFace pFaceFace, pFace pFaceOppFace, pRegion pRegionRgn);

  /// Tag additional edges to match the existent templates for pyramids and prisms
  int tagAdditionalEdgesForPyrTemplates(double dLimit);


  void decomposeMetricField();


  /// Set up the mesh edges and vertices for periodic model boundary entities.
  void setupEdgesForPBC(); 

  /// Tag the additional edges for periodic model boundary entities.
  int tagEdgesForPBC();
  

  int moveVertex(pVertex vt, double threshdSq,double tar[3], double *worstshp);
  int getTarget819(pVertex vt, double target[3]);
//  int getTarget816(pVertex vt, double target[3]);

  int R_isSliver(pRegion, double, double *, double);
  int removeSliverFaces();
  int swapOrsplitPbTet(pRegion, double, pMeshMod *);
  int clpsBdryTet(pRegion);
  int handleSliverFace(pFace, double, pMeshMod *, pPList *);

//  void toOptimal(pVertex vt, double opt[3],double);
  void cleanSmoothFlag();

  /** \brief Eliminate a given edge by edge collapse or relocation.
   *
   *  Given an edge and a vertex defining the cavity, the function tries 
   *  to eliminate a given edge by collapse or swap.
   *
   *  \param  edge          (In)  Edge to be coarsened
   *  \param  vd            (In)  Vertex defining the cavity
   *  \param  upperBoundSq  (In)  
   *  \param  maxWorstShape
   *  \param  clps
   *  \param  loopId        (In)  Current iteration
   *  \param  deref         (In)  Tag for coarsening
   *  \param  drVertices    (In/Out)  Container of vertexes to be coarsened
   *  \param  removedEnts   (In/Out)
   *  \return                        1 if a vertex of the edge is collapsed
   *                                 2 if a vertex of the edge is moved
   *                                 0 if no mesh modification happened
   */
  int coarsenVertex (pEdge edge, pVertex vd, double upperBoundSq, double maxWorstShape,
		     edgeCollapsMod *clps, int loopId, pMeshDataId deref, 
		     std::list<pVertex>& drVertices, std::set<pVertex>& removedEnts); 


  int coarsenVertexInBL(pEdge edge, pVertex vd, double upperBoundSq, double maxWorstShape,
                        layerEdgeCollapsMod *LEclps, int loopId, pMeshDataId deref,
                        std::list<pVertex>& drVertices, std::set<pVertex>& removedEnts);


  int isLowerLimitOnTotalThickness;

  int applyThicknessAdaptationInBL;
  int isAdjustGrowthDirectionForGCs;
  int isFirstLayerThicknessSet;
  int thicknessAdaptExecuted;

  // put gcThicknessID outside the class as it is needed (as of now)
  // in templates2D.cc (splitLinearEdge) during the split of
  // zero level layer edge
  // i.e., to tag the new vertex (ONode) created due to split of
  // zero level layer edge whose end nodes are tagged with gcThicknessID
  // pMeshDataId gcThicknessID;
  pMeshDataId firstLayerThicknessID;
  pMeshDataId layerFaceNormalChangeID;
  pMeshDataId metricDecompositionID;

  /// Snapping stuff
  pMeshDataId notBLSnapID, topNodeMoveID, moveDirID, moveVectorID, updateGCOnModelBdryID;

  int adjustGrowthDirectionForGCs();


  void thicknessAdjustmentInBL();


  void thicknessAdaptationInBL();


  void gradeLayerThicknessAlongGC(pMeshDataId targetLocationsID, pMeshDataId meshSizesID);


  void gradeLayerThicknessAroundGC(pMeshDataId targetLocationsID, pMeshDataId meshSizesID);


  int procAnNodeOnGCToGradeLayerThickness(vector<pVertex>& gcNodes, int curNode, dArray *targetLocations, deque<int> &queue);


  void procGCsOnNodesOfEdgeToGradeLayerThickness(pEdge edge, pMeshDataId targetLocationsID, pMeshDataId meshSizesID, std::deque<pEdge> &queue, pMeshDataId inQueueID);


  void updateTargetLocationsOfUpperNodesOnGCOnModelBdry(vector<pVertex>& gcNodes,
                                                        int curNode,
                                                        dArray *targetLocations);
  void updateSizesOfUpperNodesOnGC(vector<pVertex>& gcNodes,
                                   int curNode,
                                   dArray* currentLocations,
                                   dArray* targetLocations,
                                   pPList meshSizes);


  void limitTargetLocationsBasedOnAdjGCs(vector<pVertex>& gcNodes,
                                         int curNode,
                                         dArray* currentLocations,
                                         dArray* targetLocations);


  pVertex updateGCOnModelBdry(vector<pVertex>& gcNodes);

#ifdef MA_PARALLEL

  /** \brief Provides coarsening operations.
   *
   *  Given a prescribed mesh size field, this procedure eliminates
   *  short mesh edges using edge collapses applied every one another
   *  return the number of applied edge collapses.
   *
   *  \param  upperBoundSq         (In)  The maximum allowable upper bound square edge length.
   *  \param  userLB               (In)  
   *  \return                            The coarsening strategy applied
   */  
  int coarsen(double upperBoundSq, pmMigrationCallbacks& userLB);


  int coarsenSurfaceInBL(double upperBoundSq, pmMigrationCallbacks& userLB);


  /** \brief Main routine for parallel element shape correction.
   *
   *
   *
   *  \param  shpLowerBound        (In)  
   *  \param  userLB               (In)
   *  \return                            1
   */
  int removeSliverRegions(double shpLowerBound, double upperBoundSq, pmMigrationCallbacks& userLB);


  int optimizeSurfaceInBL(double upperBoundSq, pmMigrationCallbacks &userLB);


  int initSnapBLNodes(pmMigrationCallbacks &userLB);


  int snapBLNodes(pmMigrationCallbacks &userLB);


  int adjustGrowthDirectionForGCs(pmMigrationCallbacks& userLB);


  void thicknessAdjustmentInBL(pmMigrationCallbacks& userLB);


  void thicknessAdaptationInBL(pmMigrationCallbacks& userLB);


  /*B \brief Mesh migration to fulfill the local cavities for coarsening routines.
   *
   *  Given a list of mesh vertices on partition boundary (vtOnCB) and
   *  a empty mesh vertices container (drVertices), this routine tries
   *  to migrate the mesh to make as many vertices in vtOnCB interior
   *  of partition boundary as possible.
   *
   *  If this leads to conflicts, e.g., one vertex in vtOnCB want to
   *  move mesh region A into partition 1 while another vertex in vtOnCB
   *  need move region A into partition 0, we only respect the first
   *  vertex. The second vertex remains on partion boundary as well as
   *  returned in list vtOnCB.
   *
   *  After mesh migration, the routine loops over all mesh edges connected
   *  to (i) new vertices come to current partition and (ii) survived
   *  vertices in vtOnCB (both may be interior vertices or partition boundary
   *  vertices), determine if any is a short edge and append two end vertices
   *  of short edges into vertex container "drVertices".
   *
   *  \param  vtOnCB               (In)  List of vertices on partition boundary.
   *  \param  drVertices           (In)  List of vertices ito be coarsened after migration.
   *  \param  userLB               (In)  Customized load balancer.
   *  \param  deref                (In)  Coarsening tag.
   *  \param  lowerLenSqBound      (In)  Threshold.
   *  \return                            The size of drVertices
   */
  int mMigrateForCoarsen(list<pVertex>& vtOnCB, list<pVertex>& drVertices, pmMigrationCallbacks& userLB, 
			 pMeshDataId& deref, double lowerLenSqBound);


  int mMigrateForCoarsenBL(list<pVertex>& vtOnCB, list<pVertex>& drVertices, pmMigrationCallbacks& userLB,
                         pMeshDataId& deref, double lowerLenSqBound);


  void deleteDimReduction(std::list<pVertex> &, pmMigrationCallbacks&);


  void updateRgnList(pRegion,std::list<pEntity> &);


  int mMigrateForShapeCorrect(std::list<pEntity> &, std::set<pRegion> &, pmMigrationCallbacks &, double);


  int mMigrateForShapeCorrectBL(std::set<pBLayer> &FacesNextToPB, std::set<pBLayer> &newAndNotRemSlivers, pmMigrationCallbacks &userLB);


#else
  int coarsen(double upperBoundSq);
  int coarsenSurfaceInBL(double upperBoundSq);
  int removeSliverRegions(double, double upperBoundSq);
  int optimizeSurfaceInBL(double upperBoundSq);
  int initSnapBLNodes();
  int snapBLNodes();
#endif


  /* constrain and unconstrain the boundary layer entities */
  void constrainBL(int opOrStage = 0);
  void unconstrainBL(int opOrStage = 0);
  void constrainThicknessAdapt();
  void unconstrainThicknessAdapt();
  void setConstraintBL(pEntity e);
  void setUnconstraintBL(pEntity e);


};

#endif

