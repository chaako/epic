/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Optimization
  Author(s) : Pascal J. Frey
  Creation  : Jan., 95
  Modifi.   : de Cougny (ifdef MPI)
  Function  :
   Check if two vertices can be collapsed. Returns the target vertex.
   Vertices must be connected to allow collapsing. Input collapsed vert. 
   may be switched
   ifdef MPI, make sure collapsed vert. is NOT on part. bdry !
-------------------------------------------------------------------------*/
#include "FMDB.h"
#include "fromMeshTools.h"

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
 #include <stdlib.h>
#endif

int E_chkColaps(pVertex *vert0,pVertex *vert1,pEdge ledge)
{
  pVertex  vert_0,vert_1,vertx[2];
  pGEntity gment,gmptr,edgent[2],geom[2];
  pEdge   edge_0,edge_1,f_edges[3] ;
  pFace   face;
  int     i,j,gmtype[2],lent[2],gmedge,nvtx0,nvtx1;
  int     gmtyp0,edgtyp[2],status;
  int link_nbr;
  int *ngb_pids[2];
  int PInumtids;
  int PImytid;
  int link_nbrs[2];
  int k;
  int ngb_pid;
  pVertex ngb_vert;
  int found_it;
  pVertex e_verts[2];

  /* make a copy of the two vertices */
  vertx[0]= *vert0;
  vertx[1]= *vert1;
  /* get model entities and types for both vertices */
  geom[0]= V_whatIn(vertx[0]);
  gmtype[0]= V_whatInType(vertx[0]);
  geom[1]= V_whatIn(vertx[1]);
  gmtype[1]= V_whatInType(vertx[1]);
  gment= E_whatIn(ledge);
  gmedge= E_whatInType(ledge);

  if ( gmtype[0]==gmtype[1] ) {
    /* two verts are classified on model entities of same order */
    if ( geom[0] != geom[1] ) {
      /* model entitie are distinct: cannot collapse */
      return(0);
    }
    else {
      /* two verts are classified on same model entity */
      if ( gmtype[0]==Tregion ) {
	/* Common model entity is a model region: OK */
	return(1);
      }
      else {
        if ( gmedge != gmtype[0] || gment != geom[0] ) {
           return(0);
        }
	/* Need further investigation */
	lent[0] = 0;
	lent[1] = 1;
      }
    }
  }
  else {
    /* Two verts are classified on model entities of different order */
    if (gmtype[0] == Tregion || gmtype[1] == Tregion ) {
      /* One of the two verts is classified in model region.
	 Collapse ok (may have to switch though) */
      if ( gmtype[1] == Tregion ) {
	*vert0 = vertx[1];
	*vert1 = vertx[0];
      }
      return(1) ;
    }
    /* Two verts are classified on model boundary (vert, edge, or face) */
    /* Target vertex should be classified on lowest order
       model entity */
    if (gmtype[0] > gmtype[1] ) {
       lent[0] = 0;
       lent[1] = 1;
    }
    else {
      lent[0] = 1;
      lent[1] = 0;
    }

    if ( gmedge != gmtype[lent[0]] || gment != geom[lent[0]] ) {
      /* Connecting edge not classified on highest order
	 model entity: Cannot collapse */
      return(0);
    }
  }
  /* Two verts are classified on model boundary (vertex, edge, or face)
     Connecting edge is classified on model entity of highest order */
  
  nvtx0= V_numEdges(vertx[lent[0]]);
  nvtx1= V_numEdges(vertx[lent[1]]);
  for ( i= 0 ; i< nvtx0 ; i++ ) {
    edge_0= V_edge(vertx[lent[0]],i);
    if ( E_whatInType(edge_0) == Gregion ) continue;
    vert_0= E_otherVertex(edge_0,vertx[lent[0]]);
    if ( vert_0==vertx[lent[1]] )
      continue;
    found_it= 0; /* Initialize to not found */
    for ( j= 0 ; j< nvtx1 ; j++ ) {
      edge_1= V_edge(vertx[lent[1]],j);
     #ifndef MPI
      if ( E_whatInType(edge_1) == Gregion ) continue;
      #endif
      vert_1= E_otherVertex(edge_1,vertx[lent[1]]);
      if ( vert_1 == vertx[lent[0]] ) continue;
      if ( vert_1 == vert_0 ) {
	/* The two edges have a common vertex */
        found_it= 1;
        #ifdef MPI
        if ( E_whatInType(edge_1) == Gregion ) break;
        #endif
	edgent[0]= E_whatIn(edge_0);
	edgtyp[0]= E_whatInType(edge_0);
	edgent[1]= E_whatIn(edge_1);
	edgtyp[1]= E_whatInType(edge_1);

        #ifdef MPI
        /*
        Actual collapsing will delete and replace the edge
        with higher class.
        */

        if ( edgtyp[0] < edgtyp[1] ) {
           link_nbr= pmdb_en_num_iplinks(edge_1);
           if ( link_nbr > 0 ) {
              return(0);
           }
        }
        #endif

	if ( edgtyp[0]==edgtyp[1] ) {
	  if ( edgent[0]!=edgent[1] )
	    return(0) ;
	  else if ( edgtyp[0]==Gedge )
	    return(0);
	}

	/* The two edges are classified on same model face or
	   one is classified on the model face and
	   the other is classified on an adjacent model edge */
	if ( edgtyp[1] > edgtyp[0] ) {
	  edgent[0]= edgent[1];
	  edgtyp[0]= edgtyp[1];
	}
	f_edges[0]= ledge;
	f_edges[1]= edge_0;
	f_edges[2]= edge_1;
	face = F_exists(Tedge,f_edges[0],f_edges[1],f_edges[2],0);
	if ( !face ) {
	  /* There s no face that connects the 3 edges:
	     Cannot collapse */
	  return(0);
	}
	gmptr= F_whatIn(face);
	gmtyp0= F_whatInType(face);
	if ( gmtyp0!=edgtyp[0] || edgent[0]!=gmptr ) {
	  /* The face that connects the 3 edges is not
	     classified on the model face: Cannot collapse */
	  return(0) ;
	}
	break;
      } /*if */
    } /* end loop on edges connected to vertx[lent[1]] */ 

    #ifdef MPI
    /*
    Assume vertx[lent[0]] NOT on partition bdry, that is,
    all connected edges can be accessed
    */

    if ( found_it == 0 ) {

       /*
       The edge is not there on proc but could be off proc
       Be conservative:
       Do not do anything if the 2 verts are ngbing
       the same proc since it s a necessary condition
       for the edge to be actually off proc
       */

       e_verts[0]= vertx[lent[1]];
       e_verts[1]= vert_0;

       MPI_Comm_rank(MPI_COMM_WORLD,&PImytid);
       MPI_Comm_size(MPI_COMM_WORLD,&PInumtids);

       for ( j= 0 ; j< 2 ; j++ )
        ngb_pids[j]= (int *)calloc(PInumtids,sizeof(int));
       for ( j= 0 ; j< 2 ; j++ ) {
          link_nbrs[j]= pmdb_en_num_iplinks(e_verts[j]);
          for ( k= 0 ; k< link_nbrs[j] ; k++ ) {
             pmdb_en_iplink(e_verts[j],k,&ngb_pid,&ngb_vert);
             ngb_pids[j][k]= ngb_pid;
          }
       }
       status= 0;
       for ( j= 0 ; j< link_nbrs[0] ; j++ ) {
          for ( k= 0 ; k< link_nbrs[1] ; k++ ) {
             if ( ngb_pids[1][k] == ngb_pids[0][j] ) {
                status= 1;
                break;
             }
          }
          if ( status == 1 ) break;
       }
       for ( j= 0 ; j< 2 ; j++ )
        free(ngb_pids[j]);

       if ( status == 1 ) {
          return(0);
       }

    } /* If edge not there */
    #endif

  } /* end loop on edges connected to vertx[lent[0]] */
  /* restore the vertices */
  *vert0 = vertx[lent[0]];
  *vert1 = vertx[lent[1]];
  return(1);
}
 
