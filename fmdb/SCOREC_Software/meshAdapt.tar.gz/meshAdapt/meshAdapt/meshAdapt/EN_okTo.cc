/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project   : Mesh Tools
  Author(s) : Rao Garimella
  Creation  : Feb., 95
  Modifi.   : Pascal Frey, Feb., 95
  Function  :
    checks if a particular mesh modification operation is allowed by
    checking the appropriate bit field of integer data on entity and the 
    model entity it is classified on.
-------------------------------------------------------------------------*/
#include <stdio.h>
#include "FMDB.h"
#include "fromMeshTools.h"

extern int globalCst ;
extern MarkID MT_cnst;
 
int EN_okTo(int i,pEntity e) {
  pGEntity ge=0;
  int ok1, ok2, ival;

  /* have to actually check global constraint here. */
  if (globalCst & 1<<i)
    return(0);
  if (!e)
    return(1);
  else {
    switch (EN_type(e)) {
    case Tvertex:
      ge = V_whatIn((pVertex)e);
      break;
    case Tedge:
      ge = E_whatIn((pEdge)e);
      break;
    case Tface:
      ge = F_whatIn((pFace)e);
      break;
    case Tregion:
      ge = (pGEntity)R_whatIn((pRegion)e);
      break;    
    }
  }
  /* Disallow operation if either the entity or the model entity it is */
  /* classified on disallows it                                        */

  /* put in place for Delaunay mesher where classfn. is temporarily absent */
  if(!GEN_dataI(ge,"cnst",&ival))
    ival = 0;
  ok1 = ge ? !(ival & 1<<i) : 1;
  ok2 = !(EN_mark(e,MT_cnst) & 1<<i);
  return (ok1 && ok2);
}

/* Check if it is ok to perform operation on model entity */
int GEN_okTo(int i,pGEntity g) {

  /* put in place for Delaunay mesher where classfn. is temporarily absent */
  if (!g)   
    return 1;

  /* have to actually check global constraint here. */
  if (globalCst & 1<<i)
    return(0);
  if (!g)
    return(1);
  else {
    int ival;
    if(!(GEN_dataI(g,"cnst",&ival)))
       ival = 0;
    return ( !(ival & 1<<i) );
  }
}

