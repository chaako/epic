/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Optimization
  Author(s) : Hugues de Cougny
  Creation  : Mar., 94
  Modifi.   : Pascal Frey, Feb., 95
              Pascal Frey, Rao Garimella, Apr 95
  Function  :
    Check if the c'th swap configuration is valid.
-------------------------------------------------------------------------*/
#include "FMDB.h"
#include "Eswap.h"
#include "fromMeshTools.h"

extern SwapConfig sc;

int E_evalSwpCfg(pEdge edge, int c) {
  pVertex rvert[8] ;
  double  xyz[4][3];
  int     j,t,v,c2;

  /* check if swap configuration already available */
  if (sc.edge != edge)
    if (!E_numSwpCfg(edge))
      return 0;

  if (!c && !sc.nbr_triangles)
    /* This is the special case where only configuration is valid       */
    /* unless the resulting mesh will violate topological compatibility */
    /* (this is checked during the actual swap operation)               */
    return 1; 

  if (c >= sc.nbr_trianguls)
    return 0;

  /* Have to find the c'th *topologically valid* configuration */
  for (c2 = 0, j = -1; c2 < sc.nbr_trianguls; c2++) {
    if (sc.topoValidCfg[c2]) j++;
    if (j == c) break;
  }

  /* evaluate the triangles of the c'th configuration */
  for ( j=0 ; j < sc.nbr_triangles_2 ; j++ ) {
    t = sc.trianguls[c2][j];

    if (sc.valid[t]) {
      if (sc.valid[t] == -1) 
	return 0; /* invalid triangulation */
      else
	continue;
    }
     
    /* top region */
    rvert[0] = sc.pverts[sc.triangles[t][0]] ;
    rvert[1] = sc.pverts[sc.triangles[t][1]] ;
    rvert[2] = sc.pverts[sc.triangles[t][2]] ;
    rvert[3] = sc.top_vert ;
    for ( v=0 ; v<4 ; v++ )
      V_coord(rvert[v],xyz[v]) ;
    if ( XYZ_checkFlat(xyz) ) {
      sc.valid[t] = -1;
      return(0);
    }
    /* bottom region */
    rvert[0] = sc.pverts[sc.triangles[t][0]] ;
    rvert[1] = sc.pverts[sc.triangles[t][2]] ;
    rvert[2] = sc.pverts[sc.triangles[t][1]] ;
    rvert[3] = sc.bot_vert ;
    for ( v=0 ; v< 4 ; v++ )
      V_coord(rvert[v],xyz[v]) ;
    if ( XYZ_checkFlat(xyz) ) {
      sc.valid[t] = -1;
      return(0) ;
    }

    sc.valid[t] = 1;
  }
  return(1) ;
}

