#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <math.h>
#include <fstream>
#include <iostream>

#ifdef PARASOLID
#include "ParasolidModel.h"
#endif
#ifdef ACIS
#include "AcisModel.h"
#endif

#include "MA.h"
#include "mMeshIO.h"
using std::cout;
using std::endl;

int main(int argc, char* argv[])
{  

  if( argc == 1 ){
    cout<<"[Usage:] ./<exec> <1. Input Geom Model>"<<endl;
    cout<<"                  <2. Input Linear Mesh>"<<endl;
    cout<<"                  <3. Output Curved Mesh using PM_write>"<<endl;
    cout<<"                  <4. Output Curved Mesh using M_writeSMS>"<<endl;
    cout<<endl<<endl;
    return 0;
  }

  /* Initiate ParUtil and get size and rank */
  //ParUtil::Instance()->init(argc,argv);
  //int myrank = ParUtil::Instance()->rank(); 
  int nproc = SCUTIL_CommSize();

  /* Load geom model and mesh */
  pGModel model;
  pMeshMdl mesh_instance;
  vector<pPart> parts;
  pPart part;
#ifdef PARASOLID
  model=GM_createFromParasolidFile(argv[1]);
#endif
#ifdef ACIS
  model=GM_createFromAcisFile(argv[1]);
#endif

  FMDB_Mesh_Create(model, mesh_instance);

  FMDB_Mesh_GetPartOnProc(mesh_instance, 0, parts);
  part=parts.at(0);

#ifdef DEBUG
  cout<<"load mesh"<<endl;
#endif 

  FILE * pInputFile;
  int iFileFlag = 0;
  pInputFile = fopen(argv[2], "r");
  if(pInputFile){
    iFileFlag = 1;
    fclose(pInputFile);
  }

  if(iFileFlag){
    cout<<"Calling importSMS ..."<<endl;
    importSMS(mesh_instance, argv[2]); 
  }
  else{
    cout<<"Calling PM_load ..."<<endl;
    //PM_load(part, argv[2]);
    exit(1);
  }
  
  if(nproc>1){
    curveMigrateCB curveCB;
    M_loadbalance(part, curveCB);
  }

  
#ifdef DEBUG
  cout<<"Loading complete"<<endl;
#endif

#ifdef DEBUG
  cout<<"new curveMesh"<<endl;
#endif
  pCrvMesh pCrvMeshObj;
  CMA_NewCrvMeshObj(pCrvMeshObj, part); 
  CMA_CurveLinearMesh(pCrvMeshObj);
  CMA_DelCrvMeshObj(pCrvMeshObj);
#ifdef DEBUG
  cout<<"writing out mesh:"<<endl;
#endif
  //PM_write(part, argv[3]);
  //M_writeSMS(pMeshMesh,argv[4]);
  FMDB_Mesh_WriteToFile(mesh_instance, argv[4], 0);
  M_delete(part);
  
  ParUtil::Instance()->Finalize(true);
  return 0;

		  
}
