#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>

#include "mMeshIO.h"
#include "MA.h"
#include "M_writeVTKFile.h"
#ifdef PARASOLID
#include "ParasolidModel.h"
#endif /* PARASOLID */
#ifdef ACIS
#include "AcisModel.h"
#endif /* ACIS */
#ifdef MA_PARALLEL
#include "ParUtil.h"
#include "mpi.h"
#endif /* MA_PARALLEL */

using std::cout;
using std::endl;

void uniformRefine(pMesh,meshAdapt* );

void
catchDebugger() {
  static volatile int debuggerPresent =0;
  while (!debuggerPresent ); // assign debuggerPresent=1 or set debuggerPresent=1
}

int main(int argc, char* argv[])
{  

  if(argc!=6)
    {
      cout<<"\n\nUsage: ./<exec> \n <1. Geometric model to be loaded> \n <2. serial/partitioned mesh to be loaded> \n <3. partitioned mesh to be written out by PM_write> \n <4. partitioned mesh to be written out by M_writeSMS>\n <5. partitioned mesh to be written out by M_writeVTKFile>\n"<<endl;
      exit(1);
    }
  ParUtil::Instance()->init(argc,argv);
  
  pMesh pMeshMesh;
  pGModel pGeomModel = 0;
#ifdef PARASOLID
  pGeomModel = GM_createFromParasolidFile(argv[1]);
#endif
#ifdef ACIS
  pGeomModel = GM_createFromAcisFile(argv[1]);
#endif
//  zoltanCB zcb;

  int iMyRank = ParUtil::Instance()->rank();
  int iSize = ParUtil::Instance()->size();

  pMeshMesh = MS_newMesh(pGeomModel);
  //pMeshMesh = MS_newMesh(0);

  if(iMyRank==0)
  {
    cout<<"***********************************************************"<<endl;
    cout<<"****** Stage 1: Loading in partitioned (curved) mesh ******"<<endl;
    cout<<"***********************************************************"<<endl;
  }

  FILE * pInputFile;
  int iFileFlag = 0;
  pInputFile = fopen(argv[2], "r");
  if(pInputFile){
    iFileFlag = 1;
    fclose(pInputFile);
  }

  if(iFileFlag){
    cout<<"Calling importSMS ..."<<endl;
    importSMS( pMeshMesh, argv[2]); 
  }
  else{
    cout<<"Calling PM_load ..."<<endl;
    PM_load(pMeshMesh, argv[2]);
  }
#ifdef PARASOLID
  meshAdapt *pMAdaptObj = new meshAdapt(pMeshMesh, NULL, 0, 1);
#else
  meshAdapt *pMAdaptObj = new meshAdapt(pMeshMesh, NULL, 0, 1);
#endif/*PARASOLID*/
  pMAdaptObj->CMA()->CM_printNumEntities();

  if(iSize > 1){
    
    curveMigrateCB crvCB;
    cout<<"[Info]:("<<iMyRank<<"): multiple processors, migration will be called"<<endl;
    
    cout<<"[Info]:("<<iMyRank<<"): Start load balancing... "<<endl;
    M_loadbalance(pMeshMesh, crvCB);
    cout<<"[Info]: Setting points from coords... "<<endl;

  }

// check mesh validity
  if(iMyRank==0)
  {
    cout<<"**************************************"<<endl;
    cout<<"****** Stage 2: Validity checks ******"<<endl;
    cout<<"**************************************"<<endl;
  }
  for(int i=0;i<2;i++){
    if(iMyRank==0)
      cout<<"**** Iteration No."<<i<<" ****"<<endl;
    pMAdaptObj->CMA()->CM_createInvalidRgnList();
    //pMAdaptObj->CMA()->CMA_UncurveInvalidRgns();
    MPI_Barrier(MPI_COMM_WORLD);
  }
  if(iMyRank==0)
  {
    cout<<"*****************************************"<<endl;
    cout<<"****** Stage 3: Uniform Refinement ******"<<endl;
    cout<<"*****************************************"<<endl;
  }
  //M_writeVTKFile(pMeshMesh, "test_in_curveMesh");

  uniformRefine(pMeshMesh, pMAdaptObj);
  MPI_Barrier(MPI_COMM_WORLD);
  pMAdaptObj->CMA()->CM_printNumEntities();

// check mesh validity
  if(iMyRank==0)
  {
    cout<<"**************************************"<<endl;
    cout<<"****** Stage 4: Validity checks ******"<<endl;
    cout<<"**************************************"<<endl;
  }
  for(int i=0;i<1;i++){
    if(iMyRank==0)
      cout<<"**** Iteration No."<<i<<" ****"<<endl;
    //pMAdaptObj->CMA_ShapeInfo();
    pMAdaptObj->CMA()->CM_createInvalidRgnList();
    MPI_Barrier(MPI_COMM_WORLD);
  }

  if(iMyRank==0)
  {
    cout<<"**********************************************************"<<endl;
    cout<<"****** Stage 5: Write out partitioned (curved) mesh ******"<<endl;
    cout<<"**********************************************************"<<endl;
  }

  M_verify(pMeshMesh);

  PM_write(pMeshMesh, argv[3]);
  MPI_Barrier(MPI_COMM_WORLD);
  
  M_writeSMS(pMeshMesh, argv[4]);
  M_writeVTKFile(pMeshMesh, argv[5]);
  ParUtil::Instance()->Finalize();
  return 0;
		  
}

void uniformRefine(pMesh pm, meshAdapt *pAdapt)
{
  EIter eit=M_edgeIter(pm);
  pEdge edge;
  while( edge=EIter_next(eit) ) {
    //if(EN_owner(edge)==0){
      pAdapt->setAdaptLevel(edge,1);
    //}
  }
  EIter_delete(eit);

  pAdapt->run(1,0,0);

  return;
}

