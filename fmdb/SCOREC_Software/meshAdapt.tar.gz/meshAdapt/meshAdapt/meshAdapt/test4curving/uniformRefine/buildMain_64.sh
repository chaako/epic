#!/bin/bash

# this script tries to build the exec and create links assuming the source code directory is organized in such a way as follows:
# ~/$DEVELOP/$SUBSYS/$SUBMOD/$SUBMOD/$TEST/$EXEC
# the resulting exec will be name as $EXEC


# assuming we are standing at the directory of main.cc

EXEC=$(basename $PWD)   # get the folder name i.e. the exec name
cd ..
TEST=$(basename $PWD)   # get the test folder name e.g. test4curving
cd ..
SUBMOD=$(basename $PWD)
cd ../..
SUBSYS=$(basename $PWD)
cd ..
DEVELOP=$(basename $PWD)

export DEVROOT=$PWD
cd $DEVROOT
source env.pglt
cd $DEVROOT/$SUBSYS/$SUBMOD/$SUBMOD/
gmake CURVE=1
gmake checkone DIR=./$TEST/$EXEC/ MODELER=parasolid CURVE=1
cd $TEST/$EXEC

if [ -e /users/qlu/bin/debug/$EXEC ] ; then
  rm /users/qlu/bin/debug/$EXEC
  echo "[Process]: Found old exec, remove it"
else
  echo "[Process]: Old exec not found "
fi

if [ -e main ] ; then 
  ln main /users/qlu/bin/debug/$EXEC
else
  echo "[Error]: No executable is found, check errors in source codes "
fi

echo $DEVELOP
echo $SUBSYS
echo $SUBMOD
echo $SUBMOD
echo $TEST  
echo $EXEC
