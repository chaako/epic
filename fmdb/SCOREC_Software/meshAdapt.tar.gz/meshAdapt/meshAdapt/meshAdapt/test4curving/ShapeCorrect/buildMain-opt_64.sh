#!/bin/bash

# assuming we are standing at the directory of main.cc

EXEC=$(basename $PWD)   # get the folder name i.e. the exec name
cd ..
TEST=$(basename $PWD)   # get the test folder name e.g. test4curving
cd ..
SUBMOD=$(basename $PWD)
cd ../..
SUBSYS=$(basename $PWD)
cd ..
DEVELOP=$(basename $PWD)

OPT="-0"
EXEC_OPT=$EXEC$OPT

export DEVROOT=$PWD
cd $DEVROOT
source env.pglt
cd $DEVROOT/$SUBSYS/$SUBMOD/$SUBMOD/
gmake CURVE=1 VERS=opt
gmake checkone DIR=./$TEST/$EXEC/ MODELER=null CURVE=1 VERS=opt
cd $TEST/$EXEC

if [ -e /users/qlu/bin/opt/$EXEC_OPT ] ; then
  rm /users/qlu/bin/opt/$EXEC_OPT
  echo "[Process]: Found old exec, remove it"
else
  echo "[Process]: Old exec not found "
fi

if [ -e main ] ; then 
  ln main /users/qlu/bin/opt/$EXEC_OPT
  mv main main-0
else
  echo "[Error]: No executable is found, check errors in source codes "
fi

echo $DEVELOP
echo $SUBSYS
echo $SUBMOD
echo $SUBMOD
echo $TEST  
echo $EXEC_OPT
