#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>

#include "MA.h"
#include "M_writeVTKFile.h"

#ifdef PARASOLID
#include "ParasolidModel.h"
#endif
#ifdef ACIS
#include "AcisModel.h"
#endif

#ifdef MA_PARALLEL
#include "ParUtil.h"
#include "mpi.h"
#endif

using namespace curveUtil;
using namespace adaptUtil;
using std::cout;
using std::endl;

void Message(int iMyRank, char* msg){
  std::cout<<"("<<iMyRank<<")[Message]:"<<msg<<endl;
}

void Debug_wait(int i){

#ifdef DEBUG
  cout<<endl<<endl;
  cout<<"Press any key to continue ... ... "<<i<<endl;
  cout<<endl<<endl;
  char a;
  cin>>a;
#endif
  return;
}

void uniformRefine(pMesh pm, meshAdapt *pMAdaptObj)
{
  EIter eit = M_edgeIter(pm);
  pEdge edge;
  while( edge = EIter_next( eit ) ) {
    pMAdaptObj->setAdaptLevel(edge, 1); 
  }
  EIter_delete(eit);
  return;
}

int main(int argc, char* argv[])
{ 

  if(argc==1){
    cout<<"\n\nUsage: ./main <geometric model to be loaded> <meshfilename to be loaded> <meshfilename to be written out>\n\n"<<endl;
    exit(1);
  }

  int iDebugCnt = 0;

  // initialization
  ParUtil::Instance()->init(argc,argv);

  // get local rank and No of processors
  int iMyRank = ParUtil::Instance()->rank(); 
  int iSize = ParUtil::Instance()->size();; 

  pGModel pGeomModel = 0;
  pMesh pMeshMesh;
  curveMigrateCB crvCB;

  // load geom model
#ifdef PARASOLID
  pGeomModel = GM_createFromParasolidFile(argv[1]);
#endif
#ifdef ACIS
  pGeomModel = GM_createFromAcisFile(argv[1]);
#endif
  if(!pGeomModel)
    adaptUtil::Warning("No Geom Model Loaded!");

  // create and load serial curved mesh
  pMeshMesh = MS_newMesh(pGeomModel);
//  pMeshMesh = MS_newMesh(0);

  //AOMD_Util::Instance()->importSMS(argv[2], pMeshMesh);
  PM_load(pMeshMesh, argv[2]);
  MPI_Barrier(MPI_COMM_WORLD);
 
  M_verify(pMeshMesh);
 
  // create curveMesh object
  meshAdapt* pMAdaptObj = new meshAdapt(pMeshMesh, NULL, 2, 1); 
  pMAdaptObj->CMA_SetMyRank(iMyRank);

  pMAdaptObj->CMA()->CM_printNumEntities();
 
  std::vector<pRegion> InvalidRgnVec;
  InvalidRgnVec.clear();
  pMAdaptObj->CMA()->CM_CreateInvalidRgnVec(InvalidRgnVec, 0);
  int size = InvalidRgnVec.size();  
  cout<<"["<<iMyRank<<"]: Size of invalid region vector: "<<size<<endl;

  // partition the serial mesh
  if(iSize > 1){
    adaptUtil::Info("multiple processors, migration will be called");
    M_loadbalance(pMeshMesh, crvCB);
  }
  pMAdaptObj->CMA()->CM_SetRgnShapeThresh(0.0);
  pMAdaptObj->CMA()->CM_printNumEntities();
  M_writeSMS(pMeshMesh, "M_mesh_init.sms", 2);
  M_writeVTKFile(pMeshMesh, "test_in_curveMesh");

  double Min, Max, Ave;
  double UpperBound = 0.0;
  double LowerBound = 0.0;
  
  for(int It=0; It<atoi(argv[4]); It++){

    pMAdaptObj->CMA_CalcMinMaxAve(Min, Max, Ave);
    UpperBound = Max*0.8+Ave*0.2;
    LowerBound = Min;
    // process edges to be split
    pMAdaptObj->CMA()->CM_SetRgnShapeThresh(0.0);
    pMAdaptObj->CMA_CreateEdgeVecs(UpperBound, LowerBound);
    
/*   
    pPList elist = R_edges(rgn, 1);
    for(int i=0; i<6; i++){
      pEdge edge = (pEdge)PList_item(elist, i);
      pMAdaptObj->setAdaptLevel(edge, 0);
      double vcoords[2][3];
      double mpcoords[3], stcoords[3];
      for(int j=0; j<2; j++)
	V_coord(E_vertex(edge, j), vcoords[j]);
      if(E_numPoints(edge)){
	pPoint pt = E_point(edge, 0);
	mpcoords[0] = P_x(pt);
	cout<<mpcoords[0]<<endl;
	mpcoords[1] = P_y(pt);
	cout<<mpcoords[1]<<endl;
	mpcoords[2] = P_z(pt);
	cout<<mpcoords[2]<<endl;
	for(int k=0;k<3;k++){
	  stcoords[k]=0.5*(vcoords[0][k]+vcoords[1][k]);
	  cout<<stcoords[k]<<endl;
	}
	cout<<P_length(mpcoords, stcoords)<<endl;
	cout<<P_length(vcoords[0], vcoords[1])<<endl;
	if(P_length(mpcoords, stcoords)>=0.1*P_length(vcoords[0], vcoords[1])){
	  cout<<"("<<iMyRank<<"): Found very curved edge, tag it to split... "<<endl;
	  //pMAdaptObj->setAdaptLevel(edge, 1);
	}
  
      }
    }
*/
    pMAdaptObj->run(1,0,0);

    M_verify(pMeshMesh);

   

    pMAdaptObj->CMA_ShapeInfo();
    pMAdaptObj->CMA()->CM_printNumEntities();

    InvalidRgnVec.clear();
    pMAdaptObj->CMA()->CM_CreateInvalidRgnVec(InvalidRgnVec, 0);
    size = InvalidRgnVec.size();  
    cout<<"["<<iMyRank<<"]: Size of invalid region vector: "<<size<<endl;

    Debug_wait(iDebugCnt++);
    
    if(size){
      cout<<"Found invalid region(s), exit the refinement process! "<<endl;
      break;
    }
  }
  
  //pMAdaptObj->CMA_ShapeInfo();

  MPI_Barrier(MPI_COMM_WORLD);



  crShpInfo *csi = new crShpInfo;

  for(int i=0;i<size;i++){
    pRegion invalidRgn = InvalidRgnVec[i];
    CR_isValid(invalidRgn, csi);
    cout<<"csi->index: "<<csi->index;
    if(csi->index==-2)
      cout<<"    csi->qs: "<<csi->qs;
    if(isBdryRegion(invalidRgn))
      cout<<"    is Boundary Region";
    cout<<endl;
  }
  delete csi;
  //if(iSize > 1){
  //  adaptUtil::Info("multiple processors, migration will be called");
  //  M_loadbalance(pMeshMesh, crvCB);
  //}

  // check param coords
  adaptUtil::Info("Check Param Coords Before Writting Out Meshes...");
  pMAdaptObj->CMA_CheckVtxParamCoords(iMyRank);
  pMAdaptObj->CMA()->CM_printNumEntities();

  M_verify(pMeshMesh);
  // write out mesh in various formats
  char name[32];
  sprintf(name, "M_%s",argv[3]);
  M_writeVTKFile(pMeshMesh, "test_out_curveMesh");
  M_writeSMS(pMeshMesh, name, 2);
  sprintf(name, "PM_%s", argv[3]);
  PM_write(pMeshMesh, name);

  // verify part mesh 

  ParUtil::Instance()->Finalize();

  return 0;
		  
}


