#include "curveUtil.h"
#include "curveMesh.h"
#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "visUtil.h"
#include "PWLinearSField.h"
#include "fromMeshTools.h"
#include <stdlib.h>
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>
#ifdef MA_PARALLEL
#include "mpi.h"
#endif
#include "ParUtil.h"
#include "M_writeVTKFile.h"

#ifdef AOMD_
#else
#include "SimParasolidKrnl.h"
#endif

#include "templateUtil.h"
#include "modeler.h"
#ifdef PARASOLID
#include "modelerParasolid.h"
#include "ParasolidModel.h"
#endif
#ifdef ACIS
#include "AcisModel.h"
#endif
#ifdef AOMD_
#include "AOMD.h"
#include "mAOMD.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "MeshTools.h"
#ifdef MA_PARALLEL
#include "pmMeshAdapt.h"
#include "SF_MigrationCallbacks.h"
#include "pmZoltanCallbacks.h"
#endif
#endif

#define FILE "/users/xli/stop.check"

extern "C" int readLicenseFile(char *filename);
void uniformRefine(pMesh,meshAdapt &);

using std::cout;

int main(int argc, char* argv[])
{
  if(argc ==1){
    cout<<"[Usage:] ./main <Geometric model> <Curved PM_ mesh to be refined> \n\n\n";
    return 0;
  }
  
  // initialize
  
  AOMD::ParUtil::Instance()->init (argc,argv);
  int myrank = AOMD::ParUtil::Instance()->rank();
  int nproc;
  MPI_Comm_size(MPI_COMM_WORLD, &nproc);
  MS_init();
  
  // load geometric model

  pGModel model;
#ifdef PARASOLID
  model = GM_createFromParasolidFile(argv[1]);
  model->stats();
#endif
#ifdef ACIS
  model = new AcisModel(argv[1],0);
  model->stats();
#endif
  
  curveMigrateCB crvCB;
  pMesh mesh=MS_newMesh(model);
  double t1=AOMD::ParUtil::Instance()->wTime(); 

  AOMD_Util::Instance()->importSMS(argv[2], mesh);
 
  curveMesh *cvmh = new curveMesh(mesh, 1, 0);
 
  cvmh->CrvMesh_printNumEntities();
 
  if(nproc > 1){
    cout<<"[Info]: multiple processors, migration will be called"<<endl;
 
    M_loadbalance(mesh, crvCB);
    
   }
  cvmh->CrvMesh_printNumEntities();
  MPI_Barrier(MPI_COMM_WORLD);
  M_writeSMS(mesh,"mesh_parted_curved_FMDB_ind.sms",2);
  M_writeVTKFile(mesh, "mesh_in_curveMesh");
  meshAdapt rdr(mesh,0,1,1);  // snap off; last parameter should be set to 1 to enable template refinement; 

  cout<<"("<<P_pid()<<") Start first round of refinement..."<<endl;
  uniformRefine(mesh, rdr);

  M_writeVTKFile(mesh, "after_first_round_refinement");
  M_writeSMS(mesh, "M_after_first_round_FMDB.sms", 2);
  M_printNumEntities(mesh);

  M_verify(mesh);

  cout<<"("<<P_pid()<<") Start second round of refinement..."<<endl;
  uniformRefine(mesh, rdr);
  M_printNumEntities(mesh);
 
  myTimer tt;

  double t2=AOMD::ParUtil::Instance()->wTime();
  
//   if (P_pid()==0)
//    { printf("Total clock time: %f\n",tt.elapsedCPU());
   
//    }  
  
  
  // write out refined curved partitioned mesh
  M_writeSMS(mesh,"mesh_refined_curved_FMDB_ind.sms",2);
  PM_write(mesh, "mesh_refined_curved_FMDB.sms");
  M_writeVTKFile(mesh,"mesh_refined_curved");
  
  M_printNumEntities(mesh);
 
  if (P_pid()==0){ 
    cout<<"\n# partitions = "<<P_size()<<"\n";
    cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
  }  

  M_verify(mesh);
  MS_exit();    
  
#ifdef MA_PARALLEL
  AOMD::ParUtil::Instance()->Finalize();
#endif
  
  return 1;
}

void uniformRefine(pMesh pm, meshAdapt &pAdapt)
{
  EIter eit=M_edgeIter(pm);
  pEdge edge;
  while( edge=EIter_next(eit) ) {
    //if(EN_owner(edge)==P_pid()){
      pAdapt.setAdaptLevel(edge,1);
      //break;
    //}
  }
  EIter_delete(eit);

  pAdapt.run(1,0,0);

  return;
}
