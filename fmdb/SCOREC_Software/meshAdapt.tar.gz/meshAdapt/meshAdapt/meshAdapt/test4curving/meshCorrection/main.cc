#include "MeshAdapt.h"
#include "curveMesh.h"
#include "curveUtil.h"
#include "AdaptUtil.h"
#include "visUtil.h"
#include "PWLinearSField.h"
#include "fromMeshTools.h"
#include <stdlib.h>
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>

#include "ParUtil.h"
#include "slacUtil.h"

#ifdef AOMD_
#include "AOMD.h"
#include "mAOMD.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "MeshTools.h"
#include "mMesh.h"
#ifdef MA_PARALLEL
#include "SF_MigrationCallbacks.h"
#include "mpi.h"
#endif
#endif

#define FILE "/users/xli/stop.check"
using namespace AOMD;
using namespace adaptUtil;
using std::cout;
using std::endl;

int main(int argc, char* argv[])
{  

  if(argc == 1){
    cout<<"Usage:   <exec> \n         <1. Input serial curved mesh to be loaded> \n         <2. Shape quality threshold (lower bound)> \n         <3. Output fixed serial curved mesh>"<<endl;
    exit(1);
  }
  
  pMesh mesh, newmesh;
  int option;
 
  ParUtil::Instance()->init(argc,argv);

  int iMyRank = ParUtil::Instance()->rank();
  int iSize = ParUtil::Instance()->size();

//  MS_init();
  
  mesh = MS_newMesh(0);
//  mesh->setMeshModFunctors(1);
  double t1=AOMD::ParUtil::Instance()->wTime();
  if(argc == 6){
    if(iMyRank==0)
    importNCDF(argv[1], mesh, atoi(argv[4]));
    AOMD_Util::Instance()->exportSmsFile(argv[2], mesh);
    cout<<"DEBUG: importing and exporting"<<endl;
  }
  else{
    //M_load_URR(mesh, argv[1], "usr.mrm");
    AOMD_Util::Instance()->importSMS(argv[1], mesh);
  }
  double t2=AOMD::ParUtil::Instance()->wTime();
  
  cout<<"Time Usage for Loading the NCDF Mesh:    [" <<t2-t1<<"(sec)]"<<endl;
  curveMesh *cmsh = new curveMesh(mesh, 1, 0);
  
  t1=AOMD::ParUtil::Instance()->wTime();
  FIter fiter = M_faceIter(mesh);
  pFace face;
  pEdge edge;
  
  if(iSize>1){
    curveMigrateCB crvCB;
    cout<<"[Info]:("<<iMyRank<<"): multiple processors, migration will be called"<<endl;

    cout<<"[Info]:("<<iMyRank<<"): Start load balancing... "<<endl;
    M_loadbalance(mesh, crvCB);
    cout<<"[Info]: Setting points from coords... "<<endl;
  }


  while(face = FIter_next(fiter)) {
    if(F_whatInType(face) == 2) {
      for(int i=0; i<3; i++) {
        edge = F_edge(face, i);
        cmsh->fix_entity((pEntity)edge);
      }
    } 
  }
  //  M_checkCurvedRegionShape(mesh, "cbefore.shape");
  //M_checkSTRegionShape(mesh, "sbefore.shape");
  
  FIter_delete(fiter);
  t1=AOMD::ParUtil::Instance()->wTime();
  if(argc == 6){
    cmsh->set_desired_shape(atof(argv[5]));
  }
  else
    cmsh->set_desired_shape(atof(argv[2]));
  cmsh->run();
  t2=AOMD::ParUtil::Instance()->wTime();
  cout<<"Time Usagefor Correcting Invalid Regions:[" <<t2-t1<<"(sec)]"<<endl;
  
  //  M_checkCurvedRegionShape(mesh, "cAfter.shape");
  //  M_checkSTRegionShape(mesh, "sAfter.shape");
  
  t1=AOMD::ParUtil::Instance()->wTime();
  if(argc == 6) {
    AOMD_Util::Instance()->exportNCDF(mesh, 0, argv[3], 0);
    //export new mesh 
  }
  else{
    AOMD_Util::Instance()->exportSmsFile(argv[3], mesh);
    //AOMD_Util::Instance()->exportNCDF(mesh, 0, argv[2], 0);
  }
  M_verify(mesh);
  t2=AOMD::ParUtil::Instance()->wTime();
  cout<<"Time Usage for Exporting into NCDF:      [" <<t2-t1<<"(sec)]"<<endl;
  AOMD_Util::Instance()->exportSmsFile("tmp.sms", mesh);
  delete cmsh;
  
  ParUtil::Instance()->Finalize();
  return 0;
  
}
