#include "mpi.h"
#include "pnetcdf.h"
#include <stdio.h>

int main(int argc, char **argv)
{
  int ncfile, ret, count, myrank;
  char buf[13] = "Hello World\n";
  char name[32]; 
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  sprintf(name, "myfile.%d.nc", myrank);
  ret = ncmpi_create(MPI_COMM_WORLD, name, NC_CLOBBER, MPI_INFO_NULL, &ncfile);
  if(ret!=NC_NOERR) return 1;
  ret = ncmpi_put_att_text(ncfile, NC_GLOBAL, "string", 13, buf);
  if(ret!=NC_NOERR) return 1;
  ncmpi_enddef(ncfile);

  ncmpi_close(ncfile);
  MPI_Finalize();
  return 0;
}
