#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <math.h>
#include <fstream>
#include <iostream>

#include "MA.h"
#include "M_writeVTKFile.h"

#ifdef PARASOLID
#include "ParasolidModel.h"
#endif
#ifdef ACIS
#include "AcisModel.h"
#endif

#ifdef MA_PARALLEL
#include "ParUtil.h"
#include "mpi.h"
#endif

using std::cout;
using std::endl;

int main(int argc, char* argv[])
{  

  if(argc==1)
    {
      cout<<"\n\nUsage: ./main \n <1. geometric model> \n <2. serial mesh to be loaded> \n <3. meshfile to be written out by PM_write> \n <4. meshfile to be written out by M_writeSMS> \n <5. No. of Iters>\n\n"<<endl;
      exit(1);
    }
  ParUtil::Instance()->init(argc,argv);
  
  pGModel pGeomModel = 0;
  pMesh pMeshMesh;

  int iMyRank = ParUtil::Instance()->rank();
  int iSize = ParUtil::Instance()->size();

  if(iMyRank==0)
  {
    cout<<"*********************************************"<<endl;
    cout<<"****** Stage 1: Import Serial SMS mesh ******"<<endl;
    cout<<"*********************************************"<<endl;
  }

#ifdef PARASOLID
  pGeomModel = GM_createFromParasolidFile(argv[1]);
#endif
#ifdef ACIS
  pGeomModel = GM_createFromAcisFile(argv[1]);
#endif

  if(!pGeomModel&&iMyRank==0)
  {
    cout<<"No Geom Model Loaded"<<endl;
  }
  pMeshMesh = MS_newMesh(pGeomModel);

  cout<<"[Info]:("<<iMyRank<<"): Start loading mesh ..."<<endl;
  AOMD_Util::Instance()->importSMS(argv[2], pMeshMesh);
  MPI_Barrier(MPI_COMM_WORLD);
  cout<<"[Info]:("<<iMyRank<<"): Finished loading mesh ###"<<endl;
  EIter eiter=M_edgeIter(pMeshMesh);
  pEdge edge;
  int HONcount=0;
  int BDYcount=0;
  int RGNcount=0;
  while(edge=EIter_next(eiter)){
    if(E_whatInType(edge)!=3){
      BDYcount++;
    }
    else
      RGNcount++;
    if(E_numPoints(edge))
      HONcount++;
  }
  cout<<"[Info]:("<<iMyRank<<"): Total # of edge HON: "<<HONcount<<"Total # of BDY edges: "<<BDYcount<<endl;

  if(iMyRank==0)
  {
    cout<<"*******************************************"<<endl;
    cout<<"****** Stage 2: Uncurve Invalid mesh ******"<<endl;
    cout<<"*******************************************"<<endl;
  }


  meshAdapt *pMAdaptObj = new meshAdapt(pMeshMesh, NULL, 2, 1);
  pMAdaptObj->CMA()->CM_printNumEntities();
  for(int i=0;i<atoi(argv[5]);i++){
    if(iMyRank==0)
      cout<<"**** Iteration No."<<i<<" ****"<<endl;
    cout<<"[Info]:("<<iMyRank<<"): Start uncurving invalid regions... "<<endl;
    pMAdaptObj->CMA()->CMA_UncurveInvalidRgns();

    MPI_Barrier(MPI_COMM_WORLD);
    cout<<"[Info]:("<<iMyRank<<"): Finished uncurving invalid mesh ###"<<endl;
  }
  //if(iSize > 1){

    if(iMyRank==0)
    {
      cout<<"************************************************"<<endl;
      cout<<"****** Stage 3: Partition the serial mesh ******"<<endl;
      cout<<"************************************************"<<endl;
    }

    curveMigrateCB crvCB;
    cout<<"[Info]:("<<iMyRank<<"): multiple processors, migration will be called"<<endl;
    
    cout<<"[Info]:("<<iMyRank<<"): Start load balancing... "<<endl;
    M_loadbalance(pMeshMesh, crvCB);
    cout<<"[Info]: Setting points from coords... "<<endl;
    
  //}

  cout<<"[Info]:("<<iMyRank<<"): # of edges: "<<M_numEdges(pMeshMesh)<<endl;

  MPI_Barrier(MPI_COMM_WORLD);

  pMAdaptObj->CMA()->CM_printNumEntities();

  if(iMyRank==0)
  {
    cout<<"***************************************************"<<endl;
    cout<<"****** Stage 4: Uncurve the partitioned mesh ******"<<endl;
    cout<<"***************************************************"<<endl;
  }

  for(int i=0;i<atoi(argv[5]);i++){
    if(iMyRank==0)
      cout<<"**** Iteration No."<<i<<" ****"<<endl;
    cout<<"[Info]:("<<iMyRank<<"): Start uncurving invalid regions... "<<endl;

    pMAdaptObj->CMA()->CMA_UncurveInvalidRgns();
    MPI_Barrier(MPI_COMM_WORLD);
    cout<<"[Info]:("<<iMyRank<<"): Finished uncurving invalid mesh ###"<<endl;

  }
 
  if(iMyRank==0)
  {
    cout<<"*************************************************"<<endl;
    cout<<"****** Stage 5: Write out partitioned mesh ******"<<endl;
    cout<<"*************************************************"<<endl;
  }
  
  pMAdaptObj->CMA_CheckVtxParamCoords(iMyRank);

  MPI_Barrier(MPI_COMM_WORLD);
  cout<<"Start M_writeVTKFile..."<<endl;
  M_writeVTKFile(pMeshMesh, "curved_mesh_out");
  cout<<"Start PM_write..."<<endl;
  PM_write(pMeshMesh, argv[3]);
 
  MPI_Barrier(MPI_COMM_WORLD);
  cout<<"Start M_writeSMS... "<<endl;
  M_writeSMS(pMeshMesh, argv[4], 2);
  cout<<"File I/O finished."<<endl;
  MPI_Barrier(MPI_COMM_WORLD);
  ParUtil::Instance()->Finalize();
  return 0;
		  
}


