#include "SplitCollapsMod.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "fromMeshTools.h"
#include "PList.h"
#include "FMDB_cint.h"
#include "BLUtil.h"
#include <stdio.h>
#include <iostream>
using std::cout;
using std::endl;

#ifdef CURVE
#include "curveUtil.h"
#include "curveMesh.h"
using namespace curveUtil;
#endif/*CURVE*/

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif

/*
  History: 10/31/01 Created  X. Li
*/

int EsplitClpsMod::topoCheck()
{
  if( !F_inClosure(goneFace,(pEntity)splitEdge) )
    return 0;
  vt=F_edOpVt(goneFace,splitEdge);

  if (!EN_okTo(DELETE,(pEntity)splitEdge))
    return 0;
#ifdef CURVE
  if (!EN_okTo(DELETE,(pEntity)vt))
    return 0;
#endif/*CURVE*/
  // --- osahni
  // check constrain on 'vt' only if 'vt' is likely to be deleted
  // when new vertex will be retained (i.e., switchOrder is 0)
  if( E_whatIn(splitEdge)!=F_whatIn(goneFace) )
    if (!EN_okTo(DELETE,(pEntity)vt))
      return 0;

#ifdef MA_PARALLEL
  if( EN_onCB((pEntity)splitEdge) || EN_onCB((pEntity)vt) )
    return 0;
#endif

  /// Can't handle cases involving any topology other than tets
  int iValidRgn = 1;
  pVertex pVertexVtx[3] = {E_vertex(splitEdge, 0), E_vertex(splitEdge, 1), vertMv};
  pRegion pRegionRgn;
  int iVtxNum = 2;
  if (vertMv)
    iVtxNum = 3;
  for (int iVtx = 0; iVtx < iVtxNum; ++iVtx)
  {
    pPList vregs = V_regions(pVertexVtx[iVtx]);
    for (int iRgn = 0; iRgn < PList_size(vregs); ++iRgn)
    {
      pRegionRgn = (pRegion)PList_item(vregs, iRgn);
      if (pRegionRgn->getType() == PYRAMID)
      {
        iValidRgn = 0;
        PList_delete(vregs);
        break;
      }
    }
    if (iValidRgn)
      PList_delete(vregs);
    else
      break;
  }
  if (!iValidRgn)
    return 0;

  return checkDimRection();
}

int EsplitClpsMod::checkDimRection() 
{
  pGEntity gent=F_whatIn(goneFace); 

  // one of the classifications must be the same as the face
  if( V_whatIn(vt)!=gent && E_whatIn(splitEdge)!=gent )
    return 0;

  // if not snap, classification of "vt" must be equal or 
  // less than that of "splitEdge"
  if( !snap && V_whatInType(vt) > E_whatInType(splitEdge) )
    return 0;

  // "goneFace" is on Gregion, no further check needed
  if( F_whatInType(goneFace)==Gregion )
    return 1;

  // consider the cavity defined by the two regions adjacent to 
  // "goneFace". Figure out all new regions created by the split.
  // if three faces of a new region are on model face, this 
  //      compound operation will lead to dimension reduction;
  // if two faces of a new region are on model face, need to find
  //      the common edge of the two boundary faces, the compound
  //      operation will cause dimension reduction in case the
  //      common edge is opposite to "splitEdge"
  // otherwise, no dimension reduction
  //                  -li   12/3/02
  pRegion goneRgn;
  pFace face, faces[3], faces_2[2];
  pEdge edge;
  int numBdryFc;
  int i,j,k,id[3];
  for( i=0; i<2; i++ ) {
    goneRgn=F_region(goneFace,i);
    if( !goneRgn )
      continue;
    // classify the four faces 
    faces[0]=goneFace;
    k=0;
    for( j=0; j<4; j++ ) {
      face=R_face(goneRgn,j);
      if( face==goneFace )
	continue;
      if( F_inClosure(face,(pEntity)splitEdge) )
	{ faces[1]=face; continue; }
      faces_2[k++]=face;
    }

    // figure out the number of boundary faces and check
    for( j=0; j<2; j++ ) {
      numBdryFc=0;
      faces[2]=faces_2[j];
      for( k=0; k<3; k++ ) 
	if( F_whatInType(faces[k])==Gface )
	  { id[numBdryFc]=k; numBdryFc++; }
      
      if( numBdryFc==3 )
	return 0;
      if( numBdryFc==2 ) {
	edge=adaptUtil::CommonEdge(faces[id[0]],faces[id[1]]);
	if( !edge )
	  printf("Error: invalid mesh detected (EsplitClpsMod::topoCheck)\n");
	if( edge==R_gtOppEdg(goneRgn,splitEdge) )
	  return 0;
      }
    }
  }
  
  return 1;
}

int EsplitClpsMod::geomCheck()
{
  pPList eregs;
  pPList rvlist;
  pRegion rgn, goneRgn[2];
  pVertex vertex,ev;
  void *iter;
  void *temp = 0 ;
  double xyz[3],rg[4][3] ; 
  double shape_1;
  double ori[3];
  int i,j;
  pMSize pmt[4];

  double worstShape =BIG_NUMBER;

  // check the pre-vertex motion
  if( vertMv ) {
    V_coord(vertMv,ori);
    adaptUtil::move_vertex(vertMv,target);
    
    pPList vRgns;
    if(!EN_isBLEntity(vertMv))
      vRgns = V_regions(vertMv);
    else {
      if(!V_atBLInterface(vertMv)) {
        cout<<"\nError in edgeCollapsMod::geomCheck()..."<<endl;
        cout<<"vertMv is BL entity but not at BL interface"<<endl;
        exit(0);
      }

      vRgns = PList_new();

      vector<pRegion> Vrgns;
      V_nonBLRegions(vertMv, Vrgns);
      for (int itReg = 0; itReg < Vrgns.size(); ++itReg)
      {
        PList_append(vRgns, Vrgns[itReg]);
      }

      double f_xyz[3][3], v01[3], v02[3], nor[3];;
      pMSize f_pmt[3];
      pFace face;
      vector<pFace> vLyrFaces;
      V_layerFaces(vertMv, vLyrFaces);
      pPList fverts;
      int numFaces = vLyrFaces.size();
      for(int iFace=0; iFace<numFaces; iFace++) {
        face = vLyrFaces[iFace];

        fverts = F_vertices(face,1);

        // compute the original normal
        temp = 0; i = 0;
        while (vertex = (pVertex)PList_next(fverts, &temp)) {
          if(vertex==vertMv) {
            f_xyz[i][0]=ori[0]; f_xyz[i][1]=ori[1]; f_xyz[i++][2]=ori[2];
          }
          else
            V_coord(vertex,f_xyz[i++]);
        }
        diffVt(f_xyz[1],f_xyz[0],v01);
        diffVt(f_xyz[2],f_xyz[0],v02);
        crossProd(v01,v02,nor);

        temp = 0; i = 0;
        while (vertex = (pVertex)PList_next(fverts, &temp)) {
          f_pmt[i]=pSizeField->getSize(vertex);
          V_coord(vertex,f_xyz[i++]);
        }
        PList_delete(fverts);

        // check validity and calculate shape
        if(!shpMeasure->XYZ_shape(f_xyz, f_pmt, nor, &shape_1)) {
          PList_delete(vRgns);
          adaptUtil::move_vertex(vertMv,ori);
          return 0;
        }
      }
    }

    temp=0;
    while( rgn = (pRegion)PList_next(vRgns,&temp) ) {
      if( R_inClosure(rgn,(pEntity)splitEdge) ) 
	continue;
      if( ! shpMeasure->R_shape(rgn,&shape_1) ) {
	PList_delete(vRgns);
	adaptUtil::move_vertex(vertMv,ori);
	return 0;
      }
      if( worstShape > shape_1 ) 
	worstShape=shape_1;
    }
    PList_delete(vRgns);
  }

  // initialize
  V_coord(vt,xyz);
  goneRgn[0]=F_region(goneFace,0);
  goneRgn[1]=F_region(goneFace,1);

  // check the result from split operation
  eregs=E_regions(splitEdge);
#ifdef CURVE
  if(quadratic == false){
#endif /*CURVE*/
  temp=0;
  while ( rgn = (pRegion)PList_next(eregs,&temp) ) {

    // ignore the two region to be eliminated
    if( rgn==goneRgn[0] ) continue;
    if( rgn==goneRgn[1] ) continue;

    rvlist=R_vertices(rgn,1);

    // evaluate the two regions created by splitting 'rgn'
    for( i=0; i<2; i++ ) {
      ev=E_vertex(splitEdge,i);
      iter=0; j=0;
      while( (vertex=(pVertex)PList_next(rvlist,&iter)) ) {
	if( vertex==ev )
	  {
	    pmt[j]=pSizeField->getSize(vt);
	    rg[j][0]=xyz[0]; rg[j][1]=xyz[1]; rg[j++][2]=xyz[2];
	  }
	else 
	  {
	    pmt[j]=pSizeField->getSize(vertex);
	    V_coord(vertex,rg[j++]);
	  }
      }
      // check validity
      if( ! shpMeasure->XYZ_shape(rg,pmt,&shape_1) ) 
	{
	  PList_delete (eregs);
	  PList_delete (rvlist);
	  if( vertMv ) 
	    adaptUtil::move_vertex(vertMv,ori);
	  return 0;
	}
      // determine the worst shape
      if( worstShape > shape_1 )
	worstShape=shape_1;
    }
    PList_delete(rvlist);
  }
  PList_delete(eregs);
  
#ifdef CURVE
  }
  else if (quadratic == true) {
    // for quadratic tet meshes
    crShpInfo csi;
    
    for (temp=0; (rgn =(pRegion)PList_next(eregs,&temp)); ) {
      // ignore the two regions to be removed
      if(rgn==goneRgn[0] || rgn==goneRgn[1]) 
	continue;
      
      rvlist=R_vertices(rgn,1);
      
      // evaluate the two regions created by breaking the region
      // with the splitEdge split at the position of vt (xyz)
      for( i=0; i<2; i++ ) {
	double rg[10][3];
	pVertex v[4];
	
	// get the 4 corner points of the new region
	ev=E_vertex(splitEdge,i);
	for (iter=0, j=0; (vertex=(pVertex)PList_next(rvlist,&iter)); j++) {
	  if(vertex==ev) {
	    //pmt[j]=pSizeField->getSize(vt);
	    rg[j][0]=xyz[0]; rg[j][1]=xyz[1]; rg[j][2]=xyz[2];
	    v[j] =vt;
	  }
	  else {
	    // pmt[j]=pSizeField->getSize(vertex);
	    V_coord(vertex,rg[j]);
	    v[j] =vertex;
	  }
	}
	
	// get the 6 mid-side nodes of the new region
	int j0, j1, ii;
	for (int ipoint=0; ipoint<6; ipoint++) {
	  switch (ipoint) {
	  case 0:
	    j0 =0; j1 =1;
	    break;
	  case 1:
	    j0 =1; j1 =2;
	    break;
	  case 2:
	    j0 =2; j1 =0;
	    break;
	  case 3:
	    j0 =0; j1 =3;
	    break;
	  case 4:
	    j0 =1; j1 =3;
	    break;
	  case 5:
	    j0 =2; j1 =3;
	    break;
	  }
	  
	  pPoint pt;
	  // for the existing edges, use their mid-side nodes
	  pEdge e=E_exists(v[j0], v[j1]);
	  if(!e) {
	    rg[j][0] = 0.5*(rg[j0][0]+rg[j1][0]);
	    rg[j][1] = 0.5*(rg[j0][1]+rg[j1][1]);
	    rg[j++][2] = 0.5*(rg[j0][2]+rg[j1][2]);
	    //cout<<"edge does not exists -- SplitCollapse"<<endl;
	  }
	  else
	    E_bezierCtrlPt(e, rg[j++]);
	} // for (ipoint=0; ipoint<6; ipoint++)
	
	
	
	// check quality of the new region
	if( !HO_XYZ_isValid(rg, &csi)) {
	  PList_delete (eregs);
	  PList_delete (rvlist);
	  if( vertMv ) 
	    adaptUtil::move_vertex(vertMv,ori);
	  return 0;
	}
	// determine the worst shape
	if( worstShape > csi.shape )
	  worstShape=csi.shape;
      } // for (i=0; i<2; i++)
      PList_delete(rvlist);
    } // for (temp=0...
    PList_delete(eregs);
  }
#endif/*CURVE*/
  

  // check geometric similarity
  //  printf("WARNING: geometric similarity check NOT implemented (SplitCollapsMod.cc)\n");

  if( vertMv ) 
    adaptUtil::move_vertex(vertMv,ori);

  // Note that 2D evaluation of splitCollapse is not implemented
  if( F_region(goneFace,0) || F_region(goneFace,1) ) 
    if (worstShape==BIG_NUMBER)  
      return 0; 
  
  results->setWorstShape(worstShape);  
  return 1;
}

int EsplitClpsMod::sizeCheck()
{
  pFace face;
  pVertex vertex;
  double ori[3];
  double min, max;
  double tmp;
  int i;

  if( vertMv ) {
    V_coord(vertMv,ori);
    adaptUtil::move_vertex(vertMv,target);
  }  

  min=BIG_NUMBER;
  max=0.0;
  for( i=0; i<E_numFaces(splitEdge); i++ ) {
    face=E_face(splitEdge,i);
    if( face==goneFace ) 
      continue;
    vertex=F_edOpVt(face,splitEdge);
    tmp = pSizeField->lengthSq(vt,vertex);

    if( tmp>max ) max=tmp;
    if( tmp<min ) min=tmp;
  }

  results->setMaxSize(max);
  results->setMinSize(min);
  if( vertMv )  
    adaptUtil::move_vertex(vertMv,ori);
  return 1;
}


void EsplitClpsMod::getAffectedRgns(pPList *l)
{
  *l=E_regions(splitEdge);
  return;
}


int EsplitClpsMod::apply(pPList *newRegions)
{
  pEdge edgeDel;
  pVertex vd, vr;
  pVertex newVt;
  double parm[3] ={0., 0., 0.};
  double xyz[3], Exyz[2][3];
  int i, switchOrder=0;
  
  pPList newRegs;
  
  if( E_whatIn(splitEdge)==F_whatIn(goneFace) )
    switchOrder=1;    // delete the new vertex

// #ifdef DEBUG
//   if( !switchOrder )
//     printf("delete an existing vertex\n");
// #endif

  if( vertMv ) {
    adaptUtil::move_vertex(vertMv,target,CB_move,userData_CB_move);
#ifdef DEBUG
    pRegion region;
    pPList mvRgns=V_regions(vertMv);
    pPList edRgns=E_regions(splitEdge);
    void *iter=0;
    while( region=(pRegion)PList_next(mvRgns,&iter) ) {
      if( ! PList_inList(edRgns,region) ) {
	if( R_Volume2(region) < 1.e-14 )
	  printf("WARNING: region %p: R_volume=%f (splitCollapsMod::apply())\n",
		 region,R_volume(region));
      }
    }
    PList_delete(edRgns);
    PList_delete(mvRgns);
#endif
  }

  // perform splits and set mesh size
  V_coord(E_vertex(splitEdge,0),Exyz[0]);
  V_coord(E_vertex(splitEdge,1),Exyz[1]);
  for(i= 0; i< 3; i++) 
    xyz[i]=0.5*(Exyz[0][i]+Exyz[1][i]);
  
  // NOTE: not work for non-parameter model
  if( model_type==PARAM && E_whatInType(splitEdge)!=Tregion ) {
    double tmpxyz[3];
    if( !adaptUtil::V_checkPar(E_vertex(splitEdge,0), 0) ||
	!adaptUtil::V_checkPar(E_vertex(splitEdge,1), 0) )
      adaptUtil::Warning("may introduce infinite recursion (EsplitClpsMod::apply)");
    if (!templatesUtil::middlePoint(splitEdge,0.5,tmpxyz,parm)) 
      printf("WARNING: maybe a bad target location (EsplitClpsMod::apply)\n");
  }

  newVt=templatesUtil::Edge_split (mesh, splitEdge, xyz, parm, 
				   function_CB,userData_CB,&newRegs);
  PList_delete(newRegs);
  
  // determine the edge collapse
  edgeDel=E_exists(vt,newVt);
  V_coord(vt,xyz);
#ifdef DEBUG
  if( !edgeDel )
    cout<<"Error: SplitCollapsMod::apply()"<<endl;
#endif
  if( switchOrder ) {
    vd=newVt;
    vr=vt;
  } else {
#ifdef DEBUG
    printf("INFO: an existing vertex %p is deleted (SplitCollapsMod::apply)\n",vt);
#endif
    vd=vt;
    vr=newVt;
    vt=vr;     // this is needed since getVertex() may return this information 
    // Be very careful here, it assume the attached pointer is not deleted in collapsing 
    pSizeField->setSize((pEntity)newVt, pSizeField->getSize(vd));
  }

  // move the retained new vertex and perform collapse
  if(!switchOrder)
    adaptUtil::move_vertex(vr,xyz,CB_move,userData_CB_move);

  if( ! templatesUtil::Edge_colaps(mesh,edgeDel,vd,vr,function_CB,userData_CB,newRegions) )
    printf("Error: edge collapsing failed (SplitCollapsMod::apply)");

#ifdef DEBUG
  pRegion region1;
  void *iter1=0;
  pPList vrRgns=V_regions(vr);
  while( region1=(pRegion)PList_next(vrRgns,&iter1) ) {
    if( R_Volume2(region1) < 1.e-14 )
      printf("WARNING: region %p: R_volume=%f (SPLTCLPSMod::apply())\n",
	     region1,R_Volume2(region1));
  }
  PList_delete(vrRgns);
#endif

  return 1;
}


int EsplitClpsMod::apply()
{
  pPList newRegions;
  int flag=apply(&newRegions);
  PList_delete(newRegions);
  return flag;
}

