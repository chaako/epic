#ifndef _H_FaceSwapMod
#define _H_FaceSwapMod

#include "LocMeshMod.h"
#ifdef CURVE
#include "Fswap.h"
//extern "C" F_SwapConfig fsc;
extern F_SwapConfig fsc;
#endif
class faceSwapMod: public locMeshMod
{
 public:
  faceSwapMod(const faceSwapMod &);
  faceSwapMod(pMesh, pSField, MeanRatio *, evalResults *);
  faceSwapMod(pMesh, pSField, MeanRatio *, evalResults *, pVertex, double *);
  ~faceSwapMod() { }

  /* the common local modification interface */
  virtual int topoCheck();
  virtual int geomCheck();
  virtual int sizeCheck();
  virtual void getAffectedRgns(pPList *);
  virtual int apply();
  virtual int apply(pPList *);
  virtual modType type() { return FSWAP; }
  
  /* specific member functions for face swap */
  void  setSwapFace(pFace f) { face=f; results->reset(); }
  pFace getSwapFace() { return face; }
  int   getCfg() { return conf; }
#ifdef CURVE
  void setFSC(F_SwapConfig  select_fsc) {fsc = select_fsc;}
#endif
 private:
  pFace face;          // face to be swapped
  int conf;            // TWO2TWO, TRI2TWO or TWO2TRI (set after geomCheck())
  
  /* internal data */
  pEdge edgeDel;       // the edge to be removed if TRI2TWO; it is NULL if TWO2TRI
};


inline faceSwapMod::faceSwapMod(const faceSwapMod &x):
  locMeshMod(x.mesh, x.pSizeField, x.shpMeasure, x.results) 
{
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;    
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;
  CB_move=x.CB_move;
  userData_CB_move=x.userData_CB_move;

  face=x.face;
  vertMv=x.vertMv;
  target[0]=x.target[0];
  target[1]=x.target[1];
  target[2]=x.target[2];
#ifdef CURVE
  quadratic=x.quadratic;
#endif
}

inline faceSwapMod::faceSwapMod(pMesh p, pSField mf, MeanRatio *m, 
				evalResults *r):
  locMeshMod(p,mf,m,r), face(0) 
{
#ifdef CURVE
  quadratic=false;
#endif
}

inline faceSwapMod::faceSwapMod(pMesh p, pSField mf, MeanRatio *m,
				evalResults *r, pVertex v, double *t):
  locMeshMod(p,mf,m,r), face(0)
{
  setVertMotion(v, t);
#ifdef CURVE
  quadratic=false;
#endif
}

#endif
