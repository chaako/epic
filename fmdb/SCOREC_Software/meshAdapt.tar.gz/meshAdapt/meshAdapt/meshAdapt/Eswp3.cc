/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Optimization
  Author(s) : Pascal Frey
  Creation  : Jan., 95
  Modifi.   : 
  Function  :
    templates for possible swap configurations
-------------------------------------------------------------------------*/
#include "Eswap.h"

/* Templates for the possible swap configarations */
void E_swp3_3(SwapConfig *sc)
{
  static int trgl[][3] = { 0,1,2 } ;
  static int trgul[][5] = { 0,-1,-1,-1,-1 } ;

  sc->nbr_triangles = 1 ;
  sc->nbr_triangles_2 = 1 ;
  sc->nbr_trianguls = 1 ;
  sc->triangles = trgl ;
  sc->trianguls = trgul ;
}

void E_swp3_4(SwapConfig *sc)
{
  static int trgl[][3] =
    { 0,1,2, 0,2,3, 0,1,3, 1,2,3 } ;
  static int trgul[][5] = 
    { 0,1,-1,-1,-1, 2,3,-1,-1,-1 } ;

  sc->nbr_triangles = 4 ;
  sc->nbr_triangles_2 = 2 ; 
  sc->nbr_trianguls = 2 ; 
  sc->triangles = trgl ;
  sc->trianguls = trgul ;
}


void E_swp3_5(SwapConfig *sc)
{
  static int trgl[][3] = 
    { 0,1,2, 0,2,3, 0,3,4, 0,1,4, 1,3,4, 1,2,3, 2,3,4, 0,2,4, 0,1,3, 1,2,4 } ;
  static int trgul[][5] =
    { 0,1,2,-1,-1, 3,4,5,-1,-1, 0,6,7,-1,-1, 2,5,8,-1,-1, 3,6,9,-1,-1 } ;

  sc->nbr_triangles = 10 ;
  sc->nbr_triangles_2 = 3 ;
  sc->nbr_trianguls = 5 ;
  sc->triangles = trgl ;
  sc->trianguls = trgul ; 
}

void E_swp3_6(SwapConfig *sc)
{
  static int trgl[][3] = 
    { 0,1,2, 0,2,3, 0,3,4, 0,4,5, 0,2,5, 2,4,5, 2,3,4, 0,3,5,
      3,4,5, 0,2,4, 2,3,5, 1,2,3, 0,1,3, 0,1,5, 1,4,5, 1,3,4,
      0,1,4, 1,3,5, 1,2,4, 1,2,5 } ;
  static int trgul[][5] = 
    { 0,1,2,3,-1, 0,4,5,6,-1, 0,1,7,8,-1, 0,3,6,9,-1, 0,4,8,10,-1,
      2,3,11,12,-1, 11,13,14,15,-1, 7,8,11,12,-1, 3,11,15,16,-1,
      8,11,13,17,-1, 6,13,14,18,-1, 3,6,16,18,-1, 5,6,13,19,-1, 
      8,10,13,19,-1 } ;

  sc->nbr_triangles = 20 ; 
  sc->nbr_triangles_2 = 4 ; 
  sc->nbr_trianguls = 14 ; 
  sc->triangles = trgl ; 
  sc->trianguls = trgul ;
}

void E_swp3_7(SwapConfig *sc)
{
  static int trgl[][3] = 
    { 0,1,2, 0,2,3, 0,3,4, 0,4,5, 0,5,6, 0,3,6, 3,5,6, 3,4,5, 0,4,6,
      4,5,6, 0,3,5, 3,4,6, 0,2,4, 2,3,4, 0,2,6, 2,5,6, 2,4,5, 0,2,5,
      2,4,6, 2,3,5, 2,3,6, 0,1,3, 1,2,3, 0,1,4, 1,3,4, 0,1,6, 1,5,6,
      1,4,5, 0,1,5, 1,4,6, 1,3,5, 1,3,6, 1,2,4, 1,2,5, 1,2,6 };
  static int trgul[][5] = 
    { 0,1,2,3,4, 0,1,5,6,7, 0,1,2,8,9, 0,1,4,7,10, 0,1,5,9,11, 0,3,4,12,13,
      0,13,14,15,16, 0,8,9,12,13, 0,4,13,16,17, 0,9,13,14,18, 0,7,14,15,19,
      0,4,7,17,19, 0,6,7,14,20, 0,9,11,14,20, 2,3,4,21,22, 5,6,7,21,22,
      2,8,9,21,22, 4,7,10,21,22, 5,9,11,21,22, 3,4,22,23,24, 22,24,25,26,27,
      8,9,22,23,24, 4,22,24,27,28, 9,22,24,25,29, 7,22,25,26,30, 4,7,22,28,30,
      6,7,22,25,31, 9,11,22,25,31, 3,4,13,23,32, 13,25,26,27,32, 8,9,13,23,32,
      4,13,27,28,32, 9,13,25,29,32, 13,16,25,26,33, 4,13,16,28,33, 
      13,15,16,25,34, 9,13,18,25,34, 7,19,25,26,33, 4,7,19,28,33,
      7,15,19,25,34, 6,7,20,25,34, 9,11,20,25,34 } ;

  sc->nbr_triangles = 35 ;
  sc->nbr_triangles_2 = 5 ;
  sc->nbr_trianguls = 42 ;
  sc->triangles = trgl ;
  sc->trianguls = trgul ;
}
 
