/*
  Modification history:
    09/06/2000  created     Jie Wan
    06/20/2001  add sizeCheck()   Xiangrong Li
    11/07/2001  add pre-motion of a vertex   Xiangrong Li
*/

#include "EdgeSplitMod.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "MeshSize.h"
#include "MeshAdjTools.h"
#include "fromMeshTools.h"
#include "PList.h"
#include "BLUtil.h"
#include "FMDB_cint.h"
#include <stdio.h>
#include <iostream>
using std::cout;
using std::endl;

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif


// setting the XYZ and param coords of the new vertex
void edgeSplitMod::setSplitPos(double p[3],double *a) 
{
  xyz[0]=p[0];
  xyz[1]=p[1];
  xyz[2]=p[2]; 
  if( a ) {
    par[0]=a[0]; 
    par[1]=a[1];
  }
} 


int edgeSplitMod::topoCheck()
{
  if (!EN_okTo(SPLIT,(pEntity)edge)) 
    return 0;
#ifdef MA_PARALLEL
  if( EN_onCB((pEntity)edge) ) // not splitting if on Common boundary
    return 0;
#endif

  /// Can't handle cases involving any topology other than tets
  int iValidRgn = 1;
  pVertex pVertexVtx[3] = {E_vertex(edge, 0), E_vertex(edge, 1), vertMv};
  pRegion pRegionRgn;
  int iVtxNum = 2;
  if (vertMv)
    iVtxNum = 3;
  for (int iVtx = 0; iVtx < iVtxNum; ++iVtx)
  {
    pPList vregs = V_regions(pVertexVtx[iVtx]);
    for (int iRgn = 0; iRgn < PList_size(vregs); ++iRgn)
    {
      pRegionRgn = (pRegion)PList_item(vregs, iRgn);
      if (pRegionRgn->getType() == PYRAMID)
      {
        iValidRgn = 0;
        PList_delete(vregs);
        break;
      }
    }
    if (iValidRgn)
      PList_delete(vregs);
    else
      break;
  }
  if (!iValidRgn)
    return 0;  

  return 1;
} 


int edgeSplitMod::geomCheck()
{
  pPList rvlist;
  pRegion rgn;
  pVertex vt, vertex, ev;
  void *iter, *temp = 0 ;
  double rg[4][3];
  double ori[3];
  double shape_1;
  int    i,j;

  // initialize
  double worstShape =BIG_NUMBER;

  // move the vertex if there is a pre-motion
  if( vertMv ) {
    V_coord(vertMv,ori);
    adaptUtil::move_vertex(vertMv,target);

    pPList vRgns;
    if(!EN_isBLEntity(vertMv))
      vRgns = V_regions(vertMv);
    else {
      if(!V_atBLInterface(vertMv)) {
        cout<<"\nError in edgeCollapsMod::geomCheck()..."<<endl;
        cout<<"vertMv is BL entity but not at BL interface"<<endl;
        exit(0);
      }

      vRgns = PList_new();

      vector<pRegion> Vrgns;
      V_nonBLRegions(vertMv, Vrgns);
      for (int itReg = 0; itReg < Vrgns.size(); ++itReg)
      {
        PList_append(vRgns, Vrgns[itReg]);
      }

      double f_xyz[3][3], v01[3], v02[3], nor[3];;
      pMSize f_pmt[3];
      pFace face;
      vector<pFace> vLyrFaces;
      V_layerFaces(vertMv, vLyrFaces);
      pPList fverts;
      int numFaces = vLyrFaces.size();
      for(int iFace=0; iFace<numFaces; iFace++)
      {
        face = vLyrFaces[iFace];

        fverts = F_vertices(face,1);

        // compute the original normal
        temp = 0; i = 0;
        while (vertex = (pVertex)PList_next(fverts, &temp)) {
          if(vertex==vertMv) {
            f_xyz[i][0]=ori[0]; f_xyz[i][1]=ori[1]; f_xyz[i++][2]=ori[2];
          }
          else
            V_coord(vertex,f_xyz[i++]);
        }
        diffVt(f_xyz[1],f_xyz[0],v01);
        diffVt(f_xyz[2],f_xyz[0],v02);
        crossProd(v01,v02,nor);

        temp = 0; i = 0;
        while (vertex = (pVertex)PList_next(fverts, &temp)) {
          f_pmt[i]=pSizeField->getSize(vertex);
          V_coord(vertex,f_xyz[i++]);
        }
        PList_delete(fverts);

        // check validity and calculate shape
        if(!shpMeasure->XYZ_shape(f_xyz, f_pmt, nor, &shape_1)) {
          PList_delete(vRgns);
          adaptUtil::move_vertex(vertMv,ori);
          return 0;
        }
      }
    }

    temp=0;
    while( rgn = (pRegion)PList_next(vRgns,&temp) ) {
      if( R_inClosure(rgn,(pEntity)edge) ) continue;
      if( !shpMeasure->R_shape(rgn,&shape_1) ) {
	PList_delete(vRgns);
	adaptUtil::move_vertex(vertMv,ori);
	return 0;
      }
      if( worstShape > shape_1 ) 
	worstShape=shape_1;
    }
    PList_delete(vRgns);

    // check geometric similarity after this motion
// #ifdef DEBUG
//     printf("WARNING: geometric similarity check not implementated (EdgeSplitMod.cc)\n");
// #endif
  }

  pMSize pSxyz=pSizeField->getSize(xyz,(pEntity)edge);

  pMSize pmt[4];
  pPList eregs = E_regions(edge);
  temp = 0;
  while ( rgn = (pRegion)PList_next(eregs,&temp) ) {
    rvlist=R_vertices(rgn,1);

    // evaluate the two regions created by splitting 'rgn'
    for( i=0; i<2; i++ ) {
      ev=E_vertex(edge,i);
      iter=0; j=0;
      while( (vt=(pVertex)PList_next(rvlist,&iter)) ) {
	if( vt==ev )
	  {
	    pmt[j]=pSxyz;
	    rg[j][0]=xyz[0]; rg[j][1]=xyz[1]; rg[j++][2]=xyz[2];
	  }
	else 
	  {
	    pmt[j]=pSizeField->getSize(vt);
	    V_coord(vt,rg[j++]);
	  }
      }
      // check validity
      if( !shpMeasure->XYZ_shape(rg,pmt,&shape_1) ) 
	{
	  PList_delete (eregs);
	  PList_delete (rvlist);
          if( pSxyz )
	    delete pSxyz;
	  if( vertMv ) 
	    adaptUtil::move_vertex(vertMv,ori);
	  return 0;
	}
      // determine the worst shape
      if( worstShape > shape_1 )
	worstShape=shape_1;
    }
    PList_delete(rvlist);
  }
  PList_delete(eregs);

  if( vertMv )  
    adaptUtil::move_vertex(vertMv,ori);
  if( pSxyz )
    delete pSxyz;

#ifdef DEBUG
  if (worstShape==BIG_NUMBER) 
    return 0; 
#endif
  
  results->setWorstShape(worstShape);
  return 1;
}

/*
  we only take account of the size change by the split operation
*/
int edgeSplitMod::sizeCheck() 
{
  pFace face;
  pVertex vts[2];
  pVertex OpVt;
  pMSize mtVts[2];
  pMSize mtSplt;
  pMSize mtOpVt;
  double coords[2][3], xyz1[3];
  double ori[3];
  int i;
  double max,min,tmp;

  if( !pSizeField ) {
    printf("WARNING: NULL metric field, you can not do size checking");
    return 1;
  }

  if( vertMv ) {
    V_coord(vertMv,ori);
    adaptUtil::move_vertex(vertMv,target);
  }

  // get the desired size & coordinates
  for( i=0; i<2; i++ ) {
    vts[i]=E_vertex(edge,i);
    V_coord(vts[i],coords[i]);
    mtVts[i]=pSizeField->getSize(vts[i]);
  }

  // interpolate the desired size at splitting location
  mtSplt=pSizeField->getSize(xyz,(pEntity)edge);
//    t=adaptUtil::ParOnLinearEdge(coords,xyz);
//    pSizeField->interpolate(mtVts[0],mtVts[1],t,&mtSplt);

  // estimate the max size of the new edges after splitting
  max = pSizeField->lengthSq(xyz,coords[0],mtSplt,mtVts[0]);
  min=max;

  tmp = pSizeField->lengthSq(xyz,coords[1],mtSplt,mtVts[1]);
  //  size->get(xyz,coords[1],mtSplt,mtVts[1],&tmp);
  if( tmp>max ) max=tmp;
  if( tmp<min ) min=tmp;

  for( i=0; i<E_numFaces(edge); i++ ) {
    face=E_face(edge,i);
    OpVt=F_edOpVt(face,edge);
    mtOpVt=pSizeField->getSize(OpVt);
    V_coord(OpVt,xyz1);
    tmp = pSizeField->lengthSq(xyz,xyz1,mtSplt,mtOpVt);
    if( tmp>max ) max=tmp;
    if( tmp<min ) min=tmp;
  }
  
  if( mtSplt ) 
    delete mtSplt;
  results->setMaxSize(max);
  results->setMinSize(min);
  if( vertMv ) 
    adaptUtil::move_vertex(vertMv,ori);
  return 1;
}


void edgeSplitMod::getAffectedRgns(pPList *l)
{
  *l=E_regions(edge);
  return;
}


int edgeSplitMod::apply() 
{
  pPList newRegs;
  int flag;

  flag=apply(&newRegs);

#ifdef __CURVE

  if(quadratic==true&&model_type==PARAM){
    //cout<<"set up new edge nodes if on model boundary"<<endl;
      void *temp=0;
      pRegion newRgn;
      pEdge newEdge;
      pPList relist;
      while(newRgn=(pRegion)PList_next(newRegs,&temp)){
	void *tempEdge=0;
	relist = R_edges(newRgn, 1);
	while(newEdge=(pEdge)PList_next(relist,&tempEdge)){
	  if(E_whatInType(newEdge) != 3){
	    pPoint pt;
	    if(!E_numPoints(newEdge)) 
	      pt = P_new();
	    else 
	      pt = E_point(newEdge, 0);

	    double xyz[3];
	    double par[3];
	    templatesUtil::middlePoint(newEdge,0.5,xyz,par);
	   
	    P_setPos(pt, xyz[0], xyz[1], xyz[2]);
	    if(!E_numPoints(newEdge))
	      E_setPoint(newEdge, pt);
	    AOMD_P_setParametricPos(pt, par[0], par[1], par[2]);
	    
	  }
	}
      }
      //PList_delete(relist);
      
  }
  

#endif //CURVE

  PList_delete(newRegs); 

  return flag;
}

int edgeSplitMod::apply(pPList *newRegs) 
{
#ifdef CURVE
  if(quadratic == false)
#endif
  if( E_whatInType(edge)!=Gregion && par[0]==0 )
    printf("WARNING: par is not set (edgeSplitMod)\n");

  // first move the vertex
  if( vertMv ) {
    adaptUtil::move_vertex(vertMv,target,CB_move,userData_CB_move);
#ifdef DEBUG
    pRegion region;
    pPList mvRgns=V_regions(vertMv);
    void *iter=0;
    while( region=(pRegion)PList_next(mvRgns,&iter) ) {
      if( R_inClosure(region,(pEntity)edge) )
	continue;
      if( R_Volume2(region) < 1.e-14 )
	printf("Error: 1. region %d: R_volume=%f (edgeSwapMod::apply())\n",
	       EN_id((pEntity)region),R_Volume2(region));
    }
    PList_delete(mvRgns);
    printf("edge split + move did not created any negative volume\n");
#endif
  }

  pMSize mtSplt;
  if( pSizeField ) 
    // interpolate the desired size at splitting location
    mtSplt=pSizeField->getSize(xyz,(pEntity)edge);

#ifdef CURVE  
if(E_numPoints(edge))
    {
      pPoint point = E_point(edge, 0);
      P_delete(point);

    }
#endif

  v=templatesUtil::Edge_split (mesh, edge, xyz, par, 
			       function_CB, userData_CB, newRegs);
#ifdef CURVE
if(quadratic == true) {
    // we have to set up the higher order nodes for all of the edges
    // connected to the new vertex
    map<pVertex, double *>::iterator mit = edpts.begin(), mitend = edpts.end();
    pVertex vt;
    pEdge e;
    pPoint pt;
    double *temp;
    double vxyz[2][3];
    V_coord(v, vxyz[0]);

    for(; mit != mitend; mit++) {
      vt = mit->first;
      temp = mit->second;
      e = E_exist(vt, v);
      if(!e) {
        printf("edge split: can not find the new edges\n");
        delete []temp;
      }
      else {
        V_coord(vt, vxyz[1]);
        for(int k=0; k<3; k++)
          temp[k] = 0.25*(vxyz[0][k] + vxyz[1][k]) + 0.5*temp[k];
        if(E_numPoints(e)) {
          pt = E_point(e, 0);
          P_setPos(pt, temp[0], temp[1], temp[2]);
        }
        else{
          pt = P_new();
          P_setPos(pt, temp[0], temp[1], temp[2]);
          E_setPoint(e, pt);
        }
        delete []temp;
      }
    }
  }
#endif


  if( pSizeField ) 
    pSizeField->setSize((pEntity)v,mtSplt);

  return 1;
}



