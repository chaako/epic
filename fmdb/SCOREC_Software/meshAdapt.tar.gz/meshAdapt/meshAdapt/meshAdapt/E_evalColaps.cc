#include "FMDB.h"
#include "Defines.h"
#include "fromMeshTools.h"

int E_evalColaps(pMesh mesh, pEdge cedge, pVertex vertd, pVertex vertr) {
  pPList vregs, rverts;
  pVertex vertex;
  pRegion region;
  void *temp1=0, *temp2=0;
  double xyz[4][3];
  int i=0;
  double shape;

  vregs = V_regions(vertd);
  temp1 = 0;
  while (region = (pRegion)PList_next(vregs,&temp1)) {
    if (!R_inClosure(region,cedge)) {
      rverts = R_vertices(region,1);
      temp2 = 0; i = 0;
      while (vertex = (pVertex)PList_next(rverts, &temp2))
	if (vertex == vertd)
	  V_coord(vertr,xyz[i++]);
	else
	  V_coord(vertex,xyz[i++]);
      PList_delete(rverts);
      shape = 0.0 ;
      if( !XYZ_shapeMeasure( xyz, &shape ) ) {
	    PList_delete(vregs);
	    return 0;
      }           
    }
  }

  PList_delete(vregs);
  return 1;
}
		  
