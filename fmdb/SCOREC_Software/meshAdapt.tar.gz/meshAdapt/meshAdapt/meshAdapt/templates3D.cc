#include "templateRefine.h"
#include "templateUtil.h"
#include "PList.h"

/*
  one edge is marked
  by Xiangrong Li     05/08/99
*/
void meshTemplate::template_1(pRegion region, pPList ordered_edges, int id, 
			      pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int Eind[6][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4},
                   {3,4,0,2,5,1}, {4,5,1,0,3,2}, {5,3,2,1,4,0} };
  int Find[6][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2},
                   {1,3,2,0},     {2,1,3,0},     {3,2,1,0} };
  int Vind[6][4]={ {0,1,2,3},     {1,2,0,3},     {2,0,1,3},
                   {0,3,1,2},     {1,3,2,0},     {2,3,0,1} };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // split the region
  sub_template_1(parent_edges, parent_faces,r_dirs, verts, g_entity,newRgns,newEdges);
  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);

  // delete edge if it can be
  delete_edge(parent_edges[0],0);

  PList_delete(ordered_verts);
}

/*
  two edges on a face are marked
  by Xiangrong Li 05/12/99
*/
void meshTemplate::template_2_1(pRegion region, pPList ordered_edges, int id, 
				pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  // index tables
  int Eind[12][6]={ {0,1,2,3,4,5},  {1,2,0,4,5,3}, {2,0,1,5,3,4}, {4,0,3,5,1,2},
                    {3,4,0,2,5,1},  {0,3,4,1,2,5}, {5,1,4,3,2,0}, {4,5,1,0,3,2},
                    {1,4,5,2,0,3},  {5,3,2,1,4,0}, {3,2,5,4,0,1}, {2,5,3,0,1,4} };
  int Find[12][4]={ {0,1,2,3},      {0,2,3,1},     {0,3,1,2},     {1,2,0,3},
                    {1,3,2,0},      {1,0,3,2},     {2,3,0,1},     {2,1,3,0},
                    {2,0,1,3},      {3,2,1,0},     {3,1,0,2},     {3,0,2,1} };
  int Vind[12][4]={ {0,1,2,3},      {1,2,0,3},     {2,0,1,3},     {3,1,0,2},
                    {0,3,1,2},      {1,0,3,2},     {3,2,1,0},     {1,3,2,0},
                    {2,1,3,0},      {2,3,0,1},     {3,0,2,1},     {0,2,3,1} };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // split the region
  sub_template_2_1(parent_edges, parent_faces,r_dirs, verts, g_entity,newRgns, newEdges);
  callCallback((pEntity)region,newRgns,0);
  
  // delete the region.
  delete_region(region,0);
  
  // delete face if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);

  // delete edge if it can be
  delete_edge(parent_edges[1],0);
  delete_edge(parent_edges[2],0);

  // Free the memory
  PList_delete(ordered_verts);
}

/*
  two opposite edges are marked
  by Xiangrong Li 05/12/99
*/
void meshTemplate::template_2_2(pRegion region,pPList ordered_edges,int id,
				pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int Eind[3][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4} };
  int Find[3][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2} };
  int Vind[3][4]={ {0,1,2,3},     {1,2,0,3},     {2,0,1,3} };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // split the region
  sub_template_2_2(parent_edges, parent_faces,r_dirs, verts, g_entity,newRgns,newEdges);
  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);

  // delete edges if it can be
  delete_edge(parent_edges[0],0);
  delete_edge(parent_edges[5],0);

  // Free the memory
  PList_delete(ordered_verts);
}

/*
  by Xiangrong Li 05/15/99
*/
void meshTemplate::template_3_1(pRegion region,pPList ordered_edges,int id,
				pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);
  int k;

  int Eind[6][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4},
                   {3,4,0,2,5,1}, {4,5,1,0,3,2}, {5,3,2,1,4,0} };
  int Find[6][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2},
                   {1,3,2,0},     {2,1,3,0},     {3,2,1,0}     };
  int Vind[6][4]={ {0,1,2,3},     {1,2,0,3},     {2,0,1,3},
                   {0,3,1,2},     {1,3,2,0},     {2,3,0,1}     };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // find the pattern k for sub-templates
  k=0;
  if(r_dirs[0]) k = k | 1;
  if(r_dirs[1]) k = k | 2;

  // split the region
  sub_template_3_1(parent_edges, parent_faces, r_dirs, verts, g_entity, k, newRgns, newEdges);
  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);

  // delete edge if it can be
  delete_edge(parent_edges[0],0);
  delete_edge(parent_edges[2],0);
  delete_edge(parent_edges[4],0);

  // Free the memory
  PList_delete(ordered_verts);
}

/*
  by Xiangrong Li 05/15/99
*/
void meshTemplate::template_3_2(pRegion region,pPList ordered_edges,int id,
				  pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);
  int k;

  int Eind[6][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4},
                   {3,4,0,2,5,1}, {4,5,1,0,3,2}, {5,3,2,1,4,0}   };
  int Find[6][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2},
                   {1,3,2,0},     {2,1,3,0},     {3,2,1,0}       };
  int Vind[6][4]={ {0,1,2,3},     {1,2,0,3},     {2,0,1,3},
                   {0,3,1,2},     {1,3,2,0},     {2,3,0,1}       };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // find the pattern k for sub-templates
  k=0;
  if(r_dirs[0]) k = k | 1;
  if(r_dirs[1]) k = k | 2;

  // split the region
  sub_template_3_2(parent_edges, parent_faces, r_dirs, verts, g_entity, k, newRgns, newEdges);
  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);

  // delete edges if it can be
  delete_edge(parent_edges[0],0);
  delete_edge(parent_edges[1],0);
  delete_edge(parent_edges[3],0);

  // Free the memory
  PList_delete(ordered_verts);
}

/*
  three edges with a common vertex are marked
  by Xiangrong Li 05/18/99
*/
void meshTemplate::template_3_3(pRegion region,pPList ordered_edges,int id,
				  pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);
  int k;

  int Eind[4][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4},  {4,0,3,5,1,2}  };
  int Find[4][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2},      {1,2,0,3}      };
  int Vind[4][4]={ {0,1,2,3},     {1,2,0,3},     {2,0,1,3},      {3,1,0,2}      };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // find the pattern k for sub-templates
  k=0;
  if(r_dirs[0]) k = k | 1;
  if(r_dirs[1]) k = k | 2;
  if(r_dirs[3]) k = k | 4;

  // split the region
  pVertex newVt=0;
  if(k==0 || k==7)
    newVt = sub_template_3_3_a(parent_faces, r_dirs, verts,g_entity, k, newRgns, newEdges);
  else
    sub_template_3_3_b(parent_edges, parent_faces,r_dirs,verts,g_entity,k,newRgns,newEdges);

  // delete the region.
  callCallback((pEntity)region,newRgns,newVt);
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[3],0);

  // delete edges if it can be
  delete_edge(parent_edges[0],0);
  delete_edge(parent_edges[2],0);
  delete_edge(parent_edges[3],0);

  // free memories
  PList_delete(ordered_verts);
}

/*
  three edges on a face are marked
  by Xiangrong Li 05/18/99
*/
void meshTemplate::template_3_4(pRegion region,pPList ordered_edges,int id,
				  pPList newRgns,pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int Eind[4][6]={ {0,1,2,3,4,5}, {0,3,4,1,2,5}, {1,4,5,2,0,3},  {5,3,2,1,4,0} };
  int Find[4][4]={ {0,1,2,3},     {1,0,3,2},     {2,0,1,3},      {3,2,1,0}     };
  int Vind[4][4]={ {0,1,2,3},     {1,0,3,2},     {2,1,3,0},      {2,3,0,1}     };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // split the region
  sub_template_3_4(parent_edges,parent_faces,r_dirs,verts,g_entity,newRgns,newEdges);

  // delete the region.
  callCallback((pEntity)region,newRgns,0);
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);

  // delete edges if it can be
  delete_edge(parent_edges[0],0);
  delete_edge(parent_edges[1],0);
  delete_edge(parent_edges[2],0);

  // free memories
  PList_delete(ordered_verts);
}

/*
  template for 4 marked edges with three on a face
  by Xiangrong Li 05/23/99
*/
void meshTemplate::template_4_1(pRegion region,pPList ordered_edges,int id,
				  pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);
  int k=0;

  int Eind[12][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4}, {0,3,4,1,2,5},
                    {3,4,0,2,5,1}, {4,0,3,5,1,2}, {4,5,1,0,3,2}, {1,4,5,2,0,3},
                    {5,1,4,3,2,0}, {2,5,3,0,1,4}, {5,3,2,1,4,0}, {3,2,5,4,0,1}
                  };

  int Find[12][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2},     {1,0,3,2},
                    {1,3,2,0},     {1,2,0,3},     {2,1,3,0},     {2,0,1,3},
                    {2,3,0,1},     {3,0,2,1},     {3,2,1,0},     {3,1,0,2}
                  };

  int Vind[12][4]={ {0,1,2,3},     {1,2,0,3},     {2,0,1,3},     {1,0,3,2},
                    {0,3,1,2},     {3,1,0,2},     {1,3,2,0},     {2,1,3,0},
                    {3,2,1,0},     {0,2,3,1},     {2,3,0,1},     {3,0,2,1}
                  };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // find the sub-template pattern
  if(r_dirs[1]) k = k | 1;
  if(r_dirs[3]) k = k | 2;

  // split the region
  sub_template_4_1(parent_edges, parent_faces, r_dirs, verts, g_entity, k, newRgns, newEdges);

  // delete the region.
  callCallback((pEntity)region,newRgns,0);
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);

  // delete edge if it can be
  delete_edge(parent_edges[0],0);
  delete_edge(parent_edges[1],0);
  delete_edge(parent_edges[2],0);
  delete_edge(parent_edges[3],0);

  // free memories
  PList_delete(ordered_verts);
}

/*
  four edges are marked with two in each face
  by Xiangrong Li 05/23/99
*/
void meshTemplate::template_4_2(pRegion region,pPList ordered_edges,int id,
				  pPList newRgns,pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);
  int i;
  int k=0;

  int filter[]={1,2,4,8};

  int Eind[4][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4} };
  int Find[4][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2}  };
  int Vind[4][4]={ {0,1,2,3},     {1,2,0,3},     {2,0,1,3}  };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // find the sub-template
  for(i=0; i<4; i++)
    if(r_dirs[i])
      k= k | filter[i];

  // split the region
  pVertex newVt=0;
  if(k==3 || k==12)
    newVt = sub_template_4_2_b(parent_faces, r_dirs, verts,g_entity, newRgns, newEdges);
  else
    sub_template_4_2_a(parent_edges, parent_faces, verts, g_entity, k, newRgns, newEdges);

  // delete the region.
  callCallback((pEntity)region,newRgns,newVt);
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);

  // delete edges if it can be
  delete_edge(parent_edges[1],0);
  delete_edge(parent_edges[2],0);
  delete_edge(parent_edges[3],0);
  delete_edge(parent_edges[4],0);

  // free memories
  PList_delete(ordered_verts);
}

/*
  five edges are marked
  by Xiangrong Li 05/24/99
*/
void meshTemplate::template_5(pRegion region,pPList ordered_edges,int id,
				pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);
  int k=0;

  int Eind[6][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4},
                   {3,4,0,2,5,1}, {4,5,1,0,3,2}, {5,3,2,1,4,0} };
  int Find[6][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2},
                   {1,3,2,0},     {2,1,3,0},     {3,2,1,0} };
  int Vind[6][4]={ {0,1,2,3},     {1,2,0,3},     {2,0,1,3},
                   {0,3,1,2},     {1,3,2,0},     {2,3,0,1} };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,
				 parent_faces,parent_edges,r_dirs,verts);

  // find the sub-template
  if(r_dirs[0]) k = k | 1;
  if(r_dirs[1]) k = k | 2;

  // split the region
  sub_template_5(parent_edges, parent_faces,r_dirs, verts, g_entity, k, newRgns, newEdges);

  // delete the region.
  callCallback((pEntity)region,newRgns,0);
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);

  // delete edges if it can be
  delete_edge(parent_edges[1],0);
  delete_edge(parent_edges[2],0);
  delete_edge(parent_edges[3],0);
  delete_edge(parent_edges[4],0);
  delete_edge(parent_edges[5],0);

  // free memories
  PList_delete(ordered_verts);
}

/*
  template for uniform refinement
*/
void meshTemplate::template_63(pRegion region,pPList ordered_edges,int flag,
			       pPList newRgns,pPList newEdges)
{
  pEdge parent_edges[6];
  pFace parent_faces[4];
  int id, r_dirs[4];
  pVertex verts[4];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int Eind[3][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4} };
  int Find[3][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2} };
  int Vind[3][4]={ {0,1,2,3},     {1,2,0,3},     {2,0,1,3} };

  // get the 4 vertices of the region in the guaranteed order
  pPList ordered_verts=R_vertices(region,1);

  // determine the interior mesh edge to be created
  id=templatesUtil::shortestDiagonal(ordered_verts,7,pSizeField);

  // mapping
  templatesUtil::mapping_template(region,ordered_edges,ordered_verts,id,Eind,Find,Vind,    
				 parent_faces,parent_edges,r_dirs,verts);

  // split the region
  sub_template_6(region,parent_edges,parent_faces,r_dirs,verts,g_entity,
		 newRgns,newEdges);
  callCallback((pEntity)region,newRgns,0);

  if( flag ) {
    // delete the region.
    delete_region(region,0);
    // delete face if it can be
    delete_face(parent_faces[0],0);
    delete_face(parent_faces[1],0);
    delete_face(parent_faces[2],0);
    delete_face(parent_faces[3],0);
    // delete edge if it can be
    delete_edge(parent_edges[0],0);
    delete_edge(parent_edges[1],0);
    delete_edge(parent_edges[2],0);
    delete_edge(parent_edges[3],0);
    delete_edge(parent_edges[4],0);
    delete_edge(parent_edges[5],0);
  }

  // free memories
  PList_delete(ordered_verts);
}


