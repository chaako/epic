#include "MeshAdapt.h"
#include "AdaptUtil.h"
#include "MeshSimAdapt.h"
#include "PWLinearSField.h"
#include <cmath>

extern "C"
meshAdapt *  MSA_new(pMeshMdl pMeshInstance, pMesh mesh, int procedure)
{
  if(!procedure) // tag driven
#ifndef MESHMODEL
      return new meshAdapt(pMeshInstance, TagDriven, 2);
#else
      return new meshAdapt(pMeshInstance, TagDriven, 0);
#endif
  else // size-field driven 
    {  
//      pSField mf = new PWLsfield(mesh);
#ifndef MESHMODEL
      return new meshAdapt(pMeshInstance, Application, 2);
#else
      return new meshAdapt(pMeshInstance, Application, 0);
#endif
    }
}

extern "C"
void MSA_setAnisoVertexSize(meshAdapt *simAdapter, 
			    pVertex vertex,
			    double simData[3][3]) {

  double h[3] = {0.,0.,0.};
  double dirs[3][3];

  for(int i=0; i<3; i++) {
    for (int j=0 ;j<3; j++) {
      h[i] += simData[i][j]*simData[i][j]; 
    }

    h[i] = sqrt(h[i]);

    for(int j=0; j<3; j++)
      dirs[i][j] = simData[i][j]/h[i];
  }

  pSField field = simAdapter->getSizeField();

  ((PWLsfield *)field)->setSize((pEntity)vertex,dirs,h);
}

extern "C"
void MSA_setVertexSize(meshAdapt *simAdapter, 
		       pVertex vertex,
		       double size) {

  pSField field = simAdapter->getSizeField();

  ((PWLsfield *)field)->setSize((pEntity)vertex,size);
}
extern "C"
void MSA_delete(meshAdapt *rdr)
{ 
    delete rdr->getSizeField();
    delete rdr; 
}

/* set refinement for mesh entity */
extern "C"
void MSA_setRefineLevel(meshAdapt *rdr,pEdge ed,int level)
{ rdr->setAdaptLevel(ed,level); }

/* do refinement */
extern "C"
void MSA_adapt(meshAdapt *rdr)
{ rdr->run(rdr->GetNumIt(), 0, 0); }

extern "C"
void MSA_setCallback(meshAdapt *rdr, CBFunction CB, int filter, void *userData)
{ rdr->setCallback(CB,userData); }

