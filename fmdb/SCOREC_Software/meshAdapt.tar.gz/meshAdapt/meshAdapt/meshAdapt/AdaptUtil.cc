#include "AdaptUtil.h"
#include "visUtil.h"
#include "templateUtil.h"
#include "EdgeSwapMod.h"
#include "SplitCollapsMod.h"
#include "EdgeCollapsMod.h"
#include "Macros.h"
#include "ParamsOnGFace.h"
#include "MeshSize.h"
#include "meanRatio.h"
#include <math.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <assert.h>
#include "fromMeshTools.h"
#include "MeshAdjTools.h"
#include "PList.h"
#include "BLUtil.h"

using namespace std;

#ifdef MVTK
#include "mvtk.h"
#endif

#ifdef AOMD_
#include "FMDB_cint.h"
#endif

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#include "paraAdapt.h"
#include "ParUtil.h"
#endif


namespace adaptUtil {

#ifdef MA_PARALLEL
  void M_checkRemoteCopies(pMesh mesh) {
    Info("\n******* checkRemoteCopies starts ********\n");
    vector<pEntity> ents_send;
    vector<pEntity>::iterator ents_it;

    FIter fit=M_faceIter(mesh);
    pFace face;
    while( face=FIter_next(fit) ) 
    {
      if (EN_onCB((pEntity)face))
        ents_send.push_back((pEntity)face);
    }
    FIter_delete(fit);

    EIter eit=M_edgeIter(mesh);
    pEdge edge;
    while( edge=EIter_next(eit) )  
    {
      if (EN_onCB((pEntity)edge))
        ents_send.push_back((pEntity)edge);
    }
    EIter_delete(eit);

    VIter vit=M_vertexIter(mesh);
    pVertex vertex;
    while( vertex=VIter_next(vit) ) 
    {
      if (EN_onCB((pEntity)vertex))
        ents_send.push_back((pEntity)vertex);
    }
    VIter_delete(vit);

    IPComMan *CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int msg_size = sizeof(remoteCopyPack);
    CM->set_fixed_msg_size(msg_size);
    remoteCopyPack *msg_send = (remoteCopyPack*)CM->alloc_msg(msg_size);
    int num_sent = 0, num_recvd = 0;

    pEntity ent;
    for (ents_it = ents_send.begin(); ents_it != ents_send.end(); ents_it++)
    {
      int pid;
      ent = *ents_it;
      std::vector<std::pair<pEntity,int> > remotePtrs;
      std::vector<std::pair<pEntity,int> >::iterator remoteIter;
      EN_getRemoteCopies(mesh, ent, remotePtrs);

      for( remoteIter=remotePtrs.begin(); remoteIter!=remotePtrs.end(); ++remoteIter ) 
      {

        pid=remoteIter->second;
        msg_send->localInSend  = ent;
        msg_send->remoteInSend = remoteIter->first;
        msg_send->type = EN_type(ent);
        msg_send->pid = M_Pid();
        CM->send(pid, (void*)msg_send);
        num_sent++;
      }
    }
    CM->finalize_send();
    CM->free_msg(msg_send);

    pEntity locInRecv;

    // receive phase begins
    void *msg_recv;
    int pid_from;

    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      num_recvd++;  
      remoteCopyPack *castbuf = (remoteCopyPack *)msg_recv;
      locInRecv = castbuf->remoteInSend;
      if( EN_type(locInRecv)!=castbuf->type ) {
	  printf("(%d)  localType=%d  receivedType+% \n", 
		 EN_type(locInRecv),castbuf->type);
      }

      std::vector<std::pair<pEntity,int> > remotePtrs;
      std::vector<std::pair<pEntity,int> >::iterator remoteIter;
      EN_getRemoteCopies(mesh,locInRecv, remotePtrs);

      int flag=0, flag2=0;
      for( remoteIter=remotePtrs.begin(); remoteIter!=remotePtrs.end(); ++remoteIter ) {
        if( remoteIter->first == castbuf->localInSend ) {
	  flag2++;
	  if ( remoteIter->second == castbuf->pid ) {
	    flag++;
	  }
	}
      }

      if( flag!=1 ) {
        Info(flag,"inconsistent remote copies");
        if( flag2==1 ) 
          Info(flag2,"found in remote copy list, but Pid not match");
      }
      assert( flag==1 );
      CM->free_msg(msg_recv);
    }

    Info("\n******* checkRemoteCopies done ********\n");
    return;
  }


/*  
  void EN_sendRemoteCopy(pMesh mesh, pEntity ent) {
    if( ! EN_onCB(ent) )
      return;

    int pid;
    std::vector<std::pair<pEntity,int> > remotePtrs;
    std::vector<std::pair<pEntity,int> >::iterator remoteIter;
    EN_getRemoteCopies(mesh,ent, remotePtrs);

    for( remoteIter=remotePtrs.begin(); 
	 remoteIter!=remotePtrs.end(); ++remoteIter ) {

      pid=remoteIter->second;
      void *buf=AP_alloc(pid,1,sizeof(remoteCopyPack));
      remoteCopyPack *castbuf=(remoteCopyPack *)buf;

      castbuf->localInSend  = ent;
      castbuf->remoteInSend = remoteIter->first;
      castbuf->type = EN_type(ent);
      castbuf->pid = M_Pid();

      AP_send(buf);
    }
    return;
  }
*/

  void checkFace(pMesh mesh) {
    cout<<"\n******* checkFace ********\n";
    FIter fit=M_faceIter(mesh);
    pFace face;
    while( face=FIter_next(fit) ) 
      {
	if( F_numRegions(face)==1 && ! EN_onCB(face) )
	{  if (F_whatInType(face)!=2)
 	     printf("F_whatInType(face)!=2 from checkFace() in AdaptUtil.h\n");
	   assert(F_whatInType(face)==2);
	}
        
      }
    FIter_delete(fit);
    cout<<"\n******* checkFace ********\n";
  }

#endif

  void Info(int num, string str) { 
  #ifdef MA_PARALLEL
  if (P_pid()==0)
    cout<<"("<<M_Pid()<<") Info: " << num << " " << str << endl; 
  #else
  cout<< "Info: " << num << " " << str << endl; 
  #endif
  return; }

  void Info(string str, int num) {
  #ifdef MA_PARALLEL
    if (P_pid()==0)
     cout<<"("<<M_Pid()<<") Info: " << str << " " << num << endl; 
  #else
  cout<< "Info: " << str << " " << num << endl; 
  #endif
  return; }

  void Info(double f, string str) { 
  #ifdef MA_PARALLEL
  if (P_pid()==0)
    cout<<"("<<M_Pid()<<") Info: " << f << " " << str << endl; 
  #else
  cout<< "Info: " << f << " " << str << endl;  
  #endif
  return; }
  
  void Info(string str) { 
  #ifdef MA_PARALLEL
    if (P_pid()==0)
    cout<<"("<<M_Pid()<<") Info: " << str << endl;
  #else
  cout<< "Info: " << str << endl; 
  #endif
  return; }
  
  void Error(string str) { 
  #ifdef MA_PARALLEL
  cout<<"("<<M_Pid()<<") Error:" << str << endl;
  #else
  cout << "Error:" << str << endl;
  #endif
  return; 
  }

  void Warning(string str) { 
  #ifdef MA_PARALLEL
  cout<<"("<<M_Pid()<<") Warning:" << str << endl; 
  #else
  cout << "Warning:" << str << endl; 
  #endif
  return; }



  /* 
     1. calculate the target location and attach to the vertex
     2. set the parametric value correctly

     Note that the position and the parameter of the vertex becomes not consistent,
     snapping this vertex usually is needed
 */
  void ProcessNewBdryVertex(pMesh pmesh, pVertex vertex)
  {
    pGEntity gent = V_whatIn(vertex);
    int gtype = GEN_type(gent);
    if( gtype == Gregion || gtype == Gvertex )
      return;

    double xyz[3];
    double coords[3];
    double par[]={0.0,0.0,0.0};

    V_coord(vertex,xyz);
    
    if( gtype == Gface)
      GF_closestPoint((pGFace)gent, xyz, coords, par);
    else if(gtype == Gedge)
      GE_closestPoint((pGEdge)gent, xyz, coords, par);
    else
      return;

#ifdef AOMD_
    FMDB_P_setParametricPos (V_point(vertex) , par[0], par[1], par[2]);
#else
    pPoint pt=M_createP(pmesh,coords[0],coords[1],coords[2],par,0,gent);
    pPoint point=V_point(vertex);
    V_setPoint(vertex,pt);
    P_delete(point);
    P_setPos(pt,xyz[0],xyz[1],xyz[2]);
#endif      

    return;
  }


  // given a list of regions, copy them into another mesh and return the mesh.
  // if a vertex/edge/face is given, its copy will be returned.
  // Note: you must delete the returned mesh to avoid memory leaks.
  pMesh copyRegions(pPList regions, pEntity ori, pEntity copy)
  {
    pMesh tmpMesh=MS_newMesh(0);
    pMeshDataId localPtr=MD_newMeshDataId("ptrToTmpMesh");
    
    pFace faces[4];
    int f_dirs[4];
    pEdge edges[3];       // the three bounding edges to create a new face
    int   e_dirs[3];      // the three orientations how a new face uses its edges
    pVertex vertices[2];  // the two bounding vertices of a new edge. Direction: [0]->[1]
    pRegion rgn;
    pFace fc;
    pEdge eg;
    pVertex vt;
    pPoint pt;
    double xyz[3];
    double par[3];
    pGEntity gent;
    int type;
    int i,j,k;
    
    void *temp_ptr;
    void *iter=0;
    
    while( rgn=(pRegion)PList_next(regions,&iter) )    {	
      // loop over the four faces
      for( i=0;i<4;i++ ) {
	fc=R_face(rgn,i);
	f_dirs[i]=R_dirUsingFace(rgn,fc);
	if( EN_getDataPtr((pEntity)fc,localPtr,&temp_ptr) ) 
	  faces[i]=(pFace)temp_ptr;
	else {
	  
	  // loop over the three edges
	  for( j=0;j<3;j++ ) {
	    eg=F_edge(fc,j);
	    e_dirs[j]=F_dirUsingEdge(fc,eg);
	    if( EN_getDataPtr((pEntity)eg,localPtr,&temp_ptr) ) 
	      edges[j]=(pEdge)temp_ptr;
	    else {
	      
	      // loop over the two vertices
	      for( k=0;k<2;k++ ) {
		vt=E_vertex(eg,k);
		if( EN_getDataPtr((pEntity)vt,localPtr,&temp_ptr) ) 
		  vertices[k]=(pVertex)temp_ptr;
		else {
		  
		  // create vertex in local mesh and attach it to its matching vertex in pmesh
		  pt=V_point(vt);
		  xyz[0]=P_x(pt);  xyz[1]=P_y(pt);  xyz[2]=P_z(pt);
		  gent=V_whatIn(vt);
		  type=GEN_type(gent);
		  par[0]=0.0;   par[1]=0.0;   par[2]=0.0;
		  //               if( type==Gedge ) 
		  //                 par[0]=P_param1(pt);
		  //               else if( type==Gface )
		  //                 P_param2(pt,&par[0],&par[1],(int*)&par[2]);
		  
		  vertices[k] = M_createVP2(tmpMesh,xyz,par,0,gent);
		  EN_attachDataPtr((pEntity)vt,localPtr,vertices[k]);
		}
	      }
	      
	      // create edge in local mesh and attach it to its matching edge in pmesh
	      gent=E_whatIn(eg);
	      edges[j]=M_createE(tmpMesh,vertices[0], vertices[1], gent);
	      EN_attachDataPtr((pEntity)eg,localPtr,edges[j]);
	    }
	  }
	  
	  // create face in local mesh and attach it to the matching face in pmesh
	  gent=F_whatIn(fc);
	  faces[i]=M_createF(tmpMesh, 3, edges, e_dirs, gent);
	  EN_attachDataPtr((pEntity)fc,localPtr,faces[i]);
	}
      }
      
      
      // create new regions
      gent=(pGEntity)R_whatIn(rgn);
      M_createR(tmpMesh, 4, faces, f_dirs, gent);
    }

    if( ori ) 
      if( EN_getDataPtr((pEntity)ori,localPtr,&temp_ptr) ) 
	copy = (pEntity)temp_ptr;
    
    iter=0;
    while( rgn=(pRegion)PList_next(regions,&iter) )
    {      
      for( i=0;i<4;i++ ) 
      {
	fc=R_face(rgn,i);
	if( EN_getDataPtr((pEntity)fc,localPtr,&temp_ptr) ) 
        {
          EN_deleteData((pEntity)fc,localPtr);
          for( j=0;j<3;j++ ) 
	  {
	    eg=F_edge(fc,j);
	    if( EN_getDataPtr((pEntity)eg,localPtr,&temp_ptr) ) 
	    {
	      EN_deleteData((pEntity)eg,localPtr);
	      for( k=0;k<2;k++ ) 
	      {
		vt=E_vertex(eg,k);
		if( EN_getDataPtr((pEntity)vt,localPtr,&temp_ptr) ) 
		  EN_deleteData((pEntity)vt,localPtr);
	      }
	    } // if eg
	  } // for j
	} // if fc
      } // for i
    } // while
        
    MD_deleteMeshDataId(localPtr);
    return tmpMesh;
  }

  // given a list of regions, copy them into another mesh and return the mesh.
  // if a list of vertex/edge/face is given, their copies will be returned in the same order.
  // Note: you must delete the returned mesh to avoid memory leaks.
  pMesh copyRegions(pPList regions, vector<pEntity> oris, vector<pEntity>& copies, pSField pSizeField)
  {
    pMesh tmpMesh=MS_newMesh(0);
    pMeshDataId localPtr=MD_newMeshDataId("ptrToTmpMesh");

    pFace faces[4];
    int f_dirs[4];
    pEdge edges[3];       // the three bounding edges to create a new face
    int   e_dirs[3];      // the three orientations how a new face uses its edges
    pVertex vertices[2];  // the two bounding vertices of a new edge. Direction: [0]->[1]
    pRegion rgn;
    pFace fc;
    pEdge eg;
    pVertex vt;
    pPoint pt;
    double xyz[3];
    double par[3];
    pGEntity gent;
    int type;
    int i,j,k;

    void *temp_ptr;
    void *iter=0;

    while( rgn=(pRegion)PList_next(regions,&iter) )    {
      // loop over the four faces
      for( i=0;i<4;i++ ) {
        fc=R_face(rgn,i);
        f_dirs[i]=R_dirUsingFace(rgn,fc);
        if( EN_getDataPtr((pEntity)fc,localPtr,&temp_ptr) )
          faces[i]=(pFace)temp_ptr;
        else {

          // loop over the three edges
          for( j=0;j<3;j++ ) {
            eg=F_edge(fc,j);
            e_dirs[j]=F_dirUsingEdge(fc,eg);
            if( EN_getDataPtr((pEntity)eg,localPtr,&temp_ptr) )
              edges[j]=(pEdge)temp_ptr;
            else {

              // loop over the two vertices
              for( k=0;k<2;k++ ) {
                vt=E_vertex(eg,k);
                if( EN_getDataPtr((pEntity)vt,localPtr,&temp_ptr) )
                  vertices[k]=(pVertex)temp_ptr;
                else {

                  // create vertex in local mesh and attach it to its matching vertex in pmesh
                  pt=V_point(vt);
                  xyz[0]=P_x(pt);  xyz[1]=P_y(pt);  xyz[2]=P_z(pt);
                  gent=V_whatIn(vt);
                  type=GEN_type(gent);
                  par[0]=0.0;   par[1]=0.0;   par[2]=0.0;
                  if( type==Gedge )
                    par[0]=P_param1(pt);
                  else if( type==Gface )
                    P_param2(pt,&par[0],&par[1],(int*)&par[2]);

                  vertices[k] = M_createVP2(tmpMesh,xyz,par,0,gent);
                  EN_attachDataPtr((pEntity)vt,localPtr,vertices[k]);

                  // set the mesh size for vertex
                  pMSize pT = new MeshSize(pSizeField->getSize(vt));
                  pSizeField->setSize((pEntity)vertices[k],pT);

                }
              }

              // create edge in local mesh and attach it to its matching edge in pmesh
              gent=E_whatIn(eg);
              edges[j]=M_createE(tmpMesh,vertices[0], vertices[1], gent);
              EN_attachDataPtr((pEntity)eg,localPtr,edges[j]);
              //    cout<<"("<<eg<<")"<<EN_getUid(eg)<<"->("<<edges[j]<<")"<<EN_getUid(edges[j])<<endl;
            }
          }

          // create face in local mesh and attach it to the matching face in pmesh
          gent=F_whatIn(fc);
          faces[i]=M_createF(tmpMesh, 3, edges, e_dirs, gent);
          EN_attachDataPtr((pEntity)fc,localPtr,faces[i]);
          //      cout<<"("<<fc<<")"<<EN_getUid(fc)<<"->("<<faces[i]<<")"<<EN_getUid(faces[i])<<endl;
        }
      }


      // create new regions
      gent=(pGEntity)R_whatIn(rgn);
      M_createR(tmpMesh, 4, faces, f_dirs, gent);
    }

    //    cout<<"copies: ";
    vector<pEntity>::iterator liter;
    for(liter=oris.begin(); liter!=oris.end(); liter++) {
      pEntity ori=*liter;
      if( ori )
        if( EN_getDataPtr((pEntity)ori,localPtr,&temp_ptr) ) {
          pEntity copy = (pEntity)temp_ptr;
          copies.push_back(copy);
//        cout<<"("<<ori<<")"<<EN_getUid(ori)<<"->";
//        cout<<"("<<copy<<")"<<EN_getUid(copy)<<" ";
        }
    }
    //   cout<<endl;

    iter=0;
    while( rgn=(pRegion)PList_next(regions,&iter) )
    {
      for( i=0;i<4;i++ )
      {
        fc=R_face(rgn,i);
        if( EN_getDataPtr((pEntity)fc,localPtr,&temp_ptr) )
        {
          EN_deleteData((pEntity)fc,localPtr);
          for( j=0;j<3;j++ )
            {
            eg=F_edge(fc,j);
            if( EN_getDataPtr((pEntity)eg,localPtr,&temp_ptr) )
            {
              EN_deleteData((pEntity)eg,localPtr);
              for( k=0;k<2;k++ )
              {
                vt=E_vertex(eg,k);
                if( EN_getDataPtr((pEntity)vt,localPtr,&temp_ptr) ) {
                  EN_deleteData((pEntity)vt,localPtr);
                }
              }
            } // if eg
          } // for j
        } // if fc
      } // for i
    } // while

    MD_deleteMeshDataId(localPtr);
    return tmpMesh;
  }


  double E_lengthSq(pEdge edge)
  {
    pVertex v1,v2 ;
    pPoint  pt ;
    double  org[3],org2[3];
    
    v1 = E_vertex(edge,0) ;
    v2 = E_vertex(edge,1) ;
    V_coord(v1,org) ;
    V_coord(v2,org2) ;
    org[0] -= org2[0];
    org[1] -= org2[1];
    org[2] -= org2[2];
    
    return org[0]*org[0] + org[1]*org[1] + org[2]*org[2] ;
  }


  // given an edge and a location, compute the squre of d/H ratio for curvature control
  double E_dOverH(pEdge edge, double xyz[3]) {
    double exyz[2][3];
    double vec_a[3], vec_b[3], vec[3];
    double tmp;
  
    for( int i=0; i<2; i++ )
      V_coord(E_vertex(edge,i),exyz[i]);
      
    diffVt(exyz[1],exyz[0],vec_a);
    diffVt(xyz,exyz[0],vec_b);
    crossProd(vec_a,vec_b,vec);
    tmp=dotProd(vec_a,vec_a);

    return dotProd(vec,vec)/(tmp*tmp);
  }

  // given an edge and a vertex, get the face both bound
  pFace F_exists_2(pEdge edge, pVertex vertex) {
    pFace face;
    int i, num=E_numFaces(edge);
    for( i=0; i<num; i++ ) {
      face=E_face(edge,i);
      if( F_edOpVt(face,edge)==vertex )
	return face;
    }
    return 0;
  }

  pPList getCavityClosure(pPList rgns, pMeshDataId bdryFaceFlag)
  {
    pRegion region;
    pFace face;
    int i, value;

    void *iter=0;
    while( region=(pRegion)PList_next(rgns,&iter) ) 
      for( i=0; i<R_numFaces(region); i++ ) {
	face=R_face(region,i);
	if( EN_getDataInt((pEntity)face,bdryFaceFlag,&value) )
	  EN_deleteData((pEntity)face,bdryFaceFlag);
	else
	  EN_attachDataInt((pEntity)face,bdryFaceFlag,R_faceDir(region,i));
      }

    pPList Bfaces=PList_new();
    iter=0;
    while( region=(pRegion)PList_next(rgns,&iter) ) 
      for( i=0; i<R_numFaces(region); i++ ) {
	face=R_face(region,i);
	if( EN_getDataInt((pEntity)face,bdryFaceFlag,&value) ) 
	  PList_append(Bfaces, face);
      }
    
    return Bfaces;
  }

  // get the two faces of the given region that the given edge bounds
  pPList R_edAdjFcs(pRegion region,pEdge edge)
  {
    pPList faces=PList_new();
    pFace face;

    for( int i=0; i<R_numFaces(region); i++ ) {
      face=R_face(region,i);
      if( F_inClosure(face,(pEntity)edge) )
	PList_append(faces,face);
    }
    return faces;
  }   


  struct greater_abs
  {
    bool operator () (const double &a, const double &b)
    {
      return fabs(a) > fabs(b);
    }
  };
  
  long eigen (double pos[3][3], double e[3][3], double v[3])
  {            
    /// characteristic polynomial of T : find v root of
    /// v^3 - I1 v^2 + I2 T + I3 = 0
    /// I1 : first invariant , trace(T)
    /// I2 : second invariant , 1/2 (I1^2 -trace(T^2))
    /// I3 : third invariant , det T
    double I[4];
    I[3] = 1.0;
    I[2] = - trace(pos);
    I[1] = 0.5 * (I[2]*I[2] - trace2(pos));
    I[0] = - det(pos);

    //    printf (" %lf x^3 +  %lf x^2 + %lf x + %lf = 0\n",
    //	    I[3],I[2],I[1],I[0]);

    long nbEigen = FindCubicRoots (I,v);
    
    std::sort(v,v+3, greater_abs() );
    
    //    printf ("nbEigen = %d %12.5E %12.5E %12.5E\n",nbEigen,v[0],v[1],v[2]);
    
    double result[12];
    int nb_vec=0;

    while(1)
      {
        double a[9] = {pos[0][0]-v[nb_vec],pos[0][1],pos[0][2],
                       pos[1][0],pos[1][1]-v[nb_vec],pos[1][2],
                       pos[2][0],pos[2][1],pos[2][2]-v[nb_vec]};
	
        double eps = 1.e-3;
        int nb = 0;
        while (1)
          {
            nb = NullSpace (a,result,eps,3);
            if (nb != 0)break;
            eps *= 2.0;
          }
        int kk=0;
        for (int i=nb_vec;i<nb+nb_vec;i++)
          {
	    e[i][0] = result[0+kk*3];
	    e[i][1] = result[1+kk*3];
	    e[i][2] = result[2+kk*3];
	    normVt (e[i], e[i]);
	    //	    printf("%d: %f (%f, %f, %f)\n",i,v[nb_vec],e[i][0],e[i][1],e[i][2]);
            kk++;
	    if (i == 2) {
	      if( !checkUnitaryOthoganal(e) )
		{
		  
	          printf (" %lf x^3 +  %lf x^2 + %lf x + %lf = 0\n",I[3],I[2],I[1],I[0]);
		  printf ("nbEigen = %d %12.5E %12.5E %12.5E\n",nbEigen,v[0],v[1],v[2]);
		  for(int jj=0; jj<3; jj++ )
		  	printf("%d: %f (%f, %f, %f)\n",jj,v[jj],e[jj][0],e[jj][1],e[jj][2]);
		  printf("nb=%d nb_vec=%d nbEigen=%d\n",nb,nb_vec,nbEigen);
		  printf("WARNING: not orthoganal (adaptUtil::eigen)\n\n");
		}
	      return nbEigen;
  	    }
          }
        nb_vec += nb;
        if (nb_vec == 3)
	  return nbEigen;
	if( nb_vec > 3 )
	  throw;
        if (nb > 3)
	  throw;
      }
  }
  
  int checkUnitaryOthoganal(double e[3][3])
  {
    int i;
    double dot, n[3];  
    double tol=1e-14;
    double cosalpha, alpha;
    
    for( i=0; i<3; i++ ) {
      dot=dotProd(e[i],e[i]);
      if( dot < tol ) 
	{ printf("the %d vector in zero length\n",i); return 0; }
      if( ABS(dot - 1.) > tol )
	{ printf("the %d vector not unitary. lenthSq=%f\n",i,dot); return 0; }
    }
    dot=dotProd(e[0],e[1]);
    cosalpha=dot/sqrt(dotProd(e[0],e[0])*dotProd(e[1],e[1]));
    alpha = 57.295718*acos(cosalpha);
    if( alpha > 95 && alpha<85 ) {
      printf("first two base vectors not orthognal.  %f\n",alpha);
      return 0;
    }
    crossProd(e[0],e[1],n);
    dot=dotProd(e[2],n);
    cosalpha=dot/sqrt(dotProd(e[2],e[2])*dotProd(n,n));
    alpha = 57.295718*acos(cosalpha);
    if( alpha < 175 && alpha>5 ) {
      printf("third base vector not orthognal to first two.  %f\n", alpha);
      return 0;
    }
    return 1;
  }
  
  double trace (double pos[3][3])
  {
    return pos[0][0] + pos[1][1] + pos[2][2];
  }

  double trace2 (double pos[3][3])
  {
    double a00 =  pos[0][0] * pos[0][0] + 
      pos[1][0] * pos[0][1] + 
      pos[2][0] * pos[0][2]; 
    double a11 =  pos[1][0] * pos[0][1] + 
      pos[1][1] * pos[1][1] + 
      pos[1][2] * pos[2][1]; 
    double a22 =  pos[2][0] * pos[0][2] + 
      pos[2][1] * pos[1][2] + 
      pos[2][2] * pos[2][2];

    return a00 + a11 + a22;
  }

  double det (double pos[3][3])
  {
    return pos[0][0] * (pos[1][1] * pos[2][2] - pos[1][2] * pos[2][1]) -
      pos[0][1] * (pos[1][0] * pos[2][2] - pos[1][2] * pos[2][0]) +
      pos[0][2] * (pos[1][0] * pos[2][1] - pos[1][1] * pos[2][0]);
  }

  // solve x^2 + b x + c = 0
  // x[2] is always set to be zero
  long FindQuadraticRoots(const double b, const double c, double x[3])
  {
    //    printf("Quadratic roots\n");
    x[2]=0.0;
    double delt=b*b-4.*c;
    if( delt >=0 ) {
      delt=sqrt(delt);
      x[0]=(-b+delt)/2.0;
      x[1]=(-b-delt)/2.0;
      return 3;
    }
    
    printf("Imaginary roots, impossible, delt=%f\n",delt);
    return 1;
  }
  
  // solve x^3 + a1 x^2 + a2 x + a3 = 0
  long FindCubicRoots(const double coeff[4], double x[3])
  {
    double a1 = coeff[2] / coeff[3];
    double a2 = coeff[1] / coeff[3];
    double a3 = coeff[0] / coeff[3];
    
    if( ABS(a3)<1.0e-8 ) 
      return FindQuadraticRoots(a1,a2,x);
    
    double Q = (a1 * a1 - 3 * a2) / 9.;
    double R = (2. * a1 * a1 * a1 - 9. * a1 * a2 + 27. * a3) / 54.;
    double Qcubed = Q * Q * Q;
    double d = Qcubed - R * R;
    
    //    printf ("d = %22.15e Q = %12.5E R = %12.5E Qcubed %12.5E\n",d,Q,R,Qcubed);

    /// three roots, 2 equal 
    if(Qcubed == 0.0 || fabs ( Qcubed - R * R ) < 1.e-8 * (fabs ( Qcubed) + fabs( R * R)) )
      {
        double theta;
        if (Qcubed <= 0.0)theta = acos(1.0);
        else if (R / sqrt(Qcubed) > 1.0)theta = acos(1.0); 
        else if (R / sqrt(Qcubed) < -1.0)theta = acos(-1.0); 
        else theta = acos(R / sqrt(Qcubed));
        double sqrtQ = sqrt(Q);
        //      printf("sqrtQ = %12.5E teta=%12.5E a1=%12.5E\n",sqrt(Q),theta,a1);
        x[0] = -2 * sqrtQ * cos( theta           / 3) - a1 / 3;
        x[1] = -2 * sqrtQ * cos((theta + 2 * M_PI) / 3) - a1 / 3;
        x[2] = -2 * sqrtQ * cos((theta + 4 * M_PI) / 3) - a1 / 3;
      return (3);
      }

    /* Three real roots */
    if (d >= 0.0) {
      double theta = acos(R / sqrt(Qcubed));
      double sqrtQ = sqrt(Q);
      x[0] = -2 * sqrtQ * cos( theta           / 3) - a1 / 3;
      x[1] = -2 * sqrtQ * cos((theta + 2 * M_PI) / 3) - a1 / 3;
      x[2] = -2 * sqrtQ * cos((theta + 4 * M_PI) / 3) - a1 / 3;
      return (3);
    }
    
    /* One real root */
    else {
      printf("IMPOSSIBLE !!!\n");

      double e = pow(sqrt(-d) + fabs(R), 1. / 3.);
      if (R > 0)
        e = -e;
      x[0] = (e + Q / e) - a1 / 3.;
      return (1);
    }
  }

  
#define MAXN 32
#define R(i,j)  result[n*(i)+(j)]
  
  long NullSpace(const double *a, double *result, double eps, long n)
  {
    int r[MAXN], c[MAXN];
    register long i, j, k;
    int jj, kk, t;
    double max, temp;
    int ec;
    
    for (i = 0; i < n; i++)
      r[i] = c[i] = -1;                 /* Reset row and column pivot indices */
    
    // copy the input matrix if not in place
    if (result != a) 
      for (i = 0; i < n*n; i++)  
        result[i] = a[i];
    // rest of algorithm is in place wrt result[]
    
    for (i = 0; i < n; i++) {
      /* Find the biggest element in the remaining submatrix
       * for the next full pivot.
       */
      max = 0.0;
      for (k = 0; k < n; k++) {
        if (r[k] < 0) {
          for (j = 0; j < n; j++) {
            if ((c[j] < 0) && ((temp = fabs(R(k, j))) > max)) {
              kk = k;
              jj = j;
              max = temp;
            }
          }
        }
      }
      if (max < eps)
        break;          /* Consider this and all subsequent pivots to be zero */

      c[jj] = kk;                                       /* The row */
      r[kk] = jj;                                       /* and column of the next pivot */
      
      temp = 1.0 / R(kk, jj);
      R(kk, jj) = 1.0;
      for (j = 0; j < n; j++)           /* Should this be for j != jj ? */
        R(kk, j) *= temp;               /* Row equilibration */
      
      for (k = 0; k < n; k++) { /* Row elimination */
        if (k == kk)
          continue;                     /* Don't do a thing to the pivot row */
        temp = R(k, jj);
        R(k, jj) = 0.0;
        for (j = 0; j < n; j++) {
          R(k, j) -= temp * R(kk, j);   /* Subtract row kk from row k */
          if (fabs(R(k, j)) < eps)
            R(k, j) = 0.0;      /* Flush to zero if too small */
        }
      }
    }
    
    /* Sort into a truncated triangular matrix */
    for (j = 0; j < n; j++) {           /* For all columns... */
      while ((c[j] >= 0) && (j != c[j])) {
        for (k = 0; k < n; k++) {
          if (r[k] < 0) {
            /* Aha! a null column vector */
            temp = R(k, j);     /* Get it on top */
            R(k, j) = R(k, c[j]);
            R(k, c[j]) = temp;
          }
        }
        t = c[j];                /* Twiddle until pivots are on the diagonal */
        c[j] = c[t];
        c[t] = t;
      }
    }
    
    /* Copy the null space vectors into the top of the A matrix */
    ec = 0;
    for (k = 0; k < n; k++) {
      if (r[k] < 0) {
        R(k, k) = 1.0;                  /* Set the pivot equal to 1 */
        if (ec != k) {
          for (j = 0; j < n; j++) {
            R(ec, j) = R(k, j);
          }
        }
        ec++;
      }
    }
    /* The first  ec  rows of the matrix  a  are the vectors which are
     * orthogonal to the columns of the matrix  a.
     */
    return (ec);
  }    



void M_checkSize(pMesh mesh,pSField field,double &max,double &min) 
  {
    EIter eit=M_edgeIter(mesh);
    pEdge edge;
    double size;
    max=0; min=10e14;
    while( edge=EIter_next(eit) ) 
    {
      if (E_typeInBL(edge))
        continue;

      if (!EN_okTo(DELETE,(pEntity)edge))
        continue;
      if (!EN_okTo(MOVE,(pEntity)edge))
        continue;
      size=field->lengthSq(edge);

      if( size > max )
        max=size;
      if( min > size )
        min=size;
    }
    EIter_delete(eit);

#ifdef MA_PARALLEL
    M_unify(&max,&min);
#endif
    return;
  }
  
  void M_checkSizeBL(pMesh mesh,pSField field,double &max,double &min)
  {
    EIter eit=M_edgeIter(mesh);
    pEdge edge;
    pEdge minEdge = 0, maxEdge = 0;
    double size;
    max=0; min=10e14;

    pEdge edg;
    while( edge=EIter_next(eit) ) 
    {
      // ONLY CHECK LENGTHS OF LAYER EDGES (IN METRIC SPACE)
      if(E_typeInBL(edge) != eLAYER)
        continue;

      if (!EN_okTo(DELETE,(pEntity)edge))
        continue;
      if (!EN_okTo(MOVE,(pEntity)edge))
        continue;
      size=field->lengthSq(edge);

      if( size > max ) 
      {
        max=size;
        maxEdge = edge;
      }
      if( min > size ) 
      {
        min=size;
        minEdge = edge;
      }
    }
    EIter_delete(eit);

#ifdef MA_PARALLEL
    M_unify(&max,&min);
#endif

  }

  // interior mesh connectivity analysis
  void M_connectivityAnalysis(pMesh mesh)
  {
    pFace face;
    pEdge edge;
    double worst, aver, best;
    FILE *efout = fopen("E_conn.dat","w");
    
    EIter eiter=M_edgeIter(mesh);
    while( edge=EIter_next(eiter) ) {
      if( E_whatInType(edge)!=Gregion ) 
	continue;      
      E_volumeRatio(edge,&worst,&aver,&best);
      fprintf(efout,"%d  %8.5f %8.5f %8.5f\n", 
	      E_numFaces(edge),worst,aver,best);
    }
    EIter_delete(eiter);
    fclose(efout);

    FILE *ffout = fopen("F_conn.dat","w");
    FIter fiter=M_faceIter(mesh);
    pPList edges, tmp;;
    void *iter;
    int nmax, nmin, nn, d;
    while( face=FIter_next(fiter) ) {
      if( F_region(face,0)==0 || F_region(face,1)==0 ) 
	continue;   

      edges=R_edges(F_region(face,0),1);
      tmp=R_edges(F_region(face,1),1);
      iter=0;
      while( edge=(pEdge)PList_next(tmp,&iter) ) {
	if ( F_inClosure(face,(pEntity)edge ) )
	  continue;
	PList_append(edges,edge);
      }
      PList_delete(tmp);

      nmax=0; nmin=99999; aver=0; d=0;
      iter=0;
      while( edge=(pEdge)PList_next(edges,&iter) ) {
	if( E_whatInType(edge)!=Gregion )
	  continue;
	nn=E_numFaces(edge);
	if( nn>nmax ) nmax=nn;
	if( nn<nmin ) nmin=nn;
	aver += nn;
	++d;
      }
      aver /= (float)d;
      PList_delete(edges);
      fprintf(ffout,"%8.5f  %d %8.5f %d\n", 
	      F_volumeRatio(face),nmin,aver,nmax);
    }
    FIter_delete(fiter);
    fclose(ffout);
  }

//    void M_checkConn_2(pMesh mesh)
//    {
//      int n, edgeFaces[20], vertEdges[40];
//      pVertex vertex;
//      pEdge edge;
//      for( n=0; n<20; n++ )
//        edgeFaces[n]=0;
//      for( n=0; n<40; n++ )
//        vertEdges[n]=0;

//      EIter eiter=M_edgeIter(mesh);
//      while( edge=EIter_next(eiter) ) 
//        if( E_whatInType(edge)==Gregion ) {
//  	n=E_numFaces(edge);
//  	if( n>19 )
//  	  n=19;
//  	edgeFaces[n]++;
//        }
//      EIter_delete(eiter);

//      printf("Info: edge valance distribution\n");
//      for( n=0; n<20; n++ )
//        printf(" %d      %d \n",n,edgeFaces[n]);

//      VIter viter=M_vertexIter(mesh);
//      while( vertex=VIter_next(viter) ) 
//        if( V_whatInType(vertex)==Gregion ) {
//  	n=V_numEdges(vertex);
//  	if( n>39 )
//  	  n=39;
//  	vertEdges[n]++;
//        }
//      VIter_delete(viter); 
    
//      printf("Info: vertex valance distribution\n");
//      for( n=0; n<40; n++ )
//        printf(" %d      %d \n",n,vertEdges[n]);
//    }

//    void improveConn(pMesh mesh, pSField field, SSList<pVertex> *verts)
//    {  
//      MeanRatio *shpMeasure=new MeanRatio(field);
//      evalResults *result=new evalResults();
//      edgeSwapMod eswp(mesh,field,shpMeasure,result);

//      SSListIter<pVertex> viter(*verts);
//      pVertex vertex;
//      pEdge edge;
//      int nswap=0;
//      int num;

//      pPList edges=PList_new();
//      while(viter(vertex)) {

//        num=V_getSwapEdges(vertex,&edges);
//        for(;;) {
//  	if( !num || PList_size(edges)==0 )
//  	  { viter.remove(); break; }
//  	edge = getLongestEdge(edges,field);
//          PList_remItem(edges,(void *)edge);

//  	shpMeasure->setDefaultAcptValue();
//  	eswp.setSwapEdge(edge);
//  	if( !eswp.topoCheck() ) 
//  	  continue; 
//  	if( !eswp.geomCheck() ) 
//  	  continue;
//  	eswp.apply();
//          num--;
//  	nswap++;
//        }
//        PList_clear(edges);
//      }
//      PList_delete(edges);
//      delete shpMeasure;
//      delete result;
//      cout<<nswap<<" edge swap applied"<<endl;
//    }

  pEdge getLongestEdge(pPList edlist, pSField field)
  {
    pEdge edge, longEdge;
    double lenSq, maxLenSq=0;
    void *iter=0;

    while( edge=(pEdge)PList_next(edlist,&iter) ) {
      lenSq=field->lengthSq(edge);
      if( lenSq > maxLenSq )
        {
          longEdge=edge;
          maxLenSq=lenSq;
        }
    }

    return longEdge;
  }

  int V_getSwapEdges(pVertex vertex, pPList *edges)
  {
    pEdge edge;
    int i;
    int ne=V_numEdges(vertex);
    
    int type=V_whatInType(vertex);
    for( i=0; i<ne; i++ ) {
      edge=V_edge(vertex,i);
      if( type == Gregion )
         PList_append(*edges,edge);
      else {
         if( E_whatInType(edge) !=Gregion )
            PList_append(*edges,edge);
      }
    }
    int numswp=PList_size(*edges);
    if( type == Gregion )
       numswp-= 17;
    else
       numswp -= 8;

    if( numswp<0 )
       numswp=0;
    return numswp;
  }

  int E_volumeRatio(pEdge edge, double *max, 
		     double *aver, double *min)
  {
    std::vector<pFace> faces;
    std::vector<pFace>::iterator fIter;
    pMeshDataId touched=MD_newMeshDataId("touchedEnt");  

    // determine the faces
    pPList ergns=E_regions(edge);
    void *iter=0;
    pFace face;
    pRegion region;
    int i, value;
    while( region=(pRegion)PList_next(ergns,&iter) ) 
      for( i=0; i<4; i++ ) {
	face=R_face(region,i);
	if( !EN_getDataInt((pEntity)face,touched,&value) ||
	    F_whatInType(face)==Gregion ) {
	  faces.push_back(face);
	  EN_attachDataInt((pEntity)face,touched,1);
	}
      }
    PList_delete(ergns);

    // clean the tag
    for( fIter=faces.begin(); fIter!=faces.end(); fIter++ )
      EN_deleteData((pEntity)(*fIter),touched);
    MD_deleteMeshDataId(touched);

    // compute volume ratio information
    *max=0;
    *aver=0;
    *min=99999;
    iter=0;
    int num=0;
    double volRatio;
    for( fIter=faces.begin(); fIter!=faces.end(); fIter++ ) {
      volRatio=F_volumeRatio(*fIter);
      if( !volRatio )
	continue;
      if( volRatio<0 ) 
	return -1;
      if( *max < volRatio ) 
	*max=volRatio;
      if( *min > volRatio ) 
	*min=volRatio;
      *aver += volRatio;
      ++num;
    }
    *aver /= num;
    return 1;
  }

  double V_worstVolumeRatio(pVertex vt, std::vector<pFace> *pfaces)
  {
    std::vector<pFace>::iterator fIter;

    if( pfaces->size()==0 ) {
      pMeshDataId touched=MD_newMeshDataId("touchedEnt");  
    
      pPList vrgns=V_regions(vt);
      void *iter=0;
      pFace face;
      pRegion region;
      int i, value;
      while( region=(pRegion)PList_next(vrgns,&iter) ) 
	for( i=0; i<4; i++ ) {
	  face=R_face(region,i);
	  if( !EN_getDataInt((pEntity)face,touched,&value) ) {
	    pfaces->push_back(face);
	    EN_attachDataInt((pEntity)face,touched,1);
	  }
	}
      PList_delete(vrgns);
      
      for( fIter=pfaces->begin(); fIter!=pfaces->end(); fIter++ )
	EN_deleteData((pEntity)(*fIter),touched);
      MD_deleteMeshDataId(touched);
    }

    double volRatio, max=0;
    for( fIter=pfaces->begin(); fIter!=pfaces->end(); fIter++ ) {
      volRatio=F_volumeRatio(*fIter);
      if( !volRatio )
	continue;
      if( volRatio<0 ) 
	return -1;
      if( max < volRatio )
        max=volRatio;
    }
    return max;  
  }


//    double V_worstVolumeRatio(pVertex vt)
//    {
//      pPList vfaces=V_faces(vt);
//      pPList vrgns=V_regions(vt);
//      void *iter=0;
//      pFace face;
//      pRegion region;
//      while( region=(pRegion)PList_next(vrgns,&iter) ) {
//        face=R_vtOpFc(region,vt);
//        PList_append(vfaces,face);
//      }
//      PList_delete(vrgns);
    
//      iter=0;
//      double volRatio, max=0;
//      while( face=(pFace)PList_next(vfaces,&iter) ) {
//        volRatio=VolumeRatioCrossFace(face);
//        if( !volRatio )
//  	continue;
//        if( volRatio<0 ) { 
//  	PList_delete(vfaces);
//  	return -1;
//        }
//        if( max < volRatio )
//          max=volRatio;
//      }
//      PList_delete(vfaces);
//      return max;
//    }

  double F_volumeRatio(pFace face) 
  {
    pRegion region=F_region(face,0);
    pRegion region_2=F_region(face,1);
    double v0,v1, volRatio;

    if( !region || !region_2 )
      return 0;

    v0=R_volume(region);
    v1=R_volume(region_2);
    if( v0<0. || v1<0. )
      return -1;
    volRatio=v0/v1;
    if( volRatio < 1 )
      volRatio=1./volRatio;
    return volRatio;
  }

  int F_ratio2(pFace face, double &lenRatio, double &alpha) 
  {
    pPList edges;
    pRegion rgn[2];
    pEdge edge, maxEdge;
    double lenSq, maxLenSq[2], maxLen[2], xyz0[3], xyz1[3], vec[2][3];
      void *iter;
    int i;

    rgn[0]=F_region(face,0);
    rgn[1]=F_region(face,1);

    if( !rgn[0] || !rgn[1] )
      return 0;

    for( i=0; i<2; i++ ) {
      edges=R_edges(rgn[i],1);
      iter=0; 
      maxLenSq[i]=0;
      while( edge=(pEdge)PList_next(edges,&iter) ) {
	lenSq=adaptUtil::E_lengthSq(edge);
	if( lenSq > maxLenSq[i] ) {
	  maxLenSq[i]=lenSq;
	  maxEdge=edge;
	}
      }
      PList_delete(edges);

      V_coord(E_vertex(maxEdge,0),xyz0);
      V_coord(E_vertex(maxEdge,1),xyz1);
      diffVt(xyz1,xyz0,vec[i]);	      
    }

    maxLen[0]=sqrt(maxLenSq[0]);
    maxLen[1]=sqrt(maxLenSq[1]);
    lenRatio=maxLen[0]/maxLen[1];
    if( lenRatio < 1 )
      lenRatio=1./lenRatio;

    alpha = 57.295718*acos( ABS(dotProd(vec[0],vec[1])/(maxLen[0]*maxLen[1])) );
    return 1;
  }

  
  void M_checkRatio(pMesh mesh)
  {
    //    void *iter=0;

    // element number
//      printf("\n# of elements: %d   # of vertices: %d\n",
//  	   M_numRegions(mesh), M_numVertices(mesh));

//      // check element shape
//      pRegion region, worRgn;
//      double shp, worstShp=2., avgShp=0;
//      MeanRatio myShape(0);
//      int numR=0;

//      RIter r_iter=M_regionIter(mesh);
//      while( region=RIter_next(r_iter) ) {
//        if( !EN_okTo(DELETE,(pEntity)region) )
//          continue;
//        myShape.R_shape(region,&shp);
//        if( shp<worstShp ) {
//  	worstShp=shp;
//  	worRgn=region;
//        }
//        numR++;
//        avgShp += shp;
//      }
//      avgShp /= numR;
//      RIter_delete(r_iter);
//      printf("Element Shape Info: worst = %f   average = %f\n",
//  	   worstShp,avgShp);
    
    // check element size
//      pEdge edge;
//      double len, max=0, min=10e14, rms=0;

//      EIter e_iter=M_edgeIter(mesh);
//      while( edge=EIter_next(e_iter) ) {
//        if (!EN_okTo(DELETE,(pEntity)edge))
//  	continue;
//        if (!EN_okTo(MOVE,(pEntity)edge))
//  	continue;
//        len=sqrt(field->lengthSq(edge));
//        if( len > max )
//  	max=len;
//        if( len < min )
//  	min=len;
//        len = len-1;
//        rms += len*len;
//      }
//      EIter_delete(e_iter);
//      rms = sqrt(rms/M_numEdges(mesh));
//      printf("Element Size Info:  sigma = %f   range: (%f,%f)\n",
//  	   rms,min,max);
    
    // check smoothness
    pFace face;
    pFace maxRSFace, maxRLFace;
    double RS, RL, alpha;
    double maxRS=0, avgRS=0, maxRSRL, maxRSalpha;
    double maxRL=0, maxRLRS, maxRLalpha;
    int numF,less15=0, less20=0, less30=0, above30=0;
    
    FIter f_iter=M_faceIter(mesh);
    numF=0;
    while( face=FIter_next(f_iter) ) {

      // compute ratio
      RS=F_volumeRatio(face);
      if( !RS )
	continue;  
      F_ratio2(face,RL,alpha);
    
      // max volume ratio
      if( RS > maxRS ) {
	maxRS = RS;
	maxRSRL = RL;
	maxRSalpha = alpha;
	maxRSFace =face;
      }
      avgRS += RS;
      if( RS < 1.5 ) less15++;
      else if( RS < 1.9999 ) less20++;
      else if( RS < 3.0 ) less30++;
      else above30++;
      numF++;

      // max length ratio
      if( RL > maxRL ) {
	maxRL = RL;
	maxRLRS = RS;
	maxRLalpha = alpha;
	maxRLFace =face;
      }
    }
    FIter_delete(f_iter);
    avgRS /= numF;
    printf("Mesh Smooth Info:   maxRs = %f   Rl = %f  alpha = %f averageRs = %f\n",
	   maxRS,maxRSRL,maxRSalpha,avgRS);
    printf("                    maxRl = %f   Rs = %f  alpha = %f\n",
	   maxRL,maxRLRS,maxRLalpha);
    printf("         <1.5  %10.8f  %d\n", (float)less15/(float)numF,less15);
    printf("         <2.0  %10.8f  %d\n", (float)less20/(float)numF,less20);
    printf("         <3.0  %10.8f  %d\n", (float)less30/(float)numF,less30);
    printf("         >3.0  %10.8f  %d\n", (float)above30/(float)numF,above30);

#ifdef MVTK
    visUtil::mvtkAddMRgn(F_region(maxRSFace,0));
    visUtil::mvtkAddMRgn(F_region(maxRSFace,1));
    mvtkActivate();
    mvtkRemoveAllMEnts();
    visUtil::mvtkAddMRgn(F_region(maxRLFace,0));
    visUtil::mvtkAddMRgn(F_region(maxRLFace,1));
    mvtkActivate();
    mvtkRemoveAllMEnts();
#endif
  }

  void F_shapeInfo(pFace face) {
    double xyz[3][3];
    double cosangs[3];
    int i;
    
    F_coord(face,xyz);
    fromMeshTools::XYZ_FAngles(xyz,cosangs);
    
    cout<<"Three interior angle of triangle: ";
    for( i=0; i<3; i++ ) 
      cout<<57.295718*acos(cosangs[i])<<"  ";
    cout<<endl;
    
    cout<<"Three edge length of triangle:";
    for( i=0; i<3; i++ )
      cout<<sqrt(XYZ_distance2(xyz[i],xyz[(i+1)%3]))<<"  ";
    cout<<endl;
    return;
  }

  void R_edgesInfo(pRegion region, pSField pSizeField)
  {
    pEdge edge;
    pPList edges=R_edges(region,1);
    void *iter=0;
    printf("R_edgesInfo:  region=%p pSField=%p\n",region,pSizeField);
    while( edge=(pEdge)PList_next(edges,&iter) )
      printf(" %p  %f \n", edge, sqrt(pSizeField->lengthSq(edge)));
    printf("\n");
    PList_delete(edges);
  }

  int R_countLongLengthSq(pRegion region,pSField pSizeField, double upperBoundSq)
  {
    pEdge edge;
    pPList edges=R_edges(region,1);
    void *iter=0;
    int count = 0;
    double lenSq;
    while( edge=(pEdge)PList_next(edges,&iter) )
      {
        lenSq=pSizeField->lengthSq(edge);
        if( lenSq>upperBoundSq )
          count++;
      }
    PList_delete(edges);
    return count;
  }

  double R_maxTominLengthSq(pRegion region,pSField pSizeField)
  {
    pEdge edge;
    pPList edges=R_edges(region,1);
    void *iter=0;
    double lenSq, minSq, maxSq;
    edge=(pEdge)PList_next(edges,&iter);
    minSq=pSizeField->lengthSq(edge);
    maxSq=minSq;
    while( edge=(pEdge)PList_next(edges,&iter) )
      {
	lenSq=pSizeField->lengthSq(edge);
	if( lenSq<minSq )
	  minSq=lenSq;
	if( lenSq>maxSq )
	  maxSq=lenSq;	  
      }
    PList_delete(edges);
    return (maxSq/minSq);
  } 

  int E_swpCheckPer(pEdge edge) {
    if( E_whatInType(edge)==Gface ) {
      pGFace gf=(pGFace)E_whatIn(edge);
      if( GF_periodic(gf,0) || GF_periodic(gf,1) ) { 

	pFace face;
	pVertex vt;
	double par[2][3];
	double span, period, low, high;
	double tol=M_getTolerance();
	int i,j;
	
	// find the two ends of the new boundary mesh edge
	j=0;
	for( i=0; i<E_numFaces(edge); i++ ) {
	  face=E_face(edge,i);
	  if( F_whatInType(face)==Gface ) {
	    vt=F_edOpVt(face,edge);
	    V_reparamOnGFace(vt,gf,par[j++]);
	  }
	  if( j==2 ) break;
	}
	
	// check parametric span
	for( i=0; i<2; i++ ) {
	  
	  if(GF_periodic(gf,i)) {
	    
	    if( ifDegenerated(gf, par[0], tol) == (i+1)%2 )
	      continue;
	    if( ifDegenerated(gf, par[1], tol) == (i+1)%2 )
	      continue;
	    
	    GF_parRange(gf,i,&low,&high);
	    period=high-low;
	    span=ABS(par[0][i]-par[1][i]);
	    if( (period*MAX_PERIODIC_SPAN<span) && 
		(period*(1-MAX_PERIODIC_SPAN)>span) ) 
	      return 0;
	  } // end if
	}  // end for
      }
    }
    return 1;
  }

  
  double F_angleToGNormal(pFace face)
  {
    if( F_whatInType(face)==Gface ) {
      pVertex vts[3];
      int i;
      pGFace gf=(pGFace)F_whatIn(face);
      pPList vertices=F_vertices(face,1);
      for(i=0;i<PList_size(vertices) && i<3;++i)
	vts[i]=(pVertex)PList_item(vertices,i);
      PList_delete(vertices);
      return F_angleToGNormal(vts[0],vts[1],vts[2],gf);
    }
    
    return 0.0;
  }


  /* return the signed cosine angle square */
  double F_angleToGNormal(pVertex v0, pVertex v1, pVertex v2, pGFace gf)
  {
    double xyz[3][3], x1[3], x2[3];
    double gNormal[3], mNormal[3], tmp, ll0, ll1;
    int i;
    
    // first estimate model normal at the face defined by three vertices  
    V_getNormal(gf,v0,xyz[0]);
    V_getNormal(gf,v1,xyz[1]);
    V_getNormal(gf,v2,xyz[2]);
    
    gNormal[0]=0.0;
    gNormal[1]=0.0;
    gNormal[2]=0.0;
    for( i=0; i<3; i++ ) {
      gNormal[0] += xyz[i][0];
      gNormal[1] += xyz[i][1];
      gNormal[2] += xyz[i][2];
    }
    
    // get the normal of the mesh face
    V_coord(v0,xyz[0]);
    V_coord(v1,xyz[1]);
    V_coord(v2,xyz[2]);
    diffVt(xyz[1],xyz[0],x1);
    diffVt(xyz[2],xyz[0],x2);
    crossProd(x1,x2,mNormal);
    
    // computer the angle between the two normals
    double tol=M_getTolerance();
    ll0=dotProd(mNormal,mNormal);
    if( ll0<tol )
      return 0;
    ll1=dotProd(gNormal,gNormal);
    if( ll1<tol )
      return 0;
    tmp=dotProd(mNormal,gNormal);
    if( tmp > 0.0 )
      return tmp*tmp/(ll0*ll1);
    
    return -tmp*tmp/(ll0*ll1);
  }
  
  /* oriMinAngle:  signed cosine 
     oriMaxAngToNormal: signed cosine square  */
  void E_swpGetOriAngles(pEdge swpedge,double *oriMinAngle,double *oriMaxAngToNormal)
  {
    pFace face;
    double xyz[3][3], cosangs[3];
    double sqrCosangToNormal[2], minAng[2];
    int j;
    
    for( j=0; j<2; j++ ) {
      face=E_face(swpedge,j);
      sqrCosangToNormal[j]=F_angleToGNormal(face);
      
      F_coord(face,xyz);
      fromMeshTools::XYZ_FAngles(xyz,cosangs);
      minAng[j]=MAX(cosangs[0],MAX(cosangs[1],cosangs[2]));
    }
    
    *oriMaxAngToNormal=MIN(sqrCosangToNormal[0],sqrCosangToNormal[1]);
    *oriMinAngle=MAX(minAng[0],minAng[1]);
#ifdef DEBUG
    if( *oriMaxAngToNormal<0.0 )
      cout<<"INFO - invalid new triangulation (improveNewSurfMesh)"<<endl;
#endif
    
    return;
  }

  /* the normal of the given model face at a vertex  */
  int V_getNormal(pGFace gf, pVertex v, double *normal)
  {
    double par[3];    
    if( !V_reparamOnGFace(v,gf,par) )
      return 0;
    GF_normal(gf,par,normal);
    return 1;
  }

  /* get a face from a face list that the given edge bounds */
  pFace F_getFmFaces(pPList &pl, pEdge edge)
  {
    void *iter=0;
    pFace fc;
    while( (fc=(pFace)PList_next(pl,&iter)) )
      if( F_inClosure(fc,(pEntity)edge) )
	return fc;
    
    return 0;
  }

  pFace F_getFmFaces(SCOREC::Util::scorecSSList<pFace> &pl, pEdge edge)
  {
    pFace fc;
    SCOREC::Util::scorecSSListIter<pFace> fcIter(pl);
    while( fcIter(fc) )
      if( F_inClosure(fc,(pEntity)edge) )
	return fc;
    
    return 0;
  }


  /*
    Given a poorly-shaped tetrahedron, a base triangle and the opposite vertex of the base,
    determine the following information:
    1. the key mesh entities to apply local mesh modification
    2. area of the four faces
    3. the intersection of two intersected opposite edges in case two large dihedral angles
    
    return 0   : if an edge is degenerated
           1-7 : the index indicating the location of projection point
  */
  int getTetInfo(
		 pRegion rgn,      // a tet of poor shape       
		 pFace fc,         // the base triangle face
		 pVertex vt,       // the vertex opposite to base wrt the tet
		 int valid,        // 1 - the tet is not flat; 0 - flat
		 pEntity ents[4],    
		 double area[4],
		 double intXYZ[3])
  {
    pEdge edges[6];    // the three ordered edges of the tet with fc to be base
    pVertex verts[3];  // the three ordered vertices of the face
    double fxyz[3][3]; // coordinates of the three vertices of the face
    double pxyz[3];    // coordinates of the opposite vertex
    pFace faces[4];    // order faces of the tet 
    
    pFace face;
    pEdge edge;
    double v01[3],v02[3], norm[3], temp[3];
    double ri[3], rj[3], rk[3], normi[3], normj[3], normk[3], mag[3];
    int i,j;
    
   
    for(i=0; i<3; i++) {
      edges[i]=F_edge(fc,i);
      if(F_edgeDir(fc,i))
	verts[i]=E_vertex(edges[i],0);
      else
	verts[i]=E_vertex(edges[i],1);
      V_coord(verts[i],fxyz[i]);
    }
    
    faces[0]=fc;
    for(i=0;i<4;i++) {
      face=R_face(rgn,i);
      if( face==fc ) continue;
      if( F_inClosure(face,(pEntity)edges[0]) ) { faces[1]=face; continue; }
      if( F_inClosure(face,(pEntity)edges[1]) ) { faces[2]=face; continue; }
      if( F_inClosure(face,(pEntity)edges[2]) ) faces[3]=face;
    }
    
    for( i=1;i<3;i++ ) {
      for( j=0;j<3;j++ ) {
	edge=F_edge(faces[i],j);
	if( edge==edges[i-1] ) continue;
	if( E_inClosure(edge,(pEntity)verts[0]) ) { edges[3]=edge; continue; }
	if( E_inClosure(edge,(pEntity)verts[1]) ) { edges[4]=edge; continue; }
	if( E_inClosure(edge,(pEntity)verts[2]) ) edges[5]=edge;
      }
    }
    
    /* project vt onto plane containing the base in case valid*/
    V_coord(vt,pxyz);
    if( valid ) {     // not flat, we need project
      P_projOnTriPlane(fxyz,pxyz,temp);
      pxyz[0]=temp[0]; 
      pxyz[1]=temp[1]; 
      pxyz[2]=temp[2]; 
    }
    
    /* find if the projection coincides with any of the 3 points */
    for(i=0;i<3; ++i){
      diffVt(pxyz,fxyz[i],v01);
      if(dotProd(v01,v01)<1.e-14)     
	{
//	  printf("Info: project onto a vertex AdaptUtil::getTetInfo()\n");
	  return 0;
	}
    }
    
    /* find normal to the plane */
    diffVt(fxyz[1],fxyz[0],v01);
    diffVt(fxyz[2],fxyz[0],v02);
    crossProd(v01,v02,norm);
    
    diffVt(pxyz,fxyz[0],ri);
    diffVt(pxyz,fxyz[1],rj);
    diffVt(pxyz,fxyz[2],rk);
    
    /* determine which side of the edges does the point R lie.
       First get normal vectors */
    crossProd(v01,ri,normi);
    diffVt(fxyz[2],fxyz[1],temp);
    crossProd(temp,rj,normj);
    diffVt(fxyz[0],fxyz[2],temp);
    crossProd(temp,rk,normk);
    
    mag[0]=dotProd(normi,norm);
    mag[1]=dotProd(normj,norm);
    mag[2]=dotProd(normk,norm);
    
    area[0]=dotProd(norm,norm);
    area[1]=dotProd(normi,normi);
    area[2]=dotProd(normj,normj);
    area[3]=dotProd(normk,normk);
    
    int filter[]={1,2,4};
    int bit=0;
    /* examine signs of mag[0], mag[1] and mag[2] */
    for(i=0;i<3;i++){
      //  #ifdef DEBUG
      //      if( ABS(mag[i])<1.e-12 )
      //        cout<<" 3 colinear points (getTetInfo)"<<endl;
      //  #endif
    if(mag[i]>0.0) {
      bit = bit | filter[i];
    }
    }
    
    /*  
           010=2   | 011=3  /  001=1
                   |       /
       ------------+--e2--+-----------
                 v0|     /v2
                   | 7  /
           110=6   e0  e1
                   |  /
                   | /    101=5
                   |/
                 v1+
                  /|
                 / |
                  4
    */

    // determine the key entities to solve problem
    switch( bit ) {
    case 1:{
      int Emap[]={0,4,3};
      int Fmap[]={0,2,3};
      ents[0]=(pEntity)faces[1];
      i=indexOfMin(area[0],area[2],area[3]);
      ents[1]=(pEntity)edges[Emap[i]];
      ents[2]=(pEntity)faces[Fmap[i]];
      break;
    }
    case 2: {
      int Emap[]={1,4,5};
      int Fmap[]={0,1,3};
      ents[0]=(pEntity)faces[2];
      i=indexOfMin(area[0],area[1],area[3]);
      ents[1]=(pEntity)edges[Emap[i]];
      ents[2]=(pEntity)faces[Fmap[i]];
      break;   
    }
    case 3: {
      double L1_xyz[2][3], L2_xyz[2][3];
      ents[0]=(pEntity)edges[2];
      ents[1]=(pEntity)edges[4];
      ents[2]=(pEntity)( (area[0]<area[3]) ? faces[0]:faces[3] );
      ents[3]=(pEntity)( (area[1]<area[2]) ? faces[1]:faces[2] );
      L1_xyz[0][0]=fxyz[0][0];    L1_xyz[1][0]=fxyz[2][0]; 
      L1_xyz[0][1]=fxyz[0][1];    L1_xyz[1][1]=fxyz[2][1];
      L1_xyz[0][2]=fxyz[0][2];    L1_xyz[1][2]=fxyz[2][2];
      L2_xyz[0][0]=fxyz[1][0];    L2_xyz[1][0]=pxyz[0]; 
      L2_xyz[0][1]=fxyz[1][1];    L2_xyz[1][1]=pxyz[1];
      L2_xyz[0][2]=fxyz[1][2];    L2_xyz[1][2]=pxyz[2];
      fromMeshTools::MT_intLineLine2(L1_xyz,L2_xyz,&i,intXYZ);
      break; 
    }   
    case 4: {
      int Emap[]={2,3,5};
      int Fmap[]={0,1,2};
      ents[0]=(pEntity)faces[3];
      i=indexOfMin(area[0],area[1],area[2]);
      ents[1]=(pEntity)edges[Emap[i]];
      ents[2]=(pEntity)faces[Fmap[i]];
      break; 
    }  
    case 5: {
      double L1_xyz[2][3], L2_xyz[2][3];
      ents[0]=(pEntity)edges[1];
      ents[1]=(pEntity)edges[3];
      ents[2]=(pEntity)( (area[0]<area[2]) ? faces[0]:faces[2] );
      ents[3]=(pEntity)( (area[1]<area[3]) ? faces[1]:faces[3] );
      L1_xyz[0][0]=fxyz[1][0];    L1_xyz[1][0]=fxyz[2][0]; 
      L1_xyz[0][1]=fxyz[1][1];    L1_xyz[1][1]=fxyz[2][1];
      L1_xyz[0][2]=fxyz[1][2];    L1_xyz[1][2]=fxyz[2][2];
      L2_xyz[0][0]=fxyz[0][0];    L2_xyz[1][0]=pxyz[0]; 
      L2_xyz[0][1]=fxyz[0][1];    L2_xyz[1][1]=pxyz[1];
      L2_xyz[0][2]=fxyz[0][2];    L2_xyz[1][2]=pxyz[2];
      fromMeshTools::MT_intLineLine2(L1_xyz,L2_xyz,&i,intXYZ);
      break;
    }
    case 6: {
      double L1_xyz[2][3], L2_xyz[2][3];
      ents[0]=(pEntity)edges[0];
      ents[1]=(pEntity)edges[5];
      ents[2]=(pEntity)( (area[0]<area[1]) ? faces[0]:faces[1] );
      ents[3]=(pEntity)( (area[2]<area[3]) ? faces[2]:faces[3] );
      L1_xyz[0][0]=fxyz[0][0];    L1_xyz[1][0]=fxyz[1][0]; 
      L1_xyz[0][1]=fxyz[0][1];    L1_xyz[1][1]=fxyz[1][1];
      L1_xyz[0][2]=fxyz[0][2];    L1_xyz[1][2]=fxyz[1][2];
      L2_xyz[0][0]=fxyz[2][0];    L2_xyz[1][0]=pxyz[0]; 
      L2_xyz[0][1]=fxyz[2][1];    L2_xyz[1][1]=pxyz[1];
      L2_xyz[0][2]=fxyz[2][2];    L2_xyz[1][2]=pxyz[2];
      fromMeshTools::MT_intLineLine2(L1_xyz,L2_xyz,&i,intXYZ);
      break;
    }
    case 7: {
      int Emap[]={0,1,2};
      int Fmap[]={1,2,3};
      ents[0]=(pEntity)faces[0];
      i=indexOfMin(area[1],area[2],area[3]);
      ents[1]=(pEntity)edges[Emap[i]];
      ents[2]=(pEntity)faces[Fmap[i]];
      break; 
    }  
    default: 
      cout<<endl<<" someything wrong"<<endl;
    }
    
    return bit;
  }


  int indexOfMin(double a0, double a1, double a2)
  {
    double buf;
    int k;
    if( a0<a1 )
      { buf=a0; k=0; }
    else
      { buf=a1; k=1; }
    
    return (buf<a2) ? k:2;
  }
  

  
  /*
    exactly the same as V_sqrDistToFace, but different implementation
    suggest using the another that is efficient
  */
  double V_sqrDistToFace_2(pVertex vertex,  pFace face)
  {
    double fxyz[3][3];   
    double pxyz[3];
    double proxyz[3];  // the coordinates of projection
    
    double v01[3],v02[3], norm[3], temp[3];
    double ri[3], rj[3], rk[3], normi[3], normj[3], normk[3], mag[3];
    int i;
    
    F_coord(face,fxyz);
    V_coord(vertex,pxyz);
    P_projOnTriPlane(fxyz,pxyz,proxyz);

    /* find if the projection coincides with any of the 3 points */
    for(i=0;i<3; ++i){
      diffVt(proxyz,fxyz[i],v01);
      if(dotProd(v01,v01)<1.e-12)  
	return XYZ_distance2(fxyz[i],pxyz);
    }

    /* find normal to the plane */
    diffVt(fxyz[1],fxyz[0],v01);
    diffVt(fxyz[2],fxyz[0],v02);
    crossProd(v01,v02,norm);

    diffVt(pxyz,fxyz[0],ri);
    diffVt(pxyz,fxyz[1],rj);
    diffVt(pxyz,fxyz[2],rk);

    /* determine which side of the edges does the point R lie.
       First get normal vectors */
    crossProd(v01,ri,normi);
    diffVt(fxyz[2],fxyz[1],temp);
    crossProd(temp,rj,normj);
    diffVt(fxyz[0],fxyz[2],temp);
    crossProd(temp,rk,normk);
    
    mag[0]=dotProd(normi,norm);
    mag[1]=dotProd(normj,norm);
    mag[2]=dotProd(normk,norm);
    
    int filter[]={1,2,4};
    int bit=0;
    /* examine signs of mag[0], mag[1] and mag[2] */
    for(i=0;i<3;i++){
      if(mag[i]>0.0) {
	bit = bit | filter[i];
      }
    }
    
    switch( bit ) {
    case 1: {
      double dSquare_1, dSquare_2;
      dSquare_1=P_sqrDistToSegment(fxyz[0],fxyz[2],pxyz);
      dSquare_2=P_sqrDistToSegment(fxyz[1],fxyz[2],pxyz);
      return MIN(dSquare_1,dSquare_2);
    }
    case 2: {
      double dSquare_1, dSquare_2;
      dSquare_1=P_sqrDistToSegment(fxyz[1],fxyz[0],pxyz);
      dSquare_2=P_sqrDistToSegment(fxyz[2],fxyz[0],pxyz);
      return MIN(dSquare_1,dSquare_2);
    }
    case 3: 
      return P_sqrDistToSegment(fxyz[0],fxyz[2],pxyz);
    case 4: {
      double dSquare_1, dSquare_2;
      dSquare_1=P_sqrDistToSegment(fxyz[0],fxyz[1],pxyz);
      dSquare_2=P_sqrDistToSegment(fxyz[2],fxyz[1],pxyz);
      return MIN(dSquare_1,dSquare_2);
    }
    case 5: 
      return P_sqrDistToSegment(fxyz[1],fxyz[2],pxyz);
    case 6: 
      return P_sqrDistToSegment(fxyz[0],fxyz[1],pxyz);
    case 7: {
      double snorm, d;
      d=P_distToPlane(pxyz,fxyz[0],fxyz[1],fxyz[2],&snorm);
      return d*d/snorm;
    }
    default:
      cout<<" this could happen (AdaptUtil::P_distToTriangle)"<<endl;
    }
    
    return 999999.;
  }


  /* given a segment defined by Lxyz0 & Lxyz1, determine the shortest
     distance square from point pxyz to that segment  11/26/01 -li */
  double P_sqrDistToSegment(double L_ori[3],double L_end[3], double pxyz[3])
  {
    double L_dir[3], kDiff[3];
    double fT;
    
    diffVt(L_end,L_ori,L_dir);
    diffVt(pxyz,L_ori,kDiff);
    fT=dotProd(kDiff,L_dir);
    
    if( fT > 0.0 ) {
      double fSqrLen=dotProd(L_dir,L_dir);
      if( fT>=fSqrLen ) 
	diffVt(kDiff,L_dir,kDiff);
      else {
	fT /= fSqrLen;
	L_dir[0] *= fT; 
	L_dir[1] *= fT; 
	L_dir[2] *= fT;
	diffVt(kDiff,L_dir,kDiff);
      }
    }
    
    return dotProd(kDiff,kDiff);
  }
  
  
  double V_sqrDistToFace(pVertex vt,  pFace fc)
  {
    double pxyz[3], xyz[3][3], e1[3], e2[3];
    
    V_coord(vt,pxyz);
    F_coord(fc,xyz);
    diffVt(xyz[1],xyz[0],e1);
    diffVt(xyz[2],xyz[0],e2);
    return P_sqrDistToTri(pxyz,xyz[0],e1,e2);
  }


  double P_sqrDistToTri(
			double pxyz[3],   // the coordinates of the point 
			double triOri[3], // the origin of the triangle
			double triEd0[3], // the vector defining an edge of triangle
			double triEd1[3]) // the vector defining another edge of triangle
  {
    double kDiff[3];
    double fA00, fA01,fA11, fB0, fB1, fC;
    double fDet;
    double fS, fT, fSqrDist;
    
    diffVt(triOri,pxyz,kDiff);
    fA00=dotProd(triEd0,triEd0);
    fA01=dotProd(triEd0,triEd1);
    fA11=dotProd(triEd1,triEd1);
    fB0=dotProd(kDiff,triEd0);
    fB1=dotProd(kDiff,triEd1);
    fC=dotProd(kDiff,kDiff);
    
    fDet = ABS(fA00*fA11-fA01*fA01);
    fS = fA01*fB1-fA11*fB0;
    fT = fA01*fB0-fA00*fB1;
    
    if ( fS + fT <= fDet )  {
      if ( fS < 0.0 )  {
	if ( fT < 0.0 )  // region 4
	  {
	    if ( fB0 < 0.0 )  {
	      fT = 0.0;
	      if ( -fB0 >= fA00 ) 
		{ fS = 1.0; fSqrDist = fA00+2.0*fB0+fC; }
	      else 
		{ fS = -fB0/fA00; fSqrDist = fB0*fS+fC; }
	    }
	    else {
	      fS = 0.0;
	      if ( fB1 >= 0.0 )
		{ fT = 0.0; fSqrDist = fC; }
	      else if ( -fB1 >= fA11 )
		{ fT = 1.0; fSqrDist = fA11+2.0*fB1+fC; }
	      else
		{ fT = -fB1/fA11; fSqrDist = fB1*fT+fC; }
	    }
	  }
	else  // region 3
	  {
	    fS = 0.0;
	    if ( fB1 >= 0.0f )
	      { fT = 0.0; fSqrDist = fC; }
	    else if ( -fB1 >= fA11 )
	      { fT = 1.0; fSqrDist = fA11+2.0*fB1+fC; }
	    else
	      { fT = -fB1/fA11; fSqrDist = fB1*fT+fC; }
	  }
      }
      else if ( fT < 0.0 )  // region 5
	{
	  fT = 0.0;
	  if ( fB0 >= 0.0 )
	    {
	      fS = 0.0f;
	      fSqrDist = fC;
	    }
	  else if ( -fB0 >= fA00 )
	    {
	      fS = 1.0;
	      fSqrDist = fA00+2.0*fB0+fC;
	    }
	  else
	    {
	      fS = -fB0/fA00;
	      fSqrDist = fB0*fS+fC;
	    }
	}
      else  // region 0
	{
	  // minimum at interior point
	  double fInvDet = 1.0/fDet;
	  fS *= fInvDet;
	  fT *= fInvDet;
	  fSqrDist = fS*(fA00*fS+fA01*fT+2.0*fB0) +
	    fT*(fA01*fS+fA11*fT+2.0f*fB1)+fC;
	}
    }
    else
      {
	double fTmp0, fTmp1, fNumer, fDenom;
	
	if ( fS < 0.0 )  // region 2
	  {
	    fTmp0 = fA01 + fB0;
	    fTmp1 = fA11 + fB1;
	    if ( fTmp1 > fTmp0 )
	      {
		fNumer = fTmp1 - fTmp0;
		fDenom = fA00-2.0*fA01+fA11;
		if ( fNumer >= fDenom )
		  {
		    fS = 1.0;
		    fT = 0.0;
		    fSqrDist = fA00+2.0*fB0+fC;
		  }
		else
		  {
		    fS = fNumer/fDenom;
		    fT = 1.0 - fS;
		    fSqrDist = fS*(fA00*fS+fA01*fT+2.0*fB0) +
		      fT*(fA01*fS+fA11*fT+2.0*fB1)+fC;
		  }
	      }
	    else
	      {
		fS = 0.0;
		if ( fTmp1 <= 0.0 )
		  {
		    fT = 1.0;
		    fSqrDist = fA11+2.0*fB1+fC;
		  }
                else if ( fB1 >= 0.0 )
		  {
                    fT = 0.0;
                    fSqrDist = fC;
		  }
		else
		  {
		    fT = -fB1/fA11;
		    fSqrDist = fB1*fT+fC;
		  }
	      }
	  }
	else if ( fT < 0.0 )  // region 6
	  {
	    fTmp0 = fA01 + fB1;
	    fTmp1 = fA00 + fB0;
	    if ( fTmp1 > fTmp0 )
	      {
		fNumer = fTmp1 - fTmp0;
		fDenom = fA00-2.0*fA01+fA11;
		if ( fNumer >= fDenom )
		  {
		    fT = 1.0;
		    fS = 0.0;
		    fSqrDist = fA11+2.0*fB1+fC;
		  }
		else
		  {
		    fT = fNumer/fDenom;
		    fS = 1.0 - fT;
		    fSqrDist = fS*(fA00*fS+fA01*fT+2.0*fB0) +
		      fT*(fA01*fS+fA11*fT+2.0*fB1)+fC;
		  }
	      }
	    else
	      {
		fT = 0.0;
		if ( fTmp1 <= 0.0 )
		  {
		    fS = 1.0;
		    fSqrDist = fA00+2.0*fB0+fC;
		  }
		else if ( fB0 >= 0.0 )
		  {
		    fS = 0.0;
		    fSqrDist = fC;
		  }
		else
		  {
		    fS = -fB0/fA00;
		    fSqrDist = fB0*fS+fC;
		  }
	      }
	  }
	else  // region 1
	  {
	    fNumer = fA11 + fB1 - fA01 - fB0;
	    if ( fNumer <= 0.0 )
	      {
		fS = 0.0;
		fT = 1.0;
		fSqrDist = fA11+2.0f*fB1+fC;
	      }
	    else
	      {
		fDenom = fA00-2.0*fA01+fA11;
		if ( fNumer >= fDenom )
		  {
		    fS = 1.0;
		    fT = 0.0;
		    fSqrDist = fA00+2.0*fB0+fC;
		  }
		else
		  {
		    fS = fNumer/fDenom;
		    fT = 1.0 - fS;
		    fSqrDist = fS*(fA00*fS+fA01*fT+2.0*fB0) +
		      fT*(fA01*fS+fA11*fT+2.0*fB1)+fC;
		  }
	      }
	  }
      }
  
    return ABS(fSqrDist);
  }


  double M_sqrDistEdges(pEdge e0,pEdge e1)
  {
    double ori0[3], dir0[3];
    double ori1[3], dir1[3];
    double tmp[3];
    
    V_coord(E_vertex(e0,0),ori0);
    V_coord(E_vertex(e0,1),tmp);
    diffVt(tmp,ori0,dir0);
    
    V_coord(E_vertex(e1,0),ori1);
    V_coord(E_vertex(e1,1),tmp);
    diffVt(tmp,ori1,dir1);
    
    return XYZ_sqrDistSegments(ori0,dir0,ori1,dir1);
  }


  /* calculate the distance of two line segments   12/07/01  -li */
  double XYZ_sqrDistSegments(
			     double ori0[3],   // origin of the first segment 
			     double dir0[3],   // direction of the first segment
			     double ori1[3],   // origin of the second segment
			     double dir1[3])   // direction of the second segment
  {
    const double gs_fTolerance = 1e-010;
    
    double kDiff[3];
    double fA00,fA01,fA11,fB0,fC;
    double fDet;
    double fB1, fS, fT, fSqrDist, fTmp;
    
    diffVt(ori0,ori1,kDiff);
    fA00=dotProd(dir0,dir0);
    fA01=-dotProd(dir0,dir1);
    fA11=dotProd(dir1,dir1);
    fB0=dotProd(kDiff,dir0);
    fC=dotProd(kDiff,kDiff);
    fDet = ABS(fA00*fA11-fA01*fA01);

    if ( fDet >= gs_fTolerance ) {
      // line segments are not parallel
      fB1 = -dotProd(kDiff,dir1);
      fS = fA01*fB1-fA11*fB0;
      fT = fA01*fB0-fA00*fB1;
    
      if ( fS >= 0.0 )  {
	if ( fS <= fDet ) {
	  if ( fT >= 0.0 )  {
	    if ( fT <= fDet )  // region 0 (interior)
	      {
		// minimum at two interior points of 3D lines
		double fInvDet = 1.0/fDet;
		fS *= fInvDet;
		fT *= fInvDet;
		fSqrDist = fS*(fA00*fS+fA01*fT+2.0*fB0) +
		  fT*(fA01*fS+fA11*fT+2.0*fB1)+fC;
	      }
	    else  // region 3 (side)
	      {
		fT = 1.0;
		fTmp = fA01+fB0;
		if ( fTmp >= 0.0 ) {
		  fS = 0.0;
		  fSqrDist = fA11+2.0*fB1+fC;
		}
		else if ( -fTmp >= fA00 ) {
		  fS = 1.0;
		  fSqrDist = fA00+fA11+fC+2.0*(fB1+fTmp);
		}
		else {
		  fS = -fTmp/fA00;
		  fSqrDist = fTmp*fS+fA11+2.0*fB1+fC;
		}
	      }
	  }
	  else  // region 7 (side)
	    {
	      fT = 0.0;
	      if ( fB0 >= 0.0 ) {
		fS = 0.0;
		fSqrDist = fC;
	      }
	      else if ( -fB0 >= fA00 ) {
		fS = 1.0;
		fSqrDist = fA00+2.0*fB0+fC;
	      }
	      else {
		fS = -fB0/fA00;
		fSqrDist = fB0*fS+fC;
	      }
	    }
	}
	else
	  {
	    if ( fT >= 0.0 )  {
	      if ( fT <= fDet )  // region 1 (side)
		{
		  fS = 1.0;
		  fTmp = fA01+fB1;
		  if ( fTmp >= 0.0 ) {
		    fT = 0.0;
		    fSqrDist = fA00+2.0*fB0+fC;
		  }
		  else if ( -fTmp >= fA11 ) {
		    fT = 1.0;
		    fSqrDist = fA00+fA11+fC+2.0*(fB0+fTmp);
		  }
		  else {
		    fT = -fTmp/fA11;
		    fSqrDist = fTmp*fT+fA00+2.0*fB0+fC;
		  }
		}
	      else  // region 2 (corner)
		{
		  fTmp = fA01+fB0;
		  if ( -fTmp <= fA00 )  {
		    fT = 1.0;
		    if ( fTmp >= 0.0 ) {
		      fS = 0.0;
		      fSqrDist = fA11+2.0*fB1+fC;
		    }
		    else  {
		      fS = -fTmp/fA00;
		      fSqrDist = fTmp*fS+fA11+2.0*fB1+fC;
		    }
		  }
		  else  {
		    fS = 1.0;
		    fTmp = fA01+fB1;
		    if ( fTmp >= 0.0 )  {
		      fT = 0.0;
		      fSqrDist = fA00+2.0*fB0+fC;
		    }
		    else if ( -fTmp >= fA11 )  {
		      fT = 1.0;
		      fSqrDist = fA00+fA11+fC+2.0*(fB0+fTmp);
		    }
		    else  {
		      fT = -fTmp/fA11;
		      fSqrDist = fTmp*fT+fA00+2.0*fB0+fC;
		    }
		  }
		}
	    }
	    else  // region 8 (corner)
	      {
		if ( -fB0 < fA00 ) {
		  fT = 0.0;
		  if ( fB0 >= 0.0 ) {
		    fS = 0.0;
		    fSqrDist = fC;
		  }
		  else  {
		    fS = -fB0/fA00;
		    fSqrDist = fB0*fS+fC;
		  }
		}
		else  {
		  fS = 1.0;
		  fTmp = fA01+fB1;
		  if ( fTmp >= 0.0 )  {
		    fT = 0.0;
		    fSqrDist = fA00+2.0*fB0+fC;
		  }
		  else if ( -fTmp >= fA11 )  {
		    fT = 1.0;
		    fSqrDist = fA00+fA11+fC+2.0*(fB0+fTmp);
		  }
		  else  {
		    fT = -fTmp/fA11;
		    fSqrDist = fTmp*fT+fA00+2.0*fB0+fC;
		  }
		}
	      }
	  }
      }
      else 
	{
	  if ( fT >= 0.0 )  {
	    if ( fT <= fDet )  // region 5 (side)
	      {
		fS = 0.0;
		if ( fB1 >= 0.0 ) {
		  fT = 0.0;
		  fSqrDist = fC;
		}
		else if ( -fB1 >= fA11 )  {
		  fT = 1.0;
		  fSqrDist = fA11+2.0f*fB1+fC;
		}
		else {
		  fT = -fB1/fA11;
		  fSqrDist = fB1*fT+fC;
		}
	      }
	    else  // region 4 (corner)
	      {
		fTmp = fA01+fB0;
		if ( fTmp < 0.0 )  {
		  fT = 1.0;
		  if ( -fTmp >= fA00 )  {
		    fS = 1.0;
		    fSqrDist = fA00+fA11+fC+2.0*(fB1+fTmp);
		  }
		  else  {
		    fS = -fTmp/fA00;
		    fSqrDist = fTmp*fS+fA11+2.0*fB1+fC;
		  }
		}
		else  {
		  fS = 0.0;
		  if ( fB1 >= 0.0 ) {
		    fT = 0.0;
		    fSqrDist = fC;
		  }
		  else if ( -fB1 >= fA11 )  {
		    fT = 1.0;
		    fSqrDist = fA11+2.0*fB1+fC;
		  }
		  else {
		    fT = -fB1/fA11;
		    fSqrDist = fB1*fT+fC;
		  }
		}
	      }
	  }
	  else   // region 6 (corner)
	    {
	      if ( fB0 < 0.0 ) {
		fT = 0.0;
		if ( -fB0 >= fA00 )  {
		  fS = 1.0;
		  fSqrDist = fA00+2.0*fB0+fC;
		}
		else  {
		  fS = -fB0/fA00;
		  fSqrDist = fB0*fS+fC;
		}
	      }
	      else {
		fS = 0.0;
		if ( fB1 >= 0.0 )  {
		  fT = 0.0;
		  fSqrDist = fC;
		}
		else if ( -fB1 >= fA11 ) {
		  fT = 1.0;
		  fSqrDist = fA11+2.0*fB1+fC;
		}
		else {
		  fT = -fB1/fA11;
		  fSqrDist = fB1*fT+fC;
		}
	      }
	    }
	}
    }

    else {
      // line segments are parallel
      if ( fA01 > 0.0 ) {
	// direction vectors form an obtuse angle
	if ( fB0 >= 0.0 ) {
	  fS = 0.0;
	  fT = 0.0;
	  fSqrDist = fC;
	}
	else if ( -fB0 <= fA00 ) {
	  fS = -fB0/fA00;
	  fT = 0.0;
	  fSqrDist = fB0*fS+fC;
	}
	else  {
	  fB1 = - dotProd(kDiff,dir1); 
	  fS = 1.0;
	  fTmp = fA00+fB0;
	  if ( -fTmp >= fA01 ) {
	    fT = 1.0;
	    fSqrDist = fA00+fA11+fC+2.0*(fA01+fB0+fB1);
	  }
	  else {
	    fT = -fTmp/fA01;
	    fSqrDist = fA00+2.0*fB0+fC+fT*(fA11*fT+2.0*(fA01+fB1));
	  }
	}
      }
      else {
	// direction vectors form an acute angle
	if ( -fB0 >= fA00 ) {
	  fS = 1.0;
	  fT = 0.0;
	  fSqrDist = fA00+2.0f*fB0+fC;
	}
	else if ( fB0 <= 0.0 ) {
	  fS = -fB0/fA00;
	  fT = 0.0;
	  fSqrDist = fB0*fS+fC;
	}
	else  {
	  fB1 = - dotProd(kDiff,dir1);
	  fS = 0.0;
	  if ( fB0 >= -fA01 ) {
	    fT = 1.0;
	    fSqrDist = fA11+2.0*fB1+fC;
	  }
	  else {
	    fT = -fB0/fA01;
	    fSqrDist = fC+fT*(2.0*fB1+fA11*fT);
	  }
	}
      }
    }

    return ABS(fSqrDist);
  }

  /* return the longest mesh edge of a mesh face, and the ratio square of
     longest edge to shortest edge */
  int F_longestEdge(pSField mf, pFace fc, pEdge *longest, double *ratio)
  {
    pEdge edge;
    double buf, max=0.0, min=BIG_NUMBER;
    int i, flag=0;

    for( i=0; i<3; i++ ) {
      edge=F_edge(fc,i);
      if( mf )
	buf=mf->lengthSq(edge);
      else
	buf=adaptUtil::E_lengthSq(edge);
      if( buf>max ) 
	{ max=buf; *longest=edge; flag=1; }
      if( buf<min )
	min=buf;
    }
    *ratio=max/min;
    *ratio *= *ratio;
    return flag;
  }

  /* compute the square length of the shortest edge adjacent to the vertex */
  double V_shortestLength(pVertex vt)
  {
    double sqrL, tmp;
    sqrL=-1.0;
    for( int i=0; i<V_numEdges(vt); i++ )
      {
	tmp=adaptUtil::E_lengthSq( V_edge(vt,i) );
	if( sqrL==-1.0 )
	  sqrL=tmp;
	else if( sqrL>tmp )
	  sqrL=tmp;
      }
    return sqrL;
  }


  /* Project a point onto a given plane specified by three points in 3D */
  void P_projOnTriPlane(double fxyz[3][3],double pxyz[3],double *proxyz)
  {
    int i;
    double v01[3],v02[3],v0P[3],normal[3], ratio;
    double magCP,magN;
    
    diffVt(fxyz[1],fxyz[0],v01);
    diffVt(fxyz[2],fxyz[0],v02); 
    crossProd(v01,v02,normal);
    
    magN=dotProd(normal,normal);
    
    diffVt(pxyz,fxyz[0],v0P);
    magCP=dotProd(v0P,normal);
    
    ratio=magCP/magN;
  
    for(i=0;i<3;++i)
      proxyz[i]=pxyz[i]-ratio*normal[i];
    
    return;
  }

  int evalEclps(pSField mf, edgeCollapsMod *pclps, pMeshMod *ppBestMod, double *maxR, double upperBoundSq)
  {
    if( !pclps->topoCheck() ) 
      return 0;
    
    evalResults *result=pclps->getResultHolder();
    
    if( mf )
      {
	if( !pclps->sizeCheck() ) 
	  return 0;
	if( result->getMaxSize()>upperBoundSq &&
	    result->getRatioSquareAtMaxSize()>1.44 ) 
	  // considerations of picking 1.2*1.2: we should allow the edge of
	  // max size a little longer so that the short edge can be eliminated,
	  // but not much
	  return 0;
      }
   
    if( !pclps->topoCheck() )
      return 0; 
    if( !pclps->geomCheck() )
      return 0;  
    if( result->getWorstShape() < IMPROVE_RATIO*(*maxR) )
      return 0;
    
    *maxR = result->getWorstShape();
    if(*ppBestMod) 
      delete *ppBestMod;
    *ppBestMod = new edgeCollapsMod(*pclps);
    return 1;
  }
  
  
  /* return 1 if swap operation is valid and better */
  int evalEswp(edgeSwapMod *eswp, pMeshMod *ppBestMod, double *maxR, double lowerLenSqBound)
  {
    if( !eswp->topoCheck() )
      return 0;
    if( !eswp->geomCheck() )
      return 0;
    if( !eswp->sizeCheck() )
      return 0;

    evalResults *result=eswp->getResultHolder();

//     if( result->getMaxSize() > UPPERLENSQBOUND &&
//      result->getMaxRatioSquare() > 1. )
//       return 0;

    // if( result->getMinSize() > lowerLenSqBound &&
    //  result->getWorstShape() > IMPROVE_RATIO*(*maxR) )
    if( result->getWorstShape() > IMPROVE_RATIO*(*maxR) )
      {
        *maxR = result->getWorstShape();
        if(*ppBestMod)
          delete *ppBestMod;
        *ppBestMod = new edgeSwapMod(*eswp);
        return 1;
      }
    return 0;
  }


  int evalSpltClps(EsplitClpsMod *comp, pMeshMod *ppBestMod, double *maxR, double upperLenSqBound)
  {
    if( !comp->topoCheck() )
      return 0;
    if( !comp->geomCheck() )
      return 0;
    if( !comp->sizeCheck() )
      return 0;

    evalResults *result=comp->getResultHolder();

    // if( result->getMaxSize() < upperLenSqBound &&
    //    result->getWorstShape() > IMPROVE_RATIO*(*maxR) )
    if( result->getWorstShape() > IMPROVE_RATIO*(*maxR) )
      {
        *maxR = result->getWorstShape();
        if(*ppBestMod)
          delete *ppBestMod;
        *ppBestMod = new EsplitClpsMod(*comp);
        return 1;
      }
    return 0;
  }  


  /*
    given a segment and a point, find parameter t at the projection of
    the point wrt the segment
    We assume: t=0 at segment[0]
               t=1 at segment[1]
	       0<t<1 if the projection is on the segment
  */
  double ParOnLinearEdge(double segment[2][3], double xyz[3])
  {
    double t, tmp;
     
    double AB[3], AC[3], CB[3];
    diffVt(segment[1],segment[0],AB);
    diffVt(segment[1],xyz,CB);
    tmp=dotProd(CB,AB);
    if( tmp < 1e-10 )
      t=1;
    else {
      diffVt(xyz,segment[0],AC);
      tmp=dotProd(AC,AB)/tmp;
      t=tmp/(1+tmp);
    }

#ifdef DEBUG
    if( t>1 && t<0 )
      printf("Info: parameter not in [0,1]\n");
#endif

    return t;
  }


  void centroidOfMRegion(pRegion rgn, double *cent)
  {
    double t_xyz[4][3];
    int i;
    
    R_coord(rgn, t_xyz);
    cent[0]=0.0; cent[1]=0.0; cent[2]=0.0;
    for(i=0; i<4; i++)
      { cent[0]+=t_xyz[i][0]; cent[1]+=t_xyz[i][1]; cent[2]+=t_xyz[i][2]; }
    
    cent[0]/=4.0; cent[1]/=4.0; cent[2]/=4.0;
  }
  
  
  void centroidOfMFace(pFace face, double *cent)
  {
    double t_xyz[3][3];
    int i;
    
    F_coord(face, t_xyz);
    cent[0]=0.0; cent[1]=0.0; cent[2]=0.0;
    for(i=0; i<3; i++)
      { cent[0]+=t_xyz[i][0]; cent[1]+=t_xyz[i][1]; cent[2]+=t_xyz[i][2]; }
    
    cent[0]/=3.0; cent[1]/=3.0; cent[2]/=3.0;
  }
  
  void centroidOfMEdge(pEdge edge, double *cent)
  {
    cent[0]=0.0; cent[1]=0.0; cent[2]=0.0;
    double cen[3];
    int i;
    for (i=0; i<2; i++) {
      V_coord(E_vertex(edge,i), cen);
      cent[0]+=cen[0]; cent[1]+=cen[1]; cent[2]+=cen[2];
    }
    cent[0]/=2.0; cent[1]/=2.0; cent[2]/=2.0;
  }
  
  void centroidOfMVertex(pVertex vertex, double *cent)
  {
    V_coord(vertex, cent);
  }
  
  
  void centroidOfCavity(pVertex vertex, double *cent)
  {
    pEdge edge;
    pVertex otherV;
    pGEntity gent;
    double cen[3];
    int ne;

    if( V_whatInType(vertex)==Gvertex ) {
      V_coord(vertex,cent);
      return;
    }

    cent[0]=0.0; cent[1]=0.0; cent[2]=0.0;
    ne=0;
    gent=V_whatIn(vertex);
    for( int i=0; i<V_numEdges(vertex); i++ )
      {
	edge=V_edge(vertex,i);
	if( E_whatIn(edge)!=gent )
	  continue;
	ne++;
	otherV=E_otherVertex(edge,vertex);
	V_coord(otherV,cen);
	cent[0]+=cen[0]; cent[1]+=cen[1]; cent[2]+=cen[2];
      }
    cent[0]/=ne; cent[1]/=ne; cent[2]/=ne;
    return;
  }

  void centroidOfCavity2(pEdge edge, double *cent) 
  {
    if( E_whatInType(edge)!=Gregion ) {
      printf("Error: not implemented (adaptUtil::centroidOfCavity2)\n");
      return;
    }

    pFace face;
    pVertex vertex;
    double xyz[3];
    int i, nv;

    cent[0]=0.0; cent[1]=0.0; cent[2]=0.0;
    for (i=0; i<2; i++) {
      V_coord(E_vertex(edge,i), xyz);
      cent[0]+=xyz[0]; cent[1]+=xyz[1]; cent[2]+=xyz[2];
    }
    nv=2;
    for (i=0; i<E_numFaces(edge); i++) {
      face=E_face(edge,i);
      vertex=F_edOpVt(face,edge);
      V_coord(vertex, xyz);
      cent[0]+=xyz[0]; cent[1]+=xyz[1]; cent[2]+=xyz[2];
      nv++;
    }
    cent[0]/=nv; cent[1]/=nv; cent[2]/=nv;
    return;
  }

  void M_checkPar(pMesh mesh, int fixIt) {
    pVertex vert;
    VIter vit=M_vertexIter(mesh);

    if(fixIt) {
      pGEntity g_entity;
      double xyz[3];
      double new_xyz[3];
      double par[]={0.0,0.0,0.0};
      double old_par[]={0.0,0.0,0.0};
      int type;
      while( vert=VIter_next(vit) )
	if(! V_checkPar(vert,1)) {
	  g_entity = V_whatIn(vert);
	  type = GEN_type(g_entity);
	  V_coord(vert,xyz);
	  if(type == Gvertex || type == Gregion)
	    cerr << "M_checkPar:  Error in finding the closest Point"<<endl;
	  else {
	    if(type == Gface)
	      GF_closestPoint((pGFace)g_entity, xyz, new_xyz, par);
	    else if(type == Gedge)
	      GE_closestPoint((pGEdge)g_entity, xyz, new_xyz, par);
	    else
	      cerr << "M_checkPar:  Error in finding the closest Point"<<endl;
	      
	    pPoint point= V_point(vert);
	    if(type==Gedge) {
	      old_par[0]=P_param1(point);
	      FMDB_P_setParametricPos (point, par[0], par[1], par[2]);
	      //P_setParam1(point,par[0]);
	    }
	    else if(type==Gface) {
	      P_param2(point,&old_par[0],&old_par[1],(int *)(&old_par[2]));
	      FMDB_P_setParametricPos (point, par[0], par[1], par[2]);
	      //P_setParam2(point,par[0],par[1],(int)par[2]);
	    }
	    P_setPos(point,new_xyz[0],new_xyz[1],new_xyz[2]);
	    
	    if(ValidCheck(vert)) 
	      cout << "incorrect parameter of vertex "<<vert<<" is fixed" << endl;
	    else {
	      cout << "incorrect parameter of vertex "<<vert<<" can not be fixed" << endl;
	      if(type==Gedge)
		FMDB_P_setParametricPos (point, old_par[0], old_par[1], old_par[2]);
		//P_setParam1(point,old_par[0]);
	      else if(type==Gface)
		FMDB_P_setParametricPos (point, old_par[0], old_par[1], old_par[2]);
		//P_setParam2(point,par[0],par[1],(int)par[2]);
	      P_setPos(point,xyz[0],xyz[1],xyz[2]);
	    }
	  }
	}
    }
    else 
      while( vert=VIter_next(vit) )
	V_checkPar(vert,1);
    
    VIter_delete(vit);
    return;
  }

  /*
    return 1: if par is correct
           0: if par is incorrect
	   2: if no par (classified on model vertex or model region)
  */
  int V_checkPar(pVertex vert, int print)
  {
    double xyz[3],pxyz[3];
    double vec[3];
    pPoint point;
    pGEntity g_entity;
    double tol;
    
    point=V_point(vert);
    xyz[0]=P_x(point);
    xyz[1]=P_y(point);
    xyz[2]=P_z(point);
    
    g_entity=V_whatIn(vert);
    tol=GEN_tolerance(g_entity);
    
    switch(V_whatInType(vert)) {
    case Tedge:{
      double par=P_param1(point);
      GE_point((pGEdge)g_entity, par, pxyz);
      diffVt(pxyz,xyz,vec);
      if(dotProd(vec,vec) > tol*tol) {
#ifdef DEBUG
	if( print )
	  cout<<" par of vertex "<< EN_id((pEntity)vert) <<" is not correct! "<<vert<<endl;
#endif
	return 0;
      }
      break;
    }
    case Tface:{
      double par[3];
      P_param2(point,&par[0],&par[1],(int *)&par[2]);
      GF_point((pGFace)g_entity, par, pxyz);
      diffVt(pxyz,xyz,vec);
      if(dotProd(vec,vec) > tol*tol) {
#ifdef DEBUG
	if ( print )
	  cout<<" par of vertex "<< EN_id((pEntity)vert) <<" is not correct! "<<vert<<endl;
#endif
	return 0;
      }
      break;
    }
    default:
      return 2;
    }    
    return 1;
  }


  void move_vertex(pVertex vert, double *xyz)
  {
    if(!EN_isBLEntity((pEntity)vert))
      if( !EN_okTo(MOVE,(pEntity)vert) )
        return;
    pPoint point= V_point(vert);
    P_setPos(point,xyz[0],xyz[1],xyz[2]);
  }
  
  void move_vertex(pVertex vert, double *xyz, CBFunc_move CB, void *userData)
  {
    if(!EN_isBLEntity((pEntity)vert))
      if( !EN_okTo(MOVE,(pEntity)vert) )
        return;
    
    if( CB )
      CB(vert,xyz,userData);
    pPoint point= V_point(vert);
    P_setPos(point,xyz[0],xyz[1],xyz[2]);

//  #ifdef AOMD_
//  #ifdef DEBUG
//      if( ! ValidCheck(vert) )
//        printf("WARNING: moving vertex %d leads to negative volume (move_vertex)\n",EN_id((pEntity)vert));
//  #endif
//  #endif
  }


double V_worstShp(MeanRatio *shp, pVertex vt)
{
  pRegion region;
  pPList rlist=V_regions(vt);
  double worst=BIG_NUMBER;
  double shape_1;

  double mtol=M_getTolerance();
  void *temp=0;
  
  if( PList_size(rlist)==0 ) {
    // 2D case
    pPList flist=V_faces(vt);
    pFace face;
    while( face=(pFace)PList_next(flist,&temp) ) {
      shp->F_shape(face,0,&shape_1);
      if( shape_1<= mtol ) {
        PList_delete(rlist);
	PList_delete(flist);
	return 0.0;
      }
      if(shape_1 < worst)
        worst=shape_1;
    }
    PList_delete(flist);
  }
  else {
    // 3D case
    while(region=(pRegion)PList_next(rlist,&temp)) {
      shp->R_shape(region,&shape_1);
      if( shape_1 <= mtol ) {
	PList_delete(rlist);
	return 0.0;
      }
      if(shape_1 < worst)
        worst=shape_1;
    }
  }
  
  PList_delete(rlist);
  return worst;
}


double E_worstShp(MeanRatio *shp, pPList rlist, pEdge ed)
{
  double worst=BIG_NUMBER;
  double shape_1;
  int flag=0;

  double mtol=M_getTolerance();
  void *temp=0;

  if( !rlist )
    {
    rlist=E_regions(ed);
    flag=1;
   }

  if( PList_size(rlist)==0 ) {
    // 2D case
    pFace face;
    for( int i=0; i<E_numFaces(ed); i++ ) {
      face=E_face(ed,i);
      shp->F_shape(face,0,&shape_1);
      if( shape_1<=mtol )  { 
	if( flag)
	  PList_delete(rlist);
	return 0.0;
      }
      if(shape_1 < worst)
        worst=shape_1;
    }      
  }
  else {
    // 3D case
    pRegion region;
    while(region=(pRegion)PList_next(rlist,&temp)) {
      shp->R_shape(region,&shape_1);
      if( shape_1<=mtol ) {
        if( flag )
          PList_delete(rlist); 
	return 0.0;
      }
      if(shape_1 < worst)
	worst=shape_1;
    }
  }

  if( flag )
    PList_delete(rlist);

  return worst;
}


pRegion F_otherRgn(pFace face, pRegion Reg1)
{
  pRegion Reg0=F_region(face,0);

  if(Reg0==Reg1)
      Reg0=F_region(face,1);

  return Reg0;
}



/*
  return 1:  the point is inclosure of the line
         0:  not inclosure of the line

  Last Modification:  May 13,  2000
*/
int XYZ_InClosureOfLine(double int_xyz[3], double L_xyz[2][3])
{
  double vec0[3];
  double vec1[3];
  double d0, d1, d2;
  double mtol=M_getTolerance();

  mtol = mtol*mtol;

  diffVt(L_xyz[0],int_xyz, vec0);
  diffVt(L_xyz[1],int_xyz, vec1);

  // see if it is resident on bounding point 0
  d0 = dotProd(vec0,vec0);
  if(d0 < mtol) return 1;
  // see if it is resident on bounding point 1
  d1 = dotProd(vec1,vec1);
  if(d1 < mtol) return 1;
  d2 = dotProd(vec0,vec1);
  if(d2 > 0) return 0;

  if(1 - d2*d2/(d0*d1) < mtol) return 1;
  return 0;
}

/*
  give a mesh face, a reference (mesh vertex), and a random position

  if the position is located in the plane containing the mesh face, return 0;
  otherwise, if the position and the reference is on the same side of the mesh face , return 1;
             if the position and the reference is on different side of the mesh face, return -1;

  MeshAdapt  V1.0      Xiangrong Li    12/9/99
*/
int V_wrtFace(
  double *xyz_vr,       // the position being considering
  const pVertex &Vref,  // the reference vertex
  const pFace &face)    // the mesh face
{
  pVertex vt;
  double fxyz[3][3];
  double v01[3],v02[3], v03[3], normal[3];
  double dr, ds;
  double tol=M_getTolerance();
  int i;

  pPList verts=F_vertices(face,1);
  void *iter=0;
  i=0;
  while( vt=(pVertex)PList_next(verts,&iter) )
    V_coord(vt,fxyz[i++]);
  PList_delete(verts);

  diffVt(fxyz[1],fxyz[0],v01);
  diffVt(fxyz[2],fxyz[0],v02);
  crossProd(v01,v02,normal);

  diffVt(xyz_vr,fxyz[0],v03);

  dr = dotProd(v03,normal);

  if(dr*dr < tol*tol)
    return 0;                  // vertex is on the face

  if(!Vref) return 2;

  V_coord(Vref,xyz_vr);
  diffVt(xyz_vr,fxyz[0],v03);
  ds = dotProd(v03,normal);

  if(dr*ds < 0.0) return -1;   // different side of the mesh face

  return 1;   // the same side of the mesh face
}


// find out if point lies on the same side of the mesh face (towards the normal)
// return -1 : point is on other side of the face normal
// return  0 : point is on the face
// return  1 : point is on the same side of the face normal
int XYZ_wrtFace(pFace face, double *xyz) {
  // assuming triangular face
  double fxyz[3][3];
  double v01[3],v02[3], v03[3], normal[3];
  double tol = M_getTolerance();

  pPList verts=F_vertices(face,1);
  void *iter=0;
  int i=0;
  pVertex vt;
  while( vt=(pVertex)PList_next(verts,&iter) )
    V_coord(vt,fxyz[i++]);
  PList_delete(verts);

  diffVt(fxyz[1],fxyz[0],v01);
  diffVt(fxyz[2],fxyz[0],v02);
  crossProd(v01,v02,normal);
  normVt(normal,normal);

  double f_cg[3] = {0.,0.,0.};
  // assuming triangular face
  for(int iVert=0; iVert<3; iVert++) {
    for(int iComp=0; iComp<3; iComp++)
      f_cg[iComp] += fxyz[iVert][iComp];
  }
  for(int iComp=0; iComp<3; iComp++)
    f_cg[iComp] /= 3;

  diffVt(xyz,f_cg,v03);

  double dot = dotProd(normal,v03);

  if(fabs(dot)<tol)
    return 0;

  // other side (op. to face normal)
  if(dot<0.)
    return -1;

  return 1;
}


/*
   return 1: Two vector are nearly in the same direction with angle between less than 5 degree
         -1: Two vector are nearly in the opposite direction with angle between greater than 175 degree
          0: else
*/
int RelativeDirection(double *n1, double *n2)
{
  double dot,ll1,ll2;

  dot=dotProd(n1,n2);

  ll1=n1[0]*n1[0]+n1[1]*n1[1]+n1[2]*n1[2];
  ll2=n2[0]*n2[0]+n2[1]*n2[1]+n2[2]*n2[2];

  if(dot*dot/(ll1*ll2) < 0.9924) return 0;
  if(dot > 0) return 1;
  return -1;
}

int RelativeDirection(double *n1, double *n2, double flatAngle)
{
  double cosFlatAngleSquare;
  double dot,ll1,ll2;

  cosFlatAngleSquare=cos(flatAngle*0.017453293);   //  PI/180
  cosFlatAngleSquare=cosFlatAngleSquare*cosFlatAngleSquare;

  dot=dotProd(n1,n2);

  ll1=n1[0]*n1[0]+n1[1]*n1[1]+n1[2]*n1[2];
  ll2=n2[0]*n2[0]+n2[1]*n2[1]+n2[2]*n2[2];

  if(dot*dot/(ll1*ll2) < cosFlatAngleSquare) return 0;
  if(dot > 0) return 1;
  return -1;
}


/*
  return 1: need expand,  otherwise not
*/
int ifNeedExpand(pFace face,pEdge edge,double *target)
{
  pVertex vert;
  double xyz[4][3];
  double tol;

  if( F_whatInType(face)==Gface ) 
    tol=GEN_tolerance(F_whatIn(face));
  else
    tol=M_getTolerance();

  vert=F_edOpVt(face,edge);

  V_coord( E_vertex(edge,0), xyz[0] );
  V_coord( E_vertex(edge,1), xyz[1] );
  V_coord( vert,             xyz[2] );

  xyz[3][0]=target[0];
  xyz[3][1]=target[1];
  xyz[3][2]=target[2];

  // not colinear
  if( P_distToLine(target, xyz[0], xyz[1],0 )<tol ) return 1;

  // rotation less than 90 degrees
  if( E_dihedral(xyz) < tol )  return 1;

  return 0;
}


/*
   find the common edge of two mesh faces
   02/09/2000     for region collapse
*/
pEdge CommonEdge(pFace fc1, pFace fc2)
{
  pEdge edge;

  for(int i=0; i<F_numEdges(fc1); ++i) {
    edge=F_edge(fc1,i);
    if(F_inClosure(fc2,(pEntity)edge))
      return edge;
  }
  return (pEdge)0;
}


/*
   return 0: if all regions hooked on given vertex with a vertex moved are vaild
          1: otherwise
*/
int ValidCheck(pVertex vert, pVertex SnapVert, double int_xyz[3])
{
  pRegion region;
  pVertex vt;
  pPList vrlist, rvlist;
  double xyz[4][3];
  void *temp=0;
  void *tmp;
  int i;

  vrlist=V_regions(vert);
  while(region=(pRegion)PList_next(vrlist,&temp)) {

    rvlist=R_vertices(region,1);
    tmp=0; i=0;
    while(vt=(pVertex)PList_next(rvlist,&tmp)) {
      if(vt==SnapVert)
        { xyz[i][0]=int_xyz[0]; xyz[i][1]=int_xyz[1]; xyz[i][2]=int_xyz[2]; }
      else
        V_coord(vt,xyz[i]);
      ++i;
    }

    if(XYZ_checkFlat(xyz)) {
      PList_delete(vrlist);
      PList_delete(rvlist);
      return 0;
    }
  }

  PList_delete(vrlist);
  PList_delete(rvlist);
  return 1;
}


/*
   return 1 if all regions hooked on the given vertex are valid
          0 otherwise  
*/
int ValidCheck(pVertex vert)
{
  pRegion region;
  pPList vrlist;
  void *temp=0;

  vrlist=V_regions(vert);
  while(region=(pRegion)PList_next(vrlist,&temp)) {
    if(R_checkFlat(region)) {
      PList_delete(vrlist);
      return 0;
    }
  }
  PList_delete(vrlist);

  return 1;
}


/*
  return 0:  visible region does not exist
         1:  visible region is found and returned by reference

  50/09/2000  created                 by X. Li
  07/20/2000  several bugs are fixed  by X. Li
  09/19/2000  rewrite most the code to increase performance   X. Li
*/
int VisibleRegion(pVertex vert, SCOREC::Util::scorecSSList<double *> &ptList)
{
  pRegion region, regions[2];
  pFace face, faces[2];
  pEdge edge;
  pVertex vertex;
  pVertex E_verts[2];
  pVertex F_verts[3];
  double F_xyz[3][3], start[3], end[3], dir[3], int_xyz[3];
  double xyz[4][3], volume;
  void *temp, *temp_2;
  int i, j, k, flag, infinite;

  double mtol=M_getTolerance();
  double tol2=mtol*mtol;
  double tol3=tol2*mtol;

  SCOREC::Util::scorecSSListIter<double *> PtIter(ptList);
  double *pt;

  pPList fverts;
  pPList rverts;
  pPList edgelist=PList_new();
  pPList facelist=PList_new();
  pPList reglist=PList_new();
  pPList flist=V_faces(vert);

  // initialize the edge list
  // if there is a ZERO-length edge, no visible region
  // if it is a concave edge, attach the two faces using it on polyhedron 
  temp=0;
  while(face=(pFace)PList_next(flist,&temp)) {
    edge=F_vtOpEd(face,vert);
    if(adaptUtil::E_lengthSq(edge) < tol2) {
      PList_delete(flist);
      PList_delete(edgelist);
      PList_delete(reglist);
      PList_delete(facelist);
      return 0;
    }
    PList_append(edgelist,edge);

    // get the two/one regions adjacent the face hooked on vert
    regions[0]=F_region(face,0);
    if( !regions[0] ) {
      regions[0]=F_region(face,1); 
      flag=1;
    } else {
      regions[1]=F_region(face,1);
      if( !regions[1] )
        flag=1;
      else
        flag=2;
    }

    if( flag==1 ) continue;

    // get the two faces using the boundary edge
    faces[0]=R_vtOpFc(regions[0],vert);
    faces[1]=R_vtOpFc(regions[1],vert);

    // see if the dihedral angle between above two faces is greater than 180
    F_coord(faces[0],xyz);
    V_coord(F_edOpVt(faces[1], edge),xyz[3]);
    volume=XYZ_volume(xyz);
    if( R_dirUsingFace(regions[0], faces[0]) )
      volume=-volume;

    if(volume < -tol3) {
      // Here, we have a concave edge (dihedral angle between the two boundary 
      // faces is greater than 180 wrt the polyhedron), remember the two faces
      if( !PList_inList(facelist,faces[0]) ) {
        PList_append(facelist,faces[0]);
        PList_append(reglist,regions[0]);
      }
      if( !PList_inList(facelist,faces[1]) ) {
        PList_append(facelist,faces[1]);
        PList_append(reglist,regions[1]);
      }
    }    
  }
  PList_delete(flist);

  // calculate all possibles intersection points
  temp=0;
  while(face=(pFace)PList_next(facelist,&temp)) {
    
    // get the coordinates of the three verices of current face
    fverts=F_vertices(face,1);
    temp_2=0; 
    for( j=0; j<3; j++ ) {
      F_verts[j]=(pVertex)PList_next(fverts,&temp_2);
      V_coord(F_verts[j],F_xyz[j]);
    }
    PList_delete(fverts);
      
    temp_2=0;
    while(edge=(pEdge)PList_next(edgelist,&temp_2)) {

      E_verts[0]=E_vertex(edge,0);
      E_verts[1]=E_vertex(edge,1);

      // see if edge_2 is connected to faces[i]
      flag=0;
      for(j=0; j<3; j++) 
        if( F_verts[j]==E_verts[0] || F_verts[j]==E_verts[1] )
          { flag=1; break; }
      if( flag ) continue;

      // check to see if the plane intersects with the line
      V_coord(E_verts[0],start);
      V_coord(E_verts[1],end);

      diffVt(start,end,dir);
      if( M_intersectLine3XYZ(end, dir, F_xyz, int_xyz, &infinite) ) {
        if(infinite) continue;
        double *new_pt=new double[3];
        new_pt[0]=int_xyz[0];
        new_pt[1]=int_xyz[1];
        new_pt[2]=int_xyz[2];
        ptList.append(new_pt);
      }
    }
  }

  // remove these points located on the plane or negative side of any mesh faces
  // bounding the polyhedron from the point list
  temp=0;
  while(region=(pRegion)PList_next(reglist,&temp)) {
    
    rverts = R_vertices(region,1);
    temp_2=0; i=0; k=0;
    while (vertex = (pVertex)PList_next(rverts, &temp_2)) {
      if(vertex == vert) 
        j=i++; 
      else 
        V_coord(vertex,xyz[i++]);
    }
    PList_delete(rverts);

    // throw those locations away if on negative side
    PtIter.reset();
    while(PtIter(pt)) {
      xyz[j][0]=pt[0];  xyz[j][1]=pt[1];  xyz[j][2]=pt[2];
      if(XYZ_volume(xyz) <= 0.0) {
        PtIter.remove();
        delete[] pt;
      }
    }
  }

  // get rid of the duplicated points in point list
  PtIter.reset();
  while(PtIter(pt)) 
    if( isDuplicated(pt, ptList, tol2)==2 ) {
      PtIter.remove();
      delete[] pt;
    }

  // initilize a vertex list to be all vertices on the polyhedron
  SCOREC::Util::scorecSSList<pVertex> vtlist;
  SCOREC::Util::scorecSSListIter<pVertex> vertIter(vtlist);
  for(i=0; i<V_numEdges(vert); i++) {
    edge=V_edge(vert,i);
    vtlist.append(E_otherVertex(edge,vert));
  }

  // remove vertices on the negative side of any mesh faces bounding the polyhedron
  // from above list 
  temp=0;
  while(region=(pRegion)PList_next(reglist,&temp)) {
    
    rverts = R_vertices(region,1);
    temp_2=0; i=0; k=0;
    while (vertex = (pVertex)PList_next(rverts, &temp_2)) {
      if(vertex == vert) 
        j=i++; 
      else {
        V_coord(vertex,xyz[i++]);
        F_verts[k++]=vertex;
      }
    }
    PList_delete(rverts);
    
    vertIter.reset();
    while ( vertIter(vertex) ) {
      // see if current region is bounded by current vertex
      if( vertex==F_verts[0] || vertex==F_verts[1] || vertex==F_verts[2] )
        continue;
      
      // if vertex on the negative side, it should be removed from vtlist
      V_coord(vertex,xyz[j]);
      if(XYZ_volume(xyz) < -1.0*tol3) 
        vertIter.remove();
    }
  }

  // add the remaining vertices in above vertex list into point list
  while ( vertIter(vertex) ) {
    double *new_pt=new double[3];
    V_coord(vertex,new_pt);
    ptList.append(new_pt);
  }

  PList_delete(reglist);
  PList_delete(edgelist);
  PList_delete(facelist);

  // check if all points nearly locate on a plane
  if(ptList.size() > 3) {
    PtIter.reset();  
    i=0;
    while(PtIter(pt)) {
      if(i < 3)
        { xyz[i][0]=pt[0];  xyz[i][1]=pt[1];  xyz[i++][2]=pt[2]; }
      else {
        xyz[3][0]=pt[0];  xyz[3][1]=pt[1];  xyz[3][2]=pt[2];
        volume = XYZ_volume(xyz);
        if(volume < tol3 && volume > -tol3) continue;
        return 1;
      }
    }
  }

  // delete memory
  PtIter.reset();
  while(PtIter(pt))
    { delete[] pt; PtIter.remove(); }

  return 0;
}


void DeleteVisibleRegion(SCOREC::Util::scorecSSList<double *> &ptList)
{
  SCOREC::Util::scorecSSListIter<double *> PtIter(ptList);
  double *pt;
  while(PtIter(pt))
    { delete[] pt; PtIter.remove(); }

  return;
}

/*
   return 0 if point does not exist in list
          1 if point is unique in list
          2 if point is at least duplicated
*/
int isDuplicated(double *xyz, SCOREC::Util::scorecSSList<double *> &ptList, double tol2)
{
  SCOREC::Util::scorecSSListIter<double *> PtIter(ptList);
  double *pt;
  int count=0;

  while(PtIter(pt)) {
    if(XYZ_distance2(pt,xyz) < tol2)
      ++count;
    if(count==2)
      return 2;
  }
  return count;
}


/*
  return 1:  vertex vd is collapsed
         0:  no collapse applied

  if flag=1, a pPList of mesh faces needs to be updated
          0, no need for updating
     type=Gface, collapse a vertex of surface mesh
          otherwise, collapse a vertex in volume mesh
*/
int RemoveAVertex(pMesh pmesh, pSField field, pVertex vd, int type,
		  int flag, pPList TPM00, CBFunction CB, void *userData)
{
  pEdge edgeDel;
  pVertex vr;
  pFace face;
  pPList newRgns;
  double sqrSize;
  int i;

  std::vector< std::pair<double,pEdge> > stdVector;
  for(i=0; i<V_numEdges(vd); i++) {
    edgeDel=V_edge(vd,i);
    sqrSize=field->lengthSq(edgeDel);
    stdVector.push_back(std::make_pair(sqrSize,edgeDel));
  }
  std::sort(stdVector.begin(),stdVector.end());

  std::vector< std::pair<double,pEdge> >::iterator pairIt;
  for(pairIt=stdVector.begin();pairIt!=stdVector.end();++pairIt) 
    {
      edgeDel=(*pairIt).second;
      vr=E_otherVertex(edgeDel,vd);

      if (!E_chkClpTopo (vd, edgeDel)) 
	continue;
      if(E_evalColaps(pmesh,edgeDel,vd,vr)) 
	{
	  if( flag==1 ) 
	    for( i=0; i<E_numFaces(edgeDel); i++ ) 
	      {
		face=E_face(edgeDel,i);
		PList_remItem(TPM00,face);
	      }

	  if( field )
	    field->deleteSize((pEntity)vd);
	  templatesUtil::Edge_colaps(pmesh,edgeDel,vd,vr,CB,userData,&newRgns);
	  PList_delete(newRgns);
	  return 1;
	}
    }
  return 0;
}

pPList R_adjRegions(pRegion region)
{
  pRegion otherRgn;
  pFace face;

  pPList rlist=PList_new();

  for(int i=0; i<4; i++) {
    face=R_face(region,i);
    otherRgn=F_otherRgn(face, region);
    if(otherRgn)
      PList_append(rlist,otherRgn);
  }

  return rlist;
}

/*
   see if it is a closed cavity (Cavity is defined in two list)
   return 1 if it is closed
          0 otherwise
   Created  9/8/2000    XiangrongLi 
*/
#ifdef DEBUG
int isCavityClosed(pPList *faces)
{
  pFace face, face_2;
  pEdge edge;
  int i,ok;
  void *temp=0;
  void *temp_2;

  while(face=(pFace)PList_next(*faces,&temp)) {
    for(i=0; i<3; i++) {
      edge=F_edge(face,i);
      temp_2=0;
      ok=0;
      while(face_2=(pFace)PList_next(*faces,&temp_2)) {
        if(face_2==face) continue;
        if(F_inClosure(face_2,(pEntity)edge))
          { ok=1; break; }
      }
      if(!ok) {
        cout << "   Open Cavity:  edge="<<edge<<"  face="<<face<<endl;
        return 0;
      }
    }
  }
  return 1;
}
#endif


/*
  Function: get the parameter of a boundary vertex and re-parameterize it onto
            the given model face
  
  return 1: all parameters are gotten correctly
         0: function fails
  
  Created:  10/11/00   Xiangrong Li
  Last Mod: 01/07/01
*/
int V_reparamOnGFace(pVertex vert, pGFace gface, double *par)
{
  // get the parameter and re-parameterize them on model face
  switch( V_whatInType(vert) ) {
  case Gface: {
    pPoint pt=V_point(vert);
#ifdef DEBUG
    if( V_whatIn(vert) != (pGEntity)gface )
      { cout << "...vertex not inclosure of model face (1) (V_reparamOnGFace)"<<endl;   return 0; }
#endif
    P_param2(pt,par,(par+1),(int *)(par+2));
    break;
  }
  case Gedge: {
    pPoint pt=V_point(vert);
    double e_par=P_param1(pt);
    pGEdge ge=(pGEdge)V_whatIn(vert);
#ifdef DEBUG
    if(adaptUtil::GF_inClosure(gface, (pGEntity)ge))
      GF_edgeReparam(gface, ge, e_par, 1, par);
    else
      { cout << "...vertex not inclosure of model face (2) (V_reparamOnGFace)"<<endl;   return 0; }
#else
    GF_edgeReparam(gface, ge, e_par, 1, par);
#endif
    break;
  }
  case Gvertex: {
    pGVertex gv= (pGVertex)V_whatIn(vert);
#ifdef DEBUG
    if(adaptUtil::GF_inClosure(gface, (pGEntity)gv))
      GF_vertexReparam(gface, gv, par);
    else
      { cout << "...vertex not inclosure of model face (3) (V_reparamOnGFace)"<<endl;   return 0; }
#else
    GF_vertexReparam(gface, gv, par);
#endif
    break;
  }
  default: 
    cerr<<"...a boundary vertex classified on model region (V_reparamOnGFace)"<<endl; 
    cerr<<"   id:"<<EN_id((pEntity)vert)<<"  address:"<<vert<<endl;
    exit(0);
  }
  
  *(par+2)=0.0;
  return 1;
}

/* 
   given a mesh vertex classified on model vertex or model edge, 
   get its parameter w.r.t the given model edge

   return 1 if the parameter is retrieved correctly
          0 can not retrieve the parameter

   Created 9/25/01
*/ 
int V_reparamOnGEdge(pVertex vert, pGEdge ge, double *par)
{
  switch( V_whatInType(vert) ) {

  case Gedge: 
#ifdef DEBUG
    if( V_whatIn(vert) != (pGEntity)ge )
      { cout << "...vertex not inclosure of model edge (1)"<<endl;   return 0; }
#endif
    *par=P_param1(V_point(vert));
    break;

  case Gvertex: {
    pGVertex gv= (pGVertex)V_whatIn(vert);
#ifdef DEBUG
    if(GE_inClosure(ge, (pGEntity)gv))
      *par=GE_vertexReparam(ge, gv);
    else
      { cout << "...vertex not inclosure of model edge (2)"<<endl;   return 0; }
#else
    *par=GE_vertexReparam(ge, gv);
#endif
    break;
  }

  default:
    return 0;
  }

  return 1;
}


int F_fixPeriodicParams(pGFace gface, double tol, double par[3][3])
{
  double low, high, period, half;
  int i, dir;

  // take care of geometry degeneracy
  for( i=0; i<3; i++ ) {
    dir=ifDegenerated(gface, par[i], tol);
    if( dir==-1 )  continue;
    dir=(dir+1)%2;
    GF_parRange(gface,dir,&low,&high);
    period=high-low;
    if( par[(i+1)%3][dir]-par[(i+2)%3][dir]>0.5*period ) 
      par[(i+2)%3][dir] += period;
    par[i][dir]=0.5*(par[(i+1)%3][dir]+par[(i+2)%3][dir]);
// #ifdef DEBUG
//     cout<<"...Info - detected a degenerated location (F_fixPeriodicParams)"<<endl;
// #endif
  }

  // take care of periodic model face
  for( i=0; i<2; i++ ) {
   
    if(GF_periodic(gface,i)) {
      GF_parRange(gface,i,&low,&high);
      period=high-low;
      half=0.5*period;

      // if the parameter difference is exactly half period, the assumption does not work
#ifdef DEBUG
      if( ABS(ABS(par[0][i]-par[1][i])-half)<tol ||
	  ABS(ABS(par[1][i]-par[2][i])-half)<tol ||
	  ABS(ABS(par[2][i]-par[0][i])-half)<tol )
	{cout << "Error:detected an edge with half period difference"<<endl; return 0;}
#endif

      // correct parameters based on less-half-period assumption
      if( par[0][i]-par[1][i]>half ) par[1][i] += period;
      else if( par[1][i]-par[0][i]>half ) par[0][i] += period;

      if( par[1][i]-par[2][i]>half ) par[2][i] += period;
      else if( par[2][i]-par[1][i]>half ) par[1][i] += period;

      if( par[2][i]-par[0][i]>half ) par[0][i] += period;
      else if( par[0][i]-par[2][i]>half ) par[2][i] += period;
    }
  }
  return 1;
}

// check the degeneracy of a location in parametric space
// if model face has no degeneracy, return -1
// if model face has degeneracy, but the location is not degenerated, return -1
// if model face has degeneracy and the location is degenerated, 
//        return 0  if a location in 1st parametric direction is degenerated (2nd parameter uncertain)
//               1  if a location in 2nd parametric direction is degenerated (1st parameter uncertain)
int ifDegenerated(pGFace gf, double *par, double tol)
{
  double depar[2];
  int i,dir;

#ifndef SCOREC_MESH
  for( dir=0; dir<2; dir++ ) {
    int num=GF_paramDegeneracies(gf, dir, depar);
    for( i=0; i<num; i++ )
      if( ABS(par[dir]-depar[i])<tol ) 
        return dir;
  }
#else
  double tmp[2],xyz1[3],xyz2[3],vec[3];
  double low,high;
  for( dir=0; dir<2; dir++ ) {
    if( C_parType(Gface,gf,dir) ) continue;
    GF_parRange(gf,dir,&depar[0],&depar[1]);
    for( i=0; i<2; i++ ) {
      if( fabs(par[dir]-depar[0])<tol ) {
        GF_parRange(gf,(dir+1)%2,&low,&high);
        tmp[dir]=par[dir];
        tmp[(dir+1)%2]=low;
        GF_point(gf, tmp, xyz1);
        tmp[(dir+1)%2]=0.5*(low+high);
        GF_point(gf, tmp, xyz2);
        diffVt(xyz1,xyz2,vec);
        if( dotProd(vec,vec)<tol*tol ) return dir;
      }
    }
  }
#endif

  return -1;
}


//  this function check the normal of a boundary mesh face
//  return -1  if it is inconsistent with the model normal
//          1  consistent
//         -2  parameters can not be gotten successfully
//          0  the third component of the normal in parametric space is 0
//
//  "consistent" means the mesh face is defined in the same direction as model face
//  (set dir=1, the bounding vertices or edges are returned in the defined direction) 
//
//  if inconsistent (-1), there are two possibilities:
//     (a) normal becomes flipped
//     (b) parametric difference is greater than half period
//  the chance of both above happenning together is rare, 
//  So we just consider "returning 1" as "consistent".
//
//  10/11/00   by Xiangrong Li  
int F_checkGeoSim(pPList *F_vertices, pGFace gface)
{
  pVertex vertex;
  double par[3][3];
  int i=0;
  void *iter=0;
  double tol=GEN_tolerance((pGEntity)gface);

  // get the parameters
  while( vertex=(pVertex)PList_next(*F_vertices,&iter) ) {
    if( !V_reparamOnGFace(vertex,gface,par[i]) )  
      return -2;
    // always similar in case of any vertex in degenerated location
    if( ifDegenerated(gface,par[i],tol)!=-1 )
      return 1;
    i++;
  }

  // take care of periodic issues
  F_fixPeriodicParams(gface, tol, par);

  // check the orientation in parametric space
  return Par_checkGeoSim(gface, tol, par);
}

int F_checkGeoSim(pFace face)
{
  pPList fverts=F_verticesOutofMesh(face);
  int flag=F_checkGeoSim(&fverts,(pGFace)F_whatIn(face));
  PList_delete(fverts);
  return flag;
}
  
pPList F_verticesOutofMesh(pFace face)
{
#ifdef AOMD_
  pRegion rgn;
  pVertex vertex;
  double xyz[4][3], v01[3], v02[3], v03[3], nor[3];
  void *iter=0;
  int i=0;
  pPList fverts=F_vertices(face,1);
  if( F_region(face,0) && F_region(face,1) )
     return fverts;
  if( F_region(face,0)==0 && F_region(face,1)==0 )
     return fverts;
  while( vertex=(pVertex)PList_next(fverts,&iter) ) 
    V_coord(vertex,xyz[i++]);
  diffVt(xyz[1],xyz[0],v01);
  diffVt(xyz[2],xyz[0],v02);
  crossProd(v01,v02,nor);
  rgn=F_region(face,0);
  if( !rgn ) rgn=F_region(face,1);
  vertex=R_fcOpVt(rgn,face);
  V_coord(vertex,xyz[3]);
  diffVt(xyz[3],xyz[0],v03);
  if( dotProd(v03,nor)>0 ) {
     vertex=(pVertex)PList_item(fverts,1);
     PList_remItem(fverts,vertex);
     PList_append(fverts,vertex);
  }
  return fverts;
#else
  return F_vertices(face,1);
#endif
}


int F_checkGeoSim(pFace face, pMeshDataId ptr_geoSim)
{
  pPList F_verts;
  pGFace gface;
  pVertex vertex;
  double par[3][3];
  void *tmp_ptr;
  ParamsOnGFace *pPars;

  int attached, i;
  void *iter=0;

  // get the Params on GFace for each bounding vertex
  gface=(pGFace)F_whatIn(face);
  F_verts=F_verticesOutofMesh(face);
  i=-1;
  while( vertex=(pVertex)PList_next(F_verts,&iter) ) {
    attached=0;
    ++i;
    if( EN_getDataPtr((pEntity)vertex,ptr_geoSim,&tmp_ptr) ) {
      pPars=(ParamsOnGFace *)tmp_ptr;
      attached=1;
      if( pPars->getParam(gface,par[i]) )
	continue; 
    }

    if( !V_reparamOnGFace(vertex,gface,par[i]) )  
      return -2;

    if( attached ) {
      pPars->append(gface,par[i]);
      EN_modifyDataPtr((pEntity)vertex,ptr_geoSim,pPars);
    } else {
      pPars=new ParamsOnGFace(V_numGFaces(vertex),gface,par[i]);
      EN_attachDataPtr((pEntity)vertex,ptr_geoSim,pPars);
    }
  }
  PList_delete(F_verts); 

  // take care of periodic issues
  double tol=GEN_tolerance((pGEntity)gface);
  F_fixPeriodicParams(gface, tol, par);

  // check geoSim of this face
  return Par_checkGeoSim(gface, tol, par);
}



/*
  given the re-parametrized values, check if a face is geometric similar

  return 1:  geometric silimar
        -1:  dissimilar
         0:  the 3rd component of the normal in parametric space is zero
*/ 
int Par_checkGeoSim(pGFace gface, double tol, double par[3][3])
{
  double x1[3],x2[3], normal[3];

  // calculate normal in parametric space
  diffVt(par[1],par[0],x1);
  diffVt(par[2],par[0],x2);
  crossProd(x1,x2,normal);

  // check validity
  tol=tol*tol;
  if( ABS(normal[2])<tol )    return 0; 

  // check consistency
  switch( GF_geomDirection(gface) ) {
  case 1:
    if( normal[2]>0 )  
      return 1; 
    break;
  case -1:
    if( normal[2]<0 ) 
      return 1; 
    break;
  default:
    cout<<" GF_geomDirection() returns neither 1 nor -1"<<endl;
  }

  return -1;
}  


// check if the normal of all boundary mesh faces are consistent with the model
  void M_checkGeoSim(pMesh mesh) {
    pFace face;
    pPList F_verts;
    pGFace gface;

    FIter fit=M_faceIter(mesh);
    while( face=FIter_next(fit) ) {
      if( F_whatInType(face)==Gregion ) continue;
      F_verts=F_verticesOutofMesh(face);
      gface=(pGFace)F_whatIn(face);
      switch( F_checkGeoSim(&F_verts,gface) ) {
      case -1:
	cout<<"face "<<face<<" has flipped normal or more than half period parametric span"<<endl;
	break;
      case -2:
	cout<<"can not get parameters at bounding vertices of face "<<face<<endl; 
	break;
      case 0:
	cout<<"the 3rd component of face "<<face<<"'s normal is zero"<<endl;
	break;
      }
      PList_delete(F_verts);
    }

    FIter_delete(fit);
    return;
  }


double GF_Tolerances(pGFace gf)
{
  double Tf,Te,Tv,Tmax;

  Tf=GEN_tolerance((pGEntity)gf);
  cout<<" faceTolerance:       "<<Tf<<endl;
  Tmax=Tf;

  pGEdge ge;
  pPList gedges=GF_edges(gf);
  void *iter=0;
  cout<<" edgeTolerances:      ";
  while( ge=(pGEdge)PList_next(gedges,&iter) ) {
    Te=GEN_tolerance((pGEntity)ge);
    cout<<Te<<"    ";
    if( Te>Tmax ) Tmax=Te;
  }
  cout<<endl;
  PList_delete(gedges);

  pGVertex gv;
  pPList gvertices=GF_vertices(gf);
  iter=0;
  cout<<" vertexTolerances:    ";
  while( gv=(pGVertex)PList_next(gvertices,&iter) ) {
    Tv=GEN_tolerance((pGEntity)gv);
    cout<<Tv<<"    ";
    if( Tv>Tmax ) Tmax=Tv;
  }
  cout<<endl;
  PList_delete(gvertices);

  return Tmax;
}


double GE_Tolerances(pGEdge ge)
{
  double Te,Tv,Tmax;

  Te=GEN_tolerance((pGEntity)ge);
  cout<<" edgeTolerance:       "<<Te<<endl;
  Tmax=Te;

  pGVertex gv;
  pPList gvertices=GE_vertices(ge);
  void *iter=0;
  cout<<" vertexTolerances:    ";
  while( gv=(pGVertex)PList_next(gvertices,&iter) ) {
    Tv=GEN_tolerance((pGEntity)gv);
    cout<<Tv<<"    ";
    if( Tv>Tmax ) Tmax=Tv;
  }
  cout<<endl;
  PList_delete(gvertices);

  return Tmax;
}


void G_info(pGModel model)
{
  cout<<"     -- model info --   "<<endl;
  cout<<" # of regions:"<<GM_numRegions(model)<<endl;
  cout<<" # of faces:"<<GM_numFaces(model)<<endl;
  cout<<" # of edges:"<<GM_numEdges(model)<<endl;
  cout<<" # of vertices:"<<GM_numVertices(model)<<endl;

  GFIter iter=GM_faceIter(model);
  pGFace gf;
  while( gf=(pGFace)GFIter_next(iter) ) 
    GF_info(gf);

  return;
}


void GF_info(pGFace gf)
{
  int dir;
  double par[2],xyz[3];
  double high,low;
  pGEdge ge;
  pGVertex gv;

  cout<<gf<<"   Tag:"<<GEN_tag((pGEntity)gf) << endl;//"  ID: "<<GEN_id((pGEntity)gf)<<endl;

//   switch( C_gmtype(Gface,gf) ) {
//   case 0:   cout<< "SurfaceType: unknown"<<endl;  break;
//   case 6:   cout<< "SurfaceType: plane"<<endl;  break;
//   case 7:   cout<< "SurfaceType: nurb"<<endl;;  break;
//   case 8:   cout<< "SurfaceType: cylinder"<<endl;;  break;
//   case 9:   cout<< "SurfaceType: sphere"<<endl;;  break;
//   case 10:  cout<< "SurfaceType: cone"<<endl;;  break;    
//   case 11:  cout<< "SurfaceType: torus"<<endl;;  break;
//   case 12:  cout<< "SurfaceType: parametric surface"<<endl;;  break;
//   default:  cout<< "SurfaceType: undefined"<<endl;;
//   }

  for( dir=0; dir<2; dir++ ) {
    cout<<" parametric direction "<<dir<<":"<<endl;
#ifndef SCOREC_MESH
    int num=GF_paramDegeneracies(gf, dir, par);
    cout<<" - Degeneracy:"<<num;
    for( int i=0; i<num; i++ )
      cout<<"  "<<par[i];
    cout<<endl;
#endif
    cout<<" - Periodicity:"<<GF_periodic(gf,dir);
    cout<<" - ParRange ("<<dir<<"): ";
    GF_parRange(gf, dir, &low, &high);
    cout<<low<<"~"<<high<<endl;
  }
  cout<<endl;

  cout<<"Bounding edges:"<<endl;
  pPList gedges=GF_edges(gf);
  void *iter=0;
  while( ge=(pGEdge)PList_next(gedges,&iter) ) {

    cout<<"  "<<ge<<"  ";
//     switch( C_gmtype(Gedge,ge) ) {
//     case 0:   cout<< "EdgeType: unknown  ";  break;
//     case 2:   cout<< "EdgeType: Line  ";  break;
//     case 3:   cout<< "EdgeType: circle  ";  break;
//     case 4:   cout<< "EdgeType: Ellipse  ";  break;
//     case 5:   cout<< "EdgeType: ParametricCurve  ";  break;    
//     default:  cout<< "EdgeType: undefined  ";
//     }

    cout<<"tag="<<GEN_tag((pGEntity)ge) <<endl;//" id="<<GEN_id((pGEntity)ge)<<" range:";
    GE_parRange(ge, &low, &high);
    cout<<low<<"~"<<high;
    if( GE_periodic(ge) )
      cout<<"  periodic";
    cout<<endl;
  }
  PList_delete(gedges);
  cout<<endl;

  cout<<"Bounding vertices:"<<endl;
  pPList gvertices=GF_vertices(gf);
  iter=0;
  while( gv=(pGVertex)PList_next(gvertices,&iter) ) {
    cout<<"  "<<gv<<" tag="<<GEN_tag((pGEntity)gv) <<endl;//" id="<<GEN_id((pGEntity)gv)<<" coords:";
    GV_point(gv,xyz);
    cout<<"("<<xyz[0]<<" "<<xyz[1]<<" "<<xyz[2]<<")"<<" pars:";
    GF_vertexReparam(gf, gv, par);
    cout<<"("<<par[0]<<" "<<par[1]<<")"<<endl;
  }
  cout<<endl;
  PList_delete(gvertices);

  return;
}


int GF_inClosure(pGFace gf, pGEntity gent)
{
  void *iter=0;

  switch( GEN_type(gent) ) {
  case Gedge: {
    pPList gedges=GF_edges(gf);
    pGEdge ge;
    while( ge=(pGEdge)PList_next(gedges,&iter) ) 
      if( ge==(pGEdge)gent ) {
	PList_delete(gedges);
	return 1;
      }
    PList_delete(gedges);
    break;
  }
  case Gvertex: {
    pPList gvertices=GF_vertices(gf);
    pGVertex gv;
    while( gv=(pGVertex)PList_next(gvertices,&iter) ) 
      if( gv==(pGVertex)gent ) {
	PList_delete(gvertices);
	return 1;
      }
    PList_delete(gvertices);
    break;
  }
  }
  return 0;
}


// 10/30/2000  X-R Li
void V_bdryfacesOngface(pVertex vt,pGEntity gent,pPList *facesOnGf)
{
  pPList faces=V_faces(vt);

  pFace face;
  void *iter=0;
  while( face=(pFace)PList_next(faces,&iter) ) {
    if( F_whatInType(face)!=Gface ) continue;
    if( F_whatIn(face)!=gent ) continue;
    PList_append(*facesOnGf,face);
  }
  PList_delete(faces);
  return;
}
    

pFace E_otherBdryFace(pEdge edge, pFace face)
{
  pFace otherFace;

  if( E_whatInType(edge)!=Gface ) return 0;

  for( int i=0; i<E_numFaces(edge); i++ ) {
    otherFace=E_face(edge,i);
    if( F_whatInType(otherFace)==Gregion ) continue;
    if( otherFace==face ) continue;
    return otherFace;
  }

  return 0;
}


int V_numGFaces(pVertex vertex)
{
  if( V_whatInType(vertex)==Gface )
    return 1;

  pPList list = GV_faces((pGVertex)V_whatIn(vertex));   
  int size=PList_size(list);
  PList_delete(list);
  return size;
}


// Calculate the mesh size associated with vertex. called from MA_Vtx_Size() defined in MA.h
int Vtx_Size(pVertex pVertexVtx, double dAnisoSize[3][3])
{
  int iNumEdge;
  double dEdgeLength = 0, dEdgeLocLength;;
  double dEdgeMinMax[2] = {10e+20, 0.};
  pEdge pEdgeEdge;
  if (EN_isBLEntity(pVertexVtx))
  {
    double dLayerEdgeLength = 0;
    int iEdgeTypeInBL;
    int iNumLayerEdgeCount = 0;
    int iNumGrowthEdgeCount = 0;
    iNumEdge = V_numEdges(pVertexVtx);
    for (int iEdge = 0; iEdge < iNumEdge; ++iEdge)
    {
      pEdgeEdge = V_edge(pVertexVtx, iEdge);
      iEdgeTypeInBL = E_typeInBL(pEdgeEdge);
      if (iEdgeTypeInBL == eGROWTH)
      {
        iNumGrowthEdgeCount++;
        dEdgeLocLength = sqrt(adaptUtil::E_lengthSq(pEdgeEdge));
        dEdgeLength += dEdgeLocLength;
      }
      else if (iEdgeTypeInBL)
      {
        iNumLayerEdgeCount++;
        dEdgeLocLength = sqrt(adaptUtil::E_lengthSq(pEdgeEdge));
        if (dEdgeLocLength < dEdgeMinMax[0])
          dEdgeMinMax[0] = dEdgeLocLength;
        else dEdgeMinMax[1] = dEdgeLocLength;
        dLayerEdgeLength += dEdgeLocLength;
      }
    }
    dEdgeLength = dEdgeLength / iNumGrowthEdgeCount;
    dAnisoSize[0][0] = dEdgeLength;
    dLayerEdgeLength = dLayerEdgeLength / iNumLayerEdgeCount;
    dAnisoSize[1][1] = dAnisoSize[2][2] = dLayerEdgeLength;

    for (int iRow = 0; iRow < 3; ++iRow)
    {
      for (int iClm = 0; iClm < 3; ++iClm)
        if (iRow != iClm)
          dAnisoSize[iRow][iClm] = 0.;
    }    
  }
  else
  {
    iNumEdge = V_numEdges(pVertexVtx);
    for (int iEdge = 0; iEdge < iNumEdge; ++iEdge)
    {
      pEdgeEdge = V_edge(pVertexVtx, iEdge);
      dEdgeLocLength = sqrt(adaptUtil::E_lengthSq(pEdgeEdge));
      if (dEdgeLocLength < dEdgeMinMax[0])
        dEdgeMinMax[0] = dEdgeLocLength;
      else dEdgeMinMax[1] = dEdgeLocLength;
      dEdgeLength += dEdgeLocLength; 
    }
    dEdgeLength = dEdgeLength / iNumEdge;
    for (int iRow = 0; iRow < 3; ++iRow)
    {
      for (int iClm = 0; iClm < 3; ++iClm)
        if (iRow = iClm)
          dAnisoSize[iRow][iClm] = dEdgeLength;
        else
          dAnisoSize[iRow][iClm] = 0.;
    }     
  }
}


/*
  Check if the face is a front face of the mesh 
  embedded and non-manifold faces are also taken into account
*/
int isfacefront(pFace face2,pGModel model,pGRegion *greg)
{

int nr,ngr;
pGRegion gregion;
pRegion region;
pGEntity gen;
int gentype;
int i,k,ok;
pRegion mregs[2];
pGRegion gregs[2];
pGRegion outerReg;

 if(model==0)
   outerReg=0;
 else
   { cout<<" routine GM_outerRegion not available"<<endl; exit(0); }
//    outerReg=GM_outerRegion(model);

/*check if it is a front face*/

  nr=0;
 for(k=0;k<2;++k){
   region=F_region(face2,k);
   if(region){
     mregs[nr]=region;
     ++nr;
   }
 }
 if(nr==2) {
   cout<<" nr==2 face="<<face2<<endl;
   return(0);
 }

 /*check if face2 on the model face*/
 
 gen=F_whatIn(face2);
 gentype=GEN_type(gen);

 if(gentype==Tface){

   ngr=0;
   for(k=0;k<2;++k){
     gregion=GF_region((pGFace)gen,k);
     if(gregion && gregion!=outerReg){
       gregs[ngr]=gregion;		
       ++ngr;
     }
   }
   /* outer embedded mface */
   if(ngr==0)
     return(0);
   if(ngr<2 && nr>0)
     return(0);
 }
 else {
   ngr=1;
   gregs[0]=(pGRegion)gen;
 }

 /* face2 is a front */
 /* check if the front is for greg; if not do accept the face as a front */
 if(*greg){
   ok=0;
   for(i=0;i<ngr;++i){
     if(gregs[i]==*greg){
       ok=1;
       break;
     }
   }
   if(!ok)
     return(0);

   if(gentype==Tregion)
     return(1);

   for(k=0;k<nr;++k)
     if(R_whatIn(mregs[k])==*greg)
       return(0);

   return(1);
   
 }
 else{
 
  if(nr==1)
    if(gentype==Tregion)
      *greg=gregs[0];
    else
      for(i=0;i<ngr;++i){
	if(R_whatIn(mregs[0])!=gregs[i]){
	  *greg=gregs[i];
          break;
	} 
      }
  else
    *greg=gregs[0];

  return(1);	
 }        

}

void maxminEdgeLength(pSField field, pVertex vd, double *max, double *min)
{
  double l;
  int n=V_numEdges(vd);
  
  if( !n ) 
    { cout<<" WARNING: a flying mesh vertex"<<endl; return; }

  if( field )
    *max=field->lengthSq(V_edge(vd,0));
  else
    *max=adaptUtil::E_lengthSq(V_edge(vd,0));
  *min=*max;

  for(int i=1;i<n;i++) {
    if( field )
      l=field->lengthSq(V_edge(vd,i));
    else
      l=adaptUtil::E_lengthSq(V_edge(vd,i));
    if( l>*max ) *max=l;
    if( l<*min ) *min=l;
  }

  return;
}
 
/* print the shape distribution of a mesh */   
void M_checkShape(pMesh mesh, pSField mf)
{
  if( M_numRegions(mesh)==0 )
    M_checkShape2D(mesh,mf);

  else {
  pRegion region, worRgn;
  int i;
  double shape;
  double worstShape=1.e10;
  double bestShape=0.0;
  double averageShape=0.0;

  double sml, big;
  double biggestDhA=1.0, smallDHA=-1;

  int shape_profile[]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
  double dihd_profile[13];
  double shape_per[16];

  MeanRatio myShape(mf);

  for( i=0; i<13; i++ ) 
    dihd_profile[i]=0;

  void *iter=0;
  RIter r_iter=M_regionIter(mesh);
  while( region=RIter_next(r_iter) ) {
    if( mf )
      myShape.R_shape(region,&shape);
    else
      R_shape(region,&shape);

    if( shape<0.0 ) ++shape_profile[0];
    else if( shape<1.0e-5 ) ++shape_profile[1];
    else if( shape<1.0e-4 ) ++shape_profile[2];
    else if( shape<1.0e-3 ) ++shape_profile[3];
    else if( shape< 0.01 ) ++shape_profile[4];
    else if( shape< 0.05 ) ++shape_profile[5];
    else if( shape< 0.1 ) ++shape_profile[6];
    else if( shape< 0.2 ) ++shape_profile[7];
    else if( shape< 0.3 ) ++shape_profile[8];
    else if( shape< 0.4 ) ++shape_profile[9];
    else if( shape< 0.5 ) ++shape_profile[10];
    else if( shape< 0.6 ) ++shape_profile[11];
    else if( shape< 0.7 ) ++shape_profile[12];
    else if( shape< 0.8 ) ++shape_profile[13];
    else if( shape< 0.9 ) ++shape_profile[14];
    else ++shape_profile[15];

    averageShape += shape;
    if( shape<worstShape ) 
      {
	worstShape=shape;
	worRgn=region;
      }
    if( shape>bestShape ) bestShape=shape;

    R_dihedral(region,&sml,&big);
    if( big<Dh_175 ) ++dihd_profile[0];
    else if( big<Dh_170 ) ++dihd_profile[1];
    else if( big<Dh_160 ) ++dihd_profile[2];
    else if( big<Dh_150 ) ++dihd_profile[3];
    else if( big<Dh_140 ) ++dihd_profile[4];
    else if( big<Dh_130 ) ++dihd_profile[5];
    else if( big<Dh_120 ) ++dihd_profile[6];
    else if( big<Dh_110 ) ++dihd_profile[7];
    else if( big<Dh_100 ) ++dihd_profile[8];
    else if( big<Dh_90 ) ++dihd_profile[9];
    else if( big<Dh_80 ) ++dihd_profile[10];
    else if( big<Dh_70 ) ++dihd_profile[11];
    else if( big<Dh_70 ) ++dihd_profile[12];

    if( big<biggestDhA ) biggestDhA=big;
    if( sml>smallDHA ) smallDHA=sml;    
  }

  RIter_delete(r_iter);
  int nr=M_numRegions(mesh);
  averageShape=averageShape/nr;

  for( i=0; i<13; i++ ) 
    dihd_profile[i]=(double)dihd_profile[i]/(double)nr;
    

  cout<<"  -> shape distribution <-"<<endl;
  cout<<"   ~0.0    "<< shape_profile[0]<<endl;
  cout<<"0.0~e-5    "<< shape_profile[1]<<endl; 
  cout<<"e-5~e-4    "<< shape_profile[2]<<endl;
  cout<<"e-4~e-3    "<< shape_profile[3]<<endl;
  cout<<"e-3~0.01   "<< shape_profile[4]<<endl;
  cout<<"0.01~0.05  "<< shape_profile[5]<<endl;
  cout<<"0.05~0.1   "<< shape_profile[6]<<endl;
  cout<<"0.1~0.2    "<< shape_profile[7]<<endl;
  cout<<"0.2~0.3    "<< shape_profile[8]<<endl;
  cout<<"0.3~0.4    "<< shape_profile[9]<<endl;
  cout<<"0.4~0.5    "<< shape_profile[10]<<endl;
  cout<<"0.5~0.6    "<< shape_profile[11]<<endl;
  cout<<"0.6~0.7    "<< shape_profile[12]<<endl;
  cout<<"0.7~0.8    "<< shape_profile[13]<<endl;
  cout<<"0.8~0.9    "<< shape_profile[14]<<endl;
  cout<<"0.9~1.0    "<< shape_profile[15]<<endl;

  std::ofstream outFile("shape.dat");
  outFile<<"0.0      "<<shape_per[0]<<endl;
  outFile<<"0.000001 "<<shape_per[0]<<endl;
  outFile<<"0.000001 "<<shape_per[1]<<endl;
  outFile<<"0.00001  "<<shape_per[1]<<endl;
  outFile<<"0.00001  "<<shape_per[2]<<endl;
  outFile<<"0.0001   "<<shape_per[2]<<endl;
  outFile<<"0.0001   "<<shape_per[3]<<endl;
  outFile<<"0.001    "<<shape_per[3]<<endl;
  outFile<<"0.001    "<<shape_per[4]<<endl;
  outFile<<"0.01     "<<shape_per[4]<<endl;
  outFile<<"0.01     "<<shape_per[5]<<endl;
  outFile<<"0.05     "<<shape_per[5]<<endl;
  outFile<<"0.05     "<<shape_per[6]<<endl;
  for( i=1; i<11; i++ ) {
    outFile<<0.1*i<<"      "<<shape_per[5+i]<<endl;
    outFile<<0.1*i<<"      "<<shape_per[6+i]<<endl;
  }
  outFile<<"1.0      "<<shape_per[15]<<endl;
  outFile.close();

  std::ofstream outFile1("BigDihedral.dat");
  outFile1<<"180    "<<dihd_profile[0]<<endl;
  outFile1<<"175    "<<dihd_profile[0]<<endl;
  outFile1<<"175    "<<dihd_profile[1]<<endl;
  for( i=1; i<12; i++ ) {
    outFile1<<(18-i)*10<<"    "<<dihd_profile[i]<<endl;
    outFile1<<(18-i)*10<<"    "<<dihd_profile[i+1]<<endl;
  }
  outFile1<<"60    "<<dihd_profile[12]<<endl;
  outFile1.close();

  cout<<" worst shape:"<<worstShape<<"   inscriR:"<<R_inscrRad(worRgn)<<endl;
  cout<<" max dihedral angle:"<<57.295718*acos(biggestDhA);
  cout<<"   min dihedral angle:"<<57.295718*acos(smallDHA)<<endl;
  }

}


void M_checkShape2D(pMesh mesh, pSField mf)
{
  pFace face, worstFace;
  double shape, worstShape=1.e10;;
  double a,b,c,p,inscrR;
  int shape_profile[]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
  MeanRatio myShape(mf);

  void *iter=0;
  FIter fiter=M_faceIter(mesh);
  while( (face=FIter_next(fiter)) ) 
    {
      myShape.F_shape(face,0,&shape);
      
      if( shape<0.0 ) ++shape_profile[0];
      else if( shape<1.0e-5 ) ++shape_profile[1];
      else if( shape<1.0e-4 ) ++shape_profile[2];
      else if( shape<1.0e-3 ) ++shape_profile[3];
      else if( shape< 0.01 ) ++shape_profile[4];
      else if( shape< 0.05 ) ++shape_profile[5];
      else if( shape< 0.1 ) ++shape_profile[6];
      else if( shape< 0.2 ) ++shape_profile[7];
      else if( shape< 0.3 ) ++shape_profile[8];
      else if( shape< 0.4 ) ++shape_profile[9];
      else if( shape< 0.5 ) ++shape_profile[10];
      else if( shape< 0.6 ) ++shape_profile[11];
      else if( shape< 0.7 ) ++shape_profile[12];
      else if( shape< 0.8 ) ++shape_profile[13];
      else if( shape< 0.9 ) ++shape_profile[14];
      else ++shape_profile[15];

      if( shape<worstShape ) 
	{
	  worstShape=shape;
	  worstFace=face;
	}
    }
  FIter_delete(fiter);

  std::cout<<"  -> shape distribution <-"<<endl;
  std::cout<<"   ~0.0    "<< shape_profile[0]<<endl;
  std::cout<<"0.0~e-5    "<< shape_profile[1]<<endl; 
  std::cout<<"e-5~e-4    "<< shape_profile[2]<<endl;
  cout<<"e-4~e-3    "<< shape_profile[3]<<endl;
  cout<<"e-3~0.01   "<< shape_profile[4]<<endl;
  cout<<"0.01~0.05  "<< shape_profile[5]<<endl;
  cout<<"0.05~0.1   "<< shape_profile[6]<<endl;
  cout<<"0.1~0.2    "<< shape_profile[7]<<endl;
  cout<<"0.2~0.3    "<< shape_profile[8]<<endl;
  cout<<"0.3~0.4    "<< shape_profile[9]<<endl;
  cout<<"0.4~0.5    "<< shape_profile[10]<<endl;
  cout<<"0.5~0.6    "<< shape_profile[11]<<endl;
  cout<<"0.6~0.7    "<< shape_profile[12]<<endl;
  cout<<"0.7~0.8    "<< shape_profile[13]<<endl;
  cout<<"0.8~0.9    "<< shape_profile[14]<<endl;
  cout<<"0.9~1.0    "<< shape_profile[15]<<endl;

  a=sqrt(adaptUtil::E_lengthSq(F_edge(worstFace,0)));
  b=sqrt(adaptUtil::E_lengthSq(F_edge(worstFace,1)));
  c=sqrt(adaptUtil::E_lengthSq(F_edge(worstFace,2)));
  p=0.5*(a+b+c);
  inscrR=sqrt((p-a)*(p-b)*(p-c)/p);

  printf("worst face:  shape=%10.8f  inscrR=%10.8f \n",
	 worstShape, inscrR);
  
  //  writeAFace(worstFace);
  return;
}


void ifMeshDataIdCleaned(pMesh mesh, pMeshDataId handle)
{
  pRegion region;
  pFace face;
  pEdge edge;
  pVertex vertex;
  void *iter;
  int value;
  void *tmp;

  RIter rit =M_regionIter (mesh);
  while ((region =RIter_next (rit))) {
    if( EN_getDataInt((pEntity)region,handle,&value) )
      cerr<<"  attached integer on mesh region uncleaned"<<endl;
    if( EN_getDataPtr((pEntity)region,handle,&tmp) )
      cerr<<"  attached pointer on mesh region uncleaned"<<endl;
  }
  RIter_delete (rit);

  FIter fit =M_faceIter (mesh);
  while ((face =FIter_next (fit))) {
    if( EN_getDataInt((pEntity)face,handle,&value) )
      cerr<<"  attached integer on mesh face uncleaned "<<EN_id((pEntity)face)<<endl;
    if( EN_getDataPtr((pEntity)face,handle,&tmp) )
      cerr<<"  attached pointer on mesh face uncleaned "<<EN_id((pEntity)face)<<endl;
  }
  FIter_delete (fit);


  EIter eit =M_edgeIter (mesh);
  while ((edge =EIter_next (eit))) {
    if( EN_getDataInt((pEntity)edge,handle,&value) ) 
      cerr<<"  attached integer on mesh edge "<<EN_id((pEntity)edge)<<" uncleaned"<<endl; 
    if( EN_getDataPtr((pEntity)edge,handle,&tmp) )
      cerr<<"  attached pointer on mesh edge "<<EN_id((pEntity)edge)<<" uncleaned"<<endl;
  }
  EIter_delete (eit);

  VIter vit =M_vertexIter (mesh);
  while ((vertex =VIter_next (vit))) {
    if( EN_getDataInt((pEntity)vertex,handle,&value) )
      cerr<<"  attached integer on mesh vertex "<<EN_id((pEntity)vertex)<<" uncleaned"<<endl; 
    if( EN_getDataPtr((pEntity)vertex,handle,&tmp) )
      cerr<<"  attached pointer on mesh vertex "<<EN_id((pEntity)vertex)<<" uncleaned"<<endl; 
  }
  VIter_delete (vit);

  return;
}


void R_info(pRegion region, 
	    MeanRatio *shpMeasure, 
	    pSField pS)
{
  pEdge edge;
  double tmp;
  void *iter;

  shpMeasure->R_shape(region,&tmp);  
  printf(" region %d, volumeM/shape %f, length\n",EN_id((pEntity)region),tmp);
  
  pPList tmplist=R_edges(region,1);
  iter=0;
  while( edge=(pEdge)PList_next(tmplist,&iter) ) {
    tmp=pS->lengthSq(edge);
    printf("                    %f\n ",sqrt(tmp));
  }
  PList_delete(tmplist);

#ifdef MVTK
  tmplist=PList_new();
  PList_append(tmplist,region);
  visUtil::mvtkAddPList(tmplist,0.3,4,1,Tregion);
  mvtkActivate();
  mvtkRemoveAllMEnts();
  PList_delete(tmplist);
#endif
  return;
}

}

