#include <iostream>
#include <list>
#include <set>

#include "FMDB.h"
#include "templateRefine.h"
#include "FMDB_Internals.h"
#include "BLUtil.h"
#include "templateUtil.h"

using std::cout;
using std::endl;

using std::list;
using std::set;

extern "C" int M_checkAdj(pMesh mesh);
//extern "C" int M_checkOrdering(pMesh mesh);

pVertex E_commonVertex(pEdge edge1, pEdge edge2) 
{
  pVertex e2_verts[2] = {E_vertex(edge2,0), E_vertex(edge2,1)};
  for(int iVert=0; iVert<2; iVert++) {
    pVertex vert = E_vertex(edge1,iVert);
    if(vert==e2_verts[0] ||
       vert==e2_verts[1])
      return vert;
  }

  return 0;
}


int meshTemplate::BL_SplitQuadFaces(std::vector<pFace> &VecFaceStack)
{
  int iQuadFace = 0;
  pEdge pEdgeEdge;
  pFace pFaceFace;

  int iNumFace = VecFaceStack.size();
  for (int iFace = 0; iFace < iNumFace; ++iFace)
  {
    pFaceFace = VecFaceStack[iFace];
    if (pFaceFace->getType() == TRI)
      continue;

    for (int iEdge = 0; iEdge < 4; ++iEdge)
    {
      pEdgeEdge = F_edge(pFaceFace, iEdge);
      if (EN_levelInBL(pEdgeEdge) < EN_levelInBL(pFaceFace))
        break;
    }

    get_tri_faces_of_quad(pFaceFace, pEdgeEdge, 0);
    iQuadFace++;
  }
}


void meshTemplate::SyncVtxIDsByOwner()
{
  /// Deal with boundary layer vertices on the part boundary
#ifdef MA_PARALLEL
  if (SCUTIL_CommSize() > 1)
  {
    /// Initialize IPComMan
    IPComMan *CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int num_sent = 0, num_recvd = 0;
    int iSize = sizeof(pVertex) + sizeof(int);
    CM->set_fixed_msg_size(iSize);
    void* msg_send = CM->alloc_msg(iSize);
    pVertex* vtxSend = (pVertex*)msg_send;
    int* iSend = (int*)((char*)msg_send + sizeof(pVertex));

    pVertex pVertexVtx;
    VIter vit = M_vertexIter(pmesh);
    while(pVertexVtx = VIter_next(vit))
    {
      if (EN_isBLEntity(pVertexVtx) && EN_onCB(pVertexVtx))
      {
        int iOwnerPart;
        FMDB_Ent_GetOwnPartID(pVertexVtx, pmesh, &iOwnerPart);
        if (iOwnerPart != P_pid())
          continue;
      
        std::vector<std::pair<int, pMeshEnt> > VtxRemCpy;
        FMDB_Ent_GetAllRmt(pVertexVtx, VtxRemCpy);

        /// Get the rem copy of the vertex and send its id
        *iSend = EN_id(pVertexVtx);
        for (int iRC = 0; iRC < VtxRemCpy.size(); ++iRC)
        {
          *vtxSend = VtxRemCpy[iRC].second;
          CM->send(VtxRemCpy[iRC].first, msg_send);
        }
      }
    }
    VIter_delete(vit);

    CM->free_msg(msg_send);
    CM->finalize_send();

    void* msg_recv;
    int pid_from;

    // recieve phase
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      vtxSend = (pVertex*)msg_recv;
      iSend = (int*)((char*)msg_recv + sizeof(pVertex));
      EN_setSplitID(*vtxSend, *iSend);

      CM->free_msg(msg_recv);
    }
  }
#endif
}


void meshTemplate::tetrahedronizeBL() 
{
  pVertex pVertexVtx;
  pEdge pEdgeEdge;
  pFace pFaceFace;
//  std::vector<pFace> VecFaceStack;

  split_id = MD_lookupMeshDataId("Vertex originating bisection");

  /// Tetrahedralize pyramids sitting in the unstructured part of the domain
  Mesh_TetrahedralizePyramids();

#ifdef MA_PARALLEL
  SyncVtxIDsByOwner();
#endif

  /// Split quad faces into tri-s
  int iLvlFace;
  FIter fit = M_faceIter(pmesh);
  while(pFaceFace = FIter_next(fit))
  {
    if (pFaceFace->getType() == TRI)
      continue;

    /// Verify whether the quad face is part of a BL or adjacent to the region detached from the BL stack
    iLvlFace = EN_levelInBL(pFaceFace);
    if (iLvlFace > -1)
    {
      for (int iEdge = 0; iEdge < 4; ++iEdge)
      {
        pEdgeEdge = F_edge(pFaceFace, iEdge);
        if (EN_levelInBL(pEdgeEdge) < iLvlFace)
          break;
      }
    }
    else
    {
      iLvlFace = EN_remLevelInBL(pFaceFace);

      if (iLvlFace < 0)
        printf("Error!!! Quad face doesn't have level number and remote level number as well.\n");
      
      for (int iEdge = 0; iEdge < 4; ++iEdge)
      {
        pEdgeEdge = F_edge(pFaceFace, iEdge);
        if (EN_remLevelInBL(pEdgeEdge) < iLvlFace)
          break;
      }
    }
    get_tri_faces_of_quad(pFaceFace, pEdgeEdge, 0);
  }
  FIter_delete(fit);


#ifdef MA_PARALLEL
  /// Sync children faces on the part boundary
  if (SCUTIL_CommSize() > 1)
  {
    M_update_CB_Links(entities_to_update, ptr_reff);
    entities_to_update.clear();
    M_updateOwnership(pmesh);

    /// Delete additional vertex id-s
    VIter vit = M_vertexIter(pmesh);
    int iVal;
    while(pVertexVtx = VIter_next(vit))
    {
      if (EN_getDataInt(pVertexVtx, split_id, &iVal))
        EN_deleteData(pVertexVtx, split_id);
    }
    VIter_delete(vit);
  }
#endif

  /// Delete p-sets
  int iNumBL;
  FMDB_Part_GetNumSet (pmesh, &iNumBL);
  pEntSet entSet;
  pPartSetIter iterEntSet;
  std::vector<pBLayer> VecBLRem;
  FMDB_PartSetIter_Init(pmesh, iterEntSet);
  for (int iSet = 0; iSet < iNumBL; ++iSet)
  {
    FMDB_PartSetIter_GetNext(pmesh, iterEntSet, entSet);
    VecBLRem.push_back((pBLayer)entSet);
  }
  for (int iSet = 0; iSet < iNumBL; ++iSet)
  {
    entSet = VecBLRem[iSet];
    FMDB_Set_Clr(entSet);
    FMDB_Set_Del(NULL, pmesh, entSet);
  }
  VecBLRem.clear();

  /// Split regions
  pRegion pRegionRgn;
  pRegion pRegionChdRgn[8];
  int iRgn, iTetNoInterVtx=0, iTetInterVtx=0;
  RIter rit = M_regionIter(pmesh);
  while(pRegionRgn = RIter_next(rit))
  {
    switch (pRegionRgn->getType())
    {
      case TET:
        continue;
        break;
      case PYRAMID:
        tetrahedronizePyramid(pRegionRgn, pRegionChdRgn);
        break;
      case PRISM:
        iRgn = tetrahedronizeWedge(pRegionRgn, pRegionChdRgn);
        if (iRgn == 3)
          iTetNoInterVtx++;
        else
          iTetInterVtx++;
        break;
      default:
        printf("Wrong entity to tetrahedronize!\n");
        break;
    }
  }
  RIter_delete(rit);

  MD_deleteMeshDataId(split_id);

  if (iTetInterVtx)
    deleteSteiner();

#ifdef DEBUG
  if (P_pid() == 0)
    printf("Tetrahedralization is done\n");
  if (iTetInterVtx)
    printf("Warning! [%d]: Tetrahedralization template with interior verts was applied %d times\n", P_pid(), iTetInterVtx);
#endif

 
//  M_checkAdj(pmesh);
//  M_checkOrdering(pmesh);

}


int meshTemplate::tetrahedronizeWedge(pRegion region, pRegion *chdRgns)
{
  int iNumRgn;

  pPList plist;
  pVertex commonStartVtx;
  pEdge diag_edges[3];
  pFace face;
  // must be a prism/wedge
  for(int iFace=0; iFace<3; iFace++)
  {
    face = R_face(region, iFace+1);
    plist = get_tri_faces_of_quad(face,0,0);
    diag_edges[iFace] = (pEdge)PList_item(plist,0);
  }

  for (int iEdge = 0; iEdge < 3; ++iEdge)
  {
    commonStartVtx = E_commonVertex(diag_edges[iEdge],diag_edges[(iEdge+1)%3]);
    if (commonStartVtx)
      break;
  }

  if (commonStartVtx)
  {
    tetrahedronizeWedge_CommonStartVtx(region, chdRgns);
    iNumRgn = 3;
  }  
  else
  {
    tetrahedronizeWedge_NoCommonStartVtx(region, chdRgns);
    iNumRgn = 8;
  }

  return iNumRgn;
}


void meshTemplate::tetrahedronizeWedge_NoCommonStartVtx(pRegion region, pRegion *chdRgns)
{
  pPList plist;
  pEdge diag_edges[3];
  pFace face;
  pFace pFaceRemFace[3] = {R_face(region, 1), R_face(region, 2), R_face(region, 3)};
  // must be a prism/wedge
  for(int iFace=0; iFace<3; iFace++)
  {
    plist = get_tri_faces_of_quad(pFaceRemFace[iFace],0,0);
    diag_edges[iFace] = (pEdge)PList_item(plist,0);
  }

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  double xyz[]={0.0, 0.0, 0.0};
  double par[]={0.0,0.0,0.0};

  pPList rverts = R_vertices(region, 1);
  pVertex pVertexVtx[6];
  for (int iVtx = 0; iVtx < 6; ++iVtx)
    pVertexVtx[iVtx] = (pVertex)PList_item(rverts, iVtx);
  PList_delete(rverts);

  // create the centroid and the regions inside polyhedron
  pVertex centroid = M_createVP2(pmesh, xyz, par, 0, g_entity);

  // calculate the centroid and interpolate the metric tensor
  if (pSizeField->getSize(pVertexVtx[0]))
  {
    pMSize pScenter = templatesUtil::wedgeCenter(pVertexVtx, xyz, pSizeField);
    pSizeField->setSize((pEntity)centroid,pScenter);
  }

  pVertex pVertexNewVtx[4];

  pVertexNewVtx[3] = centroid;
  /// Create tets
  face = R_face(region, 0);
  for (int iVtx = 0; iVtx < 3; ++iVtx)
  {
    pVertexNewVtx[iVtx] = F_vertex(face, iVtx);
  }
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[0]);

  face = R_face(region, 4);
  for (int iVtx = 0; iVtx < 3; ++iVtx)
  {
    pVertexNewVtx[iVtx] = F_vertex(face, iVtx);
  }
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[1]);

  pPList entlist=PList_new();

  int iRgn = 2;
  for (int iFace = 0; iFace < 3; ++iFace)
  {
    face = pFaceRemFace[iFace];
    pVertexNewVtx[0] = E_vertex(diag_edges[iFace], 0);
    pVertexNewVtx[1] = E_vertex(diag_edges[iFace], 1);
    PList_append(entlist, diag_edges[iFace]);
    int iVtx;
    for (iVtx = 0; iVtx < 4; ++iVtx)
    {
      pVertexNewVtx[2] = F_vertex(face, iVtx);
      if (!(pVertexNewVtx[2] == pVertexNewVtx[0] || pVertexNewVtx[2] == pVertexNewVtx[1]))
      {
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[iRgn]);
        PList_append(entlist,pVertexNewVtx[2]);
        iRgn++;
      }
    }
  }

  EN_attachDataPtr((pEntity)centroid,ptr_reff,entlist);
  PList_append(steinerVerts,centroid);

  pPList newRegs = 0;
  if (function_CB)
  {
    newRegs = PList_new();
    for (int iRgn = 0; iRgn < 8; ++iRgn)
      PList_append(newRegs, chdRgns[iRgn]);
  }

  callCallback((pEntity)region, newRegs, centroid);

  if (function_CB)
    PList_delete(newRegs);

  M_removeRegion(pmesh,region);

  for(int iFace=0; iFace<3; iFace++)
    delete_face(pFaceRemFace[iFace]);

}


void meshTemplate::tetrahedronizeWedges(list<pRegion> &wedges, list<pRegion> *chdRgns) 
{
  int numWedgesToSplit = wedges.size();
  int countWedgesSplit = 0;
  int iNumChdRgn;

  pRegion childRgns[3];
  list<pRegion>::iterator it_list, it_list_end;
  it_list = wedges.begin();
  it_list_end = wedges.end();
  while(it_list!=it_list_end) {
    iNumChdRgn = tetrahedronizeWedge(*it_list,childRgns);
    countWedgesSplit++;
    it_list++;
    if(chdRgns) {
      for(int iChd=0; iChd<iNumChdRgn; iChd++)
        chdRgns->push_back(childRgns[iChd]);
    }
  }

  if(countWedgesSplit!=numWedgesToSplit) {
    cout<<"\nWarning in tetrahedronizeWedges()..."<<endl;
    cout<<"all wedges ["<<numWedgesToSplit<<"] NOT split into tets. [split:"<<countWedgesSplit<<"]\n"<<endl;
  }
}

void meshTemplate::tetrahedronizeWedge_CommonStartVtx(pRegion region, pRegion *chdRgns) 
{
  pEdge edges[5];   // edges to create two new tri. faces
  pFace faces[10];  // faces to create three new tets.
  pEdge f_edges[3]; // three edges to create a new tri. face
  int f_dirs[3];
  pFace r_faces[4]; // four faces to create a new tet. region
  int r_dirs[4];

  // pRegion chdRgns[3]; // three new regions

  int f_offset, offset, config, min_id, b_fdir, u_fdir, offset_fdirs[3], fe_dir[2];
  pPList plist;
  pVertex vertex, zeroVtx;
  pEdge offset_lower_edges[3];
  pFace offset_qfaces[3];
  pGEntity g_entity;

    g_entity = (pGEntity)R_whatIn(region);

    f_offset = 0;
    for(int iFace=0; iFace<3; iFace++) {
      pFace rface = R_face(region,iFace+1);
      if(check_is_face_split(rface)) {
	f_offset = iFace+1;
	break;
      }
    }

    pPList rverts = R_vertices(region,1);
    pPList redges = R_edges(region,1);

    offset = -9999; config = -9999;
    zeroVtx = 0;
    if(f_offset) {
      int f_order[3] = {f_offset, f_offset%3+1, (f_offset+1)%3+1};
      // lower edges are as per the f_offset
      for(int iEdge=0; iEdge<3; iEdge++)
	offset_lower_edges[iEdge] = (pEdge)PList_item(redges,f_order[iEdge]-1);

      int othSpFaceInd, cOthSpFaces = 0;
      for(int iFace=0; iFace<2; iFace++) {
	if(check_is_face_split(R_face(region,f_order[iFace+1]))) {
	  othSpFaceInd = iFace+1;
          cOthSpFaces++;
	}
      }

      if(!cOthSpFaces) {
        get_tri_faces_of_quad(R_face(region,f_order[1]),offset_lower_edges[1],0);
        othSpFaceInd = 1;
        cOthSpFaces++;
      }

      pVertex coVert = 0, oCoVert = 0;
      pEdge diag_edges[3];

      plist = get_tri_faces_of_quad(R_face(region,f_order[0]),0,0);
      diag_edges[0] = (pEdge)PList_item(plist,0);
      plist = get_tri_faces_of_quad(R_face(region,f_order[othSpFaceInd]),0,0);
      diag_edges[othSpFaceInd] = (pEdge)PList_item(plist,0);

      coVert = E_commonVertex(diag_edges[0],diag_edges[othSpFaceInd]);

      if(cOthSpFaces==1) {
        if(coVert) { // if diag. edges of 2 split quad. faces have a common vertex
          plist = get_tri_faces_of_quad(R_face(region,f_order[3-othSpFaceInd]),offset_lower_edges[3-othSpFaceInd],0);
          diag_edges[3-othSpFaceInd] = (pEdge)PList_item(plist,0);
          oCoVert = E_commonVertex(diag_edges[0],diag_edges[3-othSpFaceInd]);
          if(!oCoVert)
            oCoVert = E_commonVertex(diag_edges[othSpFaceInd],diag_edges[3-othSpFaceInd]);
        }
        else { // else split third (unsplit) quad. face based on a lower common vertex
          coVert = E_commonVertex(diag_edges[0],offset_lower_edges[3-othSpFaceInd]);
          if(!coVert)
            coVert = E_commonVertex(diag_edges[othSpFaceInd],offset_lower_edges[3-othSpFaceInd]);
          if(!coVert) {
            cout<<"\nError in tetrahedronizeWedge()..."<<endl;
            cout<<"could NOT understand split config. of quad. faces of wedge\n"<<endl;
            exit(0);
          }

          plist = get_tri_faces_of_quad(R_face(region,f_order[3-othSpFaceInd]),0,coVert);
 
          diag_edges[3-othSpFaceInd] = (pEdge)PList_item(plist,0);
          oCoVert = E_otherVertex(diag_edges[3-othSpFaceInd],coVert); 
        }
      }
      else { // all three quad. faces of wedge are already split
        plist = get_tri_faces_of_quad(R_face(region,f_order[3-othSpFaceInd]),0,0);
        diag_edges[3-othSpFaceInd] = (pEdge)PList_item(plist,0);
        if(!coVert) {
          coVert = E_commonVertex(diag_edges[0],diag_edges[3-othSpFaceInd]);
          if(!coVert) {
            cout<<"\nError in tetrahedronizeWedge()..."<<endl;
            cout<<"quad. faces of wedge NOT split consistently\n"<<endl;
            exit(0);
          }
          oCoVert = E_otherVertex(diag_edges[3-othSpFaceInd],coVert);
        }
        else { // get oCoVert
          oCoVert = E_commonVertex(diag_edges[0],diag_edges[3-othSpFaceInd]);
          if(!oCoVert)
            oCoVert = E_commonVertex(diag_edges[othSpFaceInd],diag_edges[3-othSpFaceInd]);
        }
      }
      if(!coVert && !oCoVert) {
        cout<<"\nError in tetrahedronizeWedge()..."<<endl;
        cout<<"both common vertex NOT found\n"<<endl;
        exit(0);
      }
      for(int iVert=0; iVert<3; iVert++) {
	vertex = (pVertex)PList_item(rverts,iVert);
        if(vertex==coVert ||
           vertex==oCoVert) {
	  offset = iVert;
	  zeroVtx = vertex;
          plist = get_tri_faces_of_quad(R_face(region,iVert+1),0,0);
          pEdge cfgEdge = (pEdge)PList_item(plist,0);
          if(E_otherVertex(cfgEdge,zeroVtx)==coVert ||
             E_otherVertex(cfgEdge,zeroVtx)==oCoVert)
            config = 1;
          else
            config = 0; 
          break;
        } 
      }
    }
    else { // no quad. face of wedge is split yet
      min_id = 100000000;
      for(int iVert=0; iVert<3; iVert++) {
	vertex = (pVertex)PList_item(rverts,iVert);
	int id = EN_getSplitID((pEntity)vertex);
	if(id < min_id) {
	  min_id = id;
	  offset = iVert;
	  zeroVtx = vertex;
	}
      }

      if(EN_getSplitID((pEntity)PList_item(rverts,(offset+1)%3)) < EN_getSplitID((pEntity)PList_item(rverts,(offset+2)%3)))
	config = 0;
      else
	config = 1;
    }

    int order[3] = {offset, (offset+1)%3, (offset+2)%3};
    // lower edges are as per the offset
    for(int iEdge=0; iEdge<3; iEdge++)
      offset_lower_edges[iEdge] = (pEdge)PList_item(redges,order[iEdge]);

    faces[0] = R_face(region,0);
    b_fdir= R_faceDir(region,0);
    faces[1] = R_face(region,4);
    u_fdir = R_faceDir(region,4);

    int mapEIndex[2] = {0,2};
    edges[3] = offset_lower_edges[mapEIndex[config]];
    fe_dir[0] = (b_fdir+F_dirUsingEdge(faces[0],edges[3]))%2;
    edges[4] = (pEdge)PList_item(redges,order[1]+6);
    fe_dir[1] = 1-(u_fdir+F_dirUsingEdge(faces[1],edges[4]))%2;

    PList_delete(rverts);
    PList_delete(redges);

    // loop over quad. faces
    for(int iFace=0; iFace<3; iFace++) {
      int index1 = order[iFace]+1;
      offset_qfaces[iFace] = R_face(region,index1);
      offset_fdirs[iFace] = R_faceDir(region,index1);

      int index2 = 2*(iFace+1);
      plist = get_tri_faces_of_quad(offset_qfaces[iFace],offset_lower_edges[iFace],0);
      edges[iFace] = (pEdge)PList_item(plist,0);
      faces[index2]   = (pFace)PList_item(plist,1);
      faces[index2+1] = (pFace)PList_item(plist,2);
      if(!F_inClosure(faces[index2],(pEntity)offset_lower_edges[iFace])) {
	pFace swapface = faces[index2+1];
	faces[index2+1] = faces[index2];
	faces[index2]   = swapface;
      }
    }

    int mapFEdges1[2][3] = {{3,1,2}, {3,0,1}};
    int mapFEDirs1[3] = {fe_dir[0],1,0};
    for(int iEdge=0; iEdge<3; iEdge++) {
      f_edges[iEdge] = edges[mapFEdges1[config][iEdge]];
      f_dirs[iEdge] = mapFEDirs1[iEdge];
    }
    for(int iEdge=1; iEdge<3; iEdge++) {
      if(E_vertex(f_edges[iEdge-1],f_dirs[iEdge-1])!=E_vertex(f_edges[iEdge],1-f_dirs[iEdge]))
        f_dirs[iEdge] = 1-f_dirs[iEdge];
    }
    faces[8] = M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    int mapFEdges2[3] = {4,2,0};
    int mapFEDirs2[3] = {fe_dir[1],0,1};
    for(int iEdge=0; iEdge<3; iEdge++) {
      f_edges[iEdge] = edges[mapFEdges2[iEdge]];
      f_dirs[iEdge] = mapFEDirs2[iEdge];
    }
    for(int iEdge=1; iEdge<3; iEdge++) {
      if(E_vertex(f_edges[iEdge-1],f_dirs[iEdge-1])!=E_vertex(f_edges[iEdge],1-f_dirs[iEdge]))
        f_dirs[iEdge] = 1-f_dirs[iEdge];
    }
    faces[9] = M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    int mapRFaces1[2][4] = {{0,8,4,6}, {0,2,4,8}};
    int mapRFDirs1[2][4] = {{b_fdir,1,offset_fdirs[1],offset_fdirs[2]}, {b_fdir,offset_fdirs[0],offset_fdirs[1],1}};
    for(int iFace=0; iFace<4; iFace++) {
      r_faces[iFace] = faces[mapRFaces1[config][iFace]];
      r_dirs[iFace] = mapRFDirs1[config][iFace];
    }
    chdRgns[0] = M_createR(pmesh,4,r_faces,r_dirs,g_entity);

    int mapRFaces2[2][4] = {{8,2,5,9}, {8,6,9,5}};
    int mapRFDirs2[2][4] = {{0,offset_fdirs[0],offset_fdirs[1],1}, {0,offset_fdirs[2],1,offset_fdirs[1]}};
    for(int iFace=0; iFace<4; iFace++) {
      r_faces[iFace] = faces[mapRFaces2[config][iFace]];
      r_dirs[iFace] = mapRFDirs2[config][iFace];
    }
    chdRgns[1] = M_createR(pmesh,4,r_faces,r_dirs,g_entity);

    int mapRFaces3[4] = {9,1,7,3};
    int mapRFDirs3[4] = {0,u_fdir,offset_fdirs[2],offset_fdirs[0]};
    for(int iFace=0; iFace<4; iFace++) {
      r_faces[iFace] = faces[mapRFaces3[iFace]];
      r_dirs[iFace] = mapRFDirs3[iFace];
    }
    chdRgns[2] = M_createR(pmesh,4,r_faces,r_dirs,g_entity);

    M_removeRegion(pmesh,region);

    for(int iFace=0; iFace<3; iFace++)
      delete_face(offset_qfaces[iFace]);

}

void meshTemplate::tetrahedronizePyramidizeWedges(list<pRegion> &wedges, list<pRegion> *chdRgns) 
{
  int numWedgesToSplit = wedges.size();
  int countWedgesSplit = 0;
  int iNumChdRgn;

  pRegion childRgns[2];
  list<pRegion>::iterator it_list, it_list_end;
  it_list = wedges.begin();
  it_list_end = wedges.end();
  while(it_list!=it_list_end) {
    iNumChdRgn = tetrahedronizePyramidizeWedge(*it_list,childRgns);
    countWedgesSplit++;
    it_list++;
    if(chdRgns) {
      for(int iChd=0; iChd<iNumChdRgn; iChd++)
        chdRgns->push_back(childRgns[iChd]);
    }
  }
 
  if(countWedgesSplit!=numWedgesToSplit){
    cout<<"\nWarning in tetrahedronizePyramidizeWedges()..."<<endl;
    cout<<"all wedges ["<<numWedgesToSplit<<"] NOT split into pyramid and tet. [split:"<<countWedgesSplit<<"]\n"<<endl;
  }
}

int meshTemplate::tetrahedronizePyramidizeWedge(pRegion region, pRegion *chdRgns) 
{
  int iNumRgn;
  pPList plist;
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int offset, off_index[2];
  pVertex commonStartVtx;
  pEdge diag_edges[2];
  pFace face;
  pFace pFaceFace[3] = {R_face(region, 1), R_face(region, 2), R_face(region, 3)};
  pFace pFaceRemFace[2];
  // must be a prism/wedge
  for(int iFace=0; iFace<3; iFace++)
  {
    face = pFaceFace[iFace]; //R_face(region,iFace+1);
    if(!check_is_face_split(face)) 
    {
      offset = iFace;
      off_index[0] = (iFace+1)%3;
      off_index[1] = (iFace+2)%3;

      for(int iFace2=0; iFace2<2; iFace2++) 
      {
	pFaceRemFace[iFace2] = pFaceFace[off_index[iFace2]];
        plist = get_tri_faces_of_quad(pFaceRemFace[iFace2],0,0);
        diag_edges[iFace2] = (pEdge)PList_item(plist,0);
      }

      commonStartVtx = E_commonVertex(diag_edges[0],diag_edges[1]);
      break;
    }
  }

  pVertex pVertexNewVtx[5];

  face = pFaceFace[offset];

  /// Create a pyramid
  for (int iVtx = 0; iVtx < 4; ++iVtx)
  {
    pVertexNewVtx[iVtx] = F_vertex(face, iVtx);
  }

  if (commonStartVtx)
  {
    pVertexNewVtx[4] = commonStartVtx;
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, chdRgns[0]);

    face = R_face(region, 0);
    if (F_inClosure(face, commonStartVtx))
      face = R_face(region, 4);

    /// Create a tet  
    for (int iVtx = 0; iVtx < 3; ++iVtx)
    {
      pVertexNewVtx[iVtx] = F_vertex(face, iVtx);
    }
    pVertexNewVtx[3] = commonStartVtx;     

    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[1]);

    iNumRgn = 2;

  }
  else
  {
    double xyz[]={0.0, 0.0, 0.0};
    double par[]={0.0,0.0,0.0};

    pPList rverts = R_vertices(region, 1);
    pVertex pVertexVtx[6];
    for (int iVtx = 0; iVtx < 6; ++iVtx)
      pVertexVtx[iVtx] = (pVertex)PList_item(rverts, iVtx);
    PList_delete(rverts);

    // create the centroid and the regions inside polyhedron
    pVertex centroid = M_createVP2(pmesh, xyz, par, 0, g_entity);
    // calculate the centroid and interpolate the metric tensor
    if (pSizeField->getSize(pVertexVtx[0]))
    {
      pMSize pScenter = templatesUtil::wedgeCenter(pVertexVtx, xyz, pSizeField);
      pSizeField->setSize((pEntity)centroid,pScenter);
    }

    pVertexNewVtx[4] = centroid;
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, chdRgns[0]);

    /// Create tets
    face = R_face(region, 0);
    for (int iVtx = 0; iVtx < 3; ++iVtx)
    {
      pVertexNewVtx[iVtx] = F_vertex(face, iVtx);
    }
    pVertexNewVtx[3] = centroid;
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[1]);

    face = R_face(region, 4);
    for (int iVtx = 0; iVtx < 3; ++iVtx)
    {
      pVertexNewVtx[iVtx] = F_vertex(face, iVtx);
    }
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[2]);

    pPList entlist=PList_new();

    int iRgn = 3;
    for (int iFace = 0; iFace < 2; ++iFace)
    {
      face = pFaceRemFace[iFace];
      pVertexNewVtx[0] = E_vertex(diag_edges[iFace], 0);
      pVertexNewVtx[1] = E_vertex(diag_edges[iFace], 1);
      PList_append(entlist, diag_edges[iFace]);
      int iVtx;
      for (iVtx = 0; iVtx < 4; ++iVtx)
      {
        pVertexNewVtx[2] = F_vertex(face, iVtx);
        if (!(pVertexNewVtx[2] == pVertexNewVtx[0] || pVertexNewVtx[2] == pVertexNewVtx[1]))
        {
          FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[iRgn]);
          PList_append(entlist,pVertexNewVtx[2]);
          iRgn++;
        }
      }
    }

    EN_attachDataPtr((pEntity)centroid,ptr_reff,entlist);
    PList_append(steinerVerts,centroid);

    iNumRgn = 7;

    pPList newRegs = 0;
    if (function_CB)
    {
      newRegs = PList_new();
      for (int iRgn = 0; iRgn < iNumRgn; ++iRgn)
        PList_append(newRegs, chdRgns[iRgn]);
    }

    callCallback((pEntity)region, newRegs, centroid);

    if (function_CB)
      PList_delete(newRegs);
  }

  M_removeRegion(pmesh,region);

  for(int iFace=0; iFace<2; iFace++)
    delete_face(pFaceRemFace[iFace]);

  return iNumRgn;
}


void meshTemplate::tetrahedronizePyramidizeWedge_OneQuadFaceSplit(pRegion region, pRegion *chdRgns)
{
  int iNumRgn;
  pPList plist;
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int offset, off_index[2];
  pEdge diag_edge;
  pFace face;
  pFace pFaceFace[3] = {R_face(region, 1), R_face(region, 2), R_face(region, 3)};
  pFace pFaceRemFace;
  // must be a prism/wedge
  for(int iFace=0; iFace<3; iFace++)
  {
    face = pFaceFace[iFace]; //R_face(region,iFace+1);
    if(check_is_face_split(face))
    {
      offset = iFace;
      off_index[0] = (iFace+1)%3;
      off_index[1] = (iFace+2)%3;

      pFaceRemFace = pFaceFace[iFace];
      plist = get_tri_faces_of_quad(pFaceRemFace,0,0);
      diag_edge = (pEdge)PList_item(plist,0);
      break;
    }
  }

  double xyz[]={0.0, 0.0, 0.0};
  double par[]={0.0,0.0,0.0};

  pVertex pVertexNewVtx[5];

  pPList rverts = R_vertices(region, 1);
  pVertex pVertexVtx[6];
  for (int iVtx = 0; iVtx < 6; ++iVtx)
    pVertexVtx[iVtx] = (pVertex)PList_item(rverts, iVtx);
  PList_delete(rverts);

  // create the centroid and the regions inside polyhedron
  pVertex centroid = M_createVP2(pmesh, xyz, par, 0, g_entity);

  // calculate the centroid and interpolate the metric tensor
  if (pSizeField->getSize(pVertexVtx[0]))
  {
    pMSize pScenter = templatesUtil::wedgeCenter(pVertexVtx, xyz, pSizeField);
    pSizeField->setSize((pEntity)centroid,pScenter);
  }

  pVertexNewVtx[4] = centroid;

  /// Create 2 pyramids
  for (int iFace = 0; iFace < 2; ++iFace)
  {
    face = pFaceFace[off_index[iFace]];
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(face, iVtx);
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, chdRgns[iFace]);
  }

  /// Create tets
  face = R_face(region, 0);
  for (int iVtx = 0; iVtx < 3; ++iVtx)
  {
    pVertexNewVtx[iVtx] = F_vertex(face, iVtx);
  }
  pVertexNewVtx[3] = centroid;
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[2]);

  face = R_face(region, 4);
  for (int iVtx = 0; iVtx < 3; ++iVtx)
  {
    pVertexNewVtx[iVtx] = F_vertex(face, iVtx);
  }
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[3]);

  pPList entlist=PList_new();

  int iRgn = 4;
  face = pFaceRemFace;
  pVertexNewVtx[0] = E_vertex(diag_edge, 0);
  pVertexNewVtx[1] = E_vertex(diag_edge, 1);
  PList_append(entlist, diag_edge);
  int iVtx;
  for (iVtx = 0; iVtx < 4; ++iVtx)
  {
    pVertexNewVtx[2] = F_vertex(face, iVtx);
    if (!(pVertexNewVtx[2] == pVertexNewVtx[0] || pVertexNewVtx[2] == pVertexNewVtx[1]))
    {
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[iRgn]);
      PList_append(entlist,pVertexNewVtx[2]);
      iRgn++;
    }
  }

  EN_attachDataPtr((pEntity)centroid,ptr_reff,entlist);
  PList_append(steinerVerts,centroid);

  pPList newRegs = 0;
  if (function_CB)
  {
    newRegs = PList_new();
    for (int iRgn = 0; iRgn < 6; ++iRgn)
      PList_append(newRegs, chdRgns[iRgn]);
  }

  callCallback((pEntity)region, newRegs, centroid);

  if (function_CB)
    PList_delete(newRegs);

  M_removeRegion(pmesh,region);

  delete_face(pFaceRemFace);

}


void meshTemplate::tetrahedronizePyramids(list<pRegion> &pyramids, list<pRegion> *chdRgns) 
{
  int numPyramidsToSplit = pyramids.size();
  int countPyramidsSplit = 0;

  pRegion childRgns[2];
  list<pRegion>::iterator it_list, it_list_end;
  it_list = pyramids.begin();
  it_list_end = pyramids.end();
  while(it_list!=it_list_end) {
    tetrahedronizePyramid(*it_list,childRgns);
    countPyramidsSplit++;
    it_list++;
    if(chdRgns) {
      for(int iChd=0; iChd<2; iChd++)
        chdRgns->push_back(childRgns[iChd]);
    }
  }

  if(countPyramidsSplit!=numPyramidsToSplit){
    cout<<"\nWarning in tetrahedronizePyramids()..."<<endl;
    cout<<"all pyramids ["<<numPyramidsToSplit<<"] NOT split into tets. [split:"<<countPyramidsSplit<<"]\n"<<endl;
  }
}

void meshTemplate::tetrahedronizePyramid(pRegion region, pRegion *chdRgns) 
{
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pEdge diag_edge;
  pFace pFaceRemFace = R_face(region, 0);
  pPList plist = get_tri_faces_of_quad(pFaceRemFace,0,0);
  diag_edge = (pEdge)PList_item(plist,0);

  pVertex pVertexNewVtx[4];

  pPList rverts = R_vertices(region, 1);
  pVertex pVertexVtx[5];
  for (int iVtx = 0; iVtx < 5; ++iVtx)
    pVertexVtx[iVtx] = (pVertex)PList_item(rverts, iVtx);
  PList_delete(rverts);

  pVertexNewVtx[3] = pVertexVtx[4];
  pVertexNewVtx[0] = E_vertex(diag_edge, 0);
  pVertexNewVtx[1] = E_vertex(diag_edge, 1);
  int iRgn = 0;
  for (int iVtx = 0; iVtx < 4; ++iVtx)
  {
    pVertexNewVtx[2] = F_vertex(pFaceRemFace, iVtx);
    if (!(pVertexNewVtx[2] == pVertexNewVtx[0] || pVertexNewVtx[2] == pVertexNewVtx[1]))
    {
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, chdRgns[iRgn]);
      iRgn++;
    }
  }

  M_removeRegion(pmesh,region);

  delete_face(pFaceRemFace);

}
