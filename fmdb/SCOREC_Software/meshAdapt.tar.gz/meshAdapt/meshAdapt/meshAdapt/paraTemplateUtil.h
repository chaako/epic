/*<i> ****************************************************************************
 *
 *  templateUtil/paraTemplateUtil.h
 *  Created by Seegyoung Seol, on Tue May 11 2004, 10:26:37 EDT
 *
 *  Copyright (c) 2004, Scientific Computation Research Center
 *
 *  <a href="http://www.scorec.rpi.edu" CLASS="nav">www.scorec.rpi.edu</a>
 *
 *  File Content: header of parallel size field helper operators
 *
 *************************************************************************** </i>*/
 
#ifndef _H_PARATEMPLATEUTIL
#define _H_PARATEMPLATEUTIL

#include "sizeFieldBase.h"

#ifdef MA_PARALLEL
#include "pmDataExchanger.h"
#include "pmMigrationCallbacks.h"
#endif

void printSize(pEntity, pMSize);

#ifdef AOMD_

bool M_checkSizeField(pMesh, pSField);

#ifdef MA_PARALLEL
class sfExchanger:public pmDataExchanger
{
private:
  pSField pSizeField;
public :
  sfExchanger(pSField sf): pSizeField(sf) {}
  virtual int msg_size();
  virtual void fill_buffer (mEntity *e, int src, int dest, mEntity* remoteEnt, void *&msg_send);
  virtual void receiveData (void *msg_recv, int pid_from);
};

class sfUnifier:public pmDataExchanger
{
private:
  pSField pSizeField;
public :
  sfUnifier(pSField sf): pSizeField(sf) {}
  virtual int msg_size();
  virtual void fill_buffer (mEntity *e, int src, int dest, mEntity* remoteEnt, void *&msg_send);
  virtual void receiveData (void *msg_recv, int pid_from);
};

int M_unifySizeField(pMesh,pSField);

#endif /* MA_PARALLEL */
  
#endif /* AOMD_ */

#endif /* _H_PARATEMPLATEUTIL */
