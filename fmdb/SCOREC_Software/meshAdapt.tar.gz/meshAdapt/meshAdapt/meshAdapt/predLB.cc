#ifdef MA_PARALLEL
#include "predLB.h"
#include "PList.h"
#include <vector>


int Calculate_Weights(pMeshMdl mesh, pSField field, double &dMaxWeight, double &dMinWeight, double &dMaxBLWeight, double &dMinBLWeight, double &dTotWeight)
{
  dMinWeight = dMinBLWeight = 1e+10;
  dMaxWeight = dMaxBLWeight = dTotWeight = 0;

  double weight;
  pRegion region;
  double vol,volsf;
  pVertex vertex;
  int nen;
  pPart pm;
  FMDB_Mesh_GetPart (mesh, 0, pm);
  RIter riter = M_regionIter(pm);
  double h[3];
  double normal[3];

  while(region=RIter_next(riter))
  {
    if (region->getType() == PRISM)
      continue;

    vol = fabs(R_Volume2(region));
    volsf = 0.0;
    pPList vertices = R_vertices(region,1);
    nen = PList_size(vertices);
    void *iter=0;
    while(vertex=(pVertex)PList_next(vertices,&iter))
    {
      pMSize pS = field->getSize((pVertex)vertex);
      for(int i=0;i<3;i++)
        h[i]=pS->size(i);
      if (region->getType() == TET)
        volsf+=h[0]*h[1]*h[2]/6;
      else if (region->getType() == PYRAMID)
        volsf+=h[0]*h[1]*h[2]/3;
    }

    weight = vol/volsf*nen;
    PList_delete(vertices);
    if(weight<dMinWeight)
      dMinWeight = weight;
    if(weight>dMaxWeight)
      dMaxWeight = weight;
    FMDB_Ent_SetWeight((pRegion)region,weight);

    dTotWeight += weight;
  }
  RIter_delete(riter);

  /// Traversing boundary layers  
  pBLIter egBegIter = Mesh_GetBegBLIter(pm);
  pBLIter egEndIter = Mesh_GetEndBLIter(pm);
  pBLIter egIter;
  pBLayer pBLayerBL;
  pFace pFaceFace;
  pEdge pEdgeEdge;

//double dCheckMaxLnSq = 0;
  /// For each edge in the stack find maximum size it is going to be split on
  for (egIter = egBegIter; egIter != egEndIter; egIter++)
  {
    pBLayerBL = ((pBLayer)*egIter);
    pFaceFace = BL_GetZeroLvlFace(pBLayerBL);

    std::vector<double> dMax;
    double dLocW[3];
    for (int iEdge = 0; iEdge < 3; ++iEdge)
    {
      pEdgeEdge = F_edge(pFaceFace, iEdge);
      dMax.push_back(0);

      std::vector<pEdge> edgesStack;
      BL_getHorizontalEdgesByEdge(pEdgeEdge, edgesStack);
      for (int iLEdge = 0; iLEdge < edgesStack.size(); ++iLEdge)
      {
        pEdgeEdge = edgesStack[iLEdge];
        dLocW[iEdge] = field->lengthSq(pEdgeEdge);
/*
if (dLocW[iEdge] > dCheckMaxLnSq)
  dCheckMaxLnSq = dLocW[iEdge];
if (dCheckMaxLnSq > 890)
  int aaa = 5;
*/
        if (dLocW[iEdge] > 1.)
          dLocW[iEdge] = log2(dLocW[iEdge]) / 2.;

        if (dLocW[iEdge] > dMax[iEdge])
          dMax[iEdge] = dLocW[iEdge];
      }
      edgesStack.clear();
    }

    /// Calculate the weight of a region in a stack
    std::sort(dMax.begin(), dMax.end());
    /// if all 3 edges are split it will produce 4 prisms
    int iVal = 0;
    weight = 1.;
    while (dMax[iVal] < 1. && iVal < 3)
    {
      weight *= dMax[iVal];
      dMax[iVal] = 1.;
      iVal++;
    }

    /// for the case of rest of 2 edges and 1 edge
    for (; iVal < 3; ++iVal)
    {
      if (iVal == 0)
        weight = pow(4, (floor(dMax[0])));
      else
      {
        int iDeg = floor(dMax[iVal]) - floor(dMax[iVal-1]);
        if (iDeg > 0)
          weight += weight*(3-iVal)/3.*pow((4-iVal), iDeg);
      }
    }

    /// Attach weight to each region in the stack
    pBLEntIter entBegIter = BL_GetBegEntIter(pBLayerBL);
    pBLEntIter entEndIter = BL_GetEndEntIter(pBLayerBL);
    pBLEntIter entIter = entBegIter;

    for (; entIter != entEndIter; ++entIter)
    {
      FMDB_Ent_SetWeight(*entIter, weight);
      dTotWeight += weight;
    }

    if(weight<dMinWeight)
      dMinWeight = weight;
    if(weight>dMaxWeight)
      dMaxWeight = weight;

    if (weight < dMinBLWeight)
      dMinBLWeight = weight;
    if (weight > dMaxBLWeight)
      dMaxBLWeight = weight;
  }

}


int PredLB(pMeshMdl mesh, pSField field, pMeshDataId SolutionID, int nVar)
{
  double dMaxWeight, dMinWeight, dMaxBLWeight, dMinBLWeight, dTotWeight;
  double globalmin, globalmax, dGlobalMaxBLWeight, dGlobalMinBLWeight, dGlobalAvgTotWeight, dGlobalMaxTotWeight, dGlobalMinTotWeight;

  Calculate_Weights(mesh, field, dMaxWeight, dMinWeight, dMaxBLWeight, dMinBLWeight, dTotWeight);

  MPI_Allreduce(&dMinWeight, &globalmin, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
  MPI_Allreduce(&dMaxWeight, &globalmax, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);

  MPI_Allreduce(&dMinBLWeight, &dGlobalMinBLWeight, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
  MPI_Allreduce(&dMaxBLWeight, &dGlobalMaxBLWeight, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
 
//printf("[%d]: Max edge sq length is %lf\n",P_pid(), dCheckMaxLnSq);   
  if(P_pid()==0)
  {
    printf("The minimum weight is %lf\n",globalmin);
    printf("The maximum weight is %lf\n",globalmax);
    printf("The minimum BL weight is %lf\n",dGlobalMinBLWeight);
    printf("The maximum BL weight is %lf\n",dGlobalMaxBLWeight);
  }
/*
  MPI_Allreduce(&dTotWeight, &dGlobalMinTotWeight, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
  MPI_Allreduce(&dTotWeight, &dGlobalMaxTotWeight, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
  MPI_Allreduce(&dTotWeight, &dGlobalAvgTotWeight, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
  dGlobalAvgTotWeight /= P_size();

  if(P_pid()==0)
    printf("Global weights before partitioning [min, max, avg]: [%lf, %lf, %lf]\n", dGlobalMinTotWeight, dGlobalMaxTotWeight, dGlobalAvgTotWeight);
*/
    
  if(globalmax/globalmin>5000)
    globalmin = globalmax/5000;
    
  dMinWeight = 1e+10; dMaxWeight = 0;

  pPart pm;
  FMDB_Mesh_GetPart (mesh, 0, pm);

  double weight;
  dTotWeight = 0;

  pRegion region;
  RIter riter = M_regionIter(pm);
  while(region=RIter_next(riter))
  {
    FMDB_Ent_GetWeight((pRegion)region,&weight);
    weight/= globalmin;
    if(weight<1) 
      weight+=1;
    FMDB_Ent_SetWeight((pRegion)region,weight);

    if(weight<dMinWeight)
      dMinWeight = weight;
    if(weight>dMaxWeight)
        dMaxWeight = weight;

    dTotWeight += weight;
  }
  RIter_delete(riter);

/*
  MPI_Allreduce(&dMinWeight, &globalmin, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
  MPI_Allreduce(&dMaxWeight, &globalmax, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);

  if(P_pid()==0)
  {
    printf("The minimum weight after adjustment is %6.4f\n",globalmin);
    printf("The maximum weight after adjustment is %12.4f\n",globalmax);
  }
*/
//    SF_MigrationCallbacks CB(field);
  BL_MigrationCallbacks CB(field);
  if(nVar)
  {
    CB.SF_setSolutionID(SolutionID);
    CB.SF_setnVar(nVar);
  }
  CB.SF_setPredLB(1);
  FMDB_Mesh_GlobPtn (mesh, CB, FMDB_PARMETIS, PartKway, 1.03, 0);
//  FMDB_Mesh_GlobPtn (mesh, CB, FMDB_HYPERGRAPH, FMDB_REFINE, 1.03, 0);

  Mesh_CategorizeBLEntities(pm);
  Mesh_AssignBLLevelsToAllBLEnts(pm);
  Mesh_UnifyBLInterfaceOnCB(pm);
  Mesh_ClrHangingBLEntLvl(pm);


  FMDB_Mesh_DspStat (mesh);
  FMDB_Mesh_DspNumEnt (mesh);


  /// Deleting all the weights after partitioning
  riter = M_regionIter(pm);
  while(region=RIter_next(riter))
    FMDB_Ent_DelWeight(region);
  RIter_delete(riter);

/*
  Calculate_Weights(mesh, field, dMaxWeight, dMinWeight, dMaxBLWeight, dMinBLWeight, dTotWeight);
  MPI_Allreduce(&dTotWeight, &dGlobalMinTotWeight, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
  MPI_Allreduce(&dTotWeight, &dGlobalMaxTotWeight, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
  MPI_Allreduce(&dTotWeight, &dGlobalAvgTotWeight, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
  dGlobalAvgTotWeight /= P_size();

  if(P_pid()==0)
    printf("Global weights after partitioning [min, max, avg]: [%lf, %lf, %lf]\n", dGlobalMinTotWeight, dGlobalMaxTotWeight, dGlobalAvgTotWeight);
*/

  return 0;
}
#endif
