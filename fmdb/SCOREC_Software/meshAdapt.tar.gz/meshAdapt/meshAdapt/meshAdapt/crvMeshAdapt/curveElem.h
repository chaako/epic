/* This class is design to represent the 3D high-order curved tetrahedron element. The data member should include:

1) FMDB pRegion: this is the handle for the mesh entity
2) a shape metric container that is able to store shape quality values calculated from different kinds shape measure including the straight-sided frame element and the Bezier based jacobian ratio measure
3) to be added

*/

#include "FMDB.h"
#include "curveUtil.h"

class CrvElem{

  private:
    // disabled from usage
    CrvElem(){ }
 
  public:
    // the only constructor
    CrvElem(pRegion pInputRgn){
      pTheRgn_ = pInputRgn;
    }
    // the destructor
    ~CrvElem(){ }

// **** the two shape measure for the ST-frame **** //

    // get the Radius Ratio
    double RadiusRatio();
    // get the Aspect Ratio 
    double AspectRatio();

// **** curved mesh shape measure **** //

    // get the Jacobian Ratio
    double JacobiRatio();

// **** generic multiplicative measure **** //

    double GenShape();

// ======================================== //

    int VertsOnGVert();
    int VertsOnGEdge();
    int VertsOnGFace();
    int VertsOnGRegn();

    int EdgesOnGEdge();
    int EdgesOnGFace();
    int EdgesOnGRegn();

    int FacesOnGFace();
    int FacesOnGRegn();
 

  private:
    // the underlying mesh region of the element
    pRegion pTheRgn_;

};
