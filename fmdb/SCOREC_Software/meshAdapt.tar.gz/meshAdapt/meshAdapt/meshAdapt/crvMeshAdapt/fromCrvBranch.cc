#include "MeshAdapt.h"
#include "EdgeSplitMod.h"
#include "curveUtil.h"
#include "curveMesh.h"
#include "curveElem.h"

//#ifdef WHATEVER
#ifdef CURVE
#include "curveMesh.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "DSplitClpsMod.h"
#include "EdgeCollapsMod.h"
#include "EdgeSwapMod.h"
#include "VertMotionMod.h"
#include "FaceSwapMod.h"
#include "SplitCollapsMod.h"
#include "RegionCollapsMod.h"
#include "EdgeReShapeMod.h"
#include "Fswap.h"
#include "modeler.h"
#include "ParUtil.h"
#include <math.h>
#include <iostream>
#include <fstream>
#ifdef MVTK
#include "mvtk.h"
#endif
#include "Macros.h"

using std::cout;
using std::endl;
using std::ofstream;
using std::map;
using namespace adaptUtil;
using namespace curveUtil;
// int iOpCounts_[8];
extern F_SwapConfig fsc;

// Improve the mesh shape by local modification
void curveMesh::ImproveRgnsByMods()
{
  
  //int stage = getCurrentStage();

  int isPerformed = 1;
  int Loop = 0;
  pMeshMod pBestMod;
  map<pRegion, crShpInfo*>::iterator miter, mitend;
  pRegion region;
  crShpInfo *csi;

  while(invalidCurvedRgns.size()) {
    //cout<<"Current size of invalid region: "<<invalidCurvedRgns.size()<<endl;
    if(!isPerformed)// if nothing is perfromed after one loop, don't bother looping any more.
      break;
    
    isPerformed = 0;
    Loop++;
    
    //iterate the invalid regions and try the local mesh modification
    miter = invalidCurvedRgns.begin();
    mitend= invalidCurvedRgns.end();
    // crShpInfo *csi;
    for(; miter != mitend; ++miter){
      csi = miter->second;
      csi->processed = 0;
    }

    miter = invalidCurvedRgns.begin();
    mitend= invalidCurvedRgns.end();
    
    for(; miter != mitend; ) {
      // pRegion region;
      region = miter->first;   
      csi = miter->second;
      if(csi->processed == 1)
	{
	  miter++; 
	  continue;
	}
      else
	csi->processed = 1;
#ifdef MA_PARALLEL
      // skip the ones on part boundary
      if(CR_isOnPartBdry(region)){
        //cout<<"Found region to be processed on Part Bdry... "<<endl;
	miter++;
        continue;
        //isOnPB = 1;
      }
#endif
      // check if the best local mesh modification is available
      if(findBestMod(region, csi, &pBestMod)){

	isPerformed = 1;
	// apply the local mesh modification
	applyBestMod(&pBestMod);
	//	cout<<"Current size of invalid region: "<<invalidCurvedRgns.size()<<endl;
	delete pBestMod;//  ??
	miter  = invalidCurvedRgns.begin();
	mitend = invalidCurvedRgns.end();
      }
      else
	miter++;
    }
    cout<<"Current Loop is No."<<Loop<<endl;
    if(Loop >= 5)
      break;
  }
  return;
}

// Fix the invalid regions by local modification
void  curveMesh::fixInvalidRgnsByMods()
{
  int Loop = 0, isPerformed = 1;
  pMeshMod pBestMod;
  map<pRegion, crShpInfo*>::iterator miter, mitend;
  int count = 0;
  int up_limit = 0;
  while(invalidCurvedRgns.size()) {
    if(!isPerformed)
      break;
    
    //count = 0; // Kai debug Apr 4
    //up_limit = 20*invalidCurvedRgns.size(); // Kai debug Apr 4

    isPerformed = 0;
    Loop++;
    
    // iterate the invalid regions and try the local mesh modification
    miter = invalidCurvedRgns.begin();
    mitend= invalidCurvedRgns.end();
    crShpInfo *csi;
    
    // reset csi's of the regions to be "un-processed"
    for(; miter != mitend; ++miter){
      csi = miter->second;
      csi->processed = 0;
    }

    miter = invalidCurvedRgns.begin();
    mitend= invalidCurvedRgns.end();

#ifdef DEBUG    
    cout<<"**** Begin of the Local Mesh Modification Loop ****"<<endl;
#endif

    for(; miter != mitend; ) {
      //break;
      pRegion region;
      region = miter->first;   
      csi = miter->second;
      // skip the processed ones
      if(csi->processed == 1)
      {
        miter++; 
        continue;
      }
      else
        csi->processed = 1;
#ifdef MA_PARALLEL
      // int isOnPB = 0;
      // skip the ones on part boundary
      if(CR_isOnPartBdry(region)){
        //cout<<"Found region to be processed on Part Bdry... "<<endl;
	miter++;
        continue;
        //isOnPB = 1;
      }
#endif
      // check if the best local mesh modification is available
      if(findBestMod(region, csi, &pBestMod)){
	isPerformed = 1;
/*
if(isOnPB){
  if((pBestMod)->type() == RCOLAPS_2)
    cout<<"found best mod : Double Split + Collapse"<<endl;
  else if((pBestMod)->type() == ECOLAPS)
    cout<<"found best mod : ECOLAPS"<<endl;
  else if((pBestMod)->type() == FSWAP)
    cout<<"found best mod : FSWAP"<<endl;
  else if((pBestMod)->type() == ESWAP)
    cout<<"found best mod : ESWAP"<<endl;
  else if((pBestMod)->type() == SPLTCLPS)
    cout<<"found best mod : SPLTCLPS"<<endl;
  else if((pBestMod)->type() == RSHAPE)
    cout<<"found best mod : RSHAPE"<<endl;
  else if((pBestMod)->type() == RCOLAPS)
    cout<<"found best mod : Region Collapse"<<endl;
  else if((pBestMod)->type() == ESPLIT)
    cout<<"found best mod : ESPLIT"<<endl;
  else if((pBestMod)->type() == MOTION)
    cout<<"found best mod : MOTION"<<endl;
}
*/

	// apply the local mesh modification
	applyBestMod(&pBestMod);
	delete pBestMod;
	miter  = invalidCurvedRgns.begin();
	mitend = invalidCurvedRgns.end();
	
	// count++; // Kai debug Apr 4
// 	if(count>=up_limit) // Kai debug Apr 4
// 	  break; // Kai debug Apr 4


      }
      else
	miter++;
    } // end of the local mesh modification loop

#ifdef DEBUG 
    cout<<"**** End of the Local Mesh Modification Loop ****"<<endl;
#endif

#if 1
    
    
    if(invalidCurvedRgns.size()) {

#ifdef DEBUG      
      cout<<"**** Begin of the Edge Reshape Loop ****"<<endl;
#endif

      count = 0;
      up_limit = invalidCurvedRgns.size()*20;

      // apply edge reshape
      miter  = invalidCurvedRgns.begin();
      mitend = invalidCurvedRgns.end();
      
      crShpInfo *csi;
      for(; miter != mitend; ++miter){
	csi = miter->second;
	csi->processed = 0;
      }
      
      miter  = invalidCurvedRgns.begin();
      mitend = invalidCurvedRgns.end();
     
      

      for(; miter != mitend; ) {


	pRegion region;
	region = miter->first;
	csi = miter->second;
	if(csi->processed == 1)
	  {miter++; continue;}
	
	csi->processed = 1;

        if(CR_isOnPartBdry(region)){
          //cout<<"Found region to be processed on Part Bdry... "<<endl;
	  miter++;
          continue;
          //isOnPB = 1;
        }

	//cout<<"This is dividing line -- 1"<<endl;
	// check if the best local mesh modification is available
	if(findEdgeReShape(region, csi, &pBestMod)){
	  isPerformed = 1;
	  // apply the local mesh modification
	  applyBestMod(&pBestMod);
	  delete pBestMod;
	  miter  = invalidCurvedRgns.begin();
	  mitend = invalidCurvedRgns.end();
        
          count++; // Kai debug Apr 4
#ifdef DEBUG
	  cout<<count<<" out of "<<up_limit<<endl;
#endif
	  if(count>=up_limit) // Kai debug Apr 4
	    break; // Kai debug Apr 4
	}
	else
	  miter++;
 
      }

#ifdef DEBUG
      cout<<"**** End of the Edge Reshape Loop ****"<<endl;
#endif

    } // end of edge reshape
    

#endif

#if 1

    if(invalidCurvedRgns.size() && !isPerformed) {
      
      // apply loose double split+collapse
      miter  = invalidCurvedRgns.begin();
      mitend = invalidCurvedRgns.end();
      
      crShpInfo *csi;
      for(; miter != mitend; ++miter){
	csi = miter->second;
	csi->processed = 0;
      }
      
      miter  = invalidCurvedRgns.begin();
      mitend = invalidCurvedRgns.end();
      
      for(; miter != mitend; ) {
	pRegion region;
	region = miter->first;
	csi = miter->second;
	if(csi->processed == 1)
	  {miter++; continue;}
	
	csi->processed = 1;
	
        if(CR_isOnPartBdry(region)){
          //cout<<"Found region to be processed on Part Bdry... "<<endl;
	  miter++;
          continue;
          //isOnPB = 1;
        }


        pPList newR = PList_new();
	// check if the best local mesh modification is available
	if(isUnCurvedModValid(region, csi, &newR)){
	  PList_delete(newR);
	  miter++;
	}
	else {
	  updateNewReg(&newR);
	  PList_delete(newR);
	  isPerformed = 1;
	  miter  = invalidCurvedRgns.begin();
	  mitend = invalidCurvedRgns.end();
	}
      }

    } // end of loose double split+collapse

#endif

    if(Loop == 5)
      break;
  } // end of the outer while loop
  
  return ;
}

// apply the best local mesh modification
void curveMesh::applyBestMod(pMeshMod *pBestMod)
{
  pPList affect_rgns;
  void *temp;
  

  if((*pBestMod)->type() == RCOLAPS_2)
    iOpCounts_[0] = iOpCounts_[0]+1;
  else if((*pBestMod)->type() == ECOLAPS)
    iOpCounts_[1] = iOpCounts_[1]+1;
  else if((*pBestMod)->type() == FSWAP)
    iOpCounts_[2] = iOpCounts_[2]+1;
  else if((*pBestMod)->type() == ESWAP)
    iOpCounts_[3] = iOpCounts_[3]+1;
  else if((*pBestMod)->type() == SPLTCLPS)
    iOpCounts_[4] = iOpCounts_[4]+1;
  else if((*pBestMod)->type() == RSHAPE)
    iOpCounts_[5] = iOpCounts_[5]+1;
  else if((*pBestMod)->type() == RCOLAPS)
    iOpCounts_[6] = iOpCounts_[6]+1;
  else if((*pBestMod)->type() == ESPLIT)
    iOpCounts_[7] = iOpCounts_[7]+1;
  else if((*pBestMod)->type() == MOTION)
    iOpCounts_[8] = iOpCounts_[8]+1;

  // retrieve the affected regions
  (*pBestMod)->getAffectedRgns(&affect_rgns);

  // remove the affected regions from the map
  temp=0;
  pRegion region, rg;
  while(region = (pRegion)PList_next(affect_rgns, &temp)) {
    map<pRegion, crShpInfo *>::iterator miter, miterend = invalidCurvedRgns.end();
    miter = invalidCurvedRgns.find(region);
    if( miter != miterend) {
      delete miter->second;
      invalidCurvedRgns.erase(miter);
    }
  }
  PList_delete(affect_rgns);
  
  pPList newReg = PList_new();
  int flag, ok = (*pBestMod)->apply(&newReg); // the curved one should be taken care of
  

  // only the edge reshape and edge split ops allow the new regions to be invalid
  if(desired_shape == 0.0) {
    if((*pBestMod)->type() == RSHAPE || (*pBestMod)->type() == ESPLIT || (*pBestMod)->type() == RCOLAPS || (*pBestMod)->type() == MOTION ) 
      updateNewReg(&newReg);
  }
  else {
    updateNewReg(&newReg);
  }
  

  // temp = 0;
//   pVertex v;
//   crShpInfo *csi;
//   while(region = (pRegion)PList_next(newReg, &temp)) {
//     pPList rvlist = R_vertices(region, 1);
    
//     void *temp2, *temp1;
//     temp2 = 0;
//     while(v = (pVertex)PList_next(rvlist, &temp2)) {

//       pPList tmplist = V_regions(v);
    
//       temp1 = 0;
//       while(rg = (pRegion)PList_next(tmplist, &temp1)) {
// 	csi = new crShpInfo;
// 	flag = CR_isValid(rg, csi);
// 	if(flag < 2) {
// 	  if(!flag || (csi->shape < desired_shape))
// 	    {
// 	      map<pRegion, crShpInfo *>::iterator miter, miterend = invalidCurvedRgns.end();
// 	      miter = invalidCurvedRgns.find(rg);
// 	      if(miter == miterend) {
// 		invalidCurvedRgns[rg] = csi;
// 		if((*pBestMod)->type() != RSHAPE || (*pBestMod)->type() != ESPLIT)
// 		  cout<<"Error: Expand the Invalid Region:        ["<<(*pBestMod)->type()<<"]"<<endl;
// 	      } 
// 	      else{
// 		delete miter->second;
// 		invalidCurvedRgns.erase(miter);
// 		invalidCurvedRgns[rg] = csi;
// 	      }
// 	    }
// 	  else
// 	    delete csi;
// 	}
// 	else 
// 	  delete csi;
//       }
//       PList_delete(tmplist);
//     }
//     PList_delete(rvlist);
//   }

  

  
  // fixed the new boundary entities
  temp = 0;
  int ii, ve, fid;
  pEdge tmpedge;
  while(region = (pRegion)PList_next(newReg, &temp)) {
    pPList tmpelist = R_edges(region, 1);
    void *temp2;
    temp2 = 0;
    while(tmpedge = (pEdge)PList_next(tmpelist, &temp2)) {
      if(E_whatInType(tmpedge) != 3 && !EN_getDataInt((pEntity)tmpedge, _fixEnt, &fid))
	EN_attachDataInt((pEntity)tmpedge, _fixEnt, 1);
    }
    PList_delete(tmpelist);
    // pPList tmprvlist = R_vertices(region, 1);
//     void *temp2; 
//     temp2 = 0;
//     while(v = (pVertex)PList_next(tmprvlist, &temp2)) {
//       ve = V_numEdges(v);
//       for(ii=0; ii<ve; ii++) {
// 	tmpedge = V_edge(v, ii);
// 	if(E_whatInType(tmpedge) != 3 && !EN_getDataInt((pEntity)tmpedge, _fixEnt, &fid))
// 	  EN_attachDataInt((pEntity)tmpedge, _fixEnt, 1);
	
//       }
//     }
//     PList_delete(tmprvlist);
  }
  
  if((*pBestMod)->type() == RSHAPE) {
    tmpedge = ((edgeReShapeMod*)(*pBestMod))->getKeyEdge();
    if(!EN_getDataInt((pEntity)tmpedge, _fixEnt, &fid))
      EN_attachDataInt((pEntity)tmpedge, _fixEnt, 1);
  }
  
  PList_delete(newReg);
  
}

int curveMesh::isDsplitClpsLooseModValid(pRegion region, pMeshMod *pBestMod)
{
  *pBestMod = 0;
  
  double xyz[4][3], vxyz[3], param[3], worstShape = -BIG_NUMBER;
  double cosDhAngs[6];
  int i,  index, flag = 0, select_i, select_j, ok;
  double maxAng = BIG_NUMBER;
  pEdge e[2];
  
  R_coord(region, xyz);

  XYZ_dhdAngs(xyz, cosDhAngs);

  for(i=0; i<6; i++) {
    if(cosDhAngs[i] < maxAng) {
      maxAng = cosDhAngs[i];
      index = i;
    }
  }

  if(maxAng >= -0.86666)
    return 0;

  int e_index[6][2] = {{0,5}, {1,3}, {2,4}, {3, 1}, {2,4}, {0, 5}};
  
  pPList relist = R_edges(region, 1);
  DSplitClpsMod *dsclps = new DSplitClpsMod(pThePart_, pNullSF_, pShpMeasure_, pResults_); 
  dsclps->setCurved();
  for(i=0; i<2; i++) {
    e[0] = (pEdge)PList_item(relist, e_index[index][i]);
    e[1] = (pEdge)PList_item(relist, e_index[index][!i]);

    if(iTheMdlType_ == 1) {
      // check whether the edgepair[1] is fixed
      if(E_whatInType(e[1]) != 3) {
	ok = 0;
	continue;
      }
    }

    E_eval(e[0], 0.5, vxyz, param);

    dsclps->setCollaps(region, e[0], e[1], vxyz, param);
    if(iTheMdlType_ == 1)
      dsclps->setModelType(NOPARAM);
    else
      dsclps->setModelType(PARAM);

    // do the topocheck
    ok = dsclps->topoCheck();
    if(!ok)
      continue;

    dsclps->geomCheck();
    double newWorstShape = pResults_->getWorstShape();
    if(newWorstShape > worstShape)
      {
	flag = 1;
	worstShape = newWorstShape;
	select_i = e_index[index][i]; select_j= e_index[index][!i];
      }
  }

  if(flag) {
    e[0] = (pEdge)PList_item(relist, select_i);
    e[1] = (pEdge)PList_item(relist, select_j);
    E_eval(e[0], 0.5, vxyz, param);
    dsclps->setCollaps(region, e[0], e[1], vxyz, param);
    pResults_->setWorstShape(worstShape);
    *pBestMod = dsclps;
  }

  PList_delete(relist);
  
  return flag;

}

#if 1
int curveMesh::isUnCurvedModValid(pRegion region, crShpInfo *csi, pPList *newR) {
  
  
  double worstShape = csi->shape, invalidShape;
  
  if(csi->index > 3)
    {
      //   cout<<"Split edge with more than one invalid corners\n";
      // edge split to correct the situation that has more than one invalid corners 
      edgeSplitMod *esplit = new edgeSplitMod(pThePart_, pNullSF_, pShpMeasure_, pResults_);
      esplit->setModelType(NOPARAM);
      esplit->setCurved();
     
      if(isEdgeSplitModValid(esplit, region, csi->index, worstShape)){
	applyBestMod((pMeshMod *)esplit);
	delete esplit;
	return 1;
      }else {
	delete esplit;
	return 0;
      }
    }
  
  
  if(csi->index < 0)
    return 1;

  pPList elist = PList_new();

  edgeReShapeMod *rshp = new edgeReShapeMod(pThePart_, region, csi->index, pResults_);
  rshp->findKeyEdges(&elist);
  delete rshp;

  double vxyz[2][3];
  int i, flag = 0;
  pEdge edge;
  
  // Traverse every edge to determine the possible nodes
  for(i=0; i<3; i++) {
    edge = (pEdge)PList_item(elist, i);
    
    if( (E_whatInType(edge) != 3) && E_numPoints(edge)) {
      // ignore the straight edge
      if(!E_isCurved(edge))
	continue;
      
      
      pPoint pt = E_point(edge, 0);
      V_coord(E_vertex(edge, 0), vxyz[0]);
      V_coord(E_vertex(edge, 1), vxyz[1]);
      P_setPos(pt, 0.5*(vxyz[0][0]+vxyz[1][0]), 0.5*(vxyz[0][1]+vxyz[1][1]) , 0.5*(vxyz[0][2]+vxyz[1][2]));
      
      pPList erlist = E_regions(edge);
      int ok= R_worstShape(&erlist, worstShape, invalidShape, newR);
      PList_delete(erlist);
      
      if(!ok) {
	flag = 1;
	break;
      }      
    }
  }
  
  PList_delete(elist);
  
  return flag;
  
}

#endif

// find out the reshape
int curveMesh::findEdgeReShape(pRegion region, crShpInfo *csi, pMeshMod *pBestMod)
{
  *pBestMod = 0;
  double worstShape=csi->shape, newWorstShape;
  double xyz[3];
  
  if(csi->index > 3)
  {
      //  cout<<"Split edge with more than one invalid corners\n";
      // edge split to correct the situation that has more than one invalid corners 
      edgeSplitMod *esplit = new edgeSplitMod(pThePart_, pNullSF_, pShpMeasure_, pResults_);
      esplit->setModelType(NOPARAM);
      esplit->setCurved();
     
      if(isEdgeSplitModValid(esplit, region, csi->index, worstShape)){
	*pBestMod = esplit;
	return 1;
      }else {
	delete esplit;
	return 0;
      }
  }
  if(csi->index < 0)
  {
    //cout<<"Reshape not applied to shape improvement"<<endl; 
    return 0;
  }
  
  // Find the three edges at the invalid corner
  int flag = 0, i, ok, nc, all_fixed=0;
  pEdge edge, select_e;
  pPList elist = PList_new();

  edgeReShapeMod *rshp = new edgeReShapeMod(pThePart_, region, csi->index, pResults_);
  rshp->findKeyEdges(&elist);

  
  vector<rEdShpInfo *> reinfo;
  
  // Traverse every edge to determine the possible nodes
  for(i=0; i<3; i++) {
    edge = (pEdge)PList_item(elist, i);

    // The edge has been fixed
    if(EN_getDataInt((pEntity)edge, _fixEnt, &nc)){
      continue; // do not deal with fixed edges. Kai Apr 8, 2011
      if(E_whatInType(edge) == 3)
	continue;
      
      if(E_isCurved(edge))
	continue;
      
      if(E_onPlanarFace(edge)) {	
	//EN_deleteData(edge, _fixEnt);
	//cout<<"Edge on the planar model face"<<endl;
      }
    }
    // Set the edge to be curved
    rshp->setKeyEdge(edge);
 
    // Compute the target location of the edge 
    ok = rshp->computeMiddlePtTarget();
    
    rEdShpInfo *re = new rEdShpInfo;
    re->shape = pResults_->getWorstShape();
    re->newR = ok;
    re->ptxyz[0] = P_x(E_point(edge, 0));
    re->ptxyz[1] = P_y(E_point(edge, 0));
    re->ptxyz[2] = P_z(E_point(edge, 0));
    re->edge = edge;
    reinfo.push_back(re);
   
    rshp->resetEdge();
  }
  
  PList_delete(elist);


  if(!reinfo.size()){ // none of the three edges can be moved
    delete rshp;
    return 0;
  }

  rEdShpInfo *re = FindBestReShapeEdge(reinfo);
    
  if(re && (re->shape > csi->shape)) {
    rshp->setKeyEdge(re->edge);
    EN_attachDataInt(re->edge, _fixEnt, 1);
    pResults_->setWorstShape(re->shape);
    rshp->setPoint(re->ptxyz);
    *pBestMod = rshp;
    flag = 1;
  }
  else
    delete rshp;

  vector<rEdShpInfo *>::iterator miter=reinfo.begin(), miterend=reinfo.end();
  for(; miter != miterend; miter++)
    delete *miter;

  return flag;
  

}

// find out the best local mesh modification
int curveMesh::findBestMod(pRegion region, crShpInfo *csi, pMeshMod *pBestMod)
{
  *pBestMod = 0;
  double worstShape=csi->shape, newWorstShape;
  //crShpInfo tempcsi;
  /*if(CR_isValid(region, &tempcsi))
    {
      cout<<"The minimum jac is : jac";
      for(int i=0;i<3;i++)
	{
	  cout<<"["<<tempcsi.subscript[i]<<"]";
	}
      cout<<endl;
      }*/
#if 0 
  // vertex motion
  vertMotionsMod *vmotions = new vertMotionsMod(pThePart_, pNullSF_, pShpMeasure_, pResults_); 
  vmotions->setModelType(PARAM);
  vmotions->setMvEntTopo(0);
  if(getCurrentStage()==1 || getCurrentStage()==2)
    {
      //cout<<"Using Constraint Laplacian"<<endl;
      vmotions->setGeomCheckType(1); // Constrained Laplacian  
    } 
  else if(getCurrentStage()==3)
    {
      //cout<<"Applying Explicit Motion"<<endl;
      vmotions->setGeomCheckType(2); // Explicit Motion 
    }// cout<<isVertexMotionModValid(vmotions, region, worstShape)<<endl; 
  else
    {
      cout<<"Unknown Stage!!!"<<endl;
      return 0;
    }
  if(isVertexMotionModValid(vmotions, region, worstShape)){ 
    newWorstShape = pResults_->getWorstShape();
    if(newWorstShape > 0.0) {
      if(newWorstShape > worstShape) 
	{worstShape = newWorstShape; *pBestMod = vmotions;} 
      else 
	delete vmotions;
    } 
  }else 
    delete vmotions; 
    
  // assume that vertex motion takes the top priority **May 24, 2009
  // bad assumption, not much room for vertex motion before collapsing. Kai, Apr 27, 2010
  if(*pBestMod)
    return 1;

  //if(getCurrentStage()==3) // if at Stage 3: Apply explicit smoothing, then don't bother checking other locMod operations.
  // return 0;

#endif  

  // region collapse
  regionCollapsMod *rclps = new regionCollapsMod(pThePart_, pNullSF_, region, 150, pResults_);
  rclps->setCurved();
  rclps->setModelType(NOPARAM);
  if(isRegionClpsModValid(rclps, region, worstShape)){
    newWorstShape = pResults_->getWorstShape();
    if(newWorstShape > worstShape && newWorstShape > 0)
       {worstShape = newWorstShape; *pBestMod = rclps;}
     else
       delete rclps;
  }else
    delete rclps; 

  if(*pBestMod)
    return 1;
  
  // double split and collapse
  DSplitClpsMod *dsclps = new DSplitClpsMod(pThePart_, pNullSF_, pShpMeasure_, pResults_); 
  dsclps->setCurved();
  dsclps->setModelType(NOPARAM);
  if(isDsplitClpsModValid(dsclps, region, worstShape)){
    newWorstShape = pResults_->getWorstShape();
    if(newWorstShape > worstShape) {
      worstShape = newWorstShape; 
      if(*pBestMod) // if *pBestMod has pre-assigned memory, delete it first
        delete *pBestMod;
      *pBestMod = dsclps;
    }
    else
      delete dsclps;
  }else
    delete dsclps;

 
  
  // edge collapse 
  edgeCollapsMod *clps = new edgeCollapsMod(pThePart_, pNullSF_, pShpMeasure_, pResults_);
  clps->setCurved();
  clps->setModelType(NOPARAM);
  if(isEdgeClpsModValid(clps, region, worstShape)){
    newWorstShape = pResults_->getWorstShape();
    if(newWorstShape > worstShape) {
      worstShape = newWorstShape; 
      if(*pBestMod) // if *pBestMod has pre-assigned memory, delete it first
        delete *pBestMod;
      *pBestMod = clps;
    }
    else
      delete clps;
  }else
    delete clps;

 

  // face swap
  faceSwapMod *fswp = new faceSwapMod(pThePart_, pNullSF_, pShpMeasure_, pResults_);
  fswp->setCurved();
  fswp->setModelType(NOPARAM);
  if(isFaceSwpModValid(fswp, region, worstShape)){
    newWorstShape = pResults_->getWorstShape();
    if(newWorstShape > worstShape) {
       worstShape = newWorstShape; 
       if(*pBestMod) // if *pBestMod has pre-assigned memory, delete it first
         delete *pBestMod;
       *pBestMod = fswp;
    }
    else
      delete fswp;
  }else
    delete fswp;
  
 
  

  //edge swap
  edgeSwapMod *eswp = new edgeSwapMod(pThePart_, pNullSF_, pShpMeasure_, pResults_);
  eswp->setCurved();
  eswp->setModelType(NOPARAM);
  if(isEdgeSwpModValid(eswp, region, worstShape)){
    newWorstShape = pResults_->getWorstShape();
    if(newWorstShape > worstShape) {
      worstShape = newWorstShape; 
      if(*pBestMod) // if *pBestMod has pre-assigned memory, delete it first
        delete *pBestMod;
      *pBestMod = eswp;
    }
    else
      delete eswp;
  }else
    delete eswp;

 

  // edge slpit + collapse
  EsplitClpsMod *esclps = new EsplitClpsMod(pThePart_, pNullSF_, pShpMeasure_, pResults_);
  esclps->setCurved();
  esclps->setModelType(NOPARAM);
  if(isEdgeSplitClpsModValid(esclps, region, worstShape)){
    newWorstShape = pResults_->getWorstShape();
    if(newWorstShape > worstShape) {
      worstShape = newWorstShape; 
      if(*pBestMod) // if *pBestMod has pre-assigned memory, delete it first
        delete *pBestMod;
      *pBestMod = esclps;
    }
    else
      delete esclps;
  }else
    delete esclps; 

  
  
//   if(worstShape > desired_shape)
//     return 1;

  if(*pBestMod)
    return 1;
  
  // else {
//     // vertex motion
//     vertMotionsMod *vmotions = new vertMotionsMod(pThePart_, pNullSF_, pShpMeasure_, pResults_);
//     vmotions->setModelType(NOPARAM);
//     // vmotions->setGeomCheckType(1); // Constrained Laplacian
//     vmotions->setGeomCheckType(2); // Explicit Motion
//     // cout<<isVertexMotionModValid(vmotions, region, worstShape)<<endl;
//     // if(worstShape > desired_shape) { return 0; }
//     cout<<worstShape<<endl;
//     if(isVertexMotionModValid(vmotions, region, worstShape)){
//       cout<<"worstshape"<<worstShape<<endl;
//       newWorstShape = pResults_->getWorstShape();
//       cout<<"new worstshape"<<newWorstShape<<endl;
//       if(newWorstShape > worstShape*1.0)
// 	{worstShape = newWorstShape; *pBestMod = vmotions;cout<<"VertexMotion selected"<<endl;}
//       else
// 	delete vmotions;
//     }else
//       delete vmotions; 
//     if(*pBestMod)
//       return 1;
//     else
//       return 0;
//   }
  
  return 0;
}
/*
int curveMesh::isVertexMotionModValid(vertMotionsMod *vmotions, pRegion region, double &Shape)
{
  pPList vrlist = R_vertices(region, 1);
  void *temp;
  temp = 0;
  pVertex v, select_v;
  double select_target[3];
  int ok, flag = 0;
  double worstShape = Shape;
  
  while(v = (pVertex)PList_next(vrlist, &temp)) {
    vmotions->setVertex(v);
    ok = vmotions->geomCheck();
    if(!ok)
      continue;
    
    double newWorstShape = pResults_->getWorstShape();
    if(newWorstShape > worstShape) {
      flag = 1;
      worstShape = newWorstShape;
      select_v = v;
      vmotions->getTarget(select_target);
    }
  }

  PList_delete(vrlist);
  
  if(!flag)
    return 0;

  
  vmotions->setVertex(select_v);
  vmotions->setTarget(select_target);
  pResults_->setWorstShape(worstShape);
  return flag;

}


*/

// check whether edge split is valid
int curveMesh::isEdgeSplitModValid(edgeSplitMod *esplit,
				    pRegion region,
				    int & index,
				    double &Shape)
{
 
  pEdge edge;
  pFace face;
  pVertex vert;
  pPList elist, flist;
  void *temp;
  double *ptxyz;

  if(index > 3 && index < 10){
    // in the case of two invalid corners
    int edIndex[6] = {0, 2, 3, 1, 4, 5};
    double xyz[3], par[3];
    elist = R_edges(region, 1);
    edge = (pEdge)PList_item(elist, edIndex[index-4]);
    esplit->setSplitEdge(edge);
    E_eval(edge, 0.5, xyz, par);
    esplit->setSplitPos(xyz, par);
    PList_delete(elist);
    // quadratic situation
    flist = E_faces(edge);
    temp = 0;
    
    while(face = (pFace)PList_next(elist, &temp)) {
      vert = F_edOpVt(face, edge);
      ptxyz = new double[3];
      F_bezierSplit(face, edge, ptxyz);
      esplit->setHighOrderEdPts(vert, ptxyz);
    }
    PList_delete(flist);
    return 1;
  }

  return 0;

}

int curveMesh::isRegionClpsModValid(regionCollapsMod *rclps,
				    pRegion region,
				    double &Shape)
{

  //return 0;
  double worstShape = Shape;
  int  flag=0;
  if(Shape > 0.0)
    return 0;

  flag = rclps->topoCheck();

  // do the linear topology and geometric check first
  if(!flag)
    return 0;

  // only allow the cases that the # of the mesh faces 
  // classified on model face is 3
//  if(rclps->getCfg()!=3)
//    return 0;

  
  flag = rclps->geomCheck();
  if(!flag)
    return 0;

  // set up as the curved 
  rclps->setCurved();
  
  return flag;

}


int curveMesh::isEdgeSplitClpsModValid(EsplitClpsMod *esclps,
				       pRegion region,
				       double &Shape)
{

  int i, j, fid, ok = 0, flag=0;
  pFace face, select_face;
  pEdge edge, select_edge;
  pVertex select_v;
  double worstShape = Shape;
  
  for(i=0; i<4; i++) {
    face = R_face(region, i);
    
    for(j=0; j<3; j++) {
      edge = F_edge(face, j);

      // check whether the edge has been fix
      
      if(iTheMdlType_ ==1 && EN_getDataInt((pEntity)edge, _fixEnt, &fid)) 
	continue;
      

      // set up the edge and face
      esclps->reset(edge, face);
      
      ok = esclps->topoCheck();

      if(!ok)
	continue;

      ok = esclps->geomCheck();

      if(!ok)
	continue;

      double newWorstShape = pResults_->getWorstShape(); 
      if(newWorstShape > worstShape) {
	flag = 1;
	worstShape = newWorstShape;
	select_face = face;
	select_edge = edge;
	select_v = esclps->getVertex();
      }
    }
  }


  if(flag) {
    esclps->reset(select_edge, select_face);
    esclps->setVertex(select_v);
    pResults_->setWorstShape(worstShape);
  }

  return flag;
  
}


int curveMesh::isEdgeSwpModValid(edgeSwapMod *eswp,
				 pRegion region,
				 double &Shape)
{
  int i, fid, ok=0, flag=0, select_conf=-1;
  pPList relist = R_edges(region, 1);
  pEdge edge, select_e;
  double worstShape = Shape, best_xyz[3];

  for(i=0; i<6; i++) {
    edge = (pEdge)PList_item(relist, i);
   
    // in the case of no CAD model, edge swap is not allowed 
    // for edges classified on model boundary 
    if(iTheMdlType_ == 1 && E_whatInType(edge) != 3){
      continue;
    }
    
    eswp->setSwapEdge(edge);

    ok = eswp->topoCheck();
    
    if(!ok)
      continue;

    ok = eswp->geomCheck();

    if(!ok)
      continue;
    
    double newWorstShape = pResults_->getWorstShape(); 
    if(newWorstShape > worstShape) {
      flag = 1;
      worstShape = newWorstShape;
      select_e = edge;
      select_conf = eswp->getCfg();
      if(eswp->isMiddlePtComputed())
	eswp->getBestMdpt(best_xyz);
    } 
  }

  if(flag) {
    eswp->setSwapEdge(select_e);
    eswp->setCfg(select_conf);
    pResults_->setWorstShape(worstShape);
    if(eswp->isMiddlePtComputed())
      eswp->setBestMdpt(best_xyz);
  }

  PList_delete(relist);

  return flag;

}

int curveMesh::isFaceSwpModValid(faceSwapMod *fswp,
				 pRegion region,
				 double &Shape)
{
  int i, fid, ok=0, flag = 0;
  pFace face, select_face;
  double worstShape = Shape;
  F_SwapConfig select_fsc;
  
  for(i=0; i<4; i++) {
    face = R_face(region, i);

    fswp->setSwapFace(face);
    
    ok = fswp->topoCheck();
    
    if(!ok)
      continue;
    
    ok = fswp->geomCheck();

    if(!ok)
      continue;
      
    double newWorstShape = pResults_->getWorstShape(); 
    if(newWorstShape > worstShape) {
      flag = 1;
      worstShape = newWorstShape;
      select_face = face;
      select_fsc = fsc;
      select_fsc.swapType = fsc.swapType;
     
    } 
  }
  
  if(flag){
    fswp->setSwapFace(select_face);
    fswp->setFSC(select_fsc);
    pResults_->setWorstShape(worstShape);
  }
  return flag;
}

#endif // WHATEVER

int curveMesh::isEdgeClpsModValid(edgeCollapsMod *clps,
				  pRegion region, 
				  double &Shape)
{
  pPList rvlist, clps_ed_list;
  pVertex vert, vr, vd, select_vr, select_vd;
  pEdge edge, e, select_e;
  int i, numv_e, fid, ok, j, flag=0;
  void *temp;
  double worstShape = Shape;
  
  // get all the the possible edges
  clps_ed_list = PList_new();
  
  rvlist = R_vertices(region, 1);
  temp = 0;
  while(vert = (pVertex)PList_next(rvlist, &temp)) {
    numv_e = V_numEdges(vert);
    
    for(i=0; i<numv_e; i++) {
      edge = V_edge(vert, i);
      
      // check whether the edge has been fixed
      if(iTheMdlType_ == 1) {
	if(!EN_getDataInt((pEntity)edge, _fixEnt, &fid))
	  PList_appUnique(clps_ed_list, edge);
      }
      else
	PList_appUnique(clps_ed_list, edge);
    }
  }
  PList_delete(rvlist);
  

  // traverse all of the possible edges
  temp = 0;
  while(edge = (pEdge)PList_next(clps_ed_list, &temp)) {
  
    // check whether the edge collapse can be applied based on the selection of the vertex
    ok = 1;
    for(i=0; i<2; i++) {
      vr = E_vertex(edge, i);
      vd = E_otherVertex(edge, vr);
      
      // check whether all of the edges connected to vd are curved
      
      if(iTheMdlType_ == 1) {
	numv_e = V_numEdges(vd);
	for(j=0; j<numv_e; j++) {
	  e = V_edge(vd, j);
	  if(EN_getDataInt((pEntity)e, _fixEnt, &fid))
	    {ok = 0; break;}
	}
	
	if(!ok)
	  continue;
      }
      
      
      // initialize the collapse
      if(!R_inClosure(region, vd))
	continue;
      
      if(iTheMdlType_ == 1)
	clps->setModelType(NOPARAM);
      else
	clps->setModelType(PARAM);

      // set up the edgeDel, vr, vd
      clps->setCollaps(edge, vd, vr);
      
      // do the topocheck
      ok = clps->topoCheck();
      if(!ok) 
	continue;
      
      // do the geometric check
      ok = clps->geomCheck();

      if(!ok)
	continue;
      
      double newWorstShape = pResults_->getWorstShape(); 
      if(newWorstShape > worstShape) {
	flag = 1;
	worstShape = newWorstShape;
	select_e = edge;
	select_vr = vr;
	select_vd = vd;
      }
      
    } 
  }

  if(flag) {
    clps->setCollaps(select_e, select_vd, select_vr);
    pResults_->setWorstShape(worstShape);
  }

  PList_delete(clps_ed_list);

  return flag;
  
}



#ifdef CURVE

int meshAdapt::CMA_isEdgeClpsModValid(edgeCollapsMod *clps,
				  pRegion region, 
				  double &Shape)
{
  pPList rvlist, clps_ed_list;
  pVertex vert, vr, vd, select_vr, select_vd;
  pEdge edge, e, select_e;
  int i, numv_e, fid, ok, j, flag=0;
  void *temp;
  double worstShape = Shape;
  
  // get all the the possible edges
  clps_ed_list = PList_new();
  
  rvlist = R_vertices(region, 1);
  temp = 0;
  while(vert = (pVertex)PList_next(rvlist, &temp)) {
    numv_e = V_numEdges(vert);
    
    for(i=0; i<numv_e; i++) {
      edge = V_edge(vert, i);
      
      // check whether the edge has been fixed
      //if(iTheMdlType_ == 1) {
	//if(!EN_getDataInt((pEntity)edge, _fixEnt, &fid))
	 // PList_appUnique(clps_ed_list, edge);
      //}
      //else
	//PList_appUnique(clps_ed_list, edge);
    }
  }
  PList_delete(rvlist);
  

  // traverse all of the possible edges
  temp = 0;
  while(edge = (pEdge)PList_next(clps_ed_list, &temp)) {
  
    // check whether the edge collapse can be applied based on the selection of the vertex
    ok = 1;
    for(i=0; i<2; i++) {
      vr = E_vertex(edge, i);
      vd = E_otherVertex(edge, vr);
      
      // check whether all of the edges connected to vd are curved
      
      //if(iTheMdlType_ == 1) {
	//numv_e = V_numEdges(vd);
	//for(j=0; j<numv_e; j++) {
	  //e = V_edge(vd, j);
	  //if(EN_getDataInt((pEntity)e, _fixEnt, &fid))
	    //{ok = 0; break;}
	//}
	
	//if(!ok)
	  //continue;
      //}
      
      
      // initialize the collapse
      if(!R_inClosure(region, vd))
	continue;
      
      if(model_type == 1)
	clps->setModelType(NOPARAM);
      else
	clps->setModelType(PARAM);

      // set up the edgeDel, vr, vd
      clps->setCollaps(edge, vd, vr);
      
      // do the topocheck
      ok = clps->topoCheck();
      if(!ok) 
	continue;
      
      // do the geometric check
      ok = clps->geomCheck();

      if(!ok)
	continue;
      
      double newWorstShape = result->getWorstShape(); 
      if(newWorstShape > worstShape) {
	flag = 1;
	worstShape = newWorstShape;
	select_e = edge;
	select_vr = vr;
	select_vd = vd;
      }
      
    } 
  }

  if(flag) {
    clps->setCollaps(select_e, select_vd, select_vr);
    result->setWorstShape(worstShape);
  }

  PList_delete(clps_ed_list);

  return flag;
  
}

#endif // CURVE

//#ifdef WHATEVER
#ifdef CURVE
int curveMesh::isDsplitClpsModValid(DSplitClpsMod *dsclps,
				    pRegion region, 
				    double &Shape)
{
  int i,j, ok = 0, fid, bc_id, select_i, select_j, flag = 0;
  pEdge e[2];
  double param[3], vxyz[3];
  double worstShape = Shape;
  int eindex[3][2] = {{0, 5}, {1, 3}, {2, 4}};

  pPList relist = R_edges(region, 1);
  for(i=0; i<3; i++) {
    for(j=0; j<2; j++) {
      e[0] = (pEdge)PList_item(relist, eindex[i][j]);
      e[1] = (pEdge)PList_item(relist, eindex[i][!j]);
      E_eval(e[0], 0.5, vxyz, param);
      
      if(iTheMdlType_ == 1) {
	// check whether the edgepair[1] is fixed
	if(EN_getDataInt((pEntity)e[1], _fixEnt, &fid)) {
	  ok = 0;
	  continue;
	}
      }
      
      // set up the region and the edges
      dsclps->setCollaps(region, e[0], e[1], vxyz, param);
      if(iTheMdlType_ == 1)
	dsclps->setModelType(NOPARAM);
      else
	dsclps->setModelType(PARAM);
      
      // do the topocheck
      ok = dsclps->topoCheck();
      if(!ok)
	continue;
      
      // do the geometric check
      ok = dsclps->geomCheck();
      if(!ok) 
	continue;
      
      // the region collapse is ok
      if(ok) {
	double newWorstShape = pResults_->getWorstShape();
	if(newWorstShape > worstShape)
	  {
	    flag = 1;
	    worstShape = newWorstShape;
	    select_i = i; select_j=j;
	  }
      }
    }
  }

  if(flag) {
    e[0] = (pEdge)PList_item(relist, eindex[select_i][select_j]);
    e[1] = (pEdge)PList_item(relist, eindex[select_i][!select_j]);
    E_eval(e[0], 0.5, vxyz, param);
    dsclps->setCollaps(region, e[0], e[1], vxyz, param);
    pResults_->setWorstShape(worstShape);
  }

  PList_delete(relist);

 
  return flag;

}


 
int R_worstShape(pPList *erlist, double &worstShape, double &worstInvalidShape, pPList *invalidRList)
{
  void *iter;
  iter = 0;
  pRegion region;
  crShpInfo csi;
  int ok = 1;
  double shape = BIG_NUMBER, ishape =  BIG_NUMBER;

  while(region = (pRegion)PList_next(*erlist, &iter)) {
    if(!CR_isValid(region, &csi)) {
      ok = 0;
      PList_appUnique(*invalidRList, region);
      if(csi.shape < ishape)
	ishape = csi.shape;
    }
    else {
      if(csi.shape < shape)
	shape = csi.shape;
    }
  }

  worstShape = shape;
  
  if(!PList_size(*invalidRList)) { 
    worstInvalidShape = shape;
  }
  else
    worstInvalidShape = ishape;

  return ok;
}

/* print the shape distribution of a curved mesh */
void M_checkCurvedRegionShape(pMesh pThePart_, char *fname)
{
  int numRTot = M_numRegions(pThePart_);
  int numCRTot = 0;
  int cshape_profile[]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
  pRegion  region;
  int index, i;
  double shape, sml, big;
  int shapeMeasureMethod = 0;
  double rgnShape = 0.5;
  crShpInfo csi;
  numCRTot = numRTot;
  
  RIter riter=M_regionIter(pThePart_);
  while(region = RIter_next(riter)) {
    index = CR_isValid(region, &csi);
    shape = csi.shape;
   //  numCRTot ++;  
    
    if( shape<0.0 ) ++cshape_profile[0];
    else if( shape<1.0e-5 ) ++cshape_profile[1];
    else if( shape<1.0e-4 ) ++cshape_profile[2];
    else if( shape<1.0e-3 ) ++cshape_profile[3];
    else if( shape< 0.01 ) ++cshape_profile[4];
    else if( shape< 0.02 ) ++cshape_profile[5];
    else if( shape< 0.05 ) ++cshape_profile[6];
    else if( shape< 0.1 ) ++cshape_profile[7];
    else if( shape< 0.2 ) ++cshape_profile[8];
    else if( shape< 0.3 ) ++cshape_profile[9];
    else if( shape< 0.4 ) ++cshape_profile[10];
    else if( shape< 0.5 ) ++cshape_profile[11];
    else if( shape< 0.6 ) ++cshape_profile[12];
    else if( shape< 0.7 ) ++cshape_profile[13];
      else if( shape< 0.8 ) ++cshape_profile[14];
    else ++cshape_profile[15];
    
  }
  
  RIter_delete(riter);
  
  
  std::ofstream outFile(fname);
  outFile<<"-> shape distribution for curved meshes <-: "<< numCRTot<< endl;
  
  outFile<<"0.0      "<<cshape_profile[0]<<" "<<(double)cshape_profile[0]/(double)numCRTot<<endl;
  outFile<<"0.00001 "<<cshape_profile[1]<<" "<<(double)cshape_profile[1]/(double)numCRTot<<endl;
  outFile<<"0.0001  "<<cshape_profile[2]<<" "<<(double)cshape_profile[2]/(double)numCRTot<<endl;
  outFile<<"0.001   "<<cshape_profile[3]<<" "<<(double)cshape_profile[3]/(double)numCRTot<<endl;
  outFile<<"0.01    "<<cshape_profile[4]<<" "<<(double)cshape_profile[4]/(double)numCRTot<<endl;
  outFile<<"0.02     "<<cshape_profile[5]<<" "<<(double)cshape_profile[5]/(double)numCRTot<<endl;
  outFile<<"0.05     "<<cshape_profile[6]<<" "<<(double)cshape_profile[6]/(double)numCRTot<<endl;
  outFile<<"0.1    "<<cshape_profile[7]<<" "<<(double)cshape_profile[7]/(double)numCRTot<<endl;
  outFile<<"0.2     "<<cshape_profile[8]<<" "<<(double)cshape_profile[8]/(double)numCRTot<<endl;
  outFile<<"0.3     "<<cshape_profile[9]<<" "<<(double)cshape_profile[9]/(double)numCRTot<<endl;
  outFile<<"0.4    "<<cshape_profile[10]<<" "<<(double)cshape_profile[10]/(double)numCRTot<<endl;
  outFile<<"0.5     "<<cshape_profile[11]<<" "<<(double)cshape_profile[11]/(double)numCRTot<<endl;
  outFile<<"0.6     "<<cshape_profile[12]<<" "<<(double)cshape_profile[12]/(double)numCRTot<<endl;
  outFile<<"0.7     "<<cshape_profile[13]<<" "<<(double)cshape_profile[13]/(double)numCRTot<<endl;
  outFile<<"0.8     "<<cshape_profile[14]<<" "<<(double)cshape_profile[14]/(double)numCRTot<<endl;
  outFile<<"1.     "<<cshape_profile[15]<<" "<<(double)cshape_profile[15]/(double)numCRTot<<endl;
  
  cout<<"-> shape distribution for curved elements <-"<< numCRTot<< endl;
  cout<<"0.0      "<<cshape_profile[0]<<" "<<(double)cshape_profile[0]/(double)numCRTot<<endl;
  cout<<"0.00001 "<<cshape_profile[1]<<" "<<(double)cshape_profile[1]/(double)numCRTot<<endl;
  cout<<"0.0001  "<<cshape_profile[2]<<" "<<(double)cshape_profile[2]/(double)numCRTot<<endl;
  cout<<"0.001   "<<cshape_profile[3]<<" "<<(double)cshape_profile[3]/(double)numCRTot<<endl;
  cout<<"0.01   "<<cshape_profile[4]<<" "<<(double)cshape_profile[4]/(double)numCRTot<<endl;
  cout<<"0.02     "<<cshape_profile[5]<<" "<<(double)cshape_profile[5]/(double)numCRTot<<endl;
  cout<<"0.05     "<<cshape_profile[6]<<" "<<(double)cshape_profile[6]/(double)numCRTot<<endl;
  cout<<"0.1    "<<cshape_profile[7]<<" "<<(double)cshape_profile[7]/(double)numCRTot<<endl;
  cout<<"0.3     "<<cshape_profile[8]<<" "<<(double)cshape_profile[8]/(double)numCRTot<<endl;
  cout<<"0.3     "<<cshape_profile[9]<<" "<<(double)cshape_profile[9]/(double)numCRTot<<endl;
  cout<<"0.4    "<<cshape_profile[10]<<" "<<(double)cshape_profile[10]/(double)numCRTot<<endl;
  cout<<"0.5     "<<cshape_profile[11]<<" "<<(double)cshape_profile[11]/(double)numCRTot<<endl;
  cout<<"0.6     "<<cshape_profile[12]<<" "<<(double)cshape_profile[12]/(double)numCRTot<<endl;
  cout<<"0.7     "<<cshape_profile[13]<<" "<<(double)cshape_profile[13]/(double)numCRTot<<endl;
  cout<<"0.8     "<<cshape_profile[14]<<" "<<(double)cshape_profile[14]/(double)numCRTot<<endl;
  cout<<"1.0     "<<cshape_profile[15]<<" "<<(double)cshape_profile[15]/(double)numCRTot<<endl;

  return;

}

void writeOutCurvedRegion(pRegion region, int closure, char *cname)
{
  
  pPList rlist;
  rlist = PList_new();
  PList_appUnique(rlist, region);
  writeOutCurvedRList(&rlist, closure, cname);
  PList_delete(rlist);
}


void writeOutCurvedRList(pPList *rlist, int closure, char* cname)
{
  
  pPList vlist;
  pPList elist;
  pPList flist;

  flist = PList_new();
  elist = PList_new();
  vlist = PList_new();
  
  // face adjacency
  void *temp;
  temp = 0;
  pRegion region;
  while(region = (pRegion)PList_next(*rlist, &temp)) {
    pPList tmplist = R_vertices(region, 1);
    PList_appPListUnique(vlist, tmplist);
    PList_delete(tmplist);
    tmplist = R_edges(region, 1);
    PList_appPListUnique(elist, tmplist);
    PList_delete(tmplist);
    for(int i=0; i<4; i++)
      PList_appUnique(flist, R_face(region, i));
  }
  

  if(closure==2){
    
    // get all of the region
    temp = 0;
    pFace face;
    while(face = (pFace)PList_next(flist, &temp)) {
      pPList tmpr = F_regions(face);
      PList_appPListUnique(*rlist, tmpr);
      PList_delete(tmpr);
    }  
  }
  else if (closure == 1) { // edge adjacency
    
    temp = 0;
    pEdge edge;
    while(edge = (pEdge)PList_next(elist, &temp)) {
      pPList tmpr = E_regions(edge);
      PList_appPListUnique(*rlist, tmpr);
      PList_delete(tmpr);
    }
  }
  else if (closure == 0) {

    temp = 0;
    pVertex v;
    while(v = (pVertex)PList_next(vlist, &temp)) {
      pPList tmpr = V_regions(v);
      PList_appPListUnique(*rlist, tmpr);
      PList_delete(tmpr);
    }
  }
  

  
    // get all of the vertices
  temp=0;
  pRegion r;
  while(r = (pRegion)PList_next(*rlist, &temp)) {
    pPList tmpr = R_vertices(r, 1);
    PList_appPListUnique(vlist, tmpr);
    PList_delete(tmpr);
  }
  
  // get all of the edge;
  temp=0;
  while(r = (pRegion)PList_next(*rlist, &temp)) {
    pPList tmpr = R_edges(r, 1);
    PList_appPListUnique(elist, tmpr);
    PList_delete(tmpr);
  }
  
    // get all of faces;
  temp=0;
  while(r = (pRegion)PList_next(*rlist, &temp)) {
    for(int i=0; i<4; i++)
      PList_appUnique(flist, R_face(r, i));
  }
  
  
  pMeshDataId vid = MD_newMeshDataId("vid");
  int count = 1, j;
  int numV, numE, numF, numR;
  temp = 0;
  pVertex v;
  while(v = (pVertex)PList_next(vlist, &temp)) 
    EN_attachDataInt((pEntity)v, vid, count++);
  
  numV = PList_size(vlist);
  numE = PList_size(elist);
  numF = PList_size(flist);
  numR = PList_size(*rlist);

  FILE* outFile = fopen(cname, "w");
  fprintf(outFile, "sms 2\n");
  fprintf(outFile, "%d %d %d %d %d\n", numR, numF, numE, numV, numV);
  
  
  temp=0;
  double loc[3];
  int gentag = 1;
  int gentitytype = 2;
  while(v = (pVertex)PList_next(vlist, &temp)) {
    V_coord(v, loc);
    fprintf(outFile, "%d %d %d\n%.15f %.15f %.15f ",
                      gentag++, gentitytype, V_numEdges(v), 
		      loc[0], loc[1], loc[2]); 	
    fprintf(outFile, "%d %d %d", 0, 0, 0);    
    fprintf(outFile, "\n"); 
  }

  temp=0;
  pEdge e;
  int id;
  count = 1;
  while(e = (pEdge)PList_next(elist, &temp)) {
    fprintf(outFile, "%d %d ",  gentag++, gentitytype);
    EN_attachDataInt(e, vid, count++);
    for(j=0; j<2; j++) {
      v=E_vertex(e, j);
      EN_getDataInt(v, vid, &id);
      fprintf(outFile, "%d ",id);
    }
    fprintf(outFile, "%d ", E_numFaces(e));
    fprintf(outFile, "%d\n", 1);
    if(E_numPoints(e)) {
      pPoint pt = E_point(e, 0);
      fprintf(outFile,"%.15f %.15f %.15f ",P_x(pt), P_y(pt), P_z(pt));
      fprintf(outFile, "0 0 0");
      fprintf(outFile, "\n");
    }
    else {
      E_bezierCtrlPt(e, loc);
      fprintf(outFile,"%.15f %.15f %.15f ",loc[0], loc[1], loc[2]);
      fprintf(outFile, "0 0 0");
      fprintf(outFile, "\n");
    }
  }

  pFace f;
  count=1;
  temp = 0;
  while(f=(pFace)PList_next(flist, &temp)) {
    EN_attachDataInt(f, vid, count++);
    fprintf(outFile, "%d %d ", gentag++, gentitytype);
    int numEdges=F_numEdges(f);
    fprintf(outFile, "%d ", numEdges);
    for (j=0; j<numEdges ;j++)
    {
      e = F_edge(f,j);
      EN_getDataInt(e, vid, &id);
      if (!F_edgeDir(f,j)) id=-id;
      fprintf(outFile, "%d ", id);
    }
    fprintf(outFile, "0\n");
  }

  temp=0;
  gentag = 1;
  gentitytype = 3;
  while(r=(pRegion)PList_next(*rlist, &temp)) {
    int  numFaces=R_numFaces(r);
    fprintf(outFile, "%d %d ",  gentag++, numFaces);
    for (j=0; j<numFaces ;j++)
      {		  
	f = R_face(r,j);
	EN_getDataInt(f, vid, &id);
	if (!R_faceDir(r,j)) id=-id;
	fprintf(outFile, "%d ", id);
      } 
      fprintf(outFile, "0\n");
  }

  fclose(outFile);

  temp = 0;
  while(v = (pVertex)PList_next(vlist, &temp)) 
    EN_deleteData((pEntity)v, vid);
  temp=0;
  while(e = (pEdge)PList_next(elist, &temp)) 
    EN_deleteData((pEntity)e, vid);
  temp=0;
  while(f = (pFace)PList_next(flist, &temp)) 
    EN_deleteData((pEntity)f, vid);
  
  MD_deleteMeshDataId(vid);
  
  PList_delete(vlist);
  PList_delete(elist);
  PList_delete(flist);

  return;

}

rEdShpInfo * FindBestReShapeEdge(vector<rEdShpInfo*> &reinfo){
  pEdge edge[3], iedge[3];
  double shape[3], ishape[3];
  int numR[3];
  
  int numE = reinfo.size();

  // only one edge available
  if(numE == 1)
    return reinfo[0];

  // two edges available
  shape[0] = (reinfo[0])->shape;
  shape[1] = (reinfo[1])->shape;
  numR[0] = (reinfo[0])->newR;
  numR[1] = (reinfo[1])->newR;

  if(!numR[0] && !numR[1]) {
    // both of the them have no new invalid regions
    if(shape[1] > shape[0])
      return reinfo[1];
    else
      return reinfo[0];
  }
  else if(!numR[0] && numR[1])
    return reinfo[0];
  else if(numR[0] && !numR[1])
    return reinfo[1];
  else{
    // both of them have new invalid regions
    if(shape[1] > shape[0])
      return reinfo[1];
    else
      return reinfo[0];
  }
  
  // three edges available
  shape[2] = (reinfo[2])->shape;
  numR[2] = (reinfo[2])->newR;
 
  if(!numR[0] && !numR[1] && !numR[2]) { //000
    // all of them have no new invalid regions
    int index =0;
    double tmp = shape[0];
    for(int i=1; i<3; i++)
      if(shape[i] > tmp)
	index = i;

    return reinfo[index];
  }
  else if(!numR[0] && !numR[1] && numR[2]) { //001
    if(shape[1] > shape[0])
      return reinfo[1];
    else
      return reinfo[0];
  }
  else if(!numR[0] && numR[1] && !numR[2]) { //010
    if(shape[2] > shape[0])
      return reinfo[2];
    else
      return reinfo[0];
  }
  else if(numR[0] && !numR[1] && !numR[2]) { //100
    if(shape[2] > shape[1])
      return reinfo[2];
    else
      return reinfo[1];
  }
  else if(!numR[0] && numR[1] && numR[2])  //011
    return reinfo[0];
  else if(numR[0] && !numR[1] && numR[2])  //101
    return reinfo[1];
  else if(numR[0] && numR[1] && !numR[2])  //110
    return reinfo[2];
  else if(numR[0] &&  numR[1] && numR[2])  {//111
     int index =0;
    double tmp = shape[0];
    for(int i=1; i<3; i++)
      if(shape[i] > tmp)
	index = i;

    return reinfo[index];
  }
  else{
    cout<<"Error: unexpected pattern:"<<endl;
  }
  
  return (rEdShpInfo *)0;
}

// for computing Q_s and Q_c of high-order tets.
void computeRegionShape(pRegion region, crShpInfo *csi){
 
  pPList elist = R_edges(region, 1);
  pPList vlist = R_vertices(region, 1);
  pVertex vert;
  pEdge e;
  int i, j, isHighOrder = 0;
  double shape;
  double xyz[10][3];
  
  R_coord(region, xyz);

  for(j=0; j<6; j++) {
    e = (pEdge)PList_item(elist, j);
    if(E_numPoints(e))//non-zero  ->  higher order
      {
	isHighOrder = 1; 
	break;
      }
  }
  
  // PList_delete(elist);
  
  XYZ_shapeMeasure(xyz, &shape);
  csi->qs = shape;   // get straight-sided shape

  if(!isHighOrder){    // linear tet
    csi->qc = 1;
    csi->shape = shape * 1;
    //cout<<"Linear"<<endl;
  }
  else {       // high-order tet

    double rxyz[10][3];
  
  // assemble the control points for the quadratic element
   
 
    for(i=0; i<4; i++) {
      vert = (pVertex)PList_item(vlist, i);
      V_coord(vert, rxyz[i]);
    }

    PList_delete(vlist);
  
    for(j=0; j<6; j++) {
      e = (pEdge)PList_item(elist, j);
      E_bezierCtrlPt(e, rxyz[i++]);
    }
    
    PList_delete(elist);
  
    double tetCtrlPts[3][3][3][3];
  
    double du[2][2][2][3], dv[2][2][2][3], dw[2][2][2][3];

    double jac[4][4][4];

    int i, j, k, l, m, n, r, s, t, d1, d2, d3, d4, d5, d6;
    int degree = 2;
    double minDetJ = BIG_NUMBER, maxDetJ = -BIG_NUMBER;
    

    for(k=0; k<3; k++) {
    // vertices
      tetCtrlPts[0][0][0][k] = rxyz[0][k];
      tetCtrlPts[2][0][0][k] = rxyz[1][k];
      tetCtrlPts[0][2][0][k] = rxyz[2][k];
      tetCtrlPts[0][0][2][k] = rxyz[3][k];

    // edges
      tetCtrlPts[1][0][0][k] = rxyz[4][k];
      tetCtrlPts[1][1][0][k] = rxyz[5][k];
      tetCtrlPts[0][1][0][k] = rxyz[6][k];
      tetCtrlPts[0][0][1][k] = rxyz[7][k];
      tetCtrlPts[1][0][1][k] = rxyz[8][k];
      tetCtrlPts[0][1][1][k] = rxyz[9][k];
    }



    //calculate the derivatives
    for(i=0; i<degree; i++) {
      for(j=0; j<degree-i; j++) {
	for(k=0; k<degree-i-j; k++) {
	  diffVt(tetCtrlPts[i+1][j][k], tetCtrlPts[i][j][k], du[i][j][k]);
	  diffVt(tetCtrlPts[i][j+1][k], tetCtrlPts[i][j][k], dv[i][j][k]);
	  diffVt(tetCtrlPts[i][j][k+1], tetCtrlPts[i][j][k], dw[i][j][k]);
	}
      }
    }
    
    //clear the jacobian 
    for (i = 0; i < 4; i++) {
      for (j = 0; j < 4-i; j++) {
	for (k = 0; k < 4-i-j; k++) { 
	  jac[i][j][k] = 0.0;
	  //	issues(i,j,k) = 0;
	}
      }
    }
    
    int flag = 1;
    //calculate the box products
    double degree2 = degree * degree * degree, cp[3], detj, coeff;
  
    for (i = 0; i < degree; i++) {
      d1 = degree - i;
      for (j = 0; j < d1; j++) {
	d2 = d1 - j;
	for(k = 0; k < d2; k++){
	  for (l = 0; l < degree; l++) {
	    d3 = degree - l;
	    for (m = 0; m < d3; m++) {
	      d4 = d3 - m;
	      for(n = 0; n < d4; n++){
		for(r = 0; r < degree; r++){
		  d5 = degree - r;
		  for(s = 0; s < d5; s++){
		    d6 = d5 - s;
		    for(t = 0; t< d6; t++){
		      crossProd(du[i][j][k], dv[l][m][n], cp);
		      detj = dotProd(cp, dw[r][s][t]);
		      //    printf("%d %d %d, %d %d %d, %d %d %d\n", i, l, r, j, m, s, k, n, t);
		      jac[i+l+r][j+m+s][k+n+t] += detj * degree2;
		      if((i+l+r) > 3 || (j+m+s) >3 || (k+n+t) > 3)
			printf("Something is wrong: %d %d %d\n", i+l+r, j+m+s, k+n+t);
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    } 
    //int xi[3];
    for (i = 0; i < 4; i++) {
      for (j = 0; j < 4-i; j++) {
	for (k = 0; k < 4-i-j; k++) { 
	  coeff = (double)factorial(3*(degree-1))/(double)(factorial(i)*factorial(j)*factorial(k)*factorial(3*(degree-1)-i-j-k));
	  jac[i][j][k] /= coeff;
	  if(jac[i][j][k] <=0.0) {
	    flag = 0;
	  }
	  minDetJ = MIN(minDetJ, jac[i][j][k]);
	  if( minDetJ == jac[i][j][k] )
	    {
	      csi->index1[0] = i;
	      csi->index1[1] = j;
	      csi->index1[2] = k;
	    }
	  maxDetJ = MAX(maxDetJ, jac[i][j][k]);
	  //	issues(i,j,k) = 0;
	}
      }
    }
    // the index is used to help to determine the key entities to apply
    // local mesh modifications
    //if(minDetJ/maxDetJ < 0.9) 
    // cout<<"min Jac["<<xi[0]<<"]["<<xi[1]<<"]["<<xi[2]<<"]"<<endl;
    if(csi->index1[0]==3||csi->index1[1]==3||csi->index1[2]==3||(csi->index1[0]==0&&csi->index1[1]==0&&csi->index1[2]==0))
      {
	csi->isCorner = 1;
	//cout<<"1"<<endl;
      }
    else 
      {
	csi->isCorner = 0;
	//cout<<"2"<<endl;
      }
  
    csi->qc =  minDetJ / maxDetJ;
    csi->shape = (csi->qs)*(csi->qc);
    //cout<<"High-order"<<endl; 
    
  }
}

int curveMesh::minDetJAmgVertices(crShpInfo *csi, int *edgeID, int *vertID){
  if(!csi->isCorner){ //minimum if not at corner vertices
    return 0;
  }
  else{ //minimum is at one of the corner vertices
    if(csi->index1[0]==0&&csi->index1[1]==0&&csi->index1[2]==0){ // minDetJ is at [0][0][0], vertex 0
      *vertID = 0;
      edgeID[0] = 0;
      edgeID[1] = 2;
      edgeID[2] = 3;
    }
    else if(csi->index1[0]==3&&csi->index1[1]==0&&csi->index1[2]==0){ //Jac[3][0][0], vertex 1
      *vertID = 1;
      edgeID[0] = 0;
      edgeID[1] = 1;
      edgeID[2] = 4;
    }
    else if(csi->index1[0]==0&&csi->index1[1]==3&&csi->index1[2]==0){ //Jac[0][3][0], vertex 2
      *vertID = 2;
      edgeID[0] = 1;
      edgeID[1] = 2;
      edgeID[2] = 5;
    }
    else if(csi->index1[0]==0&&csi->index1[1]==0&&csi->index1[2]==3){ //Jac[0][0][3], vertex 3 
      *vertID = 3;
      edgeID[0] = 3;
      edgeID[1] = 4;
      edgeID[2] = 5;
    }
    
    return 1;
  }
}

#endif /* WHATEVER */
