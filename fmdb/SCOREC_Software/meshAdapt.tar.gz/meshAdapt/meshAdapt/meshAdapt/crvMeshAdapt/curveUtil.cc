#include "curveUtil.h"
#include "Macros.h"
#include <math.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <assert.h>
#include "fromMeshTools.h"
#include "PList.h"

using namespace std;

#ifdef FMDB_PARALLEL
#include "ParUtil.h"
#endif


int factorial(int num)
{
  if(num < 0){
    cout<<"Error: Negative number factorial!"<<endl; 
    return -1;
  }

  int result=1;
  for(int i=1;i<=num;++i)
    result*=i;
  return result;
}

namespace curveUtil {

int R_numEdgesOnGeomRegn(pRegion pTheRgn){

  int iEdgeCnt = 0;
  pPList elist = R_edges(pTheRgn,1);

  for(int i=0; i<6; ++i){
    pEdge pCrntEdge = (pEdge)PList_item(elist, i);
    if(E_whatInType(pCrntEdge)==3){
      ++iEdgeCnt;
    }
  }

  PList_delete(elist);
#ifdef DEBUG
  assert(iEdgeCnt>=0);
  assert(iEdgeCnt<=6);
#endif
  return iEdgeCnt;

}

int R_numEdgesOnGeomFace(pRegion pTheRgn)
{
  int iEdgeCnt = 0;
  pPList elist = R_edges(pTheRgn,1);

  for(int i=0; i<6; ++i){
    pEdge pCrntEdge = (pEdge)PList_item(elist, i);

    if(E_whatInType(pCrntEdge)==2){
      ++iEdgeCnt;
    }
  }

  PList_delete(elist);
#ifdef DEBUG
  assert(iEdgeCnt>=0);
  assert(iEdgeCnt<=6);
#endif
  return iEdgeCnt;

}

int R_numEdgesOnGeomEdge(pRegion pTheRgn)
{
  int iEdgeCnt = 0;
  pPList elist = R_edges(pTheRgn,1);

  for(int i=0; i<6; ++i){
    pEdge pCrntEdge = (pEdge)PList_item(elist, i);

    if(E_whatInType(pCrntEdge)==1){
      ++iEdgeCnt;
    }
  }

  PList_delete(elist);
#ifdef DEBUG
  assert(iEdgeCnt>=0);
  assert(iEdgeCnt<=6);
#endif
  return iEdgeCnt;

}

int R_numFacesOnGeomRegn(pRegion pTheRgn)
{
  int iFaceCnt = 0;
  pPList flist = R_faces(pTheRgn,1);

  for(int i=0; i<4; ++i){
    pFace pCrntFace = (pFace)PList_item(flist, i);
    if(F_whatInType(pCrntFace)==3){
      ++iFaceCnt;
    }
  }

  PList_delete(flist);
#ifdef DEBUG
  assert(iFaceCnt>=0);
  assert(iFaceCnt<=4);
#endif
  return iFaceCnt;

}

int R_numFacesOnGeomFace(pRegion pTheRgn)
{
  int iFaceCnt = 0;
  pGFace theGFace = NULL;
  pPList flist = R_faces(pTheRgn,1);

  for(int i=0; i<4; ++i){
    pFace pCrntFace = (pFace)PList_item(flist, i);

    if(F_whatInType(pCrntFace)!=3){
      ++iFaceCnt;
#ifdef DEBUG
      pGFace CrntGFace = (pGFace)F_whatIn(pCrntFace);
      if(iFaceCnt==1)
        theGFace = CrntGFace;
      if(iFaceCnt==2){
        if(theGFace!=CrntGFace)
          cout<<"The Two Geom Faces are DIFFERENT !"<<endl;
        else
          cout<<"The Two Geom Faces are THE SAME "<<endl;
      }
#endif
    }
  }

  PList_delete(flist);
#ifdef DEBUG
  assert(iFaceCnt>=0);
  assert(iFaceCnt<=4);
#endif
  return iFaceCnt;

}


void M_checkSurfaceMeshByAngle(pMesh mesh, vector<pFace> &vec_facesLargeAngle)
{

  vec_facesLargeAngle.clear();

  /* 1. Create face iter */
  FIter fiter = M_faceIter(mesh);
  pFace crntFace;

  int nbr_poor_faces = 0;
  int nbr_small_ang = 0;
  int nbr_large_ang = 0;
  int flag;
  /* 2. Iterator over the mesh */
  while(crntFace = FIter_next(fiter)){

    if(F_whatInType(crntFace)==3) // if current face is classified on GREGION
      continue;                   // then skip it

    double fxyz[6][3];
    F_coord(crntFace, fxyz); // get the coords of the face vertices

    double vec[3][3];
    diffVt(fxyz[0], fxyz[1], vec[0]);
    diffVt(fxyz[1], fxyz[2], vec[1]);
    diffVt(fxyz[2], fxyz[0], vec[2]);  // compute the 3 edge vectors

    flag = adaptUtil::RelativeDirection(vec[0], vec[1]);
    if(flag==1||flag==-1){
      vec_facesLargeAngle.push_back(crntFace);
      nbr_poor_faces++;
      if(flag==1)
        nbr_small_ang++;
      else
        nbr_large_ang++;
      continue;
    }
    
    flag = adaptUtil::RelativeDirection(vec[1], vec[2]);
    if(flag==1||flag==-1){
      vec_facesLargeAngle.push_back(crntFace);
      nbr_poor_faces++;
      if(flag==1)
        nbr_small_ang++;
      else
        nbr_large_ang++;

      continue;
    }

    flag = adaptUtil::RelativeDirection(vec[2], vec[0]);
    if(flag==1||flag==-1){
      vec_facesLargeAngle.push_back(crntFace);
      nbr_poor_faces++;
      if(flag==1)
        nbr_small_ang++;
      else
        nbr_large_ang++;

      continue;
    }

    
  } //end while

  /* 3. delete iterator */
  FIter_delete(fiter);
  
  cout<<"[Checking Surface Mesh By Angle]  Number of Poorly Shaped Faces (with angle < 5 or > 175) : "<<nbr_poor_faces<<endl;
  cout<<"[Checking Surface Mesh By Angle]  Number of Poorly Shaped Faces with angle < 5 : "<<nbr_small_ang<<endl;
  cout<<"[Checking Surface Mesh By Angle]  Number of Poorly Shaped Faces with angle > 175 : "<<nbr_large_ang<<endl;
  assert(nbr_poor_faces==vec_facesLargeAngle.size());

}

#ifdef MA_PARALLEL

// check the four corner vertices of a given region to determine if the region is located at part boundary
int CR_isOnPartBdry(pRegion region)
{
  // get the four corner vertices
  pPList rvlist = R_vertices(region, 1);
  int isOnPB = 0;  
  pVertex vert = NULL;
  for(int i = 0; i < 4; i++){
    vert = (pVertex)PList_item(rvlist, i);
    if(EN_duplicate(vert)){
      isOnPB = 1;
      break;
    }
  }
  // delete the PList
  PList_delete(rvlist);
  
  return isOnPB;
}

void CR_migrateBdryRgns(pMesh pmesh, vector<pRegion> rgnVec)
{
  pPList vlist;
  pPList elist;
  pPList flist;
  pPList rlist;

  flist = PList_new();
  elist = PList_new();
  vlist = PList_new();
  rlist = PList_new();
  
  pRegion region;
  
  for(int i=0; i<rgnVec.size(); i++){
    region = rgnVec[i];
    pPList tmplist = R_vertices(region, 1);
    PList_appPListUnique(vlist, tmplist);
    PList_delete(tmplist);
    tmplist = R_edges(region, 1);
    PList_appPListUnique(elist, tmplist);
    PList_delete(tmplist);
    for(int i=0; i<4; i++)
      PList_appUnique(flist, R_face(region, i));
  }
  
  void *temp = 0;
  pVertex v;
  while(v = (pVertex)PList_next(vlist, &temp)) {
    pPList tmpr = V_regions(v);
    PList_appPListUnique(rlist, tmpr);
    PList_delete(tmpr);
  } 

  temp=0;
  pRegion r;
  while(r = (pRegion)PList_next(rlist, &temp)) {
    pPList tmpr = R_vertices(r, 1);
    PList_appPListUnique(vlist, tmpr);
    PList_delete(tmpr);
  }

  temp=0;
  std::list<pVertex> vertVec;
  vertVec.clear();
  while(v = (pVertex)PList_next(vlist, &temp)) {
    if(EN_duplicate(v))
      vertVec.push_back(v);
  }  

  PList_delete(vlist);
  PList_delete(elist);
  PList_delete(flist);
  PList_delete(rlist);

  std::vector<pEntity> newVt;
  std::vector<pEntity> rmVt;
  std::vector<pEntity>::iterator vIt;
  std::vector<pEntity> dummy;
  std::vector<mEntityGroup*> VecRmvEG;
  std::vector<mEntityGroup*> VecNewEG;

  curveMigrateCB crvCB;
  cout<<"vertVec size: "<<vertVec.size()<<endl;
  M_migration(pmesh,0,vertVec,crvCB,0,rmVt,newVt,-1,dummy,dummy,VecRmvEG,VecNewEG);

  return;
}


#endif
// return the face normal NOT pointing to the given region
// (point out of mesh domain if region==0)
void F_normal(pFace face, pRegion rgn, double nor[3])
{
  // get the region if it is NULL
  if( !rgn ) {
    pRegion rgn1;
    rgn=F_region(face,0);
    rgn1=F_region(face,1);
    if( (rgn && rgn1) || (!rgn && !rgn1) )
      printf("WARNING: we have a problem (curveUtil::F_normal)\n");
    if( !rgn )
      rgn=rgn1;
  }

  double xyz[4][3];
  double v01[3], v02[3], v03[3];
  pPList fverts=F_vertices(face,1);
  pVertex vertex;
  void *iter=0;
  int i=0;
  while( vertex=(pVertex)PList_next(fverts,&iter) )
    V_coord(vertex,xyz[i++]);

  vertex=R_fcOpVt(rgn,face);
  V_coord(vertex,xyz[3]);

  diffVt(xyz[1],xyz[0],v01);
  diffVt(xyz[2],xyz[0],v02);
  diffVt(xyz[3],xyz[0],v03);
  crossProd(v01,v02,nor);
  if( dotProd(nor,v03) > 0 ) {
    nor[0]=-1.*nor[0];
    nor[1]=-1.*nor[1];
    nor[2]=-1.*nor[2];
  }

  PList_delete(fverts);
}


void F_bezierSplit(pFace face, pEdge edge, double *ptxyz)
{

  double fxyz[6][3], u, v;
  int i, j, index, nume = F_numEdges(face);
  pVertex vert;
  pPList fvlist = F_vertices(face, 1);
  pEdge e;
  
  // get the vertices
  for(i=0; i<3; i++) {
    vert = (pVertex)PList_item(fvlist, i);
    V_coord(vert, fxyz[i]);
  }
  PList_delete(fvlist);

  // get the edges
  for(j=0; j<nume; j++) {
    e = F_edge(face, j);
    E_bezierCtrlPt(e, fxyz[i++]);
    if(e == edge)
      index = j;
  }

  // based on the index to determine appropriate u, v
  if(index == 0)
    {u = 0.25; v = 0.5;}
  else if(index == 1)
    {u = 0.25; v = 0.25;}
  else if(index == 2)
    {u = 0.5; v = 0.25;}

  F_bezierEval(fxyz, u, v, ptxyz);

  return;
}


int E_isCurved(pEdge edge) 
{
  double tmpxyz[2][3], nv[3], flag;

  if(E_numPoints(edge) == 0)
    return 0;
 
  pPoint pt = E_point(edge, 0);
  tmpxyz[0][0] = P_x(pt);
  tmpxyz[0][1] = P_y(pt);
  tmpxyz[0][2] = P_z(pt);
  
  double vxyz[2][3];
  V_coord(E_vertex(edge, 0), vxyz[0]);
  V_coord(E_vertex(edge, 1), vxyz[1]);
  for(int i=0; i<3; i++)
    tmpxyz[1][i] = 0.5*(vxyz[0][i]+vxyz[1][i]);

  diffVt(tmpxyz[0], tmpxyz[1], nv);
  
  double dist = dotProd(nv, nv);
  double len = adaptUtil::E_lengthSq(edge);
  if((dist/len) < 1.e-3) 
    flag =0;
  else
    flag =1;
  
  return flag;
}


int E_onPlanarFace(pEdge edge)
{
  if(E_whatInType(edge) == 3)
    return 0;
  
  pFace faces[2],f;
  faces[0] = NULL;
  faces[1] = NULL;
  pPList eflist;
  eflist = E_faces(edge);
  int count = 0;
  for(int ll=0; ll<PList_size(eflist); ll++){
    f = (pFace)PList_item(eflist, ll);
    if(F_whatInType(f) == 2)
      faces[count++] = f;
  }
  PList_delete(eflist);
 
  // compute the face normal changes
  double normal1[3], normal2[3];
  if(faces[0])
    F_normal(faces[0], 0, normal1);
  else
    return 0;
  if(faces[1])
    F_normal(faces[1], 0, normal2);
  else
    return 0;
  if(adaptUtil::RelativeDirection(normal1,normal2,165.) != -1)
    return 1;
  
  return 0;
}


void computePtForOppEdge(pEdge oppEdge, pFace *faces, double *xyz)
{
  
  double exyz[4][3];
  double vxyz[4][3], par[3];
  pVertex Vt[4], vv;
  pEdge fe[4];
  int i, j;
  
  Vt[0] = F_opEdgeVert(faces[0], oppEdge);
  Vt[2] = F_opEdgeVert(faces[1], oppEdge);
  
  pPList fvlist = F_vertices(faces[0], 1);
  for(i=0, j=1; i<3; i++) {
    vv = (pVertex)PList_item(fvlist, i);
    if(vv!=Vt[0]){
      Vt[j] = vv;
      j += 2;
    }
  }
  PList_delete(fvlist);
  
  fe[0] = E_exists(Vt[0], Vt[1]);
  fe[1] = E_exists(Vt[1], Vt[2]);
  fe[2] = E_exists(Vt[2], Vt[3]);
  fe[3] = E_exists(Vt[3], Vt[0]);
  
  //collect the coordinates
  for(i=0; i<4; i++) {
    V_coord(Vt[i], vxyz[i]);
    E_eval(fe[i], 0.5, exyz[i], par);
  }
  
  // use blending mapping to compute the xyz;
  for(i=0; i<3; i++) 
    xyz[i] = 0.5*(exyz[0][i] + exyz[1][i] + exyz[2][i] + exyz[3][i])
      - 0.25*(vxyz[0][i] + vxyz[1][i] + vxyz[2][i] + vxyz[3][i]);
  
  return;
}

// Evaluate the split location of a curved edge
void E_eval(pEdge edge, double w, double *vxyz, double *vparam)
{

  double exyz[3][3];
  int i;
  
  for(i=0; i<2; i++)
    V_coord(E_vertex(edge, i), exyz[i]);

  E_bezierCtrlPt(edge, exyz[2]);

  E_XYZeval(exyz, w, vxyz);

  for(i=0; i<3; i++)
    vparam[i] = 0.0;

  return;
  
}

// get the opposite vertex of an edge on the input face
pVertex F_opEdgeVert(pFace face, pEdge edge)
{

  pVertex vert, v;
  int i;
  pPList fvlist = F_vertices(face, 1);

  for(i=0; i<2; i++) {
    vert = E_vertex(edge, i);
    PList_remItem(fvlist, vert);
  }
  
  v = (pVertex)PList_item(fvlist, 0);
  
  PList_delete(fvlist);

  return v;
  
}


void writeRgnDataForMaple(pRegion region, char* name)
{
  FILE* outFile = fopen(name, "w");

  double rxyz[10][3];
  double lxyz[6][3];
  int i,j;
  pPList vlist = R_vertices(region, 1);
  pVertex vert;
  
  for(i=0;i<4;i++){
    vert = (pVertex)PList_item(vlist, i);
    V_coord(vert, rxyz[i]);
  }
  
  PList_delete(vlist);
  
  pPList elist = R_edges(region, 1);
  pEdge e;

  for(j=0; j<6; j++){
    e = (pEdge)PList_item(elist, j);
    E_bezierCtrlPt(e, rxyz[i++]);  // bezier control point
    // lagrange interpolation point
    if(E_numPoints(e)){
      pPoint pt=E_point(e, 0);
      lxyz[j][0]=P_x(pt);
      lxyz[j][1]=P_y(pt);
      lxyz[j][2]=P_z(pt);
    }
    else{
      double coords[2][3];
      for(int i = 0;i <2; i++)
	V_coord(E_vertex(e,i), coords[i]);
      for(int i = 0;i<3;i++){
	lxyz[j][i]=1/2*(coords[0][i]+coords[1][i]);
      }
      
    }
  }
  
  PList_delete(elist);

  // first 10 lines are beizer control points for a quadratic tet
  for(i=0;i<10;i++)
    fprintf(outFile, "%f %f %f\n", rxyz[i][0], rxyz[i][1], rxyz[i][2]);

  // latter 6 lines are the actual interpolation points on each edge
  for(i=0;i<6; i++)
    fprintf(outFile, "%f %f %f\n", lxyz[i][0], lxyz[i][1], lxyz[i][2]);
    
  fclose(outFile);
  
}


  double P_length(double* xyz1, double* xyz2){
    
    return sqrt((xyz1[0]-xyz2[0])*(xyz1[0]-xyz2[0])+(xyz1[1]-xyz2[1])*(xyz1[1]-xyz2[1])+(xyz1[2]-xyz2[2])*(xyz1[2]-xyz2[2]));
    
  }

  double E_length(pEdge edge){
    pVertex v1,v0;
    double xyz[2][3];
    v0=E_vertex(edge, 0);
    v1=E_vertex(edge, 1);
    V_coord(v0, xyz[0]);
    V_coord(v1, xyz[1]);
/*
    if(E_numPoints(edge)){
      pPoint pt = E_point(edge, 0);
      double MidPtCrds[3];
      MidPtCrds[0] = P_x(pt);
      MidPtCrds[1] = P_y(pt);
      MidPtCrds[2] = P_z(pt);
      
      return (P_length(xyz[0], MidPtCrds)+P_length(xyz[1], MidPtCrds));
    }
*/
    return P_length(xyz[0], xyz[1]);
  }
  
  int HO_XYZ_isValid(double (*xyz)[3], crShpInfo *csi, pRegion region) {

    int isValid;
    double shape;
    csi->index = -1;
 
   
    /* check the region's straight-sided shape */
    double tmp_shape = 0.0;
    isValid = XYZ_shapeMeasure(xyz, &tmp_shape);
  
    slacUtil::SU_XYZ_RadiusRatio(xyz, shape);

    csi->qs = shape;  // actual straight-sided shape
   
    

    /* CASE 1: Straight-sided (ST) part is invalid */

    if(!isValid) {
      csi->qc = 0.0;    // init curved shape in the invalid range
      csi->shape = 0.0; // the overall shape is consequently in the invalid range
      //cout<<"Invalid Straight-sided high order region "<<endl;
      return 0;
    }
    

    /* if the ST part is valid, further compute the curved (CR) part */
  
    double tetCtrlPts[3][3][3][3];
    
    double du[2][2][2][3], dv[2][2][2][3], dw[2][2][2][3];
    
    double jac[4][4][4];
    
    int i, j, k, l, m, n, r, s, t, d1, d2, d3, d4, d5, d6;
    int degree = 2;
    double minDetJ = BIG_NUMBER, maxDetJ = -BIG_NUMBER;
    

    for(k=0; k<3; k++) {
      // vertices
      tetCtrlPts[0][0][0][k] = xyz[0][k];
      tetCtrlPts[2][0][0][k] = xyz[1][k];
      tetCtrlPts[0][2][0][k] = xyz[2][k];
      tetCtrlPts[0][0][2][k] = xyz[3][k];
      
      // edges
      tetCtrlPts[1][0][0][k] = xyz[4][k];
      tetCtrlPts[1][1][0][k] = xyz[5][k];
      tetCtrlPts[0][1][0][k] = xyz[6][k];
      tetCtrlPts[0][0][1][k] = xyz[7][k];
      tetCtrlPts[1][0][1][k] = xyz[8][k];
      tetCtrlPts[0][1][1][k] = xyz[9][k];
    }
    
    //calculate the derivatives
    for(i=0; i<degree; i++) {
      for(j=0; j<degree-i; j++) {
	for(k=0; k<degree-i-j; k++) {
	  diffVt(tetCtrlPts[i+1][j][k], tetCtrlPts[i][j][k], du[i][j][k]);
	  diffVt(tetCtrlPts[i][j+1][k], tetCtrlPts[i][j][k], dv[i][j][k]);
	  diffVt(tetCtrlPts[i][j][k+1], tetCtrlPts[i][j][k], dw[i][j][k]);
	}
      }
    }
    
    //clear the jacobian 
    for (i = 0; i < 4; i++) {
      for (j = 0; j < 4-i; j++) {
	for (k = 0; k < 4-i-j; k++) { 
	  jac[i][j][k] = 0.0;
	  //	issues(i,j,k) = 0;
	}
      }
    }
    
    isValid = 1;
    //calculate the box products
    double degree2 = degree * degree * degree, cp[3], detj, coeff;
    
    for (i = 0; i < degree; i++) {
      d1 = degree - i;
      for (j = 0; j < d1; j++) {
	d2 = d1 - j;
	for(k = 0; k < d2; k++){
	  for (l = 0; l < degree; l++) {
	    d3 = degree - l;
	    for (m = 0; m < d3; m++) {
	      d4 = d3 - m;
	      for(n = 0; n < d4; n++){
		for(r = 0; r < degree; r++){
		  d5 = degree - r;
		  for(s = 0; s < d5; s++){
		    d6 = d5 - s;
		    for(t = 0; t< d6; t++){
		      crossProd(du[i][j][k], dv[l][m][n], cp);
		      detj = dotProd(cp, dw[r][s][t]);
		      //    printf("%d %d %d, %d %d %d, %d %d %d\n", i, l, r, j, m, s, k, n, t);
		      jac[i+l+r][j+m+s][k+n+t] += detj * degree2;
		      if((i+l+r) > 3 || (j+m+s) >3 || (k+n+t) > 3)
			printf("Something is wrong: %d %d %d\n", i+l+r, j+m+s, k+n+t);
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    } 
    
    for (i = 0; i < 4; i++) {
      for (j = 0; j < 4-i; j++) {
	for (k = 0; k < 4-i-j; k++) { 
	  coeff = (double)factorial(3*(degree-1))/(double)(factorial(i)*factorial(j)*factorial(k)*factorial(3*(degree-1)-i-j-k));
	  jac[i][j][k] /= coeff;
	  if(jac[i][j][k] <=0.0) {
	    isValid = 0;
	  }

	  minDetJ = MIN(minDetJ, jac[i][j][k]);

	  if( minDetJ == jac[i][j][k] ){	    
	    csi->index1[0] = i;
	    csi->index1[1] = j;
	    csi->index1[2] = k;
	  }
	  
	  maxDetJ = MAX(maxDetJ, jac[i][j][k]);
	}
      }
    }
    // the index is used to help to determine the key entities to apply
    // local mesh modifications
    //if(minDetJ/maxDetJ < 0.9) 
    // cout<<"min Jac["<<xi[0]<<"]["<<xi[1]<<"]["<<xi[2]<<"]"<<endl;
    if(csi->index1[0]==3||csi->index1[1]==3||csi->index1[2]==3||(csi->index1[0]==0&&csi->index1[1]==0&&csi->index1[2]==0))
      {
	csi->isCorner = 1;
	//cout<<"1"<<endl;
      }
    else 
      {
	csi->isCorner = 0;
	//cout<<"2"<<endl;
      }
    if(!isValid) {
      // csi->index = -1;
      // one invalid corner
      if(jac[0][0][0]<= 0.0 && jac[3][0][0] > 0.0 && jac[0][3][0] > 0.0 && jac[0][0][3]> 0.0)
	csi->index = 0;
      else if (jac[0][0][0] > 0.0 && jac[3][0][0] <= 0.0 && jac[0][3][0] > 0.0 && jac[0][0][3]> 0.0)
	csi->index = 1;
      else if (jac[0][0][0] > 0.0 && jac[3][0][0] > 0.0 && jac[0][3][0] <= 0.0 && jac[0][0][3]> 0.0)
	csi->index = 2;
      else if (jac[0][0][0] > 0.0 && jac[3][0][0] > 0.0 && jac[0][3][0] > 0.0 && jac[0][0][3]<= 0.0)
	csi->index = 3;
      else if (jac[0][0][0] <= 0.0 && jac[3][0][0] <= 0.0 && jac[0][3][0] > 0.0 && jac[0][0][3] > 0.0)
	// two invalid corners
	csi->index = 4;
      else if (jac[0][0][0] <= 0.0 && jac[3][0][0] > 0.0 && jac[0][3][0] <= 0.0 && jac[0][0][3] > 0.0)
	csi->index = 5;
      else if (jac[0][0][0] <= 0.0 && jac[3][0][0] > 0.0 && jac[0][3][0] > 0.0 && jac[0][0][3] <= 0.0)
	csi->index = 6;
      else if (jac[0][0][0] > 0.0 && jac[3][0][0] <= 0.0 && jac[0][3][0] <= 0.0 && jac[0][0][3] > 0.0)
	csi->index = 7;
      else if (jac[0][0][0] > 0.0 && jac[3][0][0] <= 0.0 && jac[0][3][0] > 0.0 && jac[0][0][3] <= 0.0)
	csi->index = 8;
      else if (jac[0][0][0] > 0.0 && jac[3][0][0] > 0.0 && jac[0][3][0] <= 0.0 && jac[0][0][3] <= 0.0)
	csi->index = 9;
      /*    else if (jac[0][0][0] > 0.0 && jac[3][0][0] > 0.0 && jac[0][3][0] > 0.0 && jac[0][0][3] > 0.0) {
	    cout<<"invalidity reported at edge control point -- call adaptive check using subdivision"<<endl;
	    int i = csi->index1[0];
	    int j = csi->index1[1];
	    int k = csi->index1[2];
	    if(jac[i][j][k]>0.0){
	    cout<<"Something wrong with the index!!!"<<endl;
	    return 0;
	    }
	    double CtrlPtGroup[6][4];
	    for(int i=0;i<4;i++){
	    CtrlPtGroup[0][i]=jac[0][0][i]; 
	    CtrlPtGroup[1][i]=jac[0][i][0];
	    CtrlPtGroup[2][i]=jac[0][3-i][i];
	    CtrlPtGroup[3][i]=jac[i][0][0];
	    CtrlPtGroup[4][i]=jac[3-i][0][i];
	    CtrlPtGroup[5][i]=jac[3-i][i][0];
	    }
	    int id = 0;
	    if(i!=0)
	    id+=4;
	    if(j!=0)
        id+=2;
      if(k!=0)
        id+=1;
      double tmp[3][3];
      
      vector<double> InVec, OutVec1, OutVec2;

      for(int i=0;i<4;i++){
//        cout<<CtrlPtGroup[id-1][i]<<";    ";
	InVec.push_back(CtrlPtGroup[id-1][i]);
      }
//      cout<<endl;
//      cout<<"      ";
      for(int i=0;i<3;i++){
        tmp[2][i]=(CtrlPtGroup[id-1][i]+CtrlPtGroup[id-1][i+1])/2;
//        cout<<tmp[2][i]<<";    ";
      }
//      cout<<endl;
//      cout<<"            ";
      for(int i=0;i<2;i++){
        tmp[1][i]=(tmp[2][i]+tmp[2][i+1])/2;
//        cout<<tmp[1][i]<<";    ";
      }
//      cout<<endl;
      tmp[0][0]=(tmp[1][0]+tmp[1][1])/2;
//      cout<<"                  "<<tmp[0][0]<<endl;
      double RelInc=1.0;
      while(1){
	int swt = Edge_SubDiv(InVec, OutVec1, OutVec2, RelInc);
	if(OutVec1[0]<=0||OutVec1[3]<=0||OutVec2[0]<=0||OutVec2[3]<=0){
#ifdef DEBUG
	  cout<<"Found Neg DetJ at interpolation points"<<endl;
#endif
	  csi->index=99;
	  writeOutCorner(region, NULL, "testInvalid.sms");
	  break;
	}
	if(RelInc<=0.1)
	  break;
	else{
	  if(swt==0)
	    break;
	  else if(swt==1){
	    InVec.clear();
	    InVec = OutVec1;
	  }
	  else if(swt==2){
	    InVec.clear();
	    InVec = OutVec2;
	    
	  }
	  else{
	    throw new mException(__LINE__,__FILE__,"Undined swt index"); 
	  }
	}
        int iAllPosit = 1;
        for(int i=0;i<4;i++){
  	  if(InVec[i]<=0)
            iAllPosit = 0;
	}
        if(iAllPosit)
          break;  
      }
      // cout<<endl;
//       for(int i=0;i<4;i++)
// 	cout<<OutVec1[i]<<";    ";
//       double MinOutVec1 = *(std::min_element(OutVec1.begin(), OutVec1.end()));
//       cout<<endl<<"Min: "<<MinOutVec1;
//       cout<<endl;
//       for(int i=0;i<4;i++)
// 	cout<<OutVec2[i]<<";    ";
//       double MinOutVec2 = *(std::min_element(OutVec2.begin(), OutVec2.end()));
//       cout<<endl<<"Min: "<<MinOutVec2;
//       double MinCtrlPt = MIN(MinOutVec1, MinOutVec2);
//       cout<<endl<<"New lower bound after subdivision: "<<MinCtrlPt<<endl;
//       cout<<endl;
      if(tmp[2][0]>0&&tmp[1][0]>0&&tmp[0][0]>0&&tmp[1][1]>0&&tmp[2][2]>0)
        isValid=1;

    }*/
      else {
	csi->index = 10; 
      }
    } 
    
    //if(isValid==1&&minDetJ<=0)
    //  minDetJ = 0.0-minDetJ;
    shape =  minDetJ / maxDetJ;
    
    if(fabs(fabs(shape) - 1.) < 1.e-3) {
      // treat as a straight-sided region
      csi->qc = 1.0;
    }
    else{
      csi->qc = shape;
    }
    csi->shape = csi->qs*csi->qc;
    //csi->shape = shape;
    
    return isValid;
    
  }
  

  int CR_isValid(pRegion region, crShpInfo *csi)
  {
    
    pPList elist = R_edges(region, 1);
    pEdge e;
    int i, j;
    int iIsHighOrder = 0 ;// assume linear to start with;
    int flag = 0;
    for(j=0;j<6;j++){
      e = (pEdge)PList_item(elist, j);
      if(E_numPoints(e))//non-zero  ->  higher order
      {
 	iIsHighOrder = 1;
	break;
      }
    }// end of for


    /* linear (straight-sided) tet */

    if(!iIsHighOrder){ 
      PList_delete(elist);
      double xyz[10][3];
      R_coord(region, xyz);
      double shape;
      flag = XYZ_shapeMeasure(xyz, &shape);

      slacUtil::SU_XYZ_RadiusRatio(xyz, shape);      

      csi->index = -2;
  
      csi->qs = shape;
 
      if(flag){
       
	csi->qc = 1.0;
	csi->shape= csi->qs * csi->qc;
        return 1;
      }
      else {
#ifdef DEBUG
	cout<<"Invalid Linear Region "<<endl;
#endif
	csi->qc = 0.0;
	csi->shape = csi->qs * csi->qc;
        return 0;
      }

    } // end of if
    
    /* High-order region */

    double rxyz[10][3];

    pPList vlist = R_vertices(region, 1);
    pVertex vert;

    for(i=0;i<4;i++){
      vert = (pVertex)PList_item(vlist, i);
      V_coord(vert, rxyz[i]);
    }

    PList_delete(vlist);

    for(j=0; j<6; j++){
      e = (pEdge)PList_item(elist, j);
      E_bezierCtrlPt(e, rxyz[i++]);
    }

    PList_delete(elist);

    return HO_XYZ_isValid(rxyz, csi, region);
  }
 
  // This function allocates memory for the point 
  pPoint extractPt(pMesh msh, pFace mf, pEdge edge, double u, double v)
  {
    double xyz[3];
    double fxyz[6][3];
    double exyz[3][3];
    pPoint pt;
    
    F_bezierXYZ(mf, fxyz);
    
    pt = P_new();
   
    F_bezierEval(fxyz, v, 1.-u-v, xyz);
    P_setPos(pt, xyz[0], xyz[1], xyz[2]);

    return pt;
  }

  // This function allocates memory for the point 
  pPoint extractPt(pMesh msh, pEdge me, double u)
  {
    double xyz[3];
    double exyz[3][3];
    pPoint pt;
    
    for(int i=0; i<2; i++)
      V_coord(E_vertex(me, i), exyz[i]);
    E_bezierCtrlPt(me, exyz[2]);
    E_XYZeval(exyz, u, xyz);
    
    
    pt = P_new();
    P_setPos(pt, xyz[0], xyz[1], xyz[2]);

    return pt;
  }

  // get the middle point location for the interior new edge when
  // split an edge of a curved bezier face
  void F_bezierXYZ(pFace face, double (*fxyz)[3])
  {
    int i, j, nume = F_numEdges(face);;
    pPList fvlist = F_vertices(face, 1);
    pVertex vert;
    // get the vertices
    for(i=0; i<3; i++) {
      vert = (pVertex)PList_item(fvlist, i);
      V_coord(vert, fxyz[i]);
    }
    PList_delete(fvlist);
    
    // get the edges
    pEdge e;
    for(j=0; j<nume; j++) {
      e = F_edge(face, j);
      E_bezierCtrlPt(e, fxyz[i++]);
    }
    
    return;
  }
  
  //
  // evaluate a curved face point based on the input u, v
  //
  void F_bezierEval(double (*fxyz)[3], double u, double v, double *ptxyz)
  {
    double t[6], w = 1.-u-v;
    int i, j;
    
    t[0] = w*w;
    t[1] = u*u;
    t[2] = v*v;
    t[3] = 2.*u*w;
    t[4] = 2.*u*v;
    t[5] = 2.*v*w;
    
    for(i=0; i<3; i++)
      ptxyz[i] = 0.0;
    
    for(i=0; i<6; i++) 
      for(j=0; j<3; j++)
	ptxyz[j] += t[i]*fxyz[i][j];
    
    return;
    
    
  }
  
  // Compute the Bezier control points of the edges
  void E_bezierCtrlPt(pEdge edge, double *bexyz)
  {
    
    double  vxyz[2][3], lpxyz[3];
    int numPts, i;
    pPoint pt;
    pMeshDataId midPt;
    void *temp;
    
    numPts = E_numPoints(edge);
    
    V_coord(E_vertex(edge, 0), vxyz[0]);
    V_coord(E_vertex(edge, 1), vxyz[1]);
    
    if(numPts){
      pt = E_point(edge, 0);
      lpxyz[0] = P_x(pt);
      lpxyz[1] = P_y(pt);
      lpxyz[2] = P_z(pt);
    }else {
      
      // The mesh edge has been attached middle pt info
      midPt = MD_lookupMeshDataId("midpt");
      if(midPt && EN_getDataPtr((pEdge)edge, midPt, &temp)) {
	for(i=0; i<3; i++)
	  lpxyz[i] = ((double*)temp)[i];
	
      }else {
	
	// The mesh edge does not have middle pt info
	for(i=0; i<3; i++)
	  lpxyz[i] = 0.5*(vxyz[0][i] + vxyz[1][i]);
      }
      
    }
    
    // Bezier control points
    E_XYZ_bezierCtrlPt(vxyz[0], vxyz[1], lpxyz, bexyz);
    
    return;
  }
  
   //Bezier curving     lpxyz: middle point of Lagrange interpolation. May 26, 2009
  void E_XYZ_bezierCtrlPt(double *vxyz0, double *vxyz1, double *lpxyz, double *bexyz)
  {
    int i;
    for(i=0; i<3; i++)
      bexyz[i] = 2.*lpxyz[i] - 0.5*(vxyz0[i] + vxyz1[i]);
    
    return;
  }
  
  // Bezier split
  void E_XYZeval(double (*exyz)[3], double w, double *ptxyz)
  {
    
    double t1, t2, t3;
    int i;
    
    t1 = (1.-w)*(1.-w);
    t2 = 2.*w*(1.-w);
    t3 = w*w;
    
    for(i=0; i<3; i++)
      ptxyz[i] = exyz[0][i]*t1 + exyz[2][i]*t2 + exyz[1][i]*t3;
    
    return;
  }
  

  // PList to STD Vectors
  void Rgn_vtxs(pRegion region, int order, vector<pVertex> &VtxVec)
  {
    pPList VtxPList = R_vertices(region, order);
    int Iter;
    for(Iter=0; Iter<PList_size(VtxPList); Iter++){
      pVertex Vtx = (pVertex)PList_item(VtxPList, Iter);
      VtxVec.push_back(Vtx);
    }
    PList_delete(VtxPList);
    if(VtxVec.size()!=4){
      cout<<"Error: Vertex Vector size is not equal to 4"<<endl;
      exit(1);
    }

  }
  
  void Rgn_edges(pRegion region, int order, vector<pVertex> &EdgeVec)
  {
    pPList EdgePList = R_edges(region, order);
    int Iter;
    for(Iter=0; Iter<PList_size(EdgePList); Iter++){
      pEdge Edge = (pEdge)PList_item(EdgePList, Iter);
      EdgeVec.push_back(Edge);
    }
    PList_delete(EdgePList);
    if(EdgeVec.size()!=6){
      cout<<"Error: Edge Vector size is not equal to 6"<<endl;
      exit(1);
    }

  }

  int Edge_SubDiv(vector<double> InVec, vector<double> &OutVec1, vector<double> &OutVec2, double &RelInc){
     if(InVec.size()!=4){
       cout<<"Size of Input Vector: "<<InVec.size()<<endl;
       throw new mException(__LINE__,__FILE__,"Currently only support SubDiv of 3rd-order Bezier Rep ( 4 control points )");  
     }
     double CtrlPt4[]={0.0, 0.0, 0.0, 0.0};
     double CtrlPt3[]={0.0, 0.0, 0.0,};
     double CtrlPt2[]={0.0, 0.0};
     double CtrlPt1[]={0.0};

     for(int i=0; i<4; i++){
       CtrlPt4[i] = InVec[i];
     }
     
     for(int i=0; i<3; i++)
       CtrlPt3[i] = (CtrlPt4[i]+CtrlPt4[i+1])/2;

     for(int i=0; i<2; i++)
       CtrlPt2[i] = (CtrlPt3[i]+CtrlPt3[i+1])/2;

     CtrlPt1[0] = (CtrlPt2[0]+CtrlPt2[1])/2;

     if(OutVec1.size())
       OutVec1.clear();

     OutVec1.push_back(CtrlPt4[0]);
     OutVec1.push_back(CtrlPt3[0]);
     OutVec1.push_back(CtrlPt2[0]);
     OutVec1.push_back(CtrlPt1[0]);
    
     if(OutVec2.size())
       OutVec2.clear();

     OutVec2.push_back(CtrlPt4[3]);    
     OutVec2.push_back(CtrlPt3[2]);    
     OutVec2.push_back(CtrlPt2[1]);    
     OutVec2.push_back(CtrlPt1[0]); 

     for(int i=0;i<4;i++)
	cout<<OutVec1[i]<<";    ";
     double MinOutVec1 = *(std::min_element(OutVec1.begin(), OutVec1.end()));
     cout<<endl<<"Min: "<<MinOutVec1;
     cout<<endl;
     for(int i=0;i<4;i++)
       cout<<OutVec2[i]<<";    ";
     double MinOutVec2 = *(std::min_element(OutVec2.begin(), OutVec2.end()));
     cout<<endl<<"Min: "<<MinOutVec2;
     double NewMinCtrlPt = MIN(MinOutVec1, MinOutVec2);
     double OldMinCtrlPt = *(std::min_element(InVec.begin(), InVec.end()));
     cout<<endl<<"Old lower bound after subdivision: "<<OldMinCtrlPt;
     cout<<endl<<"New lower bound after subdivision: "<<NewMinCtrlPt;
     RelInc = fabs((NewMinCtrlPt-OldMinCtrlPt)/OldMinCtrlPt);
     cout<<endl<<"Relative Increment: "<<RelInc<<endl<<endl;
     if(MinOutVec1<MinOutVec2)
       return 1;
     if(MinOutVec1>MinOutVec2)
       return 2;
     return 0;
  }

}// end of curveUtil

