#ifndef MESHADAPT_CURVEUTIL_H_
#define MESHADAPT_CURVEUTIL_H_

#include "mMesh.h"
#include "mFMDB.h"
#include "FMDB_Internals.h"
#include "FMDB.h"
#include "FMDB_cint.h"
#include "mException.h"
#include "curveMesh.h"
#include "AdaptTypes.h"
#include "MeshTools.h"
#include "scorecSSList.h"
#include "PList.h"
#include "pmZoltanCallbacks.h"
#include <iostream>
#include <vector>
#include <string>

/* #ifdef AOMD_ */
/* #include "AOMD_cint.h" */
/* #endif */

#define UPPERLENSQBOUND 2.25
#define LOWERLENSQBOUND 0.25

#define SNAP_UPPERLENSQBOUND 2.25
#define SNAP_LOWERLENSQBOUND 0.25

#define QUALITYTHRESHOLD 0.027
#define FACE_QUALITYTHRESHOLD 0.04

#define QUALITYFRACTION 0.001
#define SNAP_QUALITYFRACTION 0.001

#define THICKNESSGRADEFACTORAROUNDGC 0.2
#define THICKNESSGRADEFACTORONGC 1.5

#ifdef SIM
#include "ModelTypes.h"
#endif

using std::vector; 
using std::list;
//using namespace AOMD;

int factorial(int num);

#ifdef MA_PARALLEL

class curveMigrateCB: public zoltanCB
{
public :
  curveMigrateCB():zoltanCB(){}

  virtual void * getUserData(mEntity *ent, int dest_proc, int &size)
  {
    /*
    Data's are packed like this
    -) p[0], p[1], p[2], where p[i] is coordinate of vertex
   */
//  cout<<"("<<M_Pid()<<") getUserData()\n";

  size = 7*sizeof(double);
  char *mybuffer = (char*) malloc (size);
  double *dbuf = (double*)malloc(7*sizeof(double));
  
  // not an edge
  if (M_GetElementType(ent)!=EDGE)
  {
  //  cout<<"("<<M_Pid()<<") not an edge()\n";
    dbuf[0]=1985.0807;
    memcpy(&mybuffer[0], dbuf, 7*sizeof(double));
    free(dbuf);
    return mybuffer;
  }
  //cout<<"is an edge"<<endl;
  // linear edge
  if(E_numPoints((pEdge)ent)==0)
  {
    dbuf[0]=1985.0807;
    memcpy(&mybuffer[0],dbuf, 7*sizeof(double));
    free(dbuf);
    return mybuffer;
  }

  // curved edges

  // XYZ coordinates of the HON
 
  pPoint pt = E_point((pEdge)ent,0);
  dbuf[0]=1982.1104;
  dbuf[1]=P_x(pt);
  dbuf[2]=P_y(pt);
  dbuf[3]=P_z(pt);
  
  // Param coordinates of the HON
  int temp_param3 = 0;
  if(E_whatInType((pEdge)ent)==1)
    dbuf[4] = P_param1(pt);
  if(E_whatInType((pEdge)ent)==2)
    P_param2(pt, &dbuf[4], &dbuf[5], &temp_param3); 

  //cout<<"("<<M_Pid()<<") send "<<ent->getUid()<<": "<<dbuf[0]<<","<<dbuf[1]<<","<<dbuf[2]<<","<<dbuf[3]<<endl;
  memcpy(&mybuffer[0], dbuf,7*sizeof(double));
  free(dbuf);
  return mybuffer;
  }

virtual void recieveUserData (mEntity *ent, int pid, int tag, void *buf)
{
  //cout<<"("<<M_Pid()<<") receiving user data()"<<endl;
  if(M_GetElementType(ent)!=EDGE)
    return;
  
  //if(E_numPoints((pEdge)ent))
  //  return;

  char *mybuffer = (char*) buf;
 
  double *dbuf = (double*)malloc(7*sizeof(double));
  memcpy(dbuf,&mybuffer[0], 7*sizeof(double));
  double p[7];
  int k=0;
  for (;k<7;k++)
    p[k]=dbuf[k];

  free(dbuf);

  // set XYZ coordinates
  if(p[0]==1985.0807)
    return;
  pPoint pt = P_new();
  P_setPos(pt, p[1], p[2], p[3]);
  E_setPoint((pEdge)ent, pt);
  //cout<<"("<<M_Pid()<<") receive "<<ent->getUid()<<": "<<p[0]<<","<<p[1]<<","<<p[2]<<","<<p[3]<<endl;

  // set Param coordinates

  FMDB_P_setParametricPos(pt, p[4], p[5], 0);

}

 virtual void deleteUserData (void *buf)
  {
    free(buf);
  }
  bool useWeights() const {return false;}
  float getWeight (mEntity *) const {return 1.0;}
};

#endif

typedef struct CurvedRegionShapeInfo crShpInfo;

namespace curveUtil {

  int R_numEdgesOnGeomRegn(pRegion pTheRgn);

  int R_numEdgesOnGeomFace(pRegion pTheRgn);

  int R_numEdgesOnGeomEdge(pRegion pTheRgn);

  int R_numFacesOnGeomRegn(pRegion pTheRgn);

  int R_numFacesOnGeomFace(pRegion pTheRgn);

  void M_checkSurfaceMeshByAngle(pMesh pmesh, vector<pFace> &vec_facesLargeAngle);

#ifdef MA_PARALLEL
  int CR_isOnPartBdry(pRegion region);
  void CR_migrateBdryRgns(pMesh pmesh, vector<pRegion> rgnVec);
#endif


  void F_normal(pFace face, pRegion region, double nor[3]);
  int E_onPlanarFace(pEdge);
  void F_bezierSplit(pFace face, pEdge edge, double *ptxyz);
  int E_isCurved(pEdge edge);
  // Bezier edge evaluation 
  void E_eval(pEdge edge, double w, double *vxyz, double *vparam);
  pVertex F_opEdgeVert(pFace face, pEdge edge);
  void computePtForOppEdge(pEdge oppEdge, pFace *faces, double *xyz);
   
  void writeRgnDataForMaple(pRegion, char*);
  // edge subdivision algorithm for a vector of edge control points
  int Edge_SubDiv(vector<double>, vector<double> &, vector<double> &, double &);
  // compute edge length, treat as straigh edge
  double E_length(pEdge);
  double P_length(double*, double*);
  // routines for shape quality evaluations
  int HO_XYZ_isValid(double (*)[3], crShpInfo*, pRegion region=NULL);
  int CR_isValid(pRegion, crShpInfo*); 
  pPoint extractPt(pMesh msh, pFace mf, pEdge edge, double u, double v);// for face
  pPoint extractPt(pMesh msh, pEdge me, double u);// for edge
  void F_bezierXYZ(pFace face, double (*fxyz)[3]);
  // evaluate a curved face point based on the input u, v
  void F_bezierEval(double (*fxyz)[3], double u, double v, double *ptxyz);
  // Compute the Bezier control points of the edges
  void E_bezierCtrlPt(pEdge edge, double *bexyz);
  //Bezier curving     lpxyz: middle point of Lagrange interpolation. May 26, 2009
  void E_XYZ_bezierCtrlPt(double *vxyz0, double *vxyz1, double *lpxyz, double *bexyz);
  // Bezier split
  void E_XYZeval(double (*exyz)[3], double w, double *ptxyz);

  // PList to STD Vectors
  void Rgn_vtxs(pRegion region, int order, vector<pVertex> &VtxVec);
  void Rgn_edges(pRegion region, int order, vector<pVertex> &EdgeVec);
}

#endif //MESHADAPT_CURVEUTIL_H_

