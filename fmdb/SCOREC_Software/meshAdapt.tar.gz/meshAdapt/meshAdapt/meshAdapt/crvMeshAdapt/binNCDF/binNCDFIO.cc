/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/

/*<i> ****************************************************************************
 *
 *  FMDB/src/mNCDF.cc
 *  Created by xiaojaun luo, on Fri Oct 13 2006, 10:40:37 EDT
 *
 *  File Content: function definition for NCDF mesh loading
 *
 *************************************************************************** </i>*/

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <vector>
#include <string>
#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mNodeElm.h"
#include "mException.h"
#include "mFMDB.h"
#include "MeshEntTools.h"
#include "mVertex.h"
#include "slacUtil.h"

namespace slacUtil{

#ifdef NCDF

#include "netcdf.h"

using std::cout;
using std::ofstream;
using std::ifstream;
using std::ostream;
using std::istream;
using std::endl;
using std::vector;
using SCOREC::Util::mPoint;
//using namespace AOMD;
using namespace slacUtil;

#define NDIMS 2 /* 2D Data */
#define ERRCODE 2
#define ERR(e) {printf("Error: %s\n", nc_strerror(e)); exit(ERRCODE);}

// **********************************************************
void importNCDFBin(char *fName, pMesh theMesh, int mid_flag)
// **********************************************************
{

  double xyz[3], par[3]={0., 0.};
  
  pVertex rgn_vert[4], ed_vert[2], fc_vert[3];
  int i, j, num[4], size[4];
  int gentid, vtid[4], tagid[4], conn[4] = {0, 1, 2, 3};
  pRegion region;
  pMeshDataId fbc = MD_newMeshDataId("bcf");
  int fcid[4][3] = {{0, 2, 1},
		    {0, 3, 2},
		    {0, 1, 3},
		    {1, 2, 3}};
  pGEntity gent;
  
  inputNodeElm *inp = new inputNodeElm(theMesh, 3);


  /* **************************************************** */
  /* Code block that reads in data using NetCDF APIs      */
  /* **************************************************** */

  int ncid, varid, dimid[2], retval;
  size_t dimlengthp[2];
  /* Open file */
  if ((retval = nc_open(fName, NC_NOWRITE, &ncid)))
    ERR(retval);

  /* Get the DIM IDs of "tetinterior" and "tetinteriorsize" */
  if ((retval = nc_inq_dimid(ncid, "tetinterior", &dimid[0])))
    ERR(retval);
  if ((retval = nc_inq_dimid(ncid, "tetinteriorsize", &dimid[1])))
    ERR(retval);
  /* Get the length of the DIMs */
  if ((retval = nc_inq_dimlen(ncid, dimid[0], &dimlengthp[0])))
    ERR(retval);
  if ((retval = nc_inq_dimlen(ncid, dimid[1], &dimlengthp[1])))
    ERR(retval);
  /* Get the varid of the data variable, based on its name. */
  if ((retval = nc_inq_varid(ncid, "tetrahedron_interior", &varid)))
    ERR(retval);
  
  /* allocate memory for interior tet data */
  int *tet_interior = new int[dimlengthp[0]*dimlengthp[1]];
  
  /* Read the data. */
  if ((retval = nc_get_var_int(ncid, varid, &tet_interior[0])))
    ERR(retval);
 
  num[0] = dimlengthp[0];
  size[0] = dimlengthp[1];

  /* -----------------------------------------------------*/
  
  /* Get the DIM IDs of "tetexterior" and "tetexteriorsize" */
  if ((retval = nc_inq_dimid(ncid, "tetexterior", &dimid[0])))
    ERR(retval);
  if ((retval = nc_inq_dimid(ncid, "tetexteriorsize", &dimid[1])))
    ERR(retval);
  /* Get the length of the DIMs */
  if ((retval = nc_inq_dimlen(ncid, dimid[0], &dimlengthp[0])))
    ERR(retval);
  if ((retval = nc_inq_dimlen(ncid, dimid[1], &dimlengthp[1])))
    ERR(retval);
  /* Get the varid of the data variable, based on its name. */
  if ((retval = nc_inq_varid(ncid, "tetrahedron_exterior", &varid)))
    ERR(retval);
 
  /* allocate memory for exterior tet data */
  int *tet_exterior = new int[dimlengthp[0]*dimlengthp[1]];
  
  /* Read the data. */
  if ((retval = nc_get_var_int(ncid, varid, &tet_exterior[0])))
    ERR(retval);
 
  num[1] = dimlengthp[0];
  size[1] = dimlengthp[1];

  /* -----------------------------------------------------*/

   /* Get the DIM IDs of "ncoords" and "coord_size" */
  if ((retval = nc_inq_dimid(ncid, "ncoords", &dimid[0])))
    ERR(retval);
  if ((retval = nc_inq_dimid(ncid, "coord_size", &dimid[1])))
    ERR(retval);
  /* Get the length of the DIMs */
  if ((retval = nc_inq_dimlen(ncid, dimid[0], &dimlengthp[0])))
    ERR(retval);
  if ((retval = nc_inq_dimlen(ncid, dimid[1], &dimlengthp[1])))
    ERR(retval);
  /* Get the varid of the data variable, based on its name. */
  if ((retval = nc_inq_varid(ncid, "coords", &varid)))
    ERR(retval);

  double *data_coords=new double[dimlengthp[0]*dimlengthp[1]];
  /* Read the data. */
  if ((retval = nc_get_var_double(ncid, varid, &data_coords[0])))
    ERR(retval);

  /* Create vertices and Assemble to "verts" */

  pVertex *verts = new pVertex[dimlengthp[0]];
  num[2] = dimlengthp[0];
  size[2] = dimlengthp[1];
  for(int i=0; i<dimlengthp[0]; i++){
    double xyz[3];
    for(int j=0; j<dimlengthp[1]; j++)
      xyz[j] = data_coords[i*dimlengthp[1]+j];
    //cout<<xyz[0]<<" "<<xyz[1]<<" "<<xyz[2]<<endl;
    pGEntity gent = theMesh->getGEntity(1,3);
    verts[i] = M_createVP2(theMesh, xyz, par, i+1, gent);
    
  }
  
  /* -----------------------------------------------------*/

   /* Get the DIM IDs of "nsurface_midpoint" and "surface_midpoint_size" */
  if ((retval = nc_inq_dimid(ncid, "nsurface_midpoint", &dimid[0])))
    ERR(retval);
  if ((retval = nc_inq_dimid(ncid, "surface_midpoint_size", &dimid[1])))
    ERR(retval);
  /* Get the length of the DIMs */
  if ((retval = nc_inq_dimlen(ncid, dimid[0], &dimlengthp[0])))
    ERR(retval);
  if ((retval = nc_inq_dimlen(ncid, dimid[1], &dimlengthp[1])))
    ERR(retval);
  /* Get the varid of the data variable, based on its name. */
  if ((retval = nc_inq_varid(ncid, "surface_midpoint", &varid)))
    ERR(retval);
  double *data_surf_midpts=new double[dimlengthp[0]*dimlengthp[1]];
  /* Read the data. */
  if ((retval = nc_get_var_double(ncid, varid, &data_surf_midpts[0])))
    ERR(retval);
  /* Create vertices and Assemble to "verts" */
  double *surf_midpoints = new double[dimlengthp[0]*(dimlengthp[1]-2)];
  int *surf_midpt_vt = new int[dimlengthp[0]*2];
  num[3]=dimlengthp[0];
  size[3]=dimlengthp[1];
  for(int i=0; i<dimlengthp[0]; i++){
    for(int j=0; j<2; j++){
      surf_midpt_vt[i*2+j]=(int)data_surf_midpts[i*size[3]+j];
    }
    for(int k=0; k<dimlengthp[1]-2; k++){
      surf_midpoints[i*(dimlengthp[1]-2)+k]=data_surf_midpts[i*size[3]+k+2];
    }
  }

  // ******************************************************
  // ********  create the interior tet region
  // ******************************************************
  pPList negR = PList_new();
  double vol;
  pEntity ent;
  double tmpvxyz[2][3];

  for(i=0; i<num[0]; i++){
  
    gentid = tet_interior[i*size[0]];
    
    for(j=1; j<size[0]; j++) {
      vtid[j-1] = tet_interior[i*size[0]+j];
      rgn_vert[j-1] = verts[vtid[j-1]];
    }
    
   
    SCOREC::Util::mVector v12 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[1])->point());
    SCOREC::Util::mVector v13 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[2])->point());
    SCOREC::Util::mVector v14 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[3])->point());

    vol =  -(1./6.) * ((v12 % v13) * v14);
    
    // if(gentid != 1)
//       printf("The gentid of the exterior tet %d is not equal to 1", i);

    

    gent = theMesh->getGEntity(gentid,3);
    ent = inp->addElement(rgn_vert, 3, TET, VERTEX, gent);
    
    if(vol < 0.0)
      PList_appUnique(negR, ent);
    
  }
  int numNegR = PList_size(negR);

  cout<<"The total number of interior regions with negative volume: "<<PList_size(negR)<<endl;
 
  
  // ******************************************************
  // ********  create the extrior tet region
  // ******************************************************

  for(i=0; i<num[1]; i++){
  
    gentid = tet_exterior[i*size[1]];

    for(j=1; j<5; j++) {
      vtid[j-1] = tet_exterior[i*size[1]+j];
      rgn_vert[j-1] = verts[vtid[j-1]];

      tagid[j-1] = tet_exterior[i*size[1]+j+4];
    }

    SCOREC::Util::mVector v12 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[1])->point());
    SCOREC::Util::mVector v13 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[2])->point());
    SCOREC::Util::mVector v14 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[3])->point());

    vol =  -(1./6.) * ((v12 % v13) * v14);
    
    // if(gentid != 1)
//       printf("The gentid of the exterior tet %d is not equal to 1", i);
    
    
    gent = theMesh->getGEntity(gentid,3);
    ent = inp->addElement(rgn_vert, 3, TET, VERTEX, gent);
    
    if(vol < 0.0)
      PList_appUnique(negR, ent);
    
    
    // attach the bcs to the boundary faces
    int temp;
    for(j=0; j<4; j++) {
      if(tagid[j] != -1) {
	fc_vert[0] = rgn_vert[fcid[j][0]];
        FMDB_P_setParametricPos(V_point(fc_vert[0]), 0.0, 0.0, 0.0); 
	fc_vert[1] = rgn_vert[fcid[j][1]];
	FMDB_P_setParametricPos(V_point(fc_vert[1]), 0.0, 0.0, 0.0); 
	fc_vert[2] = rgn_vert[fcid[j][2]];
	FMDB_P_setParametricPos(V_point(fc_vert[2]), 0.0, 0.0, 0.0); 

	pFace face = F_exist(0, fc_vert[0], fc_vert[1], fc_vert[2], 0);
	if(!face) {
	  cout<<"face does not exist ----"<<endl;
	}
	else {
	  if(!EN_getDataInt((pEntity)face, fbc, &temp))
	    EN_attachDataInt((pEntity)face, fbc, tagid[j]);
	  else {
	    if(temp == tagid[j])
	      cout<<"The attached id are same-----"<<endl;
	    else
	      cout<<"The attached id are different-----"<<endl;
	  }
	}
	  
      }
    }
    

  }

  cout<<"The total number of exterior regions with negative volume: "<<PList_size(negR)-numNegR<<endl;
 
  //******************************************************
  // ********  output the mesh information
  // ******************************************************
  
  printf ("\n\t Vertices =%d", M_numVertices (theMesh));
  printf ("\n\t Edges    =%d", M_numEdges (theMesh));
  printf ("\n\t Faces    =%d", M_numFaces (theMesh));
  printf ("\n\t Regions  =%d", M_numRegions (theMesh));


  //******************************************************
  //******* analyze the boundary condition
  //******************************************************
  FIter fiter = M_faceIter(theMesh);
  pFace face, ef;
  pEdge edge;

  pPList gflist = PList_new();
  int attid;
  while(face = FIter_next(fiter)) {
    if(EN_getDataInt((pEntity)face, fbc, &attid)) {
      gent = theMesh->getGEntity(attid,2);
      // set up the face classification
      face->classify(gent);
      PList_appUnique(gflist, gent);
    }
  }

  FIter_reset(fiter);
  while(face = FIter_next(fiter)) {
    int f_num_r = F_numRegions(face);
    // face has one connected region
    if(f_num_r == 1) {
      if(F_whatInType(face) == 3)
	cout<<"The face connected to one mesh region does not attach the BC"<<endl;
    }
    // face has two connected region
    else if(f_num_r == 2) {
      int ok[2];
      ok[0] = GEN_tag((pGEntity)R_whatIn(F_region(face, 0)));
      ok[1] = GEN_tag((pGEntity)R_whatIn(F_region(face, 1)));

      // face is shared by two model regions
      if(ok[0] != ok[1]) {
	if(F_whatInType(face) == 3)
	 { 
	   //cout<<"The face connected to two material mesh regions does not attach the BC"<<endl;
	 }
      }
    }
  }
  FIter_delete(fiter);


  // get all of the edges on the gedges;
  void *temp_ptr, *ptr;
  pPList f_bc_eds;
  int geid = 1;
  int gvid = 1;
  int ecount, ve, vsize, ok, f_count, numef;
  pVertex vv, startv, vt;
  pEdge e;
  pGEdge ge;
  pGVertex gv[2];
  temp_ptr = 0;
  pGEntity gfent;
  cout<<endl;  

  cout<<"gfent id is : ";
  for(int k=0; k<PList_size(gflist); k++) {
    gfent = (pGEntity)PList_item(gflist, k);
    // gent =  theMesh->getGEntity(attid,2);
    cout<<GEN_tag(gfent)<<" ";
    f_bc_eds = PList_new();
    
    // get the mesh edges that possible on gface
    fiter = M_classifiedFaceIter(theMesh, gfent, 0);
    while(face = FIter_next(fiter)) {
      for(i=0; i<3; i++) {
	edge = F_edge(face, i);
	f_count = 0;
	numef = E_numFaces(edge);
	for(j=0; j<numef; j++) {
	  ef = E_face(edge, j);
	  if(F_whatIn(ef) == gfent)
	    f_count++;
	}
	if(f_count == 1){
	  if(E_whatInType(edge) != 1)
	    PList_appUnique(f_bc_eds, edge);
	}
	else
	  edge->classify(gfent);
      }
    }
    FIter_delete(fiter);

    if(PList_size(f_bc_eds)) {
      // process the edges to set up the correct gv and ge classification
      pPList endvlist = PList_new();
      ptr = 0;
    
      // find the vertices that only have one edge in the list
      while(edge = (pEdge)PList_next(f_bc_eds, &ptr)) {
	for(i=0; i<2; i++) {
	  pVertex vt = E_vertex(edge, i);
	  ecount =0;
	  ve = V_numEdges(vt);
	  
	  for(j=0; j<ve; j++) {
	    pEdge ee = V_edge(vt, j);
	    if(PList_inList(f_bc_eds, ee))
	      ecount++;
	  }

	  if(ecount == 1)
	    PList_appUnique(endvlist, vt);	  
	}
      }
      ptr = 0;
      while(vv = (pVertex)PList_next(endvlist, &ptr)) {
	if(V_whatInType(vv) != 0) {
	  gent = theMesh->getGEntity(gvid++,0);
	  vv->classify(gent);
	}
	else
	  cout<<"vertex already has been set up with the gv"<<endl;
      }
      
      vsize = PList_size(endvlist);
      if(vsize%2 != 0)
	cout<<"the gv size is not in pair"<<endl;

      while(PList_size(endvlist)) {
	
	vt = (pVertex)PList_item(endvlist, 0);
	PList_remItem(endvlist, vt);
	gent = theMesh->getGEntity(geid++,1);

	ok = 1;
	while(ok) {
	  
	  ve = V_numEdges(vt);
	  for(j=0; j<ve; j++) {
	    e = V_edge(vt, j);
	    if(PList_inList(f_bc_eds, e)){
	      PList_remItem(f_bc_eds, e);
	      e->classify(gent);
	      break;
	    }
	  }
	  
	  vt = E_otherVertex(e, vt);

	  if(PList_inList(endvlist, vt)) {
	    ok = 0;
	    PList_remItem(endvlist, vt);
	  }
	}
      }
      PList_delete(endvlist);

      // need to take care of the circular model edges
      while(PList_size(f_bc_eds)) {
	
	e = (pEdge)PList_item(f_bc_eds, 0);
	gent = theMesh->getGEntity(geid++,1);
	e->classify(gent);
	
	startv = E_vertex(e, 0);
	startv->classify(gent);
	
	vt = startv;
	ok = 1;

	while(ok) {
	  
	  ve = V_numEdges(vt);
	  for(j=0; j<ve; j++) {
	    e = V_edge(vt, j);
	    if(PList_inList(f_bc_eds, e)){
	      PList_remItem(f_bc_eds, e);
	      e->classify(gent);
	      break;
	    }
	  }

	  vt = E_otherVertex(e, vt);
	  vt->classify(gent);
	  
	  if(vt == startv) {
	    ok=0;
	    PList_remItem(endvlist, vt);
	  }
	}	
      }
    }
    
    PList_delete(f_bc_eds);

    // set up the rest of edges and vertices
    fiter = M_classifiedFaceIter(theMesh, gfent, 0);
    while(face = FIter_next(fiter)) {
      for(i=0; i<3; i++) {
	edge = F_edge(face, i);
	if(E_whatInType(edge)==3) 
	  edge->classify(gfent);
	for(j=0; j<2; j++){
	  vt = E_vertex(edge, j);
	  if(V_whatInType(vt) == 3)
	    vt->classify(gfent);	    
	}
      }
    }
    FIter_delete(fiter);
  }

  cout<<endl;
  
  //Traverse all the mesh and set up face classification for all of the faces
  //with only one region connected to it
 
  PList_delete(negR);


  
  // ******************************************************
  // ********  create the middle surface point
  // ******************************************************
  for(i=0; i<num[3]; i++) {
    
    for(j=0; j<2; j++){
      vtid[j] = surf_midpt_vt[i*2+j];
      ed_vert[j] = verts[vtid[j]];
    }

    for(j=0; j<3; j++) 
      xyz[j] = surf_midpoints[i*3+j];

    
    pEdge edge = E_exist(ed_vert[0], ed_vert[1]);
    if(!edge) {
      printf("can not get the edge %d - %d for the middle point \n", vtid[0], vtid[1]);
      printf("Please check the input NCDF.\n");
      exit(0);
    }

    if(mid_flag) {
      pPoint pt = P_new();
      P_setPos(pt, xyz[0], xyz[1], xyz[2]);
      E_setPoint(edge, pt);
      if(E_whatInType(edge) != 3) { // set parametric coords for boundary edges
        FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0);
      }
    }
    else{
      if(E_whatInType(edge) != 3) {
	// since there are so many crazy curved shape for the interior edges, reset them to linear
	pPoint pt = P_new();
	P_setPos(pt, xyz[0], xyz[1], xyz[2]);
	E_setPoint(edge, pt);
        FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0);
      }
    }
  }
  
  fiter = M_faceIter(theMesh);
  while(face = FIter_next(fiter))
    if(EN_getDataInt((pEntity)face, fbc, &attid))
      EN_deleteData((pEntity)face, fbc);	
  MD_deleteMeshDataId(fbc);
  
  delete []tet_interior;
  delete []tet_exterior;
  delete []data_coords;
  delete []data_surf_midpts;
  delete []surf_midpoints;
  delete []surf_midpt_vt;
  delete []verts;
  delete inp;


  return ;
}


  // **********************************************************
void exportNCDFBin(pMesh pMeshMesh, pGModel model, const char *FILE_NAME, const char *tagFname)
// **********************************************************
{
  
   /* When we create netCDF variables and dimensions, we get back an
   * ID for each one. */

  /* ID of the file */
  int ncid;

  /* IDs of the dimensions */
  int tet_int_size_dimid; 
  int tet_int_num_dimid;
  int tet_ext_size_dimid;
  int tet_ext_num_dimid;
  int num_coords_dimid;
  int coord_size_dimid;
  int num_surf_midpt_dimid;
  int surf_midpt_size_dimid;

  int dimids[2];

  /* IDs of the variables */
  int tetra_int_varid;
  int tetra_ext_varid;
  int coords_varid;
  int surf_midpt_varid;

  //int varids[4];

  int tetinteriorsize = 5 ;
  int tetinterior = -1 ;
  int tetexteriorsize = 9 ;
  int tetexterior = -1 ;
  int ncoords = M_numVertices(pMeshMesh) ;
  int coord_size = 3 ;
  int nsurface_midpoint = -1 ;
  int surface_midpoint_size = 5 ;
  
  vector<pRegion> int_rgns, ext_rgns;

  SU_mesh_info(pMeshMesh, tetinterior, tetexterior, nsurface_midpoint, int_rgns, ext_rgns);
  

   /* This is the data array we will write. It will just be filled
    * with a progression of numbers for this example. */
   int* tet_int_data=new int[tetinterior*tetinteriorsize];
   int* tet_ext_data=new int[tetexterior*tetexteriorsize];
   double* coords_data=new double[ncoords*coord_size];
   double* surf_midpts_data=new double[nsurface_midpoint*surface_midpoint_size];
   
   /* Loop indexes, and error handling. */
   int x, y, retval;

   /* Create some pretend data. If this wasn't an example program, we
    * would have some real data to write, for example, model
    * output. */
//    for (x = 0; x < tetinteriorsize; x++)
//       for (y = 0; y < tetinterior ; y++)
	//data_out[x][y] = x * tetinterior + y;

   /* Always check the return code of every netCDF function call. In
    * this example program, any retval which is not equal to NC_NOERR
    * (0) will cause the program to print an error message and exit
    * with a non-zero return code. */

   /* Create the file. The NC_CLOBBER parameter tells netCDF to
    * overwrite this file, if it already exists.*/
   if ((retval = nc_create(FILE_NAME, NC_CLOBBER, &ncid)))
     ERR(retval);
   
   /* Define the dimensions. NetCDF will hand back an ID for each. */
   if ((retval = nc_def_dim(ncid, "tetinteriorsize", tetinteriorsize, &tet_int_size_dimid)))
     ERR(retval);
   if ((retval = nc_def_dim(ncid, "tetinterior", tetinterior, &tet_int_num_dimid)))
     ERR(retval);
   if ((retval = nc_def_dim(ncid, "tetexteriorsize", tetexteriorsize, &tet_ext_size_dimid)))
     ERR(retval);
   if ((retval = nc_def_dim(ncid, "tetexterior", tetexterior, &tet_ext_num_dimid)))
     ERR(retval);
   if ((retval = nc_def_dim(ncid, "ncoords", ncoords, &num_coords_dimid)))
     ERR(retval);
   if ((retval = nc_def_dim(ncid, "coord_size", coord_size, &coord_size_dimid)))
     ERR(retval);
   if ((retval = nc_def_dim(ncid, "nsurface_midpoint", nsurface_midpoint, &num_surf_midpt_dimid)))
     ERR(retval);
   if ((retval = nc_def_dim(ncid, "surface_midpoint_size", surface_midpoint_size, &surf_midpt_size_dimid)))
     ERR(retval);
   /* The dimids array is used to pass the IDs of the dimensions of
    * the variable. */
   dimids[0] = tet_int_num_dimid;
   dimids[1] = tet_int_size_dimid;

   /* Define the variable. The type of the variable in this case is
    * NC_INT (4-byte integer). */
   if ((retval = nc_def_var(ncid, "tetrahedron_interior", NC_INT, NDIMS, 
			    dimids, &tetra_int_varid)))
      ERR(retval);

   dimids[0] = tet_ext_num_dimid;
   dimids[1] = tet_ext_size_dimid;

   if ((retval = nc_def_var(ncid, "tetrahedron_exterior", NC_INT, NDIMS, 
			    dimids, &tetra_ext_varid)))
      ERR(retval);

   dimids[0] = num_coords_dimid;
   dimids[1] = coord_size_dimid;

   if ((retval = nc_def_var(ncid, "coords", NC_DOUBLE, NDIMS, 
			    dimids, &coords_varid)))
      ERR(retval);

   dimids[0] = num_surf_midpt_dimid;
   dimids[1] = surf_midpt_size_dimid;

   if ((retval = nc_def_var(ncid, "surface_midpoint", NC_DOUBLE, NDIMS, 
			    dimids, &surf_midpt_varid)))
      ERR(retval);

   /* End define mode. This tells netCDF we are done defining
    * metadata. */
   if ((retval = nc_enddef(ncid)))
      ERR(retval);

   /* --------------------------------------------------------------- */

   pMeshDataId  entid = MD_newMeshDataId("vid");

   /* Setup coords data block assign vertex ids    */
   void *temp = 0;
   int count = 0;
   pVertex vertex;
   VIter viter = M_vertexIter(pMeshMesh);
   double xyz[3];
   while(vertex = VIter_next(viter)){
     EN_attachDataInt((pEntity)vertex, entid, count);
     V_coord(vertex, xyz);
     for(int i=0; i<3; i++){
       coords_data[count*coord_size+i]=xyz[i];
     }
     count++;     
   }
   VIter_delete(viter);
   
   /* Setup interior tetrahedron data */
   count = 0;
   temp = 0;
   int vvid;
   pRegion region;
 
   for(int i=0; i<int_rgns.size(); i++){
     
     tet_int_data[i*tetinteriorsize+0] = 1; // material property

     region = int_rgns[i]; 
     pPList rvlist = R_vertices(region, 1);
     
      for(int j=0; j<4; j++) {
	vertex = (pVertex)PList_item(rvlist, j);
	EN_getDataInt((pEntity)vertex, entid, &vvid);
	tet_int_data[i*tetinteriorsize+j+1] = vvid; // vertex IDs
      }
    }

   /* Setup exterior tetrahedron data */
   count = 0;
   temp = 0;
   pFace face;
   pGEntity gent;
   int findex[] = {0, 3, 1, 2};
   for(int i=0; i<ext_rgns.size(); i++){
     
     tet_ext_data[i*tetexteriorsize+0] = 1; // material property

     region = ext_rgns[i]; 
     pPList rvlist = R_vertices(region, 1);
     
      for(int j=0; j<4; j++) {
	vertex = (pVertex)PList_item(rvlist, j);
	EN_getDataInt((pEntity)vertex, entid, &vvid);
	tet_ext_data[i*tetexteriorsize+j+1] = vvid; // vertex IDs
      }
      for(int j=0; j<4; j++) {
	face = R_face(region, findex[j]);
	if(F_whatInType(face) == 3)
	  tet_ext_data[i*tetexteriorsize+j+5] = -1;
	else{
	  int idd;
	  gent = F_whatIn(face);
	  idd = GEN_tag(gent) ;
	  tet_ext_data[i*tetexteriorsize+j+5] = idd;
	}
      }
   }
   
   /* Setup up surface_midpoint data block */
   count = 0;
   EIter eiter = M_edgeIter(pMeshMesh);
   while(pEdge edge = EIter_next(eiter)){
     if(!E_numPoints(edge))
       continue;
     
     //count++;
     for(int i=0; i<2; i++){
       vertex = E_vertex(edge, i);
       EN_getDataInt((pEntity)vertex, entid, &vvid);
       surf_midpts_data[count*surface_midpoint_size+i] = (double)vvid;
     }
     
     pPoint pt = E_point(edge, 0);
     surf_midpts_data[count*surface_midpoint_size+2] = P_x(pt);
     surf_midpts_data[count*surface_midpoint_size+3] = P_y(pt);
     surf_midpts_data[count*surface_midpoint_size+4] = P_z(pt);

     count++;

   }
   
   /* Write the pretend data to the file. Although netCDF supports
    * reading and writing subsets of data, in this case we write all
    * the data in one operation. */
   if ((retval = nc_put_var_int(ncid, tetra_int_varid, &tet_int_data[0])))
     ERR(retval);

   if ((retval = nc_put_var_int(ncid, tetra_ext_varid, &tet_ext_data[0])))
     ERR(retval);

   if ((retval = nc_put_var_double(ncid, coords_varid, &coords_data[0])))
     ERR(retval);
   
   if ((retval = nc_put_var_double(ncid, surf_midpt_varid, &surf_midpts_data[0])))
     ERR(retval);

  /* Close the file. This frees up any internal netCDF resources
   * associated with the file, and flushes any buffers. */
   if ((retval = nc_close(ncid)))
      ERR(retval);

   delete []tet_int_data;
   delete []tet_ext_data;
   delete []coords_data;
   delete []surf_midpts_data;

   printf("*** SUCCESS writing ncdf file!\n");
   return;
}

#endif/*NCDF*/

} /*end of namespace slacUtil*/
