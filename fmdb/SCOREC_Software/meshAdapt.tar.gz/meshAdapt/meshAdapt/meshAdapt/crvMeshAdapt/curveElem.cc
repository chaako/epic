#include "curveElem.h"
#include "curveUtil.h"
#include "slacUtil.h"

double CrvElem::RadiusRatio(){

  double dRR = 0.0;
  slacUtil::SU_RadiusRatio(pTheRgn_, dRR);
  return dRR;

}

double CrvElem::AspectRatio(){

  double dAR = 0.0;
  slacUtil::SU_AspectRatio(pTheRgn_, dAR);
  return dAR;

}

int CrvElem::VertsOnGVert(){

}

int CrvElem::VertsOnGEdge(){

}

int CrvElem::VertsOnGFace(){

}

int CrvElem::VertsOnGRegn(){

}


int CrvElem::EdgesOnGEdge(){

  return curveUtil::R_numEdgesOnGeomEdge(pTheRgn_);

}

int CrvElem::EdgesOnGFace(){

  return curveUtil::R_numEdgesOnGeomFace(pTheRgn_);
}

int CrvElem::EdgesOnGRegn(){

  return curveUtil::R_numEdgesOnGeomRegn(pTheRgn_);

}


int CrvElem::FacesOnGFace(){

  return curveUtil::R_numFacesOnGeomFace(pTheRgn_);

}

int CrvElem::FacesOnGRegn(){

  return curveUtil::R_numFacesOnGeomRegn(pTheRgn_);

}


