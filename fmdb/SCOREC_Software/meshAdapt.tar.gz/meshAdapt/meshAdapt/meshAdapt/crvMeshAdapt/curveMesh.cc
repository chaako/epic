#include "pmMigrateUtil.h"
#include "SF_MigrationCallbacks.h"
//#include "M_writeVTKFile.h"
#include "MeshAdapt.h"
#include "curveMesh.h"
#include "curveUtil.h"
#include "curveElem.h"

#include "AdaptUtil.h"
#include "DSplitClpsMod.h"
#include "templateUtil.h"
#include "modeler.h"
#include "ParUtil.h"
#include <map>
#include <math.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <list>
#ifdef MVTK
#include "mvtk.h"
#endif
#include "Macros.h"

#include "mException.h"

using std::cout;
using std::endl;
using std::ofstream;
using std::ifstream;
using std::map;
using std::vector;
using namespace std;
//using namespace adaptUtil;
using namespace curveUtil;

void curveMesh::updateNewReg(pPList *newReg)
{
  void *temp;
  temp = 0;
  crShpInfo *csi;
  pRegion region;
  int flag;

  while(region = (pRegion)PList_next(*newReg, &temp)) {
    csi = new crShpInfo;
    flag = CR_isValid(region, csi);
    if(!flag || (csi->shape < desired_shape))
      {
        map<pRegion, crShpInfo *>::iterator miter, miterend = invalidCurvedRgns.end();
        miter = invalidCurvedRgns.find(region);
        if(miter == miterend) {
          invalidCurvedRgns[region] = csi;
        }
        else{
          delete miter->second;
          invalidCurvedRgns.erase(miter);
          invalidCurvedRgns[region] = csi;
        }
      }
    else
      delete csi;
  }

  return;

}

// create higher order nodes for mesh edges
void curveMesh::create_ho_edges()
{
  EIter eiter = M_edgeIter(pThePart_);
  pEdge edge;
  pPoint pt;
  double xyz[3], par[3]={0.0, 0.0, 0.0};
  pVertex verts[2][3];
  //pPoint points[2];
  double coords[2][3];
  while(edge = EIter_next(eiter)) {
    if(E_whatInType(edge) != 3) {

#ifdef SGMI_IGEOM

      verts[0]=E_vertex(edge,0);
      verts[1]=E_vertex(edge,1);

      V_coord( verts[0], coords[0]);
      V_coord( verts[1], coords[1]);



#else
      templatesUtil::middlePoint(edge,0.5,xyz,par);
      pt = P_new();
      P_setPos(pt, xyz[0], xyz[1], xyz[2]);
      E_setPoint(edge, pt);
      FMDB_P_setParametricPos(pt, par[0], par[1], par[2]);
#endif
    }
  }
  EIter_delete(eiter);
}



//
// Find the invalid regions
// There are two type of invalid regions:
// 1) Invalid curved regions - at least one mesh entity
// in the region closure has high order nodes;
// 2) Invalid linear regions - none of the mesh entity
// in the region closure has high order nodes;
//
//
void curveMesh::createInvalidRgns(double shape)
{
  double t1=ParUtil::Instance()->wTime();
  _GWORSTSHAPE=BIG_NUMBER;
  // check the invalid regions
  RIter riter = M_regionIter(pThePart_);
  int flag;
  pRegion rgn;
  while(rgn = RIter_next(riter)){

    // check the aspect ratio
    CrvElem CrvElemObj = CrvElem(rgn);
//    double AR = 0.0;
//    slacUtil::SU_AspectRatio(rgn, AR);
    double AR = CrvElemObj.AspectRatio();
#ifdef DEBUG
    assert(AR>0);
    if(AR>20.0)
      cout<<"[WARNING] Large Aspect Ratio Detected: "<<AR<<endl;
#endif
    crShpInfo *csi = new crShpInfo;
    flag = CR_isValid(rgn, csi);
    if(csi->shape < _GWORSTSHAPE)
      _GWORSTSHAPE = csi->shape;
    if(csi->shape <= shape) {
    // Note: this is not exactly right, since "shape" can be set to be not equal to zero
      invalidCurvedRgns[rgn] = csi;
#ifdef DEBUG
      cout<<"------------------------------------------------"<<endl;
      cout<<"[INVALID REGION]: Radius Ratio ---- "<<csi->qs<<endl;
      cout<<"[INVALID REGION]: Aspect Ratio ---- "<<AR<<endl;
//      cout<<"[INVALID REGION]: # verts on Model Bdry ---- "<<curveUtil::R_numVtxsOnGeomBdry(rgn)<<endl;
      cout<<"[INVALID REGION]: # edges on Model Edge ---- "<<CrvElemObj.EdgesOnGEdge()<<endl;
      cout<<"[INVALID REGION]: # edges on Model Face ---- "<<CrvElemObj.EdgesOnGFace()<<endl;
      cout<<"[INVALID REGION]: # edges on Model Regn ---- "<<CrvElemObj.EdgesOnGRegn()<<endl;
      cout<<"[INVALID REGION]: # faces on Model Face ---- "<<CrvElemObj.FacesOnGFace()<<endl;
      cout<<"[INVALID REGION]: # faces on Model Regn ---- "<<CrvElemObj.FacesOnGRegn()<<endl;
      cout<<"[INVALID REGION]: The Invalidity Index  ---- "<<csi->index<<endl;
      cout<<"------------------------------------------------"<<endl;
#endif//DEBUG
      if(csi->qs <= 0.0)
        cout<<"Found Region with Invalid ST Part -- curveMesh::createInvalidRgns"<<endl;
    }
    else
      delete csi;
  }

  RIter_delete(riter);
  double t2=ParUtil::Instance()->wTime();
  cout<<"Time for Computing the Regions' Shape:      ["<<t2-t1<<"(sec)]"<<endl;
#ifdef MA_PARALLEL
  int count = 0;
  int nbr_edges_on_gbdry[]={0,0,0,0,0,0,0};
  map<pRegion, crShpInfo*>::iterator miter = invalidCurvedRgns.begin(), mitend= invalidCurvedRgns.end();
  for(; miter!=mitend ;miter++){
    pRegion region = miter->first;
    if(CR_isOnPartBdry(region))
      count++;
    pPList elist = R_edges(region, 1);
    int bdry_edge_count = 0;
    for(int i=0; i<6; i++){
      pEdge edge = (pEdge)PList_item(elist, i);
      if(E_whatInType(edge)!=3)
        bdry_edge_count++;
    }
    PList_delete(elist);
    nbr_edges_on_gbdry[bdry_edge_count]++;

  }

#ifdef DEBUG
  cout<<"Invalid Elements on Part Boundary:          ["<<count<<"]"<<endl;
  cout<<"****** Geometric Constraint data ****** :"<<endl;
  cout<<"  With NO edge on G Bdry:                   ["<<nbr_edges_on_gbdry[0]<<"]"<<endl;
  cout<<"  With 1 edge  on G Bdry:                   ["<<nbr_edges_on_gbdry[1]<<"]"<<endl;
  cout<<"  With 2 edges on G Bdry:                   ["<<nbr_edges_on_gbdry[2]<<"]"<<endl;
  cout<<"  With 3 edges on G Bdry:                   ["<<nbr_edges_on_gbdry[3]<<"]"<<endl;
  cout<<"  With 4 edges on G Bdry:                   ["<<nbr_edges_on_gbdry[4]<<"]"<<endl;
  cout<<"  With 5 edges on G Bdry:                   ["<<nbr_edges_on_gbdry[5]<<"]"<<endl;
  cout<<"  With 6 edged on G Bdry:                   ["<<nbr_edges_on_gbdry[6]<<"]"<<endl;
#endif //DEBUG

#endif //MA_PARALLEL

  return;

}

//
// routine to correct the invalid region list
//
//
void curveMesh::run()
{

  if(iTheCrvType_ == 1) {
    //create the higher order nodes for each edge classified on model boundaries
    create_ho_edges();
  }

  double tmpShape = desired_shape;
  desired_shape = 0.0;

  cout<<endl;
  cout<<"*******************************************"<<endl;
  cout<<"Stage 0: Migrate the Curved/Linear  Regions"<<endl;
  cout<<"*******************************************"<<endl;
  createInvalidRgns(desired_shape);
  std::vector<pRegion> fakeRgnVec;
  getRgnsOnPartBdry(invalidCurvedRgns, fakeRgnVec);

  setCurrentStage(1);
  // Stage 1: Apply local mesh modification operations
  //          to correct the invalid linear regions
  cout<<endl;
  cout<<"*******************************************"<<endl;
  cout<<"Stage 1: Correct the Curved/Linear  Regions"<<endl;
  cout<<"*******************************************"<<endl;
  //return;

for(int loop = 0; loop<5; loop++){
  invalidCurvedRgns.clear();

  createInvalidRgns(desired_shape);
  cout<<"Linear/Curved Regions to be Processed:      [" <<invalidCurvedRgns.size()<<"]"<<endl;
  cout<<"Worst Shape in the Mesh:                    [" <<_GWORSTSHAPE<<"]"<<endl;

  //invalidRgnsInfo();

  cout<<"---------"<<endl;
  //invalidCurvedRgns.clear();
  //createInvalidRgns(desired_shape);
  //cout<<"Linear/Curved Regions to be Processed:      [" <<invalidCurvedRgns.size()<<"]"<<endl;

  getRgnsOnPartBdry(invalidCurvedRgns, fakeRgnVec);
  invalidCurvedRgns.clear();
  createInvalidRgns(desired_shape);
  //invalidRgnsInfo();

  if(invalidCurvedRgns.size()) {

    fixInvalidRgnsByMods();

    outPutOpsInfo();

    cout<<"Remaining Invalid Linear/Curved Regions:    [" <<invalidCurvedRgns.size()<<"]"<<endl;

    if(invalidCurvedRgns.size()) {
      map<pRegion, crShpInfo*>::iterator miter = invalidCurvedRgns.begin(), mitend= invalidCurvedRgns.end();
      for(; miter!=mitend;) {
        delete miter->second;
        miter++;
      }
    }

    invalidCurvedRgns.clear();
  }

#ifdef DEBUG
  cout<<"Finished Loop "<<loop<<endl;
#endif

}

// Stage 2: Improve the shape of curved regions
  setCurrentStage(2);
  cout<<endl;
  cout<<"*****************************************"<<endl;
  cout<<"Stage 2: Improve the Region Shapes "<<endl;
  cout<<"*****************************************"<<endl;
  desired_shape = tmpShape;
  createInvalidRgns(desired_shape);
  cout<<"Linear/Curved Regions to be Processed:      [" <<invalidCurvedRgns.size()<<"]"<<endl;
  cout<<"Worst Shape in the Mesh:                    [" <<_GWORSTSHAPE<<"]"<<endl;
  cout<<"---------"<<endl;
  if(invalidCurvedRgns.size()) {
    // cout<<"Improving "<<invalidCurvedRgns.size()<<" regions"<<endl;

    //Commented by Kai for turning off local mesh modifications. Dec 4, 2009
    ImproveRgnsByMods();

    //cout<<"Improved"<<endl;
    outPutOpsInfo();




    int invalidCount=0, tot = invalidCurvedRgns.size();
    if(invalidCurvedRgns.size()) {
      map<pRegion, crShpInfo*>::iterator miter = invalidCurvedRgns.begin(), mitend= invalidCurvedRgns.end();
      for(; miter!=mitend;) {
        if(miter->second->shape <= 0.0)
          invalidCount++;
        delete miter->second;
        miter++;
      }
    }
#ifdef DEBUG
    cout<<"Remaining Invalid Linear/Curved Regions:    [" <<invalidCount<<"]"<<endl;
    cout<<"Remaining Regions Below Shape Quality:      [" <<tot-invalidCount<<"]"<<endl;
#endif
    invalidCurvedRgns.clear();
  }

  //step 3, apply explicit nodal smoothing
  setCurrentStage(3);
  cout<<endl;
  cout<<"*****************************************"<<endl;
  cout<<"Stage 3: Apply explicit nodal smoothing "<<endl;
  cout<<"*****************************************"<<endl;
  //cout<<endl;
  // cout<<"Not implemented yet"<<endl;

  createInvalidRgns(desired_shape);
  cout<<"Linear/Curved Regions to be Processed:      [" <<invalidCurvedRgns.size()<<"]"<<endl;
  cout<<"Worst Shape in the Mesh:                    [" <<_GWORSTSHAPE<<"]"<<endl;
  cout<<"*****************************************"<<endl<<endl;

  if(invalidCurvedRgns.size()) {
    // cout<<"Improving "<<invalidCurvedRgns.size()<<" regions"<<endl;
    //Commented by Kai for turning off local mesh modifications. Dec 4, 2009
    //ImproveRgnsByMods();
    //cout<<"Improved"<<endl;
    outPutOpsInfo();

    int invalidCount=0, tot = invalidCurvedRgns.size();
    if(invalidCurvedRgns.size()) {
      map<pRegion, crShpInfo*>::iterator miter = invalidCurvedRgns.begin(), mitend= invalidCurvedRgns.end();
      for(; miter!=mitend;) {
        if(miter->second->shape <= 0.0)
          invalidCount++;
        delete miter->second;
        miter++;
      }
    }
#ifdef DEBUG
    cout<<"Remaining Invalid Linear/Curved Regions:    [" <<invalidCount<<"]"<<endl;
    cout<<"Remaining Regions Below Shape Quality:      [" <<tot-invalidCount<<"]"<<endl;
#endif
    invalidCurvedRgns.clear();
  }

 // Stage 4: HO_node smoothing

  cout<<endl;
  cout<<"********************************************"<<endl;
  cout<<"Stage 4: Uncurve the remaining invalid rgns "<<endl;
  cout<<"********************************************"<<endl;
  desired_shape = tmpShape;
  createInvalidRgns(desired_shape);
  cout<<"Linear/Curved Regions to be Processed:      [" <<invalidCurvedRgns.size()<<"]"<<endl;
  cout<<"Worst Shape in the Mesh:                    [" <<_GWORSTSHAPE<<"]"<<endl;
  cout<<"---------"<<endl;
  pMeshMod pBestMod;

for(int loop = 0; loop<3; loop++){

  invalidCurvedRgns.clear();
  createInvalidRgns(desired_shape);
  getRgnsOnPartBdry(invalidCurvedRgns, fakeRgnVec);
  invalidCurvedRgns.clear();
  createInvalidRgns(desired_shape);

  if(invalidCurvedRgns.size()) {
    // cout<<"Improving "<<invalidCurvedRgns.size()<<" regions"<<endl

    //cout<<"1"<<endl;
    CM_createInvalidRgnList();
    unCurveInvalidRgns();

    int invalidCount=0, tot = invalidCurvedRgns.size();

    map<pRegion, crShpInfo*>::iterator miter = invalidCurvedRgns.begin(), mitend= invalidCurvedRgns.end();
    crShpInfo *csi;
    for(; miter != mitend; ++miter){
      csi = miter->second;
      csi->processed = 0;
    }

    miter = invalidCurvedRgns.begin();
    mitend= invalidCurvedRgns.end();
/*
    for(; miter!=mitend;) {

      vertMotionsMod *vmotions = new vertMotionsMod(pThePart_, pNullSF_, pShpMeasure_, pResults_);
      vmotions->setModelType(PARAM);
      vmotions->setMvEntTopo(1); // move the high order node
      computeRegionShape(miter->first, miter->second);
      //cout<<miter->second->shape<<"   Q_c  "<<miter->second->qc<<"    Q_s  "<<miter->second->qs<<endl;

      if(isExplicitHONSmoothingValid(vmotions, miter->first, miter->second, miter->second->qc))
        {
          pBestMod = vmotions;
          applyBestMod(&pBestMod);
          delete pBestMod;
          //cout<<"apply nodal smoothing"<<endl;
          miter  = invalidCurvedRgns.begin();
          mitend = invalidCurvedRgns.end();
        }
      else {
        miter++;
        //cout<<"not apply"<<endl;
        delete vmotions;
      }
    }
    //cout<<"2"<<endl;
    */
    invalidCurvedRgns.clear();
  }
#ifdef DEBUG
  cout<<"Finished loop "<<loop<<endl;
#endif
}


  // Output remaining worst shape at the very end.
  createInvalidRgns(desired_shape);
  //cout<<"Linear/Curved Regions to be Processed:      [" <<invalidCurvedRgns.size()<<"]"<<endl;
  cout<<"Remaining Regions Below Shape Quality:      [" <<invalidCurvedRgns.size()<<"]"<<endl;
  cout<<"Worst Shape in the Mesh:                    [" <<_GWORSTSHAPE<<"]"<<endl;
  cout<<"*****************************************"<<endl<<endl;

  return;

}


void curveMesh::outPutOpsInfo()
{
  if(iOpCounts_[6])
    cout<<"Applied Region Collapse:                    ["<<iOpCounts_[6]<<"]"<<endl;
  if(iOpCounts_[1])
    cout<<"Applied Edge Collapse:                      ["<<iOpCounts_[1]<<"]"<<endl;
  if(iOpCounts_[2])
    cout<<"Applied Face Swap:                          ["<<iOpCounts_[2]<<"]"<<endl;
  if(iOpCounts_[3])
    cout<<"Applied Edge Swap:                          ["<<iOpCounts_[3]<<"]"<<endl;
  if(iOpCounts_[4])
    cout<<"Applied Edge Split+Collapse:                ["<<iOpCounts_[4]<<"]"<<endl;
  if(iOpCounts_[0])
    cout<<"Applied Double Split+Collapse:              ["<<iOpCounts_[0]<<"]"<<endl;
  if(iOpCounts_[7])
    cout<<"Applied Edge Split:                         ["<<iOpCounts_[7]<<"]"<<endl;
  if(iOpCounts_[5])
    cout<<"Applied Edge Reshape:                       ["<<iOpCounts_[5]<<"]"<<endl;
  if(iOpCounts_[8])
    cout<<"Applied Constraint Nodal Smoothing:         ["<<iOpCounts_[8]<<"]"<<endl;

  for(int i=0; i<9; i++)
    iOpCounts_[i] = 0;

}

void curveMesh::fix_entity(pEntity ent)
{

  int temp;
  if(!EN_getDataInt(ent, _fixEnt, &temp))
    EN_attachDataInt(ent, _fixEnt, 1);
  return;

}

int curveMesh::getRgnsOnPartBdry(std::map<pRegion, crShpInfo*> inputRgnMap, std::vector<pRegion> &outputBdryRgns)
{
#ifdef MA_PARALLEL
  outputBdryRgns.clear();
  std::map<mEntity*, int> bdryRgnsToMigrate;
  std::list<pVertex> vtOnCB;
  vtOnCB.clear();
  std::list<pVertex>::iterator tmpIter;
  bdryRgnsToMigrate.clear();
  if(inputRgnMap.size()==0){
    //return 0; // no input rgn
  }
  else{
    std::map<pRegion, crShpInfo*>::iterator miter = inputRgnMap.begin();
    std::map<pRegion, crShpInfo*>::iterator mitend = inputRgnMap.end();
    for(;miter!=mitend;miter++){  // loop over input region map
      pRegion region = miter->first;
      crShpInfo* csi = miter->second;
      delete csi; // clear the csi's
      if(CR_isOnPartBdry(region)){
        bdryRgnsToMigrate[(mEntity*)region] = 0; //target processer set to 0
        pPList vlist = R_vertices(region, 1); // get the vertices of the bdry region
        for(int i = 0; i<4; i++){ // loop over the vertices
          pVertex vert = (pVertex)PList_item(vlist, i);
          if(!EN_duplicate(vert)){ // not on PB
            //continue;
            pPList rlist = V_regions(vert);
            int size = PList_size(rlist);
            for(int i=0; i<size; i++){
              pRegion region = (pRegion)PList_item(rlist, i);
              std::map<pRegion, int>::iterator mfinder = bdryRgnsToMigrate.find(region);
              if(mfinder ==  bdryRgnsToMigrate.end())
                bdryRgnsToMigrate[region]=0;
            }
            PList_delete(rlist);

          }
          else{
            int temp;
            if(!EN_getDataInt(vert, _onPartBdry, &temp)){
              EN_attachDataInt(vert, _onPartBdry, 1);
              vtOnCB.push_back(vert);
            }

          }
        }
        PList_delete(vlist);//*/
        
      }
    }
  }
#ifdef DEBUG
  cout<<"Number of vtOnCB before unifying: "<<vtOnCB.size();
#endif
  M_unifyTaggedEntities(_onPartBdry, &vtOnCB);
#ifdef DEBUG
  cout<<"Number of vtOnCB after unifying: "<<vtOnCB.size();
#endif
// 
  VIter viter = M_vertexIter(pThePart_);
  while(pVertex vertex = VIter_next(viter)){
    int temp;
    if(EN_getDataInt(vertex, _onPartBdry, &temp)){
      pPList rlist = V_regions(vertex);
      int size = PList_size(rlist);
      for(int i=0; i<size; i++){
        pRegion region = (pRegion)PList_item(rlist, i);
        std::map<pRegion, int>::iterator mfinder = bdryRgnsToMigrate.find(region);
        if(mfinder ==  bdryRgnsToMigrate.end())
          bdryRgnsToMigrate[region]=0;
      }
    }

  }

  curveMigrateCB ccb;
  //deleteDimReduction(vtOnCB, ccb);
  migrateMeshEntities(pThePart_, bdryRgnsToMigrate, ccb);
  //std::vector<pEntity> newVt;
  //std::vector<pEntity> rmVt;
  //std::vector<pEntity>::iterator vIt;
  //std::vector<pEntity> dummy;
  //std::vector<mEntityGroup*> VecRmvEG;
  //std::vector<mEntityGroup*> VecNewEG;

  //M_migration(theMesh,0,vtOnCB,ccb,0,rmVt,newVt,-1,dummy,dummy,VecRmvEG,VecNewEG);
#endif
  return 1;
}
int curveMesh::computeMiddlePtTarget(pRegion theRegion, int keyIndex, pEdge keyEdge)
{
  cout<<"start computeMiddlePtTarget -- "<<endl;
  pEdge edges[3], edge;
  pPList relist = R_edges(theRegion, 1);
  int i, k, l, j, flag = 0, ee_id[4][3] = {{0, 2, 3}, {1, 0, 4}, {2, 1, 5},{3, 5, 4}};
  double v[3][3], vxyz[3], nv[3][3], shape;
  pVertex vert; ;
  double cv[3], mvxyz[3], dist, detj, len;
  double vtxyz[2][3], ptxyz[3], old_xyz[3];

  // find the three edges;
  edges[0] = keyEdge;
  for(k = 0, l=1; k<3; k++) {
    edge = (pEdge)PList_item(relist, ee_id[keyIndex][k]);
    if(edge != edges[0])
      edges[l++] = edge;
  }
  PList_delete(relist);
  
// retrieve the control points of the three edges
  E_bezierCtrlPt(edges[0], v[0]);
  pPoint pt;
  if(E_numPoints(edges[0])) {
    pt = E_point(edges[0], 0);
    old_xyz[0] = P_x(pt);
    old_xyz[1] = P_y(pt);
    old_xyz[2] = P_z(pt);
  }
  else {
    pt = P_new();
    E_bezierCtrlPt(edges[0], old_xyz);
    P_setPos(pt, old_xyz[0], old_xyz[1], old_xyz[2]);
    E_setPoint(edges[0], pt);
  }
  
  for(int ll=0; ll<2; ll++)
    V_coord(E_vertex(edges[0], ll), vtxyz[ll]);
  
  E_bezierCtrlPt(edges[1], v[1]);
  E_bezierCtrlPt(edges[2], v[2]);

  // retrieve the vertex 
  pPList rvlist = R_vertices(theRegion, 1);
  vert = (pVertex)PList_item(rvlist, keyIndex);
  V_coord(vert, vxyz);
  PList_delete(rvlist);
  
  // compute the three norms
  for(int ll=0; ll<3; ll++)
    diffVt(v[ll], vxyz, nv[ll]);
  
  crossProd(nv[1], nv[2], cv);
  detj = dotProd(cv, nv[0]);
  
  if(detj>0){
    double tmp;
    for(int i=0;i<3;i++){
      tmp = nv[1][i];
      nv[1][i] = nv[2][i];
      nv[2][i] = tmp;
    }
    crossProd(nv[1], nv[2], cv);
    if(dotProd(cv, nv[0])>0)
      cout<<"something wrong in check point 1"<<endl;
  }

  // compute the distance of the point to the plance
  dist = fabs(dotProd(cv, nv[0]))/sqrt(dotProd(cv, cv));
  
  // compute the mirror points (Bezier)
  len = sqrt(dotProd(cv, cv));

 
  int oldNumInvalid = 0;

  crShpInfo csi;
  pPList oldlist = E_regions(edges[0]);
  for(int i=0; i<PList_size(oldlist); i++){
    pRegion region = (pRegion)PList_item(oldlist, i);
    if(!CR_isValid(region, &csi))
      oldNumInvalid++;  
  } 
  cout<<"No of originally invalid regions connected to the edge: "<<oldNumInvalid<<endl;
  PList_delete(oldlist);

  //start brute force search from 1.0 to 2.0
  int allValid = 0;
  CR_isValid(theRegion, &csi);
  double oldShape = csi.shape; 
  double newShape;
  for(double incre=0.0 ; incre <= 2.0; ){
    incre += 0.1;
    int numInvalid = 0;
    cout<<"increment = "<<incre<<"; ";
    for(int ll=0; ll<3; ll++)
      mvxyz[ll] = incre*dist*cv[ll]/len + v[0][ll]; // bezier control point
    
    // adjust the computed mv to langrange interpolation point
    for(int ll=0; ll<3; ll++)
      ptxyz[ll] = 0.25*(vtxyz[0][ll] + vtxyz[1][ll]) + 0.5*mvxyz[ll];
    
    P_setPos(pt, ptxyz[0], ptxyz[1], ptxyz[2]);
    
    // check the validity of the resulting cavity
    pPList erlist = E_regions(edges[0]);
    
    

    if(!CR_isValid(theRegion, &csi)){
      cout<<"The target region is not valid after movement"<<endl;
      cout<<"index: "<<csi.index<<endl;
      cout<<"shape: "<<csi.shape<<endl;
      newShape = csi.shape;
      if(newShape<=oldShape){
	for(int i=0; i<3;i++){
	  cv[i]*=-1;
	}
      }
      oldShape = newShape;
      //break;
      //exit(0);
    }
      

    for(int i=0; i<PList_size(erlist); i++){
      pRegion region = (pRegion)PList_item(erlist, i);
      if(CR_isValid(region, &csi)){
	allValid = 1;
      }
      else{
	//allValid = 0;
	cout<<"found another region that is not valid"<<endl;
	numInvalid++;
	//break;
      } 
    } 
    PList_delete(erlist);

    if((numInvalid<=oldNumInvalid)&&(CR_isValid(theRegion, &csi))){
      cout<<"Found a permissible position, increment = "<<incre<<endl;
      break;
    }

    if(incre>2.0){
      cout<<"Can't find all valid position......"<<endl;
      P_setPos(pt, old_xyz[0], old_xyz[1], old_xyz[2]);
      //exit(0);
    }

  }// end of search

}

int curveMesh::isExplicitNodalSmoothingValid(pRegion region, crShpInfo *csi, pEdge *targetEdge)
{
  cout<<"calling - isExplicitNodalSmoothingValid"<<endl;
  if(csi->index<0||csi->index>3){
    return 0;
    // index in [0, 3] corresponds to "one invalid corner"
  }

  //set up look-up table for edge IDs
  // first index: csi->index
  // second index: corresponding edge index
  int edgeID[4][3];

  edgeID[0][0] = 0;
  edgeID[0][1] = 2;
  edgeID[0][2] = 3;

  edgeID[1][0] = 0;
  edgeID[1][1] = 1;
  edgeID[1][2] = 4;

  edgeID[2][0] = 1;
  edgeID[2][1] = 2;
  edgeID[2][2] = 5;
  
  edgeID[3][0] = 3;
  edgeID[3][1] = 4;
  edgeID[3][2] = 5;

  int index = csi->index;

  // check edge classification: need only one edge on model region
  pPList elist = R_edges(region, 1);
  pEdge edge;
  int gregionEdgeNo = 0;
  for(int i = 0; i<3; i++){
    edge = (pEdge)PList_item(elist, edgeID[index][i]);
    if(E_whatInType(edge)==3){
      *targetEdge = edge;
      gregionEdgeNo++;
    }
  }
  
  PList_delete(elist);
  
  if(gregionEdgeNo==1){
    return 1;
  }
  else{
    *targetEdge=NULL;
    cout<<gregionEdgeNo<<" interior edges"<<endl;
    return 0;
  }
}

void curveMesh::invalidRgnsInfo(){
  
  if(invalidCurvedRgns.size()==0){
    cout<<"curveMesh::invalidRgnsInfo() -- No Invalid Curved Regions"<<endl;
    return;
  }
  
  // stats containers
  int oneCorner = 0;
  int twoCorners = 0;
  int others = 0;
  
  // iterate of the invalid regions
  map<pRegion, crShpInfo*>::iterator invIter;
  for(invIter=invalidCurvedRgns.begin(); invIter!=invalidCurvedRgns.end(); invIter++){
    int index = invIter->second->index;
   
    if(index >= 0&&index <=3){
      oneCorner++;
      cout<<"index: "<<index<<endl;
      cout<<"["<<invIter->second->index1[0]<<"]"
	  <<"["<<invIter->second->index1[1]<<"]"
	  <<"["<<invIter->second->index1[2]<<"]"
	  <<endl;
      
      int edgeID[3];
      if(index==0){
	edgeID[0] = 0;
	edgeID[1] = 2;
	edgeID[2] = 3;
      }
      else if(index==1){
	edgeID[0] = 0;
	edgeID[1] = 1;
	edgeID[2] = 4;
      }
      else if(index==2){
	edgeID[0] = 1;
	edgeID[1] = 2;
	edgeID[2] = 5;
      }
      else{ //index==3
	edgeID[0] = 3;
	edgeID[1] = 4;
	edgeID[2] = 5;
	
      }

      pPList relist = R_edges(invIter->first, 1);
      for(int i=0; i<3; i++){
	pEdge edge = (pEdge)PList_item(relist, edgeID[i]);
	cout<<"edge "<<edgeID[i]<<" is classified on: "<<E_whatInType(edge)<<endl<<endl;
      }
      pEdge targetEdge;
      int ok = isExplicitNodalSmoothingValid(invIter->first, invIter->second, &targetEdge);
      if(ok){
	cout<<"ExplicitNodalSmoothing is Valid"<<endl;
	computeMiddlePtTarget(invIter->first, invIter->second->index, targetEdge);
      }

    }
    else if(index >= 4&&index <=9)
      twoCorners++;
    else{
      others++;
     
    }

    

  }
  
  cout<<"No. of total invalid regions: "<<invalidCurvedRgns.size()<<endl;
  cout<<"No. of regions with one invalid corner: "<<oneCorner<<endl;
  cout<<"No. of regions with two invalid corners: "<<twoCorners<<endl;
  cout<<"No. of regions with other situations: "<<others<<endl;
  
  return;
}

int curveMesh::CM_RegionInfo(){
  RIter rgnIt = M_regionIter(pThePart_);
  double tmp = 0.0;
  int Performed = 0;
  // vector<pEdge> vecEdge;
  int iTotalNbrRgns = M_numRegions(pThePart_);
  int iNbrBdryRgns = 0;
  int iNbrIntRgns = 0;
  int iNbrPosBdryDSCM = 0;
  vector<pRegion> InvalidRegionVec;

  for(int loop=0; loop<1; loop++){
    
    InvalidRegionVec.clear();
    
    while(pRegion rgn = RIter_next(rgnIt)){
      crShpInfo *csi = new crShpInfo;
      if(!CR_isValid(rgn, csi)){
	InvalidRegionVec.push_back(rgn);
        cout<<"csi->index: "<<csi->index<<endl;
        cout<<"csi->qc:    "<<csi->qc<<endl;
        cout<<"csi->qs:    "<<csi->qs<<endl<<endl;

      }
    }
    
    int size = InvalidRegionVec.size();

    if(size==0)
      break;
    else
      cout<<"This is loop: "<<loop<<endl<<"Number of remaining invalid region: "<<size<<endl<<endl;
    for(int i=0; i<size; i++){
      pRegion region = InvalidRegionVec[i];
      if(!region)
	continue;
      DSplitClpsMod *dsclps = new DSplitClpsMod(pThePart_, pNullSF_, pShpMeasure_, pResults_); 
      dsclps->setCurved();
      dsclps->setModelType(PARAM);
      if(isDsplitClpsModValid(dsclps, region, tmp)){
	//dsclps->apply();
        //break;
        cout<<"This region is DSC valid "<<endl;
      }
      else
        cout<<"This region is DSC NOT valid"<<endl;
      delete dsclps;
    }
    RIter_reset(rgnIt);
  }
  
  return 1;

  RIter_reset(rgnIt);

  while(pRegion rgn = RIter_next(rgnIt)){
    if(Performed)
      break;
    crShpInfo *csi = new crShpInfo;
    //if(isBdryRegion(rgn)){
    if(!CR_isValid(rgn, csi)){
      iNbrBdryRgns++;
      DSplitClpsMod *dsclps = new DSplitClpsMod(pThePart_, pNullSF_, pShpMeasure_, pResults_); 
      dsclps->setCurved();
      dsclps->setModelType(PARAM);
      if(isDsplitClpsModValid(dsclps, rgn, tmp)){
	iNbrPosBdryDSCM++;
	//if(!Performed){
	  if(dsclps->apply())
	    Performed++;
	  //}
	delete dsclps;
      }
      else
	delete dsclps;
      
    }
    else{
      iNbrIntRgns++;
      
    }
  }
  
  cout<<"Total Number of Regions:          "<<iTotalNbrRgns<<endl;
  cout<<"Total Number of Boundary Regions: "<<iNbrBdryRgns<<endl;
  cout<<"Total Number of Interior Regions: "<<iNbrIntRgns<<endl;
  
  cout<<"Total Number of TopoPossible DSplClpsMod on Interior regions : "<<iNbrPosBdryDSCM<<endl;

}

void curveMesh::outPutEdgeVtxClassify(pRegion region)
{
  int count0=0,count1=0,count2=0,count3=0;
  int whatInType=999;
  pPList elist = PList_new();
  elist = R_edges(region, 1);
  void *temp=0;
  pEdge edge;
  pVertex vert[2];
  double mid_pt[6][3];
  int mid_pt_count=0;
  cout<<"****** Output Edge and Vertex Info: ******"<<endl;
  cout<<"("<<P_pid()<<") Edge Classify: ";
  while(edge = (pEdge)PList_next(elist, &temp)){
    if(E_numPoints(edge)){
      pPoint pt=E_point(edge, 0);
      mid_pt[mid_pt_count][0]=P_x(pt);
      mid_pt[mid_pt_count][1]=P_y(pt);
      mid_pt[mid_pt_count++][2]=P_z(pt);
    }
    else{
      double coords[2][3];
      for(int i = 0;i <2; i++)
	V_coord(E_vertex(edge,i), coords[i]);
      for(int i = 0;i<3;i++){
	mid_pt[mid_pt_count][i]=1/2*(coords[0][i]+coords[1][i]);
      }
      mid_pt_count++;
    }
    whatInType=E_whatInType(edge);
    //if(GEN_tag(E_whatIn(edge))==9){
    //  P_setPos(pt, P_x(pt)+1.0, P_y(pt)+1.0, P_z(pt)+0.5);
    //}
    cout<<"Dim: "<<whatInType<<", ID: "<<GEN_tag(E_whatIn(edge))<<"; ";
    switch(whatInType){
    case 0: count0++;
      break;
    case 1: count1++;
      break;
    case 2: count2++;
      break;
    case 3: count3++;
      break;
    default:
      cout<<"Error -- whatInType"<<endl;
      exit(1);
      break;
    }
  }
  cout<<endl;
  cout<<"("<<P_pid()<<") Edge classified on GVertex: "<<count0<<endl;
  cout<<"                                on GEdge:   "<<count1<<endl;
  cout<<"                                on GFace:   "<<count2<<endl;
  cout<<"                                on GRegion: "<<count3<<endl<<endl;
  PList_delete(elist);

  pPList vlist = PList_new();
  vlist = R_vertices(region, 1);
  temp = 0;
  count0=0;
  count1=0;
  count2=0;
  count3=0;
  pVertex vertex;
  double xyz[4][3];
  int i=0;
  while(vertex = (pVertex)PList_next(vlist, &temp)){
    V_coord(vertex, xyz[i++]);    
  }
  temp=0;
  i=0;
  cout<<"Edge midPt Coords: "<<endl;
  for(int i=0;i<6;i++)
    cout<<"["<<mid_pt[i][0]<<", "<<mid_pt[i][1]<<", "<<mid_pt[i][2]<<"]"<<endl;
  cout<<"("<<P_pid()<<") Vertex Classify: "<<endl;
  while(vertex = (pVertex)PList_next(vlist, &temp)){
    whatInType=V_whatInType(vertex);
    cout<<"Dim: "<<whatInType<<", ID: "<<GEN_tag(V_whatIn(vertex))<<"; ";
    cout<<"["<<xyz[i][0]<<", "<<xyz[i][1]<<", "<<xyz[i][2]<<"]"<<endl;
    i++;
    switch(whatInType){
    case 0: count0++;
      break;
    case 1: count1++;
      break;
    case 2: count2++;
      break;
    case 3: count3++;
      break;
    default:
      cout<<"Error -- whatInType"<<endl;
      exit(1);
      break;
    }
  }
  cout<<endl;
  cout<<"("<<P_pid()<<") Vertex classified on GVertex: "<<count0<<endl;
  cout<<"                                  on GEdge:   "<<count1<<endl;
  cout<<"                                  on GFace:   "<<count2<<endl;
  cout<<"                                  on GRegion: "<<count3<<endl<<endl;
  PList_delete(vlist);

  cout<<" ********************************************************* "<<endl;
  

}

void curveMesh::CM_edgePropOfInvalidList()
{
  pRegion region;
  void *temp=0;
  int count=0;
  char name[32];
  while(region = (pRegion)PList_next(_invalidRgnPList, &temp)){
    outPutEdgeLength(region);
    outPutEdgeVtxClassify(region);
    sprintf(name,"invalid%d.sms",count);
    writeOutCorner(region, NULL, name);
    sprintf(name,"invalid%d",count++);
    writeRgnDataForMaple(region, name);
  }
}

void curveMesh::outPutEdgeLength(pRegion region)
{
  pPList elist = PList_new();
  elist = R_edges(region, 1);
  void *temp=0;
  pEdge edge;
  cout<<"("<<P_pid()<<") Edge Lengths: ";
  while(edge = (pEdge)PList_next(elist, &temp)) {
    cout<<E_length(edge)<<", ";
  }
  cout<<endl;
  PList_delete(elist);
}

// void curveMesh::CM_attachCrdsFromPts()
// {
//   //pMeshDataId midPtCrdsTag = MD_newMeshDataId("midPtCrds");
//   EIter edgeIter = M_edgeIter(theMesh);
//   pEdge edge;
//   pPoint pt;
//   double coords[3];
//   int temp_param3 = 0;
//   double params[3] = {0.0, 0.0, 0.0};
//   while(edge = EIter_next(edgeIter)){
//     if(E_numPoints(edge)&&E_whatInType(edge)!=3){  // if edge has high order node, attach coords to the edge
//       pt = E_point(edge,0);
//       double coords[3];
//       coords[0]=P_x(pt);
//       coords[1]=P_y(pt);
//       coords[2]=P_z(pt);
// #ifdef CURVE  // temperorily added to be able to compile with FMDB_2522. QLU, May 10, 2010
//       Ent_AttachDataPt(edge, midPtCrdsTag, coords);
//       if(E_whatInType(edge)==1)
// 	params[0] = P_param1(pt);
//       else if(E_whatInType(edge)==2)
//         P_param2(pt, params, params+1, &temp_param3);
//       Ent_AttachDataPt(edge, midPtParaTag, params);
// #endif
//       //EN_attachDataDbl(edge, midPtCrdsTag, coords);
//       //cout<<"Coords attached"<<endl;
//     }
//   }
//   EIter_delete(edgeIter); // delete iter before load balance !!!!!! otherwise seg fault  QLU
//   //return midPtCrdsTag;
// }


curveMesh::curveMesh(pMesh mesh, int modeltype, int curveType) : pThePart_(mesh), iTheMdlType_(modeltype), iTheCrvType_(curveType)
{
  //theMesh = _theMesh;
  //theCurveType = iTheCrvType_;
  _midPtCrdsTag = MD_newMeshDataId("midPtCrds");
  _midPtParaTag = MD_newMeshDataId("midPtPara");
  _onPartBdry = MD_newMeshDataId("onPartBdry");
  pNullSF_ = new NullSField();
  pResults_ = new evalResults();
  pShpMeasure_=new MeanRatio(0);

  for(int i=0; i<9; i++)
    iOpCounts_[i] = 0;

//  nullsf = pNullSF_;
//  results = pResults_;
//  shpMeasure = pShpMeasure_;
  // setting default desired to be 0.0
  _desiredShape = 0.0;
  _invalidRgnPList = PList_new();

  if(iTheMdlType_ == 1) {
    // The mesh does not have any model information 
    // a set of mesh entities have been fixed
    // 1. the only operations allowed to the fixed mesh edges, faces, regions
    //    is the split operation without changing the geometric approximation
    // 2. the colapse operation should always use the fixed vertices as the 
    //    remaing vertex
    _fixEnt = MD_newMeshDataId("fixed");
    //theModel = M_model(mesh);
  }
  else if(iTheMdlType_ == 2){
    // The mesh is classified on model entity
    pTheGMdl_ = M_model(mesh);
    //theModel = _theModel;
  }

  if(iTheCrvType_==2)
    _fixEnt = MD_newMeshDataId("fixed");

// #ifdef SIM
//   // Do not know how to delete point from mesh database
//   midpt = MD_newMeshDataId("midpt");
// #endif

}

curveMesh::~curveMesh()
{
  delete pNullSF_;
  delete pResults_;
  delete pShpMeasure_;

  MD_deleteMeshDataId(_midPtCrdsTag); 
  MD_deleteMeshDataId(_midPtParaTag);
  if(iTheMdlType_ == 1) {
    EIter eiter = M_edgeIter(pThePart_);
    pEdge ed;
    int fid;
    while(ed = EIter_next(eiter)) {
      if(EN_getDataInt((pEntity)ed, _fixEnt, &fid))
	EN_deleteData(ed, _fixEnt);
    }
    
    EIter_delete(eiter);
    
    
    MD_deleteMeshDataId(_fixEnt);
  }
  PList_delete(_invalidRgnPList);
  MD_deleteMeshDataId(_onPartBdry);
}

/*
void curveMesh::run()
{
  if(iTheCrvType_ == 1) {
    cout<<"create the higher order nodes for each edge classified on model boundaries"<<endl;
    //CMA_CreateHOEdges();
    M_writeSMS(_theMesh, "output.sms", 2);
   
  }

  createInvalidRgnList(_invalidRgnPList);
  //return;

  // testing EdgeCollapseMode in serial first
  M_writeSMS(_theMesh, "before_collapse.sms", 2);
  M_writeVTKFile(_theMesh, "before_collapse");


  pRegion region;
  double worstShape, newWorstShape;

  RIter riter = M_regionIter(_theMesh);
  while(region = RIter_next(riter)){
    crShpInfo *csi = new crShpInfo;
    CR_isValid(region, csi);
    worstShape = csi->shape;
    // edge collapse 
    edgeCollapsMod *clps = new edgeCollapsMod(_theMesh, pNullSF_, pShpMeasure_, pResults_);
    
//    if(isEdgeClpsModValid(clps, region, worstShape)){
      if(0){
#ifdef CRVDEBUG
      cout<<"Edge Collapse Mode is valid, !!!";
#endif
      	// test Common boundary
      if(EN_onCB((pEntity)clps->edgeD()))
#ifdef CRVDEBUG
	cout<<"edge to be collapsed is on Common Boundary"<<endl;
#endif     
      newWorstShape = pResults_->getWorstShape();
      if(newWorstShape > worstShape){
	worstShape = newWorstShape; 
#ifdef CRVDEBUG
	cout<<"shape will be improved";
#endif   
	// test to apply an edge collapse
	pMeshMod pBestModTmp = clps;
      }
      
#ifdef CRVDEBUG
      cout<<endl;
#endif   
    }
    else{
#ifdef CRVDEBUG
      cout<<"Edge Collapse Mode is NOT valid, ###";
#endif
      if(EN_onCB((pEntity)clps->edgeD())){
#ifdef CRVDEBUG
	cout<<"edge to be collapsed is on Common Boundary";
#endif
	
	cout<<E_whatInType(clps->edgeD())<<"    "<<GEN_tag(E_whatIn(clps->edgeD()))<<endl;
	//test migration
	std::list<pVertex> vtOnCB;
	pVertex vert1 = E_vertex(clps->edgeD(),0);
	pVertex vert2 = E_vertex(clps->edgeD(),1);
	cout<<"Got vert2"<<endl;
	vtOnCB.push_back(vert1);
	vtOnCB.push_back(vert2);
	std::vector<pEntity> newVt;
	std::vector<pEntity> rmVt;
	std::vector<pEntity>::iterator vIt;
	std::vector<pEntity> dummy;
	std::vector<pEntityGroup> dummyEG;
	//pmMigrationCallbacks userLB;
	zoltanCB zcb;
	curveMigrateCB crvCB;
	M_writeVTKFile(_theMesh,"mesh_out_before_migration");
	M_writeSMS(_theMesh,"mesh_out_before_migration.sms",2);
	cout<<"calling M_migration"<<endl;
	M_migration(_theMesh,0,vtOnCB,crvCB,0,rmVt,newVt,-1,dummy,dummy,dummyEG,dummyEG); // API changed by FMDB, need modifications here   QLU, May 9, 2010
	//CM_setPtsFromCrds();
	M_writeVTKFile(_theMesh,"mesh_out_after_migration");
	M_writeSMS(_theMesh,"mesh_out_after_migration.sms",2);
	break;
	
      }
      delete clps;
#ifdef CRVDEBUG
      cout<<endl;
#endif
    }
  }


  RIter_delete(riter);
  worstShape = 999;
  RIter riter2 = M_regionIter(_theMesh);
  while(region = RIter_next(riter2)){
    crShpInfo *csi = new crShpInfo;
    CR_isValid(region, csi);
    if(csi->shape<=worstShape)
      worstShape=csi->shape;
#ifdef CRVDEBUG
    cout<<"shape: "<<csi->shape<<endl;
#endif
    delete csi;
  }
#ifdef CRVDEBUG
  cout<<"{{{{{{{{{{{{{WORSTSHAPE:}}}}}}}}}}} "<<worstShape<<endl;
#endif
  worstShape=999;

  RIter_reset(riter2);
  while(region = RIter_next(riter2)){
    crShpInfo *csi = new crShpInfo;
    CR_isValid(region, csi);
    worstShape = csi->shape;
    // edge collapse 
    edgeCollapsMod *clps = new edgeCollapsMod(_theMesh, pNullSF_, pShpMeasure_, pResults_);
    
//    if(isEdgeClpsModValid(clps, region, worstShape)){
      if(0){
#ifdef CRVDEBUG
      cout<<"Edge Collapse Mode is valid, !!!";
#endif   
      	// test Common boundary
      if(EN_onCB((pEntity)clps->edgeD()))
#ifdef CRVDEBUG
	cout<<"edge to be collapsed is on Common Boundary"<<endl;
#endif       
      newWorstShape = pResults_->getWorstShape();
      //if(newWorstShape > worstShape){
	worstShape = newWorstShape; 
#ifdef CRVDEBUG
	cout<<"shape will be improved";
#endif
	// test to apply an edge collapse
	pMeshMod pBestModTmp = clps;
	//applyBestMod(&pBestModTmp);

	if(GEN_tag(E_whatIn(clps->edgeD()))==26){
          cout<<V_whatInType(E_vertex(clps->edgeD(),0))<<"    "<<GEN_tag(V_whatIn(E_vertex(clps->edgeD(),0)))<<endl;
          cout<<V_whatInType(E_vertex(clps->edgeD(),1))<<"    "<<GEN_tag(V_whatIn(E_vertex(clps->edgeD(),1)))<<endl;
	  clps->apply();
	  cout<<"edge collapse applied"<<endl;
	  
	  break;
	}


	

	//}
#ifdef CRVDEBUG     
      cout<<endl;
#endif
    }
  }

  RIter_delete(riter2);
  worstShape=999;
  RIter riter3 = M_regionIter(_theMesh);
  while(region = RIter_next(riter3)){
    crShpInfo *csi = new crShpInfo;
    CR_isValid(region, csi);
    if(csi->shape<=worstShape)
      worstShape=csi->shape;
#ifdef CRVDEBUG
    cout<<"shape: "<<csi->shape<<endl;
#endif
    delete csi;
  }
#ifdef CRVDEBUG
  cout<<"{{{{{{{{{{{WORSTSHAPE: }}}}}}}}}}}}  "<<worstShape<<endl;
#endif
  RIter_delete(riter3);

  M_writeSMS(_theMesh, "after_collapse.sms", 2);
  //exit(0);

}
*/

void curveMesh::createRgnsToProcess(double dThreshold, int iOption)
{
  //int count=0; //for debug purpose
  //char invalid[32];
  _GWORSTSHAPE=999999;
  // check invalid regions
  RIter riter = M_regionIter(pThePart_);
  int flag;
  pRegion rgn;
  while(rgn = RIter_next(riter)){
    crShpInfo *csi = new crShpInfo;
    flag = curveUtil::CR_isValid(rgn,csi);
    
    if(csi->shape < _GWORSTSHAPE)
      _GWORSTSHAPE = csi->shape;
    if(csi->shape <= dThreshold){
      _crvdRgnMapToProcess[rgn] = csi;
    }
    else
      delete csi;
  }
  RIter_delete(riter);
#ifdef DEBUG
  cout<<"[Total number of curved regions to be processed:] "<<_crvdRgnMapToProcess.size()<<endl;
#endif
  return;
}


// void curveMesh::CM_setPtsFromCrds()
// {
//   //midPtCrdsTag = MD_newMeshDataId("midPtCrds");
//   EIter edgeIter = M_edgeIter(_theMesh);
//   pEdge edge;
//   //double coords[3];
//   while(edge = EIter_next(edgeIter)){

//     if(!E_numPoints(edge)){
//       double *coords = new double[3];
//       double *params = new double[3];
// #ifdef CURVE    // temperorily added to be able to compile with FMDB_2522. QLU, May 10, 2010
//       if(Ent_GetDataPt(edge, _midPtCrdsTag, coords)){  // if edge has mid point coords tag, attach coords to the edge
// 	//cout<<"got data, setting up edge node!!"<<endl;
// 	pPoint pt = P_new();
// 	P_setPos(pt, coords[0], coords[1], coords[2]);
// 	//cout<<coords[0]<<", "<<coords[1]<<", "<<coords[2];
// 	E_setPoint(edge, pt);
//        	if(Ent_GetDataPt(edge, _midPtParaTag, params)){   // if edge has param tag       
//  	   AOMD_P_setParametricPos(pt, params[0], params[1], params[2]);
// 	}	
//       }  
// #endif
//     }
//     //  else
// //       delete coords;
//   }
//   EIter_delete(edgeIter); // delete iter before load balance !!!!!! otherwise seg fault  QLU
// }

void writeOutCorner(pRegion region, pVertex vertex, char* name){
  /*
    to be implemented
  */ 
  pPList vlist;
  pPList elist;
  pPList flist;

  flist = PList_new();
  elist = PList_new();
  vlist = PList_new();
 
  void *temp;
  // find the vertices of the region
  vlist = R_vertices(region, 1);

  // find the edges of the region
  elist = R_edges(region, 1);
 
  // adding faces to the list
  for(int i=0; i<4; i++)
    PList_appUnique(flist, R_face(region, i));

  // write .sms file in FMDB format. refer to writeOutCurvedRList()

  pMeshDataId vid = MD_newMeshDataId("vid");
  int count = 1, j;
  int numV, numE, numF, numR;
  temp = 0;
  pVertex v;
  while(v = (pVertex)PList_next(vlist, &temp)) 
    EN_attachDataInt((pEntity)v, vid, count++);
  
  numV = PList_size(vlist);
  numE = PList_size(elist);
  numF = PList_size(flist);
  //numR = PList_size(*rlist);

  numR = 1;

  FILE* outFile = fopen(name, "w");
  fprintf(outFile, "sms 2\n");
  fprintf(outFile, "%d %d %d %d %d\n", numR, numF, numE, numV, numV);

  temp=0;
  double loc[3];
  int gentag = 1;
  int gentitytype = 2;
  while(v = (pVertex)PList_next(vlist, &temp)) {
    V_coord(v, loc);
    fprintf(outFile, "%d %d %d\n%.15f %.15f %.15f ",
                      gentag++, gentitytype, 3, 
		      loc[0], loc[1], loc[2]); 	
    fprintf(outFile, "%d %d %d", 0, 0, 0);    
    fprintf(outFile, "\n"); 
  }
  
  temp=0;
  gentitytype = 2;
  pEdge e;
  int id;
  count = 1;
  while(e = (pEdge)PList_next(elist, &temp)) {
    fprintf(outFile, "%d %d ",  gentag++, gentitytype);
    EN_attachDataInt(e, vid, count++);
    for(j=0; j<2; j++) {
      v=E_vertex(e, j);
      EN_getDataInt(v, vid, &id);
      fprintf(outFile, "%d ",id);
    }
    fprintf(outFile, "%d ", 2);
    fprintf(outFile, "%d\n", 1);
    if(E_numPoints(e)) {
      pPoint pt = E_point(e, 0);
      fprintf(outFile,"%.15f %.15f %.15f ",P_x(pt), P_y(pt), P_z(pt));
      //E_bezierCtrlPt(e, loc);
      //fprintf(outFile,"%.15f %.15f %.15f ",loc[0], loc[1], loc[2]);

      fprintf(outFile, "0 0 0");
      fprintf(outFile, "\n");
    }
    else {
      E_bezierCtrlPt(e, loc);
      fprintf(outFile,"%.15f %.15f %.15f ",loc[0], loc[1], loc[2]);
      fprintf(outFile, "0 0 0");
      fprintf(outFile, "\n");
    }
  }
  
  pFace f;
  count=1;
  temp = 0;
  gentitytype = 2;
  while(f=(pFace)PList_next(flist, &temp)) {
    EN_attachDataInt(f, vid, count++);
    fprintf(outFile, "%d %d ", GEN_tag(F_whatIn(f)), gentitytype);
    int numEdges=3;
    fprintf(outFile, "%d ", numEdges);
    for (j=0; j<numEdges ;j++)
    {
      e = F_edge(f,j);
      EN_getDataInt(e, vid, &id);
      if (!F_edgeDir(f,j)) id=-id;
      fprintf(outFile, "%d ", id);
    }
    fprintf(outFile, "0\n");
  }
 
  //numFaces=R_numFaces(region);
      //ofs << gentid+1 << " " << numFaces << " ";
  fprintf(outFile, "%d %d ",  1, 4);       
  for (j=0; j<4 ;j++)
  {
    f = R_face(region,j);
    EN_getDataInt(f, vid, &id);
    if (!R_faceDir(region,j)) id=-id;
    //ofs << ID << " ";
    fprintf(outFile, "%d ", id);
  }
  //ofs << "0\n";
  fprintf(outFile, "0\n");

 
  fclose(outFile);

  temp = 0;
  while(v = (pVertex)PList_next(vlist, &temp)) 
    EN_deleteData((pEntity)v, vid);
  temp=0;
  while(e = (pEdge)PList_next(elist, &temp)) 
    EN_deleteData((pEntity)e, vid);
  temp=0;
  while(f = (pFace)PList_next(flist, &temp)) 
    EN_deleteData((pEntity)f, vid);
  
  MD_deleteMeshDataId(vid);

  PList_delete(vlist);
  PList_delete(elist);
  PList_delete(flist);
  return;
}

int curveMesh::CMA_UncurveInvalidRgns()
{
  int iSuccess = 1;
  unCurveInvalidRgns();
  return iSuccess;
}

void curveMesh::unCurveInvalidRgns()
{
  double threshhold = 0.0;
 
  createInvalidRgnList(_invalidRgnPList);
 
  if(PList_size(_invalidRgnPList))
    cout<<"Created PList _invalidRgnPList: "<<PList_size(_invalidRgnPList)<<endl;
  int isPerformed = 0, count = 0, index, Iter=0, isBdyEdge=0, countBdy=0;
  double shape;
  crShpInfo *csi = new crShpInfo;
  void *temp;
  pRegion region, neighborRegion;
  pEdge edge;
  double xyz[3], xyz_ori[3];
  pPoint pt;
  while(PList_size(_invalidRgnPList) && Iter < 20) {
    temp = 0;
    while(region = (pRegion)PList_next(_invalidRgnPList, &temp)){

      // have to ensure the underlying linear frame is valid
      assert(R_volume(region)>0.0);

      //DEBUG
//      CR_isValid(region, csi);
//      cout<<"Shape Quality before uncurving: "<<csi->shape<<endl;
//      cout<<"csi->index: "<<csi->index<<endl;
// skip the ones on part boundary
#ifdef MA_PARALLEL
      if(CR_isOnPartBdry(region)){
        //cout<<"Found region to be processed on Part Bdry... "<<endl;
	//miter++;
        continue;
        //isOnPB = 1;
      }
#endif
      ///////
      pPList elist = R_edges(region, 1);
      isBdyEdge=0;
      for(int i=0; i<6; i++) {
	edge = (pEdge)PList_item(elist, i);
	if(E_whatInType(edge)!=3)
	  isBdyEdge=1;
	E_middleStPt(edge, xyz);
	if(E_numPoints(edge)) {
	  pt = E_point(edge, 0);
          xyz_ori[0] = P_x(pt);
          xyz_ori[1] = P_y(pt);
          xyz_ori[2] = P_z(pt);
	
//	  cout<<setprecision(10)<<P_x(pt)<<", "<<P_y(pt)<<", "<<P_z(pt)<<endl;
	  P_setPos(pt, xyz[0], xyz[1], xyz[2]);
          //P_setPos(pt, (xyz[0]+xyz_ori[0])/2, (xyz[1]+xyz_ori[1])/2, (xyz[2]+xyz_ori[2])/2);
//	  cout<<setprecision(10)<<P_x(pt)<<", "<<P_y(pt)<<", "<<P_z(pt)<<endl;
	}
      }	
      
      if(!CR_isValid(region, csi)) {
	cout<<"Found invalid linear region in curveMesh::unCurvedInvalidRgns()"<<endl;
      }
      else{
        cout<<"Shape Quality after uncurving: "<<csi->shape<<endl;
        double AR = 0.0; 
        slacUtil::SU_AspectRatio(region, AR);
        cout<<"Aspect Ratio:                  "<<AR<<endl;
        char name[32];
        sprintf(name, "uncurved-%d.txt", count);
        writeRgnDataForMaple(region, name);
        // the geomCheck for regionCollapsMod accepts flatAngle greater than the user-input value
        regionCollapsMod *rclps = new regionCollapsMod(pThePart_, pNullSF_, region, 90, pResults_);
        rclps->setCurved();
        rclps->setModelType(NOPARAM);
        //assert(rclps->topoCheck());
        //assert(rclps->geomCheck());
        rclps->apply();
      }
      count++;
      if(isBdyEdge)
	countBdy++;
      // check the validity of the connected regions
      for(int i=0; i<6; i++) {
	edge = (pEdge)PList_item(elist, i);
	pPList rlist = E_regions(edge);
	
	for(int j=0; j<PList_size(rlist); j++) {
	  neighborRegion = (pRegion)PList_item(rlist, j);
	  if(neighborRegion == region)
	    continue;

	  if(!CR_isValid(neighborRegion, csi)) {
	    PList_appUnique(_invalidRgnPList, neighborRegion);
	  }
	}
	PList_delete(rlist);

	PList_remItem(_invalidRgnPList, region);
      }
      PList_delete(elist);
    }

    Iter++;
    
  }
  
  if(count){
    cout<<"Uncurve "<<count<<" invalid regions, out of which "<<countBdy<<" is on model boundary"<<endl;
  //createRgnsToProcess(threshhold);
    createInvalidRgnList(_invalidRgnPList);
    cout<<"Created PList invalidRgnPList: "<<PList_size(_invalidRgnPList)<<endl;
  }
}

//
// create the invalid region list
//

void curveMesh::CM_createInvalidRgnList()
{
  createInvalidRgnList(_invalidRgnPList);
}

void curveMesh::createInvalidRgnList(pPList &rlist)
{
  // clean up the list container
 
  PList_delete(rlist);
  rlist = PList_new();
  cout<<"Initiate Invalid Rgn List: "<<PList_size(rlist)<<endl;
 
  // check the invalid regions
  int index;
  double shape;
  RIter riter = M_regionIter(pThePart_);
  pRegion rgn;
  crShpInfo *csi = new crShpInfo;
  int count = 0;
  while(rgn = RIter_next(riter)){
    CR_isValid(rgn, csi);
    if(csi->shape<=_desiredShape)
      PList_appUnique(rlist, rgn);
   
  }
  RIter_delete(riter);
 
  cout<<"Total invalid curved regions: "<<PList_size(rlist)<<endl;

  return;
}

void curveMesh::CM_CreateInvalidRgnVec(std::vector<pRegion> &InvalidRgnVec, int option){
  
  if(InvalidRgnVec.size()){
    throw new mException(__LINE__,__FILE__,"Size of InvalidRgnVec is not zero to begin with! ");
  }
  
  double shape;
  RIter riter = M_regionIter(pThePart_);
  pRegion rgn;
  crShpInfo *csi = new crShpInfo;
  int count = 0;
  while(rgn = RIter_next(riter)){
    CR_isValid(rgn, csi);
    double shape;
    switch(option){
    case 0:
      shape = csi->shape;
      break;
    case 1:
      shape = csi->qs;
      break;
    case 2:
      shape = csi->qc;
      break;
    default:
      throw new mException(__LINE__, __FILE__, "Shape metric not supported! ");
    }
    if(shape<=0.0)
      InvalidRgnVec.push_back(rgn);
      
  }
  RIter_delete(riter);
  delete csi;
}

void curveMesh::CM_CreatePoorRgnVec(std::vector<pRegion> &PoorRgnVec, int option){
  
  if(PoorRgnVec.size()){
    throw new mException(__LINE__,__FILE__,"Size of PoorRgnVec is not zero to begin with! ");
  }
  
  if(_RgnShapeThresh==0.0)
    adaptUtil::Warning("_CM_RgnShapThresh was set to 0.0, and not updated");

  double shape;
  RIter riter = M_regionIter(pThePart_);
  pRegion rgn;
  crShpInfo *csi = new crShpInfo;
  int count = 0;
  while(rgn = RIter_next(riter)){
    CR_isValid(rgn, csi);
    double shape;
    switch(option){
    case 0:
      shape = csi->shape;
      break;
    case 1:
      shape = csi->qs;
      break;
    case 2:
      shape = csi->qc;
      break;
    default:
      throw new mException(__LINE__, __FILE__, "Shape metric not supported! ");
    }
    if(shape<=_RgnShapeThresh)
      PoorRgnVec.push_back(rgn);
      
  }
  RIter_delete(riter);
  delete csi;
}


void E_middleStPt(pEdge edge, double *xyz)
{
  double vxyz[2][3];
  V_coord(E_vertex(edge, 0), vxyz[0]);
  V_coord(E_vertex(edge, 1), vxyz[1]);

  for(int i=0; i<3; i++)
    xyz[i] = 0.5*(vxyz[0][i] + vxyz[1][i]);
}
/*
int R_worstShape(pPList *erlist, double &worstShape, double &worstInvalidShape, pPList *invalidRList)
{
  void *iter;
  iter = 0;
  pRegion region;
  crShpInfo csi;
  int ok = 1;
  double shape = BIG_NUMBER, ishape =  BIG_NUMBER;

  while(region = (pRegion)PList_next(*erlist, &iter)) {
    if(!CR_isValid(region, &csi)) {
      ok = 0;
      PList_appUnique(*invalidRList, region);
      if(csi.shape < ishape)
	ishape = csi.shape;
    }
    else {
      if(csi.shape < shape)
	shape = csi.shape;
    }
  }

  worstShape = shape;
  
  if(!PList_size(*invalidRList)) { 
    worstInvalidShape = shape;
  }
  else
    worstInvalidShape = ishape;

  return ok;
}
*/
