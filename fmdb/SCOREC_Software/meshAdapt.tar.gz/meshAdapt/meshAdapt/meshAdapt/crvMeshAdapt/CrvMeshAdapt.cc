/*
  codes for curved mesh adaptation
*/

#include "MeshAdapt.h"
#include "paraAdapt.h"
#include "templateUtil.h"
#include "EdgeCollapsMod.h"
#include "EdgeSwapMod.h"
#include "SplitCollapsMod.h"
#include "RegionCollapsMod.h"
#include "DSplitClpsMod.h"
#include "EdgeSplitMod.h"
#include "FaceSwapMod.h"
#include "AdaptUtil.h"
#include "meanRatio.h"
#include "Macros.h"
#include "fromMeshTools.h"
#include "NullSField.h"
#include "visUtil.h"
#include "PList.h"
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <math.h>
#include <vector>
#include "predLB.h"
#include "ParUtil.h"
#include <list>
#include <set>

//#include "M_writeVTKFile.h"

#include "modeler.h"
#include "pbcOnGFace.h"
#include "pbcOnGEdge.h"
#include "FMDB.h"

#include "pmModel.h"

#include "BLUtil.h"

#ifdef CURVE
#include "curveMesh.h"
#include "curveUtil.h"
using namespace curveUtil;
//using namespace adaptUtil;
#endif //CURVE

using std::vector;
using std::cout;
using std::cerr;
using std::endl;
using std::list; 
using std::set; 


#ifdef MVTK
#include "mvtk.h"
#endif

#ifdef AOMD_
#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#include "pbcOnGEdge.h"
#ifdef PARALLEL
#include "SF_MigrationCallbacks.h"
#include "pmMeshAdapt.h"
#endif /* PARALLEL */
#endif /* AOMD_ */

#ifdef CURVE

struct CurvedRegionShapeInfo;
typedef struct CurvedRegionShapeInfo crShpInfo;

int curveMesh::CMA_LockSurfaceMesh()
{
  // assert no CAD model available
  assert(iTheMdlType_==1);

  FIter fiter = M_faceIter(pThePart_);
  pFace face;
  pEdge edge;

  while(face = FIter_next(fiter)) {
    if(F_whatInType(face) == 2) {
      for(int i=0; i<3; i++) {
        edge = F_edge(face, i);
        fix_entity((pEntity)edge);
      }
    }
  }

  FIter_delete(fiter);


  return 1;
}

// delete the higher order nodes
int curveMesh::CMA_ClearHONodes()
{
  int iSuccess = 1;
  cout<<"Calling CMA_ClearHONodes()"<<endl;
  EIter edgeIt = M_edgeIter(pThePart_);
  pEdge edge;
  pPoint pt;

  while(edge = EIter_next(edgeIt)){
    if(E_numPoints(edge)){
      pt = E_point(edge, 0);
      P_delete(pt);
    }
  }

  EIter_delete(edgeIt);

  return iSuccess;

}

// create higher order nodes for mesh edges
int curveMesh::CMA_CreateHOEdges()
{
 
  int iSuccess = 1;

  EIter edgeIt = M_edgeIter(pThePart_);
  pEdge edge;
  pPoint pt;
  double xyz[] = {0.0, 0.0, 0.0}; 
  double par[] = {0.0, 0.0, 0.0};

  while(edge = EIter_next(edgeIt)) {
    if(E_whatInType(edge) != 3) { 
      templatesUtil::middlePoint(edge,0.5,xyz,par);
      if(E_numPoints(edge))
	pt = E_point(edge, 0);
      else
	pt = P_new();
      P_setPos(pt, xyz[0], xyz[1], xyz[2]);
      E_setPoint(edge, pt);
      FMDB_P_setParametricPos(pt, par[0], par[1], par[2]);
    }
  }
  EIter_delete(edgeIt);

  return iSuccess;
}


int meshAdapt::CMA_ClearEdgeVecToClps()
{
  _EdgeVecToClps.clear();
  return 1;
}


int meshAdapt::CMA_ClearEdgeVecToSplit()
{
  _EdgeVecToSplit.clear();
  return 1;
}


 
int meshAdapt::CMA_CheckVtxParamCoords(int myrank)
{
  if(model_type!=2){
    cout<<"["<<myrank<<"]: Not a parametric model type, no need to check vtx param coords." <<endl;
    return 1;

  }
  VIter vtxIt = M_vertexIter(pmesh);
  double param[3];
  //int tmp;
  while(pVertex vertex = VIter_next(vtxIt)){
    //cout<<myrank<<": "<<vertex->getUid()<<": "<<P_x(vertex)<<", "<<P_y(vertex)<<", "<<P_z(vertex);
    switch (V_whatInType(vertex)) {
    case 1:
      //cout<<" On GEdge: ";
      param[0]=P_param1(V_point(vertex));
      //cout<<param[0]<<endl;
      break;
    case 2:
      //cout<<" On GFace: ";
      P_param2(V_point(vertex), &param[0], &param[1], (int*)&param[2]);
      //cout<<param[0]<<", "<<param[1]<<endl;
      break;
    default:
      //cout<<endl;
      break;
    }
  }
  
  VIter_delete(vtxIt);

}

int meshAdapt::CMA_CalcMinMaxAve(double &Min, double &Max, double &Ave)
{ 
  double MinEdgeLength=999.9;
  double MaxEdgeLength=-999.9;
  double AveEdgeLength=0.0;
  int CountOnPart = 0;

  EIter EdgeIt = M_edgeIter(pmesh);
  while(pEdge edge = EIter_next(EdgeIt)){
    if(EN_owner(edge)==_iMyRank){ // if I am the owner of this entity 
      double EdgeLength = E_length(edge);
      AveEdgeLength += EdgeLength;
      if(EdgeLength > MaxEdgeLength){
	MaxEdgeLength = EdgeLength;
      }
      if(EdgeLength < MinEdgeLength){
	MinEdgeLength = EdgeLength;
      }
      CountOnPart++;
    }// end -- if(EN_owner(edge)==iMyRank)
  }// end --  while(pEdge edge = EIter_next(EdgeIt))
  EIter_delete(EdgeIt);
#ifdef DEBUG
  cout<<"("<<_iMyRank<<") Max Edge Length: "<< MaxEdgeLength <<endl;
  cout<<"("<<_iMyRank<<") Min Edge Length: "<< MinEdgeLength <<endl;
  cout<<"("<<_iMyRank<<") Ave. Edge Length: "<< AveEdgeLength/CountOnPart <<endl;
#endif //DEBUG
  Min=MinEdgeLength;
  Max=MaxEdgeLength;
  Ave=AveEdgeLength/CountOnPart;
#ifdef MA_PARALLEL
  /* calc global sum of edge length */
  double GlobalAve;
  double GlobalMax;
  double GlobalMin;
  int GlobalCount;

  MPI_Allreduce(&AveEdgeLength, &GlobalAve, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
  /* total number of edges */
  MPI_Allreduce(&CountOnPart, &GlobalCount, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
  /* global max of edge length */ 
  MPI_Allreduce(&MaxEdgeLength, &GlobalMax, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
  /* global min of edge length */
  MPI_Allreduce(&MinEdgeLength, &GlobalMin, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);

  Min = GlobalMin;
  Max = GlobalMax;
  Ave = GlobalAve/GlobalCount;
#endif

  return 1;

}// end -- meshAdapt::CMA_CalcMinMaxAve()

int meshAdapt::CMA_FixInvalidRgnsByTopoMods(curveMesh *TheCrvMesh)
{
  cout<<"Calling FixInvalidRgnsByTopoMods"<<endl;
  _EdgeVecToClps.clear();
  // first create the invalid region list
  //TheCrvMesh->CrvMesh_createInvalidRgnList();
  std::vector<pRegion> InvalidRgnVec;
 
  TheCrvMesh->CM_CreateInvalidRgnVec(InvalidRgnVec, 1);
  //pPList pInvalidRgnList = TheCrvMesh->CrvMesh_getInvalidRgnList();
  void *Iter = 0;
  double TheShortestEdgeLength;
  pEdge TheShortestEdge; 
  //while(pRegion InvalidRgn = (pRegion)PList_next(pInvalidRgnList, &Iter)){
  for(int i=0; i<InvalidRgnVec.size(); i++){
    pRegion InvalidRgn=InvalidRgnVec[i];
    pPList elist = R_edges(InvalidRgn, 1);
    TheShortestEdge = (pEdge)PList_item(elist, 0);
    TheShortestEdgeLength = E_length(TheShortestEdge);

    _EdgeVecToClps.push_back(TheShortestEdge);

    for(int i=1;i<6;i++){
      pEdge edge = (pEdge)PList_item(elist, i);
      
      _EdgeVecToClps.push_back(edge);

      double length = E_length(edge);
      if(length < TheShortestEdgeLength){
	TheShortestEdge = edge;
	TheShortestEdgeLength = length;
      }
      
    } //end for
#ifdef DEBUG
    // InvalidRgn->print();
    cout<<"("<<_iMyRank<<") TheShortestEdgeLength: "<<TheShortestEdgeLength<<endl;
#endif
    //_EdgeVecToClps.push_back(TheShortestEdge);
  } // end while

}

int meshAdapt::CMA_FixPoorRgnsByTopoMods(curveMesh *TheCrvMesh)
{
  cout<<"Calling FixPoorRgnsByTopoMods"<<endl;
  _EdgeVecToClps.clear();
  // first create the invalid region list
  //TheCrvMesh->CrvMesh_createInvalidRgnList();
  std::vector<pRegion> PoorRgnVec;
 
  TheCrvMesh->CM_CreatePoorRgnVec(PoorRgnVec, 1);
  //pPList pInvalidRgnList = TheCrvMesh->CrvMesh_getInvalidRgnList();
  void *Iter = 0;
  double TheShortestEdgeLength;
  pEdge TheShortestEdge; 
  //while(pRegion InvalidRgn = (pRegion)PList_next(pInvalidRgnList, &Iter)){
  for(int i=0; i<PoorRgnVec.size(); i++){
    pRegion PoorRgn=PoorRgnVec[i];
    pPList elist = R_edges(PoorRgn, 1);
    TheShortestEdge = (pEdge)PList_item(elist, 0);
    TheShortestEdgeLength = E_length(TheShortestEdge);

    _EdgeVecToClps.push_back(TheShortestEdge);

    for(int i=1;i<6;i++){
      pEdge edge = (pEdge)PList_item(elist, i);
      
      _EdgeVecToClps.push_back(edge);

      double length = E_length(edge);
      if(length < TheShortestEdgeLength){
	TheShortestEdge = edge;
	TheShortestEdgeLength = length;
      }
      
    } //end for

    // consider the edges connected to the vertices

    // pPList vlist = R_vertices(PoorRgn, 1);
//     for(int i=0;i<4;i++){
//       pVertex vert = (pVertex)PList_item(vlist, i);
//       pPList elist = V_edges(vert);
//       for(int j=0; j<PList_size(elist);j++){
// 	pEdge edge = (pEdge)PList_item(elist, j);
// 	vector<pEdge>::iterator EdgeVecIt = _EdgeVecToClps.begin();
// 	int isNewEdge = 1;
// 	for(; EdgeVecIt!=_EdgeVecToClps.end(); EdgeVecIt++){
// 	  if(*EdgeVecIt==edge){
// 	    isNewEdge = 0;
// 	    break;
// 	  }
// 	}
// 	if(isNewEdge)
// 	  _EdgeVecToClps.push_back(edge);
//       }
//     }
#ifdef DEBUG 
    // PoorRgn->print();
    cout<<"("<<_iMyRank<<") TheShortestEdgeLength: "<<TheShortestEdgeLength<<endl;
#endif
    //_EdgeVecToClps.push_back(TheShortestEdge);
  } // end while

}

int meshAdapt::CMA_TagEdgeWithLargeCurve()
{
  EIter EdgeIt = M_edgeIter(pmesh);
  while(pEdge edge = EIter_next(EdgeIt)){
    if(EN_owner(edge)==_iMyRank&&E_numPoints(edge)){
      pPoint pt=E_point(edge, 0);
      double StPtCrds[3];
      E_middleStPt(edge, StPtCrds);
      double CrvPtCrds[3];
      CrvPtCrds[0] = P_x(pt);
      CrvPtCrds[1] = P_y(pt);
      CrvPtCrds[2] = P_z(pt);
      double dist = P_length(StPtCrds, CrvPtCrds);
      double VCrds[2][3];
      V_coord(E_vertex(edge, 0), VCrds[0]);
      V_coord(E_vertex(edge, 1), VCrds[1]);
      double length = P_length(VCrds[0], VCrds[1]);
      if(dist/length>=0.2)
	setAdaptLevel(edge, 1);
    }
    
 
  }
  //unifyTaggedEntities(_SplitEdge, &taggedCBEdgeList);

  EIter_reset(EdgeIt);
  return 1;
}

int meshAdapt::CMA_CreateEdgeVecs(double UpperBound, double LowerBound)
{
  _EdgeVecToSplit.clear();
  _EdgeVecToClps.clear();

  std::list<pEntity> taggedCBEdgeList;

  EIter EdgeIt = M_edgeIter(pmesh);
  while(pEdge edge = EIter_next(EdgeIt)){
    double EdgeLength = E_length(edge);
    if(EdgeLength >= UpperBound){ 
      if(EN_owner(edge)==_iMyRank){
	
	setAdaptLevel(edge,1);

      }
    }
    if(EdgeLength <= LowerBound){
      //_EdgeVecToClps.push_back(edge);
    }
   
  }
  //unifyTaggedEntities(_SplitEdge, &taggedCBEdgeList);

  EIter_reset(EdgeIt);
  //int value;
  //while(pEdge edge = EIter_next(EdgeIt)){
    //if(EN_getDataInt((pEntity)edge, _SplitEdge, &value)){
    //  _EdgeVecToSplit.push_back(edge);
    //  EN_deleteData((pEntity)edge, _SplitEdge);
  // }
  //}
  
  EIter_delete(EdgeIt);  
#ifdef DEBUG
  cout<<"("<<_iMyRank<<") Created Edge Vec to split, size :"<<_EdgeVecToSplit.size()<<endl;
  cout<<"("<<_iMyRank<<") Created Edge Vec to claps, size :"<<_EdgeVecToClps.size()<<endl;
#endif //DEBUG
  
  return 1;
}

int meshAdapt::CMA_ProcessEdgeVecToClps()
{
#ifdef MA_PARALLEL
  std::list<pVertex> vtOnCB;
  std::vector<pEntity> newVt;
  std::vector<pEntity> rmVt;
  std::vector<pEntity> dummy;
  std::vector<pEntityGroup> dummyEG;

  curveMigrateCB crvCB;
  zoltanCB zcb;
  for(int Index = 0 ; Index < _EdgeVecToClps.size() ; Index++){
    pEdge edge = _EdgeVecToClps[Index];
    if(!edge)
      continue;
    pVertex vert0 = E_vertex(edge, 0);
    pVertex vert1 = E_vertex(edge, 1);
#ifdef DEBUG
    // status of the edge to be clpsd
    cout<<"("<<_iMyRank<<") Status of the edge: "<<endl;
    // edge->print();
    cout<<"("<<_iMyRank<<") And its length: "<<E_length(edge)<<endl;
   
    // vert0->print();
    // vert1->print();
#endif //DEBUG

    // set up edge collapse mod

    edgeCollapsMod *clps = new edgeCollapsMod(pmesh,pSizeField,shpMeasure,result);
    clps->setCallback(function_CB,userData_CB);
    clps->setCurved();
    clps->setModelType(PARAM);
    clps->setAcptControl(1);
   

    
    // restrict to collapse edges on model boundary only -- testing purpose
    // if(E_whatInType(edge)==3)
//       continue;
    
    // check if edge or its vertices are on common part boundary
    if(EN_onCB(edge)||EN_onCB(E_vertex(edge,0))||EN_onCB(E_vertex(edge,1))){
      cout<<"("<<_iMyRank<<") CMA_ProcessEdgeVecToClps -- edge to be collapsed is on Part Boundary "<<endl;
      pVertex vert1 = E_vertex(edge,0);
      pVertex vert2 = E_vertex(edge,1);
      if(EN_onCB(E_vertex(edge,0)))
	vtOnCB.push_back(vert1);
      if(EN_onCB(E_vertex(edge,1)))
	vtOnCB.push_back(vert2);
      continue;
      //break;
    }

    // if edge is interior to the local part
    clps->setCollaps(edge, vert1, vert0);
    if(clps->topoCheck()){
      if(clps->geomCheck()){
        clps->apply();
        cout<<"("<<_iMyRank<<") Edge Collapse applied -- 1"<<endl;
        break;
      }
      else
        cout<<"("<<_iMyRank<<") geomCheck failed -- 1 ! "<<endl;
    }
    else
      cout<<"("<<_iMyRank<<") topoCheck failed -- 1 ! "<<endl;
    
    // try the other way round
    clps->setCollaps(edge, vert0, vert1);    
    if(clps->topoCheck()){
      if(clps->geomCheck()){
	clps->apply();
	cout<<"("<<_iMyRank<<") Edge Collapse applied -- 2"<<endl;
	break;
      }
      else
	cout<<"("<<_iMyRank<<") geomCheck failed -- 2 ! "<<endl;
    }
    else
      cout<<"("<<_iMyRank<<") topoCheck failed -- 2 !"<<endl;
    
    
    delete clps;
  } // end for

  // call migration
  if(!M_getMaxNum(vtOnCB.size()))
    return 0;

  cout<<"("<<_iMyRank<<") CMA_ProcessEdgeVecToClps -- size of vtOnCB: "<<vtOnCB.size()<<endl;
//   if(!P_getMaxInt(vtOnCB.size())){
//     cout<<"No migration needed"<<endl;
//     return 0;
//   }
  cout<<"("<<_iMyRank<<") Calling M_migration"<<endl;
  M_migration(pmesh,0,vtOnCB,crvCB,0,rmVt,newVt,-1,dummy,dummy,dummyEG,dummyEG);
  cout<<"("<<_iMyRank<<") Finished M_migration"<<endl;
#endif
  return 1;
}

int meshAdapt::CMA_ProcessEdgeVecToSplit()
{
  for(int Index = 0 ; Index < _EdgeVecToSplit.size() ; Index++){
    pEdge edge = _EdgeVecToSplit[Index];

#ifdef DEBUG
    cout<<"("<<_iMyRank<<") Status of the edge: "<<endl;
    // edge->print();
    cout<<"("<<_iMyRank<<") And its length: "<<E_length(edge)<<endl;
#endif //DEBUG

    double splitTarget[]={0.0,0.0,0.0};
    double VtxCoords[2][3];
    double par[]={0.0, 0.0, 0.0};


    if(E_whatInType(edge)!=3){
#ifdef DEBUG
      cout<<"("<<_iMyRank<<") Edge on model boundary, ";
      cout<<"calling templatesUtil::middlePoint"<<endl;
#endif //DEBUG
      templatesUtil::middlePoint(edge, 0.5, splitTarget, par);
    }


    // if(E_numPoints(edge)){
//       pPoint pt = E_point(edge, 0);
//       splitTarget[0]=P_x(pt);
//       splitTarget[1]=P_y(pt);
//       splitTarget[2]=P_z(pt);
//       if(E_whatInType(edge)==1)
// 	par[0]=P_param1(pt);
//       if(E_whatInType(edge)==2)
// 	P_param2(pt, &par[0], &par[1], 0);
//     }
    else{
//       if(E_whatInType(edge)==3){
      V_coord(E_vertex(edge,0), VtxCoords[0]);
      V_coord(E_vertex(edge,1), VtxCoords[1]);
      for(int i=0;i<3;i++)
 	  splitTarget[i]=(VtxCoords[0][i]+VtxCoords[1][i])/2;
    }
//       else{
// 	cout<<"calling templatesUtil::middlePoint"<<endl;
// 	templatesUtil::middlePoint(edge, 0.5, splitTarget, par);
//       }
//     }
  
    cout<<"par: "<<par[0]<<","<<par[1]<<","<<par[2]<<endl;

    //setAdaptLevel(edge, 1);

    edgeSplitMod *esplit = new edgeSplitMod(pmesh,pSizeField,shpMeasure,result);
    esplit->setSplitEdge(edge);
    esplit->setSplitPos(splitTarget, par);
    esplit->setCurved();
    esplit->setModelType(PARAM);
    esplit->apply();

    delete esplit;

  }
}

int meshAdapt::CMA_SetMyRank(int i)
{
  _iMyRank = i;
}

int meshAdapt::CMA_ShapeInfo()
{
  crShpInfo *csi=new crShpInfo;
  _TheWorstShape=999.999;
  _TheWorstShapedRegion=NULL;
  int num[13];
  for(int i=0;i<13;i++)
    num[i]=0;
  RIter riter = M_regionIter(CrvMesh());
  while(pRegion region = RIter_next(riter)){
    CR_isValid(region, csi);
    if(csi->qs<0)
      adaptUtil::Warning(" Linear Shape Measure is Negative -- CMA_ShapeInfo");
    double shape = csi->shape;
    if(shape<=1&&shape>0.9)
      num[0]++;
    else if(shape<=0.9&&shape>0.8)
      num[1]++;
    else if(shape<=0.8&&shape>0.7)
      num[2]++;
    else if(shape<=0.7&&shape>0.6)
      num[3]++;
    else if(shape<=0.6&&shape>0.5)
      num[4]++;
    else if(shape<=0.5&&shape>0.4)
      num[5]++;
    else if(shape<=0.4&&shape>0.3)
      num[6]++;
    else if(shape<=0.3&&shape>0.2)
      num[7]++;
    else if(shape<=0.2&&shape>0.1)
      num[8]++;
    else if(shape<=0.1&&shape>0.01)
      num[9]++;
    else if(shape<=0.01&&shape>0.001)
      num[10]++;
    else if(shape<=0.001&&shape>0.0)
      num[11]++;
    else if(shape<=0.0)
      num[12]++; 
    else{
      cout<<"("<<_iMyRank<<") Error -- CMA_ShapeInfo(): unsupported shape quality: "<<endl;
      cout<<"shape Info: "<<shape<<"; curved: "<<csi->qc<<"; straight-sided: "<<csi->qs<<endl;
      //exit(1);
    }
      
    //cout<<"shape Info: "<<shape<<"; curved: "<<csi->qc<<"; straight-sided: "<<csi->qs<<endl;
    if(shape < _TheWorstShape){
      _TheWorstShape = shape;
      _TheWorstShapedRegion = region;
    }
  }
  for(int i=0;i<13;i++)
    cout<<"["<<_iMyRank<<"]: "<<num[i]<<endl;
  cout<<"("<<_iMyRank<<") The Worst Shape: "<<_TheWorstShape<<endl;
  CR_isValid(_TheWorstShapedRegion, csi);
  cout<<"shape Info of the Worst Shaped Region -- curved: "<<csi->qc<<"; straight-sided: "<<csi->qs<<endl;
  if(csi->qc<=0.0){
    cout<<"Is invalidity happenning at corner? "<<csi->isCorner<<endl;
    cout<<"Invalid Corner Index: "<<csi->index<<endl;
  }
  delete csi;
#ifdef DEBUG
  // _TheWorstShapedRegion->print();
#endif
  char name[32];
  sprintf(name, "TheWorstShapedRegion_%d.sms", _iMyRank);
  writeOutCorner(_TheWorstShapedRegion, NULL, name);

  // study the worst shaped region
   vector<pVertex> VtxVec;
   Rgn_vtxs(_TheWorstShapedRegion, 1, VtxVec);
//   
#ifdef DEBUG
 //  for(int index=0;index<VtxVec.size();index++)
   //  VtxVec[index]->print();
#endif
//   
//   vector<pEdge> EdgeVec;
//   double TheMaxEdgeLength=0.0;
//   pEdge TheLongestEdge;
//   Rgn_edges(TheWorstShapedRegion, 1, EdgeVec);
//   for(int index=0;index<EdgeVec.size();index++){
//     pEdge CurrentEdge = EdgeVec[index];
//     double CurrentEdgeLength = sqrt(E_lengthSq(CurrentEdge));
//     CurrentEdge->print();
//     cout<<"Current Edge length: "<<CurrentEdgeLength<<endl;
//     if( CurrentEdgeLength>TheMaxEdgeLength){
//       TheLongestEdge = CurrentEdge;
//       TheMaxEdgeLength = CurrentEdgeLength;
//     }
//   }  
// 
//   cout<<"Status of the longest edge: "<<endl;
//   TheLongestEdge->print();
//   cout<<"And its length: "<<TheMaxEdgeLength<<endl;
// 
//   double splitTarget[]={0.0,0.0,0.0};
//   double VtxCoords[2][3];
//   double par[]={0.0, 0.0, 0.0};
//   if(E_whatInType(TheLongestEdge)!=3){
//     cout<<"Edge on model boundary"<<endl;
//   }
//   if(E_numPoints(TheLongestEdge)){
//     pPoint pt = E_point(TheLongestEdge, 0);
//     splitTarget[0]=P_x(pt);
//     splitTarget[1]=P_y(pt);
//     splitTarget[2]=P_z(pt);
//   }
//   else{
//     V_coord(E_vertex(TheLongestEdge,0), VtxCoords[0]);
//     V_coord(E_vertex(TheLongestEdge,1), VtxCoords[1]);
//     for(int i=0;i<3;i++)
//       splitTarget[i]=(VtxCoords[0][i]+VtxCoords[1][i])/2;
//     //templatesUtil::middlePoint(TheLongestEdge, 0.5, splitTarget, par);
//   }
//   
//   edgeSplitMod *esplit = new edgeSplitMod(pmesh,pSizeField,shpMeasure,result);
//   esplit->setSplitEdge(TheLongestEdge);
//   esplit->setSplitPos(splitTarget, par);
//   esplit->apply();

}

int meshAdapt::CMA_TestCrvEdgeSwap()
{
#ifdef MA_PARALLEL
  int myrank;
  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  // apply edge swap to improves worst shape
 //  if(!_swapEdge)
//     _swapEdge=MD_newMeshDataId("edge2Swap");
  
  EIter eit_2=M_edgeIter(pmesh);
  int nswap=0;
  double mtol=M_getTolerance();
  double oriWorst;
  pPList rlist;
  pEdge edge;
  
  edgeSwapMod eswp(pmesh,pSizeField,shpMeasure,result);
  eswp.setCallback(function_CB,userData_CB);
  if( model_type != 2 ) 
    eswp.setModelType(NOPARAM);
  
  int ne=M_numEdges(pmesh);
  int i=0;
  shpMeasure->setDefaultAcptValue();
  //pPList elist = R_edges(TheWorstShapedRegion, 1);
  double edgelength = 0.0;
  double midpt[]={0.0,0.0,0.0};
  
  /// list of tagged edges on CB
  std::list<pEntity> taggedCBEdgeList;
  
  /// regions to be migrated
  std::list<pEntity> rgNextCB;           
  std::list<pEntity> vtOnCB;
  
  std::list<pVertex> drVertices; 
  //pmMigrationCallbacks userLB;
  pMeshDataId deref;
  double lowerLenSqBound=0.0;
  /// curved migration callback
  curveMigrateCB crvCB;
  
  //SF_MigrationCallbacks sfLB(pSizeField);
  
  /* tag the target edge on CB to be swapped */
  while(edge = EIter_next(eit_2)){
    if( i>ne ) break;
    i++;
    if( !EN_okTo(DELETE,(pEntity)edge) )
      continue;
    if( !EN_onCB(edge))
      continue;
    rlist=E_regions(edge);
    
    if( PList_size(rlist)==1&&E_whatInType(edge)==2 ) {
      edgelength = E_length(edge);
      EN_attachDataInt((pEntity)edge, _SwapEdge, 1);
      taggedCBEdgeList.push_back(edge);
      cout<<myrank<<": Data attached to: ";
      cout<<myrank<<": Vertex 1: "<<P_x(E_vertex(edge,0))<<" "<<P_y(E_vertex(edge,0))<<" "<<P_z(E_vertex(edge,0))<<endl;
      cout<<myrank<<": Vertex 2: "<<P_x(E_vertex(edge,1))<<" "<<P_y(E_vertex(edge,1))<<" "<<P_z(E_vertex(edge,1))<<endl;
      if(E_numPoints(edge)){
	pPoint pt=E_point(edge,0);
	midpt[0]=P_x(pt);
	midpt[1]=P_y(pt);
	midpt[2]=P_z(pt);
	cout<<P_x(pt)<<" "<<P_y(pt)<<" "<<P_z(pt)<<endl;
	// edge->print();
      }
      else
	cout<<myrank<<": straight-sided edge"<<endl;
      pRegion region = (pRegion)PList_item(rlist, 0);
      //if(myrank==0){
      //rgNextCB.push_back(region);
      cout<<myrank<<": Vertex 1: "<<P_x(E_vertex(edge,0))<<" "<<P_y(E_vertex(edge,0))<<" "<<P_z(E_vertex(edge,0))<<endl;
      cout<<myrank<<": Vertex 2: "<<P_x(E_vertex(edge,1))<<" "<<P_y(E_vertex(edge,1))<<" "<<P_z(E_vertex(edge,1))<<endl;
      vtOnCB.push_back(E_vertex(edge,0));
      vtOnCB.push_back(E_vertex(edge,1));
      //}
      //taggedCBEdgeList.push_back(edge);
      break;
    }
    
    
  }
  
  M_unifyTaggedEntities(_SwapEdge, &taggedCBEdgeList);
  
  pPList newSlivers1=PList_new();
  
  // M_writeVTKFile(pmesh, "mesh_before_migr");
  
  mMigrateForCoarsen(vtOnCB, drVertices, crvCB, deref, lowerLenSqBound);
  //mMigrateForShapeCorrect(rgNextCB,newSlivers1,crvCB,0.0);
  
  // M_writeVTKFile(pmesh, "mesh_after_migr");
  
  cout<<"######### checking param Coords after migration"<<endl;
  CMA_CheckVtxParamCoords(myrank);
  cout<<"######### entering swap stage"<<endl;
  
  //return 0;
  
  EIter_delete(eit_2);
  //unifyTaggedEntities(swapEdge, &taggedCBEdgeList);
  MPI_Barrier(MPI_COMM_WORLD);
  
  /* migrate the boundary regions */
  EIter eit_3 = M_edgeIter(pmesh);
  //  while(edge = EIter_next(eit_3)){
  //     rlist=E_regions(edge);
  //     int value;
  //     if(EN_getDataInt((pEntity)edge, swapEdge, &value) ) {
  //       //if(E_lengthSq(edge)==edgelength){
  //       cout<<myrank<<": after migration -- found tagged edge: ";
  //       //EN_deleteData((pEntity)edge, swapEdge);
  //       if(E_numPoints(edge)){
  // 	pPoint pt=E_point(edge,0);
  // 	midpt[0]=P_x(pt);
  // 	midpt[1]=P_y(pt);
  // 	midpt[2]=P_z(pt);
  // 	cout<<P_x(pt)<<" "<<P_y(pt)<<" "<<P_z(pt)<<endl;
  // 	edge->print();
  //       }
  //       else
  // 	cout<<myrank<<": straight-sided edge"<<endl;
  //       pRegion region = (pRegion)PList_item(rlist, 0);
  //       if(myrank==1)
  // 	rgNextCB.push_back(region);
  
  
  //     }
  //   }
  //   pPList newSlivers=PList_new();
  //   cout<<myrank<<": Size of rgNextCB: "<<rgNextCB.size()<<endl;
  
  //   cout<<"######### checking param Coords before migration"<<endl;
  //   CMA_CheckVtxParamCoords(myrank);
  
  
  //fromMeshTools::syncClassification(pmesh);
  //mMigrateForShapeCorrect(rgNextCB,newSlivers,crvCB,0.0);
  
  
  
  //EIter_delete(eit_2);
  
  i=0;
  // debug //
  //   cout<<"######### checking param Coords after migration"<<endl;
  //   CMA_CheckVtxParamCoords(myrank);
  cout<<"######### entering swap stage"<<endl;
  while(edge = EIter_next(eit_3)){
    if( i>ne ) break;
    i++;
    rlist=E_regions(edge);
    //if(PList_size(rlist)==2&&E_whatInType(edge)==2){
    
    
    int value=0;
    //if( midpt[0]==P_x(pt)&&midpt[1]==P_y(pt)&&midpt[2]==P_z(pt)){
    if(EN_getDataInt((pEntity)edge, _SwapEdge, &value)){
      cout<<myrank<<": After migration -- found edge, ready to swap: ";
      cout<<myrank<<": Vertex 1: "<<P_x(E_vertex(edge,0))<<" "<<P_y(E_vertex(edge,0))<<" "<<P_z(E_vertex(edge,0))<<endl;
      cout<<myrank<<": Vertex 2: "<<P_x(E_vertex(edge,1))<<" "<<P_y(E_vertex(edge,1))<<" "<<P_z(E_vertex(edge,1))<<endl;
      if(PList_size(rlist)==2&&E_whatInType(edge)==2){
        
	if(E_numPoints(edge)){
	  pPoint pt=E_point(edge,0);
	  cout<<P_x(pt)<<" "<<P_y(pt)<<" "<<P_z(pt)<<endl;
	}
	else
	  cout<<"straight-sided edge"<<endl;
	// 	int value=0;
	// 	cout<<EN_getDataInt((pEntity)edge, swapEdge, &value)<<endl;
	// 	cout<<"value: "<<value<<endl;
      }
      else{
	cout<<myrank<<": rlist size: "<<PList_size(rlist)<<endl;
        continue;
      }
      if(value==-1){
	cout<<myrank<<" : Already swapped, skip it this time"<<endl;
	continue;
      }
      eswp.setSwapEdge(edge);
      if( eswp.topoCheck() ) { 
	

// 	if( eswp.geomCheck() ) { // geomCheck in optimize
	  
//   	  eswp.sizeCheck();
//   	  if( result->getMaxSize()>upperBoundSq )
//   	    continue;
 
// 	  oriWorst=adaptUtil::E_worstShp(shpMeasure,rlist,edge);
// 	  if( oriWorst <mtol ) 
// 	    {
// 	      adaptUtil::Warning("flat elements (meshAdapt::optimize())");
// 	      if( result->getWorstShape() > (mtol + oriWorst) ) 
// 		{ 
// 		  eswp.apply();
// 		  nswap++;
// 		}
// 	    }
// 	  else if( result->getWorstShape() > 1.2*oriWorst ) //IMPROVE_RATIO*oriWorst )
// 	    {
	//eswp.apply();
 	eswp.setMesh(pmesh);
/*	if(eswp.setEntities()){
	  eswp.deleteOldEntities();
	  eswp.createNewEntities();
	  //EN_attachDataInt((pEntity)eswp.new_edge, swapEdge, -1);
	  nswap++;
	  //break;
	  
	}*/
	//nswap++;
	// 	    }
      }
      
      // }
    }
    //PList_delete(rlist);
  }
  EIter_delete(eit_2);
  //adaptUtil::Info(nswap,"edge swap are performed");
  cout<<myrank<<" : "<<nswap<<" edge swap are performed"<<endl;
  return nswap;
#endif
}

int curveMesh::CMA_UniformRefine(){

}

#endif //CURVE
