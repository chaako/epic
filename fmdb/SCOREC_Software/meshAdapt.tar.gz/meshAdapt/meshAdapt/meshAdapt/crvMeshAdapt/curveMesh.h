#ifndef MESHADAPT_CURVEMESH_H_
#define MESHADAPT_CURVEMESH_H_

#include "FMDBInternals.h"
#include "FMDB_cint.h"
#include "AdaptUtil.h"
#include "slacUtil.h"

#include "DSplitClpsMod.h"
#include "EdgeCollapsMod.h"
#include "EdgeSwapMod.h"
#include "VertMotionMod.h"
#include "FaceSwapMod.h"
#include "SplitCollapsMod.h"
#include "RegionCollapsMod.h"
#include "EdgeReShapeMod.h"

#include "meanRatio.h"
#include "EvalResults.h"
#include "NullSField.h"

#include <map>
#include <vector>
#include <list>
using std::map;
using std::vector;
using std::list;

// overall shape metric Q_{sc}, Jun 8, 2009, Kai

struct RegionShapeInfo{
  double qs;      // straight-sided tet
  double qc;      // high-order tet
  // Q_{sc} = Q_s * Q_c
  
};

struct CurvedRegionShapeInfo{
  int index;
  int index1[3];
  int isCorner;
  int processed;
  double shape;
  double qs;
  double qc;      //same as above
  //double minDetJ;  // minimum of the Jacobian Determinant evaluated over a curved tet
  //double maxDetJ;  // maximum of the above
};

struct ReShapeEdgeInfo{
  pEdge edge;
  double shape;
  double ptxyz[3];
  int newR;
};

typedef struct ReShapeEdgeInfo rEdShpInfo;
typedef struct CurvedRegionShapeInfo crShpInfo;
typedef struct RegionShapeInfo rShpInfo;

class curveMesh {

public:
  // construct
  curveMesh(pMesh mesh, int modeltype, int curvetype);

  // destructor
  ~curveMesh();

  // fix the input mesh ent
  void fix_entity(pEntity);
  
  // correct the mesh
  void run();

  void set_desired_shape(double t) {desired_shape = t;}
  void setCurrentStage(int stage) { currentStage=stage;}
  int getCurrentStage() { return currentStage; }
  

private:

  pGModel pTheGMdl_;
  pPart pThePart_;
  int iTheMdlType_;
  int iTheCrvType_;
//  int theCurveType;

  NullSField * pNullSF_;
  evalResults * pResults_;
  MeanRatio * pShpMeasure_; 
  
//  NullSField *nullsf;
//  evalResults *results;
//  MeanRatio *shpMeasure; 

  // from the curving branch //
  int currentStage;
  double desired_shape;

  /////////////////////////////
  double _desiredShape;
  double _GWORSTSHAPE;
  double _edgeClpsBound;
 
  map<pRegion, crShpInfo*> _crvdRgnMapToProcess;
  map<pRegion, crShpInfo*> invalidCurvedRgns;  //used in fromCrvBranch.cc
  pPList _invalidRgnPList;
 
  // attach data Ids
  pMeshDataId _fixEnt;
  pMeshDataId _midPtCrdsTag;
  pMeshDataId _midPtParaTag;
  pMeshDataId _onPartBdry; 
 
  double _RgnShapeThresh;
  double _EdgeLengthUpper;
  double _EdgeLengthLower;

  // counters for various mesh mod operations
  int iOpCounts_[9];

  // from the curving branch //
  int getRgnsOnPartBdry(std::map<pRegion, crShpInfo*> inputRgnMap, std::vector<pRegion> &outputBdryRgns);
  void create_ho_edges();
  void createInvalidRgns(double);
  void invalidRgnsInfo();
  void fixInvalidRgnsByMods();
  void ImproveRgnsByMods();
  void outPutOpsInfo();
  int isEdgeSplitModValid(edgeSplitMod *, pRegion, int &, double&);
  int isDsplitClpsModValid(DSplitClpsMod *,pRegion, double &);
  int isEdgeClpsModValid(edgeCollapsMod *, pRegion, double &);
  int isFaceSwpModValid(faceSwapMod *, pRegion, double &);
  int isEdgeSwpModValid(edgeSwapMod *, pRegion, double &);
  int isEdgeSplitClpsModValid(EsplitClpsMod *, pRegion, double &);
  int isRegionClpsModValid(regionCollapsMod *, pRegion, double &);
  int isVertexMotionModValid(vertMotionsMod *, pRegion, double &);
  int findBestMod(pRegion, crShpInfo *, pMeshMod *);
  int findEdgeReShape(pRegion, crShpInfo *, pMeshMod *);
  int isDsplitClpsLooseModValid(pRegion, pMeshMod *);
  int isUnCurvedModValid(pRegion, crShpInfo *, pPList *);
  void updateNewReg(pPList *);
  void applyBestMod(pMeshMod *);

  // for high-order tets. Jun 8, 2009, Kai
  // for computing Q_s and Q_c of high-order tets.
  //void computeRegionShape(pRegion, crShpInfo *); 
  // check if its OK to use high-order node smoothing
  int isExplicitHONSmoothingValid(vertMotionsMod *, pRegion, crShpInfo *, double &);
  // This implementation is limited to the case where only one edge is in model region. Mar 28, 2011. Kai
  int isExplicitNodalSmoothingValid(pRegion region, crShpInfo *, pEdge *targetEdge);

  int minDetJAmgVertices(crShpInfo *, int *edgeID, int *); // compute the minimum Det among four vertices
  // return 0 if minimum is not located at vertex control point.
  int computeMiddlePtTarget(pRegion, int, pEdge);

 protected:
  // internal functions

  /** \brief Screen output the lengths of the six edges of a tet region, regarding the edges as straight
   *
   *  \param region (In) region to be examined.
   */
  void outPutEdgeLength(pRegion region);

  /** \brief output the classification info of the six edges
   *
   *  \param region (In) region to be examined.
   */
  void outPutEdgeVtxClassify(pRegion region);

  /** \brief ouput the coords of the two vertices and midpoints if any
   *
   *
   */
  void outPutEdgeCoords(pRegion region);
  void unCurveInvalidRgns();
  void createInvalidRgnList(pPList &);
  void createRgnsToProcess(double dThreshold, int iOption);
  //int isEdgeClpsModValid(edgeCollapsMod *, pRegion, double &);
  int isEdgeClpsable(edgeCollapsMod *, pEdge);
 
 public:

  /////////////////////
  // Categorize APIs //
  /////////////////////

  /* Gets and Sets */
  void CM_SetModelType(int iTheMdlType){ iTheMdlType_ = iTheMdlType; }
  double CM_GetEdgeLengthLower(){ return _EdgeLengthLower;}
  double CM_GetEdgeLengthUpper(){ return _EdgeLengthLower;}
  double CM_GetRgnShapeThresh() { return _RgnShapeThresh; }
  void CM_SetEdgeLengthLower(double input){ _EdgeLengthLower = input;}
  void CM_SetEdgeLengthUpper(double input){ _EdgeLengthUpper = input;}
  void CM_SetRgnShapeThresh(double input) { _RgnShapeThresh = input; }
  pMeshDataId CM_getMidPtCrdsTag(){return _midPtCrdsTag;}
  pMeshDataId CM_getMidPtParaTag(){return _midPtParaTag;}
  pPList CM_getInvalidRgnList(){ return _invalidRgnPList; } 

  /* Querying  */
  int CM_RegionInfo();
  void CM_CreateInvalidRgnVec(std::vector<pRegion> &, int option=0);
  void CM_CreatePoorRgnVec(std::vector<pRegion> &, int option=0);
  void CM_writeInvalidRgnsData();
  void CM_edgePropOfInvalidList();
  void CM_createInvalidRgnList();
  void CM_printNumEntities(){ M_printNumEntities(pThePart_); }
  void CM_setEdgeClpsBound(double bound){_edgeClpsBound = bound;}

  /* Funtional */
  int CMA_CheckMeshQuality(){
    
    RIter rgnIter = M_regionIter(pThePart_);
    double dMinRadiusRatio = 999.999;
    double dMaxRadiusRatio = -999.999;
    pRegion crntRgn = NULL;

    cout<<"Checking mesh quality ........."<<endl;
    cout<<"Shape Measure: Radius Ratio ..."<<endl;
    while(crntRgn = RIter_next(rgnIter)){
      double crntShape = 0.0;
      slacUtil::SU_RadiusRatio(crntRgn, crntShape);

      if(crntShape > dMaxRadiusRatio)
        dMaxRadiusRatio = crntShape;

      if(crntShape < dMinRadiusRatio)
        dMinRadiusRatio = crntShape;
    }

    RIter_delete(rgnIter);

    cout<<" Min: "<<dMinRadiusRatio<<endl;
    cout<<" Max: "<<dMaxRadiusRatio<<endl;
    cout<<" ============================="<<endl;

    return 1;

  }
  int CMA_LockSurfaceMesh();
  int CMA_UniformRefine();
  int CMA_CreateHOEdges();
  int CMA_ClearHONodes();
  int CMA_UncurveInvalidRgns();
  int CMA_Refine();
  int CMA_Coarsen();
  int CMA_NodalSmooth();
  int CMA_SetCrvMeshQualityThreshold(double dThreshold) { desired_shape = dThreshold; }
  /////////////////////

};

void writeOutCorner(pRegion region, pVertex vertex, char* name);
void E_middleStPt(pEdge edge, double *xyz);

void computeRegionShape(pRegion, crShpInfo *); 
// Validity check of a quadratic region
void M_checkCurvedRegionShape(pMesh, char*);
/* void M_checkSTRegionShape(pMesh, char*);   */
/* int CR_isValid(pRegion, crShpInfo *); */
/* int CXYZ_isValid(double (*xyz)[3], crShpInfo*); */
void writeOutCurvedRegion(pRegion, int, char *);
void writeOutCurvedRList(pPList *, int, char*);
int R_worstShape(pPList *, double &, double &,  pPList *);
rEdShpInfo * FindBestReShapeEdge(vector<rEdShpInfo*> &);

#endif
