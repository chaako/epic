#include "FaceSwapMod.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "Fswap.h"
#include "FMDB.h"
#include "FMDB_cint.h"
#include "MeshAdjTools.h"
#include "fromMeshTools.h"
#include "PList.h"
#include "BLUtil.h"
#include <math.h>
#include <stdio.h>
#include <iostream>
using std::cout;
using std::endl;

#ifdef CURVE
#include "curveMesh.h"
#include "curveUtil.h"
using namespace curveUtil;
#endif/*CURVE*/

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif

extern F_SwapConfig fsc;


/*
  Given a vertex motion followed by face swap 


  Return 0: the swap and the motion will create an invalid mesh
         1: valid and a rank is returned by reference

  10/04/99   created
  06/27/2000 modified    by Xiangrong Li
*/
int faceSwapMod::topoCheck() 
{
  if( F_whatInType(face)==Gface )
    return 0;
  if (!EN_okTo(SWAP,(pEntity)face))
    return 0;
#ifdef MA_PARALLEL
  if( EN_onCB((pEntity)face) )
    return 0;
#endif

  /// Can't handle cases involving any topology other than tets
  int iValidRgn = 1;
  pVertex pVertexVtx[4] = {F_vertex(face, 0), F_vertex(face, 1), F_vertex(face, 2), vertMv};
  pRegion pRegionRgn;
  int iVtxNum = 3;
  if (vertMv)
    iVtxNum = 4;
  for (int iVtx = 0; iVtx < iVtxNum; ++iVtx)
  {
    pPList vregs = V_regions(pVertexVtx[iVtx]);
    for (int iRgn = 0; iRgn < PList_size(vregs); ++iRgn)
    {
      pRegionRgn = (pRegion)PList_item(vregs, iRgn);
      if (pRegionRgn->getType() == PYRAMID)
      {
        iValidRgn = 0;
        PList_delete(vregs);
        break;
      }
    }
    if (iValidRgn)
      PList_delete(vregs);
    else
      break;
  }
  if (!iValidRgn)
    return 0;


  return 1;
}

int faceSwapMod::geomCheck()
{
  pRegion region;
  pFace fc;

  pMSize pmt[4];
  pVertex vt,vertex;
  double origin[3];
  double xyz[4][3], xyz2[4][3];
  double xyz1[3];
  double worst2, shape_1;
  int ok;
  int i,j;
  void *temp_0;
  void *temp_1;
  pPList vrlist,fvlist,rvlist;

  double mtol=M_getTolerance();

  // make the motion
  if( vertMv ) {
    V_coord(vertMv,origin);
    adaptUtil::move_vertex(vertMv,target);
  }

  // check if this operation can be applied
  ok=F_evalSwap(face,mtol);
  if(!ok)
    { if(vertMv) adaptUtil::move_vertex(vertMv,origin); return 0; }

  results->reset();
  conf=fsc.swapType;
  if(fsc.swapType == TWO2TRI) {
    edgeDel=0;

    //***** calculate the worst shape after this FSWAP *********

    // consider the three new regions
    worst2=BIG_NUMBER;
    fvlist=F_vertices(fsc.face,1);
    rvlist=R_vertices(fsc.oppRegs[0],1);

    // get the coordinates of the five vertices
#ifdef CURVE
    if(quadratic == false) {
#endif/*CURVE*/
    temp_1=0; i=0;
    while(vt=(pVertex)PList_next(rvlist,&temp_1)) 
      V_coord(vt,xyz[i++]);
    V_coord(fsc.oppVrts[1],xyz1);

    // calculate worst shape of the three new regions
    temp_0=0;
    while(vertex=(pVertex)PList_next(fvlist,&temp_0)) {
      temp_1=0; i=0;
      while(vt=(pVertex)PList_next(rvlist,&temp_1)) 
        if(vt == vertex) 
	  { 
	    pmt[i]=pSizeField->getSize(fsc.oppVrts[1]);
	    xyz2[i][0]=xyz1[0]; xyz2[i][1]=xyz1[1]; xyz2[i++][2]=xyz1[2]; 
	  }
        else
          { 
	    pmt[i]=pSizeField->getSize(vt);
	    xyz2[i][0]=xyz[i][0]; xyz2[i][1]=xyz[i][1]; xyz2[i][2]=xyz[i][2];
	    i++;
	  }

      if( !shpMeasure->XYZ_shape(xyz2,pmt,&shape_1) ) {
	PList_delete(fvlist);
	PList_delete(rvlist);
	if(vertMv) 
	  adaptUtil::move_vertex(vertMv,origin);
	return 0;
      }
      
      // find the worst shape
      if(shape_1 < worst2)
        worst2=shape_1;
    }
    
#ifdef CURVE
}
    else if (quadratic == true) {
       // for quadratic tet meshes

      pVertex rverts[4];
      double xyz2[10][3];
      crShpInfo csi;
      for (temp_1=0, i=0; (vt=(pVertex)PList_next(rvlist,&temp_1)); i++) {
	V_coord(vt,xyz[i]);
	rverts[i] =vt;
      }
      pVertex fvert =fsc.oppVrts[1];
      V_coord(fvert, xyz1);
      
      // calculate worst shape of the three new regions
      temp_0=0;
      while(vertex=(pVertex)PList_next(fvlist,&temp_0)) {
	// get the coordinates of the four corners of the new region
	pVertex v[4];
	for (temp_1=0, i=0; (vt=(pVertex)PList_next(rvlist,&temp_1)); i++) {
	  if(vt == vertex) { 
	    //pmt[i]=pSizeField->getSize(fsc.oppVrts[1]);
	    xyz2[i][0]=xyz1[0]; xyz2[i][1]=xyz1[1]; xyz2[i][2]=xyz1[2]; 
	    v[i] =fvert;
	    
	  }
	  else { 
	    //pmt[i]=pSizeField->getSize(vt);
	    xyz2[i][0]=xyz[i][0]; xyz2[i][1]=xyz[i][1]; xyz2[i][2]=xyz[i][2];
	    v[i] =rverts[i];
	  }
	}

	// get the coordinates of the six mid-side nodes of the new region
	int j0, j1;
	for (int ipoint=0; ipoint<6; ipoint++, i++) {
	  switch (ipoint) {
	  case 0:
	    j0 =0; j1 =1;
	    break;
	  case 1:
	    j0 =1; j1 =2;
	    break;
	  case 2:
	    j0 =2; j1 =0;
	    break;
	  case 3:
	    j0 =0; j1 =3;
	    break;
	  case 4:
	    j0 =1; j1 =3;
	    break;
	  case 5:
	    j0 =2; j1 =3;
	    break;
	  }

	  pEdge e=E_exists(v[j0], v[j1]);
	  if (e) {
	    // for the existing edges, use their mid-side nodes
	    E_bezierCtrlPt(e, xyz2[i]);
	  }
	  else {
	    // for the new edge, compute its mid-side node
	    double vxyz[2][3];
	    V_coord (v[j0], vxyz[0]);
	    V_coord (v[j1], vxyz[1]);
	    xyz2[i][0] =(vxyz[0][0] + vxyz[1][0])/2.0;
	    xyz2[i][1] =(vxyz[0][1] + vxyz[1][1])/2.0;
	    xyz2[i][2] =(vxyz[0][2] + vxyz[1][2])/2.0;
	  }
	} // for (ipoint=0; ipoint<6; ipoint++)
	
	if( !HO_XYZ_isValid(xyz2, &csi) ) {
	  PList_delete(fvlist);
	  PList_delete(rvlist);
	  if(vertMv) 
	    adaptUtil::move_vertex(vertMv,origin);
	  return 0;
	}
	
	// find the worst shape
	if(csi.shape < worst2)
	  worst2=csi.shape;
      }
    }
#endif/*CURVE*/

    PList_delete(fvlist);
    PList_delete(rvlist);

    // consider the regions hooked on the moved vertex
    if( vertMv ) {
      if(EN_isBLEntity((pEntity)vertMv)) {
        if(!V_atBLInterface(vertMv)) {
          cout<<"\nError in faceSwapMod::geomCheck()..."<<endl;
          cout<<"vertMv is BL entity but not at BL interface"<<endl;
          exit(0);
        }

        vrlist = PList_new();

        vector<pRegion> Vrgns;
        V_nonBLRegions(vertMv, Vrgns);
        for (int itReg = 0; itReg < Vrgns.size(); ++itReg)
        {
          PList_append(vrlist, Vrgns[itReg]);
        }

        double f_xyz[3][3], v01[3], v02[3], nor[3];;
        pMSize f_pmt[3];
        pFace face;
        vector<pFace> vLyrFaces;
        V_layerFaces(vertMv, vLyrFaces);
        pPList fverts;
        int numFaces = vLyrFaces.size();
        for(int iFace=0; iFace<numFaces; iFace++) 
        {
          face = vLyrFaces[iFace];

          fverts = F_vertices(face,1);

          // compute the original normal
          temp_0 = 0; i = 0;
          while (vertex = (pVertex)PList_next(fverts, &temp_0)) {
            if(vertex==vertMv) {
              f_xyz[i][0]=origin[0]; f_xyz[i][1]=origin[1]; f_xyz[i++][2]=origin[2];
            }
            else
              V_coord(vertex,f_xyz[i++]);
          }
          diffVt(f_xyz[1],f_xyz[0],v01);
          diffVt(f_xyz[2],f_xyz[0],v02);
          crossProd(v01,v02,nor);

          temp_0 = 0; i = 0;
          while (vertex = (pVertex)PList_next(fverts, &temp_0)) {
            f_pmt[i]=pSizeField->getSize(vertex);
            V_coord(vertex,f_xyz[i++]);
          }
          PList_delete(fverts);

          // check validity and calculate shape
          if(!shpMeasure->XYZ_shape(f_xyz, f_pmt, nor, &shape_1)) {
            PList_delete(vrlist);
            adaptUtil::move_vertex(vertMv,origin);
            return 0;
          }
        }
      }
      else
        vrlist=V_regions(vertMv);
  
      temp_0=0;
      while(region=(pRegion)PList_next(vrlist,&temp_0)) {
	
	if(region==fsc.oppRegs[0] || region==fsc.oppRegs[1])
	  continue;
	
	// calculate shape and check acceptability
	if( !shpMeasure->R_shape(region, &shape_1) ) {
	  PList_delete(vrlist);
	  adaptUtil::move_vertex(vertMv,origin);
	  return 0;
	}
	
	if(shape_1 < worst2)
	  worst2=shape_1;
      }
      PList_delete(vrlist);
 
      // now move the vertex back
      adaptUtil::move_vertex(vertMv,origin);
    }

    results->setWorstShape(worst2);
  }

  else if(fsc.swapType==TRI2TWO) {

    // calculate the worst shape after face swap

    // find the edge that will be deleted
    for(i=0;i<4;i++) {
      fc=R_face(fsc.thirdReg,i);
      region=adaptUtil::F_otherRgn(fc,fsc.thirdReg);
      if(region==fsc.oppRegs[0])
        break;
    }
    edgeDel = F_vtOpEd(fc,fsc.oppVrts[0]);

    // consider the two new regions
    worst2=100.0;
    rvlist=R_vertices(fsc.oppRegs[0],1);
#ifdef CURVE
    if(quadratic == false) {
    // for linear tet meshes
#endif/*CURVE*/
    for(j=0;j<2;j++) {
      vertex=E_vertex(edgeDel,j);

      temp_0=0; i=0;
      while(vt=(pVertex)PList_next(rvlist,&temp_0)) 
        if(vt == vertex) 
	  {
	    pmt[i]=pSizeField->getSize(fsc.oppVrts[1]);
	    V_coord(fsc.oppVrts[1],xyz[i++]);
	  }
	else 
	  {
	    pmt[i]=pSizeField->getSize(vt);
	    V_coord(vt,xyz[i++]);
	  }

      // calculate shape and check acceptability
      if( !shpMeasure->XYZ_shape(xyz, pmt, &shape_1) ) {
	PList_delete(rvlist);
	if(vertMv) adaptUtil::move_vertex(vertMv,origin);
	return 0;
      }

      if(shape_1 < worst2)
        worst2=shape_1;
    }
#ifdef CURVE
}
      else if (quadratic == true) {
        // for quadratic tet meshes
        double xyz[10][3];
        crShpInfo csi;

        for(j=0;j<2;j++) {
          vertex=E_vertex(edgeDel,j);

          pVertex v[4];
          for (temp_0=0, i=0; (vt=(pVertex)PList_next(rvlist,&temp_0)); i++) {
            if(vt == vertex) {
              //pmt[i]=pSizeField->getSize(fsc.oppVrts[1]);
              V_coord(fsc.oppVrts[1],xyz[i]);
              v[i] =fsc.oppVrts[1];
            }
            else {
              //pmt[i]=pSizeField->getSize(vt);
              V_coord(vt,xyz[i]);
              v[i] =vt;
            }
          }

       // get the coordinates of the six mid-side nodes of the new region
          int j0, j1;
          for (int ipoint=0; ipoint<6; ipoint++) {
            switch (ipoint) {
            case 0:
              j0 =0; j1 =1;
              break;
            case 1:
              j0 =1; j1 =2;
              break;
            case 2:
              j0 =2; j1 =0;
              break;
            case 3:
              j0 =0; j1 =3;
              break;
            case 4:
              j0 =1; j1 =3;
              break;
            case 5:
              j0 =2; j1 =3;
              break;
            }

            pEdge e =E_exists(v[j0], v[j1]);
            // for the existing edges, use their mid-side nodes
            if (e) {
              // for the existing edges, use their mid-side nodes
              E_bezierCtrlPt(e, xyz2[i++]);
            }
            else {
              // for the new edge, compute its mid-side node
              double vxyz[2][3];
              V_coord (v[j0], vxyz[0]);
              V_coord (v[j1], vxyz[1]);
              xyz[i][0] =(vxyz[0][0] + vxyz[1][0])/2.0;
              xyz[i][1] =(vxyz[0][1] + vxyz[1][1])/2.0;
              xyz[i++][2] =(vxyz[0][2] + vxyz[1][2])/2.0;
            }

          } // for (ipoint=0; ipoint<6; ipoint++)

       // calculate shape and check acceptability
          if( !HO_XYZ_isValid(xyz, &csi) ) {
            PList_delete(rvlist);
            if(vertMv) adaptUtil::move_vertex(vertMv,origin);
            return 0;
          }

          if(csi.shape < worst2)
            worst2=csi.shape;
        }
      }


#endif/*CURVE*/
    PList_delete(rvlist);

    // consider regions adjacent to moving vertex, not including the three deleted
    if( vertMv ) {
      if(EN_isBLEntity((pEntity)vertMv)) {
        if(!V_atBLInterface(vertMv)) {
          cout<<"\nError in faceSwapMod::geomCheck()..."<<endl;
          cout<<"vertMv is BL entity but not at BL interface"<<endl;
          exit(0);
        }

        vector<pRegion> Vrgns;
        V_nonBLRegions(vertMv, Vrgns);
        vrlist = PList_new();
        for (int itReg = 0; itReg < Vrgns.size(); ++itReg)
        {
          PList_append(vrlist, Vrgns[itReg]);
        }

        double f_xyz[3][3], v01[3], v02[3], nor[3];;
        pMSize f_pmt[3];
        pFace face;
        vector<pFace> vLyrFaces;
        V_layerFaces(vertMv, vLyrFaces);
        pPList fverts;
        int numFaces = vLyrFaces.size();
        for(int iFace=0; iFace<numFaces; iFace++)
        {
          face = vLyrFaces[iFace];

          fverts = F_vertices(face,1);

          // compute the original normal
          temp_0 = 0; i = 0;
          while (vertex = (pVertex)PList_next(fverts, &temp_0)) {
            if(vertex==vertMv) {
              f_xyz[i][0]=origin[0]; f_xyz[i][1]=origin[1]; f_xyz[i++][2]=origin[2];
            }
            else
              V_coord(vertex,f_xyz[i++]);
          }
          diffVt(f_xyz[1],f_xyz[0],v01);
          diffVt(f_xyz[2],f_xyz[0],v02);
          crossProd(v01,v02,nor);

          temp_0 = 0; i = 0;
          while (vertex = (pVertex)PList_next(fverts, &temp_0)) {
            f_pmt[i]=pSizeField->getSize(vertex);
            V_coord(vertex,f_xyz[i++]);
          }
          PList_delete(fverts);

          // check validity and calculate shape
          if(!shpMeasure->XYZ_shape(f_xyz, f_pmt, nor, &shape_1)) {
            PList_delete(vrlist);
            adaptUtil::move_vertex(vertMv,origin);
            return 0;
          }
        }
      }
      else
        vrlist=V_regions(vertMv);

      temp_0=0;
      while(region=(pRegion)PList_next(vrlist,&temp_0)) {
	if(region==fsc.oppRegs[0] || region==fsc.oppRegs[1] || region==fsc.thirdReg)
	  continue;
	
	// calculate shape and check acceptability
	if( ! shpMeasure->R_shape(region,&shape_1) ) {
	  PList_delete(vrlist);
	  if(vertMv) adaptUtil::move_vertex(vertMv,origin);
	  return 0;
	}
	
	if(shape_1 < worst2)
	  worst2=shape_1;
      }
      PList_delete(vrlist);

      // move the vertex back
      adaptUtil::move_vertex(vertMv,origin);
    }

    results->setWorstShape(worst2);
  }

  else if (fsc.swapType==TWO2TWO) {
    // an edge swap, let it be considered in edge swap
    if( vertMv )
      adaptUtil::move_vertex(vertMv,origin);
    return 0;
  }
#ifndef CURVE
  if(worst2<QUALITYFRACTION*QUALITYTHRESHOLD)
    return 0;
#endif
  return 1;
}


/*
  return 0:  size unacceptable wrt the values in size measure
         1:  size acceptable wrt the values in size measure
*/
int faceSwapMod::sizeCheck()
{
  pEdge edge;
  double  xyz[2][3];
  pMSize pmt[2];
  double max, min;
  double tmp;
  int i;

  if( !pSizeField ) {
    printf("WARNING: NULL metric field. You can not do size checking");
    return 1;
  }

  if(fsc.swapType == TWO2TRI) {

    // take care of the new edge
    for(i=0; i<2; i++) {
      if(fsc.oppVrts[i]==vertMv)
        { xyz[i][0]=target[0]; xyz[i][1]=target[1]; xyz[i][2]=target[2]; }
      else
        V_coord(fsc.oppVrts[i],xyz[i]);
      pmt[i]=pSizeField->getSize(fsc.oppVrts[i]);
    }
    max = pSizeField->lengthSq(xyz[0],xyz[1],pmt[0],pmt[1]);
    min=max;
  }

  else if(fsc.swapType==TRI2TWO) {
    // no new edge will be created
    min=BIG_NUMBER;
    max=0.0;
  }

  else if(fsc.swapType==TWO2TWO) 
    return 0;

  if( vertMv ) {
    // take care of edges connected to the vertex to be moved
    pVertex vt;
    double xyz1[3];

    pmt[0]=pSizeField->getSize(vertMv);

    for(i=0;i<V_numEdges(vertMv); i++) {
      edge=V_edge(vertMv,i);
      if(edge==edgeDel) continue;
      vt=E_vertex(edge,0);
      if(vt==vertMv)  vt=E_vertex(edge,1);
      V_coord(vt,xyz1);
      pmt[1]=pSizeField->getSize(vt);
      tmp = pSizeField->lengthSq(target,xyz1,pmt[0],pmt[1]);
      if( tmp>max ) max=tmp;
      if( tmp<min ) min=tmp;
    }
  }

  results->setMaxSize(max);
  results->setMinSize(min);
  return 1;
}

/* this must be called after geomCheck() && topoCheck() */
void faceSwapMod::getAffectedRgns(pPList *l)
{
  if( fsc.swapType==TWO2TWO )
    return;

  *l=PList_new();
  
  PList_append(*l,fsc.oppRegs[0]);
  PList_append(*l,fsc.oppRegs[1]);
  if( fsc.swapType == TRI2TWO ) 
    PList_append(*l,fsc.thirdReg);

  if( vertMv ) {
    pPList vrlist=V_regions(vertMv);
    pRegion region;
    void *iter=0;
    while( region=(pRegion)PList_next(vrlist,&iter) )
      PList_appUnique(*l, region);
    PList_delete(vrlist);
  }

  return;
}


int faceSwapMod::apply()
{
  pPList newRegs;

  int flag=apply(&newRegs);
  PList_delete(newRegs);

  return flag;
}


int faceSwapMod::apply(pPList *newRegs)
{
  double mtol=M_getTolerance();

  if( vertMv ) 
    adaptUtil::move_vertex(vertMv,target,CB_move,userData_CB_move);

  if(F_evalSwap(face, mtol) == 1)
    templatesUtil::Face_swap(mesh, face, mtol, function_CB, userData_CB, newRegs); 
  else
    { std::cout << " Error:  inconsistent evaluation in F_swap" << endl;  return 0; }

#ifdef DEBUG
  if( vertMv ) {
    pRegion region;
    pPList mvRgns=V_regions(vertMv);
    void *iter=0;
    while( region=(pRegion)PList_next(mvRgns,&iter) ) {
      if( R_Volume2(region) < mtol*mtol*mtol )
	printf("Error: 1. region %d: R_volume=%18.16f (faceSwapMod::apply())\n",
	       region,R_Volume2(region));
    }
    PList_delete(mvRgns);
  }
#endif

  return 1;
}








