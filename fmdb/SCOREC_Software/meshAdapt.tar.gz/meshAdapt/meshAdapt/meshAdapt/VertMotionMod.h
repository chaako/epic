#ifndef _H_MOTIONMod
#define _H_MOTIONMod

/*
  since the diversity of determining proper vertex motions, this 
  class is designed just as the holder of multiple motions (<=6),
  and the execution of these motions  

  note that the following rule is adopted in designing:
  > for a vertex on model region, "target" hold the coordinates in world space
  > for a vertex on model face, "target" hold the coordinates in parametric space
*/

#include "LocMeshMod.h"

class vertMotionsMod : public locMeshMod
{
 public:
  vertMotionsMod(const vertMotionsMod &);
  vertMotionsMod(pMesh p, pSField mf): locMeshMod(p,mf,0,0), s(0) {}
  vertMotionsMod(pMesh, pSField, int, pVertex *, double[][3]);
  vertMotionsMod(pMesh, pSField, pVertex, pVertex, double[3],double[3]);
  ~vertMotionsMod() {}

  /* the common local modification interface */
  virtual int topoCheck() {return 0;}                 // dummy function
  virtual int geomCheck() {return 0;}                 // dummy function
  virtual int sizeCheck() {return 0;}                 // dummy function
  virtual void getAffectedRgns(pPList *) { return; }  // dummy function
  virtual int apply();
  virtual int apply(pPList *) {return 0;}             // dummy function
  virtual modType type() { return MOTION; }

  /* return the # of moved vertices in this modification */ 
  int numMotions() { return s; }
  /* insert a vertex motion into object  */
  void insert(pVertex, double[3]);
  /* check if a vertex exists  */
  int inList(pVertex);
  /* get the i-th vertex in the object   */
  pVertex vertex(int i);

 private:
  pVertex vert[6];
  int s;
  double target[6][3];
};


inline pVertex vertMotionsMod::vertex(int i)
{
  if ( i >= s ) 
    return 0;
  return vert[i];
}

#endif


