#ifndef _H_MESHMODRESULTS
#define _H_MESHMODRESULTS

#define BIG_NUMBER 99999999


/* class to control and hold result data to be collected */

class evalResults {
 public:
  evalResults();
  ~evalResults() {}

  /* interface to set information */
  void reset();
  void setWorstShape(double v) { WorstShape=v; }
  void setMaxSize(double v) { maxSize=v; }
  void setMinSize(double v) { minSize=v; };
  void setMaxRatioSquare(double r) { maxRatio=r; }
  void setRatioSquareAtMaxSize(double r) { maxS_ratio=r; }
  void setSizeAtMaxRatio(double v) { maxR_size=v; }

  /* interface to get information */
  double getWorstShape() { return WorstShape; }
  double getMaxSize() { return maxSize; }
  double getMinSize() { return minSize; }
  double getMaxRatioSquare() { return maxRatio; }
  double getRatioSquareAtMaxSize() { return maxS_ratio; }
  double getSizeAtMaxRatio() { return maxR_size; }

 private:
  double WorstShape;
  double maxSize, maxS_ratio;
  double minSize;
  double maxRatio, maxR_size;
};

inline evalResults::evalResults()
{
  WorstShape=BIG_NUMBER;
  maxSize=0.0;
  minSize=BIG_NUMBER; 
  maxRatio=0.0;
}


inline void evalResults::reset()
{
  WorstShape=BIG_NUMBER;
  maxSize=0.0;
  minSize=BIG_NUMBER; 
  maxRatio=0.0;
}

#endif
