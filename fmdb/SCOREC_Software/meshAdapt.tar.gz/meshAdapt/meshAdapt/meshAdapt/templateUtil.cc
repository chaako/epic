#include "templateUtil.h"
#include "fromMeshTools.h"
#include "MeshSize.h"
#include <stdio.h>
#include <iostream>
#include <math.h>

#ifdef MVTK
#include "mvtk.h"
#endif

#ifdef AOMD_
#include <assert.h>
#include "FMDB_cint.h"
#include "FMDB_Internals.h"
#include "ParUtil.h"
#include "PList.h"
#ifdef MA_PARALLEL
using std::vector;
#include "paraAdapt.h"
#endif
#endif

using std::cout;
using std::endl;
using std::cerr;

#define ABS(x) ((x) < 0 ? -(x) : (x))

namespace templatesUtil {

  void mapping_template(
			pRegion region,
			pPList ordered_edges,
			pPList ordered_verts,
			int id,
			const int Eind[][6],
			const int Find[][4],
			const int Vind[][4],
			pFace parent_faces[4],
			pEdge parent_edges[6],
			int r_dirs[4],
			pVertex verts[4])
  {

    // get all the faces in a guaranteed order
    pPList ordered_faces=R_faces(region,1);
    
    // Mapping the ordered edges into a correspondent sub_template
    parent_edges[0] = (pEdge)PList_item(ordered_edges,Eind[id][0]);
    parent_edges[1] = (pEdge)PList_item(ordered_edges,Eind[id][1]);
    parent_edges[2] = (pEdge)PList_item(ordered_edges,Eind[id][2]);
    parent_edges[3] = (pEdge)PList_item(ordered_edges,Eind[id][3]);
    parent_edges[4] = (pEdge)PList_item(ordered_edges,Eind[id][4]);
    parent_edges[5] = (pEdge)PList_item(ordered_edges,Eind[id][5]);
    
    // Mapping the ordered faces into the correspondent sub_template
    parent_faces[0] = (pFace)PList_item(ordered_faces,Find[id][0]);
    parent_faces[1] = (pFace)PList_item(ordered_faces,Find[id][1]);
    parent_faces[2] = (pFace)PList_item(ordered_faces,Find[id][2]);
    parent_faces[3] = (pFace)PList_item(ordered_faces,Find[id][3]);
    
    // get the face use of parent faces
    r_dirs[0] = R_dirUsingFace(region,parent_faces[0]);
    r_dirs[1] = R_dirUsingFace(region,parent_faces[1]);
    r_dirs[2] = R_dirUsingFace(region,parent_faces[2]);
    r_dirs[3] = R_dirUsingFace(region,parent_faces[3]);
    
    // Mapping the ordered vertices into the correspondent sub_template
    verts[0]=(pVertex)PList_item(ordered_verts,Vind[id][0]);
    verts[1]=(pVertex)PList_item(ordered_verts,Vind[id][1]);
    verts[2]=(pVertex)PList_item(ordered_verts,Vind[id][2]);
    verts[3]=(pVertex)PList_item(ordered_verts,Vind[id][3]);
    
    // Free the memoryi
    PList_delete(ordered_faces);
    
    return;
  }


  void mapping_template_pyr(
                        pRegion region,
                        pPList ordered_edges,
                        int id,
                        pFace parent_faces[5],
                        pEdge parent_edges[8],
                        pVertex verts[5])
  {
    int Eind[4][8]={ {0,1,2,3,4,5,6,7}, {1,2,3,0,5,6,7,4}, {2,3,0,1,6,7,4,5}, {3,0,1,2,7,4,5,6} };
    int Find[4][5]={ {0,1,2,3,4}, {0,2,3,4,1}, {0,3,4,1,2}, {0,4,1,2,3} };
    int Vind[4][5]={ {0,1,2,3,4}, {1,2,3,0,4}, {2,3,0,1,4}, {3,0,1,2,4} };

    pPList ordered_verts=R_vertices(region,1);

    // get all the faces in a guaranteed order
    pPList ordered_faces=R_faces(region,1);

    // Mapping the ordered edges into a correspondent sub_template
    parent_edges[0] = (pEdge)PList_item(ordered_edges,Eind[id][0]);
    parent_edges[1] = (pEdge)PList_item(ordered_edges,Eind[id][1]);
    parent_edges[2] = (pEdge)PList_item(ordered_edges,Eind[id][2]);
    parent_edges[3] = (pEdge)PList_item(ordered_edges,Eind[id][3]);
    parent_edges[4] = (pEdge)PList_item(ordered_edges,Eind[id][4]);
    parent_edges[5] = (pEdge)PList_item(ordered_edges,Eind[id][5]);
    parent_edges[6] = (pEdge)PList_item(ordered_edges,Eind[id][6]);
    parent_edges[7] = (pEdge)PList_item(ordered_edges,Eind[id][7]);

    // Mapping the ordered faces into the correspondent sub_template
    parent_faces[0] = (pFace)PList_item(ordered_faces,Find[id][0]);
    parent_faces[1] = (pFace)PList_item(ordered_faces,Find[id][1]);
    parent_faces[2] = (pFace)PList_item(ordered_faces,Find[id][2]);
    parent_faces[3] = (pFace)PList_item(ordered_faces,Find[id][3]);
    parent_faces[4] = (pFace)PList_item(ordered_faces,Find[id][4]);

    // Mapping the ordered vertices into the correspondent sub_template
    verts[0]=(pVertex)PList_item(ordered_verts,Vind[id][0]);
    verts[1]=(pVertex)PList_item(ordered_verts,Vind[id][1]);
    verts[2]=(pVertex)PList_item(ordered_verts,Vind[id][2]);
    verts[3]=(pVertex)PList_item(ordered_verts,Vind[id][3]);
    verts[4]=(pVertex)PList_item(ordered_verts,Vind[id][4]);

    // Free the memory
    PList_delete(ordered_verts);
    PList_delete(ordered_faces);

    return;
  }


  void mapping_template_prism(
                        pRegion region,
                        pPList ordered_edges,
                        int id,
                        pFace parent_faces[5],
                        pEdge parent_edges[9],
                        pVertex verts[6])
  {
    int Eind[3][9]={ {0,1,2,3,4,5,6,7,8}, {1,2,0,4,5,3,7,8,6}, {2,0,1,5,3,4,8,6,7} };
    int Find[3][5]={ {0,1,2,3,4}, {0,2,3,1,4}, {0,3,1,2,4} };
    int Vind[3][6]={ {0,1,2,3,4,5}, {1,2,0,4,5,3}, {2,0,1,5,3,4} };

    pPList ordered_verts=R_vertices(region,1);

    // get all the faces in a guaranteed order
    pPList ordered_faces=R_faces(region,1);

    // Mapping the ordered edges into a correspondent sub_template
    parent_edges[0] = (pEdge)PList_item(ordered_edges,Eind[id][0]);
    parent_edges[1] = (pEdge)PList_item(ordered_edges,Eind[id][1]);
    parent_edges[2] = (pEdge)PList_item(ordered_edges,Eind[id][2]);
    parent_edges[3] = (pEdge)PList_item(ordered_edges,Eind[id][3]);
    parent_edges[4] = (pEdge)PList_item(ordered_edges,Eind[id][4]);
    parent_edges[5] = (pEdge)PList_item(ordered_edges,Eind[id][5]);
    parent_edges[6] = (pEdge)PList_item(ordered_edges,Eind[id][6]);
    parent_edges[7] = (pEdge)PList_item(ordered_edges,Eind[id][7]);
    parent_edges[8] = (pEdge)PList_item(ordered_edges,Eind[id][8]);

    // Mapping the ordered faces into the correspondent sub_template
    parent_faces[0] = (pFace)PList_item(ordered_faces,Find[id][0]);
    parent_faces[1] = (pFace)PList_item(ordered_faces,Find[id][1]);
    parent_faces[2] = (pFace)PList_item(ordered_faces,Find[id][2]);
    parent_faces[3] = (pFace)PList_item(ordered_faces,Find[id][3]);
    parent_faces[4] = (pFace)PList_item(ordered_faces,Find[id][4]);

    // Mapping the ordered vertices into the correspondent sub_template
    verts[0]=(pVertex)PList_item(ordered_verts,Vind[id][0]);
    verts[1]=(pVertex)PList_item(ordered_verts,Vind[id][1]);
    verts[2]=(pVertex)PList_item(ordered_verts,Vind[id][2]);
    verts[3]=(pVertex)PList_item(ordered_verts,Vind[id][3]);
    verts[4]=(pVertex)PList_item(ordered_verts,Vind[id][4]);
    verts[5]=(pVertex)PList_item(ordered_verts,Vind[id][5]);

    // Free the memory
    PList_delete(ordered_verts);
    PList_delete(ordered_faces);

    return;
  }

  /* given 4 vertices, compute its center and interpolate its mesh size */
  pMSize tetCenter(pVertex parent_verts[4], double xyz[3], pSField pSizeField)
  {
    double coords[3];
    pMSize pS;
    int i;
    pPList verts=PList_new();
    for(i=0; i<4; i++) {
      PList_append(verts,(pEntity)parent_verts[i]);
      V_coord(parent_verts[i],coords);
      xyz[0] += coords[0];
      xyz[1] += coords[1];
      xyz[2] += coords[2];
    }
    for(i=0; i<3; i++) xyz[i] /= 4.0;

    pS=pSizeField->getSize(xyz,verts);
    PList_delete(verts);
    return pS;
  }

  pMSize wedgeCenter(pVertex parent_verts[6], double xyz[3], pSField pSizeField)
  {
    double coords[3];
    pMSize pS;
    int i;
    for(i=0; i<6; i++) {
      V_coord(parent_verts[i],coords);
      xyz[0] += coords[0];
      xyz[1] += coords[1];
      xyz[2] += coords[2];
    }
    for(i=0; i<3; i++) xyz[i] /= 6.0;

    // this seems bad, but may reasonable
    pPList verts=PList_new();
    PList_append(verts,(pEntity)parent_verts[0]);
    PList_append(verts,(pEntity)parent_verts[1]);
    pS=pSizeField->getSize(xyz,verts);
    PList_delete(verts);
    return pS;
  }



  /*
    select the shortest diagonal to triangulate the tetrahedron
    By Xiang-rong Li   02/02/01
  */
  int shortestDiagonal(pPList ordered_verts, int bit, pSField pf) 
  {
    dArray E_xyz0, E_xyz1; // coordinates of the 2 vertices of an edge
    pMSize pEmt0=0, pEmt1=0;   // tensors attached to 2 vertices of an edge
    pVertex vts[4];
    double dist, shortest=0.;
    
    int i,j, id=-1;
    void *iter=0;
    int filter[]={1,2,4};
    
    for(i=0; i<4; i++)
      vts[i]=(pVertex)PList_next(ordered_verts,&iter); 

    for( i=0; i<3; i++ ) 
      if( bit & filter[i] ) {
	j=(i+1)%3;
	pf->center(vts[i],vts[j],E_xyz0,&pEmt0);
	j=(i+2)%3;
	pf->center(vts[3],vts[j],E_xyz1,&pEmt1);
       
        dist = pf->lengthSq(E_xyz0,E_xyz1,pEmt0,pEmt1);
	if(pEmt0) 
          delete pEmt0;
        if(pEmt1)
	  delete pEmt1;

	if( id==-1 || shortest > dist )
	  { shortest=dist; id=i; }
      }
    
    return id;
  }


  void map_vertices(pFace face, pVertex verts[3], int n[3])
  {
    int dir;
    pEdge edge;
    pVertex verts_2[3];
    int i;
    
    // get the three vertices in the order the face is define
    for (i= 0; i< 3; i++) {
      edge= F_edge(face,i);
      dir= F_edgeDir(face,i);
      verts_2[i]= E_vertex(edge,!dir);
    }
    
    if(verts[0]==verts_2[0]) {
      n[0]=0;
      if (verts[1]==verts_2[1]) { n[1]=1;  n[2]=2; }
      else {  n[1]=2; n[2]=1; }
    }
    else if (verts[0]==verts_2[1]) {
      n[0]=1;
      if (verts[1]==verts_2[2]) { n[1]=2;  n[2]=0; }
      else {  n[1]=0; n[2]=2; }
    }
    else if (verts[0]==verts_2[2]) {
      n[0]=2;
      if (verts[1]==verts_2[0]) { n[1]=0;  n[2]=1; }
      else {  n[1]=1; n[2]=0; }
    }
  }
  
  
  /*
    Given an edge, computer the parameter(s) and coordinates of its middle point
    return  0: unable to get the parameter;
    1: indicate the edge is classified on model edge;
    2: indicate the edge is classified on model face;
    
    geometery degeneracy:  -1 no degeneracy
    we do not take care of degenerated model edge
    If Given edge is classified on model face: it could be 0,1,2,3,4,5,6
         0 the 2nd direction of 1st bounding vertex of the edge is degenercy
         1 the 1st direction of 1st bounding vertex of the edge is degenercy 
         2 both direction of 1st bounding vertex of the edge is degenercy
         3 the 2nd direction of 2nd bounding vertex of the edge is degenercy
         4 the 1st direction of 2nd bounding vertex of the edge is degenercy
         5 both direction of 2nd bounding vertex of the edge is degenercy
         6 both direction of both bounding vertex of the edge is degenercy
    we can not think of a case where 2,5,6 happens.

     6/28/99     Xiangrong Li
    10/04/00     recognize geometry degeneracy   -Li
    10/17/00
    12/14/02     accept the parameter to interpolate the new location  -li
  */
  int middlePoint(pEdge edge, double t, double *coords, double *par)
  {
    double xyz[2][3];
    pPoint points[2];
    pVertex verts[2];
    pGEntity g_entity;
    int type;
    int degeneracy=-1;   // no denegeracy
    int i;
    int ok;
    double tol,tmpTol;
    
    type=E_whatInType(edge); 
    if( type==Gregion ) 
      return 0;

//  #ifdef MVTK
//      mvtkAddMEnt((pEntity)edge);
//      pFace face_2;
//      for(i=0; i<E_numFaces(edge); i++ ) {
//        face_2=E_face(edge,i);
//        if( F_whatInType(face_2)!=Gregion ) 
//  	mvtkAddMEnt((pEntity)face_2);
//      }
//  #endif
    
    verts[0]=E_vertex(edge,0);
    verts[1]=E_vertex(edge,1);
    
    points[0]=V_point(verts[0]);
    points[1]=V_point(verts[1]);
    
    for(i=0;i<2;i++) {
      xyz[i][0]=P_x(points[i]);
      xyz[i][1]=P_y(points[i]);
      xyz[i][2]=P_z(points[i]);
    }
    
    g_entity=E_whatIn(edge);
    tol=GEN_tolerance(g_entity);
    
    if(type==Tedge) {
      double epar[2];
      double erange[2];
      
      // get the parameters of the two end vertices
      for(i=0; i<2; i++) {
	int vType=V_whatInType(verts[i]);
	if(vType==Tedge) 
	  epar[i]=P_param1(points[i]);
	else if (vType==Tvertex) {
	  pGVertex gv = (pGVertex)V_whatIn(verts[i]);
	  tmpTol=GEN_tolerance((pGEntity)gv);
	  if( tmpTol>tol ) tol=tmpTol;
	  epar[i]=GE_vertexReparam((pGEdge)g_entity, gv);
	}
      }
      
      GE_parRange((pGEdge)g_entity,&erange[0],&erange[1]);
      ok=bisectParam1(t,epar,xyz,(pGEdge)g_entity,erange,coords,par,tol,0);
    }
    
    else {
      
      // get the parameters of the two end vertices
      double fpar[2][3];
      double frange[2][2];
      int seams[2]={0, 0};
      int VertType[2]={2, 2};
      int num;
      
      for(i=0; i<2; i++) {
	
	int vType  = V_whatInType(verts[i]);
	
	if (vType==Tvertex) {
	  pGVertex gv= (pGVertex)V_whatIn(verts[i]);
	  tmpTol=GEN_tolerance((pGEntity)gv);
	  if( tmpTol>tol ) tol=tmpTol;
	  GF_vertexReparam((pGFace)g_entity, gv, fpar[i]);
	  seams[i]=GV_isonSeam(gv,(pGFace)g_entity);
	  VertType[i]=0;
	}
	else if(vType==Tedge) {
	  double e_par=P_param1(points[i]);
	  pGEdge ge= (pGEdge)V_whatIn(verts[i]);
	  tmpTol=GEN_tolerance((pGEntity)ge);
	  if( tmpTol>tol ) tol=tmpTol;
	  GF_edgeReparam((pGFace)g_entity, ge, e_par, 1, fpar[i]);
	  seams[i]=GE_isSeam(ge, (pGFace)g_entity);
	  VertType[i]=1;
	}
	else if (vType==Tface)
	  P_param2(points[i],&fpar[i][0],&fpar[i][1],(int*)&fpar[i][2]);
	
	// see if this location is degenerated
	num=ifDegenerated((pGFace)g_entity,fpar[i],tol);
	if( num!=-1 ) { 
	  // Degeneracy detected 
	  degeneracy=i*3+num;
	}
      }

//  #ifdef DEBUG
//        double parDistSq=(fpar[0][0]-fpar[1][0])*(fpar[0][0]-fpar[1][0]) 
//  	             + (fpar[0][1]-fpar[1][1])*(fpar[0][1]-fpar[1][1]);
//        if( parDistSq < tol*tol ) {
//  	printf("Error: distance square in parametric space: %20.1f \n",parDistSq);
//  	printf("       v0=%p type=%d par:(%f,%f) \n",verts[0],V_whatInType(verts[0]),fpar[0][0],fpar[0][1]);
//  	printf("       v1=%p type=%d par:(%f,%f) \n",verts[1],V_whatInType(verts[1]),fpar[1][0],fpar[1][1]);
//  	throw;
//        }
//  #endif

      // get par range
      GF_parRange((pGFace)g_entity,0,&frange[0][0],&frange[0][1]);
      GF_parRange((pGFace)g_entity,1,&frange[1][0],&frange[1][1]);
      
      // computer the parameter
      ok=bisectParam2(t,fpar,xyz,(pGFace)g_entity,seams,VertType,frange,degeneracy,coords,par,tol,0);
    }

//  #ifdef MVTK
//      mvtkRemoveAllMEnts();
//      mvtkRemoveAllGeos();
//  #endif
    return ok;
  }

  
  int bisectParam1(
		   double t,
		   double *par,
		   double xyz[2][3],
		   pGEdge gedge,
		   double range[2],
		   double *coords,
		   double *m_par,
		   double tol,
		   int count)
  {
    //double l[2];
    double vec[3], v1[3], v2[3], dot1, dot2, tPrime;
    
    // computer the parameter of middle point
    *m_par=(1-t)*par[0] + t*par[1];
    
    if(GE_periodic(gedge) || GE_isClosed(gedge)) {
      
      double Half_Period=0.5*(range[1]-range[0]);
      double span=ABS(par[1]-par[0]);
      
      if( (span-Half_Period)>tol) {
	if( par[0] > par[1] )
	  par[1] += 2.0*Half_Period;
	else
	  par[0] += 2.0*Half_Period;
	*m_par=(1-t)*par[0] + t*par[1];
#ifdef DEBUG
	if( ABS(par[1]-par[0]) > Half_Period )
	  printf("problem in handling periodic edges\n");
#endif
	if (*m_par >= range[1])    
	  *m_par -= 2.0*Half_Period;
      } else if ( ABS(span-Half_Period)<tol ) {
	cerr << "Half period par difference: coloring info needed !" << endl;
	return 0;
      }
    }
    
    // check if the value is  valid
    if (*m_par < range[0] || *m_par > range[1]) {
      //      cerr << "bisectParam1: parameter out of range" << endl;
      return 0;
    }
    
    // calculate the xyz coordinates of the middle point
    GE_point(gedge, *m_par, coords);

//    double pxyz[2][3];
//    GE_point(gedge, par[0], pxyz[0]);
//    GE_point(gedge, par[1], pxyz[1]);

    // compute ratio of the projection 
    diffVt(xyz[1],xyz[0],vec);
    diffVt(coords,xyz[0],v1);
    diffVt(xyz[1],coords,v2);
    dot1 = dotProd(v1,vec);
    dot2 = dotProd(v2,vec);
    if( dot1<=0 && dot2<=0 ) {
#ifdef DEBUG
      printf("Warning: not possible projection happened (bisectParam1)\n");
#endif
      return 1;
    }
    if( dot2<=0 ) 
      par[1]=*m_par;
    if( dot1<=0 )
      par[0]=*m_par;
    
    if( dot2>0 && dot1>0 ) {
      tPrime= dot1/(dot1+dot2);
      
      // if the two ratio are close, return
      //    otherwise recursively bisect
      if( tPrime >= t ) {
	if( tPrime < 1.5*t ) return 1; 
	par[1]=*m_par;
      }
      else {
	if( tPrime >= 0.5*t ) return 1;
	par[0]=*m_par;
      }
    }

//   // computer the distance square from this middle point to its two end vertices
//   for(int i=0;i<2;i++)
//     l[i]=(xyz[i][0]-coords[0])*(xyz[i][0]-coords[0])+
//          (xyz[i][1]-coords[1])*(xyz[i][1]-coords[1])+
//          (xyz[i][2]-coords[2])*(xyz[i][2]-coords[2]);

//   // if the ratio of square distance is less than 0.5, return;
//   //    otherwise bisect the domain recursively
//   if(l[0]>=l[1]) {
//     if(l[1]/l[0] > 0.5) return 1;
//     par[1]=*m_par;
//   }
//   else {
//     if(l[0]/l[1] > 0.5) return 1;
//     par[0]=*m_par;
//   }

#ifdef DEBUG
  cerr << "Info: recursive bisection is invoked (bisectParam1) " << endl;
  printf("  P (%f %f %f) (%f)\n  Q (%f %f %f) (%f)\n  middle (%f %f %f) (%f)\n",
	 xyz[0][0],xyz[0][1],xyz[0][2],par[0],
	 xyz[1][0],xyz[1][1],xyz[1][2],par[1],
	 coords[0],coords[1],coords[2],m_par);
	 //exit(1);
#endif
  count++;
  if ( count > 20 ) {
    cerr << "\n!!! WARNING bisectParam1: recursive bisection was invoked !!!\n";
    cerr << "!!! Check if your mesh is correct !!!" << endl << endl;
    return 0;
  }
  return  bisectParam1(t,par,xyz,gedge,range,coords,m_par,tol,count);
}


int bisectParam2(
  double t,          // input: the parameter wrt the edge with t=0 at E_vertex(edge,0)
  double par[2][3],  // input: the parametric domain that will be bisected
  double xyz[2][3],  // input: coordinates of the two end vertices
  pGFace gface,      // input: tag of the model face
  int seams[2],      // input: if the edge vertices is on seam 0,1,or2
  int VertType[2],   // input: 0 if vert is classified on model vertex, 1 if model edge and  2 if model face
  double range[2][2],// input: range in two directions
  int degeneracy,    // input: geometry degeneracy indicator
  double *coords,    // output: coordinates of the parametric middle point
  double *m_par,     // output: parameter of the middle point
  double tol,
  int count)
{
  //  double l[2];
  double vec[3], v1[3], v2[3], dot1,dot2, tPrime;
  
  // computer the parameter of middle point
  for(int j=0;j<2;j++) {

    if( j==0 ) {
      if( degeneracy == 1 )
        { m_par[j]=par[1][j]; continue; }
      else if( degeneracy == 4 )
        { m_par[j]=par[0][j]; continue; }
    } else {
      if( degeneracy == 0 )
        { m_par[j]=par[1][j]; continue; }
      else if( degeneracy == 3 )
        { m_par[j]=par[0][j]; continue; }  
    }
    //    m_par[j]=0.5*(par[0][j]+par[1][j]);
    m_par[j]=(1-t)*par[0][j] + t*par[1][j];

    if(ifAddPeriod(gface,seams,VertType,j,par,range)) {

      double Half_Period=0.5*(range[j][1]-range[j][0]);
      double span=ABS(par[1][j]-par[0][j]);

      if(span > Half_Period+tol) {
 	if( par[0][j] > par[1][j] )
	  par[1][j] += 2.0*Half_Period;
	else
	  par[0][j] += 2.0*Half_Period;
	m_par[j]=(1-t)*par[0][j] + t*par[1][j];
#ifdef DEBUG
	if( ABS(par[1][j]-par[0][j]) > Half_Period )
	  printf("problem in handling periodic edges\n");
#endif
      } else if ( ABS(span-Half_Period)<tol ) {
        cerr << "Half period par difference: coloring info needed !" << endl;
        return 0;
      }

      // ensure the parameter in the range  8/8/03 -Li
      if (m_par[j] >= range[j][1])  
	m_par[j] -= 2.0*Half_Period;
      else if ( m_par[j] < range[j][0] )
	m_par[j] += 2.0*Half_Period;
    }
  }
  
  // check if the value is  valid
  for(int j=0;j<2;j++) {
    if (m_par[j] < range[j][0] || m_par[j] > range[j][1]) {
      //      cerr << "bisectParam2: parameter out of range" << endl;
      return 0;
    }
  }


  GF_point(gface, m_par, coords);

  // compute ratio of the projection 
  diffVt(xyz[1],xyz[0],vec);
  diffVt(coords,xyz[0],v1);
  diffVt(xyz[1],coords,v2);
  dot1 = dotProd(v1,vec);
  dot2 = dotProd(v2,vec);
  if( dot1<=0 && dot2<=0 ) {
#ifdef DEBUG
    printf("Warning: not possible projection happened (bisectParam2)\n");
#endif
    return 0;
  }
  if( dot2<=0 ) {
    par[1][0]=m_par[0];
    par[1][1]=m_par[1];
    seams[1]=0;
  }
  if( dot1<=0 ) {
    par[0][0]=m_par[0];
    par[0][1]=m_par[1];
    seams[0]=0;
  }

  tPrime=0;
  if( dot2>0 && dot1>0 ) {
    tPrime= dot1/(dot1+dot2);
    // if the two ratio are close, return
    //    otherwise recursively bisect
    if( tPrime >= t ) {
      if( tPrime < 1.5*t ) return 2; 
      par[1][0]=m_par[0];
      par[1][1]=m_par[1];
      seams[1]=0;
    }
    else {
      if( tPrime >= 0.5*t ) return 2;   
      par[0][0]=m_par[0];
      par[0][1]=m_par[1];
      seams[0]=0;
    }
  }

//   for(int i=0;i<2;i++)
//     l[i]=(xyz[i][0]-coords[0])*(xyz[i][0]-coords[0])+
//          (xyz[i][1]-coords[1])*(xyz[i][1]-coords[1])+
//          (xyz[i][2]-coords[2])*(xyz[i][2]-coords[2]);

//   if(l[0]>=l[1]) {
//     if(l[1]/l[0] > 0.5) return 2;
//     par[1][0]=m_par[0];
//     par[1][1]=m_par[1];
//     seams[1]=0;
//   }
//   else {
//     if(l[0]/l[1] > 0.5) return 2;
//     par[0][0]=m_par[0];
//     par[0][1]=m_par[1];
//     seams[0]=0;
//   }

#ifdef DEBUG
  printf("Info: recursive bisection: t=%f, tPrime=%f (bisectParam2)\n",t,tPrime);
  printf("  P (%f %f %f) (%f %f)\n  Q (%f %f %f) (%f %f)\n  middle (%f %f %f) (%f %f)\n",
	 xyz[0][0],xyz[0][1],xyz[0][2],par[0][0],par[0][1],
	 xyz[1][0],xyz[1][1],xyz[1][2],par[1][0],par[1][1],
	 coords[0],coords[1],coords[2],m_par[0],m_par[1]);
#endif
  count++;
  if ( count > 20 ) {
    cerr << "\n!!! WARNING bisectParam2: recursive bisection was invoked !!!\n";
    cerr << "!!! Check if your mesh is correct : use SMS sim format !!!" << endl << endl;
    return 0;
  }
//  #ifdef MVTK
//    pVisSimRep pP=mvtkAddPoint(coords);
//    pVisSimRep pL=mvtkAddLine(xyz[0],xyz[1]);
//    mvtkActivate();
//  #endif
  int ok=bisectParam2(t,par,xyz,gface,seams,VertType,range,degeneracy,coords,m_par,tol,count);
//  #ifdef MVTK
//    if( ok==2 ) {
//      printf("new location converged\n");    
//      pVisSimRep pP2=mvtkAddPoint(coords);
//      mvtkActivate();
//    }
//  #endif
  return ok;
}

/*
 check if a model vertex is on the seam of model face
 return 0: it is not on seam
        1: it is on a seam
        2: it is the intersection of two seams
*/
int GV_isonSeam(pGVertex gv, pGFace gf)
{
 pGEdge ge;
 int seam_nbr=0;
 void* temp=0;

 pPList gelist = GV_edges(gv);
 while(ge=(pGEdge)PList_next(gelist,&temp)) {
   if(GF_inClosure(gf,(pGEntity)ge))
     if(GE_isSeam(ge,gf))
       ++seam_nbr;
 }
 PList_delete(gelist);

#ifdef DEBUG
 if(seam_nbr > 2)
   cerr << "GV_isSeam: pb!" << endl;
#endif

 return seam_nbr;
}


/*
  check if an edge is closed
  return 1: closed
         0: not closed
*/
int GE_isClosed(pGEdge ge)
{
  pGVertex v1,v2;
  void *temp=0;

  pPList gvlist=GE_vertices(ge);

  v1=(pGVertex)PList_next(gvlist,&temp);
  v2=(pGVertex)PList_next(gvlist,&temp);

  PList_delete(gvlist);

  if(v1==v2)
    return 1;
  else
    return 0;
}


/*
  Given a model face and a direction, Check if the parameter in specified
  direction needs updating by adding a period

  return 0: do not need adjusting
         1: need
        -1: something wrong

  8/12/99     Xiangrong Li
*/
int ifAddPeriod(
  pGFace gface,
  int seams[2],
  int VertType[2],
  int dir,
  double par[2][3],
  double range[2][2])
{
  int i;

  // if model face is periodic in this direction
  if(GF_periodic(gface,dir))   return 1;

  // if both end vertices of the edge are not on seam
  if(seams[0]==0 && seams[1]==0) return 0;

  // if either of the end vertices is the cross point of two seam
  if(seams[0]==2 || seams[1]==2) return 1;

  // if the two end vertices are on two different seam
  if(seams[0]==1 && seams[1]==1) return 1;

  // here, we have known that there is one and only one parametric
  // direction that needs add period. Check if it is the given "dir"
  double tol=GEN_tolerance((pGEntity)gface);
  for(i=0; i<2; i++) {

    // vert[i] is on seam
    if(seams[i]==1) {

      // if vert[i] is classified on model edge
      if(VertType[i]==1) {
        if((par[i][dir]-range[dir][0])<tol || (range[dir][1]-par[i][dir])<tol)
          return 1;
        else
          return 0;
      }

      // if vert[i] is classified on model vertex
      else if (VertType[i]==0) {

        double fpar[2];
        double xyz[2][3];
        double vec[3];

        // get the xyz coordinates of this vertex
        fpar[0]=par[i][0];
        fpar[1]=par[i][1];
        GF_point(gface, fpar,xyz[0]);

        // get xyz coordinates of this vertex with its parameter in "dir" moved
        // to another end of parameter range
        if((fpar[dir]-range[dir][0])<tol)
          fpar[dir]=range[dir][1];
        else
          fpar[dir]=range[dir][0];
        GF_point(gface, fpar,xyz[1]);

        // calculate distance of these two points
        diffVt(xyz[0],xyz[1],vec);
        if(dotProd(vec,vec) <= tol*tol)
          return 1;
        else
          return 0;
      }

      // it is impossible that vert[i] is classified on model face
      else
        cerr << "ifAddPeriod: pb!" << endl;
    }
  }
  return -1;
}


// check the degeneracy of a location in parametric space
// if model face has no degeneracy, return -1
// if model face has degeneracy, but the location is not degenerated, return -1
// if model face has degeneracy and the location is degenerated, 
//        return 0  if a location in 1st parametric direction is degenerated (2nd parameter uncertain)
//               1  if a location in 2nd parametric direction is degenerated (1st parameter uncertain)
int ifDegenerated(pGFace gf, double *par, double tol)
{
  double depar[2];
  int i,dir;

  for( dir=0; dir<2; dir++ ) {
    int num=GF_paramDegeneracies(gf, dir, depar);
    for( i=0; i<num; i++ )
      if( ABS(par[dir]-depar[i])<tol ) 
        return dir;
  }

  return -1;
}


int Edge_colaps(pMesh pm, pEdge pe, pVertex vd, pVertex vr, 
		CBFunction CB, void *userData, pPList *newRegs)
#ifdef MATCHING
{
  pPList newEds; 
  pPList newFcs; 
  Edge_colaps(pm, pe, vd, vr, CB, userData, &newEds, &newFcs, newRegs); 
  PList_delete(newEds);
  PList_delete(newFcs);
}

int Edge_colaps(pMesh pm, pEdge pe, pVertex vd, pVertex vr, 
                CBFunction CB, void *userData, 
 pPList *newEds,  
 pPList *newFcs,     
  pPList *newRegs)      
#endif          
{
  int flag;
  pPList delRegs=E_regions(pe);
#ifndef MATCHING
  flag=fromMeshTools::E_colaps(pm, pe, vd, vr, CB, userData, delRegs, newRegs);
#else 
 flag=fromMeshTools::E_colaps(pm, pe, vd, vr, CB, userData,delRegs, newEds, newFcs, newRegs);
#endif
  PList_delete(delRegs);
  return flag;
}

pVertex Edge_split(pMesh pm, pEdge pe, double *xyz, double *parm,
	       CBFunction CB, void *userData, pPList *newRegs)
{
  return fromMeshTools::E_split(pm,pe,xyz,parm,CB,userData,newRegs);
}


int Edge_swap(pMesh pm, pEdge pe, int conf, 
	      CBFunction CB, void *userData, pPList *newRegs) 
{
  return fromMeshTools::E_swap(pm, pe, conf, CB, userData, newRegs);
}

pEdge Edge_swapOnGFace(pMesh mesh, pEdge swpedge, pGEntity gface,    
		       CBFunction CB, void *userData, pPList *newFcs)
{
  return fromMeshTools::E_swapOnGFace(mesh,swpedge,gface,CB,userData,newFcs);
}

int Face_swap(pMesh mesh, pFace face, double mtol,    
	      CBFunction CB, void *userData, pPList *newRegs)
{
  int flag;
  pPList delRegs;
  flag=fromMeshTools::F_swap(mesh,face,mtol,CB,userData,&delRegs,newRegs);
  PList_delete(delRegs);
  return flag;
}



#ifdef CURVE
/* return 1: if the face is curved
          0: otherwise
   Created 3/16/2000    Xiangrong Li  */
int isFaceCurved(pFace face)
{
//  if(F_numPoints(face))  return 1;

  for(int i=0; i<F_numEdges(face); i++)
    if(E_numPoints(F_edge(face,i)))
      return 1;

  return 0;
}
#endif

}

