#ifndef _H_MA_WRITEVTU
#define _H_MA_WRITEVTU

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include "FMDB.h"
#include "ParUtil.h"
#include "FMDB_Internals.h"
using namespace std; 

void MA_exportPVTU(const char* fname, int numPtn, int numdof);


void MA_exportVTU(const char* fname, pMesh mesh, pMeshDataId field, int numdof);

// fname should be given without extension. 
void MA_writeVTUFile (pMesh mesh,const char * fname, pMeshDataId field, int numdof);

#endif
