#ifndef _H_MSIZE
#define _H_MSIZE


class MeshSize
{
 public:
  MeshSize(double e[3][3], double h[3]);
  MeshSize(double);
  MeshSize(MeshSize *);
  ~MeshSize() {};

  // get a principle direction
  double *eigenvector(int i) { return e[i]; }
  // get the desired size in a principle direction
  double size(int i) { return h[i]; }
  // get the desired size in the given direction
  double dirLengthSq(double dir[3]);
  // scale the desired size in the given direction
  void scale(int, double);
  void scale(double);
  // compute the transformed vector wrt this metric
  void transform(double[3], double[3]);
  // compute the reciprocal of max aspect ratio
  double aspectRatio(int);
  double aspectRatio2(int);

 protected:
  double h[3];
  double e[3][3];
};


#endif
