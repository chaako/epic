#include "PWLinearSField.h"
#include "paraAdapt.h"
#include "paraTemplateUtil.h"
#include "MeshSize.h"
#include "AdaptUtil.h"
#include <stdio.h>
#include <math.h>
#include "PList.h"
#include "FMDB_cint.h"

#define MAX(x,y) ((x)<(y) ? (y) : (x))
#define MIN(x,y) ((x)>(y) ? (y) : (x))

using namespace std;

PWLsfield::PWLsfield(pMesh pm)
{
  backMesh=pm;
  pMSizeFieldId=MD_newMeshDataId("pMSize");

  dim = 2;
#ifndef MA_PARALLEL
  if( M_numRegions(backMesh) )
    dim=3;
#else
#ifdef AOMD_ // PAOMD
//  if (P_getMaxInt(M_numRegions(backMesh))!=0 ) 
  if (M_globalMaxDim(pm) == 3)
#else  // PMESH
  if(M_numRegions(backMesh)!=0 ) 
#endif  
    dim=3;
#endif
}
 
PWLsfield::~PWLsfield()
{
  VIter iter=M_vertexIter(backMesh);
  pVertex v;
  while( (v=VIter_next(iter)) ) 
    deleteSize((pEntity)v);
  VIter_delete(iter);
  MD_deleteMeshDataId(pMSizeFieldId);
}


// specify metric based on directions and desired edge lengths
void PWLsfield::setSize(pEntity ent, 
			double dirs[3][3], // three unit vectors
			double h[3])       // three desired length
{
  pMSize pS=new MeshSize(dirs,h);
  setSize(ent,pS);
}


// specify metric based on desired edge length
void PWLsfield::setSize(pEntity ent, double h)
{
  pMSize pS=new MeshSize(h);
  setSize(ent,pS);
}


void PWLsfield::setSize(pEntity ent, pMSize pS)
{
  void *tmp;
  if( EN_getDataPtr(ent,pMSizeFieldId,&tmp) ) 
    {
      delete (pMSize)tmp;
      EN_modifyDataPtr(ent,pMSizeFieldId,pS);
    }
  else
    EN_attachDataPtr(ent,pMSizeFieldId,pS);

  return;
}


void PWLsfield::deleteSize(pEntity ent)
{
  void *tmp;
  if( EN_getDataPtr(ent,pMSizeFieldId,&tmp) )
    {
      EN_deleteData(ent,pMSizeFieldId);
      delete (pMSize)tmp; 
    }
}


double PWLsfield::lengthSq(pEdge edge)
{
  pVertex v;
  dArray xyz[2];
  pMSize pS[2];
  for( int i=0; i<2; i++ )
    {
      v=E_vertex(edge,i);
      V_coord(v,xyz[i]);
      pS[i]=getSize(v);
    }
  return lengthSq(xyz[0],xyz[1],pS[0],pS[1]);
}

double PWLsfield::lengthSq(pVertex v0, pVertex v1)
{
  dArray xyz[2];
  pMSize pS[2];
  V_coord(v0,xyz[0]);
  V_coord(v1,xyz[1]);
  pS[0]=getSize(v0);
  pS[1]=getSize(v1);
  return lengthSq(xyz[0],xyz[1],pS[0],pS[1]);
}

double PWLsfield::areaSq(pFace face)
{
  dArray fxyz[3];
  pMSize pS;
  pVertex vt;

  void *iter=0;
  int i=0;
  pPList verts=F_vertices(face,1);
  while( (vt=(pVertex)PList_next(verts,&iter)) )
    V_coord(vt,fxyz[i++]);

  double S=0;
  iter=0;
  while( (vt=(pVertex)PList_next(verts,&iter)) )
    {
      pS=getSize(vt);
      S += areaSq(fxyz,pS,0);
    }
  S /= PList_size(verts);
  PList_delete(verts);

  return S;
}

double PWLsfield::volume(pRegion region)
{
  dArray rxyz[4];
  pMSize pS;
  pVertex vt;

  void *iter=0;
  pPList verts=R_vertices(region,1);
  int i=0;
  while( (vt=(pVertex)PList_next(verts,&iter)) )
    V_coord(vt,rxyz[i++]);

  iter=0;
  double Vol=0;
  while( (vt=(pVertex)PList_next(verts,&iter)) )
    {
      pS=getSize(vt);
      Vol += volume(rxyz,pS);
    }
  Vol /= PList_size(verts);
  PList_delete(verts);

  return Vol;  
}


double PWLsfield::lengthSq(dArray loc1, dArray loc2, 
			   pMSize pS0, pMSize pS1)
{
  if( pS0 && pS1 )
    {
      double vec[3],tvec[3],lenSq0, lenSq1;
      diffVt(loc1,loc2,vec);
      pS0->transform(vec,tvec);
      lenSq0=dotProd(tvec,tvec);
      pS1->transform(vec,tvec);
      lenSq1=dotProd(tvec,tvec);
      return sqrt(lenSq0*lenSq1);
    }
 
  printf("Error: size not defined !!! PWLsfield::lengthSq()\n");
  return 0;
}


double PWLsfield::lengthSq(dArray loc1, dArray loc2, pMSize pS)
{
  if( pS )
    {
      double vec[3],tvec[3];
      diffVt(loc1,loc2,vec);
      pS->transform(vec,tvec);
      return dotProd(tvec,tvec);
    }
 
  printf("Error: size not defined !!! PWLsfield::lengthSq()\n");
  return 0;
}


double PWLsfield::areaSq(dArray fxyz[3], pMSize pS, dArray posDir)
{
  double v01[3],v02[3],nor[3];	
  double areaS, detSq;	
  double dcos[3], h[3];
  int j;

  if( !pS )
    { 
     printf("Error: size not defined !!! PWLsfield::areaSq()\n");     
     return 0;
    }
    
  diffVt(fxyz[1],fxyz[0],v01) ;
  diffVt(fxyz[2],fxyz[0],v02) ;
  // compute normal
  crossProd(v01,v02,nor);
  // compute area square in physical space
  if( posDir && dotProd(posDir,nor) < 0. )
    return 0;
  else      
    areaS = 0.25*dotProd(nor,nor) ;

  // normalize the norm
  if( areaS <= M_getTolerance() )
    return 0;
  normVt(nor,nor);  // can save a dotProd by making use of area

  // compute the determinant of Jacobi
  for( j=0; j<3; j++ ) {
    dcos[j]=dotProd(nor,pS->eigenvector(j));
    h[j]=pS->size(j);
  }
  dcos[0] /= (h[1]*h[2]);
  dcos[1] /= (h[0]*h[2]);
  dcos[2] /= (h[1]*h[0]);
  detSq = dotProd(dcos,dcos);
  
  // return the area in transformed space
  return detSq*areaS;
}

double PWLsfield::volume(dArray rxyz[4], pMSize pS)
{
  if( !pS )
    { 
     printf("Error: size not defined !!! PWLsfield::volume()\n");     
     return 0;
    }
  return (XYZ_volume(rxyz)/(pS->size(0)*pS->size(1)*pS->size(2)));
}

double PWLsfield::angleSq(dArray, dArray, pMSize)
{
   printf("Not implemented (PWLsfield::angleSq)\n");
   return 0;
}


void PWLsfield::decomposeMetricTensor(pVertex vtx, dArray Normal) 
{
  pMSize pS = getSize(vtx);

  pMSize pSNew = decomposeMetricTensor(pS,Normal);

  deleteSize((pEntity)vtx);
  setSize((pEntity)vtx,pSNew);
}


pMSize PWLsfield::decomposeMetricTensor(pMSize pS, dArray Normal) 
{
  pMSize pSNew;
  double tol = 1.e-2;
  double normal[3], dir[3][3], h[3], dotNormal[3];
  double *e;

  normVt(Normal,normal);

  for(int i=0; i<3; i++) {
    e = pS->eigenvector(i);
    h[i] = pS->size(i);
    for(int j=0; j<3; j++)
      dir[i][j] = e[j];
  }

  double maxDotProd = 0.;
  int mostAligned;
  int smallestInOtherTwo = 1;
  for(int i=0; i<3; i++) {
    dotNormal[i] = fabs(dotProd(normal,dir[i]));
    if(fabs(dotNormal[i]-1.)<tol) {
      pSNew = new MeshSize(dir,h);
      return pSNew;
    }
    if(dotNormal[i] > maxDotProd) {
      maxDotProd = dotNormal[i];
      mostAligned = i;
      if(mostAligned)
        smallestInOtherTwo = 0;
    }
  }

  // h[0] is smallest and h[2] is largest
  // 1 - ellipsoid
  // 2 - prolate spheroid (with h[0] close to h[1]) (prolate)
  // 3 - oblate  spheroid (with h[1] close to h[2]) (oblate)
  // 4 - sphere
  int metricType = 0;
  int dirToProj;

  // to check for anisotropy
  double AR = 1.5;

  dirToProj = smallestInOtherTwo;
  if(h[2]/h[0]>AR) {
    if(h[1]/h[0]>AR) {
      metricType = 1;
      if(h[2]/h[1]<AR) {
        metricType = 3;
      }
    }
    else {
      metricType = 2;
      if(mostAligned!=2)
        dirToProj = 2;
    }
  }
  else {
    metricType = 4;
  }

//   if(h[1]/h[0]>AR) {
//     if(!(dotNormal[0]>dotNormal[1] && dotNormal[0]>dotNormal[2])) {
//       // cout<<"For anisotropic sizefield - ";
//       // cout<<"normal NOT close to principal dir. of smallest size"<<endl;
//       return;
//     }
//   }

  double dot;
  dot = dotProd(normal,dir[dirToProj]);

  double projDir[2][3];
  for(int i=0; i<3; i++)
    projDir[0][i] = dir[dirToProj][i] - dot*normal[i];

  normVt(projDir[0],projDir[0]);

  crossProd(normal,projDir[0],projDir[1]);
  normVt(projDir[1],projDir[1]);

  double proj[3];
  int thirdDir;
  proj[mostAligned] = fabs(dotProd(normal,dir[mostAligned]));
  proj[dirToProj] = fabs(dotProd(projDir[0],dir[dirToProj]));
  for(int i=0; i<3; i++) {
    if(i==mostAligned || i==dirToProj)
      continue;
    thirdDir = i;
    proj[thirdDir] = fabs(dotProd(projDir[1],dir[thirdDir]));
  }

  // project the other two directions on the
  // tangential plane (i.e., perpendicular to normal)
  for(int i=0; i<3; i++) {
    dir[mostAligned][i] = normal[i];
    dir[dirToProj][i] = projDir[0][i];
    dir[thirdDir][i] = projDir[1][i];
  }

  // project the three sizes
  for(int i=0; i<3; i++)
    h[i] = h[i]*proj[i];

  double modSizes[3];
  modSizes[mostAligned] = sqrt(pS->dirLengthSq(normal));
  modSizes[dirToProj] = sqrt(pS->dirLengthSq(projDir[0]));
  modSizes[thirdDir] = sqrt(pS->dirLengthSq(projDir[1]));

  for(int i=0; i<3; i++) {
    // respect the smallest size to best possible extent
    if(metricType==1 || metricType==3)
      if(!i)
        continue;

    if(h[i]<modSizes[i])
      h[i] = modSizes[i];
  }

  // just for safety for situations that may arise due to numerics
  // (order shouldn't really change after alignment)
  double orderedDir[3][3], orderedH[3];
  double minH = 100*h[2], maxH = 0.;
  // min., mid. and max.
  int index[3];
  for(int i=0; i<3; i++) {
    if(minH>h[i]) {
      minH = h[i];
      index[0] = i;
    }
    if(h[i]>maxH) {
      maxH = h[i];
      index[2] = i;
    }
  }

  if(metricType==4) {
    if(index[0]==index[2])
      index[2] = (index[0]+1)%3;
  }

  for(int i=0; i<3; i++) {
    if(i==index[0] || i==index[2])
      continue;
    index[1] = i;
  }

  for(int i=0; i<3; i++) {
    orderedH[i] = h[index[i]];
    for(int j=0; j<3; j++)
      orderedDir[i][j] = dir[index[i]][j];
  }

  pSNew = new MeshSize(orderedDir,orderedH);
  return pSNew;
}


void PWLsfield::center(pEdge edge,dArray newxyz,pMSize *newS)
{
  double exyz[2][3];
  pMSize pS[2];
  pVertex vt;

  for( int i=0; i<2; i++ ) {
    vt=E_vertex(edge,i);
    pS[i]=getSize(vt);
    V_coord(vt,exyz[i]);
  }

  center(exyz,pS,newxyz,newS);
  return;
}

double PWLsfield::center(pVertex v0,pVertex v1,dArray newxyz,pMSize *newS)
{
  double exyz[2][3];
  pMSize pS[2];

  pS[0]=getSize(v0);
  V_coord(v0,exyz[0]);
  pS[1]=getSize(v1);
  V_coord(v1,exyz[1]);

  return center(exyz,pS,newxyz,newS);
}


double PWLsfield::center(dArray xyz[2],pMSize pS[2],
			    dArray newxyz,pMSize *newS)
{
  double vec[3], d[2], r;

  // computer the ratio to split the edge at its center with respect
  // to the size field by assuming LINEAR INTERPOLATION
  diffVt(xyz[0],xyz[1],vec);
  d[0]=pS[0]->dirLengthSq(vec);
  d[1]=pS[1]->dirLengthSq(vec);
  r=1./(1.+pow(d[1]/d[0],0.25));
  // r=0.5;

  // calculate the new point
  newxyz[0]=r*xyz[1][0]+(1-r)*xyz[0][0];
  newxyz[1]=r*xyz[1][1]+(1-r)*xyz[0][1];
  newxyz[2]=r*xyz[1][2]+(1-r)*xyz[0][2]; 

  interpolate(pS[0],pS[1],r,newS);
  return r;
}

#ifdef MATCHING
void PWLsfield::center(pVertex v0,pVertex v1, double r, dArray newxyz,pMSize *newS)
{
  double xyz[2][3];
  pMSize pS[2];

  pS[0]=getSize(v0);
  V_coord(v0,xyz[0]);
  pS[1]=getSize(v1);
  V_coord(v1,xyz[1]);

   // calculate the new point
  newxyz[0]=r*xyz[1][0]+(1-r)*xyz[0][0];
  newxyz[1]=r*xyz[1][1]+(1-r)*xyz[0][1];
  newxyz[2]=r*xyz[1][2]+(1-r)*xyz[0][2];

  interpolate(pS[0],pS[1],r,newS);
}
#endif 

pMSize PWLsfield::getSize(pVertex v)
{
  void *tmp;
  if( EN_getDataPtr((pEntity)v,pMSizeFieldId,&tmp) )
    return (pMSize)tmp;
  return 0;
}

/*
  interpolate the mesh size at the given location
  this function should be redesigned in the correct way 
  currently, if given two vertices of an edge, it returns
  the actual mesh size at the location, otherwise simply
  return the mesh size at the center of the given:
   - three vertices of a face
   - four vertices of a tet
*/

pMSize PWLsfield::getSize(dArray loc, pPList vts)
{
  dArray exyz[2];
  pMSize pS[2], pMSxyz;
  pVertex vv;
  int i;
  void *iter=0;

  switch( PList_size(vts) ) {
  case 2: {
    i=0;
    while( vv=(pVertex)PList_next(vts,&iter) ) {
      V_coord(vv,exyz[i]);
      pS[i++]=getSize(vv);
    }
    double t=adaptUtil::ParOnLinearEdge(exyz,loc);
    if( t<0 || t>1 ) {
      //      printf("Info: t=%f (PWLsfield::getSize())\n",t);
      t=0.5;
    }
    interpolate(pS[0],pS[1],t,&pMSxyz);
    return pMSxyz; //note we allocate memory for pMSxyz
  }

  case 3: {
    printf("Error: Not Implemented 1 (PWLsfield::getSize())\n");
    break;
  }

  case 4: {
    double dxyz[2][3];
    pMSize dpS[2];
    
    // interpolate the two opposite edges
    for( i=0; i<2; i++ ) 
      {
	vv=(pVertex)PList_next(vts,&iter);
	V_coord(vv,exyz[0]);
	pS[0]=getSize(vv);
	vv=(pVertex)PList_next(vts,&iter);
	V_coord(vv,exyz[1]);
	pS[1]=getSize(vv);
	center(exyz,pS,dxyz[i],&dpS[i]);
      }
    
    // interpolate the diagonal edge
    dArray tmp;
    center(dxyz,dpS,tmp,&pMSxyz);
    delete dpS[0];
    delete dpS[1];
    return pMSxyz;
  }

  default:
    printf("Error: Not implemented 2 (PWLsfield::getSize())\n");
  }

  return 0;
}


// This works for tets only
pMSize PWLsfield::getSize(pVertex vtx, dArray loc, dArray norm, pRegion rgn)
{
  double fxyz[3][3], exyz[2][3], fint_xyz[3], eint_xyz[3];

  pFace face = R_vtOpFc(rgn, vtx);

  F_coord(face,fxyz);

  /// Get intersection of the target and face intersecting with normal going through the target within the tet
  int infinite;
  M_intersectRay3XYZ(loc, norm, fxyz, fint_xyz, &infinite);

  if(infinite)
  {
    printf ("PWLsfield: Can't intersect with the region's face\n");
    exit(0);
  }

  pVertex pVertexVtx = F_vertex(face , 0);
  pEdge edge;
  for (int iEdge = 0; iEdge < 3; ++iEdge)
  {
    edge = F_edge(face, iEdge);
    if (!E_inClosure(edge, pVertexVtx))
      break;
  }

  double edir[3], vcoord[3];
  V_coord(pVertexVtx, vcoord);
  diffVt(fint_xyz, vcoord, edir);

  V_coord(E_vertex(edge,0), exyz[0]);
  V_coord(E_vertex(edge,1), exyz[1]);
  
  /// Intersect vertex on the face obtained with previous intersection with one of the edges of that face
  M_intersectRay2XYZ(fint_xyz, edir, exyz, eint_xyz, &infinite);
  if(infinite)
  {
    printf ("PWLsfield: Can't intersect with the face's edge\n");
    exit(0);
  }

  /// Interpolate the size of the vertex intersecting the edge
  pMSize pSEdge = getSize(eint_xyz, edge);

  /// Interpolate the size of the vertex intersected with face
  pMSize pSVtx = getSize(pVertexVtx);
  exyz[0][0] = vcoord[0]; exyz[0][1] = vcoord[1]; exyz[0][2] = vcoord[2];
  exyz[1][0] = eint_xyz[0]; exyz[1][1] = eint_xyz[1]; exyz[1][2] = eint_xyz[2];
  double t = adaptUtil::ParOnLinearEdge(exyz, fint_xyz);
  if( t<0 || t>1 )
    t=0.5;
  pMSize pSFace;
  interpolate(pSEdge, pSVtx, t, &pSFace);
  delete pSEdge;

  /// Interpolate the target vertex size
  pSVtx = getSize(vtx);
  V_coord(vtx, vcoord);
  exyz[0][0] = vcoord[0]; exyz[0][1] = vcoord[1]; exyz[0][2] = vcoord[2];
  exyz[1][0] = fint_xyz[0]; exyz[1][1] = fint_xyz[1]; exyz[1][2] = fint_xyz[2];  
  t = adaptUtil::ParOnLinearEdge(exyz, loc);
  if( t<0 || t>1 )
    t=0.5;
  pMSize pSTet;
  interpolate(pSFace, pSVtx, t, &pSTet);
  delete pSFace;

  return pSTet;
}


pMSize PWLsfield::getSize(dArray loc, pEntity ent)
{
  pPList vts;
  pMSize pS;
  switch( EN_type(ent) ) {
  case Tedge: {
    vts=PList_new();
    PList_append(vts,E_vertex((pEdge)ent,0));
    PList_append(vts,E_vertex((pEdge)ent,1));
    pS=getSize(loc,vts);
    PList_delete(vts);
    return pS;
  }
  case Tregion: {
    vts=R_vertices((pRegion)ent,1);
    pS=getSize(loc,vts);
    PList_delete(vts);
    return pS;
  }
  default:
    printf("Error: Not Implemented 3 (PWLsfield::getSize())\n");
  }
  return 0;
}

/*
  interpolate two tensors in terms of r (0<r<1)
  return mt0  when r=0
         mt1  when r=1
*/
void PWLsfield::interpolate(pMSize mt0,pMSize mt1,double r,
			    pMSize *newt) 
{
  int i,j;
  double e[3][3], h[3];
  double *vec0, *vec1, mag;
  double mtol = M_getTolerance();
  
  double r0=mt0->aspectRatio(dim);
  double r1=mt1->aspectRatio(dim);

  double r0_2, r1_2;
  if(dim==3) {
    r0_2=mt0->aspectRatio(dim-1);
    r1_2=mt1->aspectRatio(dim-1);
  }

  double AR = 1.5;

  if( r0<AR || r1<AR ) {
    // two or one isotropic case
    for( i=0; i<3; i++ ) {
      if( r0 < r1 )
        { vec0=mt1->eigenvector(i); }
      else
        { vec0=mt0->eigenvector(i); }
      for ( j=0 ; j<3; j++ )
         e[i][j]=vec0[j];
    }
  }
  else if(dim==3 && (r0_2<AR || r1_2<AR) ) {

    for(i=0; i<3; i++) {
      if( r0_2 < r1_2 )
        { vec0=mt1->eigenvector(i); }
      else
        { vec0=mt0->eigenvector(i); }
      for( j=0; j<3; j++ )
        e[i][j]=vec0[j];
    }
  }
  else {
//       k = spheroidType(mt0,mt1);
//       if( k==0 ) {
       // no spheroid
       // interpolate the first two directions
    for( i=0; i<2; i++ )
      {
        vec0=mt0->eigenvector(i);
        vec1=mt1->eigenvector(i);
        if(i==0 && fabs(dotProd(vec0,vec1))<mtol) {
          for( j=0; j<3; j++)
            e[0][j]=(vec0[j]+vec1[j])/2;
          if(dim==3) {
            if(r0_2 < r1_2)
              { vec0=mt1->eigenvector(1); }
            else
              { vec0=mt0->eigenvector(1); }
          }
          else {
            if( r0 < r1 )
              { vec0=mt1->eigenvector(1); }
            else
              { vec0=mt0->eigenvector(1); }
          }

          for( j=0; j<3; j++ )
            e[1][j]=vec0[j];

          break;
        }
        else if( dotProd(vec0,vec1)>0.0 ) {
          for ( j=0 ; j<3; j++ )
            e[i][j]=r*vec1[j]+(1.-r)*vec0[j];
        }
        else {
          for ( j=0 ; j<3; j++ )
            e[i][j]=r*vec1[j]-(1.-r)*vec0[j];
        }
      }
    normVt(e[0],e[0]);

    // project the second direction
    mag=dotProd(e[0],e[1]);
    for( i=0; i<3; i++ )
      e[1][i]=e[1][i]-mag*e[0][i];
    normVt(e[1],e[1]);

    // compute the third direction
    crossProd(e[0],e[1],e[2]);
//       }  //end of if (k==0)

//       if( k>0 && k<5 ) {
//         // one spheroid case
//         printf("Not Implemented yet");
//       }

//       if( k==5 || k==8 ) {
//         // two spheroids and two matched directions
//         printf("Not Implemented yet");
//       }

//       if( k==6 || k==7 ) {
//         // two spheroids with two not matched directions
//         printf("Not Implemented yet");
//       }
  } // end of else

  // interpolate the sizes
  for( i=0; i<3; i++ )
    h[i]=r*(mt1->size(i)) + (1.-r)*(mt0->size(i));

  *newt=new MeshSize(e,h);
  return;
}

/*
    rteurn 0: no spheroid
           otherwise:  mt0          mt1
           1         dir[0]        ellipsoid
	   2         dir[2]        ellipsoid
	   3         ellipsoid     dir[0]
	   4         ellipsoid     dir[2]
	   5         dir[0]        dir[0]
	   6         dir[0]        dir[2]
	   7         dir[2]        dir[0]
	   8         dir[2]        dir[2]
*/
int PWLsfield::spheroidType(pMSize mt0,pMSize mt1) 
{
  if( dim==2 ) 
     return 0;
     
  int type[3][3] = { {0,3,4}, {1,5,6}, {2,7,8} };   
     
  int k0=0, k1=0;
  if( mt0->aspectRatio2(0) <1.1 ) 
     k0=1;
  if( mt0->aspectRatio2(1) <1.1 )
     k0=2;    
  if( mt1->aspectRatio2(0) <1.1 ) 
     k1=1;
  if( mt1->aspectRatio2(1) <1.1 )
     k1=2; 
     
  return type[k0][k1];   
}


/*
  smooth the mesh size field to enforce the length ratio with respect to 
  the metric field of two neighboring edges is less than "beta"
*/
#ifndef MA_PARALLEL 
void PWLsfield::isoSmooth(double beta)
{
  pEdge edge;
  pVertex v0,v1;

  std::deque<pEdge> isoQueue;
  pMeshDataId InQueue=MD_newMeshDataId("FlagOfIfInDeQue");
 
  EIter eit=M_edgeIter(backMesh);
  while( (edge=EIter_next(eit)) ) {
    v0=E_vertex(edge,0);
    v1=E_vertex(edge,1);
    E_isoSmooth(v0,v1,beta,isoQueue,InQueue);
  }
  EIter_delete(eit);

  while( !isoQueue.empty() ) {
    edge = isoQueue.front();
    isoQueue.pop_front();
    EN_deleteData((pEntity)edge,InQueue);
    v0=E_vertex(edge,0);
    v1=E_vertex(edge,1);
    E_isoSmooth(v0,v1,beta,isoQueue,InQueue);
  }

  MD_deleteMeshDataId(InQueue);
  return;
}
#endif



void PWLsfield::anisoSmooth(double beta[3])
{
  pEdge edge;

  std::deque<pEdge> deQueue;
  pMeshDataId isInQueue=MD_newMeshDataId("FlagOfInDeQue");

#ifndef MA_PARALLEL
  EIter eit=M_edgeIter(backMesh);
  while( (edge=EIter_next(eit)) ) 
    procAnEdge(edge,deQueue,isInQueue, beta);
  EIter_delete(eit);

  while( !deQueue.empty() ) {
    edge = deQueue.front();
    deQueue.pop_front();
    EN_deleteData((pEntity)edge,isInQueue);
    procAnEdge(edge,deQueue,isInQueue, beta);
  }

#else  
#ifdef AOMD_ // PAOMD
  int done, total;

  EIter eit=M_edgeIter(backMesh);
  while( (edge=EIter_next(eit)) ) 
    procAnEdge(edge,deQueue,isInQueue, beta);
  EIter_delete(eit);

/// Using genericDataExchanger it is required much more iteration steps for mesh migration to converge somehow...
//  idExchanger_metric deCallback(this, isInQueue, deQueue);
//  genericDataExchanger(verts_to_update.begin(), verts_to_update.end(), deCallback);

  syncMetric(deQueue,isInQueue,verts_to_update);
  verts_to_update.clear();

  do {
    while( !deQueue.empty() ) {
      edge = deQueue.front();
      deQueue.pop_front();
      EN_deleteData((pEntity)edge,isInQueue);
      procAnEdge(edge,deQueue,isInQueue, beta);
    }
//    idExchanger_metric deCallback2(this, isInQueue, deQueue);
//    genericDataExchanger(verts_to_update.begin(), verts_to_update.end(), deCallback2);

    syncMetric(deQueue,isInQueue,verts_to_update);
    verts_to_update.clear();

    done=0;
    if (!deQueue.empty() )
      done=1;
    MPI_Allreduce(&done, &total, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

  } while ( total != 0 );
  
  if (P_size()>1) M_unifySizeField(backMesh, this);
#endif // PAOMD
#endif

  MD_deleteMeshDataId(isInQueue);
  return;
}


void PWLsfield::procAnEdge(pEdge edge, std::deque<pEdge> &deQueue, 
			   pMeshDataId isInQueue, double beta[3]) 
{
  // we consider the metric as isotropic if aspect ratio > 0.9
  double isoTOL=1.21;

  pVertex E_vts[2];
  pMSize pT[2];
  double aspect[2];
  double h1,h2,xyz[2][3],vec[3],l12, alpha;
  double base_dir[3][3];
  double *dir_v0;
  double *dir_v1;
  int i, j;
  double tol=M_getTolerance();
  double maxBeta=MAX( MAX(beta[0],beta[1]), beta[2] );

  for( i=0; i<2; i++ )  {
    E_vts[i]=E_vertex(edge,i); 
    pT[i]=getSize(E_vts[i]);
    aspect[i]=pT[i]->aspectRatio(dim);
  }
  
  if( aspect[0]<isoTOL && aspect[1]<isoTOL ) {
    // isotropic case
    E_isoSmooth(E_vts[0],E_vts[1],maxBeta,deQueue,isInQueue);
    return;
  }
  
  // anisotropic case
  
  // computer length in transformed space wrt geometric progression
  V_coord(E_vts[0],xyz[0]);
  V_coord(E_vts[1],xyz[1]);
  diffVt(xyz[0],xyz[1],vec);
  h1=sqrt(pT[0]->dirLengthSq(vec));
  h2=sqrt(pT[1]->dirLengthSq(vec));
  if( MIN(h2,h1)/MAX(h2,h1) > 0.95 )
    l12=2.*sqrt(dotProd(vec,vec))/(h2+h1);
  else
    l12=sqrt(dotProd(vec,vec))*(h2-h1)/(h1*h2*log(h2/h1));
  
  // always make "v0" be the vertex of larger aspect ratio
  if( aspect[0] < aspect[1] )
    {
      E_vts[0]=E_vertex(edge,1);
      E_vts[1]=E_vertex(edge,0);
      pT[0]=getSize(E_vts[0]);
      pT[1]=getSize(E_vts[1]);
      alpha = (aspect[0]-1)*aspect[1] / ((aspect[1]-1)*aspect[0]);
    }
  else
    alpha = (aspect[1]-1)*aspect[0] / ((aspect[0]-1)*aspect[1]);
  
  
  // the principle directions at "E_vts[0]" will be respected
  for( i=0; i<3; i++ ) {
    dir_v0=pT[0]->eigenvector(i);
    for( j=0; j<3; j++ ) 
      base_dir[i][j]=dir_v0[j];
  }
  if( E_anisoSmooth(E_vts[0],E_vts[1],base_dir,l12, beta) )
     updateQueue(deQueue,isInQueue,E_vts[0]);
  
  pT[0]=getSize(E_vts[0]);
    
  // now we compute the principle directions at "E_vts[1]" by interpolation
  for( i=0; i<3; i++ ) 
    {
      dir_v0=pT[0]->eigenvector(i);
      dir_v1=pT[1]->eigenvector(i);
      if( dotProd(dir_v0,dir_v1) < 0 )
	{ dir_v1[0]=-1.*dir_v1[0]; 
	dir_v1[1]=-1.*dir_v1[1]; 
	dir_v1[2]=-1.*dir_v1[2]; }
      for( j=0; j<3; j++ ) 
	base_dir[i][j]=alpha*dir_v1[j]+(1-alpha)*dir_v0[j];
    }
  if( E_anisoSmooth(E_vts[1],E_vts[0],base_dir,l12,beta) )
    updateQueue(deQueue,isInQueue,E_vts[1]);
    
  return;
}


// update the matrix attached to "v0" if required
int PWLsfield::E_anisoSmooth(
   pVertex v0,        // the attached matrix of "v0" will be smoothed 
   pVertex v1,        // a vertex connected to "v0" 
   double dirs[3][3], // new principle directions of the matrix attached to "v0 
   double l12,        // length in transformed space between "v0" and "v1" 
   double beta[3])
{
  pMSize pT0, pT1;
  double h0, h1, newh[3], logc12, etaSq;
  int i;
  int flag=0; 

  pT0=getSize(v0);
  pT1=getSize(v1);

  for( i=0; i<3; i++ ) 
    {
      h0=pT0->dirLengthSq(dirs[i]);
      h1=pT1->dirLengthSq(dirs[i]);
      newh[i]=h0;

      if( h0<1.21*h1 ) 
	continue;

      // we may reduce the size associated with "v0" in i-th direction
      logc12=0.5*log(h0/h1)/l12;
      if( logc12>log(1.05*beta[i]) ) {
	etaSq = pow(beta[i],2.*l12) * h1/h0;
	newh[i] *= etaSq;
	flag=1;
      }
    }

  // update mesh size pT0
  if( flag )
    {
      if( newh[0]<1.e-20 || newh[1]<1.e-20 || newh[2]<1.e-20 )
	printf("Error: Zero desired length (PWLsfield::E_anisoSmooth)\n");
      else
	{
	  for( i=0; i<3; i++ ) 
	    newh[i]=sqrt(newh[i]);
	  setSize((pEntity)v0,dirs,newh);
#ifdef MA_PARALLEL
//	  sendVertex(v0,dirs,newh);

          if(EN_onCB((pEntity)v0))
          {
            verts_to_update.push_back((pEntity)v0);
          }

#endif
	}
    }

  return flag;
}

// update the matrix attached to "v0" or "v1" 
int PWLsfield::E_isoSmooth(pVertex v0, pVertex v1, double beta,
			   std::deque<pEdge> &deQueue,pMeshDataId isInQueue)
{
  double xyz[2][3];
  double vec[3];
  pMSize pT[2];
  double h0, h1, tmp, logc12, l12;

  V_coord(v0,xyz[0]);
  V_coord(v1,xyz[1]);
  diffVt(xyz[0],xyz[1],vec);
  pT[0]=getSize(v0);
  pT[1]=getSize(v1);
  h0=pT[0]->dirLengthSq(vec);
  h1=pT[1]->dirLengthSq(vec);

  // always make h0 <= h1
  if( h0>h1 ) {
    tmp=h0;
    h0=h1;
    h1=tmp;
    v1=v0;
  }
  if( h0/h1>0.81 ) 
    return 0;
  h0=sqrt(h0);
  h1=sqrt(h1);

  //  l12=sqrt(dotProd(vec,vec))*(h1-h0)/(h0*h1*log(h1/h0));
  // for a piece-wise linear size field
  l12 =sqrt(dotProd(vec,vec))*(log(h1/h0)/(h1-h0));
  logc12=log(h0/h1)/l12;
  int flag=0;
  if(-logc12>log(1.05*beta) ) {
    // reduce the larger mesh size  by a factor
    flag=1;
    tmp=pow(beta,l12) * h0/h1;
    pMSize pmt_h1=getSize(v1);
    pmt_h1->scale(tmp);
    updateQueue(deQueue,isInQueue,v1);
#ifdef MA_PARALLEL
//    sendVertex(v1,pmt_h1);

    if(EN_onCB((pEntity)v1))
    {
      verts_to_update.push_back((pEntity)v1);
    }

#endif
  }

  return flag;
}


void PWLsfield::updateQueue(std::deque<pEdge> &deQueue,
			    pMeshDataId isInQueue,pVertex vert)
{
  pEdge edge;
  int value;
  
  for( int i=0; i<V_numEdges(vert); i++ ) {
    edge=V_edge(vert,i);
    if( ! EN_getDataInt((pEntity)edge,isInQueue,&value) ) {
      EN_attachDataInt((pEntity)edge,isInQueue,1);
      deQueue.push_back(edge);
    } 
  }
  
  return;
}


#ifdef MA_PARALLEL

/*
  return 1 if the local metric is reduced
         0 the metric is not modified
*/
int PWLsfield::intersect(pVertex vt, double rmtDir[3][3], double rmtH[3])
{
  double locDir[3][3];
  double locH[3];
  double* e;
  double tmpSizeSq;
  int i,j;

  pMSize locM = getSize(vt);
  pMSize rmtM=new MeshSize(rmtDir,rmtH);

  for( i=0; i<3; i++ ) {
    locH[i]=locM->size(i);
    e=locM->eigenvector(i);
    for( j=0; j<3; j++ )
      locDir[i][j]=e[j];
  }

  int reduced=0;

  // assumed that sizes are sorted with the first the minimum
  if( locH[0] < rmtH[0] ) {
    // use the direction of local metric
    for( i=1; i<3; i++ ) {
      tmpSizeSq = rmtM->dirLengthSq(locDir[i]);
      if( tmpSizeSq < locH[i]*locH[i] ) {
        locH[i] = sqrt(tmpSizeSq);
        reduced=1;
      }
    }
  }
  else {
    // use the direction of remote metric
    reduced=2;
    for( i=1; i<3; i++ ) {
      tmpSizeSq = locM->dirLengthSq(rmtDir[i]);
      if( tmpSizeSq < rmtH[i]*rmtH[i] )
        rmtH[i] = sqrt(tmpSizeSq);
    }
  }

  switch( reduced ) {
  // Note this results in ambiguity and inconsistency
  case 1:  setSize((pEntity)vt,locDir,locH); break;
  case 2:  setSize((pEntity)vt,rmtDir,rmtH); break;
  }

  delete rmtM;
  return reduced;
}

void PWLsfield::syncMetric(std::deque<pEdge> &deQueue, pMeshDataId isInQueue, list<pEntity> &list)
{
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(smoothPack));
  smoothPack* msg_send = (smoothPack*)CM->alloc_msg(sizeof(smoothPack));

  int num_sent = 0, num_recvd = 0;

  lit = list.begin();
  mEntity* ent;
  for(; lit!=list.end();lit++)
  {
    ent=*lit;
    for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
    {
      pMSize metric = getSize((pVertex)ent);
      double *eig;

      smoothPack *castbuf = (smoothPack*)msg_send;
      castbuf->vertex = (pVertex)rciter->second;
      for(int i=0; i<3; i++)
      {
        castbuf->h[i] = metric->size(i);
        eig = metric->eigenvector(i);
        for(int j=0; j<3; j++)
        {
          castbuf->e[i][j] = eig[j];
        }
      }
      CM->send(rciter->first, (void*)msg_send);
      num_sent++;
    } // for RCItet
  }  // for list 
  CM->finalize_send();
  CM->free_msg(msg_send);

  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    smoothPack *castbuf = (smoothPack*)msg_recv;
    if(intersect(castbuf->vertex, castbuf->e, castbuf->h))
    {
      updateQueue(deQueue, isInQueue, castbuf->vertex);
    }
    CM->free_msg(msg_recv);
  }
}

/*
int idExchanger_metric::msg_size ()
{
  return sizeof(smoothPack);
}

void idExchanger_metric::fill_buffer (mEntity *e, mEntity *remoteEnt, void *&msg_send)
{
  pMSize metric = pwField->getSize((pVertex)e);
  double *eig;

  smoothPack *castbuf = (smoothPack*)msg_send;
  castbuf->vertex = (pVertex)remoteEnt;
  for(int i=0; i<3; i++)
  {
    castbuf->h[i] = metric->size(i);
    eig = metric->eigenvector(i);
    for(int j=0; j<3; j++)
    {
      castbuf->e[i][j] = eig[j];
    }
  }
}

void idExchanger_metric::receiveData (void *msg_recv, int pid_from)
{
  smoothPack *castbuf = (smoothPack*)msg_recv;
  if(pwField->intersect(castbuf->vertex, castbuf->e, castbuf->h))
  {
    pwField->updateQueue(deQueue, id, castbuf->vertex);
  }
}
*/

#endif // MA_PARALLEL
