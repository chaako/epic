#ifndef _H_TEMPLATEREFINE
#define _H_TEMPLATEREFINE

#include "MeshTools.h"
#include "sizeFieldBase.h"
#include <list>
#include <vector>
#include <deque>

using namespace std;

class meshTemplate {

 public:
  // register the tags and initialize the mesh and member data
  meshTemplate(pMesh, pSField);  
  meshTemplate(pMesh, pSField, int, std::vector< std::pair<pVertex,double *> > *);
  ~meshTemplate();

  /* tag mesh edge for refinement
      0: if tagged, remove the tag
      1: bisect the edge  */
  int setRefineLevel(pEdge , int);
  int getRefineLevel(pEdge);

  /** \brief Tag the wall of edges in the stack of a boundary layer (BL).
   *
   *  Given an edge, the function tags it for refinement. It also tags
   *  all the edges along with the provided one on the same wall of the BL.
   *  This function does NOT check if the edge is a part of a BL.
   *  It assumes that the edge belongs to some BL.
   *
   *  \param  edge          (In)  Edge to be refined
   *  \return                     Number of tagged edges in the BL
   */
  int tagBLEdges(pEdge edge);

  /// Same as above but for untagging
  int untagBLEdges(pEdge edge);


  pMeshDataId getRefineTag(void) {return int_reff;}
  list<pEdge> *getRefBLEdgesList(void) {return pRefBLEdges;}
  list<pEdge> *getRefEdgesList(void) {return pRefEdges;}

  /* set the callback function to be activated when new
     elements are created while the old not removed */ 
  void setCallback( CBFunction CB, void * userData );

  /* Do the job */
  void run();

  /* Do the refinement in BL */
  void runBL();
  /* refine a BL mesh region and return mesh entities created */
  int R_refineBL(pRegion rewgion, pPList newRgns, pPList newEdges, int bit);

  /// Trim initial pyramids connected to each other with the quad face. Works in serial only
  void Mesh_TetrahedralizePyramids(void);

  /// Tetrahedronize BLs due to the wrong aspect ratio, which is provided as a square of the actual aspect ratio
  void Mesh_TetrahedronizeBLs_AspectRatio(double dBLAspectRatioLimit);

  /// Tetrahedralize the whole mesh
  void tetrahedronizeBL();

  /// Adapive trimming
  void Mesh_AdaptiveDecompBL(double dBLAspectRatioLimit=0.);

  void TagVerts(std::deque<pFace> &ListSplitQuadFace, std::deque<pVertex> &ListPrimaryVtx, std::deque<pVertex> &ListSecondaryVtx);
  void ResolveConflictingFaces(std::deque<pFace> &ListSplitQuadFace);
  void TagAdditionalFaces(std::deque<pFace> &ListSplitQuadFace, std::deque<pVertex> &ListPrimaryVtx);
  void TagFacesOnHangingPrisms(std::deque<pFace> &ListSplitQuadFace);
  void Mesh_AdaptiveTrimming_AspectRatio(double dBLAspectRatioLimit);

  /* the following functions refine a mesh entity regardless of its neighboring */

  /* refine a mesh region and return mesh entities created */
  int R_refine(pRegion r,pPList newRgns,pPList newEdges);
  /* refine a mesh face */
  int F_refine(pFace f);
  /* refine a mesh edge */
  int E_refine(pEdge e);

  /* make public for DSplitClpsMod */
  void faces_vert_create_regions(pMesh,pVertex,int,pFace *,int *,pGEntity *,pPList,pPList);
  pPList getAttachPList(pEntity);
  void delete_region(pRegion,int);
 
  /* tell templates to maintain classification between the parent mesh and its children */
  void setClassification();
  /* refine a mesh region N times */
  void R_refineN(pRegion r,int N,pPList *newRgns);
  /* get the classified parent mesh entity */
  pEntity EN_whatIn(pEntity ent);
  /* delete mesh regions and their downward mesh entities if topologically valid */
  void delete_Children(pPList l);

  void setCurved2DSurface(int iCF) { curved2DSurface = iCF; }

#ifdef CURVE
  // set refinement of curved (quadratic) tetrahedron mesh
  void setCurvList(pPList l) { curlist=l; }
  pPList  curlist;  
#endif


 protected:

  pMesh pmesh;
  pSField pSizeField; 
  int nullFieldFlag;

  /// Variable responsible for the surface of the curvature. If it's 2D mesh with flat surface (curved2DSurface == 0) 
  /// then new entities clasified on it will not request model boundary curvature functions
  int curved2DSurface;

#ifdef DEBUG
std::map<int,int> iNumPyrTemplate, iNumPyr, iNumNegPyr, iNumNegTet;
#endif 

  pMeshDataId int_reff; // tag to indicate mesh entities to be refined
  pMeshDataId ptr_reff; // tag to attach a list of child mesh entities to classified parent
  pMeshDataId split_id; // tag to deal with splitting quad faces into tri-s
  pMeshDataId ChildToParent; // tag indicating the classified parent of a child
  list<pEdge > *pRefEdges; // only containing those edges to be refined
  list<pEdge > *pRefBLEdges; // same about BL edges
  list<pEdge > *pRefNonBLEdges; // only containing interior edges to be refined during tag-driven adaptivity on mesh with boundary layer elements

  /// list of faces adjacent to BL edges but not part of BL, i.e. part of an interface region, adjacent to BL locally or remotely
  std::deque<pFace> refInterfaceFaces;
  /// list of interface regions to be refined
  std::deque<pRegion> refInterfaceRegions;

  /* indicator on how to process new boundary vertices
      0: No model or have model but you do not want to snap
      1: Mesh model (always collect snap info)
      2: solid model (always collect snap snap) */
  int  model_type; 
  vector< std::pair<pVertex,double *> > *pSnap;

  pPList steinerVerts; // verticies inserted in subtemplate_3_3_a and suntemplate_4_2_b
  pPList ambigEdges;   // ambiguous edges 

  CBFunction function_CB;     // the callback function
  void *userData_CB;          // the data set by the user and to be passed
  void callCallback(pEntity old, pPList newElements, pVertex);

  /// entities which have to be updated on part boundary after refinement is done
  list<pEntity> entities_to_update; 

  /* routines to delete mesh entities  */
  void delete_face(pFace,int);
  void delete_edge(pEdge,int);
  void delete_vertex(pVertex);

  /* compute centroid and interoplate mesh size there */
//  pMSize tetCenter(pVertex[4], double[3]);
//  pMSize wedgeCenter(pVertex[6], double[3]);

  /* process steiner points and ambiguities */
  void deleteSteiner();

  /* 3D refinement templates */
  void template_1(pRegion,pPList,int,pPList,pPList);    // one edge is marked
  void template_2_1(pRegion,pPList,int,pPList,pPList);  // 2 edges of a face are marked
  void template_2_2(pRegion,pPList,int,pPList,pPList);  // 2 opposite edges are marked
  void template_3_1(pRegion,pPList,int,pPList,pPList);  // 3 edges with with 2 on 2 faces are marked. Case 1
  void template_3_2(pRegion,pPList,int,pPList,pPList);  // 3 edges with with 2 on 2 faces are marked. Case 2
  void template_3_3(pRegion,pPList,int,pPList,pPList);  // 3 edges convergent to a vertex are marked
  void template_3_4(pRegion,pPList,int,pPList,pPList);  // 3 edges of a face are marked
  void template_4_1(pRegion,pPList,int,pPList,pPList);  // 4 marked edges with three on a face
  void template_4_2(pRegion,pPList,int,pPList,pPList);  // 4 marked edges with two on each face
  void template_5(pRegion,pPList,int,pPList,pPList);    // 5 edges are marked
  void template_63(pRegion,pPList,int,pPList,pPList);   // all the edges are marked

  /* 3D refinemnet sub-templates */
  void sub_template_1(pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,pPList,pPList);        // Only edge 0 is marked
  void sub_template_2_1(pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,pPList,pPList);      // edge 1 & 2 are marked
  void sub_template_2_2(pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,pPList,pPList);      // edge 0 & 5 are marked
  void sub_template_3_1(pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,int,pPList,pPList);  // edge 0 2,4 are marked
  void sub_template_3_2(pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,int,pPList,pPList);  // edge 0 1,3 are marked
  pVertex sub_template_3_3_a(pFace[4],int[4],pVertex[4],pGEntity,int,pPList,pPList);      // edge 0,2,3 are marked
  void sub_template_3_3_b(pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,int,pPList,pPList);// edge 0,2,3 are marked
  void sub_template_3_4(pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,pPList,pPList);      // edge 0,1,&2 are marked
  void sub_template_4_1(pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,int,pPList,pPList);  // edge 0,1,2,3 are marked
  void sub_template_4_2_a(pEdge[6],pFace[4],pVertex[4],pGEntity,int,pPList,pPList);       // edge 1,2,3,4 are marked
  pVertex sub_template_4_2_b(pFace[4],int[4],pVertex[4],pGEntity,pPList,pPList);          // edge 1,2,3,4 are marked
  void sub_template_5(pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,int,pPList,pPList);    // edge 1,2,3,4,5 are marked
  void sub_template_6(pRegion,pEdge[6],pFace[4],int[4],pVertex[4],pGEntity,pPList,pPList); // all 6 edges are marked
  pRegion face_vert_create_region(pMesh,pVertex,pFace,int, pGEntity, pPList);
  pFace get_face_by_edge_vert(pMesh,pEdge,pVertex,pGEntity,pPList);
  pEdge get_edge_by_verts(pMesh,pVertex,pVertex,pGEntity,pPList);

  /* 2D refinement templates  */
  pPList get_split_faces_1(pFace);
  pPList get_split_faces_2(pFace);
  pPList get_split_faces_3(pFace);
  pPList get_bisected_faces(pFace);
  pPList bisect_tri(pFace);
  pPList bisect_quad(pFace);
  pPList get_split_edges(pEdge);
  pPList splitLinearEdge(pEdge);


  /// routines for tetrahedronization
  void delete_face(pFace face);
  int check_is_face_split(pFace face);
  pPList get_tri_faces_of_quad(pFace face, pEdge edge, pVertex vertex);
  int EN_getSplitID(pEntity entity);
  void EN_setSplitID(pEntity entity, int id);
  pVertex F_oppVtxToEdge(pFace face, pEdge edge);
  pVertex F_getFirstVtx(pFace face);
  pEdge F_commonEdge(pFace face1, pFace face2);
  pVertex F_getMaxIDVtx(pFace face);
  pFace R_wedgeOppTriFace(pRegion region, pFace face);

  /// Syncronize vertex ids on the part boundaries dictated by owners
  void SyncVtxIDsByOwner();

  /// Choose minimum ID vertex based on the owner information
  pVertex getMinVtxIdByOwner(pEdge edge);

  void template_prism_1(pRegion region, pPList newRegs, pPList newEdges);
  void template_prism_2(pRegion region, pPList newRegs, pPList newEdges);
  void template_prism_3(pRegion region, pPList newRegs, pPList newEdges);

  void template_transition_tet_1(pRegion region, pPList newRegs, pPList newEdges);
  void template_transition_tet_1_a(pRegion region, pPList newRegs, pPList newEdges);
  void template_transition_tet_1_b(pRegion region, pPList newRgns, pPList newEdges);
  void template_transition_tet_2(pRegion region, pPList newRegs, pPList newEdges);
  void template_transition_tet_2_a(pRegion region, pPList newRegs, pPList newEdges);
  void template_transition_tet_2_b(pRegion region, pPList newRegs, pPList newEdges);
  void template_transition_tet_3(pRegion region, pPList newRegs, pPList newEdges);

  void template_pyramid_1(pRegion region, pPList newRegs, pPList newEdges);
  void template_pyramid_1_a(pRegion region, pPList newRegs, pPList newEdges);
  void template_pyramid_1_b(pRegion region, pPList newRegs, pPList newEdges);
  void template_pyramid_2(pRegion region, pPList newRegs, pPList newEdges);
  void template_pyramid_2_a(pRegion region, pPList newRegs, pPList newEdges);
  void template_pyramid_2_b(pRegion region, pPList newRegs, pPList newEdges);
  void template_pyramid_3(pRegion region, pPList newRegs, pPList newEdges);

  void template_reg_prism_1(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_prism_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_prism_3(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);

  void template_reg_pyramid_1(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);

  /// Two consecutive edges are marked
  void template_reg_pyramid_2_a(pRegion region, pFace parent_faces[5], pEdge parent_edges[8], pVertex parent_verts[5], pPList newRgns, pPList newEdges);
  /// Two opposite edges are marked
  void template_reg_pyramid_2_b(pRegion region, pFace parent_faces[5], pEdge parent_edges[8], pVertex parent_verts[5], pPList newRgns, pPList newEdges);

  void template_reg_pyramid_3(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_4(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_quad_0(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_quad_1(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_quad_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);

  /// Two consecutive edges are marked
  void template_reg_pyramid_quad_2_a(pRegion region, pFace parent_faces[5], pEdge parent_edges[8], pVertex parent_verts[5], pPList newRgns, pPList newEdges);
  /// Two opposite edges are marked
  void template_reg_pyramid_quad_2_b(pRegion region, pFace parent_faces[5], pEdge parent_edges[8], pVertex parent_verts[5], pPList newRgns, pPList newEdges);

  void template_reg_pyramid_quad_3(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_quad_4(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_tri_bisect(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_tri_bisect_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_quad_tri_bisect(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_quad_tri_bisect_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);
  void template_reg_pyramid_quad_2_tri_bisect(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges);

  void layer_division_template_prism(pRegion region, pPList newRgns, pPList newEdges);

  
  /// Tetrahedronization routines
  int BL_SplitQuadFaces(std::vector<pFace> &VecFaceStack);
  void tetrahedronizeWedges(std::list<pRegion> &wedges, std::list<pRegion> *chdRgns=NULL);
  void tetrahedronizePyramidizeWedges(std::list<pRegion> &wedges, std::list<pRegion> *chdRgns=NULL);
  void tetrahedronizePyramids(std::list<pRegion> &pyramids, std::list<pRegion> *chdRgns=NULL);
  void tetrahedronizeWedge_CommonStartVtx(pRegion region, pRegion *chdRgns);
  void tetrahedronizeWedge_NoCommonStartVtx(pRegion region, pRegion *chdRgns);
  int tetrahedronizeWedge(pRegion region, pRegion *chdRgns);
  int tetrahedronizePyramidizeWedge(pRegion region, pRegion *chdRgns);
  void tetrahedronizePyramidizeWedge_OneQuadFaceSplit(pRegion region, pRegion *chdRgns);
  void tetrahedronizePyramid(pRegion region, pRegion *chdRgns);


/// BL variables and functions
  pMeshDataId diagonalSelectionID;
  pPList get_split_faces_selected_2(pFace face);
  void labelNewBLEntities4LayerOrTransitionEdgeSplit(pEdge edge);
  void selectDiagonalOnStack(vector<pFace>& facesStack);

#ifdef CURVE
  pPList splitQuadraticEdge(pEdge);
#endif


#ifdef AOMD_
#ifdef MA_PARALLEL
  pMeshDataId vtIdTag;  // tag used by PAOMD
  void SetNewCBLinks();
#endif
//  pRegion PassIdRegion; // I hate introducing this
  void M_countSteinerPoints(pMesh pm, std::list<pEdge> *rgns);
  void count_template_3_3a(pRegion region,int id,std::list<pRegion> *rgns);
  void count_template_4_2b(pRegion region,int id,std::list<pRegion> *rgns);
#endif

};

int EN_isTagRef(pEntity ent);

#endif
