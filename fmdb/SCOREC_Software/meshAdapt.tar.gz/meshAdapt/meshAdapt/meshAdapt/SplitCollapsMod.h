#ifndef _H_SPLT_CLPS_Mod
#define _H_SPLT_CLPS_Mod

#include "LocMeshMod.h"

/*
  Compound operator: split+collapse

  Input: (1) a mesh face;
         (2) a mesh edge in the closure of the mesh face,
  Operation:
    First split the edge, then collapse the new edge on the face with
    the retained vertex at the location of the original existed vertex

  10/31/01 created Xiangrong Li
*/

class EsplitClpsMod: public locMeshMod
{
 public:
  EsplitClpsMod(const EsplitClpsMod &);
  EsplitClpsMod(pMesh, pSField, MeanRatio *, evalResults *);
  ~EsplitClpsMod() {}

  /* the common local modification interface */
  virtual int topoCheck();
  virtual int geomCheck();
  virtual int sizeCheck();
  virtual void getAffectedRgns(pPList *);
  virtual int apply();
  virtual int apply(pPList *);
  virtual modType type() { return SPLTCLPS; }

  /* specific member functions for this compound operator */
  void reset(pEdge, pFace);

  void setSnap() { snap=1; }
  pEdge getSplitEdge() { return splitEdge; }
  pFace getFace() { return goneFace; }
  pVertex getVertex() { return vt; }
#ifdef CURVE
  void setVertex(pVertex v) { vt=v; }
#endif
 private:
  pFace goneFace;
  pEdge splitEdge;
  int snap;

  pVertex vt; // initialized at topoCheck(); may be reset at apply()

  int checkDimRection(); 
};


inline EsplitClpsMod::EsplitClpsMod(const EsplitClpsMod &x):
  locMeshMod(x.mesh, x.pSizeField, x.shpMeasure, x.results) 
{
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;    
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;
  CB_move=x.CB_move;
  userData_CB_move=x.userData_CB_move;

  vertMv=x.vertMv;
  target[0]=x.target[0];
  target[1]=x.target[1];
  target[2]=x.target[2];
  
  goneFace=x.goneFace;
  splitEdge=x.splitEdge;
  snap=x.snap;
  vt=x.vt;
#ifdef CURVE
  quadratic=x.quadratic;
#endif /*CURVE*/
}

inline EsplitClpsMod::EsplitClpsMod(pMesh p, pSField mf, MeanRatio *m, 
				    evalResults *r):
  locMeshMod(p,mf,m,r)
{
  splitEdge=0;
  goneFace=0;
  snap=0;
#ifdef CURVE
  quadratic=false;
#endif /*CURVE*/
}

inline void EsplitClpsMod::reset(pEdge e, pFace f)
{
  splitEdge=e;
  goneFace=f;
}
  
#endif
