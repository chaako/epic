#include "DSplitClpsMod.h"
#include "templateRefine.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "MeshSize.h"
#include "MeshAdjTools.h"
#include "fromMeshTools.h"
#include "PList.h"
#include "BLUtil.h"
#include "FMDB_cint.h"
#include <stdio.h>
#include <iostream>
#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif

#ifdef CURVE
#include "curveUtil.h"
#include "curveMesh.h"
using namespace curveUtil;
using namespace adaptUtil;
#endif/*CURVE*/
using std::cout;
using std::endl;

/*
  History: 7/15/01 Created  X-R. Li
*/

void DSplitClpsMod::getSplitPos(double *v) 
{
  *v=xyz[0];
  *(v+1)=xyz[1];
  *(v+2)=xyz[2];
}


int DSplitClpsMod::topoCheck()
{
  // if one of the edges are classified on Gregion, it is enough
  // however, the split position must be selected carefully.
  // in case the new vertex will be snapped, no further considered
  // in case no snapping follows, the position should be on boundary
  if( E_whatInType(edgePair[0])!=Gregion && 
      E_whatInType(edgePair[1])!=Gregion )
    return 0;

  if (!EN_okTo(DELETE,(pEntity)edgePair[0]))
    return 0;
  if (!EN_okTo(DELETE,(pEntity)edgePair[1]))
    return 0;

#ifdef MA_PARALLEL
  if( EN_onCB((pEntity)edgePair[0]) || 
      EN_onCB((pEntity)edgePair[1]) )
    return 0;
#endif

  // check dimension reduction
  pPList faces;
  pRegion otherRgn;
  pFace fc;
  pEdge ed;
  pVertex opVt, vts[2];
  void *iter;
  int i,j,k, numv;
  for( i=0; i<2; i++ ) {
    faces=adaptUtil::R_edAdjFcs(region,edgePair[i]);
    iter=0; numv=0;
    while( fc=(pFace)PList_next(faces,&iter) ) {
      otherRgn=adaptUtil::F_otherRgn(fc,region);
      if( otherRgn )
	vts[numv++]=R_fcOpVt(otherRgn,fc);
    }
    PList_delete(faces);

    ed=edgePair[(i+1)%2];
    for( j=0; j<E_numFaces(ed); j++ ) {
      fc=E_face(ed,j);
      opVt=F_edOpVt(fc,ed);
      for( k=0; k<numv; k++ )
	if( opVt==vts[k] )
	  return 0;
    }
  }

  // deny the non-manifold case temporily
//    pGEntity gent;
//    pPList grgns;
//    for( i=0; i<2; i++ ) {
//      if( E_whatInType(edgePair[i])==Gedge ) {
//        gent=E_whatIn(edgePair[i]);
//        grgns=GE_regions((pGEdge)gent);
//        j=PList_size(grgns);
//        PList_delete(grgns);
//        if( j > 1 ) 
//  	return 0;

//      } else if( E_whatInType(edgePair[i])==Gface ) {
//        gent=E_whatIn(edgePair[i]);
//        grgns=GF_regions((pGFace)gent);
//        j=PList_size(grgns);
//        PList_delete(grgns);
//        if( j > 1 ) 
//  	return 0;
//      }
//    }

  // NOTE: need to add the check that no duplicated edge will be 
  //       created by this operation
  return 1;
}

int DSplitClpsMod::geomCheck()
{  
  pMSize pmt[4];
  pPList eregs;
  pPList rvlist;
  pRegion rgn;
  pVertex vt, vertex, ev;
  void *iter;
  void *temp = 0 ;
  double rg[4][3] ; 
  double shape_1;
  double ori[3];
  int k,i,j;

  // initialize
  double worstShape =BIG_NUMBER;

  // check the pre-vertex motion
  if( vertMv ) {
    V_coord(vertMv,ori);
    adaptUtil::move_vertex(vertMv,target);
    
    pPList vRgns;
    if(EN_isBLEntity((pEntity)vertMv)) {
      if(!V_atBLInterface(vertMv)) {
        cout<<"\nError in DSplitClpsMod::geomCheck()..."<<endl;
        cout<<"vertMv is BL entity but not at BL interface"<<endl;
        exit(0);
      }

      vRgns = PList_new();

      vector<pRegion> Vrgns;
      V_nonBLRegions(vertMv, Vrgns);
      for (int itReg = 0; itReg < Vrgns.size(); ++itReg)
      {
        PList_append(vRgns, Vrgns[itReg]);
      }

      double f_xyz[3][3], v01[3], v02[3], nor[3];;
      pMSize f_pmt[3];
      pFace face;
      vector<pFace> vLyrFaces;
      V_layerFaces(vertMv, vLyrFaces);
      pPList fverts;
      int numFaces = vLyrFaces.size();
      for(int iFace=0; iFace<numFaces; iFace++)
      {
        face = vLyrFaces[iFace];

        fverts = F_vertices(face,1);

        // compute the original normal
        temp = 0; i = 0;
        while (vertex = (pVertex)PList_next(fverts, &temp)) {
          if(vertex==vertMv) {
            f_xyz[i][0]=ori[0]; f_xyz[i][1]=ori[1]; f_xyz[i++][2]=ori[2];
          }
          else
            V_coord(vertex,f_xyz[i++]);
        }
        diffVt(f_xyz[1],f_xyz[0],v01);
        diffVt(f_xyz[2],f_xyz[0],v02);
        crossProd(v01,v02,nor);

        temp = 0; i = 0;
        while (vertex = (pVertex)PList_next(fverts, &temp)) {
          f_pmt[i]=pSizeField->getSize(vertex);
          V_coord(vertex,f_xyz[i++]);
        }
        PList_delete(fverts);

        // check validity and calculate shape
        if(!shpMeasure->XYZ_shape(f_xyz, f_pmt, nor, &shape_1)) {
          PList_delete(vRgns);
          adaptUtil::move_vertex(vertMv,ori);
          return 0;
        }
      }
    }
    else
      vRgns=V_regions(vertMv);

    temp=0;
    while( rgn = (pRegion)PList_next(vRgns,&temp) ) {
      if( rgn==region ) continue;
      if( R_inClosure(rgn,(pEntity)edgePair[0]) ) continue;
      if( R_inClosure(rgn,(pEntity)edgePair[1]) ) continue;
      if( !shpMeasure->R_shape(rgn,&shape_1) ) {
	PList_delete(vRgns);
	adaptUtil::move_vertex(vertMv,ori);
	return 0;
      }
      if( worstShape > shape_1 ) 
	worstShape=shape_1;
    }
  }  

  // interpolate mesh size at point xyz
  pMSize pSxyz=pSizeField->getSize(xyz,(pEntity)region);

  // check the compound operation
#ifdef CURVE
  if(quadratic == false) {
#endif
  for( k=0; k<2; k++ ) {

    eregs=E_regions(edgePair[k]);
    temp=0;
    while ( rgn = (pRegion)PList_next(eregs,&temp) ) 
      {
	// ignore the region to be eliminated
	if( rgn==region ) continue;
	
	rvlist=R_vertices(rgn,1);
	
	// evaluate the two regions created by splitting 'rgn'
	for( i=0; i<2; i++ ) {
	  ev=E_vertex(edgePair[k],i);
	  iter=0; j=0;
	  while( (vt=(pVertex)PList_next(rvlist,&iter)) ) {
	    if( vt==ev )
	      {
		pmt[j]=pSxyz;
		rg[j][0]=xyz[0]; rg[j][1]=xyz[1]; rg[j++][2]=xyz[2];
	      }
	    else 
	      {
		pmt[j]=pSizeField->getSize(vt);
		V_coord(vt,rg[j++]);
	      }
	  }
	  // check validity
	  if( !shpMeasure->XYZ_shape(rg,pmt,&shape_1) ) 
	    {
	      PList_delete (eregs);
	      PList_delete (rvlist);
              if( pSxyz )
                delete pSxyz;
	      if( vertMv ) 
		adaptUtil::move_vertex(vertMv,ori);
	      return 0;
	    }

	  // determine the worst shape
	  if( worstShape > shape_1 )
	    worstShape=shape_1;
	}
	PList_delete(rvlist);
      }
    PList_delete(eregs);
  }

#ifdef CURVE
 }
  else if (quadratic == true) {
    double rg[10][3];
    pVertex v[4], fv;
    int edgeVertPairs[6][2] ={0,1,1,2,2,0,0,3,1,3,2,3};
    double exyz[2][3], param[3];
    bptxyz loc;
    int nume_f, index;
    pFace face;
    crShpInfo csi;
    
    nume_f = E_numFaces(edgePair[0]);
    
    if(nume_f > 8)
      {
	//cout<<"too many faces connected to edgePair[0] ---- DsplitClpsMod"<<endl; 
	return 0;}
    
    // apply curved edge split on edgePair[0]
    E_eval(edgePair[0], 0.25, ptloc[0].xyz, param);
    E_eval(edgePair[0], 0.75, ptloc[1].xyz, param);
    verts_pts[E_vertex(edgePair[0], 0)] = ptloc[0];
    verts_pts[E_vertex(edgePair[0], 1)] = ptloc[1];

    // apply curved face split on edgePair[0]
    for( k=0; k<nume_f; k++ ) {
      face = E_face(edgePair[0], k);
      F_bezierSplit(face, edgePair[0], ptloc[k+2].xyz);
      
      // get the opposite vert of the edge on the face
      fv = F_opEdgeVert(face, edgePair[0]);

      verts_pts[fv] = ptloc[k+2];

    }
    
    
    // check the compound operation
    for( k=0; k<2; k++ ) {
      
      eregs=E_regions(edgePair[k]);
      for (temp=0; (rgn =(pRegion)PList_next(eregs,&temp)); ) {
	// ignore the region to be eliminated
	if( rgn==region ) continue;
	
	rvlist=R_vertices(rgn,1);
	
	// evaluate the two regions created by splitting 'rgn'
	// first get the 4 corner points
	for( i=0; i<2; i++ ) {
	  ev=E_vertex(edgePair[k],i);
	  for (iter=0, j=0; (vt=(pVertex)PList_next(rvlist,&iter)); j++ ) {
	    if(vt==ev) {
	      if(pSxyz)
		pmt[j]=pSxyz;
	      rg[j][0]=xyz[0]; rg[j][1]=xyz[1]; rg[j][2]=xyz[2];
	      v[j] =0;
	    }
	    else {
	      if(pSxyz)
		pmt[j]=pSizeField->getSize(vt);
	      V_coord(vt,rg[j]);
	      v[j] =vt;
	    }
	  }

	  // then get the 6 mid-side nodes
	  for (int ipoint=0; ipoint<6; ipoint++, j++) {
	    pPoint pt;
	    int j0 =edgeVertPairs[ipoint][0];
	    int j1 =edgeVertPairs[ipoint][1];

	    if (v[j0] && v[j1]) {
	      // for the existing edges, use their mid-side nodes
	      pEdge e=E_exists(v[j0], v[j1]);
	      
	      E_bezierCtrlPt(e, rg[j]);

	    }
	    else if (v[j0]) {
	      
	      std::map<pVertex, bptxyz>::iterator iter_vert = verts_pts.find(v[j0]);
	      

	      if(iter_vert == verts_pts.end()) {
	      // temporary for interior
		rg[j][0] =(rg[j0][0]+xyz[0])/2.0;
		rg[j][1] =(rg[j0][1]+xyz[1])/2.0;
		rg[j][2] =(rg[j0][2]+xyz[2])/2.0;
	      }
	      // must use the correct curved split location
	      else{
		loc = verts_pts[iter_vert->first];
		E_XYZ_bezierCtrlPt(xyz, rg[j0], loc.xyz, rg[j]);		
	      }
	    }
	    else if (v[j1]) {

	      // temporary for interior
	      std::map<pVertex, bptxyz>::iterator iter_vert = verts_pts.find(v[j1]);

	      if(iter_vert ==  verts_pts.end()) {
		rg[j][0] =(rg[j1][0]+xyz[0])/2.0;
		rg[j][1] =(rg[j1][1]+xyz[1])/2.0;
		rg[j][2] =(rg[j1][2]+xyz[2])/2.0;
	      }
	      else{
		loc = verts_pts[iter_vert->first];
		E_XYZ_bezierCtrlPt(xyz, rg[j1], loc.xyz, rg[j]);
	      }
	      
	    }
	    else {
	      std::cerr << "\n Error: Should never happen!" << endl;
	    }
	  }
	  
	  // using Bezier to check the validity
	  if(!HO_XYZ_isValid(rg, &csi)) {
	    PList_delete (eregs);
	    PList_delete (rvlist);
	    
	    if( pSxyz )
	      delete pSxyz;
	    if( vertMv ) 
	      adaptUtil::move_vertex(vertMv,ori);
	    return 0;
	  }
	  
	  // determine the worst shape
	  if( worstShape > csi.shape )
	    worstShape=csi.shape;
	}
	PList_delete(rvlist);
      }
      PList_delete(eregs);
    }
  }
#endif/*CURVE*/

  if( vertMv ) 
    adaptUtil::move_vertex(vertMv,ori);
  if( pSxyz )
    delete pSxyz;

#ifdef DEBUG
  if (worstShape==BIG_NUMBER) 
    return 0; 
#endif
#ifndef CURVE
  if (worstShape<QUALITYFRACTION*QUALITYTHRESHOLD)
    return 0;
#endif/*CURVE*/
  results->setWorstShape(worstShape);  
  return 1;
}


int DSplitClpsMod::sizeCheck()
{
  pFace face;
  pVertex vt;
  double xyz1[3], ori[3];
  double min, max;
  double tmp;
  int i, k;

  if( !pSizeField ) {
    printf("WARNING: NULL metric field. You can not do size checking");
    return 1;
  }

  if( vertMv ) {
    V_coord(vertMv,ori);
    adaptUtil::move_vertex(vertMv,target);
  }  

  // interpolate the metric
  pMSize pmt, mtSplt;
  mtSplt=pSizeField->getSize(xyz,(pEntity)region);

  // take care of new edges
  min=BIG_NUMBER;
  max=0.0;
  for( k=0; k<2; k++ ) {

    for( i=0; i<E_numFaces(edgePair[k]); i++ ) {
      face=E_face(edgePair[k],i);
      vt=F_edOpVt(face,edgePair[k]);
      pmt=pSizeField->getSize(vt);
      if( !pmt ) {
	if( vertMv ) V_coord(vertMv,ori);
        if( mtSplt ) delete mtSplt;
	return 0;
      }
      V_coord(vt,xyz1);
      tmp=pSizeField->lengthSq(xyz,xyz1,mtSplt,pmt);

      if( tmp>max ) max=tmp;
      if( tmp<min ) min=tmp;
    }
  }

  results->setMaxSize(max);
  results->setMinSize(min);
  if( mtSplt )
    delete mtSplt;
  if( vertMv ) 
    adaptUtil::move_vertex(vertMv,ori);
  return 1;
}


void DSplitClpsMod::getAffectedRgns(pPList *l)
{
  pPList eregs;
  pRegion rgn;
  int i;
  void *iter;

  *l=PList_new();
  PList_append(*l,region);

  for( i=0; i<2; i++ ) {
    eregs=E_regions(edgePair[i]);
    
    iter=0;
    while( rgn=(pRegion)PList_next(eregs,&iter) ) 
      if( rgn!=region )
	PList_append(*l,rgn);

    PList_delete(eregs);
  }

  return;
}

// following routines should be re-written someday so that it is done
// by cavity construction and re-triangulation
int DSplitClpsMod::apply()
{
  pEdge edgeDel;
  pVertex vd;
  pVertex newV[2];
  int k;
  
  pPList newRegs;

  int flag=0;
  if( E_whatInType(edgePair[0])==Gregion ) 
    flag=1;
  if( vertMv ) {
    adaptUtil::move_vertex(vertMv,target,CB_move,userData_CB_move);
#ifdef DEBUG
    pRegion region;
    pPList mvRgns=V_regions(vertMv);
    void *iter=0;
    while( region=(pRegion)PList_next(mvRgns,&iter) ) {
      if( R_inClosure(region,(pEntity)edgePair[0]) )
	continue;
      if( R_inClosure(region,(pEntity)edgePair[1]) )
	continue;
      if( R_Volume2(region) < 1.e-14 )
	printf("Error: 1. region %d: R_volume=%f (edgeSwapMod::apply())\n",
	       EN_id((pEntity)region),R_Volume2(region));
    }
    PList_delete(mvRgns);
    printf("DSplitCollaps: no negative volume after motion\n");
#endif
  }

  // interpolate mesh size at xyz
  pMSize pSxyz=pSizeField->getSize(xyz,(pEntity)region);
#ifdef CURVE
  if(quadratic) {
    verts_pts.clear();
    double param[3];
   // apply curved edge split on edgePair[0]
    E_eval(edgePair[0], 0.25, ptloc[0].xyz, param);
    E_eval(edgePair[0], 0.75, ptloc[1].xyz, param);
    verts_pts[E_vertex(edgePair[0], 0)] = ptloc[0];
    verts_pts[E_vertex(edgePair[0], 1)] = ptloc[1];

    int nume_f = E_numFaces(edgePair[0]);
    // apply curved face split on edgePair[0]
    for( k=0; k<nume_f; k++ ) {
      pFace face = E_face(edgePair[0], k);
      F_bezierSplit(face, edgePair[0], ptloc[k+2].xyz);

      // get the opposite vert of the edge on the face
      pVertex fv = F_opEdgeVert(face, edgePair[0]);

      verts_pts[fv] = ptloc[k+2];
    }
  }


#endif
  // perform splits 
  for( k=0; k<2; k++ ) 
    {
#ifdef CURVE
      // remove the middle point if needed
      if(E_numPoints(edgePair[k]))
        {
          pPoint point = E_point(edgePair[k], 0);
          P_delete(point);
        }

#endif
      newV[k]=templatesUtil::Edge_split (mesh, edgePair[k], xyz, par,
					 function_CB,userData_CB,&newRegs);
      PList_delete(newRegs);
    }

  // determine the edge collapse
  edgeDel=E_exists(newV[0],newV[1]);
#ifdef DEBUG
  if( !edgeDel )
    cout<<"Error: DSplitClpsMod::apply()"<<endl;
#endif

  if(flag) {
    vd=newV[0];
    vr=newV[1];
  } else {
    vd=newV[1];
    vr=newV[0];
  }
#ifdef CURVE
  if(E_numPoints(edgeDel))
    {pPoint point = E_point(edgeDel, 0); P_delete(point);}
#endif
  // move the retained new vertex and perform collapse
//  adaptUtil::move_vertex(vr,xyz,CB_move,userData_CB_move);
  templatesUtil::Edge_colaps(mesh,edgeDel,vd,vr,function_CB,userData_CB,&newRegs);
  PList_delete(newRegs);

#ifdef CURVE
  if (quadratic) {
    newRegs =V_regions (vr);
    // define mid-side nodes for the new edges

    // for interior at this moment
    pRegion region1;
    for (void *iter=0; (region1 =(pRegion)PList_next (newRegs, &iter)); ) {
      pPList relist =R_edges (region1, 1);
      pEdge edge;
      for (void *iter1=0; (edge =(pEdge)PList_next (relist, &iter1)); ) {

        if(E_inClosure(edge, vr)) {
          // get the other vertex of the dge
          pVertex vt = E_otherVertex(edge, vr);

          std::map<pVertex, bptxyz>::iterator iter_vert = verts_pts.find(vt);
          pPoint pt;

          if(E_numPoints(edge) == 1) {
            pt = E_point(edge, 0);
          //set up the correct middle points for the edge
            if(iter_vert != verts_pts.end()) {
              bptxyz loc = verts_pts[iter_vert->first];
              P_setPos(pt, loc.xyz[0], loc.xyz[1], loc.xyz[2]);
            }

          }else{

            // create the new edges if needed;
            if(iter_vert != verts_pts.end()) {
              pPoint pt =P_new ();
              bptxyz loc = verts_pts[iter_vert->first];
              P_setPos(pt, loc.xyz[0], loc.xyz[1], loc.xyz[2]);
              E_setPoint (edge, pt);
            }
          }
        }
      }
      PList_delete (relist);
    }
    PList_delete(newRegs);
  }
#endif

  // attach the desired size
  pSizeField->setSize((pEntity)vr,pSxyz);
 
#ifdef __CURVE
 
  if (quadratic == true) { // && !newEdgeNodes.empty()) {
    // set new nodes on the edges that have been merged
    pPList newRegions=V_regions(vr);
    // set up new edge nodes if on model boundary
    if(model_type==PARAM){
      cout<<"set up new edge nodes if on model boundary"<<endl;
      void *temp=0;
      pRegion newRgn;
      pEdge newEdge;
      pPList relist;
      while(newRgn=(pRegion)PList_next(newRegions,&temp)){
	void *tempEdge=0;
	relist = R_edges(newRgn, 1);
	while(newEdge=(pEdge)PList_next(relist,&tempEdge)){
	  if(E_whatInType(newEdge) != 3){
	    if(!E_numPoints(newEdge)) {
	      double xyz[3];
	      double par[3];
	      templatesUtil::middlePoint(newEdge,0.5,xyz,par);
	      pPoint pt = P_new();
	      P_setPos(pt, xyz[0], xyz[1], xyz[2]);
	      E_setPoint(newEdge, pt);
	      AOMD_P_setParametricPos(pt, par[0], par[1], par[2]);
	    }
	    else{
	      double xyz[3];
	      double par[3];
	      templatesUtil::middlePoint(newEdge,0.5,xyz,par);
	      pPoint pt = E_point(newEdge, 0);
	      P_setPos(pt, xyz[0], xyz[1], xyz[2]);
	      //E_setPoint(newEdge, pt);
	      AOMD_P_setParametricPos(pt, par[0], par[1], par[2]);
	    }
	  }
	}
      }
      //PList_delete(relist);
      
    }
  }

 //    int numv_e = V_numEdges(vr);
//     pEdge edge;
//     pPoint pt;
//     for (int iter=0; iter <numv_e; iter++) {
//       edge = V_edge(vr, iter);
//       std::map<pVertex, pPoint>::iterator it =newEdgeNodes.find(E_otherVertex (edge, vr));
//       if (it!=newEdgeNodes.end()) {
// 	pt = newEdgeNodes[it->first];
// 	P_delete(pt);
//       }
//     }
//     newEdgeNodes.clear ();
    


#endif /* CURVE */

  return 1;
}

//  int DSplitClpsMod::apply()
//  {
//    meshTemplate *ref = new meshTemplate(mesh,0);
//    pMeshDataId intflag=MD_newMeshDataId("intflag");  
//    pRegion rgn;
//    pFace face;
//    pVertex newVt;
//    void *iter;

//    if( vertMv )
//      adaptUtil::move_vertex(vertMv,target,CB_move,userData_CB_move);

//    // interpolate mesh size at xyz
//    pMSize pSxyz=pSizeField->getSize(xyz,(pEntity)region);
  
//    // get the old cavity
//    pPList oldCavity;
//    getAffectedRgns(&oldCavity);
  
//    // get faces on cavity closure
//    pPList Bfaces=adaptUtil::getCavityClosure(oldCavity,intflag);
//    pGEntity gent=(pGEntity)R_whatIn(region);

//    if( E_whatInType(edgePair[0])==Gregion && 
//        E_whatInType(edgePair[1])==Gregion )
//      newVt = M_createVP2(mesh,xyz,par,0,gent);
//    else {
//      int k=0; 
//      if( E_whatInType(edgePair[0])==Gregion )
//        k=1;
//      pPList efaces=adaptUtil::R_edAdjFcs(region,edgePair[k]); 
//      iter=0;
//      while( face=(pFace)PList_next(efaces,&iter) ) {
//        if( PList_inList(Bfaces, face) ) {
//  	PList_remItem(Bfaces, face);
//  	EN_deleteData((pEntity)face,intflag);
//        }
//      }

//      ref->setRefineLevel(edgePair[k],1);
//      ref->F_refine((pFace)PList_item(efaces,0));
//      ref->F_refine((pFace)PList_item(efaces,1));
//      PList_delete(efaces);
//      pPList ents=ref->getAttachPList((pEntity)edgePair[k]);
//  #ifdef DEBUG
//      if( !ents )
//        printf("Error: DSplitClpsMod::apply()\n");
//  #endif
//      // note that the given par is not used here
//      newVt = (pVertex)PList_item(ents,0);
//      adaptUtil::move_vertex(newVt,xyz);
//    }

//    // attach the desired size
//    pSizeField->setSize((pEntity)newVt,pSxyz);

//    // fill the cavity
//    pPList newRegions=PList_new();
//    int n=PList_size(Bfaces);
//    pFace *opFaces=new pFace[n];
//    int *dirs=new int[n];
//    pGEntity *g_entities=new pGEntity[n];
//    int value,i=0;
//    iter=0;
//    while( face=(pFace)PList_next(Bfaces,&iter) ) {
//      opFaces[i]=face;
//      g_entities[i]=gent;
//      EN_getDataInt((pEntity)face,intflag,&value);
//      dirs[i]=value;
//      EN_deleteData((pEntity)face,intflag);
//      i++;
//    }
//    MD_deleteMeshDataId(intflag);
//    ref->faces_vert_create_regions(mesh, newVt, n, opFaces, dirs,
//  				 g_entities,newRegions,0);
//    delete [] opFaces;
//    delete [] g_entities;
//    delete [] dirs;
//    PList_delete(Bfaces);

//    // call back
//    if ( function_CB )
//      (function_CB)(oldCavity,newRegions,userData_CB,RCOLAPS_2,(pEntity)newVt);

//    // delete old cavity
//    iter=0;
//    while( rgn=(pRegion)PList_next(oldCavity,&iter) )
//      ref->delete_region(rgn,1);

//    // correct classification in case non-manifold
//    // we do not take care of it so far

//    // clean up
//    PList_delete(oldCavity);
//    PList_delete(newRegions);
//    delete ref;

//    return 1;
//  }

int DSplitClpsMod::apply(pPList *newRegions)
{
  int flag=apply();
  *newRegions=V_regions(vr);
  return flag;
}
