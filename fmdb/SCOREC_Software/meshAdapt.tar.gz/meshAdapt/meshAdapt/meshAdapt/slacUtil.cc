#include "AdaptUtil.h"
#include "slacUtil.h"
#include "visUtil.h"
#include "templateUtil.h"
#include "EdgeSwapMod.h"
#include "SplitCollapsMod.h"
#include "EdgeCollapsMod.h"
#include "Macros.h"
#include "ParamsOnGFace.h"
#include "MeshSize.h"
#include "meanRatio.h"
#include <math.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <assert.h>
#include <cstring>
#include <map>
#include "MeshTools.h"
#include "fromMeshTools.h"
#include "MeshAdjTools.h"
#include "PList.h"

#include "FMDB.h"
#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#include "MeshTools.h"
#include "mMesh.h"

#ifdef CURVE
#include "curveUtil.h"
#include "curveMesh.h"
using namespace curveUtil;
#endif

using namespace std;

namespace slacUtil { 

#ifdef CURVE

  // defined as maxEdgeLength/minEdgeLength
  // ideally less than 20
  int SU_AspectRatio(pRegion region, double &shape){
    
    double maxEdgeLength = - 999.9;
    double minEdgeLength =   999.9;

    pPList elist = R_edges(region, 1);
    pEdge edge = NULL;
    for(int i=0; i<6; i++){
      edge = (pEdge)PList_item(elist, i);
      double edgeLength = E_length(edge);
     
      if(edgeLength > maxEdgeLength)
        maxEdgeLength = edgeLength;
    
      if(edgeLength < minEdgeLength)
        minEdgeLength = edgeLength;  
    }

    PList_delete(elist);
    
    shape = maxEdgeLength/minEdgeLength;

    return 1;

  }

  // ideally larger than 0.1
  int SU_RadiusRatio(pRegion region, double &shape){
    
    pPList vlist = PList_new();
    vlist = R_vertices(region, 1);

    double dVtxCrds[4][3];
    for(int i=0; i<4; i++)
      for(int j=0; j<3; j++)
        dVtxCrds[i][j] = 0.0;

    pVertex vtx;
    for(int i=0; i<4; i++){
      vtx = (pVertex)PList_item(vlist, i);
      V_coord(vtx, dVtxCrds[i]);
    }

    PList_delete(vlist);
    
    SU_XYZ_RadiusRatio(dVtxCrds, shape);

    return 1;
  }

  int SU_XYZ_RadiusRatio(double (*dVtxCrds)[3], double &shape){
  
    /* get the vertex list and coordinates */
/*    pPList vlist = PList_new();
    vlist = R_vertices(region, 1);
    double coords[3];
    pVertex vert;
    for(int i=0; i<4; i++){
      vert = (pVertex)PList_item(vlist, i);
      V_coord(vert, coords);
      cout<<"Vertex #"<<i<<": X - "<<coords[0]<<"; Y - "<<coords[1]<<"; Z - "<<coords[2]<<";"<<endl;
    }
    PList_delete(vlist);  */
    /* get the edge length and compute the "end_product" */
/*    pPList elist = PList_new();
    elist = R_edges(region, 1);
    pPList vlist = PList_new();
    vlist = R_vertices(region, 1);
    
    double dVtxCrds[4][3];
    for(int i=0; i<4; i++)
      for(int j=0; j<3; j++)
        dVtxCrds[i][j] = 0.0;
    
    pVertex vtx;
    for(int i=0; i<4; i++){
      vtx = (pVertex)PList_item(vlist, i);
      V_coord(vtx, dVtxCrds[i]);
    }

    PList_delete(vlist);

    pEdge edge;
*/
    double lengthOfStraightEdge[] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0}; 
//    for(int i=0; i<6; i++){
//      edge = (pEdge)PList_item(elist, i);
//      lengthOfStraightEdge[i] = E_length(edge);
//    }

    lengthOfStraightEdge[0] = P_length(dVtxCrds[0], dVtxCrds[1]);
    lengthOfStraightEdge[1] = P_length(dVtxCrds[1], dVtxCrds[2]);
    lengthOfStraightEdge[2] = P_length(dVtxCrds[0], dVtxCrds[2]);
    lengthOfStraightEdge[3] = P_length(dVtxCrds[0], dVtxCrds[3]);
    lengthOfStraightEdge[4] = P_length(dVtxCrds[1], dVtxCrds[3]);
    lengthOfStraightEdge[5] = P_length(dVtxCrds[2], dVtxCrds[3]);

//    PList_delete(elist);

    /* calculate the "end_product" */

    double p1 = lengthOfStraightEdge[0]*lengthOfStraightEdge[5];
    double p2 = lengthOfStraightEdge[1]*lengthOfStraightEdge[3];
    double p3 = lengthOfStraightEdge[2]*lengthOfStraightEdge[4];

    double endProd = sqrt((p1+p2+p3)*(p1+p2-p3)*(p1-p2+p3)*(p2+p3-p1));

    double semiPerimeter;
    int edgeIndex[4][3]={{0,1,2},{1,4,5},{2,3,5},{0,3,4}};
    double faceArea[] = {0.0, 0.0, 0.0, 0.0};
    for(int i=0; i<4; i++){
      semiPerimeter = (lengthOfStraightEdge[edgeIndex[i][0]]+lengthOfStraightEdge[edgeIndex[i][1]]+lengthOfStraightEdge[edgeIndex[i][2]])/2;
      faceArea[i] = sqrt(semiPerimeter*(semiPerimeter-lengthOfStraightEdge[edgeIndex[i][0]])*(semiPerimeter-lengthOfStraightEdge[edgeIndex[i][1]])*(semiPerimeter-lengthOfStraightEdge[edgeIndex[i][2]]));
    }
   
//    double volume = R_volume(region);
    double volume = XYZ_volume(dVtxCrds);  
  
    shape = 216.0 * volume * volume / (faceArea[0]*endProd+faceArea[1]*endProd+faceArea[2]*endProd+faceArea[3]*endProd);

  }

#endif /* CURVE */

  int SU_mesh_info(pMesh pMeshMesh, int &nbr_int_tets, int &nbr_ext_tets, int &nbr_surf_midpts, vector<pRegion> &int_rgns, vector<pRegion> &ext_rgns)
  {
    int_rgns.clear();
    ext_rgns.clear();

    int interior_surf_ids[]={4,14,24,34,46,56,66,76,86,96,106,116,124,134,144,154};

    nbr_int_tets = 0;
    nbr_ext_tets = 0;
    nbr_surf_midpts = 0;

    RIter rgnIter = M_regionIter(pMeshMesh);
    pPList flist;
    int flag;
    while(pRegion pRgnRgn = RIter_next(rgnIter)){
      flag = 0;
      flist = R_faces(pRgnRgn, 0);
      for(int i=0; i<4; i++){
        pFace pFaceFace = (pFace)PList_item(flist, i);
        if(F_whatInType(pFaceFace)!=3){
          flag = 1;
          // added for non-manifold faces connecting two model regions
          int pFaceId = GEN_tag((pGEntity)F_whatIn(pFaceFace));
          for(int temp=0; temp<16; temp++){
            if(pFaceId==interior_surf_ids[temp]){
              flag = 0;
              break;
            }
          }
          if(flag)
            break;          
        }
      }
      if(flag){
        nbr_ext_tets++;
	ext_rgns.push_back(pRgnRgn);
      }
      else{
        nbr_int_tets++;
	int_rgns.push_back(pRgnRgn);
      }
    }
    RIter_delete(rgnIter);

    EIter edgeIter = M_edgeIter(pMeshMesh);
    while(pEdge pEdgeEdge = EIter_next(edgeIter)){
      if(E_numPoints(pEdgeEdge))
        nbr_surf_midpts++;
    }
    EIter_delete(edgeIter);
    return 0;
  }

  void buildMapping(char* journal, char* IDMapping, char* BCMapping)
  {
    char comment[1024];
    char in_buff[32];
    char temp[32];
    char ext[6];
    int iSidesetID;
    int iSurfaceID;
    int iSidesetIDAll = -999;
    vector<int> exceptID; 
    fpos_t position;
    map<int, int> BCID;

    cout<<"Parsing Cubit Journal file"<<endl;
   
    strcpy(ext, journal+(strlen(journal)-4));
    if(strcmp(ext, ".jou") != 0){
      cout<<"Wrong file extension! Please check if it's the right journal file"<<endl;
      exit(1);
    }
    
    FILE *inFile = fopen(journal, "r");
    
    while(fscanf(inFile, "%s", in_buff) != EOF){
      if(in_buff[0] == '#'){
	//Clear out line because its a comment
	fgets(comment, 1024, inFile);
      }
      else if(!strcmp(in_buff, "Sideset")){
	fscanf(inFile, "%d", &iSidesetID);
	fscanf(inFile, "%s", temp);
	fgetpos(inFile, &position);
	fscanf(inFile, "%s", temp);
	if(!strcmp(temp, "all")){
	  iSidesetIDAll = iSidesetID;
	}
	else{ // not "all"
	  fsetpos(inFile, &position);
	  fscanf(inFile, "%d", &iSurfaceID);
	  BCID[iSurfaceID]=iSidesetID;
	}
	
	
      }
    }

    fclose(inFile);
      
    int iSimTag;
    int iCubitID;

    cout<<"Parsing ID Mapping file"<<endl;

    strcpy(ext, IDMapping+(strlen(IDMapping)-3));
    if(strcmp(ext, ".id") != 0){
      cout<<"Wrong file extension! Please check if it's the right ID Mapping file"<<endl;
      exit(1);
    }


    
    map<int, int>::iterator mapiter=BCID.begin();

    FILE *inFile2 = fopen(IDMapping, "r");
    FILE *outFile = fopen(BCMapping, "w");
    while(fscanf(inFile, "%s", in_buff) != EOF){
      if(in_buff[0] == '#'){
	//Clear out line because its a comment
	fgets(comment, 1024, inFile);
      }
      else if(!strcmp(in_buff, "SimFaceTag")){
	fscanf(inFile, "%d", &iSimTag);
	fscanf(inFile, "%s", temp);
	fscanf(inFile, "%d", &iCubitID);
// 	for(mapiter=BCID.begin();mapiter!=BCID.end();mapiter++){
// 	  if(iCubitID==mapiter->second)
	    
// 	}
	mapiter = BCID.find(iCubitID);
	//fprintf(outFile, "SimFaceTag %d    CubitID %d    ", iSimTag, iCubitID);
	if(mapiter!=BCID.end())
	  //fprintf(outFile, "SidesetID %d\n", mapiter->second);
	  fprintf(outFile, "SimFaceTag %d    CubitID %d    FACE_BC %d\n", iSimTag, iCubitID, mapiter->second);
	else
	  //fprintf(outFile, "SidesetID %d\n", iSidesetIDAll);
	  fprintf(outFile, "SimFaceTag %d    CubitID %d    FACE_BC %d\n", iSimTag, iCubitID, iSidesetIDAll);
      }
    }
    fclose(inFile2);
    fclose(outFile);

  }

  void exportPart(char* partfilename, pGModel model, pMesh inputMesh, map<int, int> &face_map, map<int, int> &region_map, int nproc, int rank)
  {
    //partfilename: <filename>.<No. Part>
    
    char filename[256];
    strcpy(filename, partfilename);
    char tmp[32];
    if(nproc<10){
      tmp[0]='.';
      tmp[1]='0'+rank;
      tmp[2]='\0';   // end of char array
    }
    else if(nproc>=10&&nproc<100){
      tmp[0]='.';
      tmp[1]='0'+rank/10;
      tmp[2]='0'+rank%10;
      tmp[3]='\0';   // end of char array
    }
    else if(nproc>=100&&nproc<1000){
      tmp[0]='.';
      tmp[1]='0'+rank/100;
      tmp[2]='0'+(rank/10)%10;
      tmp[3]='0'+rank%10;
      tmp[4]='\0';   // end of char array
    }
    else{
      cout<<"Error - Currently does not support more than 999 processors"<<endl;
      exit(1);
    }

    strcat(filename, tmp);
    
    
    
    cout<<endl<<"Exporting individual NCDF file..... "<<endl;
    
    if(!model)
      cout<<"No model file loaded"<<endl;

    int ntet_int=0, ntet_ext=0, ncoords=0, nsurface_midpoint=0;
    pMeshDataId vertID_tag = MD_lookupMeshDataId("vertID");
    if(!vertID_tag)
      cout<<"Can't find vertID_tag"<<endl;
    /* open partfilename */
    ofstream outfile(filename,ios::out | ios::binary);
    if (!outfile.good ()) {
      printf ("*** Can not open the output file, %s, to output",partfilename);
      return;
    }
    
    /* create a complete face map */
    pGFace gface;
    int tag;
    
    map<int, int>::iterator mapiter;
    
    GFIter gfiter = GM_faceIter(model);
    while(gface = GFIter_next(gfiter)){
      tag = GEN_tag((pGEntity)gface);
      if(tag==NULL)
	cout<<"Can't find tag"<<endl;
      else
	cout<<tag<<endl;
      mapiter = face_map.find(tag);// search existing map for the tag of gface
      if(mapiter==face_map.end()){// if not in the existing map, BCID of gface is either ALL or none.
	if((GF_region(gface,0)!=NULL)&&(GF_region(gface,1)!=NULL)){// if both sides of gface have model regions, gface is a merging face with no BCID.
	cout<<"Found merging face: "<<tag<<", assigning NOBC attribute "<<endl;
	face_map[tag]=0;// assign NOBC attribute
	}
	else
	  face_map[tag]=face_map[-1];// assign ALL attribute
      }
    }
    for(mapiter=face_map.begin();mapiter!=face_map.end();mapiter++){
      cout<<(*mapiter).first << " => "<<(*mapiter).second <<endl;
    }
    //return;
    /* create a complete region map */
    pGRegion gregion;
    GRIter griter = GM_regionIter(model);
    while(gregion = GRIter_next(griter)){
      tag = GEN_tag((pGEntity)gregion);
      mapiter = region_map.find(tag);
      if(mapiter==region_map.end())
	region_map[tag]=region_map[-1];
    }
    
    
    /* count exterior tets and interior tets */
    RIter riter = M_regionIter(inputMesh);
    pRegion region;
    pFace face;
    
    pPList extRList = PList_new();
    pPList intRList = PList_new();
    
    int count, flag, region_count=0;
    int findex[4] = {0, 3, 1, 2};
    while(region = RIter_next(riter)) {
      if(GEN_tag((pGEntity)R_whatIn(region))==1){
	region_count++;
      }
      flag = 0;
    for(int i=0; i<4; i++) {
      face = R_face(region, i);
      if(F_whatInType(face) == 2){// mesh face classified on model face
	gface =(pGFace)F_whatIn(face); //get model face
	tag = GEN_tag((pGEntity)gface);          //and its tag
 	if(face_map[tag]!=0){  //there is BCID associated with it

 	  ntet_ext++;
 	  flag = 1;
 	  break;
 	}
      }
    }

    if(flag)
      PList_append(extRList, region);
    else
      PList_append(intRList, region);
  }
  cout<<"[info] number of mesh regions classified on region 1: "<<region_count<<endl;
  RIter_delete(riter);
  ntet_int = M_numRegions(inputMesh) - ntet_ext;
  
  if(ntet_int!= PList_size(intRList))
    cout<<"something wrong"<<endl;


  /* Need to check the number of middle points */
  EIter eiter = M_edgeIter(inputMesh);
  pEdge edge;

  while(edge = EIter_next(eiter)) {
    if(E_numPoints(edge))
      nsurface_midpoint++;
  }
  EIter_reset(eiter);

  ncoords = M_numVertices(inputMesh);


  outfile<<"netcdf "<<filename<<"{"<<endl;
  outfile<<"dimensions:"<<endl;
  outfile<<"    tetinterior = "<< ntet_int <<" ;"<<endl;
  outfile<<"    tetinteriorsize = 5 ;"<<endl;
  outfile<<"    tetexterior = "<< ntet_ext <<" ;"<<endl;
  outfile<<"    tetexteriorsize = 9 ;"<<endl;
  outfile<<"    ncoords = "<< ncoords <<" ;"<<endl;
  outfile<<"    coord_size = 3 ;"<<endl;
  outfile<<"    surface_midpoint_size = 5 ;"<<endl;
  if(nsurface_midpoint){
    outfile<<"    nsurface_midpoint = "<<nsurface_midpoint<<" ;"<<endl;
  }
  outfile<<endl;
  outfile<<"variables:"<<endl;
  outfile<<"    int tetrahedron_interior(tetinterior, tetinteriorsize);"<<endl;
  outfile<<"    int tetrahedron_exterior(tetexterior, tetexteriorsize);"<<endl;
  outfile<<"    double coords(ncoords, coord_size);"<<endl;
  if(nproc>1)
    outfile<<"    int coordids(ncoords);"<<endl;
  if(nsurface_midpoint){
    outfile<<"    double surface_midpoint(nsurface_midpoint, surface_midpoint_size);"<<endl;
  }
  outfile.precision(16);

  outfile<<endl;
  outfile<<"data:"<<endl;
 
  //create sorted vertex list
  pVertex vertex;
  vector<pVertex> sortedVerts;
  VIter viter = M_vertexIter(inputMesh);
  //vertSorting(viter, 1, &sortedVerts);
  
  // increasing order sorting
  pVertex vert;
  map<int, pVertex> vertMap;
  //map<int, pVertex>::iterator it;
  map<int, double*> IdCrdMap;
  int id;
  //double coords[3];
  while(vert = VIter_next(viter)){
    double* coords = new double[3];
    EN_getDataInt(vert, vertID_tag, &id);
    V_coord(vert, coords); 
    //cout<<"coords: "<<coords[0]<<" "<<coords[1]<<" "<<coords[2]<<endl;
    //cout<<id<<endl;
    vertMap[id]=vert;
    IdCrdMap[id]=coords;
  }
  map<int, double*>::iterator IdCrdMapIt;
  double* crds;
  for(IdCrdMapIt=IdCrdMap.begin();IdCrdMapIt!=IdCrdMap.end();IdCrdMapIt++){
    //cout<<IdCrdMapIt->first<<endl;
    crds=IdCrdMapIt->second;
    //cout<<crds[0]<<" "<<crds[1]<<" "<<crds[2]<<endl;
  }   
  int counttmp = vertMap.size();
  //cout<<counttmp<<endl;
  id = 0;
  while(counttmp>0){
    vert = vertMap.find(id)->second;
    if(vert){
      sortedVerts.push_back(vert);
      counttmp--;
    }
    id++;
  }
  
    
  counttmp = IdCrdMap.size();

  vector<pVertex>::iterator it; //= sortedVerts.begin();

  //output the coordinate using sorted vertices;
  void *temp;
  temp = 0;
  count = 0;
  outfile<<"    coords ="<<endl;

  //cout<<sortedVerts.size()<<endl;
  double *xyz;
  //while(vertex = VIter_next(viter)){
  for(IdCrdMapIt= IdCrdMap.begin(); IdCrdMapIt!= IdCrdMap.end();IdCrdMapIt++){ 
  //id = 0;
  // while(counttmp>0){
//     vert = vertMap.find(id)->second;
//     if(vert){
//       //V_coord(vert, xyz);
//       count++;
//       if(count != ncoords)
	xyz=IdCrdMapIt->second;
	count++;
	if(count != ncoords)
	  outfile<<"     "/*<<IdCrdMapIt->first<<":"*/<<xyz[0]/1000<<", "<<xyz[1]/1000<<", "<<xyz[2]/1000<<", "<<endl;
	else
	  outfile<<"     "/*<<id<<":"*/<<xyz[0]/1000<<", "<<xyz[1]/1000<<", "<<xyz[2]/1000<<" ; "<<endl;
//       //sortedVerts.push_back(vert);
//       counttmp--;
//     }
//     id++;
//     //vertex = *it;
//     //if(!vertex)
//     // cout<<"void vertex"<<endl;
//     //  continue;
//     //EN_getDataInt(*it, vertID_tag, &id);
//     //cout<<"Got ID !!!"<<endl;
//     //if(!amITheOwnerOf(vertex))
//    //  V_coord(vertex, xyz);
// //     count++;
// //     if(count != ncoords)
// //       outfile<<"     "/*<<id<<":"*/<<xyz[0]<<", "<<xyz[1]<<", "<<xyz[2]<<", "<<endl;
// //     else
// //       outfile<<"     "/*<<id<<":"*/<<xyz[0]<<", "<<xyz[1]<<", "<<xyz[2]<<" ; "<<endl;
   }
  
//   //output coordinate IDs using sorted vertices;
//   VIter_reset(viter);
  if(nproc>1){
  count = 0;
  int coordid;
  outfile<<"    coordids ="<<endl;
  //while(vertex = VIter_next(viter)){
  //for(it= sortedVerts.begin(); it!= sortedVerts.end();it++){
  for(IdCrdMapIt= IdCrdMap.begin(); IdCrdMapIt!= IdCrdMap.end();IdCrdMapIt++){ 
  
   // vertex = *it;
    count++;
    //EN_getDataInt((pEntity)vertex, vertID_tag, &coordid);//EN_id(vertex); //starting from 0,  no offset
    if(count != ncoords)
      outfile<<"     "<<IdCrdMapIt->first<<" ,"<<endl;
    else
      outfile<<"     "<<IdCrdMapIt->first<<" ; "<<endl;
  }
  
  outfile<<endl;
  }
  //output interior region, five parameters
  
  outfile<<"    tetrahedron_interior ="<<endl;
  int matCount = 0;
  count = 0;
  temp = 0;
  int vvid;
 
  while(region = (pRegion)PList_next(intRList, &temp)) {
    gregion = R_whatIn(region);
    tag = GEN_tag((pGEntity)gregion);
    outfile<<"       "<<region_map[tag]<<","; // first para is material number
    count++;
	//debug
    if(region_map[tag]==2){
	matCount++;
    }
	//
    pPList rvlist = R_vertices(region, 1); // next four paras are vertex ids
    if(count != ntet_int) {
      for(int i=0; i<4; i++) {
	vertex = (pVertex)PList_item(rvlist, i);
	EN_getDataInt((pEntity)vertex, vertID_tag, &vvid);
	outfile<<vvid<<", ";
      }
    }
    else {
      for(int i=0; i<3; i++) {
	vertex = (pVertex)PList_item(rvlist, i);
	EN_getDataInt((pEntity)vertex, vertID_tag, &vvid);
	outfile<<vvid<<", ";
      }
      vertex = (pVertex)PList_item(rvlist, 3);
      EN_getDataInt((pEntity)vertex, vertID_tag, &vvid);
      outfile<<vvid<<" ;";
    }
    
    outfile<<endl;
    
    PList_delete(rvlist);
  }
  outfile<<endl;
  
  cout<<"interior region: "<<count<<endl;


  if(count != ntet_int) {
    cout<<"something wrong on the interior region"<<endl;
  }

  
  // output exterior region, 9 parameters  ///////////////// with BCID information ////////////////////
  temp = 0;
  count = 0;
  pGEntity gent;
  outfile<<"    tetrahedron_exterior ="<<endl;
  while(region = (pRegion)PList_next(extRList, &temp)) {
    gregion = R_whatIn(region);
    tag = GEN_tag((pGEntity)gregion);
    outfile<<"       "<<region_map[tag]<<","; //first para is material number
    // outfile<<"       1, ";
//debug
    if(region_map[tag]==2){
	matCount++;
    }
//
    count++;
    pPList rvlist = R_vertices(region, 1); // next four are vertices
    for(int i=0; i<4; i++) {
      vertex = (pVertex)PList_item(rvlist, i);
      EN_getDataInt((pEntity)vertex, vertID_tag, &vvid);
      outfile<<vvid<<", ";
    }
    PList_delete(rvlist);
    
    if(count != ntet_ext) { // last four are boundary condition info of 4 faces.
      for(int i=0; i<4; i++) {
	face = R_face(region, findex[i]); // using findex
	
	if(F_whatInType(face) == 3) // output -1 for interior mesh faces
	  outfile<<"-1, ";
	else{
	  int idd;
	  gent = F_whatIn(face);
	
	  idd = GEN_tag(gent) ;
	 
	  if(face_map[idd]==0) // if no BC attribute, output -1
	    outfile<<"-1, ";
	  else
	    outfile<<face_map[idd]<<", ";
	}
      }
    }
    else{ //last ext region
      for(int i=0; i<3; i++) {
	face = R_face(region, findex[i]);
	
	if(F_whatInType(face) == 3)
	  outfile<<"-1, ";
	else{
	  int idd;
	  gent = F_whatIn(face);
	 
	    idd = GEN_tag(gent) ;
	   
	    if(face_map[idd]==0)
	      outfile<<"-1, ";
	    else
	      outfile<<face_map[idd]<<", ";
	}
      }
      // last face of last ext region, need to output ";"
      face = R_face(region, findex[3]);
      
      if(F_whatInType(face) == 3)
	outfile<<"-1 ; ";
      else{
	int idd;
	gent = F_whatIn(face);

	  idd = GEN_tag(gent);

	  if(face_map[idd]==0)
	    outfile<<"-1; ";
	  else
	    outfile<<face_map[idd]<<" ; ";
      }
    }   
    outfile<<endl;
  }  
  
  outfile<<endl;
  
  cout<<"exterior region: "<<count<<endl;
  cout<<"[info] No. of regions of Material 2: "<<matCount<<endl; 
  if(count != ntet_ext) {
    cout<<"something wrong on the exterior region"<<endl;
  }
  
  PList_delete(intRList);
  PList_delete(extRList);
  
  //write out the surface point if there's any

  if(nsurface_midpoint){
    count = 0;
    outfile<<"    surface_midpoint ="<<endl;
    while(edge = EIter_next(eiter)) {
      if(!E_numPoints(edge))
	continue;
      
      count++;
      for(int i=0; i<2; i++){
	vertex = E_vertex(edge, i);
	EN_getDataInt((pEntity)vertex, vertID_tag, &vvid);
	outfile<<vvid<<", ";
      }
      
      pPoint pt = E_point(edge, 0);
      xyz[0] = P_x(pt);
      xyz[1] = P_y(pt);
      xyz[2] = P_z(pt);
      
      
      if(count!=nsurface_midpoint)
	outfile<<"      "<<xyz[0]/1000<<", "<<xyz[1]/1000<<", "<<xyz[2]/1000<<",";
      else
	outfile<<"      "<<xyz[0]/1000<<", "<<xyz[1]/1000<<", "<<xyz[2]/1000<<" ;";
      
      outfile<<endl;
      
    }
    
    if(count==0)
      outfile<<"       ;"<<endl;
  }
  EIter_delete(eiter);
  outfile<<"}";
  
  outfile.close();

}

void att_parse(char* attributefile, map<int, int> *face_map, map<int, int> *region_map)
{
  cout<<"Parsing attribute file"<<endl;
  
  FILE *inFile = fopen(attributefile, "r");
  while(inFile==NULL){
    inFile = fopen(attributefile, "r");// keep asking for the attribute file
  }

  char comment[1024];
  char in_buff[32];
  char temp[32];
  int in_val;
  int in_ent;
 
  while(fscanf(inFile, "%s", in_buff) != EOF){
    if(in_buff[0] == '#'){
      //Clear out line because its a comment
      fgets(comment, 1024, inFile);
    }
    else if(!strcmp(in_buff, "FACE_ALL")){ // Face_All attribute, assign to index -1
      fscanf(inFile, "%s", temp);
      fscanf(inFile, "%d", &in_val);
      if(!strcmp(temp, "true")){
	(*face_map)[-1] = in_val;
      }
      else{
	(*face_map)[-1] = 0;
      }
    }
    else if(!strcmp(in_buff, "FACE_BC")){ // BC attribute, assign to corresponding face
      fscanf(inFile, "%d", &in_ent);
      fscanf(inFile, "%d", &in_val);
      (*face_map)[in_ent]=in_val;
    }

    else if(!strcmp(in_buff, "FACE_NOBC")){ // NOBC, assign to corresponding index with value 0
      fscanf(inFile, "%d", &in_ent);
      fscanf(inFile, "%d", &in_val);
      (*face_map)[in_ent]=in_val;
      
    }
    else if(!strcmp(in_buff, "REGION_ALL")){ // region map, index -1
      fscanf(inFile, "%s", temp);
      fscanf(inFile, "%d", &in_val);
      if(!strcmp(temp, "true")){
	(*region_map)[-1] = in_val;
      }
      else{
	(*region_map)[-1] = 0;
      }
    }
    else if(!strcmp(in_buff, "REGION_MAT")){ // particular material attribute to certain region
      fscanf(inFile, "%d", &in_ent);
      fscanf(inFile, "%d", &in_val);
      (*region_map)[in_ent]=in_val;
    }

    else{
      cout<<"Key word has not been implemented yet!"<<endl;
      exit(1);
    }
  }
  fclose(inFile);
  
  cout<<"Parsing completed"<<endl;
  // exit(1);
}

// write out summary file of partitioned ncdf files
// Sep. 3 2009, QiuKai Lu
void exportSummary(char* filename, unsigned long ntetra, unsigned long ncoords, int nfiles)
{
  //filename:  the name of partitioned mesh that is loaded in

  //for individual mesh parts, naming convention is <filename>.<No. Part>

  cout<<endl<<"Exporting summary file..... "<<endl;

  //output text file

  ofstream outfile("Summary");
  if (!outfile.good ()) {
    printf ("*** Can not open the output file Summary to output");
    return;
  }
  
  int lengthfilename = 0;
  if(nfiles<=9) // single digit
    lengthfilename = strlen(filename)+2;
  else if(nfiles<=99) // double digit
    lengthfilename = strlen(filename)+3;
  else if(nfiles<=999) // triple digit
    lengthfilename = strlen(filename)+4;
  else{
    cout<<"Error - Currently does not support more than 999 processors"<<endl;
    exit(1);
  }

  
  outfile<<"netcdf "<<filename<<"{"<<endl;
  outfile<<"dimensions:"<<endl;
  outfile<<"    ntetra = "<< ntetra <<" ;"<<endl;
  outfile<<"    ncoords = "<<ncoords<<" ;"<<endl;
  outfile<<"    nfiles = "<<nfiles<<" ;"<<endl;
  outfile<<"    lengthfilename = "<<lengthfilename<<" ;"<<endl;
  outfile<<endl;
  outfile<<"variables:"<<endl;
  outfile<<"    char** filenames(nfiles, lengthfilename);"<<endl;
  outfile<<endl;
  outfile<<"data:"<<endl;
  outfile<<"    filenames ="<<endl;
  
  for(int i=0;i<nfiles-1;i++){
    outfile<<"      "<<filename<<"."<<i<<","<<endl;
  }
  outfile<<"      "<<filename<<"."<<nfiles-1<<";"<<endl;
  outfile<<"}"<<endl;
  
  outfile.close();
}




}
