/*****************************************************************************
 *
 *  templateRefine/SF_MigrationCallbacks.h
 *  Created by Seegyoung Seol, on Mon Dec 15 2003, 10:26:37 EDT
 *
 *  Copyright (c) 2003, Scientific Computation Research Center
 *
 *  <a href="http://www.scorec.rpi.edu" CLASS="nav">www.scorec.rpi.edu</a>
 *
 *  File Content: Size field migration callbacks class 
 *
 ****************************************************************************/
 
#ifdef MA_PARALLEL
#ifdef AOMD_
#ifndef _SF_MIGRATIONCALLBACKS_H
#define _SF_MIGRATIONCALLBACKS_H
#include <iostream>
#include <math.h>
#include <vector>
#include "MeshAdapt.h"
#include "MeshSize.h"
#include "PWLinearSField.h"
#include "FMDB_cint.h"

using std::vector;
using std::cout;
using std::endl;

#include "pmZoltanCallbacks.h"

class sizeFieldBase;
 
class SF_MigrationCallbacks: public pmZoltanCallbacks
{
private:
  pSField pSizeField;
  pMeshDataId SolutionID;
  int nVar;
  int PredLB;
public :
  SF_MigrationCallbacks(pSField sf)
    : pmZoltanCallbacks(pmZoltanCallbacks::PARMETIS),pSizeField(sf),SolutionID(NULL), nVar(0), PredLB(0) {}

  virtual bool useWeights() const 
      {
          if(PredLB)
              return true;
          return false;
      }
  virtual float getWeight (pEntity ent) const 
      {
          if(PredLB){
              double weight;
              EN_getWeight(ent, &weight);
              return (float)weight;
          }
          return 1.0;
      }
  virtual void * getUserData (pEntity, int dest_proc, int &size);
  virtual void receiveUserData (pEntity, int pid, int tag, void *buf);
  virtual void deleteUserData (void *buf);
  virtual void deleteEntityData (pEntity ent);
  virtual void SF_setSolutionID(pMeshDataId SolID){SolutionID=SolID;}
  virtual void SF_setnVar(int nV){nVar = nV;}
  virtual void SF_setPredLB(int predlb){PredLB=predlb;}

  virtual void * getEntGrpUserData (mEntityGroup* e, int dest_proc, int &size) { size =0; return 0; }
  virtual void receiveEntGrpUserData (mEntityGroup* e, int pid, int tag, void *buf) {}
  virtual void deleteEntGrpUserData (void *buf)  { free(buf); }
  virtual void deleteEntGrpData (mEntityGroup* e) {}

};


/// Temporary solution for keeping BL nodes tags consistent when do migration within snapBLNodes() routine.
/// Later all the tags have to migrate along with the entity and this solution will be obsolete.
/// Here it is assumed that all the tags are uniformly allocated on each part, otherwise it is needed to send the string instead of each tag.
class BL_MigrationCallbacks: public pmZoltanCallbacks //pmMigrationCallbacks
{
private:
  pMeshDataId gcNormalTag, ptr_xyz, updateGCOnModelBdryID, topNodeMoveID, moveDirID, moveVectorID, notBLSnapID;
  int iDblSize, iIntSize, iTagSize;
  pSField pSizeField;
  pMeshDataId SolutionID;
  int nVar;
  int PredLB;
public :
  BL_MigrationCallbacks(pSField sf): pmZoltanCallbacks(pmZoltanCallbacks::PARMETIS), pSizeField(sf) { init(); }
  void init(void);
  /// from a given graph, we retrieve a partitionVector
  //  virtual void partition(AOMD_distributed_graph2 &theGraph , int *partitionVector) = 0;
  virtual void partition(mMesh* mesh, map<mEntity*, int>& POtoMove) {}  // modify the parameters, do not use global part integer ids.
  virtual void partition(mPart* mesh, map<mEntity*, int>& POtoMove) {}
  virtual void partition(vector<mMesh*>& mesh, map<mEntity*, int*>& POtoMove, map<mEntityGroup*, int*>& ) {}
  virtual void partition(vector<mMesh*>& mesh, map<mEntity*, int*>& POtoMove) {}
  virtual void partition(vector<mPart*>& mesh, map<mEntity*, int*>& POtoMove, map<mEntityGroup*, int*>& ) {}
  virtual void partition(vector<mPart*>& mesh, map<mEntity*, int*>& POtoMove) {}

  virtual bool useWeights() const
      {
          if(PredLB)
              return true;
          return false;
      }
  virtual float getWeight (pEntity ent) const
      {
          if(PredLB){
              double weight;
              EN_getWeight(ent, &weight);
              return (float)weight;
          }
          return 1.0;
      }
  virtual void SF_setSolutionID(pMeshDataId SolID){SolutionID=SolID;}
  virtual void SF_setnVar(int nV){nVar = nV;}
  virtual void SF_setPredLB(int predlb){PredLB=predlb;}

  /// user can create data's attached to a given mesh entity
  /// data's have size "size"
  virtual void * getUserData (mEntity *, int dest_proc, int &size);
  /// user has to provide a way to delete its own data (delete or free).
  virtual void deleteUserData (void *);
  /// user has to take care of data associated with mesh entities (via pMeshDataId etc.)
  virtual void deleteEntityData (mEntity *);
  /// user receives its data's. mEntity is now the mesh entity on the
  /// remote side.
  virtual void receiveUserData (mEntity *, int pid, int tag, void *buf);
  virtual int nbProcs() const {}

   void * getEntGrpUserData (mEntityGroup *, int dest_proc, int &size) { size = 0; return 0; }
   virtual void deleteEntGrpUserData (void *) {}
   virtual void deleteEntGrpData (mEntityGroup *) {}
   virtual void receiveEntGrpUserData (mEntityGroup *, int pid, int tag, void *buf) {}
};

#endif
#endif
#endif
