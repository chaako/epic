#include "MA.h"

#ifdef CURVE

#include "curveUtil.h"



extern "C"
int CMA_NewCrvMeshObj(pCrvMesh &pCrvMeshObj, pMesh pMeshMesh)
{
  int iSuccess = 1;

  int theModelType = 2;
  int theCurveType = 0;
  pCrvMeshObj = new curveMesh(pMeshMesh, theModelType, theCurveType);

  if(!pCrvMeshObj)
    iSuccess = 0;

  return iSuccess;
}

extern "C"
int CMA_DelCrvMeshObj(pCrvMesh pCrvMeshObj)
{
  int iSuccess = 1;

  delete pCrvMeshObj;

  return iSuccess;
}

extern "C"
int CMA_SetModelType(pCrvMesh pCrvMeshObj, int iModelType)
{
  int iSuccess = 1;

  pCrvMeshObj->CM_SetModelType(iModelType);

  return iSuccess;
}

extern "C"
int CMA_CurveLinearMesh(pCrvMesh pCrvMeshObj)
{
  int iSuccess = 1;

  pCrvMeshObj->CMA_CreateHOEdges();

  return iSuccess;
}

extern "C"
int CMA_FixInvalidCurvedElement(pCrvMesh pCrvMeshObj)
{
  int iSuccess = 1;

  

  return iSuccess;
}

extern "C"
int CMA_ClearHighOrderNodes(pCrvMesh pCrvMeshObj)
{
  int iSuccess = 1;

  pCrvMeshObj->CMA_ClearHONodes();

  return iSuccess;

}

extern "C"
int CMA_LockSurfaceMesh(pCrvMesh pCrvMeshObj)
{

  return pCrvMeshObj->CMA_LockSurfaceMesh();

}

extern "C"
int CMA_SetCrvMeshQualityThreshold(pCrvMesh pCrvMeshObj, double dThreshold)
{

  return pCrvMeshObj->CMA_SetCrvMeshQualityThreshold(dThreshold);

}

extern "C"
int CMA_ImproveMeshQualityByMeshMod(pCrvMesh pCrvMeshObj)
{

  int iSuccess = 1;
  pCrvMeshObj->run();
  return iSuccess;

}

#endif /* CURVE */
