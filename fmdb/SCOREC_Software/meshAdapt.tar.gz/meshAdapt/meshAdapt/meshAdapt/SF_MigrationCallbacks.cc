/*<i> ****************************************************************************
 *
 *  templateRefine/SF_MigrationCallbacks.cc
 *  Created by Seegyoung Seol, on Mon Dec 15 2003, 10:26:37 EDT
 *
 *  Copyright (c) 2003, Scientific Computation Research Center
 *
 *  <a href="http://www.scorec.rpi.edu" CLASS="nav">www.scorec.rpi.edu</a>
 *
 *  File Content: Size field migration callbacks class definition
 *
 *************************************************************************** </i>*/

#include <iostream>
#include <math.h>
#include <vector>
#include "SF_MigrationCallbacks.h"
#include "MeshAdapt.h"
#include "MeshSize.h"
#include "PWLinearSField.h"
#include "FMDB_cint.h"
#include "FMDB_Internals.h"
#include "mEntity.h"

using std::vector;
using std::cout;
using std::endl;

#ifdef AOMD_
#ifdef MA_PARALLEL
#include "pmZoltanCallbacks.h"

class sizeFieldBase;

void* SF_MigrationCallbacks::getUserData (pEntity ent, int dest_proc, int &size)
{
  if (pSizeField->type()!=1)
  {
    size=0;
    return (0);
  }

  if (EN_type(ent)!=0)
  { 
    // size=(12+nVar)*sizeof(double);
    // char *mybuffer = (char*) malloc (size);
    // return mybuffer;
    size=0;
    return (0);
  }

  pMSize pS = pSizeField->getSize((pVertex)ent);

  size = (12+nVar)*sizeof(double);
  char *mybuffer = (char*) malloc (size);
  double *dbuf = (double*)malloc((12+nVar)*sizeof(double));

  int pos=0;
  for (int i=0;i<3;++i)
    dbuf[pos++]=pS->size(i);
  for (int i=0;i<3;++i)
  {  double* ebuf=pS->eigenvector(i);
     for (int j=0;j<3;++j)
       dbuf[pos++]=ebuf[j];
  }

  double *nodalData;
  if(nVar) {   
    if(!EN_getDataPtr(ent,SolutionID,(void **)&nodalData)) {
        printf("\nsolution not attached\n");
        exit(0);
    }
    for (int i=0;i<nVar;++i)
      dbuf[pos++]= nodalData[i];
  }
  memcpy(&mybuffer[0], dbuf,(12+nVar)*sizeof(double));

  free(dbuf);
  // the following is taken care in deleteEntityData()
  // as getUserData() is NOT called for all entities to be removed
  // if (EN_deleteUserData(ent,dest_proc))
  // {
    // pSizeField->deleteSize(ent); // to prevent memory leak
    // if(nVar) {
    //  delete [] nodalData;
    //  EN_deleteData(ent,SolutionID);
    // }
  // }

  return mybuffer;
}

void SF_MigrationCallbacks::receiveUserData (pEntity ent, int dest_proc, int tag, void *buf)
{
  // if (pSizeField->type()==2 || M_GetElementType(ent)!=VERTEX)
  if (pSizeField->type()!=1 || EN_type(ent)!=0)
    return;  

  char *mybuffer = (char*) buf;
  
  double *dbuf = (double*)malloc((12+nVar)*sizeof(double));
  memcpy(dbuf,&mybuffer[0], (12+nVar)*sizeof(double));

  double e[3][3], h[3];
  int k=0;
  for (;k<3;k++)
    h[k]=dbuf[k];
  for (int i=0;i<3;++i)
    for (int j=0;j<3;++j)
      e[i][j]=dbuf[k++];
    
  pMSize pS = new MeshSize(e,h);
  pSizeField->setSize(ent,pS);

  if(nVar) {
    double *value = new double[nVar];
    for (int i=0;i<nVar;i++)
      value[i]=dbuf[k++];
#ifdef DEBUG
    double *nodalData;
    if(EN_getDataPtr(ent,SolutionID,(void **)&nodalData)) {
        printf("\nsolution already attached to vertex\n");
        exit(0);
    }
#endif
    EN_attachDataPtr(ent,SolutionID,(void *)value);
  }

  free(dbuf);
}

void SF_MigrationCallbacks::deleteUserData (void *buf)
{
  free(buf);
}

void SF_MigrationCallbacks::deleteEntityData (pEntity ent)
{
  if(EN_type(ent)!=0)
    return;

  pSizeField->deleteSize(ent); // to prevent memory leak
  if(nVar) {
    double * nodalData;
    if(!EN_getDataPtr(ent,SolutionID,(void **)&nodalData)) {
        printf("\nsolution not attached\n");
        exit(0);
    }
    delete [] nodalData;
    EN_deleteData(ent,SolutionID);
  }
}


void BL_MigrationCallbacks::init()
{
  iDblSize = 3*sizeof(double);
  iIntSize = sizeof(int);
  iTagSize = sizeof(pMeshDataId);

  SolutionID = NULL;
  nVar = 0;
  PredLB = 0;

  gcNormalTag = MD_lookupMeshDataId("Vector Normal");
  ptr_xyz = MD_lookupMeshDataId("pVertex_target");      // a handle to attach the target location of snapping vertices
  topNodeMoveID = MD_lookupMeshDataId("top node move ID");
  moveVectorID = MD_lookupMeshDataId("move vector ID");

  moveDirID = MD_lookupMeshDataId("move dir ID");
  updateGCOnModelBdryID = MD_lookupMeshDataId("update GC on model bdry. after snap");
  notBLSnapID = MD_lookupMeshDataId("bl not snapped");
}


void * BL_MigrationCallbacks::getUserData (mEntity *pEnt, int dest_proc, int &iMsgSize)
{
  iMsgSize = 0;
  if (pEnt->getLevel())
    return NULL;

  /// Get the size field and the nodal data
  if (pSizeField->type() == 1)
    iMsgSize += 4 * iDblSize;
  if (nVar)
    iMsgSize += nVar * iDblSize/3;

  /// To add a normal value of the BL originating vertex
  iMsgSize += iIntSize;
  void *vVal = NULL;
  if (EN_getDataPtr(pEnt, gcNormalTag, &vVal))    
    iMsgSize += iDblSize;

  /// This is to add the number iValForTotalNumTags
  iMsgSize += iIntSize;

  int iValForTotalNumTags = 0;

  /// Pointers come first, add 10 for each pointer, 1 for the integer one
  void *vpTargetPtr = NULL, *vpTopMovePtr = NULL, *vpMoveVectorPtr = NULL;
  if (EN_getDataPtr(pEnt, ptr_xyz, &vpTargetPtr))
  {
    iMsgSize += iTagSize + iDblSize;

    /// 10 is for having a target assigned
    iValForTotalNumTags += 10;
  }

  if (EN_getDataPtr(pEnt, topNodeMoveID, &vpTopMovePtr))
  {
    iMsgSize += iTagSize + iDblSize;
    iValForTotalNumTags += 10;
  }

  if (EN_getDataPtr(pEnt, moveVectorID, &vpMoveVectorPtr))
  {
    iMsgSize += iTagSize + iDblSize;
    iValForTotalNumTags += 10;
  }

  int iValMoveDir = 0, iValUpdtGC = 0, iValNotBLSnap = 0;
  if (EN_getDataInt(pEnt, moveDirID, &iValMoveDir))
  {
    iMsgSize += iTagSize + iIntSize;
    iValForTotalNumTags++;
  }

  if (EN_getDataInt(pEnt, updateGCOnModelBdryID, &iValUpdtGC))
  {
    iMsgSize += iTagSize + iIntSize;
    iValForTotalNumTags++;
  }

  if (EN_getDataInt(pEnt, notBLSnapID, &iValNotBLSnap))
  {
    iMsgSize += iTagSize + iIntSize;
    iValForTotalNumTags++;
  }

  /// Begin to pack the data.
  void * vpBuf;
  vpBuf = malloc(iMsgSize);
  iMsgSize = 0;


  if (pSizeField->type() == 1)
    iMsgSize += 4 * iDblSize;
  if (nVar)
    iMsgSize += nVar * iDblSize/3;

  double *dbuf;
  if (iMsgSize)
    dbuf = (double*)malloc(iMsgSize);

  int pos=0;
  if (pSizeField->type() == 1)
  {
    pMSize pS = pSizeField->getSize((pVertex)pEnt);

    for (int i=0;i<3;++i)
      dbuf[pos++]=pS->size(i);
    for (int i=0;i<3;++i)
    {  
      double* ebuf=pS->eigenvector(i);
      for (int j=0;j<3;++j)
        dbuf[pos++]=ebuf[j];
    }
  }

  if (nVar)
  {
    double *nodalData;
    if(!EN_getDataPtr(pEnt,SolutionID,(void **)&nodalData)) 
    {
      printf("\nsolution not attached\n");
      exit(0);
    }

    for (int i=0;i<nVar;++i)
      dbuf[pos++]= nodalData[i];
  }

  if (iMsgSize)
  {
    memcpy(vpBuf, dbuf, iMsgSize);
    free(dbuf);
  }

  /// Get normal if the vertex is originating one
  int *isOrgVtx = (int*)((char*)vpBuf + iMsgSize);
  *isOrgVtx = 0;
  iMsgSize += iIntSize;
  if (vVal)
  {
    *isOrgVtx = 1;
    double *dNorm = (double*)((char*)vpBuf + iMsgSize);
    for (int iVal = 0; iVal < 3; ++iVal)
      dNorm[iVal] = ((double*)vVal)[iVal];
    iMsgSize += iDblSize;
  }

  /// Number for tags attached to the vertex
  int * ipValTags = (int*)((char*)vpBuf + iMsgSize);
  *ipValTags = iValForTotalNumTags;
  iMsgSize += iIntSize;
  
  /// Deal with pointer values
  double *dpVertPtr;
  pMeshDataId *pTag;
  if (vpTargetPtr)
  {
    pTag = (pMeshDataId*)((char*)vpBuf + iMsgSize);
    *pTag = ptr_xyz;
    iMsgSize += iTagSize;

    dpVertPtr = (double*)((char*)vpBuf + iMsgSize);
    for (int itVal = 0; itVal < 3; ++itVal)
      dpVertPtr[itVal] = ((double*)vpTargetPtr)[itVal];
    iMsgSize += iDblSize;
  }    

  if (vpTopMovePtr)
  {
    pTag = (pMeshDataId*)((char*)vpBuf + iMsgSize);
    *pTag = topNodeMoveID;
    iMsgSize += iTagSize;

    dpVertPtr = (double*)((char*)vpBuf + iMsgSize);
    for (int itVal = 0; itVal < 3; ++itVal)
      dpVertPtr[itVal] = ((double*)vpTopMovePtr)[itVal];
    iMsgSize += iDblSize;
  }
 
  if (vpMoveVectorPtr)
  {
    pTag = (pMeshDataId*)((char*)vpBuf + iMsgSize);
    *pTag = moveVectorID;
    iMsgSize += iTagSize;

    dpVertPtr = (double*)((char*)vpBuf + iMsgSize);
    for (int itVal = 0; itVal < 3; ++itVal)
      dpVertPtr[itVal] = ((double*)vpMoveVectorPtr)[itVal];
    iMsgSize += iDblSize;
  }

  /// Deal with integer values
  int * ipIntVal;
  if (iValMoveDir)
  {
    pTag = (pMeshDataId*)((char*)vpBuf + iMsgSize);
    *pTag = moveDirID;
    iMsgSize += iTagSize;

    ipIntVal = (int*)((char*)vpBuf + iMsgSize);
    *ipIntVal = iValMoveDir;
    iMsgSize += iIntSize;
  }

  if (iValUpdtGC)
  {
    pTag = (pMeshDataId*)((char*)vpBuf + iMsgSize);
    *pTag = updateGCOnModelBdryID;
    iMsgSize += iTagSize;

    ipIntVal = (int*)((char*)vpBuf + iMsgSize);
    *ipIntVal = iValUpdtGC;
    iMsgSize += iIntSize;
  }

  if (iValNotBLSnap)
  {
    pTag = (pMeshDataId*)((char*)vpBuf + iMsgSize);
    *pTag = notBLSnapID;
    iMsgSize += iTagSize;

    ipIntVal = (int*)((char*)vpBuf + iMsgSize);
    *ipIntVal = iValNotBLSnap;
    iMsgSize += iIntSize;
  }

  return vpBuf;
}


void BL_MigrationCallbacks::deleteUserData (void *vpBuf)
{
  if (vpBuf)
    free(vpBuf);
}


void BL_MigrationCallbacks::deleteEntityData (mEntity *pEnt)
{
  if (pEnt->getLevel())
    return;

  pSizeField->deleteSize(pEnt); // to prevent memory leak
  if(nVar) 
  {
    double * nodalData;
    if(!EN_getDataPtr(pEnt,SolutionID,(void **)&nodalData)) {
        printf("\nsolution not attached\n");
        exit(0);
    }
    delete [] nodalData;
    EN_deleteData(pEnt,SolutionID);
  }

  void * vpVertPtr;
  if (EN_getDataPtr(pEnt, gcNormalTag, &vpVertPtr))
  {
    EN_deleteData(pEnt, gcNormalTag);
    delete[] (double *)vpVertPtr;
  }

  if (EN_getDataPtr(pEnt, ptr_xyz, &vpVertPtr))
  {
    EN_deleteData(pEnt, ptr_xyz);
    delete[] (double *)vpVertPtr;
  }

  if (EN_getDataPtr(pEnt, topNodeMoveID, &vpVertPtr))
  {
    EN_deleteData(pEnt, topNodeMoveID);
    delete[] (double *)vpVertPtr;
  }

  if (EN_getDataPtr(pEnt, moveVectorID, &vpVertPtr))
  {
    EN_deleteData(pEnt, moveVectorID);
    delete[] (double *)vpVertPtr;
  }


  int iVal;
  if (EN_getDataInt(pEnt, moveDirID, &iVal))
    EN_deleteData(pEnt, moveDirID);

  if (EN_getDataInt(pEnt, updateGCOnModelBdryID, &iVal))
    EN_deleteData(pEnt, updateGCOnModelBdryID);

  if (EN_getDataInt(pEnt, notBLSnapID, &iVal))
    EN_deleteData(pEnt, notBLSnapID);
}


void BL_MigrationCallbacks::receiveUserData (mEntity *pEnt, int pid, int tag, void *vpBuf)
{
  if (pEnt->getLevel())
    return;

  int iMsgSize = 0;

  if (pSizeField->type() == 1)
    iMsgSize += 4 * iDblSize;
  if (nVar)
    iMsgSize += nVar * iDblSize/3;

  double *dbuf;
  if (iMsgSize)
  {
    dbuf = (double*)malloc(iMsgSize);
    memcpy(dbuf, vpBuf, iMsgSize);
  }

  // if (pSizeField->type()==2 || M_GetElementType(ent)!=VERTEX)
  int k=0;
  if (pSizeField->type() ==1)
  {
    double e[3][3], h[3];
    for (;k<3;k++)
      h[k]=dbuf[k];
    for (int i=0;i<3;++i)
      for (int j=0;j<3;++j)
        e[i][j]=dbuf[k++];

    pMSize pS = new MeshSize(e,h);
    pSizeField->setSize(pEnt,pS);
  }
   
  if(nVar) 
  {
    double *value = new double[nVar];
    for (int i=0;i<nVar;i++)
      value[i]=dbuf[k++];
#ifdef DEBUG
    double *nodalData;
    if(EN_getDataPtr(pEnt,SolutionID,(void **)&nodalData)) {
      printf("\nsolution already attached to vertex\n");
      exit(0);
    }
#endif
    EN_attachDataPtr(pEnt,SolutionID,(void *)value);
  }

  if (iMsgSize)
    free(dbuf);

  /// Get normal if the vertex is originating one
  int isOrgVtx = *(int*)((char*)vpBuf + iMsgSize);
  iMsgSize += iIntSize;
  if (isOrgVtx)
  {
    double *dNorm = (double*)((char*)vpBuf + iMsgSize);
    void *vVal;
    if (!EN_getDataPtr(pEnt, gcNormalTag, &vVal))
    {
      double *normalVector = new double[3];
      for (int iVal = 0; iVal < 3; ++iVal)
        normalVector[iVal] = dNorm[iVal];
      EN_attachDataPtr(pEnt, gcNormalTag, (void*)normalVector);
    }
    iMsgSize += iDblSize;
  }

  /// Get the number to identify how many tags attached to the vertex
  int iValForTotalNumTags = *(int*)((char*)vpBuf + iMsgSize);
  
  /// If an empty messages, i.e. no tags were attached
  if (!iValForTotalNumTags)
    return;

  iMsgSize += iIntSize;

  pMeshDataId pTag;
  double * dpVertPtr;
  int iCountValTag = 0;
  if (iValForTotalNumTags >= 10)
  {
    while(iCountValTag < iValForTotalNumTags)
    {
      pTag = *(pMeshDataId*)((char*)vpBuf + iMsgSize);
      iMsgSize += iTagSize;
    
      dpVertPtr = (double*)((char*)vpBuf + iMsgSize);
      double * dpVertAttachPtr = new double[3];
      for (int itPtr = 0; itPtr < 3; ++itPtr)
        dpVertAttachPtr[itPtr] = dpVertPtr[itPtr];      

      EN_attachDataPtr(pEnt, pTag, (void*)dpVertAttachPtr);
      iMsgSize += iDblSize;
      iCountValTag += 10;
    }

    /// Offset back from the last addition
    iValForTotalNumTags -= 10;
  }

  int ipIntVal;
  while(iCountValTag < iValForTotalNumTags)
  {
    pTag = *(pMeshDataId*)((char*)vpBuf + iMsgSize);
    iMsgSize += iTagSize;
  
    ipIntVal = *(int*)((char*)vpBuf + iMsgSize);
    EN_attachDataInt(pEnt, pTag, ipIntVal);
    iMsgSize += iIntSize;
    iCountValTag ++;
  }

  void *vpTargetPtr = NULL, *vpTopMovePtr = NULL;

  if (EN_getDataPtr(pEnt, topNodeMoveID, &vpTopMovePtr))
  {
    if (!EN_getDataPtr(pEnt, ptr_xyz, &vpTargetPtr))
    {
      double *target = new double[3];
      for(int iComp=0; iComp<3; iComp++)
        target[iComp] = ((double*)vpTopMovePtr)[iComp];
      EN_attachDataPtr((pEntity)pEnt, ptr_xyz, target);
    }
  }   

}


#endif /* MA_PARALLEL */
#endif /* AOMD */
