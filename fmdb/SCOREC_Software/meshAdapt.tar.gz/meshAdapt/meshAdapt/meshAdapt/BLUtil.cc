#include "mEntity.h"
#include "BLUtil.h"
#include "FMDB_cint.h"
#include "MeshTools.h"

pMeshDataId blVertexTypeID, blEdgeTypeID, blFaceTypeID, blRegionTypeID, layerNumberID, remLayerNumberID;
pMeshDataId gcNormalTag;
pMeshDataId cornerONodeID;

extern int IsLowerLimitOnTotalThickness;

/// For debugging
#include "ParUtil.h"
//#include <map>
//using namespace std;


pBLIter Mesh_GetBegBLIter(pMesh pMeshMesh)
{
  return M_beginEntGrp(pMeshMesh);
}

pBLIter Mesh_GetEndBLIter(pMesh pMeshMesh)
{
  return M_endEntGrp(pMeshMesh);
}

pBLEntIter BL_GetBegEntIter(pBLayer pBLayerBL)
{
  return EG_beginEntity(pBLayerBL);
}

pBLEntIter BL_GetEndEntIter(pBLayer pBLayerBL)
{
  return EG_endEntity(pBLayerBL);
}


int EN_isBLEntity(pEntity ent)
{
  int iEntType;
  FMDB_Ent_GetType(ent, &iEntType);
  switch (iEntType) 
  {
    case 0:
      return V_typeInBL((pVertex)ent);
//    break;
    case 1:
      return E_typeInBL((pEdge)ent);
//    break;
    case 2:
      return F_typeInBL((pFace)ent);
//    break;
    case 3:
//      return R_isBLEntity((pRegion)ent);
      return R_typeInBL((pRegion)ent);
//    break;
  }
}



int EN_levelInBL(pEntity ent) 
{
  int level;

  if(EN_getDataInt(ent,layerNumberID,&level))
    return level;

  return -99;
}

int EN_remLevelInBL(pEntity ent)
{
  int level;

  if(EN_getDataInt(ent,remLayerNumberID,&level))
    return level;

  return -199;
}

pBLayer EN_getBL(pEntity ent)
{
  int ent_level = ent->getLevel();
  pBLayer pbl;
  if (ent_level < 3)
  {
    if (ent_level < 2)
    {
      printf("Warning: entity of dimention %d can not be associated with any BL\n");
      return 0;
    }
    else
    {
      int f_type = F_typeInBL(ent);
      if (f_type == fVERTICAL_TRI || f_type == fVERTICAL_QUAD)
      {
        printf("Warning: vertical face can not be associated with any BL\n");
        return 0;
      }

      pRegion pReg;
      for (int itReg = 0; itReg < F_numRegions((pFace)ent); ++itReg)
      {
        pReg = F_region((pFace)ent, itReg);
        if (EN_isInEntGrp((pEntity)pReg, pbl))
          return pbl;
      }
      return 0;
    }
  }
  else if (EN_isInEntGrp(ent, pbl))
    return pbl;
  return 0;
}


void EN_mergeBLInfo(pEntity entTo, pEntity entFrom) 
{
/*
  if(!EN_isBLEntity(entFrom)) {
    cout<<"\nError in EN_mergeBLInfo()..."<<endl;
    cout<<"entFrom is NOT a BL entity"<<endl;
    exit(0);
  }

  int entToType = EN_type(entTo);
  int entFromType = EN_type(entFrom);
  if(entToType!=entFromType) {
    cout<<"\nError in EN_mergeBLInfo()..."<<endl;
    cout<<"entFrom ["<<entFromType<<"] is NOT of same type as entTo ["<<entToType<<"]"<<endl;
    exit(0);
  }
*/

  int modify = 0;
//  if(EN_isBLEntity(entTo))
//    modify = 1;

  int level, entTypeInBL;
//  EN_getDataInt(entFrom,blEntityID,&surfTag);
  EN_getDataInt(entFrom,layerNumberID,&level);

  pMeshDataId entTypeInBLId = 0;
  switch (entFrom->getLevel()) {
  case 0:
    if(level==0) {
      cout<<"\nError in EN_mergeBLInfo()..."<<endl;
      cout<<"cannot handle originating node as of now"<<endl;
      exit(0);
    }
    entTypeInBLId = blVertexTypeID;
    if(V_typeInBL(entTo))
      modify = 1;
    break;
  case 1:
    entTypeInBLId = blEdgeTypeID;
    if(E_typeInBL(entTo))
      modify = 1;
    break;
  case 2:
    entTypeInBLId = blFaceTypeID;
    if(F_typeInBL(entTo))
      modify = 1;
    break;
  case 3:
    entTypeInBLId = blRegionTypeID;
    if(R_isBLEntity(entTo))
      modify = 1;
    break;
  }
  if(entTypeInBLId)
    EN_getDataInt(entFrom,entTypeInBLId,&entTypeInBL);

  if(modify) {
//    EN_modifyDataInt(entTo,blEntityID,surfTag);
    EN_modifyDataInt(entTo,layerNumberID,level);
    if(entTypeInBLId)
      EN_modifyDataInt(entTo,entTypeInBLId,entTypeInBL);
  }
  else {
//    EN_attachDataInt(entTo,blEntityID,surfTag);
    EN_attachDataInt(entTo,layerNumberID,level);
    if(entTypeInBLId)
      EN_attachDataInt(entTo,entTypeInBLId,entTypeInBL);
  }

}


void EN_labelBLEntity(pEntity ent, int level, int entTypeInBL) 
{
  pMeshDataId entTypeInBLId;
  switch (ent->getLevel()) {
  case 0:
    // originating node
    if(level==0) {
//       pVertex vertex = (pVertex)ent, otherVertex;
//       int numEdges = V_numEdges((pVertex)ent);
//       int maxTotLayers = 0, otherTotLayers;
//       for(int iEdge=0; iEdge<numEdges; iEdge++) {
//      otherVertex = E_otherVertex(V_edge(vertex,iEdge),vertex);
//      otherTotLayers = V_totNumLayers(otherVertex);
//      if(maxTotLayers<otherTotLayers)
//        maxTotLayers=otherTotLayers;
//       }

      EN_attachDataInt(ent,blVertexTypeID,vORIGINATING);
      // EN_attachDataInt(ent,totNumLayersID,maxTotLayers);
//      EN_attachDataInt(ent,totNumGCsID,1);

//       if(numEdges!=2) {
//      cout<<"\nError in EN_labelBLEntity()..."<<endl;
//      cout<<"assuming vertex to be a newly created by edge split"<<endl;
//      cout<<numEdges<<" edges around the vertex (must be 2)"<<endl;
//      exit(0);
//       }
    }
    else
      EN_attachDataInt(ent,blVertexTypeID,vREGULAR);
    // no type for boundary layer vertex
    entTypeInBLId = blVertexTypeID;
    break;
  case 1:
    entTypeInBLId = blEdgeTypeID;
    break;
  case 2:
    entTypeInBLId = blFaceTypeID;
    break;
  case 3:
    entTypeInBLId = blRegionTypeID;
    break;
  }

  int checkLabelBL;
//  if(!EN_getDataInt(ent,blEntityID,&checkLabelBL)) {
  if (!EN_getDataInt(ent,layerNumberID,&checkLabelBL))
    EN_attachDataInt(ent,layerNumberID,level);
//    EN_attachDataInt(ent,blEntityID,surfTag);
  if(!EN_getDataInt(ent,entTypeInBLId,&checkLabelBL))
    EN_attachDataInt(ent,entTypeInBLId,entTypeInBL);
//  }
//  else {
//    cout<<"\n WARNING : <ent> is already labeled (see EN_labelBLEntity(...))\n"<<endl;
//  }
}


void EN_unlabelBLEntity(pEntity ent) 
{
  int data;
  pMeshDataId entTypeInBLId;
//  if(EN_getDataInt(ent,blEntityID,&data)) {
//    EN_deleteData(ent,blEntityID);
  if (EN_getDataInt(ent,layerNumberID,&data))
    EN_deleteData(ent,layerNumberID);

    switch (ent->getLevel()) {
    case 0:
//      if(EN_getDataInt(ent,totNumLayersID,&data))
//        EN_deleteData(ent,totNumLayersID);
//      if(EN_getDataInt(ent,totNumGCsID,&data))
//        EN_deleteData(ent,totNumGCsID);
      entTypeInBLId = blVertexTypeID;
      break;
    case 1:
      entTypeInBLId = blEdgeTypeID;
      break;
    case 2:
      entTypeInBLId = blFaceTypeID;
      break;
    case 3:
      entTypeInBLId = blRegionTypeID;
      break;
    }
  
  if(EN_getDataInt(ent,entTypeInBLId,&data))
    EN_deleteData(ent,entTypeInBLId);

//  }
}


void EN_unlabelBLEntAndDownAdjEnts(pEntity pEntityEnt)
{
  int iEntDim = pEntityEnt->getLevel();
  std::vector<pEntity> VecAdj;  
  if (iEntDim < 3)
  {
    FMDB_Ent_GetAdj(pEntityEnt, iEntDim+1, 1, VecAdj);
    for (int iEnt = 0; iEnt < VecAdj.size(); ++iEnt)
    {
      if (EN_isBLEntity(VecAdj[iEnt]))
        return;
    }
    EN_unlabelBLEntity(pEntityEnt);
  }
  else
    EN_unlabelBLEntity(pEntityEnt);

  VecAdj.clear();
  if (iEntDim == 0)
    return;

  FMDB_Ent_GetAdj(pEntityEnt, iEntDim-1, 1, VecAdj);
  for (int iEnt = 0; iEnt < VecAdj.size(); ++iEnt)
    EN_unlabelBLEntAndDownAdjEnts(VecAdj[iEnt]);
}


void Ent_ClrBLEntLvl(pEntity pEntityEnt)
{
  int data;
  if (EN_getDataInt(pEntityEnt, layerNumberID, &data))
    EN_deleteData(pEntityEnt, layerNumberID);
}


int EN_allBLNodes(pEntity ent) 
{
  int numNodes;
  pPList nodes;

  switch(EN_type(ent)) {
  case Tvertex :
    if(!V_typeInBL(ent))
      return 0;
    break;
  case Tedge :
    for(int iNode=0; iNode<2; iNode++)
      if(!V_typeInBL((pEntity)E_vertex((pEdge)ent,iNode)))
        return 0;
    break;
  case Tface :
    nodes = F_vertices((pFace)ent,0);
    numNodes = PList_size(nodes);
    for(int iNode=0; iNode<numNodes; iNode++)
      if(!V_typeInBL((pEntity)PList_item(nodes,iNode))) {
        PList_delete(nodes);
        return 0;
      }
    PList_delete(nodes);
    break;
  case Tregion :
    nodes = R_vertices((pRegion)ent,0);
    numNodes = PList_size(nodes);
    for(int iNode=0; iNode<numNodes; iNode++)
      if(!V_typeInBL((pEntity)PList_item(nodes,iNode))) {
        PList_delete(nodes);
        return 0;
      }
    PList_delete(nodes);
    break;
  }

  return 1;
}


// do NOT use any BL info. (can be used for a general mesh)
int EN_isPointInside(pEntity entity, double *xyz) {

  int entType = EN_type(entity);
  switch(entType) {
  case Tface :
    return F_isPointInside((pFace)entity,xyz);
  case Tregion :
    return R_isPointInside((pRegion)entity,xyz);
  case Tvertex :
  case Tedge :
  default:
    cout<<"\nError in EN_isPointInside()..."<<endl;
    cout<<"entType ["<<entType<<"] NOT supported as of now\n"<<endl;
    exit(0);
  }

}


// return 0 if NOT a boundary layer vertex
int V_typeInBL(pVertex vertex) 
{
  int data;
  if(EN_getDataInt((pEntity)vertex, blVertexTypeID, &data))
    return data;

  return 0;
}


int V_isOriginatingNode(pVertex vertex) 
{
  if (V_typeInBL(vertex) == vORIGINATING)
    return 1;

  return 0;
}


pVertex V_getOriginatingNode(pVertex vertex)
{
  if (V_isOriginatingNode(vertex))
    return vertex;

  pEdge edge;
  while(!V_isOriginatingNode(vertex))
  {
    edge = V_growthEdge(vertex,-1);
    vertex = E_otherVertex(edge,vertex);
  }
  return vertex;
}


void V_setCornerONode(pVertex vertex)
{ 
  if(!V_isOriginatingNode(vertex)) {
    cout<<"\nError in V_setCornerONode()..."<<endl;
    cout<<"vertex is NOT an originating node"<<endl;
    exit(0);
  }  
 
  int data;
  if(!EN_getDataInt((pEntity)vertex,cornerONodeID,&data))
    EN_attachDataInt((pEntity)vertex,cornerONodeID,1);
  else
  { 
    cout<<"\n WARNING in V_setCornerONode()..."<<endl;
    cout<<" vertex is already tagged\n"<<endl;
  }   
}       
        
        
int V_isCornerONode(pVertex vertex)
{     
  int data;
  if(EN_getDataInt((pEntity)vertex,cornerONodeID,&data))
    return 1;
 
  return 0;
}


void V_layerEdges(pVertex vertex, vector<pEdge>& layerEdges)
{
  layerEdges.clear();
  pEdge edge;
  int numEdges = V_numEdges(vertex);
  for(int iEdge=0; iEdge<numEdges; iEdge++) {
    edge = V_edge(vertex,iEdge);
    if(E_typeInBL(edge)==eLAYER)
      layerEdges.push_back(edge);
  }
}


void V_layerFaces(pVertex vertex, vector<pFace>& lyrFcs) 
{
  lyrFcs.clear();
  pFace face;
  pPList faces = V_faces(vertex);
  int numFaces = PList_size(faces);
  for(int iFace=0; iFace<numFaces; iFace++) 
  {
    face = (pFace)PList_item(faces,iFace);
    if(F_typeInBL(face)==fLAYER)
      lyrFcs.push_back(face);
  }
  PList_delete(faces);
}


void V_layerAndTransitionFaces(pVertex vertex, vector<pFace>& lyrFcs)
{
  lyrFcs.clear();
  pFace face;
  pPList faces = V_faces(vertex);
  int numFaces = PList_size(faces);
  int f_type;
  for(int iFace=0; iFace<numFaces; iFace++) 
  {
    face = (pFace)PList_item(faces,iFace);
    f_type = F_typeInBL(face);
    if(f_type == fLAYER || f_type == fTRANSITION)
      lyrFcs.push_back(face);
  }
  PList_delete(faces);
}


void V_layerAndTransitionFaces(pVertex vertex, int level, vector<pFace>& lyrFcs)
{
  lyrFcs.clear();
  int ftype;
  pFace face;
  pPList faces = V_faces(vertex);
  int numFaces = PList_size(faces);
  for(int iFace=0; iFace<numFaces; iFace++) 
  {
    face = (pFace)PList_item(faces,iFace);
    ftype = F_typeInBL(face);
    if( EN_levelInBL(face)==level && (ftype==fLAYER || ftype==fTRANSITION) )
      lyrFcs.push_back(face);
  }
  PList_delete(faces);
}


void V_BLRegions(pVertex vertex, int level, vector<pRegion>& BLRegs) 
{
  BLRegs.clear();
  pRegion region;
  pPList vregs = V_regions(vertex);
  int numRegions = PList_size(vregs);
  for(int iRgn=0; iRgn<numRegions; iRgn++) {
    region=(pRegion)PList_item(vregs,iRgn);
    if(EN_levelInBL((pEntity)region)==level)
      BLRegs.push_back(region);
  }
  PList_delete(vregs);
}


void V_BLRegions(pVertex vertex, vector<pRegion>& BLRegs)
{
  BLRegs.clear();
  pRegion region;
  pPList vregs = V_regions(vertex);
  int numRegions = PList_size(vregs);
  for(int iRgn=0; iRgn<numRegions; iRgn++) {
    region=(pRegion)PList_item(vregs,iRgn);
    if(R_isBLEntity((pEntity)region))
      BLRegs.push_back(region);
  }
  PList_delete(vregs);
}


void V_nonBLRegions(pVertex vertex, vector<pRegion>& nonBLRegs)
{
  nonBLRegs.clear();

  pRegion region;
  pPList vregs = V_regions(vertex);
  int numRegions = PList_size(vregs);
  for(int iRgn=0; iRgn<numRegions; iRgn++) {
    region=(pRegion)PList_item(vregs,iRgn);
    if(!R_isBLEntity((pEntity)region))
      nonBLRegs.push_back(region);
  }
  PList_delete(vregs);
/*
  // possible if vertex is not at BL interface
  // (OR vertex must be at BL interface -> must put a check in this case)
  if(PList_size(nonBLRegs)==0) {
    if(isBLEntity && !V_atBLInterface(vertex)) {
      cout<<"\n WARNING in V_nonBLRegions()..."<<endl;
      cout<<" vertex in NOT at BL interface\n"<<endl;
    }
  }
*/
}


void V_excludeLevelBLRegions(pVertex vertex, vector<pRegion>& noLevelBLRegs)
{
  int level = EN_levelInBL(vertex);
  noLevelBLRegs.clear();

  pRegion region;
  pPList vregs = V_regions(vertex);
  int numRegions = PList_size(vregs);
  for(int iRgn=0; iRgn<numRegions; iRgn++) {
    region=(pRegion)PList_item(vregs,iRgn);
    if(level>0 && EN_isBLEntity((pEntity)region) && EN_levelInBL((pEntity)region)==level)
      continue;
    noLevelBLRegs.push_back(region);
  }
  PList_delete(vregs);
/*
  if(noLevelBLRegsize()== 0) {
    cout<<"\n WARNING in V_excludeLevelBLRegions()..."<<endl;
    cout<<" regions list is EMPTY\n"<<endl;
  }
*/
}


void V_edgesAtBLInterface(pVertex vertex, vector<pEdge>& edgesBLIntfc) 
{
  edgesBLIntfc.clear();
  int eTypeInBL;
  pEdge edge;
  int numEdges = V_numEdges(vertex);
  for(int iEdge=0; iEdge<numEdges; iEdge++) {
    edge = V_edge(vertex,iEdge);
    eTypeInBL = E_typeInBL(edge);
    if((eTypeInBL==eLAYER || eTypeInBL==eTRANSITION) && E_atBLInterface(edge))
      edgesBLIntfc.push_back(edge);
  }
}


void V_facesAtBLInterface(pVertex vertex, vector<pFace>& facesBLIntfc) 
{
  facesBLIntfc.clear();
  int fTypeInBL;
  pFace face;
  pPList faces = V_faces(vertex);
  int numFaces = PList_size(faces);
  for(int iFace=0; iFace<numFaces; iFace++) {
    face = (pFace)PList_item(faces,iFace);
    fTypeInBL = F_typeInBL(face);
    if((fTypeInBL==fLAYER || fTypeInBL==fTRANSITION) && F_atBLInterface(face))
      facesBLIntfc.push_back(face);
  }
  PList_delete(faces);
}


// vertex is at BL interface if it bounds atleast one non-BL region
// (possible to have NO non-BL edge, i.e., all BL edges, connected to vertex)
int V_atBLInterface(pVertex vertex) {

  if(!EN_isBLEntity((pEntity)vertex))
    return -1;

//   int numEdges = V_numEdges(vertex);
//   for(int iEdge=0; iEdge<numEdges; iEdge++) {
//     if(!EN_isBLEntity((pEntity)V_edge(vertex,iEdge)))
//       return 1;
//   }

  pPList vregs = V_regions(vertex);
  int numRegs = PList_size(vregs);
  for(int iRgn=0; iRgn<numRegs; iRgn++) {
    if(!EN_isBLEntity((pEntity)PList_item(vregs,iRgn))) {
      PList_delete(vregs);
      return 1;
    }
  }
  PList_delete(vregs);

  return 0;
}


// dir is to decide lower or upper level growth edge
pEdge V_growthEdge(pVertex vertex, int dir) 
{
  if(!(dir==-1 || dir==1)) {
    cout<<"\nError in V_growthEdge()..."<<endl;
    cout<<"specify correct dir, i.e., -1 or 1 [specified dir="<<dir<<"]"<<endl;
    exit(0);
  }

  if(V_isOriginatingNode(vertex) && dir==-1) {
    cout<<"\nError in V_growthEdge()..."<<endl;
    cout<<"downward growth edge requested at originating node"<<endl;
    exit(0);
  }

  int level = EN_levelInBL((pEntity)vertex);

  int elevel, maxlevel = 0;
  pEdge edge;
  int numEdges = V_numEdges(vertex);
  for(int iEdge=0; iEdge<numEdges; iEdge++) {
    edge = V_edge(vertex,iEdge);
    if(E_typeInBL(edge)==eGROWTH) {
      elevel = EN_levelInBL((pEntity)edge);

      if(maxlevel<elevel)
        maxlevel = elevel;

      if(dir==-1 && elevel==level)
//      if(dir==-1 && elevel==level-1)
        return edge;
      if(dir==1 && elevel==level+1)
//      if(dir==1 && elevel==level)
        return edge;
    }
  }

  if(!maxlevel)
  {
#ifdef DEBUG
    cout<<"NO growth edge found, vertex level = "<<level<<endl; 
#endif
    return 0;
  }

  double xyz[3];
  V_coord(vertex, xyz);
  cout<<"\nError in V_growthEdge()... on PID "<<P_pid()<<endl;
  printf("Coords are: %f %f %f\n",xyz[0],xyz[1],xyz[2]);
  if(dir==1 && maxlevel==level)
    cout<<"upward growth edge requested for top most (terminating) node"<<endl;
//  exit(0);
}


void V_nonBLFacesOnBLSurfaces(pVertex vertex, vector<pFace>& nonBLFacesOnBLSurfaces) 
{
  nonBLFacesOnBLSurfaces.clear();
  pFace face;
  pGEntity gent;
  pPList faces = V_faces(vertex);
  int numFaces = PList_size(faces);
  for(int iFace=0; iFace<numFaces; iFace++) {
    face = (pFace)PList_item(faces,iFace);

    if( F_typeInBL((pEntity)face) ||
        F_whatInType(face)!=Gface )
      continue;

///NEED REVISION!
//    gent = F_whatIn(face);
//    if(GEN_isBLSurface(gent))
    if (F_whatInType(face) == 2)
      nonBLFacesOnBLSurfaces.push_back(face);
  }
  PList_delete(faces);
}


void V_getAdjacentOrigVerts(pVertex vertex, vector<pVertex>& adjOrigVerts)
{
  pVertex opp_vtx;
  pEdge edge;
  adjOrigVerts.clear();
  int numEdges = V_numEdges(vertex);

  for (int iEdge = 0; iEdge < numEdges; ++iEdge)
  {
    edge = V_edge(vertex, iEdge);
    if (EN_levelInBL(edge) == 0)
    {
      opp_vtx = E_otherVertex(edge, vertex);
      adjOrigVerts.push_back(opp_vtx);
    }
  }
}


// get the value of lower limit on total thickness of boundary layer
// (at this "vtx")
double V_getLowerLimitOnTotThickness(pVertex vtx) {
  double value, xyz[3];

  switch(IsLowerLimitOnTotalThickness) {
  case 1 :
   V_coord(vtx,xyz);
   value = 0.0327*pow(xyz[0],6./7.);
   value = 1.1*value;
   break;
  case 2 :
    value = 1.1*0.011;
    break;
 default :
   value = 0.;
  }

  return value;
}


// return 0 if NOT a boundary layer edge
int E_typeInBL(pEdge edge) {
  int data;
  if(EN_getDataInt((pEntity)edge, blEdgeTypeID, &data))
    return data;

  return 0;
}


// DOES NOT use any BL mesh info. (can be used for a general mesh)
pFace E_commonFace(pEdge edge1, pEdge edge2) 
{
  pFace face1,face2;
  int numFaces1 = E_numFaces(edge1);
  int numFaces2 = E_numFaces(edge2);
  for(int iFace1=0; iFace1<numFaces1; iFace1++) {
    face1 = E_face(edge1,iFace1);
    for(int iFace2=0; iFace2<numFaces2; iFace2++) {
      face2 = E_face(edge2,iFace2);
      if(face1==face2) {
        return face1;
      }
    }
  }

  return 0;
}


// edge is at BL interface if it bounds atleast one non-BL face
int E_atBLInterface(pEdge edge) 
{
//  int iEdgeTypeInBL = E_typeInBL(edge);
//  if (!(iEdgeTypeInBL == eLAYER || iEdgeTypeInBL == eTRANSITION))  
//    return 0;

  pRegion region;
  pPList eregs = E_regions(edge);
  int numRegions = PList_size(eregs);
  for(int iRgn=0; iRgn<numRegions; iRgn++) {
    region = (pRegion)PList_item(eregs,iRgn);
    if(!R_isBLEntity(region)) {
      PList_delete(eregs);
      return 1;
    }
  }
  PList_delete(eregs);

  int numFaces = E_numFaces(edge);
  int iFaceTypeInBL;
  for(int iFace=0; iFace<numFaces; iFace++) 
  {
    iFaceTypeInBL = F_typeInBL(E_face(edge,iFace));
    if(!iFaceTypeInBL)
      return 1;
  }
/*
  if (EN_onCB(edge))
  {
    if (EN_levelInBL(edge) >= 0)
      return 1;
  }
*/
  return 0;
}


void E_BLRegions(pEdge edge, int level, vector<pRegion>& BLRegs)
{
  BLRegs.clear();
  pRegion region;
  pPList eregs = E_regions(edge);
  int numRegions = PList_size(eregs);
  for(int iRgn=0; iRgn<numRegions; iRgn++) {
    region=(pRegion)PList_item(eregs,iRgn);
    if(EN_levelInBL((pEntity)region)==level)
      BLRegs.push_back(region);
  }
  PList_delete(eregs);
}


void E_BLRegions(pEdge edge, vector<pRegion>& BLRegs)
{
  BLRegs.clear();
  pRegion region;
  pPList eregs = E_regions(edge);
  int numRegions = PList_size(eregs);
  for(int iRgn=0; iRgn<numRegions; iRgn++) {
    region=(pRegion)PList_item(eregs,iRgn);
    if(R_isBLEntity((pEntity)region))
      BLRegs.push_back(region);
  }
  PList_delete(eregs);
}


void E_layerAndTransitionFaces(pEdge edge, int level, vector<pFace>& lyrFcs)
{
  lyrFcs.clear();
  int ftype;
  pFace face;
  int numFaces = E_numFaces(edge);
  for(int iFace=0; iFace<numFaces; iFace++)
  {
    face = E_face(edge, iFace);
    ftype = F_typeInBL(face);
    if( EN_levelInBL(face)==level && (ftype==fLAYER || ftype==fTRANSITION) )
      lyrFcs.push_back(face);
  }
}


void E_facesAtBLInterface(pEdge edge, vector<pFace>& blInterfaceFaces) 
{
  blInterfaceFaces.clear();
  int etype = E_typeInBL(edge);
  if( !(etype==eLAYER ||
        etype==eTRANSITION) ) {
    cout<<"\nError in E_facesAtBLInterface()..."<<endl;
    cout<<"edge is NOT a layer or transition edge"<<endl;
    exit(0);
  }

  pFace face;
  // only if edge is at BL interface
  if(E_atBLInterface(edge)) {
    int numFaces = E_numFaces(edge);
    for(int iFace=0; iFace<numFaces; iFace++) {
      face = E_face(edge,iFace);
      if(!EN_isBLEntity((pEntity)face))
        continue;
      if(F_atBLInterface(face))
        blInterfaceFaces.push_back(face);
    }
  }

  int size = blInterfaceFaces.size();
  if(size<0 || size>2) {
    cout<<"\n WARNING in E_facesAtBLInterface()..."<<endl;
    cout<<" list size of ["<<size<<"] is found for faces at BL interface\n"<<endl;
  }
}


// edge must be a layer/transition edge
// dir is to decide lower or upper level vertical face
// -1:lower and 1:upper
pFace E_verticalFace(pEdge edge, int dir) 
{
  if(!(dir==-1 || dir==1)) {
    cout<<"\nError in E_verticalFace()..."<<endl;
    cout<<"specify correct dir, i.e., -1 or 1 [specified dir="<<dir<<"]"<<endl;
    exit(0);
  }

  int etype = E_typeInBL(edge);
  if(!(etype==eLAYER || etype==eTRANSITION)) {
    cout<<"\nError in E_verticalFace()..."<<endl;
    cout<<"edge is NOT a layer or transition edge"<<endl;
    exit(0);
  }

  int level = EN_levelInBL((pEntity)edge);
  if(level==0 && dir==-1) {
    cout<<"\nError in E_verticalFace()..."<<endl;
    cout<<"lower level vertical face requested for zero level edge"<<endl;
    exit(0);
  }

  int ftype, flevel;
  pFace face;
  int numFaces = E_numFaces(edge);
  for(int iFace=0; iFace<numFaces; iFace++) {
    face = E_face(edge,iFace);

    ftype = F_typeInBL(face);
    if( ftype==fVERTICAL_TRI ||
        ftype==fVERTICAL_QUAD ) {

      flevel = EN_levelInBL((pEntity)face);
      if(dir==1 && flevel==level+1)
        return face;
      else if(dir==-1 && flevel==level)
        return face;
    }
  }

  cout<<"\nError in E_verticalFace()..."<<endl;
  cout<<"seems upper vertical face requested for top layer/transition edge"<<endl;
  exit(0);
}


// by default sameSurface and transition is 1
void E_layerFaces(pEdge edge, vector<pFace> &layerFaces, int transition, int sameSurface) 
{
  layerFaces.clear();
  int etype = E_typeInBL(edge);
  if( !(etype==eLAYER ||
        (transition && etype==eTRANSITION)) ) {
    cout<<"\nError in E_layerFaces()..."<<endl;
    cout<<"edge is NOT a layer edge"<<endl;
    if(transition)
      cout<<"edge is NOT a transition edge either"<<endl;

    exit(0);
  }

  if(!sameSurface) {
    cout<<"\nError in E_layerFaces()..."<<endl;
    cout<<"layer edge is at corner (sameSurface="<<sameSurface<<")"<<endl;
    exit(0);
  }

  pFace face;
  int numFaces = E_numFaces(edge);
  for(int iFace=0; iFace<numFaces; iFace++) {
    face = E_face(edge,iFace);
    if( F_typeInBL(face)==fLAYER ||
        (transition && F_typeInBL(face)==fTRANSITION) )
      layerFaces.push_back(face);
  }

/*
  int size = layerFaces.size();
  // even in cases with transition elements max. list size is 2
  if(size<0 || size>2) {
    cout<<"\n WARNING in E_layerFaces()..."<<endl;
    cout<<" list size of ["<<size<<"] is found for layer faces \n"<<endl;
  }
*/
}


void E_nonBLRegions(pEdge edge, vector<pRegion>& nonBLRegs) 
{
//  int isBLEntity = E_isBLEntity((pEntity)edge);
//   if(!isBLEntity) {
//     cout<<"\n WARNING in E_nonBLRegions()..."<<endl;
//     cout<<" edge in NOT a BL entity\n"<<endl;
//   }

  nonBLRegs.clear();
  pRegion region;
  pPList eregs = E_regions(edge);
  int numRegions = PList_size(eregs);
  for(int iRgn=0; iRgn<numRegions; iRgn++) {
    region = (pRegion)PList_item(eregs,iRgn);
    if(!R_isBLEntity(region))
      nonBLRegs.push_back(region);
  }
  PList_delete(eregs);

/*
  // possible if edge is not at BL interface
  // (OR edge must be at BL interface -> must put a check in this case)
  if(PList_size(nonBLRegs)==0) {
    if(isBLEntity && !E_atBLInterface(edge)) {
      cout<<"\n WARNING in E_nonBLRegions()..."<<endl;
      cout<<" edge in NOT at BL interface\n"<<endl;
    }
  }
*/
}


// only modify type from/to layer and transition edge
void E_correctTypeAndLevelInBL(pEdge edge) 
{
  if (E_whatInType(edge) < 3)
    return;
/*
  if(!E_typeInBL(edge)) {
    cout<<"\nError in E_correctTypeInBL"<<endl;
    cout<<"edge is NOT a BL edge"<<endl;
    exit(0);
  }

  if(!EN_allBLNodes((pEntity)edge)) {
    cout<<"\nError in E_correctTypeInBL"<<endl;
    cout<<"edge do NOT have all BL nodes"<<endl;
    exit(0);
  }
*/

  int eTypeInBL = E_typeInBL(edge);
  if(eTypeInBL==eGROWTH) {
    cout<<"\nError in E_correctTypeInBL"<<endl;
    cout<<"edge is a growth edge"<<endl;
    exit(0);
  }

  int eLevel = 0;
  int ev_levels[2] = {0,0};
  // edge with all BL nodes
  for(int iVert=0; iVert<2; iVert++) {
    ev_levels[iVert] = EN_levelInBL((pEntity)E_vertex(edge,iVert));
    if(eLevel<ev_levels[iVert])
      eLevel = ev_levels[iVert];
  }

  if(ev_levels[0]==ev_levels[1])
    eTypeInBL = eLAYER;
  else
    eTypeInBL = eTRANSITION;

  EN_modifyDataInt((pEntity)edge,blEdgeTypeID,eTypeInBL);
  EN_modifyDataInt((pEntity)edge,layerNumberID,eLevel);
}


// return 0 if NOT a boundary layer face
int F_typeInBL(pFace face) {
  int data;
  if(EN_getDataInt((pEntity)face, blFaceTypeID, &data))
    return data;

  return 0;
}


// side contains which region is non-BL entity
int F_atBLInterface(pFace face, int *side) 
{
  if( !(F_typeInBL(face)==fLAYER || F_typeInBL(face)==fTRANSITION) )
    return 0;
/*
  pBLayer pbl = EN_getBL(face);
  int bl_size = pbl->size();
  if (EN_levelInBL(face) == bl_size)
    return 1;

  return 0;
*/

  if (EN_onCB(face))
  {
    if (EN_getBL(face))
      return 1;
    else
      return 0;
  }

  pRegion rgns[2];
  rgns[0] = F_region(face,0);
  rgns[1] = F_region(face,1);

  if(F_whatInType(face)==Gface) {
    int n=0, whichOne;
    // take care of non-manifold model
    for(int iRgn=0; iRgn<2; iRgn++) {
      if(rgns[iRgn]) {
        n++;
        whichOne=iRgn;
      }
    }

    if(n==2) {
      cout<<"\nError in F_atBLInterface()..."<<endl;
      cout<<"face classified on non-manif. model face\n"<<endl;
      exit(0);
    }

    if(R_isBLEntity(rgns[whichOne])) {
      if(side)
        *side=-1;
      return 0;
    }
    else {
      if(side)
        *side=whichOne;
      return 1;
    }
  }
  else {
    int isRgnBL[2] = {0,0};
    if(R_isBLEntity(rgns[0]))
      isRgnBL[0] = 1;
    if(R_isBLEntity(rgns[1]))
      isRgnBL[1] = 1;

    if(isRgnBL[0] && isRgnBL[1]) {
      if(side)
        *side=-1;
      return 0;
    }

    if(side) {
      *side = 2;
      for(int iRgn=0; iRgn<2; iRgn++) {
        if(isRgnBL[iRgn])
          *side -= 1+iRgn;
      }
    }

    return 1;
  }
  return 0;

}


// do NOT use any BL info. (can be used for a general mesh)
pRegion F_otherRegion(pFace face, pRegion region) {

  if(!R_inClosure(region,(pEntity)face)) {
    cout<<"\nError in F_otherRegion()..."<<endl;
    cout<<"face is NOT in closure of region"<<endl;
    exit(0);
  }

  pRegion rgn = F_region(face,0);
  if(rgn==region)
    rgn=F_region(face,1);

  return rgn;
}


// do NOT use any BL info. (can be used for a general mesh)
pFace F_otherTriFcPrism(pFace face, pRegion region) {

  if(!R_inClosure(region,(pEntity)face)) {
    cout<<"\nError in F_otherTriFcPrism()..."<<endl;
    cout<<"face is NOT in closure of region"<<endl;
    exit(0);
  }

  if(region->getType()!=PRISM) {
    cout<<"\nError in F_otherTriFcPrism()..."<<endl;
    cout<<"region is NOT a prism/wedge"<<endl;
    exit(0);
  }

  if(F_numEdges(face)!=3) {
    cout<<"\nError in F_otherTriFcPrism()..."<<endl;
    cout<<"face is NOT a triangular face"<<endl;
    exit(0);
  }

//   if(R_numFaces(region)!=5)
//     return 0;

//   if(F_numEdges(face)!=3)
//     return 0;

  if(face==R_face(region,0))
    return R_face(region,4);
  else
    return R_face(region,0);
}


pFace F_otherTriFcPyramid(pFace face, pRegion region)
{
  if(!R_inClosure(region,(pEntity)face)) {
    cout<<"\nError in F_otherTriFcPyramid()..."<<endl;
    cout<<"face is NOT in closure of region"<<endl;
    exit(0);
  }

  if(region->getType()!=PYRAMID) {
    cout<<"\nError in F_otherTriFcPyramid()..."<<endl;
    cout<<"region is NOT a pyramid"<<endl;
    exit(0);
  }

  if(F_numEdges(face)!=3) {
    cout<<"\nError in F_otherTriFcPyramid()..."<<endl;
    cout<<"face is NOT a triangular face"<<endl;
    exit(0);
  }

  pEdge edges[3];
  for(int iEdge=0; iEdge<3; iEdge++)
    edges[iEdge] = F_edge(face,iEdge);

  int commonEdge;
  pFace fc;
  // iFace = 0 is the quad. face for pyramid
  for(int iFace=1; iFace<5; iFace++) {
    fc = R_face(region,iFace);
    if(fc==face)
      continue;

    commonEdge = 0;
    for(int iEdge=0; iEdge<3; iEdge++) {
      if(F_inClosure(fc,(pEntity)edges[iEdge])) {
        commonEdge = 1;
        break;
      }
    }

    if(!commonEdge)
      return fc;
  }

  return 0;
}


// only modify type from/to layer and transition face
void F_correctTypeAndLevelInBL(pFace face) 
{
  if (F_whatInType(face) < 3)
    return;
/*
  if(!E_typeInBL(face)) {
    cout<<"\nError in F_correctTypeInBL"<<endl;
    cout<<"face is NOT a BL face"<<endl;
    exit(0);
  }

  if(!EN_allBLNodes((pEntity)face)) {
    cout<<"\nError in F_correctTypeInBL"<<endl;
    cout<<"face do NOT have all BL nodes"<<endl;
    exit(0);
  }
*/
  int fTypeInBL = F_typeInBL(face);
  if(fTypeInBL==fVERTICAL_TRI || fTypeInBL==fVERTICAL_QUAD) {
    cout<<"\nError in F_correctTypeInBL"<<endl;
    cout<<"face is a vertical face [fTypeInBL="<<fTypeInBL<<"]"<<endl;
    exit(0);
  }

  int fLevel = 0;
  // edges of the face may be unlabled at this point
  // use nodes to determine BL face type
  int fv_levels[3] = {0,0,0};
  // face with all BL nodes
  pPList fverts = F_vertices(face,1);
  // must be triangle
  for(int iVert=0; iVert<3; iVert++) {
    fv_levels[iVert] = EN_levelInBL((pEntity)PList_item(fverts,iVert));
    if(fLevel<fv_levels[iVert])
      fLevel = fv_levels[iVert];
  }

  PList_delete(fverts);

  if(fv_levels[0]==fv_levels[1] && fv_levels[0]==fv_levels[2])
    fTypeInBL = fLAYER;
  else
    fTypeInBL = fTRANSITION;

  EN_modifyDataInt((pEntity)face,blFaceTypeID,fTypeInBL);
  EN_modifyDataInt((pEntity)face,layerNumberID,fLevel);
}


// check whether face swap is OK or not
// to avoid TWO2TWO case in face swap mode for non-BL faces
// connected to interface edges
int F_checkForTwo2TwoSwap(pFace face, pEdge edge) 
{
  if(EN_isBLEntity((pFace)face)) {
    cout<<"\nError in F_checkForTwo2TwoSwap()..."<<endl;
    cout<<"input face is a BL entity"<<endl;
    exit(0);
  }

  if(edge) {
     if(!(EN_isBLEntity((pEntity)edge) &&
          E_atBLInterface(edge))) {
       cout<<"\nError in F_checkForTwo2TwoSwap()..."<<endl;
       cout<<"input edge is NOT at BL interface"<<endl;
       exit(0);
     }
  }

  if(!edge) {
    pEdge edg;
    // assuming triangular topology for non-BL face
    for(int iEdge=0; iEdge<3; iEdge++) {
      edg = F_edge(face,iEdge);
      if( EN_isBLEntity((pEntity)edg) &&
          E_atBLInterface(edg) ) {
        if(!F_checkForTwo2TwoSwap(face,edg))
          return 0;
      }
    }

    return 1;
  }

  pFace interfaceFc, faces[2];
  pRegion nonBLRgn[2] = {0,0};
  vector<pFace> interfaceFcs;

  // int transition = 0;
  // if(E_typeInBL(edge)==eTRANSITION)
  //   transition = 1;
  // layerFcs = E_layerFaces(edge,transition);
  E_facesAtBLInterface(edge, interfaceFcs);
  if(interfaceFcs.size() != 2)
    return 1;

  for(int iFace=0; iFace<2; iFace++) {
    interfaceFc = interfaceFcs[iFace];
    faces[iFace] = interfaceFc;

    nonBLRgn[iFace] = F_region(interfaceFc,0);
    if( nonBLRgn[iFace] &&
        EN_isBLEntity((pEntity)nonBLRgn[iFace])) {
      nonBLRgn[iFace] = F_region(interfaceFc,1);
    if( nonBLRgn[iFace] &&
        EN_isBLEntity((pEntity)nonBLRgn[iFace]))
      nonBLRgn[iFace] = 0;
    }
  }

  if(nonBLRgn[0] && nonBLRgn[1]) {
    if( R_inClosure(nonBLRgn[0],(pEntity)face) &&
        R_inClosure(nonBLRgn[1],(pEntity)face) ) {

      double n[2][3];
      for(int iFace=0; iFace<2; iFace++) {
        F_normalVector(faces[iFace],
                       R_dirUsingFace(nonBLRgn[iFace],faces[iFace]),n[iFace]);
        normVt(n[iFace],n[iFace]);
      }

      double aci = dotProd(n[0],n[1]);
      double tol = M_getTolerance();

      if(C_raneql(aci,1.0,tol))
        return 0;
    }
  }

  return 1;
}


// do NOT use any BL info. (can be used for a general mesh)
// see combination : <return value> - <where point lies >
// 1 - purely inside face
// 2-v0, 3-v1, 4-v2
// 5-e0, 6-e1, 7-e2
int F_isPointInside(pFace face, double *xyz) 
{
  if(F_numEdges(face)!=3) {
    cout<<"\nError in F_isPointInside()..."<<endl;
    cout<<"face is NOT a triangle"<<endl;
    exit(0);
  }

  double fxyz[3][3];
  F_coord(face,fxyz);

  return XYZ_isPointInsideTriangle(fxyz,xyz);
}


int XYZ_isPointInside(dArray *X_Y_Z, double *xyz) {
  int value = 1;
  double mtol = M_getTolerance();
  double volume, sumVols = 0., subVolume;
  volume = XYZ_volume(X_Y_Z);

  // to avoid trouble due to tolerance value
  // (for example, subVolume=2.e-14 and mtol=1.e-14)
  // hence, using mtolVol, i.e., percentage of Vol
  // might be helpful than mtol, i.e., M_getTolerance()
  double mtolVol = 1.e-8*volume;

  double sub_xyz[4][3];
  for(int iComp=0; iComp<3; iComp++)
    sub_xyz[3][iComp] = xyz[iComp];

  int mapChildNode[4][3] = {0,1,2, 3,1,0, 3,2,1, 3,0,2};

  for(int iChild=0; iChild<4; iChild++) {
    // 4th node is the point to be checked
    for(int iNode=0; iNode<3; iNode++)
      for(int iDir=0; iDir<3; iDir++)
        sub_xyz[iNode][iDir] = X_Y_Z[mapChildNode[iChild][iNode]][iDir];

    subVolume = XYZ_volume(sub_xyz);

    if(fabs(subVolume)<mtolVol) {
      // value++;
      switch(XYZ_isPointInsideTriangle(sub_xyz,xyz)) {
      case 0 :
        return 0;
      case 1 : // purely inside face
        return 2;
      case 2 : // purely on vertex
      case 3 : // purely on vertex
      case 4 : // purely on vertex
        return 4;
      case 5 : // purely inside edge
      case 6 : // purely insde edge
      case 7 : // purely inside edge
        return 3;
      }
    }

    if(subVolume<0.0)
      return 0;

    sumVols += subVolume;
  }

  if(fabs(volume-sumVols)<mtolVol)
    return value;

  return 0;
}


// do NOT use any BL info. (can be used for a general mesh)
// see combination : <return value> - <where point lies >
// 1 - purely inside face
// 2-v0, 3-v1, 4-v2
// 5-e0, 6-e1, 7-e2
int XYZ_isPointInsideTriangle(double tri_xyz[3][3], double *xyz) 
{
  double mtol = M_getTolerance();
  double area, sumAreas = 0., subArea;

  for(int i=0; i<3; i++) {
    if(XYZ_distance2(tri_xyz[i],xyz)<mtol*mtol)
      return i+2;
  }

  double v[3][3];
  diffVt(tri_xyz[1],tri_xyz[0],v[0]);
  diffVt(tri_xyz[2],tri_xyz[1],v[1]);
  diffVt(tri_xyz[0],tri_xyz[2],v[2]);

  double normal[3];
  crossProd(v[0],v[1],normal);
  area = 0.5*sqrt(dotProd(normal,normal));
  double mtolArea = 1.e-8*area;

  int counter = 0;
  double temp[3], nor[3];
  for(int i=0; i<3; i++) {
    diffVt(xyz,tri_xyz[i],temp);
    crossProd(v[i],temp,nor);

    subArea = 0.5*sqrt(dotProd(nor,nor));
    // subArea is always positive
    if(subArea<mtolArea) {
      counter = i+1;
      continue;
    }

    // to avoid trouble due to tolerance value
    // (for example, subArea=2.e-14 and mtol=1.e-14)
    // hence, using mtolArea, i.e., percentage of area
    // might be helpful than mtol, i.e., M_getTolerance()
    if(dotProd(nor,normal)<0.)
      return 0;

    sumAreas += subArea;
  }

  if(fabs(area-sumAreas)<mtolArea) {
    if(counter)
      return 5+counter-1;

    return 1;
  }

  return 0;
}


// return 0 if NOT a boundary layer element
int R_typeInBL(pRegion region) {
  int data;
  if(EN_getDataInt((pEntity)region, blRegionTypeID, &data))
    return data;

  return 0;
}


int R_isBLEntity(pRegion ent)
{
//  pBLayer pbl;
//  return EN_isInEntGrp(ent, pbl);
  return R_typeInBL(ent);
}


// Region level in BL
int R_levelInBL(pRegion reg)
{
  pBLayer pbl = EN_getBL(reg);
  return pbl->getEntityOrder(reg);
}


// do NOT use any BL info. (can be used for a general mesh)
// if point lies inside return :
// 1 - purely inside region
// 2 - purely inside one of the face (for wedge could be diagonal face)
// 3 - purely inside one of the edge (for wedge could be diagonal edge)
// 4 - on one of the vertex
int R_isPointInside(pRegion region, double *xyz) 
{
  int topoType = region->getType();

  if(!(topoType==TET || topoType==PYRAMID || topoType==PRISM)) {
    cout<<"\nError in R_isPointInside()..."<<endl;
    cout<<"region is NOT a tet. or pyramid or wedge"<<endl;
    exit(0);
  }

  int value = 0;
  double X_Y_Z[4][3];
  pVertex vtx;
  if(topoType==TET) {
    pPList rverts = R_vertices(region,1);
    for(int iVtx=0; iVtx<4; iVtx++) {
      vtx = (pVertex)PList_item(rverts,iVtx);
      V_coord(vtx,X_Y_Z[iVtx]);
    }
    PList_delete(rverts);
    value = XYZ_isPointInside(X_Y_Z,xyz);
  }
  else if(topoType==PYRAMID) {
    // fit two tets in a pyramid
    // (diagonal edge of a pyramid is : V0-V2)
    int tetVerts[2][4] = {0,1,2,4, 0,2,3,4};

    pPList rverts = R_vertices(region,1);
    for(int iTet=0; iTet<2; iTet++) {
      for(int iVtx=0; iVtx<4; iVtx++) {
        vtx = (pVertex)PList_item(rverts,tetVerts[iTet][iVtx]);
        V_coord(vtx,X_Y_Z[iVtx]);
      }
      value = XYZ_isPointInside(X_Y_Z,xyz);
      if(value)
        break;
    }
    PList_delete(rverts);
  }
  else if(topoType==PRISM) {
    // fit three tets in a prism/wedge
    // (diagonal edges of a prism are : V0-V4, V1-V5 and V5-V0)
    int tetVerts[3][4] = {0,1,2,5, 0,1,5,4, 0,4,5,3};

    pPList rverts = R_vertices(region,1);
    for(int iTet=0; iTet<3; iTet++) {
      for(int iVtx=0; iVtx<4; iVtx++) {
        vtx = (pVertex)PList_item(rverts,tetVerts[iTet][iVtx]);
        V_coord(vtx,X_Y_Z[iVtx]);
      }
      value = XYZ_isPointInside(X_Y_Z,xyz);
      if(value)
        break;
    }
    PList_delete(rverts);
  }

  return value;
}


int M_getNumBLs(pMesh pmesh)
{
  return M_numEntGrps(pmesh);
}


void GC_getAvgGrowthEdgeDir(vector<pVertex> nodesOnGC, double *avgDir) {

  double xyzAtEnds[2][3], vec[3];
  pVertex vtx, ONode;
  int level = nodesOnGC.size();

  ONode = nodesOnGC[0];

  for(int iComp=0; iComp<3; iComp++)
    avgDir[iComp] = 0.;

  int count = 0;
  V_coord(ONode,xyzAtEnds[0]);
  for(int iNode=0; iNode<level-1; iNode++) {
    count++;

    vtx = nodesOnGC[iNode+1];
    V_coord(vtx,xyzAtEnds[1]);

    diffVt(xyzAtEnds[1],xyzAtEnds[0],vec);
    normVt(vec,vec);

    for(int iComp=0; iComp<3; iComp++)
      avgDir[iComp] += vec[iComp];

    for(int iComp=0; iComp<3; iComp++)
      xyzAtEnds[0][iComp] = xyzAtEnds[1][iComp];
  }

  for(int iComp=0; iComp<3; iComp++)
    avgDir[iComp] /= count;
}


// return 1 if normal vector is defined/applicable
void GC_getNormalVector(pVertex oNode, double *normal)
{
  double *normalVector;

  if (EN_getDataPtr(oNode, gcNormalTag, (void**)&normalVector))
  { 
    for(int i=0; i<3; i++)
      normal[i] = normalVector[i];
  }
  else
  {
    printf ("ERROR in GC_getNormalVector(): The normal is not defined\n");
    exit(0);
//    getNormalVector(oNode, normal);
//    GC_setNormalVector(oNode, normal);
  }
}


void GC_setNormalVector(pVertex oNode, double *normal)
{
  double *normalVector = new double[3];
  double mag = 0.;
  for(int i=0; i<3; i++) {
    mag += normal[i]*normal[i];
    normalVector[i] = normal[i];
  }

  mag = sqrt(mag);
  for(int i=0; i<3; i++)
    normalVector[i] = normalVector[i]/mag;

  void *ptr;
  if (!EN_getDataPtr(oNode, gcNormalTag, &ptr))
    EN_attachDataPtr(oNode, gcNormalTag, (void*)normalVector);
  else
    EN_modifyDataPtr(oNode, gcNormalTag, (void*)normalVector);
}


void GC_getClassification(vector<pVertex>& nodesOnGC, int &type, int &tag)
{
  int minType;
  pVertex vert;
  int numLayers = nodesOnGC.size();  
  type = 4;

  if (numLayers == 1)
  {
    vert = nodesOnGC[0];
    type = V_whatInType(vert);
    tag =  GEN_tag(V_whatIn(vert));
    return;
  }

  for(int iLayer=1; iLayer<numLayers; iLayer++) 
  {
    vert = nodesOnGC[iLayer];
    minType = V_whatInType(vert);
    if(type > minType) 
    {
      type = minType;
      tag = GEN_tag(V_whatIn(vert));
    }
  }
}


double GC_getTotalThickness(vector<pVertex>& nodesOnGC) 
{
  double xyzAtEnds[2][3];
  int level = nodesOnGC.size();
  V_coord(nodesOnGC[0],xyzAtEnds[0]);
  V_coord((pVertex)nodesOnGC[level-1],xyzAtEnds[1]);

  double vec[3], normalVector[3];
  diffVt(xyzAtEnds[1],xyzAtEnds[0],vec);
  GC_getNormalVector(nodesOnGC[0], normalVector);
  return dotProd(vec,normalVector);

}


pFace BL_GetZeroLvlFace(pBLayer pbl)
{
  pEdge pEdgeEdge;
  pFace pFaceFace, pFaceOppFace;
  pRegion pRegionRgn = pbl->getEntity(0);

  /// Dealing with BL categorized entities
  if (EN_levelInBL(pRegionRgn))
  {
    int iFaceType;
    for (int iFace = 0; iFace < R_numFaces(pRegionRgn); ++iFace)
    {
      pFaceFace = R_face(pRegionRgn, iFace);
      iFaceType = F_typeInBL(pFaceFace);
      if (iFaceType == fLAYER && F_whatInType(pFaceFace) == 2)
          return pFaceFace;
    }
  }

  /// Dealing with faces which are not BL categorized yet - through adjacencies
  int iWrongFace;
  for (int iIt = 0; iIt < R_numFaces(pRegionRgn); ++iIt)
  {
    pFaceFace = R_face(pRegionRgn, iIt);

    /// The condition of checking for model boundary only is not enough - look at the pyramids where more than two triangular faces are classified of the 
    /// model boundary. Should check for the connection with the quad face through any of the edge of a pyramid - should be none.
    if (F_whatInType(pFaceFace) == 2)
    {
      if (pRegionRgn->getType() == PYRAMID)
      {
        /// Check for the bottom of a pyramid
        iWrongFace = 0;
        for (int iEdge = 0; iEdge < 3; ++iEdge)
        {
          pEdgeEdge = F_edge(pFaceFace, iEdge);
          for (int iFace = 0; iFace < E_numFaces(pEdgeEdge); ++iFace)
          {
            pFaceOppFace = E_face(pEdgeEdge, iFace);
            if (pFaceOppFace->getType() == QUAD && F_whatInType(pFaceOppFace) == 2)
            {
              iWrongFace = 1;
              break;
            }
          }
          if (iWrongFace)
            break;
        }
        if (iWrongFace)
          continue;
      }
      else if (pRegionRgn->getType() == TET)
      {
        int iFoundEdge = 0;
        pPList redges = R_edges(pRegionRgn, 0);
        for (int iEdge = 0; iEdge < 6; ++iEdge)
        {       
          pEdgeEdge = (pEdge)PList_item(redges, iEdge);
          for (int iFace = 0; iFace < E_numFaces(pEdgeEdge); ++iFace)
          {
            pFaceOppFace = E_face(pEdgeEdge, iFace);
            if (pFaceOppFace->getType() == QUAD)
            {
              iFoundEdge = 1;
              break;
            }
          }
          if (iFoundEdge)
            break;
        }
      
        if (iFoundEdge)
          if (F_inClosure(pFaceFace, pEdgeEdge))
            continue;
      }
      return pFaceFace;
    }
  }
  printf("ERROR: There is no zero-level face in this boundary layer!\n");
}


pFace BL_GetTopFace(pBLayer pbl)
{
  int iBLSize = EG_getNumOfEntities(pbl);
/*
  std::vector<pFace> Vec_FacesStack;
  BL_getHorizontalFaces(pbl, Vec_FacesStack);
  return Vec_FacesStack[iBLSize - 1];
*/
  pRegion pRegionReg = pbl->getEntity(iBLSize - 1);

  pRegion pRegionTry;
  pFace pFaceFace;
  int iFaceType;
  for (int iFace = 0; iFace < R_numFaces(pRegionReg); ++iFace)
  {
    pFaceFace = R_face(pRegionReg, iFace);
    iFaceType = F_typeInBL(pFaceFace);
    if (iFaceType == fVERTICAL_QUAD || iFaceType == fVERTICAL_TRI)
      continue;

    pRegionTry = F_region(pFaceFace, 0);
    if (EN_getBL(pRegionTry))
      pRegionTry = F_region(pFaceFace, 1);
    else
      return pFaceFace;

    if (!pRegionTry)
      return pFaceFace;

    if (!EN_getBL(pRegionTry))
      return pFaceFace;
  }
}


void BL_GetLayerFaces(pFace pFaceBotFace, vector<pFace>& facesStack)
{
  facesStack.clear();
  facesStack.push_back(pFaceBotFace);

  pVertex pVertexVtx;
  pBLayer entSetGCZeroLvl[3];
  int iNumLayer[3];
  for (int iVtx = 0; iVtx < 3; ++iVtx)
  {
    pVertexVtx = F_vertex(pFaceBotFace, iVtx);
    EN_isInEntGrp(pVertexVtx, entSetGCZeroLvl[iVtx]);
    FMDB_Set_GetNumEnt(entSetGCZeroLvl[iVtx], &iNumLayer[iVtx]);
  }
  
  /// Figuring out the min number of layers fo the current stack such that we grab prisms only
  int iMinNumLayers = 10e+6;
  for (int iVtx = 0; iVtx < 3; ++iVtx)
    if (iMinNumLayers > iNumLayer[iVtx])
      iMinNumLayers = iNumLayer[iVtx];

  /// Find out if GCs intersect at the top
  /// Not implemented yet

  /// Get layer faces
  pRegion pRegionRgn, pRegionBotRgn = 0;
  pFace pFaceTopFace;
  for (int iNum = 1; iNum < iMinNumLayers; ++iNum)
  {
    pRegionRgn = F_region(pFaceBotFace, 0);
    if (pRegionRgn == pRegionBotRgn)
      pRegionRgn = F_region(pFaceBotFace, 1);
 
    if (pRegionRgn->getType() != PRISM)
    {
//      printf("Error! BL stack should contain only PRISMS!\n");
      break;
    }
 
    pFaceTopFace = R_face(pRegionRgn, 0);
    if (pFaceTopFace == pFaceBotFace)
      pFaceTopFace = R_face(pRegionRgn, 4);

    pFaceBotFace = pFaceTopFace;
    facesStack.push_back(pFaceBotFace);
    pRegionBotRgn = pRegionRgn;
  }
}


void BL_GetStackRgns(pFace pFaceBotFace, vector<pRegion>& rgnStack)
{
  rgnStack.clear();
  std::vector<pFace> facesStack;
  BL_GetLayerFaces(pFaceBotFace, facesStack);
  
  pRegion pRegionTopRgn, pRegionBotRgn = 0;
  for (int iFace = 0; iFace < facesStack.size()-1; ++iFace)
  {
    pFaceBotFace = facesStack[iFace];
    pRegionTopRgn = F_region(pFaceBotFace, 0);
    if (pRegionTopRgn == pRegionBotRgn)
      pRegionTopRgn = F_region(pFaceBotFace, 1);

    rgnStack.push_back(pRegionTopRgn);
    pRegionBotRgn = pRegionTopRgn; 
  }
}


// Get the stack of triangular horizontal faces.
void BL_getHorizontalFaces(pBLayer pbl, vector<pFace>& facesStack)
{
  facesStack.clear();
  pBLEntIter entBegIter = BL_GetBegEntIter(pbl);
  pBLEntIter entEndIter = BL_GetEndEntIter(pbl);
  pBLEntIter entIter = entBegIter;

  pRegion region = *entIter;
  pFace face, tri_faces[2];
  int iFaceType;

  for (int iFace = 0; iFace < R_numFaces(region); ++iFace)
  {
    face = R_face(region, iFace);
    iFaceType = F_typeInBL(face);
    if (iFaceType == fLAYER || iFaceType == fTRANSITION)
    {
      if(F_whatInType(face) == 2)
        tri_faces[0] = face;
      else
        tri_faces[1] = face;
    } 
  }
/*
  tri_faces[0] = R_face(region, 0);
//  tri_faces[1] = R_face(region, 4);
 
  if (F_whatInType(tri_faces[0]) != 2)
  {
    tri_faces[1] = tri_faces[0]; 
    tri_faces[0] = R_face(region, 4);
  }
  else
    tri_faces[1] = R_face(region, 4);
*/
  facesStack.push_back(tri_faces[0]);
  facesStack.push_back(tri_faces[1]);
  tri_faces[0] = tri_faces[1];
  entIter++;

  int reg_type, face_type;
  for (; entIter != entEndIter; entIter++)
  { 
    region = *entIter;
    reg_type = region->getType();
    switch(reg_type)
    {
      case PRISM:
        for (int i=0; i < 5; i = i+4)
        {
          tri_faces[1] = R_face(region, i);
          if (tri_faces[1] != tri_faces[0])
          {    
            facesStack.push_back(tri_faces[1]);
            tri_faces[0] = tri_faces[1];
            break;
          }
        }
        break;
      case PYRAMID:
        for (int i = 1; i < 5; i++)
        {
          tri_faces[1] = R_face(region,i);
          if (F_typeInBL(tri_faces[1]) == fTRANSITION && tri_faces[1] != tri_faces[0])
          {
            facesStack.push_back(tri_faces[1]);
            tri_faces[0] = tri_faces[1];
            break;
          }
        } 
        break;
      case TET:
        for (int i = 0; i < 4; i++)
        {
          tri_faces[1] = R_face(region,i);
          if (F_typeInBL(tri_faces[1]) == fTRANSITION && tri_faces[1] != tri_faces[0])
          {
            facesStack.push_back(tri_faces[1]);
            tri_faces[0] = tri_faces[1];
            break;
          }          
        }
        break;
    }
  }

  int eg_size = EG_getNumOfEntities(pbl);
  if ((eg_size+1) != facesStack.size())
    printf("WRONG SIZE OF THE OBTAINED STACK\n");
}

// Get the stack of quad vertical faces based on the zero level edge provided. WORKS FOR PRISMS ONLY!!!!
void BL_getVerticalFacesByZeroLevelEdge(pBLayer pbl, pEdge edge, vector<pFace>& facesStack)
{
  facesStack.clear();
  pFace face;
  pEdge opp_edge;
  int num = E_numFaces(edge);
  for (int i = 0; i < num; i++)
  {
    face = E_face(edge, i);
    if (face->getType() == QUAD)
    {
      break;
    }
  }
  while (F_typeInBL(face))
  {
    facesStack.push_back(face);
    for (int i = 0; i < 4; i++)
    {
      opp_edge = F_edge(face, i);
      if (edge != opp_edge && E_typeInBL(opp_edge) == eLAYER)
        break;
    }
    edge = opp_edge;
    num = E_numFaces(edge);
    for (int i = 0; i < num; i++)
    {
      face = E_face(edge, i);
      if (face->getType() == QUAD)
      {
        break;
      }
    }    
  }  
}

// Get vertical faces in an arbitrary order based on the edge provided.
void BL_getVerticalFacesByEdge(pEdge edge, vector<pFace>& facesStack)
{
  facesStack.clear();
  int e_type = E_typeInBL(edge);
  if (!(e_type == eLAYER || e_type == eTRANSITION))
  {
    printf("Incorrect input edge\n");
    return;
  }

  pFace faces[2], face_next;
  pEdge opp_edge, cur_edge;
  int num = E_numFaces(edge);
  int num_faces_trav = 0;
  int f_type;

  // find first adjacent QUAD face(s)
  for (int i = 0; i < num; i++)
  {
    faces[num_faces_trav] = E_face(edge, i);
    f_type = F_typeInBL(faces[num_faces_trav]);
    if (f_type == fVERTICAL_QUAD || f_type == fVERTICAL_TRI)
    {
      facesStack.push_back(faces[num_faces_trav]);
      num_faces_trav++;
      if (num_faces_trav == 2)
        break;
    }
  }

  // go through each of the face(s)
  int found_face;
  for (int i = 0; i < num_faces_trav; i++)
  {
    cur_edge = edge;
    found_face = 1;
    while (found_face)
    {
      num = F_numEdges(faces[i]);
      int j;
      for (j = 0; j < num; j++)
      {
        opp_edge = F_edge(faces[i], j);
        if (cur_edge != opp_edge)
        {
          e_type = E_typeInBL(opp_edge);
          if(e_type == eLAYER || e_type == eTRANSITION)
          {
            cur_edge = opp_edge;
            break;
          }
        }
      }
      num = E_numFaces(cur_edge);
      found_face = 0;
      for (j = 0; j < num; j++)
      {
        face_next = E_face(cur_edge, j);
        f_type = F_typeInBL(face_next);
        if ((f_type == fVERTICAL_QUAD || f_type == fVERTICAL_TRI) && face_next != faces[i])
        {
          facesStack.push_back(face_next);
          faces[i] = face_next;
          found_face = 1;
          break;
        }
      }
    }
  }
}

// Get stack of horizontal edges in an arbitrary order based on the edge provided. Assuming BL consists of PRISMs
void BL_getHorizontalEdgesByEdge(pEdge edge, vector<pEdge>& edgesStack)
{
  edgesStack.clear();
  int e_type = E_typeInBL(edge);
  if (!(e_type == eLAYER || e_type == eTRANSITION))
  {
    printf("Incorrect input edge\n");
    return;
  }

  pFace faces[2], face_next;
  pEdge opp_edge, cur_edge;
  int num = E_numFaces(edge);
  int num_faces_trav = 0;
  int f_type;
  edgesStack.push_back(edge);

  // find first adjacent QUAD face(s)
  for (int i = 0; i < num; i++)
  {
    faces[num_faces_trav] = E_face(edge, i);
    f_type = F_typeInBL(faces[num_faces_trav]);
    if (f_type == fVERTICAL_QUAD || f_type == fVERTICAL_TRI)
    {
      num_faces_trav++;
      if (num_faces_trav == 2)
        break;
    }
  }

  // go through each of the face(s)
  int found_face;
  for (int i = 0; i < num_faces_trav; i++)
  {
    found_face = 1;
    cur_edge = edge;
    while (found_face)
    {
      num = F_numEdges(faces[i]);
      int j;
      for (j = 0; j < num; j++)
      {
        opp_edge = F_edge(faces[i], j);
        if (cur_edge != opp_edge)
        {
          e_type = E_typeInBL(opp_edge);
          if(e_type == eLAYER || e_type == eTRANSITION)
          {
            edgesStack.push_back(opp_edge);
            cur_edge = opp_edge;
            break;
          }
        }
      }    
      num = E_numFaces(cur_edge);
      found_face = 0;
      for (j = 0; j < num; j++)
      {
        face_next = E_face(cur_edge, j);
        f_type = F_typeInBL(face_next);
        if ((f_type == fVERTICAL_QUAD || f_type == fVERTICAL_TRI) && face_next != faces[i])
        {
          faces[i] = face_next;
          found_face = 1;
          break;
        }
      }
    }
  }
}


void BL_getGrowthCurveEdges(pVertex vertex, vector<pEdge>& edgesStack)
{
  edgesStack.clear();
  pVertex vtx, opp_vtx;
  pEdge edge, opp_edge;

  /// Get the originating node
  vtx = V_getOriginatingNode(vertex);
  if (V_isCornerONode(vtx))
    return;

  int iEdgeType = 0;
  /// Find the first growth edge
  for (int iEdge = 0; iEdge < V_numEdges(vtx); ++iEdge)
  {
    edge = V_edge(vtx, iEdge);
    iEdgeType = E_typeInBL(edge);
    if (iEdgeType == eGROWTH)
      break;
  }

  if (iEdgeType != eGROWTH)
    return;

  /// Get another vertex of the edge
  opp_vtx = E_otherVertex(edge, vtx);
  edgesStack.push_back(edge);
  opp_edge = edge;
  
  /// Loop over adjacent growth edges to construct the growth curve
  int found_edge = 1;
  while(found_edge)
  {
    found_edge = 0;
    for (int i = 0; i < V_numEdges(opp_vtx); ++i)
    {
      edge = V_edge(opp_vtx, i);
      if (E_typeInBL(edge) == eGROWTH && edge != opp_edge)
      {
        found_edge = 1;
        break;
      }
    }
    if (found_edge)
    {
      vtx = opp_vtx;
      opp_vtx = E_otherVertex(edge, vtx);
      edgesStack.push_back(edge);
      opp_edge = edge;
    }
  }
}


void BL_getGrowthCurveNodes(pVertex vertex, vector<pVertex>& vtxStack)
{
  vtxStack.clear();
  if (V_isCornerONode(vertex))
  {
    vtxStack.push_back(vertex);
    return;
  }

  vector<pEdge> edgesStack;
  BL_getGrowthCurveEdges(vertex, edgesStack);
  /// In case of trimmed down to the model boundary entities
  if (edgesStack.size() == 0)
  {
    vtxStack.push_back(vertex);
    return;
  }

  BL_getGCNodesFromGCEdges(edgesStack, vtxStack);
}


void BL_getGCNodesFromGCEdges(vector<pEdge>& edgesStack, vector<pVertex>& vtxStack)
{
  vtxStack.clear();
  /// Identify which vertex of the first edge is the originating node
  pVertex vtx = E_vertex(edgesStack[0],0);
  pVertex opp_vtx;
  if (!V_isOriginatingNode(vtx))
  {
    opp_vtx = vtx;
    vtx = E_vertex(edgesStack[0],1);
  }
  else
    opp_vtx = E_vertex(edgesStack[0],1);

  vtxStack.push_back(vtx);
  vtxStack.push_back(opp_vtx);

  /// Add other vertexes while looping over edges
  for (int iEdge = 1; iEdge < edgesStack.size(); ++iEdge)
  {
    vtx = E_vertex(edgesStack[iEdge],0);
    if (vtx == opp_vtx)
      vtx = E_vertex(edgesStack[iEdge],1);
    vtxStack.push_back(vtx);
    opp_vtx = vtx;
  }
}


void BL_CategorizeBLEntities(pBLayer pbl)
{
  int type;
  int level1, level2;

  blVertexType vType;
  blEdgeType etype;
  blFaceType ftype;
  blRegionType rtype;

  pVertex vertex;
  pEdge edge, opp_edge;
  pFace face;
  pRegion rgn;

  pFace pFaceZeroLvlFace = BL_GetZeroLvlFace(pbl);
  /// Zero level face is always a layer face and has a layer edges
  ftype = fLAYER;
  if(!EN_getDataInt((pEntity)pFaceZeroLvlFace, blFaceTypeID, &type))
    EN_attachDataInt((pEntity)pFaceZeroLvlFace, blFaceTypeID, ftype);  

  etype = eLAYER;  
  for (int iEdge = 0; iEdge < 3; ++iEdge)
  {
    edge = F_edge(pFaceZeroLvlFace, iEdge);
    if(!EN_getDataInt((pEntity)edge, blEdgeTypeID, &type))
      EN_attachDataInt((pEntity)edge, blEdgeTypeID, etype);
  }

  /// Take care of zero-level face first in order to place originating vertices correctly without interfering them from other side faces
  vType = vORIGINATING;
  for (int iVert = 0; iVert < 3; ++iVert)
  {
    vertex = F_vertex(pFaceZeroLvlFace, iVert);
    if (!EN_getDataInt((pEntity)vertex, blVertexTypeID, &type))
      EN_attachDataInt((pEntity)vertex, blVertexTypeID, vType);
    if (EN_getDataInt(vertex, blVertexTypeID, &type) && type != vORIGINATING)
      printf("ERROR from BL_CategorizeBLEntities!!! Zero-level vertex must be originating!!!\n");
  }


  int iRgnCount = 0;
  pBLEntIter entBegIter = BL_GetBegEntIter(pbl);
  pBLEntIter entEndIter = BL_GetEndEntIter(pbl);
  pBLEntIter entIter;
    for (entIter = entBegIter; entIter != entEndIter; entIter++)
    {
      rgn = *entIter;
      iRgnCount++;
//      if(EN_getDataInt((pEntity)rgn, blRegionTypeID, &type))
//        continue;

      int topoType = rgn->getType();

      for (int iFace = 0; iFace < R_numFaces(rgn); ++iFace)
      {
        face = R_face(rgn, iFace);

//        if (topoType == PRISM || topoType == PYRAMID)

        if (face != pFaceZeroLvlFace)
        {
          vType = vREGULAR;
          for (int iVert = 0; iVert < 3; ++iVert)
          {
            vertex = F_vertex(face, iVert);
            if (!EN_getDataInt((pEntity)vertex,blVertexTypeID, &type))
            {
              EN_attachDataInt(vertex, blVertexTypeID, vType);
            }
          }
        }
      }

      if(topoType == PRISM) 
      {
        rtype = rREGULAR;
        EN_attachDataInt((pEntity)rgn, blRegionTypeID, rtype);

        // prismatic element
        for(int iFace=0; iFace<5; iFace++) {
          face = R_face(rgn,iFace);
          if(!EN_getDataInt((pEntity)face,blFaceTypeID,&type)) {
            if(iFace==0 || iFace==4)
              ftype = fLAYER;
            else
              ftype = fVERTICAL_QUAD;
            if (!EN_getDataInt((pEntity)face, blFaceTypeID, &type))
              EN_attachDataInt((pEntity)face,blFaceTypeID,ftype);
          }
        }

        // prismatic element
        pPList redges = R_edges(rgn,1);

        for(int iEdge=0; iEdge<9; iEdge++) {
          edge = (pEdge)PList_item(redges,iEdge);
          if(!EN_getDataInt((pEntity)edge, blEdgeTypeID, &type)) {
            if(iEdge>=3 && iEdge<=5)
              etype = eGROWTH;
            else
              etype = eLAYER;
            EN_attachDataInt((pEntity)edge,blEdgeTypeID,etype);
          }
        }
        PList_delete(redges);
      }
      else
      { // pyramids and tets
        // DO NOT SUPPORT TRANSITION/BLEND ELEMENTS
        if(topoType == PYRAMID) {
          rtype = rTRANSITION_PYR;
          EN_attachDataInt((pEntity)rgn,blRegionTypeID,rtype);

/// THESE TWO COMMENTED PARTS FOR PYRAMIDS AND TETS ARE TAKEN FROM ORIGINAL BLADAPT CODE. IT IS SUPPOSED TO MARK EDGES AND FACES CORRECTLY DEPENDING
/// ON THE LEVEL OF VERTEXES THEY RESIDE ON, BUT IT DOES NOT WORK PROPERLY, FIND OUT WHY LATER.
/*
          int level[2];
          pPList redges = R_edges(rgn,1);
          // pyramid element
          for(int iEdge=0; iEdge<8; iEdge++) {
            edge = (pEdge)PList_item(redges,iEdge);
            if(!EN_getDataInt((pEntity)edge,blEdgeTypeID,&type)) {
              for(int iVert=0; iVert<2; iVert++)
                level[iVert] = EN_levelInBL((pEntity)E_vertex(edge,iVert));
              if(level[0]==level[1])
                etype = eLAYER;
              else {
                if(iEdge<4)
                  etype = eGROWTH;
                else
                  etype = eTRANSITION;
              }
              EN_attachDataInt((pEntity)edge,blEdgeTypeID,etype);
            }
          }
          PList_delete(redges);

          // pyramid element
          for(int iFace=0; iFace<5; iFace++) {
            face = R_face(rgn,iFace);
            if(!EN_getDataInt((pEntity)face,blFaceTypeID,&type)) {
              if(!iFace)
                ftype = fVERTICAL_QUAD;
              else if(!EN_levelInBL((pEntity)face))
                ftype = fLAYER;
              else {
                // other faces of pyramid are triangular
                for(int iEdge=0; iEdge<3; iEdge++) {
                  edge = F_edge(face,iEdge);
                  // edges have been categorized
                  etype = (blEdgeType)E_typeInBL(edge);
                  if(etype==eGROWTH) {
                    ftype = fVERTICAL_TRI;
                    break;
                  }
                  else
                    ftype = fTRANSITION;
                }
              }
              EN_attachDataInt((pEntity)face,blFaceTypeID,ftype);
            }
          }
*/

          // Traverse all the edges of the quad face first
          face = R_face(rgn,0);
          ftype = fVERTICAL_QUAD;
          if (!EN_getDataInt((pEntity)face, blFaceTypeID, &type))
            EN_attachDataInt((pEntity)face,blFaceTypeID,ftype);
          for (int iEdge = 0; iEdge < 4; ++iEdge)
          {
            edge = F_edge(face,iEdge);
            etype = (blEdgeType)E_typeInBL(edge);

            // Find the first layer or transition edge
            if (etype == eLAYER || etype ==eTRANSITION)
              break;
          }
          for (int iEdge = 0; iEdge < 4; ++iEdge)
          {
            opp_edge = F_edge(face,iEdge);
            if (opp_edge != edge && !E_typeInBL(opp_edge))
            {
              if (!(E_vertex(edge,0) == E_vertex(opp_edge,0) || E_vertex(edge,1) == E_vertex(opp_edge,0) || E_vertex(edge,0) == E_vertex(opp_edge,1) || E_vertex(edge,1) == E_vertex(opp_edge,1)))//edge->commonVertex(opp_edge))

                // Suppose all the horisontal edges on the quad face are on the same level, i.e. layer edges
                etype = eLAYER;
              else
                etype = eGROWTH;
              EN_attachDataInt((pEntity)opp_edge,blEdgeTypeID,etype);
            }
          }

          for (int iFace = 1; iFace < 5; ++iFace)
          {
            face = R_face(rgn,iFace);
            if (!F_typeInBL(face))
            {
              for (int iEdge=0; iEdge<3; iEdge++)
              {
                edge = F_edge(face,iEdge);
                // edges have been categorized
                etype = (blEdgeType)E_typeInBL(edge);

                // If not categorized, then there are only two edges left on the upper triangular face of the pyramid
                if (!etype)
                  EN_attachDataInt((pEntity)edge,blEdgeTypeID,eTRANSITION);
                if(etype == eGROWTH) 
                {
                  ftype = fVERTICAL_TRI;
                  break;
                }
                else
                  ftype = fTRANSITION;
              }
              if (!EN_getDataInt((pEntity)face, blFaceTypeID, &type))
                EN_attachDataInt((pEntity)face,blFaceTypeID,ftype);
            }
          }

        }
        else if(topoType == TET)
        {
          rtype = rTRANSITION_TET;
          EN_attachDataInt((pEntity)rgn,blRegionTypeID,rtype);

/*
          int level[2];
          pPList redges = R_edges(rgn,1);
          // tet. element
          for(int iEdge=0; iEdge<6; iEdge++) {
            edge = (pEdge)PList_item(redges,iEdge);
            if(!EN_getDataInt((pEntity)edge,blEdgeTypeID,&type)) {
              for(int iVert=0; iVert<2; iVert++)
                level[iVert] = EN_levelInBL((pEntity)E_vertex(edge,iVert));
              if(level[0]==level[1])
                etype = eLAYER;
              else {
                int isQuad = 0;
                void *efiter = 0;
                pPList efaces = E_faces(edge);
                while(face = (pFace)PList_next(efaces,&efiter)) {
                  if(F_numEdges(face)==4) {
                    isQuad = 1;
                    break;
                  }
                }
                PList_delete(efaces);
                if(isQuad)
                  etype = eGROWTH;
                else
                  etype = eTRANSITION;
              }
              EN_attachDataInt((pEntity)edge,blEdgeTypeID,etype);
            }
          }
          PList_delete(redges);

          // tet. element
          for(int iFace=0; iFace<4; iFace++) {
            face = R_face(rgn,iFace);
            if(!EN_getDataInt((pEntity)face,blFaceTypeID,&type)) {
              if(!EN_levelInBL((pEntity)face))
                ftype = fLAYER;
              else {
                for(int iEdge=0; iEdge<3; iEdge++) {
                  edge = F_edge(face,iEdge);
                  // edges have been categorized
                  etype = (blEdgeType)E_typeInBL(edge);
                  if(etype==eGROWTH) {
                    ftype = fVERTICAL_TRI;
                    break;
                  }
                  else
                    ftype = fTRANSITION;
                }
              }
              EN_attachDataInt((pEntity)face,blFaceTypeID,ftype);
            }
          }
*/

          for(int iFace=0; iFace<4; iFace++)
          {
            face = R_face(rgn,iFace);
            if(!F_typeInBL(face))
            {
              for(int iEdge=0; iEdge<3; iEdge++)
              {
                edge = F_edge(face,iEdge);
                // edges have been categorized
                etype = (blEdgeType)E_typeInBL(edge);
                if (!etype)
                {
                  for (int i = 0; i < E_numFaces(edge); i++)
                  {
                    if (E_face(edge,i)->getType() == QUAD)
                    {
                      etype = eGROWTH;
                      break;
                    }
                  }
                  if (!etype)
                    etype = eTRANSITION;
                  EN_attachDataInt((pEntity)edge,blEdgeTypeID,etype);
                }
                if(etype==eGROWTH)
                {
                  ftype = fVERTICAL_TRI;
                  break;
                }
                else
                  ftype = fTRANSITION;
              }
              if (!EN_getDataInt((pEntity)face, blFaceTypeID, &type))
                EN_attachDataInt((pEntity)face, blFaceTypeID, ftype);
            }
          }

        }
      }
    }
}


void Mesh_CategorizeBLEntities(pMesh pmesh)
{
  blVertexTypeID = MD_lookupMeshDataId("bl vertex type");
  blEdgeTypeID = MD_lookupMeshDataId("bl edge type");
  blFaceTypeID = MD_lookupMeshDataId("bl face type");
  blRegionTypeID = MD_lookupMeshDataId("bl region type");

  int iNumBLs;
  FMDB_Part_GetNumSet (pmesh, &iNumBLs);
//  printf("Categorizing %d of boundary layers\n", iNumBLs);

  pBLIter egBegIter = Mesh_GetBegBLIter(pmesh);
  pBLIter egEndIter = Mesh_GetEndBLIter(pmesh);
  pBLIter egIter;

  for (egIter = egBegIter; egIter != egEndIter; egIter++)
  {
    BL_CategorizeBLEntities((pBLayer)(*egIter));
  }
}

#ifdef MA_PARALLEL
/// Collect and update BL edges on the part boundary
void Mesh_UnifyBLInterfaceOnCB(pMesh pmesh)
{
  if (P_size() == 1)
    return;

  list<pMeshEnt> updt_BL_on_CB;

  pMeshEnt FMDB_Ent;

  pPartEntIter pEntIter;
  pMeshDataId BL_EntType[3] = {blVertexTypeID, blEdgeTypeID, blFaceTypeID};
  for (int iType = 0; iType < 3; ++iType)
  {
    FMDB_PartEntIter_Init (pmesh, iType, FMDB_ALLTOPO, pEntIter);
    int iEnd = 0;
    while (!iEnd)
    {
      FMDB_PartEntIter_GetNext(pEntIter, FMDB_Ent);
      if (EN_isBLEntity(FMDB_Ent) && EN_onCB(FMDB_Ent))
        updt_BL_on_CB.push_back(FMDB_Ent);
      FMDB_PartEntIter_IsEnd(pEntIter, &iEnd);
    }
    M_unifyTaggedEntitiesWithValues(BL_EntType[iType], &updt_BL_on_CB);
    updt_BL_on_CB.clear();
    FMDB_PartEntIter_Del(pEntIter);
  }
}
#endif


int Mesh_BLInfo(pMesh pMeshMesh)
{
  std::map<int, int> MapStackSize;
  int iNumTopo[3] = {0, 0, 0};
  pBLIter egBegIter = Mesh_GetBegBLIter(pMeshMesh);
  pBLIter egEndIter = Mesh_GetEndBLIter(pMeshMesh);
  pBLIter egIter;
  pBLayer pBLayerBL;
  pRegion pRegionRgn;
  int iNumLayer;

  for (egIter = egBegIter; egIter != egEndIter; egIter++)
  {
    pBLayerBL = (pBLayer)(*egIter);
    iNumLayer = EG_getNumOfEntities(pBLayerBL);
    if (MapStackSize.count(iNumLayer) == 0)
      MapStackSize[iNumLayer] = 1;
    else
      MapStackSize[iNumLayer]++;

    pRegionRgn = pBLayerBL->getEntity(0);
    if (pRegionRgn->getType() == PRISM)
      iNumTopo[0]++;
    else if (pRegionRgn->getType() == PYRAMID)
      iNumTopo[1]++;
    else
      iNumTopo[2]++;
  }

#ifdef DEBUG
  for (std::map<int, int>::iterator itMap = MapStackSize.begin(); itMap != MapStackSize.end(); ++itMap)
    printf("There are %d stacks with %d regions\n", itMap->second, itMap->first);

//  printf("There are %d stacks starting with PRISM, %d with PYRAMID and %d with TET\n", iNumTopo[0], iNumTopo[1], iNumTopo[2]);
  printf("There are %d BL stacks\n", iNumTopo[0]);
#endif

  pFace pFaceFace;
  pRegion reg;
  int iCapPyrCount = 0;
  int iQuadFaceCount = 0;
  RIter riter = M_regionIter(pMeshMesh);
  while(reg=RIter_next(riter))
  {
    if (reg->getType() == PRISM && !EN_getBL(reg))
    {
      printf("!!!!!!!!!! PRISM IS NOT A PART OF ANY BL, CAN'T DEAL WITH SUCH A CASE YET !!!!!!!\n");
      exit(0);
    }

    if (reg->getType() == PYRAMID)
    {
      pFace pFaceFace = R_face(reg, 0);
      pRegion pRegionRgn = F_region(pFaceFace, 0);
      if (reg == pRegionRgn)
        pRegionRgn = F_region(pFaceFace, 1);
        
      if (pRegionRgn && (pRegionRgn->getType() != PYRAMID) && !F_typeInBL(pFaceFace))
      {
        printf("PYRAMID's QUAD face is not a BL one where the next to pyramid region is %d!!!\n",pRegionRgn->getType());
        iQuadFaceCount++;
      }
      for (int iFace = 1; iFace < 5; ++iFace)
      {
        pFaceFace = R_face(reg, iFace);
        if (F_typeInBL(pFaceFace) == fVERTICAL_TRI)
          printf("PYRAMID's TRI face IS a BL one!!!\n");
      }

      iCapPyrCount++;
    }

  }
  RIter_delete(riter);

#ifdef DEBUG
  printf("There are %d capping pyramids\n", iCapPyrCount);
  if (iQuadFaceCount)
    printf("There are %d pyramids internal to the mesh", iQuadFaceCount);
#endif
}


void BL_CategorizeBLEnts(pFace pFaceBotFace)
{
  std::vector<pFace> VecFaceStack;
  std::vector<pRegion> VecRgnStack;

  BL_GetLayerFaces(pFaceBotFace, VecFaceStack);
  BL_GetStackRgns(pFaceBotFace, VecRgnStack);

  pVertex pVertexVtx;
  pEdge pEdgeEdge;
  pFace pFaceFace;
  pRegion pRegionRgn;
  int iLevel, iMaxLevel;
  int iBLEdgeType, iBLFaceType;

  /// Categorizing all layer BL ents
  for (int iFace = 0; iFace < VecFaceStack.size(); ++iFace)
  {
    pFaceFace = VecFaceStack[iFace];
    EN_attachDataInt((pEntity)pFaceFace, layerNumberID, iFace);
    iBLFaceType = fLAYER;

    for (int iEdge = 0; iEdge < 3; ++iEdge)
    {
      pEdgeEdge = F_edge(pFaceFace, iEdge);

      iBLEdgeType = eLAYER;
      pVertexVtx = E_vertex(pEdgeEdge, 0);
      iMaxLevel = EN_levelInBL(pVertexVtx);
      pVertexVtx = E_vertex(pEdgeEdge, 1);
      iLevel = EN_levelInBL(pVertexVtx);

      if (iLevel != iMaxLevel)
      {
        if (iLevel > iMaxLevel)
          iMaxLevel = iLevel;
  
        iBLEdgeType = eTRANSITION;
        iBLFaceType = fTRANSITION;
      }

      EN_attachDataInt((pEntity)pEdgeEdge, layerNumberID, iMaxLevel);
      EN_attachDataInt((pEntity)pEdgeEdge, blEdgeTypeID, iBLEdgeType);
    }

    EN_attachDataInt((pEntity)pFaceFace, blFaceTypeID, iBLFaceType);

  }


  int iRgnTopoType, iBLRgnType;

  /// Categorizing all growth BL entities
  for (int iRgn = 0; iRgn < VecRgnStack.size(); ++iRgn)
  {
    pRegionRgn = VecRgnStack[iRgn];
    iLevel = iRgn + 1;
    EN_attachDataInt((pEntity)pRegionRgn, layerNumberID, iLevel);    

    for (int iFace = 0; iFace < R_numFaces(pRegionRgn); ++iFace)
    {
      pFaceFace = R_face(pRegionRgn, iFace);
      iBLFaceType = F_typeInBL(pFaceFace);
      if (!iBLFaceType)
      {
        if (pFaceFace->getType() == TRI)
          iBLFaceType = fVERTICAL_TRI;
        else
          iBLFaceType = fVERTICAL_QUAD;
        EN_attachDataInt((pEntity)pFaceFace, blFaceTypeID, iBLFaceType);
        EN_attachDataInt((pEntity)pFaceFace, layerNumberID, iLevel);

        for (int iEdge = 0; iEdge < F_numEdges(pFaceFace); ++iEdge)
        {
          pEdgeEdge = F_edge(pFaceFace, iEdge);
          iBLEdgeType = E_typeInBL(pEdgeEdge);
          if (!iBLEdgeType)
          {
            EN_attachDataInt((pEntity)pEdgeEdge, blEdgeTypeID, eGROWTH);
            EN_attachDataInt((pEntity)pEdgeEdge, layerNumberID, iLevel);
          }
        }
      }
    }

    iRgnTopoType = pRegionRgn->getType();
    if(iRgnTopoType == PRISM)
      iBLRgnType = rREGULAR;
    else if (iRgnTopoType == PYRAMID)
      iBLRgnType = rTRANSITION_PYR;
    else
      iBLRgnType = rTRANSITION_TET;
    EN_attachDataInt((pEntity)pRegionRgn, blRegionTypeID, iBLRgnType);
    
  }
}


/// Construction of BLs based on the entity sets implementation
int Mesh_ConstructBLs_EntSet(pMesh mesh)
{
  int iNumGC;
  FMDB_Part_GetNumSet (mesh, &iNumGC);
  if (iNumGC == 0)
    return 1;

  pPartSetIter iterEntSet;
  FMDB_PartSetIter_Init(mesh, iterEntSet);

  blVertexTypeID = MD_lookupMeshDataId("bl vertex type");
  blEdgeTypeID = MD_lookupMeshDataId("bl edge type");
  blFaceTypeID = MD_lookupMeshDataId("bl face type");
  blRegionTypeID = MD_lookupMeshDataId("bl region type");
  layerNumberID = MD_lookupMeshDataId("BL number of layers");

  pEntSet entSet;
  pVertex pVertexVtx;
  pSetEntIter iterEnt;
  int iNumVtx, iData;

  /// Checking if the sets are constructed from growth curves, or they already have regions
  if (FMDB_PartSetIter_GetNext(mesh, iterEntSet, entSet) == SCUtil_SUCCESS)
  {
    if (FMDB_SetEntIter_Init(entSet, 0, 0, iterEnt) == SCUtil_FAILURE)
    {
      FMDB_PartSetIter_Del(iterEntSet);
      return 1;
    }
    else
      FMDB_SetEntIter_Del(iterEnt);
  }

  /// Tagging all the first vertices of GCs to be originating BL vertices
  for (int iGC = 0; iGC < iNumGC; ++iGC)
  {
    FMDB_SetEntIter_Init(entSet, 0, 0, iterEnt);

    FMDB_Set_GetNumEnt (entSet, &iNumVtx);
    for (int iVtx = 0; iVtx < iNumVtx; ++iVtx)
    {
      FMDB_SetEntIter_GetNext(iterEnt, pVertexVtx);
      if (!EN_getDataInt(pVertexVtx, blVertexTypeID, &iData))
      {
        if (iVtx == 0)
          EN_attachDataInt(pVertexVtx, blVertexTypeID, vORIGINATING);
        else
          EN_attachDataInt(pVertexVtx, blVertexTypeID, vREGULAR);
      }
      if (!EN_getDataInt(pVertexVtx, layerNumberID, &iData))
        EN_attachDataInt(pVertexVtx, layerNumberID, iVtx);
    }

    FMDB_SetEntIter_Del(iterEnt);
    FMDB_PartSetIter_GetNext(mesh, iterEntSet, entSet);
  }
  FMDB_PartSetIter_Del(iterEntSet);


  /// Traversing faces, finding zero-level ones and getting the stacks of BL regions
  pFace pFaceFace;
  std::vector<pRegion> VecRgnStack;
  FIter fIter = M_faceIter(mesh);

int iCount = 0;
  while(pFaceFace = FIter_next(fIter))
  {
    if ((F_whatInType(pFaceFace) < 3) && (pFaceFace->getType() == TRI))
    {
      int iNumBLVtx = 0;
      for (int iVtx = 0; iVtx < 3; ++iVtx)
      {
        pVertexVtx = F_vertex(pFaceFace, iVtx);
        if (V_typeInBL(pVertexVtx) == vORIGINATING)
          iNumBLVtx++;
      }
      if (iNumBLVtx < 3)
        continue;
    }
    else
      continue;
 
iCount++;
    /// Put regions in the entity set
    BL_GetStackRgns(pFaceFace, VecRgnStack);
    if (VecRgnStack.size() == 0)
      continue;

    entSet = M_createEntGrp(mesh, 3);
    for (int iRgn = 0; iRgn < VecRgnStack.size(); ++iRgn)
      EG_addEntity((pBLayer)entSet, VecRgnStack[iRgn]);

    BL_CategorizeBLEnts(pFaceFace);

  }
  FIter_delete(fIter);

  /// For now, GCs are deleted since we work with region stacks
  std::vector<pBLayer> VecGCRem;
  FMDB_PartSetIter_Init(mesh, iterEntSet);  
  for (int iSet = 0; iSet < iNumGC; ++iSet)
  {
    FMDB_PartSetIter_GetNext(mesh, iterEntSet, entSet);
    VecGCRem.push_back((pBLayer)entSet);
  }
  for (int iSet = 0; iSet < iNumGC; ++iSet)
  {
    entSet = VecGCRem[iSet];
    FMDB_Set_Clr(entSet);
    FMDB_Set_Del(NULL, mesh, entSet);
  }
  VecGCRem.clear();

  return 0;
}


void BL_AssignBLLevelsToEnts(pBLayer pbl)
{
  /// This should be provided somewhere at the beginning, so make sure the tag is defined
  layerNumberID = MD_lookupMeshDataId("BL number of layers");
  remLayerNumberID = MD_lookupMeshDataId("BL number of layers on RC");

  pRegion reg;
  pRegion face;
  pEdge edge;
  pVertex vert;
  int iLevel = 0, level;

  pBLEntIter entBegIter = BL_GetBegEntIter(pbl);
  pBLEntIter entEndIter = BL_GetEndEntIter(pbl);
  pBLEntIter entIter = entBegIter;
  reg = *entIter;

  face = BL_GetZeroLvlFace(pbl);

  for (int iEdge = 0; iEdge < 3; iEdge++)
  {
    edge = F_edge(face, iEdge);
    for (int iVert = 0; iVert < 2; iVert++)
    {
      vert = E_vertex(edge, iVert);
      if (!EN_getDataInt(vert, layerNumberID, &level))
        EN_attachDataInt(vert, layerNumberID, iLevel);
      /// If there's a remote level data, it should be deleted since now the vertex/edge/face is part of the stack on local part
      if (EN_getDataInt(vert, remLayerNumberID, &level))
        EN_deleteData(vert, remLayerNumberID);
      if (EN_getDataInt(vert, blVertexTypeID, &level) && level != vORIGINATING)
        printf("ERROR from BL_AssignBLLevelsToEnts!!! Zero-level vertex must be originating!!!\n");
    }
    if (!EN_getDataInt(edge, layerNumberID, &level))
      EN_attachDataInt(edge, layerNumberID, iLevel);
    if (EN_getDataInt(edge, remLayerNumberID, &level))
      EN_deleteData(edge, remLayerNumberID);
  }
  if (!EN_getDataInt(face, layerNumberID, &level))
    EN_attachDataInt(face, layerNumberID, iLevel);
  if (EN_getDataInt(face, remLayerNumberID, &level))
    EN_deleteData(face, remLayerNumberID);

  for (; entIter != entEndIter; ++entIter)
  {
    iLevel++;
    reg = *entIter;
    for (int iFace = 0; iFace < R_numFaces(reg); ++iFace)
    {
      face = R_face(reg, iFace);
      for (int iEdge = 0; iEdge < F_numEdges(face); iEdge++)
      {
        edge = F_edge(face, iEdge);
        for (int iVert = 0; iVert < 2; iVert++)
        {
          vert = E_vertex(edge, iVert);
          if (!EN_getDataInt(vert, layerNumberID, &level))
            EN_attachDataInt(vert, layerNumberID, iLevel);
          if (EN_getDataInt(vert, remLayerNumberID, &level))
            EN_deleteData(vert, remLayerNumberID);
        }
        if (!EN_getDataInt(edge, layerNumberID, &level))
          EN_attachDataInt(edge, layerNumberID, iLevel);
        if (EN_getDataInt(edge, remLayerNumberID, &level))
          EN_deleteData(edge, remLayerNumberID);
      }
      if (!EN_getDataInt(face, layerNumberID, &level))
        EN_attachDataInt(face, layerNumberID, iLevel);
      if (EN_getDataInt(face, remLayerNumberID, &level))
        EN_deleteData(face, remLayerNumberID);
    }
//    iLevel++;
    if (!EN_getDataInt(reg, layerNumberID, &level))
      EN_attachDataInt(reg, layerNumberID, iLevel);
  }

}



/// Same as above but applied to all BLs
void Mesh_AssignBLLevelsToAllBLEnts(pMesh mesh)
{
  for (pBLIter egIt = Mesh_GetBegBLIter(mesh); egIt != Mesh_GetEndBLIter(mesh); ++egIt)
  { 
    BL_AssignBLLevelsToEnts((pBLayer)(*egIt));
  }

#ifdef MA_PARALLEL
  if (SCUTIL_CommSize() == 1)
    return;

  /// Initialize IPComMan
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  int num_sent = 0, num_recvd = 0;
  int iSize = sizeof(pMeshEnt) + sizeof(int);
  CM->set_fixed_msg_size(iSize);
  void* msg_send = CM->alloc_msg(iSize);
  pMeshEnt* entSend = (pMeshEnt*)msg_send;
  int* iSend = (int*)((char*)msg_send + sizeof(pMeshEnt));

  /// Communicate remote level data
  pMeshEnt FMDB_Ent;
  pPartEntIter pEntIter;
  for (int iType = 0; iType < 3; ++iType)
  {
    FMDB_PartEntIter_Init (mesh, iType, FMDB_ALLTOPO, pEntIter);
    int iEnd = 0;
    while (!iEnd)
    {
      FMDB_PartEntIter_GetNext(pEntIter, FMDB_Ent);
      if (EN_isBLEntity(FMDB_Ent) && EN_onCB(FMDB_Ent) && EN_levelInBL(FMDB_Ent) > -1)
      {
        std::vector<std::pair<int, pMeshEnt> > EntRemCpy;
        FMDB_Ent_GetAllRmt(FMDB_Ent, EntRemCpy);

        /// Get the rem copy of the entity and send its level
        *iSend = EN_levelInBL(FMDB_Ent);
        for (int iRC = 0; iRC < EntRemCpy.size(); ++iRC)
        {
          *entSend = EntRemCpy[iRC].second;
          CM->send(EntRemCpy[iRC].first, msg_send);
        }
      }
      FMDB_PartEntIter_IsEnd(pEntIter, &iEnd);
    }
    FMDB_PartEntIter_Del(pEntIter);
  }

  CM->free_msg(msg_send);
  CM->finalize_send();

  void* msg_recv;
  int pid_from;
  // recieve phase, attach the level as a remote level to those entities which are detached from the stack
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    entSend = (pMeshEnt*)msg_recv;
    iSend = (int*)((char*)msg_recv + sizeof(pMeshEnt));
    if (EN_levelInBL(*entSend) < 0)
      EN_attachDataInt(*entSend, remLayerNumberID, *iSend);

    CM->free_msg(msg_recv);
  }
#endif
}

/// Construction of BLs based on the entity group implementation
int Mesh_ConstructBLs(pMesh mesh)
{
  /// Delete all possibly existent EGs
  int iNumGC;
  pEntSet entSet;
  FMDB_Part_GetNumSet (mesh, &iNumGC);
  pPartSetIter iterEntSet;
  std::vector<pBLayer> VecGCRem;
  FMDB_PartSetIter_Init(mesh, iterEntSet);
  for (int iSet = 0; iSet < iNumGC; ++iSet)
  {
    FMDB_PartSetIter_GetNext(mesh, iterEntSet, entSet);
    VecGCRem.push_back((pBLayer)entSet);
  }
  for (int iSet = 0; iSet < iNumGC; ++iSet)
  {
    entSet = VecGCRem[iSet];
    FMDB_Set_Clr(entSet);
    FMDB_Set_Del(NULL, mesh, entSet);
  }
  VecGCRem.clear();

  FIter fiter = M_faceIter(mesh);
  pVertex vtx;
  pEdge edge;
  pFace opp_face, face;
  pRegion opp_reg, reg;
  pBLayer entGrp;
  int count=0;
  int num_added_ents = 0;

  layerNumberID = MD_lookupMeshDataId("BL number of layers");

  /// Put PRISMs in Entity Groups only
  while(face=FIter_next(fiter)) {

    if(face->getType()==TRI && GEN_type(F_whatIn(face))==2) {                  // on model face
      reg = F_region(face, 0);
      if(!reg)
        reg = F_region(face, 1);
      if(!reg) {
        cout<<"ERROR: no region is connected to a surface face. "<<endl;
        return 0;
      }

      opp_face = face;
      opp_reg = reg;

      if(reg->getType() == PRISM) {
        entGrp = M_createEntGrp(mesh, 3);
        count++;
//        cout<<"EntGrp"<<count<<": ";
      }
      else
        continue;

      while (reg->getType()== PRISM)
      {
//        cout<<EN_getUid(reg)<<" ";
//        entGrp->addEntity(reg);                   // add an entity to the entity group
        EG_addEntity(entGrp, reg);
        pPList flist = R_faces(reg, 0);
        void* it=0;
        while(face = (pFace)PList_next(flist, &it)) {

          if(face!=opp_face && face->getType()==TRI) {

            if (EN_onCB(face))
            {
              reg = 0;
              break;
            }

            int i=0;
            for(; i< F_numRegions(face); i++) {
              reg = F_region(face, i);
              if(reg!=opp_reg)
                break;
            }

            if(!reg || i==F_numRegions(face)) {
              cout<<"ERROR: the number of regions connected to a interior face is not correct. "<<endl;
              return 0;
            }

//          cout<<"oface:"<<oface<<","<<EN_getUid(oface)<<endl;
//          cout<<", face:"<<face<<","<<EN_getUid(face)<<endl;
            opp_face = face;
            opp_reg = reg;
            break;
          }
        }
        PList_delete(flist);
        if (!reg)
          break;
      }

      if (!reg)
        continue;

      /// Some stacks can endup with pyramids sitting on top of them, and there are no connected prisms!
      while (reg->getType() == PYRAMID)
      {
        EG_addEntity(entGrp, reg);
        num_added_ents++;
        for (int i = 1; i < 5; i++)
        {
          face = R_face(reg,i);
          if (face != opp_face)
          {
            int right_face = 1;
            for (int j = 0; j < 3; j++)
            {
              edge = F_edge(face,j);
              if (F_inClosure(opp_face,edge))
              {
                right_face = 0;
                break;
              }
            }
            if (right_face)
            {
              opp_face = face;
              opp_reg = reg;
              reg = F_region(face,0);
              if (reg == opp_reg)
                reg = F_region(face,1);
              break;
            }
          }
        }
        if (!reg)
          break;
      }

//    cout<<endl<<"**************************"<<endl;
    }
  }

  FIter_reset(fiter);

  /// Put PYRAMIDs in Entity Groups
  while(face=FIter_next(fiter))
  {
    /// The condition of checking for model boundary only is not enough - look at the pyramids where more than two triangular faces are classified of the 
    /// model boundary. Should check for the connection with the quad face through any of the edge of a pyramid - should be none.
    if(face->getType()==TRI && GEN_type(F_whatIn(face))==2) 
    {
      reg = F_region(face, 0);
      if(!reg)
        reg = F_region(face, 1);
      if(!reg)
      {
        cout<<"ERROR: no region is connected to a surface face. "<<endl;
        return 0;
      }
    }
    else
      continue;

    if(reg->getType() == PYRAMID) 
    {
      /// Check for the bottom of a pyramid such that triangular face and one of the prism next to it has the same model face
      GEntity* pGEntityGeomEnt = F_whatIn(face);
      pFace pFaceQuadFace = R_face(reg, 0);
      if (F_whatInType(pFaceQuadFace) == 2)
      {
        printf("QUAD face of the pyramid is on the model boundary as well!!!\n");
        exit(0);
      }

      if (!EN_onCB(pFaceQuadFace))
      {
        opp_reg = F_region(pFaceQuadFace, 0);
        if (opp_reg == reg)
          opp_reg = F_region(pFaceQuadFace, 1);

        if (opp_reg->getType() == PYRAMID)
          printf("Opposite region to pyramid is pyramid!!\n");

        opp_face = BL_GetZeroLvlFace(EN_getBL(opp_reg));
        if (F_whatIn(opp_face) != pGEntityGeomEnt)
          continue;
      }
      else
      {
        int iWrongFace = 0;
        for (int iEdge = 0; iEdge < 3; ++iEdge)
        {
          edge = F_edge(face, iEdge);
          for (int iFace = 0; iFace < E_numFaces(edge); ++iFace)
          {
            opp_face = E_face(edge, iFace);
            if (opp_face->getType() == QUAD && F_whatInType(opp_face) == 2)
            {
              iWrongFace = 1;
              break;
            }
          }
          if (iWrongFace)
            break;
        }
        if (iWrongFace)
          continue;
      }


      entGrp = M_createEntGrp(mesh, 3);
      count++;
//      cout<<"EntGrp"<<count<<": ";
    }
    else
      continue;

    opp_face = face;
    opp_reg = reg;

    while (reg->getType()== PYRAMID)
    {
      EG_addEntity(entGrp, reg);
      for (int i = 1; i < 5; i++)
      {
        face = R_face(reg,i);
        if (face != opp_face)
        {
          int right_face = 1;
          for (int j = 0; j < 3; j++)
          {
            edge = F_edge(face,j);
            if (F_inClosure(opp_face,edge))
            {
              right_face = 0;
              break;
            }
          }
          if (right_face)
          {
            opp_face = face;
            opp_reg = reg;
            reg = F_region(face,0);
            if (reg == opp_reg)
              reg = F_region(face,1);
            break;
          }
        }
      }
    }
  }

  FIter_reset(fiter);

  /// Put the first TET starting off the wall connected to either a PYRAMID or a PRISM into an entity group
  while(face=FIter_next(fiter))
  {
    /// The condition of checking for model boundary only is not enough - should find a tet where if the edge is connected to a quad face,
    /// the face classified on the model boundary does not have the edge in its closure.
    if(face->getType()==TRI && GEN_type(F_whatIn(face))==2)
    {
      reg = F_region(face, 0);
      if(!reg) 
        reg = F_region(face, 1);
      if(!reg)
      {
        cout<<"ERROR: no region is connected to a surface face. "<<endl;
        return 0;
      }
    }
    else
      continue;

    if (reg->getType() == TET)
    {
      /// Find the edge which connects tet with pyramids/prisms
      GEntity* pGEntityGeomEnt = F_whatIn(face);
      int iFoundEdge = 0;
      pPList redges = R_edges(reg, 0);
      for (int iEdge = 0; iEdge < 6; ++iEdge)
      {
        edge = (pEdge)PList_item(redges, iEdge);
        for (int iFace = 0; iFace < E_numFaces(edge); ++iFace)
        {
          opp_face = E_face(edge, iFace);
          if (opp_face->getType() == QUAD)
          {
            /// Find if the tet is adjacent with the pyramid and that pyramid is the first entity in the boundary layer
            /// NOTE: this is not going to be true with adjacent BL stack consisting of only 1 pyramid / prism + pyramid, if there is no adjacent prism due to the part boundary!
            opp_reg = F_region(opp_face, 0);
            if (opp_reg->getType() == PYRAMID)
              opp_reg = F_region(opp_face, 1);

            opp_face = BL_GetZeroLvlFace(EN_getBL(opp_reg));
            if (F_whatIn(opp_face) != pGEntityGeomEnt)
              continue;

/*
            opp_reg = F_region(opp_face, 0);
            if (opp_reg == reg)
              opp_reg = F_region(opp_face, 1);
*/

//            if (opp_reg && opp_reg->getType() != TET)
            if (opp_reg)
            {
              pBLayer pBLayerBL = EN_getBL(opp_reg);
              if (opp_reg == pBLayerBL->getEntity(0))
              {
                iFoundEdge = 1;
                break;
              }
            }
          }
        }
        if (iFoundEdge)
          break;
      }
   
      /// The found edge should be not in closure of the face classified on the model face
      if (iFoundEdge)
      {
        if (!F_inClosure(face, edge))
        {
          entGrp = M_createEntGrp(mesh, 3);
          count++;
          EG_addEntity(entGrp, reg);
        }
      }
    }
  }
  FIter_delete(fiter);

  /// Taking care of additional PYRAMIDs on top of PRISMs
  int eg_size;
  for (pBLIter egIt = Mesh_GetBegBLIter(mesh); egIt != Mesh_GetEndBLIter(mesh); ++egIt)
  {
    eg_size = EG_getNumOfEntities((pBLayer)(*egIt));
    reg = ((pBLayer)(*egIt))->getEntity(eg_size-1);
    if (reg->getType() != PRISM)
      continue;

    face = R_face(reg,0);
    if (F_whatInType(face) == 2)
      face = R_face(reg, 4);
    opp_reg = F_region(face,0);
    if (opp_reg == reg)
      opp_reg = F_region(face,1);
    if (opp_reg)
    {
      if(opp_reg->getType() == PRISM)
      {
        face = R_face(reg,4);
        opp_reg = F_region(face,0);
        if (opp_reg == reg)
          opp_reg = F_region(face,1);
        if (!opp_reg)
          continue;
      }
    }
    else
      continue;

    while (opp_reg->getType() == PYRAMID)
    {
      EG_addEntity((pBLayer)(*egIt), opp_reg);
      for (int i = 1; i < 5; i++)
      {
        opp_face = R_face(opp_reg,i);
        if (face != opp_face)
        {
          int right_face = 1;
          for (int j = 0; j < 3; j++)
          {
            edge = F_edge(opp_face,j);
            if (F_inClosure(face,edge))
            {
              right_face = 0;
              break;
            }
          }
          if (right_face)
          {
            face = opp_face;
            reg = opp_reg;
            opp_reg = F_region(face,0);
            if (reg == opp_reg)
              opp_reg = F_region(face,1);
            ++num_added_ents;
            break;
          }
        }
      }
      if (!opp_reg)
        break;
    }
  }

#ifdef DEBUG
  printf("Added %d pyramids to BLs in total on PID %d\n", num_added_ents, P_pid());
#endif

  /// Taking care of TETs
  for (pBLIter egIt = Mesh_GetBegBLIter(mesh); egIt != Mesh_GetEndBLIter(mesh); ++egIt)
  {
    int eg_size = EG_getNumOfEntities((pBLayer)(*egIt));
      reg = ((pBLayer)(*egIt))->getEntity(eg_size-1);
      if (reg->getType() == PRISM)
      {
        face = R_face(reg,0);
        if (F_whatInType(face) == 2)
          face = R_face(reg, 4);
        opp_reg = F_region(face,0);
        if (opp_reg == reg)
          opp_reg = F_region(face,1);
        if (opp_reg)
        {
          if(opp_reg->getType() != TET)
          {
            face = R_face(reg,4);
            opp_reg = F_region(face,0);
            if (opp_reg == reg)
              opp_reg = F_region(face,1);
            if (!opp_reg)
              continue;
          }
        }
        else
          continue;
      }
      else if (reg->getType() == PYRAMID)
      {
        /// PYRAMID
        /// Find the bottom-most face of the pyramid    
        pRegion pRegionRgnChk[2];
        for (int iFace = 1; iFace < 5; ++iFace)
        {
          opp_face = R_face(reg, iFace);
          pRegionRgnChk[0] = F_region(opp_face,0);
          pRegionRgnChk[1] = F_region(opp_face,1);
          if (EN_getBL(pRegionRgnChk[0]) == *egIt && ((pRegionRgnChk[1] && (EN_getBL(pRegionRgnChk[1]) == *egIt)) || !pRegionRgnChk[1]))
            break;
        }

        /// Find the top-most face connecting pyramid and a tet
        for (int iFace = 1; iFace < 5; ++iFace)
        {
          face = R_face(reg, iFace);
          if (face != opp_face)
          {
            int right_face = 1;
            for (int j = 0; j < 3; j++)
            {
              edge = F_edge(face,j);
              if (F_inClosure(opp_face,edge))
              {
                right_face = 0;
                break;
              }
            }
            if (right_face)
            {
//              opp_face = face;
//              opp_reg = reg;
              opp_reg = F_region(face,0);
              if (reg == opp_reg)
                opp_reg = F_region(face,1);
              break;
            }
          }
        }
      }
      else
      {
        /// Find a tet on top of the current one
        int iFoundEdge = 0;
        pPList redges = R_edges(reg, 0);
        for (int iEdge = 0; iEdge < 6; ++iEdge)
        {
          edge = (pEdge)PList_item(redges, iEdge);
          for (int iFace = 0; iFace < E_numFaces(edge); ++iFace)
          {
            face = E_face(edge, iFace);
            if (face->getType() == QUAD)
            {
              iFoundEdge = 1;
              break;
            }
          }
          if (iFoundEdge) 
            break;
        }

        if (iFoundEdge)
        {
          for(int iFace = 0; iFace < 4; ++iFace)
          {
            face = R_face(reg, iFace);
            if (!F_inClosure(face, edge) && F_whatInType(face) == 3)
            {
              opp_reg = F_region(face,0);
              if (reg == opp_reg)
                opp_reg = F_region(face,1);
              break;
            }
          }
        }
      }

      int iFoundQuad = 1;
      while(iFoundQuad)
      {

        if (EN_getBL(opp_reg) && EN_getBL(opp_reg) != *egIt)
        {
          break;
//          printf("WRONG STACK CONSTRUCTION!!! The entity is already grabbed by another entity group!\n");
//          exit(0);
        }

        iFoundQuad = 0;
        pEdge pEdgeFoundEdge;
        pRegion pRegionRgnChk[2];
        int iChkLvl[2] = {0, 0};
        pPList redges = R_edges(opp_reg, 0);
        for (int iEdge = 0; iEdge < 6; ++iEdge)
        {
          edge = (pEdge)PList_item(redges, iEdge);
          if (!F_inClosure(face,edge))
          {
            for (int k = 0; k < E_numFaces(edge); k++)
            {
              opp_face = E_face(edge,k);
              if (opp_face->getType() == QUAD)
              {
                /// Check if the regions of the quad face found are higher than the current one in the BL stacks
                /// Otherwise it might be a tet connecting two same level BLs consisting of prisms only, or pyramids or prisms and pyramids
                pRegionRgnChk[0] = F_region(opp_face, 0);
                pRegionRgnChk[1] = F_region(opp_face, 1);
                iChkLvl[0] = EN_getBL(pRegionRgnChk[0])->getEntityOrder(pRegionRgnChk[0]) + 1;
                if (pRegionRgnChk[1])
                  iChkLvl[1] = EN_getBL(pRegionRgnChk[1])->getEntityOrder(pRegionRgnChk[1]) + 1;
                if (iChkLvl[0] > eg_size || iChkLvl[1] > eg_size)
                {
                  iFoundQuad++;
                  pEdgeFoundEdge = edge;
                  break;
                }
              }
            }
          }
        }
        PList_delete(redges);

        if (iFoundQuad != 1)
        {
          break;
        }

        /// Found quad face adjacent to an edge of a tet, add the tet to the BL
        EG_addEntity((pBLayer)(*egIt), opp_reg);
        ++num_added_ents;
        ++eg_size;

        vtx = E_vertex(pEdgeFoundEdge, 0);
        if (F_inClosure(face,vtx))
          vtx = E_vertex(pEdgeFoundEdge, 1);
        for (int i = 0; i < 4; i++)
        {
          opp_face = R_face(opp_reg,i);
          if (face != opp_face)
          {
            if (F_inClosure(opp_face,vtx) && !F_inClosure(opp_face, pEdgeFoundEdge))
            {
              face = opp_face;
              break;
            }
          }
        }
        reg = opp_reg;
        opp_reg = F_region(face,0);
        if (reg == opp_reg)
          opp_reg = F_region(face,1);        
        if (!opp_reg)
          break;
      }
  }
#ifdef DEBUG
  printf("Added %d entities to BLs in total on PID %d\n", num_added_ents, P_pid());
#endif

  RIter riter = M_regionIter(mesh);
  while(reg=RIter_next(riter)) {
    if (reg->getType() == PRISM && !EN_getBL(reg))
    {
      printf("!!!!!!!!!! PRISM IS NOT A PART OF ANY BL, CAN'T DEAL WITH SUCH A CASE YET !!!!!!!\n");
      exit(0);
    }

    if (reg->getType() == PYRAMID && !EN_getBL(reg))
    {
      pPList rverts = R_vertices(reg, 0);
      pVertex pVertexVtx;
      for (int iVert = 0; iVert < 5; ++iVert)
        pVertexVtx = (pVertex)PList_item(rverts, iVert);
      printf("!!!!!!!!!! PYRAMID IS NOT A PART OF ANY BL, CAN'T DEAL WITH SUCH A CASE YET !!!!!!!\n");
      exit(0);
    }

  }
  RIter_delete(riter);

#ifdef DEBUG
  printf("Initial number of BLs on PID %d: %d\n", P_pid(), M_numEntGrps(mesh));
#endif
}

void Mesh_InitBLs(pMesh pMeshMesh, pGModel model, int iFromTopo)
{
  int iConstrFromTopo = 0;

  if (iFromTopo)
  {
    if (P_pid() == 0)
      printf("Constructing BLs from topology\n");

    Mesh_ConstructBLs(pMeshMesh);
    iConstrFromTopo = 1;
  }
  else 
  {
    if (P_pid() == 0)
      printf("Constructing BLs from P-sets\n");

    if (Mesh_ConstructBLs_EntSet(pMeshMesh))
      iConstrFromTopo = 1;
  }

  int iNumBLs;
// = M_getNumBLs(pMeshMesh);
  FMDB_Part_GetNumSet (pMeshMesh, &iNumBLs);
#ifdef MA_PARALLEL
  if (P_size() > 1)
  {
    int igNumBLs;
    MPI_Allreduce(&iNumBLs, &igNumBLs, 1, MPI_INT, MPI_SUM, ParUtil::Instance()->getComm());
    if (igNumBLs == 0)
      return;
    iNumBLs = igNumBLs;
  }
  if (P_pid() == 0)
#endif
    printf("The mesh has %d BLs\n", iNumBLs);

  if (iConstrFromTopo && iNumBLs)
  {
    Mesh_CategorizeBLEntities(pMeshMesh);
    Mesh_AssignBLLevelsToAllBLEnts(pMeshMesh);
  }

  Mesh_DetectAndLabelCornerNodes(pMeshMesh, model);

#ifdef MA_PARALLEL
  Mesh_UnifyBLInterfaceOnCB(pMeshMesh);
#endif

#ifdef DEBUG
  M_checkBLStructure(pMeshMesh);
#endif

  if (iNumBLs)
    Mesh_BLInfo(pMeshMesh);
}


#ifdef MA_PARALLEL
/// Can be figured out WITHOUT Communication - just see the diff of remote copies of the top-most
/// node and the node 1 level down from it. If the same - stacks are complete with all interface
/// regions on top of them. Otherwise some regions are detached.
void Mesh_GetBLTopVertConnToBLHangingVert(pMesh pMeshMesh, std::set<pVertex> &SetTopVerts)
{
  if (P_size() == 1)
    return;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(pEntity));
  pEntity* msg_send = (pEntity*)CM->alloc_msg(sizeof(pEntity));

  int num_sent = 0, num_recvd = 0;

  pVertex pVertexVtx;
  VIter viter = M_vertexIter(pMeshMesh);
  while(pVertexVtx = VIter_next(viter))
  {
    if(EN_isBLEntity((pEntity)pVertexVtx) && EN_onCB(pVertexVtx) && (EN_levelInBL(pVertexVtx) < 0))
    {
      for (mEntity::RCIter rciter=(pVertexVtx)->rcBegin(); rciter!=(pVertexVtx)->rcEnd(); ++rciter)
      {
        *msg_send = rciter->second;
        CM->send(rciter->first, (void*)msg_send);
        num_sent++;
      }
    }
  }
  VIter_delete(viter);
  CM->finalize_send();
  CM->free_msg(msg_send);

  pVertex pVertexTopNode;
  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    pVertexTopNode = *(pEntity*)msg_recv;

    /// It might be a hanging vertex as well!
    if (EN_levelInBL(pVertexTopNode) >= 0)
      SetTopVerts.insert(pVertexTopNode);
    CM->free_msg(msg_recv);
  }
}
#endif

/// This function MUST be simplified  - for example, get the information about migrated BLs and identify, which
/// entities are going to be hanging. Maybe provide one round of communication if doing it post-factum, i.e.
/// get the newly moved BLs, find from their top faces which of them will be hanging on the parts they are migrated from
/// and communicate to clean the hanging BL entities levels.
/// Need to traverse entities separately and not go through adjacencies because hanging edge might
/// not have hanging vertices, hanging face might not have handing edges and/or vertices.
void Mesh_ClrHangingBLEntLvl(pMesh pMeshMesh)
{
  pVertex pVertexVtx;
  pEdge pEdgeEdge;
  pFace pFaceFace;
  pRegion pRegionReg;

  std::vector<pRegion> Vec_BLRegs;
  VIter viter = M_vertexIter(pMeshMesh);
  while(pVertexVtx = VIter_next(viter))
  {
    if(EN_isBLEntity((pEntity)pVertexVtx) && EN_onCB(pVertexVtx) && (EN_levelInBL(pVertexVtx) >= 0))
    {
      V_BLRegions(pVertexVtx, Vec_BLRegs);
      if (Vec_BLRegs.size() == 0)
        Ent_ClrBLEntLvl((pEntity)pVertexVtx);
    }
  }
  VIter_delete(viter);

  EIter eiter = M_edgeIter(pMeshMesh);
  while(pEdgeEdge = EIter_next(eiter))
  {
    if(EN_isBLEntity((pEntity)pEdgeEdge) && EN_onCB(pEdgeEdge) && (EN_levelInBL(pEdgeEdge) >= 0))
    {
      E_BLRegions(pEdgeEdge, Vec_BLRegs);
      if (Vec_BLRegs.size() == 0)
        Ent_ClrBLEntLvl((pEntity)pEdgeEdge);
    }
  }
  EIter_delete(eiter);

  FIter fiter = M_faceIter(pMeshMesh);
  while(pFaceFace = FIter_next(fiter))
  {
    if(EN_isBLEntity((pEntity)pFaceFace) && EN_onCB(pFaceFace) && (EN_levelInBL(pFaceFace) >= 0))
    {
      pRegionReg = F_region(pFaceFace,0);
      if (EN_isBLEntity(pRegionReg))
        continue;
      pRegionReg = F_region(pFaceFace,1);
      if (pRegionReg && EN_isBLEntity(pRegionReg))
        continue;
      Ent_ClrBLEntLvl((pEntity)pFaceFace);
    }
  }
  FIter_delete(fiter);
}


// do NOT use any BL info. (can be used for a general mesh)
double XYZ_volume2(dArray *X_Y_Z, int rTopoType) 
{
  int numChildTets;
  int elemType;
  // fit two tets. in a pyramid
  // (diagonal edge of a pyramid is : V0-V2)
  // fit three tets. in a prism/wedge
  // (diagonal edges of a prism are : V0-V4, V1-V5 and V5-V0)
  int tetVerts[3][4] = {0,1,2,5, 0,1,5,4, 0,4,5,3};
  int mapNodes[3][3][4] ={{{0,1,2,3}, {-1,-1,-1,-1}, {-1,-1,-1,-1}},
                          {{0,1,2,4}, {0,2,3,4}, {-1,-1,-1,-1}},
                          {{0,1,2,5}, {0,1,5,4}, {0,4,5,3}}};

  switch(rTopoType) {
  case TET :
    numChildTets = 1;
    elemType = 0;
    break;
  case PYRAMID :
    numChildTets = 2;
    elemType = 1;
    break;
  case PRISM :
    numChildTets = 3;
    elemType = 2;
    break;
  default:
    cout<<"\nError in XYZ_volume2()..."<<endl;
    cout<<"region topology ["<<rTopoType<<"] NOT supported"<<endl;
    exit(0);
  }

  double sub_volume, volume = 0.;
  dArray sub_xyz[4];
  for(int iTet=0; iTet<numChildTets; iTet++) {
    for(int iTVert=0; iTVert<4; iTVert++)
      for(int iComp=0; iComp<3; iComp++)
        sub_xyz[iTVert][iComp] = X_Y_Z[mapNodes[elemType][iTet][iTVert]][iComp];

    sub_volume = XYZ_volume(sub_xyz);
    if(sub_volume<0.)
      return -1.;
    volume += sub_volume;
  }

  return volume;

}


double BL_GetNormalUnstrHeight(pVertex pVertexVtx, double dNormal[3])
{
  int iNumEdges = V_numEdges(pVertexVtx);
  int iNonBLEdges = 0;
  double dNormalUnstrHeight = 0, dProjEdgeLen;
  double dVtxCoords[2][3], dVec[3];
  pVertex pVertexOppVtx;
  pEdge pEdgeEdge;

  /// Top-node coordinates
  V_coord(pVertexVtx, dVtxCoords[0]);
  for (int iEdge = 0; iEdge < iNumEdges; ++iEdge)
  {
    pEdgeEdge = V_edge(pVertexVtx, iEdge);
    if (!E_typeInBL(pEdgeEdge))
    {
      pVertexOppVtx = E_vertex(pEdgeEdge, 0);
      if (pVertexOppVtx == pVertexVtx)
        pVertexOppVtx = E_vertex(pEdgeEdge, 1);
      V_coord(pVertexOppVtx, dVtxCoords[1]);
      diffVt(dVtxCoords[1], dVtxCoords[0], dVec);
      dProjEdgeLen = dotProd(dVec, dNormal);      
      dNormalUnstrHeight += dProjEdgeLen;
      iNonBLEdges++;
    }
  }
  if (iNonBLEdges)
    dNormalUnstrHeight /= iNonBLEdges;

  return dNormalUnstrHeight;
}


void BL_LimitFirstLayerThickness(double dCurFirstLayerThickness, double &dPropFirstLayerThickness, double dGrowthFactor, double dNormalUnstr, int iNumLayer)
{
  double dDeltaThickness = dPropFirstLayerThickness - dCurFirstLayerThickness;
   
  double dSumGrowthFactor = 1., dMultGrowthFactor = dGrowthFactor;
  /// Calculate the summ of growth factors, i.e. Sum(g^i-1), where i = 1..iNumLayer
  for (int iIt = 1; iIt < iNumLayer; ++iIt)
  {
    dSumGrowthFactor += dMultGrowthFactor;
    dMultGrowthFactor *= dGrowthFactor;
  }
  
  /// Calculate the maximum allowed difference for the change of the first layer thickness
  double dThicknessLimit = 0.5 * dNormalUnstr / dSumGrowthFactor;
  if (fabs(dDeltaThickness) > dThicknessLimit)
  {
    if (dDeltaThickness < 0.)
       dThicknessLimit = -1 * dThicknessLimit;
    dPropFirstLayerThickness = dCurFirstLayerThickness + dThicknessLimit;
  }
}


void BL_CalcThicknessesUsingFirstThicknessAndGrowthFactor(double dFirstLayerThickness, double dGrowthFactor, double *thicknesses, int listSize)
{
  thicknesses[0] = dFirstLayerThickness;

  /// Calculate hieghts having in hand the first nodal spacing off the wall and growth factor.
  for (int iLayer = 1; iLayer < listSize-1; ++iLayer)
  {
    thicknesses[iLayer] = thicknesses[iLayer-1] * dGrowthFactor;
  }
}


void BL_geomProg(double h0, double H, int nLevels, double *thicknesses, double rmin, double rmax, int h0flag) {
  /* nLevels including zero, e.g., for 10 layers nLevels will be 11 */
  /* Calculate the base/ratio for geometric series by Newton-Raphson method */
  double r = BL_rtNewton(H, 0., h0, nLevels);

  double h0_mod = h0;
  if(rmin>0.0 && r<rmin)
    r = rmin;
  if(rmax>0.0 && r>rmax)
    r = rmax;

  if(h0flag)
    h0_mod = H*(r-1.0)/(pow(r,nLevels-1)-1.0);

  BL_CalcThicknessesUsingFirstThicknessAndGrowthFactor(h0_mod, r, thicknesses, nLevels);
/*
  thicknesses[0] = h0_mod;
  for (int n=1; n<nLevels-1; n++)
    thicknesses[n] = r*thicknesses[n-1];
*/
}


double BL_rtNewton(double fmx, double fmin, double dfm, int npt) {
  int    NewtonIter = 100 ;
  double NewtonConv = 1.e-07;
  double eps, ep1tn, reps, f, dfmoe, dfmoe2, dd, fpn;

  if (npt <= 1) {
    cout<<"\nError in BL_rtNewton()..."<<endl;
    cout<<"Total # of points should be > 1\n"<<endl;
    exit(0);
  }

  if (npt == 2) {
    eps = 1;
    return eps;
  }
  else {
    eps = pow((fmx/dfm),(1.0/(npt-2)));
    for(int n=0 ; n<NewtonIter ; n++ ) {
      ep1tn = pow(eps,(npt-2));
      reps = 1.0/(eps-1);
      dfmoe = dfm*reps;
      f = fmx - fmin - dfmoe*(ep1tn*eps-1.0);
      if( fabs(f)<NewtonConv )
        return eps;
     else {
        dfmoe2 = dfmoe*reps;
        fpn = dfmoe2*(1.0 + ep1tn*((eps-1)*(npt-2)-1.0));
        dd = f/fpn;
        eps = eps + dd;
      }
    }
  }

  cout<<"\nError in BL_rtNewton()..."<<endl;
  cout<<"max. # of iterations exceeded\n"<<endl;
  exit(0);
}


void Mesh_GetNormalVectorOfOrigVtx(pMesh pmesh)
{
#ifdef MA_PARALLEL
  pVertex vertex;
  void *vVal;
  std::set<int>::iterator SetIt;
  pMeshDataId pGFaceTag = MD_newMeshDataId("Geom Faces for originating BL Vtx");

  /// Initialize IPComMan
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  int num_sent = 0, num_recvd = 0;
  int iSize;
  CM->set_fixed_msg_size(0);
  void* msg_send;
  pVertex* vtxSend; 
  int* iSend;

  int iNumGFace, dirFactor;

  VIter viter = M_vertexIter(pmesh);
  while(vertex = VIter_next(viter))
  {
    if(!V_isOriginatingNode(vertex))
      continue;

    if (EN_getDataPtr(vertex, gcNormalTag, &vVal))
      continue;

  // zero normal is set for corner ndoe
//  if(V_isCornerONode(vertex))
//    return;

  double normalVector[3];
  std::set<int> *SetGFaceBL;
  pGEntity vertClassifiedOnGEntity = V_whatIn(vertex);
  // either model face, model edge, or model vertex
  int vertClassifiedOnType = V_whatInType(vertex);
  int tagGFace;
  pGFace gface;
  pFace face;

  switch(vertClassifiedOnType) {
  case 0:
    // vertex is classified on model vertex
    // that is in closure of boundary layer surface with tag=surfTag
    {
      // all model faces around the vertex
      pPList v_faces = V_faces(vertex);
      pPList gv_gfaces = GV_faces((pGVertex)vertClassifiedOnGEntity);

      if (!EN_onCB(vertex))
      {
        for(int iComp=0; iComp<3; iComp++)
          normalVector[iComp] = 0.;
      }

      iNumGFace = PList_size(gv_gfaces);
      SetGFaceBL = new std::set<int>;

      pGRegion GReg;
      pPList gv_gregs = GV_regions((pGVertex)vertClassifiedOnGEntity);
      if(PList_size(gv_gregs)!=1) 
      {
//        cout<<"\nError in getNormalVector()..."<<endl;
//        cout<<"case 0 : non-manifold model encountered"<<endl;
//**        exit(0);
      }
      GReg = (pGRegion)PList_item(gv_gregs,0);
      PList_delete(gv_gregs);
      // loop over these faces
      for(int iFace =0; iFace<PList_size(v_faces); iFace++) 
      {
        face = (pFace)PList_item(v_faces,iFace);
        // tagGFace = GEN_tag((GFace*)gface);

        // if(tagGFace==surfTag) {
//        if(GEN_isBLSurface((pGEntity)gface)) {
/// !!!!!! WARNING! This condition from the line above should be somehow built on FMDB side - we NEED to tag model faces
/// having BLs on them from the very beginning, since the BLs can be destroyed due to aspect ratio but we still need to know
/// how many of the connected model entities carries BLs on it

        if (F_typeInBL(face) == fLAYER && F_whatInType(face) == 2)
        {
          gface = (pGFace)F_whatIn(face); 
          tagGFace = GEN_tag((GEntity*)gface);
          if (SetGFaceBL->count(tagGFace))
            continue;

          /// Collect GFaces where BLs are defined
          SetGFaceBL->insert(tagGFace);
    
          /// Do not calculate things here, calculate them when all the info on PB is unified
          if (EN_onCB(vertex))
            continue;

          double fparametric[2];
          GF_vertexReparam(gface, (pGVertex)vertClassifiedOnGEntity, fparametric);

          double normal[3];
          GF_normal(gface,fparametric,normal);

          if(GF_region(gface,0)==GReg)
            dirFactor = -1;
          else
            dirFactor = 1;

          for(int iComp=0; iComp<3; iComp++)
            normalVector[iComp] += dirFactor*normal[iComp];

          // break;
        }
      }
      PList_delete(v_faces);
      PList_delete(gv_gfaces);
    }
    break;
  case 1:
    // vertex is classified on model edge
    // that is in closure of boundary layer surface with tag=surfTag
    {
      pPoint point;
      point = V_point(vertex);

      double par1 = P_param1(point);

      // all model faces around the model edge
      // (on which vertex is classified)
      pPList e_faces = E_faces(vertex);
      pPList ge_gfaces = GE_faces((pGEdge)vertClassifiedOnGEntity);

      if (!EN_onCB(vertex))
      {
        for(int iComp=0; iComp<3; iComp++)
          normalVector[iComp] = 0.;
      }

      iNumGFace = PList_size(ge_gfaces);
      SetGFaceBL = new std::set<int>;

      pGRegion GReg;
      pPList ge_gregs = GE_regions((pGEdge)vertClassifiedOnGEntity);
      if(PList_size(ge_gregs)!=1) 
      {
//        cout<<"\nError in getNormalVector()..."<<endl;
//        cout<<"case 1 : non-manifold model encountered"<<endl;
//**        exit(0);
      }
      GReg = (pGRegion)PList_item(ge_gregs,0);
      PList_delete(ge_gregs);

      for(int iFace =0; iFace<PList_size(e_faces); iFace++) {

        face = (pFace)PList_item(e_faces,iFace);
        // tagGFace = GEN_tag((GFace*)gface);

        // if(tagGFace==surfTag) {
//        if(GEN_isBLSurface((pGEntity)gface)) {
/// !!!!!! WARNING! This condition from the line above should be somehow built on FMDB side - we NEED to tag model faces
/// having BLs on them from the very beginning, since the BLs can be destroyed due to aspect ratio but we still need to know
/// how many of the connected model entities carries BLs on it

        if (F_typeInBL(face) == fLAYER && F_whatInType(face) == 2)
        {
          gface = (pGFace)F_whatIn(face);
          tagGFace = GEN_tag((GEntity*)gface);
          if (SetGFaceBL->count(tagGFace))
            continue;

          SetGFaceBL->insert(tagGFace);

          /// Do not calculate things here, calculate them when all the info on PB is unified
          if (EN_onCB(vertex))
            continue;

          int eDir = GF_edgeDir(gface, (pGEdge)vertClassifiedOnGEntity);
          double fparametric[2];
          GF_edgeReparam(gface, (pGEdge)vertClassifiedOnGEntity, par1, eDir,fparametric);

          double normal[3];
          GF_normal(gface,fparametric,normal);

          if(GF_region(gface,0)==GReg)
            dirFactor = -1;
          else
            dirFactor = 1;

          for(int iComp=0; iComp<3; iComp++)
            normalVector[iComp] += dirFactor*normal[iComp];

          // break;
        }
      }
      PList_delete(e_faces);
      PList_delete(ge_gfaces);
    }
    break;
  case 2: // vertex is classified on boundary layer surface with tag=surfTag
    {
      tagGFace = GEN_tag((pGEntity)vertClassifiedOnGEntity);
/*
      if(tagGFace!=surfTag) {
        cout<<"\nError in getNormalVector()..."<<endl;
        cout<<"surface tag ["<<surfTag<<"] is NOT same as tag ["<<tagGFace<<"] of model surface on which vertex is classified"<<endl;
        exit(0);
      }
      if(!GEN_isBLSurface((pGEntity)vertClassifiedOnGEntity)) {
        cout<<"\nError in getNormalVector()..."<<endl;
        cout<<"surface tag ["<<surfTag<<"] for model surface tag ["<<tagGFace<<"] on which vertex is classified is NOT tagged as BL surface"<<endl;
        exit(0);
      }
*/

//      normalVector = new double[3];
      for(int iComp=0; iComp<3; iComp++)
        normalVector[iComp] = 0.;

      pGRegion GReg;
      pPList gf_gregs = GF_regions((pGFace)vertClassifiedOnGEntity);
      if(PList_size(gf_gregs)!=1) 
      {
//        cout<<"\nError in getNormalVector()..."<<endl;
//        cout<<"case 2 : non-manifold model encountered"<<endl;
//**        exit(0);
      }
      GReg = (pGRegion)PList_item(gf_gregs,0);
      PList_delete(gf_gregs);

      pPoint point;
      point = V_point(vertex);

      double par1,par2;
      P_param2(point,&par1,&par2,0);

      double fparametric[2] = {par1,par2};

      double normal[3];
      GF_normal((pGFace)vertClassifiedOnGEntity,fparametric,normal);

      if(GF_region((pGFace)vertClassifiedOnGEntity,0)==GReg)
        dirFactor = -1;
      else
        dirFactor = 1;

      for(int iComp=0; iComp<3; iComp++)
        normalVector[iComp] = dirFactor*normal[iComp];
    }
    break;
  }

  if (EN_onCB(vertex) && vertClassifiedOnType < 2)
  {
    /// Attach set of geom face tags to combine all them later after similar sets are received from other parts
    EN_attachDataPtr(vertex, pGFaceTag, (void*)SetGFaceBL);

    int iNumGFace = SetGFaceBL->size();
    iSize = sizeof(pVertex) + iNumGFace*sizeof(int);
    msg_send = CM->alloc_msg(iSize);
    vtxSend = (pVertex*)msg_send;
    iSend = (int*)((char*)msg_send + sizeof(pMeshEnt));

    std::vector<std::pair<int, pMeshEnt> > VtxRemCpy;
    FMDB_Ent_GetAllRmt(vertex, VtxRemCpy);

    int iGFace = 0;
    for (SetIt = SetGFaceBL->begin(); SetIt != SetGFaceBL->end(); ++SetIt)
    {
      iSend[iGFace] = *SetIt;
      iGFace++;
    }

    for (int iRC = 0; iRC < VtxRemCpy.size(); ++iRC)
    {
      *vtxSend = VtxRemCpy[iRC].second;
      CM->send(VtxRemCpy[iRC].first, msg_send, iSize);
      CM->free_msg(msg_send);
      num_sent++;
    }

  }
  else
  {
    if (vertClassifiedOnType < 2)
      delete SetGFaceBL;

    /// Should set the normal vector, the normalization is done inside
    GC_setNormalVector(vertex, normalVector);
  }

  }
  VIter_reset(viter);

  CM->finalize_send();

  void* msg_recv;
  int pid_from;
  // recieve phase
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    vtxSend = (pVertex*)msg_recv;
    vertex = *vtxSend;
    iSend = (int*)((char*)msg_recv + sizeof(pVertex));

    iNumGFace = (rc - sizeof(pVertex)) / sizeof(int);
    if(!EN_getDataPtr(vertex, pGFaceTag, &vVal))
    {
      printf("Error! The vertex classified on model vertex or edge should on PB should have a list of geom faces defined!\n");
      throw 0;
    }

    /// Add geom face tags to the existent ones for the current vertex
    std::set<int> *SetGFaceBL = (std::set<int> *)vVal;
    for (int iGFace = 0; iGFace < iNumGFace; ++iGFace)
      SetGFaceBL->insert(iSend[iGFace]);

    CM->free_msg(msg_recv);
  }

  /// Set up normals for vertices on PB classified either on model vertex or a model edge
  while(vertex = VIter_next(viter))
  {
    if(!V_isOriginatingNode(vertex))
      continue;
 
    if (!EN_onCB(vertex))
      continue;

    int vertClassifiedOnType = V_whatInType(vertex);
    if (vertClassifiedOnType == 2)
      continue;

    if (EN_getDataPtr(vertex, gcNormalTag, &vVal))
      continue;

    if(!EN_getDataPtr(vertex, pGFaceTag, &vVal))
    {
      printf("Error! The vertex classified on model vertex or edge should on PB should have a list of geom faces defined!\n");
      throw 0;
    }
    std::set<int> *SetGFaceBL = (std::set<int> *)vVal;

    double normalVector[3];
    for(int iComp=0; iComp<3; iComp++)
      normalVector[iComp] = 0.;

    pGEntity vertClassifiedOnGEntity = V_whatIn(vertex);
    int tagGFace;
    pGFace gface;
    pFace face;    

  switch(vertClassifiedOnType) {
  case 0:
    {
      // all model faces around the vertex
      pPList gv_gfaces = GV_faces((pGVertex)vertClassifiedOnGEntity);

      pGRegion GReg;
      pPList gv_gregs = GV_regions((pGVertex)vertClassifiedOnGEntity);
      GReg = (pGRegion)PList_item(gv_gregs,0);
      PList_delete(gv_gregs);
      // loop over these faces
      for(int iGFace =0; iGFace<PList_size(gv_gfaces); iGFace++) 
      {
        gface = (pGFace)PList_item(gv_gfaces,iGFace);
        tagGFace = GEN_tag((GEntity*)gface);
        if (!SetGFaceBL->count(tagGFace))
          continue;

          double fparametric[2];
          GF_vertexReparam(gface, (pGVertex)vertClassifiedOnGEntity, fparametric);

          double normal[3];
          GF_normal(gface,fparametric,normal);

          if(GF_region(gface,0)==GReg)
            dirFactor = -1;
          else
            dirFactor = 1;

          for(int iComp=0; iComp<3; iComp++)
            normalVector[iComp] += dirFactor*normal[iComp];

          // break;
      }
      PList_delete(gv_gfaces);
    }
    break;
  case 1:
    {
      pPoint point;
      point = V_point(vertex);

      double par1 = P_param1(point);

      // all model faces around the model edge
      // (on which vertex is classified)
      pPList ge_gfaces = GE_faces((pGEdge)vertClassifiedOnGEntity);

      pGRegion GReg;
      pPList ge_gregs = GE_regions((pGEdge)vertClassifiedOnGEntity);
      GReg = (pGRegion)PList_item(ge_gregs,0);
      PList_delete(ge_gregs);

      for(int iGFace =0; iGFace<PList_size(ge_gfaces); iGFace++) 
      {
        gface = (pGFace)PList_item(ge_gfaces,iGFace);
        tagGFace = GEN_tag((GEntity*)gface);
        if (!SetGFaceBL->count(tagGFace))
          continue;

          int eDir = GF_edgeDir(gface, (pGEdge)vertClassifiedOnGEntity);
          double fparametric[2];
          GF_edgeReparam(gface, (pGEdge)vertClassifiedOnGEntity, par1, eDir,fparametric);

          double normal[3];
          GF_normal(gface,fparametric,normal);

          if(GF_region(gface,0)==GReg)
            dirFactor = -1;
          else
            dirFactor = 1;

          for(int iComp=0; iComp<3; iComp++)
            normalVector[iComp] += dirFactor*normal[iComp];

          // break;
      }
      PList_delete(ge_gfaces);
    }
    break;
  }

    /// Should set the normal vector, the normalization is done inside
    GC_setNormalVector(vertex, normalVector);
    delete SetGFaceBL;
    EN_deleteData(vertex, pGFaceTag);

  }
  VIter_delete(viter);

  MD_deleteMeshDataId(pGFaceTag);
#endif
}


void M_checkBLEdgesAndVerts(pMesh mesh)
{
  if (M_numEntGrps(mesh) == 0)
    return;

  pEdge lp_Edge;
  EIter eit = M_edgeIter(mesh);
  while (lp_Edge = EIter_next(eit))
  {
    if (E_typeInBL(lp_Edge))
    {
      if (!(V_typeInBL(E_vertex(lp_Edge, 0)) && V_typeInBL(E_vertex(lp_Edge, 1))))
      {
        double xyz[2][3];
        V_coord(E_vertex(lp_Edge, 0), xyz[0]);
        V_coord(E_vertex(lp_Edge, 1), xyz[1]);
        printf("ERROR!!! The vertices are supposed to be BL vertices!\n");
      }
    }
  }
  EIter_delete(eit);
}


void M_checkBLFacesAndAdjRegions(pMesh mesh)
{
  if (M_numEntGrps(mesh) == 0)
    return;

  FIter fit = M_faceIter(mesh);
  pFace face;
  pRegion reg[2];
  while(face = FIter_next(fit)) {
    int f_type = F_typeInBL(face);
    if (f_type == fLAYER || f_type == fTRANSITION)
    {
      if (F_numRegions(face) > 2)
      {
        printf("ERROR!!! More than 2 regions are adjacent to face\n");
        exit(0);
      }

      reg[0] = F_region(face,0);
      reg[1] = F_region(face,1);
      if (!R_isBLEntity(reg[0]) && (reg[1] && !R_isBLEntity(reg[1])))
      {
        printf("ERROR!!! Regions adjacent to the BL face are not BL regions\n");
        exit(0);
      }
    }
  }
  FIter_delete(fit);
}


void BL_checkBLStructure(pBLayer pbl)
{
  pRegion reg;
  pRegion face;
  pEdge edge;
  pVertex vert;
  int level, maxBLLevel = 100;
  pBLEntIter entBegIter = BL_GetBegEntIter(pbl);
  pBLEntIter entEndIter = BL_GetEndEntIter(pbl);
  pBLEntIter entIter;

  for (entIter = entBegIter; entIter != entEndIter; entIter++)
  {
    reg = *entIter;
    if (reg->getType() != PRISM)
    {
      printf("BL region is not prism on PID %d!!!\n", P_pid());
//      exit(0);
    }

    level = EN_levelInBL(reg);
    if (level < 0 || level > maxBLLevel)
    {
      printf("Wrong level of a region on PID %d!!!\n", P_pid());
      pPList rverts = R_vertices(reg,1);
      double xyz[5][3];
      for (int iVert = 0; iVert < PList_size(rverts); ++iVert)
      {
        V_coord((pVertex)PList_item(rverts, iVert), xyz[iVert]);
        printf ("Vertex %d: %f, %f, %f\n", iVert, xyz[iVert][0], xyz[iVert][1], xyz[iVert][2]);
      }
      PList_delete(rverts);
      exit(0);
    }
    for (int iFace = 0; iFace < R_numFaces(reg); iFace++)
    {
      face = R_face(reg, iFace);
      if(!F_typeInBL(face))
      {
        printf("The BL face is not categorized!!!\n");
        exit(0);
      }
      level = EN_levelInBL(face);
      if (level < 0 || level > maxBLLevel)
      {
        printf("Wrong level of a face!!!\n");
        exit(0);
      }
      for (int iEdge = 0; iEdge < F_numEdges(face); iEdge++)
      {
        edge = F_edge(face, iEdge);
        if(!E_typeInBL(edge))
        {
          printf("The BL edge is not categorized!!!\n");
          exit(0);
        }
        level = EN_levelInBL(edge);
        if (level < 0 || level > maxBLLevel)
        {
          printf("Wrong level of an edge!!!\n");
          exit(0);
        }
        for (int iVert = 0; iVert < 2; iVert++)
        {
          vert = E_vertex(edge, iVert);
          if(!V_typeInBL(vert))
//          if(!V_typeInBL(vert) && reg->getType() == PRISM)
          {
            printf("The BL vertex is not categorized!!!\n");
            exit(0);
          }
          level = EN_levelInBL(vert);
          if (level < 0 || level > maxBLLevel)
          {
            printf("Wrong level of a vertex!!!\n");
            exit(0);
          }
//          if (F_inClosure(BL_GetZeroLvlFace(pbl), (pEntity)vert) && !V_isOriginatingNode(vert))
          if (EN_levelInBL(vert) == 0 && !V_isOriginatingNode(vert))
          {
            printf("Zero level vertex should be originating!!!\n");
            exit(0);
          }
        }
      }
    }
  }
}


void M_checkBLStructure(pMesh mesh)
{
  if (M_numEntGrps(mesh) == 0)
    return;

int iCount = 0;
  for (pBLIter egIt = Mesh_GetBegBLIter(mesh); egIt != Mesh_GetEndBLIter(mesh); egIt++)
  {
iCount++;
    BL_checkBLStructure((pBLayer)(*egIt));
  }

  FIter fit = M_faceIter(mesh);
  pFace face;
  while(face = FIter_next(fit)) 
  {
    int f_type = F_typeInBL(face);
    if (f_type)
    {
      int iNumBLs = 0;
      for (int iRgn = 0; iRgn < F_numRegions(face); ++iRgn)
        if (R_typeInBL(F_region(face, iRgn)))
          iNumBLs++;

      if (iNumBLs == 0 && !EN_onCB(face))
      {
        printf("ERROR!!! BL face has no BL regions adjacent to it\n");
        exit(0);
      }

    }
  }
  FIter_delete(fit);

  pRegion pRegionRgn;
  RIter rit = M_regionIter(mesh);
  while(pRegionRgn = RIter_next(rit))
  {
    if ((EN_getBL(pRegionRgn) && !R_typeInBL(pRegionRgn)) || (!EN_getBL(pRegionRgn) && R_typeInBL(pRegionRgn)))
    {
      printf("ERROR!!! inconsistency in labling of BL region\n");
      exit(0);
    }
  }
  RIter_delete(rit);
}


void M_checkBLPresence(pMesh mesh)
{
  if (M_numEntGrps(mesh) == 0)
    return;

  pFace face;
  pRegion reg;
  FIter fiter = M_faceIter(mesh);
  while(face=FIter_next(fiter)) {

    if(face->getType()==TRI && GEN_type(F_whatIn(face))==2) 
    {                  // on model face
      reg = F_region(face, 0);
      if(!reg)
        reg = F_region(face, 1);
      if(!reg) 
      {
        cout<<"ERROR: no region is connected to a surface face. "<<endl;
        exit(0);
      }

      if(reg->getType() == PRISM) 
      {
        if (!EN_getBL(reg))
        {
          printf("ERROR! BL region (PRISM on the wall) is not assigned to any BL\n");
          exit(0);
        }
      }
    }
  }
  FIter_delete(fiter);
}


void M_checkBLSplitFaces(pMesh pmesh)
{
  if (M_numEntGrps(pmesh) == 0)
    return;

  pFace face;
  pBLIter egBegIter = Mesh_GetBegBLIter(pmesh);
  pBLIter egEndIter = Mesh_GetEndBLIter(pmesh);
  pBLIter egIter;

  for (egIter = egBegIter; egIter != egEndIter; egIter++)
  {
    pBLayer pbl = (pBLayer)(*egIter);
    vector<pFace> facesChk;
    BL_getHorizontalFaces(pbl, facesChk);
    for (int iFace = 1; iFace < facesChk.size(); ++iFace)
    {
      face = facesChk[iFace];
      if (!EN_onCB(face) && F_whatInType(face) == 3)
      {
        if (F_numRegions(face) < 2)
        {
          printf("Error! Less than 2 faces for the internal face");
          double xyz[3][3];
          for (int iVert = 0; iVert < 3; ++iVert)
            V_coord(F_vertex(face,iVert), xyz[iVert]);
        }
      }
    }
  }
}


int Mesh_CheckVtxCoordsOnPB(pMesh pmesh)
{
#ifdef MA_PARALLEL
  if (SCUTIL_CommSize() == 1)
    return 1;

  /// Initialize IPComMan
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  int num_sent = 0, num_recvd = 0;
  int iSize = sizeof(pVertex) + 3*sizeof(double);
  CM->set_fixed_msg_size(iSize);
  void *msg_send = CM->alloc_msg(iSize);
  pVertex *vtxSend = (pVertex*)msg_send;
  double *dSend = (double*)((char*)msg_send + sizeof(pVertex));

  pVertex pVertexVtx;
  double eps = 1e-12;
  int iMismatch = 0;
  VIter viter = M_vertexIter(pmesh);
  while(pVertexVtx = VIter_next(viter))
  {
    if(EN_onCB(pVertexVtx))
    {
      std::vector<std::pair<int, pMeshEnt> > VtxRemCpy;
      FMDB_Ent_GetAllRmt(pVertexVtx, VtxRemCpy);

      dSend[0]=P_x(pVertexVtx);
      dSend[1]=P_y(pVertexVtx);
      dSend[2]=P_z(pVertexVtx);

      for (int iRC = 0; iRC < VtxRemCpy.size(); ++iRC)
      {
        *vtxSend = VtxRemCpy[iRC].second;
        CM->send(VtxRemCpy[iRC].first, msg_send);
        num_sent++;
      }
    }
  }
  VIter_delete(viter);
  CM->finalize_send();
  CM->free_msg(msg_send);

  void* msg_recv;
  int pid_from;
  // recieve phase
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    vtxSend = (pVertex*)msg_recv;
    pVertexVtx = *vtxSend;
    dSend = (double*)((char*)msg_recv + sizeof(pVertex));

    if (fabs(P_x(pVertexVtx) - dSend[0]) > eps || fabs(P_y(pVertexVtx) - dSend[1]) > eps || fabs(P_z(pVertexVtx) - dSend[2]) > eps)
      iMismatch = 1;

    CM->free_msg(msg_recv);
  }

  if(M_getMaxNum(iMismatch))
    return 0;

#endif
  return 1;
}


/*
/// For debugging: check several consistencies between remote copies of entities in BLs 
void checkEGRemCps(pMesh mesh, pMeshDataId ptr_reff, pMeshDataId int_reff)
{
  pRegion reg;
  pRegion face;
  pEdge edge;
  pVertex vert;
  set<pEntity> bndryEGEnts[3];
  for (pBLIter egIt = Mesh_GetBegBLIter(mesh); egIt != Mesh_GetEndBLIter(mesh); egIt++)
  {
    pBLEntIter entBegIter = BL_GetBegEntIter(*egIt);
    pBLEntIter entEndIter = BL_GetEndEntIter(*egIt);
    pBLEntIter entIter;
    for (entIter = entBegIter; entIter != entEndIter; entIter++)
    {
      reg = *entIter;
      for (int i = 0; i < R_numFaces(reg); i++)
      {
        face = R_face(reg, i);
        for (int j = 0; j < F_numEdges(face); j++)
        {
          edge = F_edge(face, j);
          for (int k = 0; k < 2; k++)
          {
            vert = E_vertex(edge, k);
            if(EN_onCB(vert))
              bndryEGEnts[0].insert(vert);
          }
          if(EN_onCB(edge))
            bndryEGEnts[1].insert(edge);
        }
        if(EN_onCB(face))
          bndryEGEnts[2].insert(face);
      }
    }
  }

  IPComMan *CM = AOMD::ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(2*sizeof(pEntity));
  pEntity* msg_send = (pEntity*)CM->alloc_msg(2*sizeof(pEntity));

  int num_sent = 0, num_recvd = 0;

  set<pEntity>::iterator it;
  pEntity ent;
  for (int i = 1; i < 2; i++)
  {
    for (it = bndryEGEnts[i].begin(); it != bndryEGEnts[i].end(); it++)
    {
      ent = *it;
      if (!ent->getNumRemoteCopies())
        printf("NO REMOTE COPIES!!!!!! WRONG! The ent dim=%d\n",ent->getLevel());
      if (ent->getLevel() == 1)
      {
        int e_type = E_typeInBL(ent);
        if (e_type == eLAYER || e_type == eTRANSITION)
        {
//          for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
          for (map<int, pEntity>::iterator rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
          {
            msg_send[0] = rciter->second;
            msg_send[1] = ent;
            CM->send(rciter->first, (void*)msg_send);
            num_sent++;
          } // for RCItet
        }
      }
      if (ent->getLevel() == 2)
      {
        void *temp_ptr;
        if (!EN_getDataPtr(ent,ptr_reff,&temp_ptr))
          continue;
      }
    }  // for EGEnts
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  void *msg_recv;
  int pid_from;
  pEntity ent_rc, ent_br;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = ((pEntity*)msg_recv)[0];
    if(ent->getRemoteCopy(pid_from) != ((pEntity*)msg_recv)[1])
    {
      printf("Wrong connectivity of entity with DIM=%d!!!\n", ent->getLevel());
    }
    if (ent->getLevel() == 1)
    {
      int e_type = E_typeInBL(ent);
      if (e_type != eLAYER || e_type != eTRANSITION)
      {
        printf("BL information is not correct!!!\n");
        for (int i = 0; i < E_numFaces(ent); i++)
          if (E_face(ent,i)->getType() == QUAD)
            printf("This should be a BL edge!\n");
        ent_rc = ((pEntity*)msg_recv)[1];
        ent_br = ent;
      }
    }
    if (ent->getLevel() == 2)
    {
      void *temp_ptr;
      int value;
      if (!EN_getDataPtr(ent,ptr_reff,&temp_ptr))
      {
        printf("FOUND Face!!! On PID %d it has %d remote copies, it's type in BL is %d and it is BL face with %d value, classification %d\n", P_pid(), face->getNumRemoteCopies(),F_typeInBL(face), EN_isBLEntity(face), face->getPClassification());
          face->printRCs();
          for (int i = 0; i < 3; i++)
          {
            edge = F_edge(face,i);
            printf("%d edge on PID %d is %d type in BL and is marked as %d for refinement and has BL with flag %d\n",i,P_pid(),E_typeInBL(edge),EN_getDataInt(edge,int_reff,&value),EN_isBLEntity(edge));
          }
      }
    }
    CM->free_msg(msg_recv);
  }
  printf("[%d]: sent - %d\, recvd - %d\n", P_pid(), num_sent, num_recvd);
}
*/


