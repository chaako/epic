/* 
   Xiangrong Li  modified  10/04/99 for Mesh Adapt V1.0
   B. Kaan Karamete Jan. 1999 

   get info of 3D face Swap operations. thru 3->2, 2->3 and 2->2
   transformations? returns 1 if the swap is realized 0 if not.

   Return 0: if face swap can not be performed
          1: TRI2TWO or TWOTRI can be performed
	  2: TWO2TWO can be performed
*/

#include "fromMeshTools.h"
#include "Fswap.h"

F_SwapConfig fsc;

int F_evalSwap(pFace face,double tol)
{
  int i,j,k,m,ok,oldu,cnt;
  pRegion reg;
  pPList regs[2];
  pFace face1,face2;
  double n1[3],n2[3],nn1[3],nn2[3];
  double aci;
  pPList fvlist,rvlist;
  pGEntity gen;
  pVertex vertex,v[2];
  pFace nface[3][3];
  int   ndir[3][3];
  int invalid;
  pEdge edge;
  double xyz[4][3];

  /* Transformation thru non-manifold regions are forbidened */

  gen=F_whatIn(face);
  if(gen && GEN_type(gen)==Tface) return(0);

  fsc.swapType=EMPTY;
  fsc.face=face;

  /* get some info about the mesh around the face */
   
  for(i=0;i<2;++i){
    fsc.oppRegs[i]=F_region(face,i);
    fsc.oppVrts[i]=R_fcOpVt(fsc.oppRegs[i],face);
    regs[i]=V_regions(fsc.oppVrts[i]);
  }  

  /* is there a common region for the opoosite vertices, then 
    there are actually three regions */

  fvlist=F_vertices(face,1);   
  ok=0; 
  for(i=0;i<PList_size(regs[0]);++i){
    reg=(pRegion)PList_item(regs[0],i);	
    if(reg==fsc.oppRegs[0] || reg==fsc.oppRegs[1]) continue;
    for(j=0;j<PList_size(regs[1]);++j)
      if(PList_item(regs[1],j)==reg){
	rvlist=R_vertices(reg,1);
	cnt=0;
	for(k=0;k<4;++k){
	  for(m=0;m<3;++m){
	    if(PList_item(rvlist,k)==PList_item(fvlist,m))
	      ++cnt;
	    if(cnt==2)
	      break;
	  }
	  if(cnt==2)
	    break;
	}
	PList_delete(rvlist);
	if(cnt==2){
	  ok=1;
	  fsc.swapType=TRI2TWO;
	  break;
	}
      }
    if(ok) break;
  }
  PList_delete(fvlist);
  PList_delete(regs[0]);
  PList_delete(regs[1]);
  
  /* a thirdReg classified on different model region is forbidden */
  if( gen && (pGEntity)R_whatIn(reg) != gen )  return (0);

  /* keep track of the third region */ 
  fsc.thirdReg=reg;

  if(fsc.swapType==EMPTY){

    /* check for TWO2TWO : This should never occur for Delaunay triangulation
       by swapping since the face to be swapped is needed to make the opposite
       region's circumsphere to be emtpty.
    */    

    for(i=0;i<4;++i){
      face1=R_face(fsc.oppRegs[0],i);
      if(face1==face) continue;
      edge=F_vtOpEd(face1,fsc.oppVrts[0]);
      oldu=0;
      for(j=0;j<4;++j){
	face2=R_face(fsc.oppRegs[1],j);
	if(face2==face) continue;
	for(k=0;k<3;++k)
	  if(F_edge(face2,k)==edge){
	    oldu=1;
	    break;  	
	  }
	if(oldu) break;
      }
      F_normalVector(face1,R_dirUsingFace(fsc.oppRegs[0],face1),n1);
      F_normalVector(face2,R_dirUsingFace(fsc.oppRegs[1],face2),n2);
      normVt(n1,nn1);
      normVt(n2,nn2);
      aci=dotProd(nn1,nn2);
      if(C_raneql(aci,1.0,tol)){
	fsc.swapType=TWO2TWO;
	fsc.edge=edge;
	break;
      }
    } 
  }

  /* The only option left is */
  
  if(fsc.swapType==EMPTY)    fsc.swapType=TWO2TRI;
  

  switch (fsc.swapType) {

  case TRI2TWO: 


      /* find the vertex which is not in the third region */

    fvlist=F_vertices(face,1);
    rvlist=R_vertices(reg,1);

    for(i=0;i<PList_size(fvlist);++i){
      vertex=(pVertex)PList_item(fvlist,i);
      ok=0;
      for(j=0;j<PList_size(rvlist);++j)
	if(PList_item(rvlist,j)==vertex){
	  ok=1;
	  break;
	}
      if(!ok) 
	break;
    }

    if(ok){
      MT_ErrorHandler("region face connect. wrong","F_swap",WARN);
      return(0);
    }

    /* find the other vertices of the face */

    k=0;
    for(i=0;i<PList_size(fvlist);++i){
      if(PList_item(fvlist,i)!=vertex){
	v[k]=(pVertex)PList_item(fvlist,i);
	++k;
      }
    }
 
    PList_delete(fvlist);
    PList_delete(rvlist);

    /* check the validity of the swap operation */

    for(i=0;i<2;++i)
      for(j=0;j<2;++j){
	nface[i][j]=R_vtOpFc(fsc.oppRegs[i],v[j]);
	ndir[i][j]=R_dirUsingFace(fsc.oppRegs[i],nface[i][j]);
      }

    invalid=0;
    for(m=0;m<2;++m){
      fvlist=F_vertices(nface[0][m],!ndir[0][m]);
      for(i=0;i<3;++i)
	V_coord((pVertex)PList_item(fvlist,i),xyz[i]);
      PList_delete(fvlist);
      V_coord(fsc.oppVrts[1],xyz[3]);
      if(XYZ_checkFlatTet(xyz,tol)){
	invalid=1;
	break;
      }
    }

    if(invalid)      return(0);

    return(1);

  case TWO2TRI:

    /* check the validity of the swap config. */

    fvlist=F_vertices(face,1);

    for(i=0;i<2;++i)
     for(j=0;j<3;++j){
       nface[i][j]=R_vtOpFc(fsc.oppRegs[i],(pVertex)PList_item(fvlist,j));
       ndir[i][j]=R_dirUsingFace(fsc.oppRegs[i],nface[i][j]);
     }
    PList_delete(fvlist);
     
    invalid=0;
    for(m=0;m<3;++m){
      rvlist=F_vertices(nface[0][m],!ndir[0][m]);
      for(i=0;i<3;++i)
	V_coord((pVertex)PList_item(rvlist,i),xyz[i]);
      PList_delete(rvlist);
      V_coord(fsc.oppVrts[1],xyz[3]);
      if(XYZ_checkFlatTet(xyz,tol)){
	invalid=1;
	break;
      }
    }

    if(invalid)
      return(0);

    return(1);

  case TWO2TWO:
    
    /* Validity check and "best" determination will be done in E_evalSwap */
    m=E_numSwpCfg(edge);
    if(m){
      ok=0;
      for(i=0;i<m;++i){
	ok=E_evalSwpCfg(edge,i);
	if(ok)
	  break;
      }
      return(ok);
    }
    else
      return(0);
  }

  return 0;
}

      
	

	

 
              
 	    
		
