#include "templateRefine.h"
#include "templateUtil.h"
#include "PList.h"
#include "BLUtil.h"

#include <iostream>
using std::cout;
using std::endl;

/*
 *  edge 0 is marked
 *
 *  MeshAdapt V1.0 Created by Xiangrong Li 05/08/99
 */
void meshTemplate::sub_template_1(pEdge parent_edges[6], pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, pPList newRgns, pPList newEdges)
{

  pEdge edges[3];    // the 3 edges to create the interior face 7
  pFace faces[7];    // the 7 faces to create the 2 regions
  pFace r_faces[4];  // the 4 faces to create the 1 regions
  pRegion regions[2];// the two regions created by this template
  int f_dir[3];      // the orientation of the 3 edges of a face
  int r_dir[4];      // the orientation of the 4 faces of a region
  pPList plist;

  // first assign the useful parent faces and edge
  faces[0]=parent_faces[2];
  faces[1]=parent_faces[3];
  edges[0]=parent_edges[5];

  // get the split faces and edge of parent face 1
  plist=get_split_faces_1(parent_faces[1]);
  edges[1]=(pEdge)PList_item(plist,0);
  faces[2]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[2],(pEntity)parent_edges[3]) )
    // faces[2] is bounded by parent edge 3
    faces[3]=(pFace)PList_item(plist,2);
  else {
    // faces[2] is not bounded by parent edge 3
    faces[3]=faces[2];
    faces[2]=(pFace)PList_item(plist,2);
  }

  // get the split faces and edge of parent face 0
  plist=get_split_faces_1(parent_faces[0]);
  edges[2]=(pEdge)PList_item(plist,0);
  faces[4]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[4],(pEntity)parent_edges[2]) )
    // faces[4] is bounded by parent edge 2
    faces[5]=(pFace)PList_item(plist,2);
  else {
    // faces[4] is not bounded by parent edge 2
    faces[5]=faces[4];
    faces[4]=(pFace)PList_item(plist,2);
  }

  // create the interior face
  if(parent_verts[3]==E_vertex(edges[0],0))
      f_dir[0]=0;
  else
      f_dir[0]=1;
  f_dir[1]=0;            // vertex 4 is always the starting vertex
  f_dir[2]=1;            // vertex 4 is always the starting vertex
  faces[6]=M_createF(pmesh,3,edges,f_dir,g_entity);

  /*
    create the two regions
    The regions created here have the correct face order
  */

  // select the interior face as face 0
  // for regions[0], it will use face 0 positively
  r_faces[0]= faces[6];
  r_faces[1]= faces[4];   // e2 of face 0
  r_faces[2]= faces[2];   // e1 of face 0
  r_faces[3]= faces[1];   // e0 of face 0
  r_dir[0]= 1;
  r_dir[1]= parent_face_dirs[0];
  r_dir[2]= parent_face_dirs[1];
  r_dir[3]= parent_face_dirs[3];
  regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  // also select the interior face as face 0
  // regions[1] will use face 0 negatively
  r_faces[0]= faces[6];
  r_faces[1]= faces[0];    // e0 of face 0
  r_faces[2]= faces[3];    // e1 of face 0
  r_faces[3]= faces[5];    // e2 of face 0
  r_dir[0]= 0;
  r_dir[1]= parent_face_dirs[2];
  r_dir[2]= parent_face_dirs[1];
  r_dir[3]= parent_face_dirs[0];
  regions[1]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  if( newRgns ) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
  }
  if( newEdges ) {
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
  }

  return;
}

/*
 *  MeshAdapt V1.0 Created by Xiangrong Li 05/11/99
 */
void meshTemplate::sub_template_2_1(pEdge parent_edges[6], pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, pPList newRgns, pPList newEdges)
{

  pEdge f_edges[3];  // the 3 edges to create a face
  int f_dir[3];      // the orientation of the 3 edges to create a face
  pFace r_faces[4];  // the 4 faces to create a region
  int r_dir[4];      // the orientation of the 4 faces to create a region
  pEdge edges[5];    // the 5 edges to the two interior face
  pFace faces[10];   // the 10 faces to create the 3 new regions
  pRegion regions[3];// the three regions created by this template
  pPList plist;

  // first assign the useful parent faces and edge
  faces[0]=parent_faces[1];
  if(parent_face_dirs[0])
    edges[0]=parent_edges[4];
  else
    edges[0]=parent_edges[3];

  // get the split faces and edge of parent face 0
  plist=get_split_faces_2(parent_faces[0]);
  edges[1]=(pEdge)PList_item(plist,0);
  edges[2]=(pEdge)PList_item(plist,1);
  faces[1]=(pFace)PList_item(plist,2);
  faces[2]=(pFace)PList_item(plist,3);
  faces[3]=(pFace)PList_item(plist,4);

  // get the split faces and edge of parent face 2
  plist=get_split_faces_1(parent_faces[2]);
  edges[3]=(pEdge)PList_item(plist,0);
  faces[4]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[4],(pEntity)parent_edges[4]) )
    // faces[4] is bounded by parent edge 4
    faces[5]=(pFace)PList_item(plist,2);
  else {
    // faces[4] is not bounded by parent edge 4
    faces[5]=faces[4];
    faces[4]=(pFace)PList_item(plist,2);
  }

  // get the split faces and edge of parent face 3
  plist=get_split_faces_1(parent_faces[3]);
  edges[4]=(pEdge)PList_item(plist,0);
  faces[6]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[6],(pEntity)parent_edges[5]) )
    // faces[6] is bounded by parent edge 5
    faces[7]=(pFace)PList_item(plist,2);
  else {
    // faces[6] is not bounded by parent edge 5
    faces[7]=faces[6];
    faces[6]=(pFace)PList_item(plist,2);
  }

  // create the two interior faces such that:
  //  (1) the normal points to vertex 0 or 2
  //  (2) the edge bounding face 0 is the first edge

  // create face 8
  if(parent_face_dirs[0]) {
    f_edges[0]= edges[1];
    f_edges[1]= edges[0];
    f_edges[2]= edges[4];
    f_dir[0]=0;
    if(E_vertex(edges[0],0)==parent_verts[3])
      f_dir[1]=0;
    else
      f_dir[1]=1;
    f_dir[2]=0;
  } else {
    f_edges[0]= edges[1];
    f_edges[1]= edges[3];
    f_edges[2]= edges[0];
    f_dir[0]=1;
    f_dir[1]=1;
    if(E_vertex(edges[0],0)==parent_verts[3])
      f_dir[2]=1;
    else
      f_dir[2]=0;
  }
  faces[8]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  // create face 9
  if(parent_face_dirs[0]) {
    f_edges[0]= edges[2];
    f_edges[1]= edges[4];
    f_edges[2]= edges[3];
    f_dir[0]=0;
    f_dir[1]=1;
    f_dir[2]=0;
  } else {
    f_edges[0]= edges[2];
    f_edges[1]= edges[4];
    f_edges[2]= edges[3];
    f_dir[0]=1;
    f_dir[1]=1;
    f_dir[2]=0;
  }
  faces[9]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  /*
    create the three regions
    The regions created here have the correct face order
  */

  // create region 0, use its interior face as face 0, negatively
  if(parent_face_dirs[0]) {
    r_faces[0]= faces[8];
    r_faces[1]= faces[1];   // e0 of face 0
    r_faces[2]= faces[0];   // e1 of face 0
    r_faces[3]= faces[7];   // e2 of face 0
    r_dir[0]= 0;
    r_dir[1]= 1;
    r_dir[2]= parent_face_dirs[1];
    r_dir[3]= parent_face_dirs[3];
  } else {
    r_faces[0]= faces[8];
    r_faces[1]= faces[1];   // e0 of face 0
    r_faces[2]= faces[4];   // e1 of face 0
    r_faces[3]= faces[0];   // e2 of face 0
    r_dir[0]= 0;
    r_dir[1]= 0;
    r_dir[2]= parent_face_dirs[2];
    r_dir[3]= parent_face_dirs[1];
  }
  regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  // create region 1, use face 8 as new region's face 0, positively
  if(parent_face_dirs[0]) {
    r_faces[0]= faces[8];
    r_faces[1]= faces[9];   // e2 of face 0
    r_faces[2]= faces[4];   // e1 of face 0
    r_faces[3]= faces[2];   // e0 of face 0
    r_dir[0]= 1;
    r_dir[1]= 1;
    r_dir[2]= parent_face_dirs[2];
    r_dir[3]= 1;
  } else {
    r_faces[0]= faces[8];
    r_faces[1]= faces[7];   // e2 of face 0
    r_faces[2]= faces[9];   // e1 of face 0
    r_faces[3]= faces[2];   // e0 of face 0
    r_dir[0]= 1;
    r_dir[1]= parent_face_dirs[3];
    r_dir[2]= 1;
    r_dir[3]= 0;
  }
  regions[1]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  // create region 2, using its interior face as face 0, negatively
  if(parent_face_dirs[0]) {
    r_faces[0]= faces[9];
    r_faces[1]= faces[3];    // e0 of face 0
    r_faces[2]= faces[6];    // e1 of face 0
    r_faces[3]= faces[5];    // e2 of face 0
    r_dir[0]= 0;
    r_dir[1]= 1;
    r_dir[2]= parent_face_dirs[3];
    r_dir[3]= parent_face_dirs[2];
  } else {
    r_faces[0]= faces[9];
    r_faces[1]= faces[3];    // e0 of face 0
    r_faces[2]= faces[6];    // e1 of face 0
    r_faces[3]= faces[5];    // e2 of face 0
    r_dir[0]= 0;
    r_dir[1]= 0;
    r_dir[2]= parent_face_dirs[3];
    r_dir[3]= parent_face_dirs[2];
  }
  regions[2]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  if( newRgns ) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
  }
  if( newEdges ) {
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[4]);
  }

  return;
}

/*
 *  split a region with edge 0 and edge 5 marked
 *  MeshAdapt V1.0  05/12/99 by Xiangrong Li
 */
void meshTemplate::sub_template_2_2(pEdge parent_edges[6], pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, pPList newRgns, pPList newEdges)
{
  pEdge edges[9];    // the 9 edges to create interior faces
  pFace faces[12];   // the 12 faces to create the 4 new regions
  pVertex verts[2];  // the 2 middle vertices
  pEdge f_edges[3];  // 3 edges to create a face
  pFace r_faces[4];  // the 4 faces to create the 1 regions
  pRegion regions[4];// the four regions created by this template
  int f_dir[3];      // the orientation of the 3 edges of a face
  int r_dir[4];      // the orientation of the 4 faces of a region
  pPList plist;

  // first get info about the two split edges

  // 1. split edge 0
  plist=get_split_edges(parent_edges[0]);
  verts[0]=(pVertex)PList_item(plist,0);
  edges[0]=(pEdge)PList_item(plist,1);
  if(E_vertex(edges[0],0)==parent_verts[0] || E_vertex(edges[0],1)==parent_verts[0])
    edges[1]=(pEdge)PList_item(plist,2);
  else {
    edges[1]=edges[0];
    edges[0]=(pEdge)PList_item(plist,2);
  }

  // 2. split edge 5
  plist=get_split_edges(parent_edges[5]);
  verts[1]=(pVertex)PList_item(plist,0);
  edges[2]=(pEdge)PList_item(plist,1);
  if(E_vertex(edges[2],0)==parent_verts[2] || E_vertex(edges[2],1)==parent_verts[2])
    edges[3]=(pEdge)PList_item(plist,2);
  else {
    edges[3]=edges[2];
    edges[2]=(pEdge)PList_item(plist,2);
  }

  // create the interior edge
  edges[4]=M_createE(pmesh,verts[0],verts[1],g_entity);

  // split the 4 faces

  // 1.get the split faces and edge of parent face 0
  plist=get_split_faces_1(parent_faces[0]);
  edges[5]=(pEdge)PList_item(plist,0);
  faces[0]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[0],(pEntity)parent_edges[2]) )
    // faces[0] is bounded by  parent edge 2
    faces[1]=(pFace)PList_item(plist,2);
  else {
    // faces[0] is not bounded by parent edge 2
    faces[1]=faces[0];
    faces[0]=(pFace)PList_item(plist,2);
  }

  // 2.get the split faces and edge of parent face 1
  plist=get_split_faces_1(parent_faces[1]);
  edges[6]=(pEdge)PList_item(plist,0);
  faces[2]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[2],(pEntity)parent_edges[3]) )
    // faces[2] is bounded by parent edge 3
    faces[3]=(pFace)PList_item(plist,2);
  else {
    // faces[2] is not bounded by parent edge 3
    faces[3]=faces[2];
    faces[2]=(pFace)PList_item(plist,2);
  }

  // 3.get the split faces and edge of parent face 2
  plist=get_split_faces_1(parent_faces[2]);
  edges[7]=(pEdge)PList_item(plist,0);
  faces[4]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[4],(pEntity)parent_edges[1]) )
    // faces[4] is bounded by parent edge 1
    faces[5]=(pFace)PList_item(plist,2);
  else {
    // faces[4] is not bounded by parent edge 1
    faces[5]=faces[4];
    faces[4]=(pFace)PList_item(plist,2);
  }

  // 4.get the split faces and edge of parent face 3
  plist=get_split_faces_1(parent_faces[3]);
  edges[8]=(pEdge)PList_item(plist,0);
  faces[6]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[6],(pEntity)parent_edges[2]) )
    // faces[4] is bounded by parent edge 2
    faces[7]=(pFace)PList_item(plist,2);
  else {
    // faces[4] is not bounded by parent edge 2
    faces[7]=faces[6];
    faces[6]=(pFace)PList_item(plist,2);
  }

  // create the interior face such that:
  // 1.the interior edge is always used positively
  // 2.the interior edge is the first edge
  f_edges[0]= edges[4];
  f_edges[1]= edges[8];
  f_edges[2]= edges[0];
  f_dir[0]=1;
  f_dir[1]=1;
  if(parent_verts[0]==E_vertex(edges[0],0))
    f_dir[2]=1;
  else
    f_dir[2]=0;
  faces[8]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  f_edges[0]= edges[4];
  f_edges[1]= edges[7];
  f_edges[2]= edges[1];
  f_dir[0]=1;
  f_dir[1]=1;
  if(parent_verts[1]==E_vertex(edges[1],0))
    f_dir[2]=1;
  else
    f_dir[2]=0;
  faces[9]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  f_edges[0]= edges[4];
  f_edges[1]= edges[3];
  f_edges[2]= edges[6];
  f_dir[0]=1;
  if(parent_verts[3]==E_vertex(edges[3],0))
    f_dir[1]=0;
  else
    f_dir[1]=1;
  f_dir[2]=0;
  faces[10]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  f_edges[0]= edges[4];
  f_edges[1]= edges[2];
  f_edges[2]= edges[5];
  f_dir[0]=1;
  if(parent_verts[2]==E_vertex(edges[2],0))
    f_dir[1]=0;
  else
    f_dir[1]=1;
  f_dir[2]=0;
  faces[11]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  /*
    create the four regions
    The regions created here have the correct face order
  */

  // select the interior face 8 as face 0
  // regions[0] will use face 0 negatively
  r_faces[0]= faces[8];
  r_faces[1]= faces[10];   // e0 of face 0
  r_faces[2]= faces[7];    // e1 of face 0
  r_faces[3]= faces[2];    // e2 of face 0
  r_dir[0]= 0;
  r_dir[1]= 1;
  r_dir[2]= parent_face_dirs[3];
  r_dir[3]= parent_face_dirs[1];
  regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  // select the interior face 10 as face 0
  // regions[1] will use face 0 negatively
  r_faces[0]= faces[10];
  r_faces[1]= faces[9];    // e0 of face 0
  r_faces[2]= faces[5];    // e1 of face 0
  r_faces[3]= faces[3];    // e2 of face 0
  r_dir[0]= 0;
  r_dir[1]= 1;
  r_dir[2]= parent_face_dirs[2];
  r_dir[3]= parent_face_dirs[1];
  regions[1]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  // select the interior face 8 as face 0
  // regions[2] will use face 0 positively
  r_faces[0]= faces[11];
  r_faces[1]= faces[8];    // e2 of face 0
  r_faces[2]= faces[6];    // e1 of face 0
  r_faces[3]= faces[0];    // e0 of face 0
  r_dir[0]= 0;
  r_dir[1]= 1;
  r_dir[2]= parent_face_dirs[3];
  r_dir[3]= parent_face_dirs[0];
  regions[2]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  // select the interior face 9 as face 0
  // regions[3] will use face 0 negatively
  r_faces[0]= faces[9];
  r_faces[1]= faces[11];   // e0 of face 0
  r_faces[2]= faces[4];    // e1 of face 0
  r_faces[3]= faces[1];    // e2 of face 0
  r_dir[0]= 0;
  r_dir[1]= 1;
  r_dir[2]= parent_face_dirs[2];
  r_dir[3]= parent_face_dirs[0];
  regions[3]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  if( newRgns ) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
    PList_append(newRgns,regions[3]);
  }
  if( newEdges ) {
    PList_append(newEdges,edges[4]);
    PList_append(newEdges,edges[5]);
    PList_append(newEdges,edges[6]);
    PList_append(newEdges,edges[7]);
    PList_append(newEdges,edges[8]);
  }

  return;
}

/*
 *  MeshAdapt V1.0 Created by Xiangrong Li 05/15/99
 */
void meshTemplate::sub_template_3_1(pEdge parent_edges[6], pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, int k, pPList newRgns, pPList newEdges)
{
  pVertex verts[2];  // 2 vertices to create the interior edge
  pEdge edges[11];   // 11 edges to create 5 interior faces
  pFace faces[15];   // 15 faces to create 5  regions
  pFace r_faces[4];  // the 4 faces to create a region
  pEdge f_edges[3];  // the 3 edges to create a face
  pRegion regions[5];// the two regions created by this template
  int f_dir[3];      // the orientation of the 3 edges of a face
  int r_dir[4];      // the orientation of the 4 faces of a region
  int e2,e4;
  pPList plist;
  int i,j=0;
  int l=0;           // counter

  // determine the orientation of parent edge 2 and 4
  if(E_vertex(parent_edges[2],0)==parent_verts[2])
     e2=1;
  else
     e2=0;

  if(E_vertex(parent_edges[4],0)==parent_verts[3])
     e4=1;
  else
     e4=0;

  //==============================================
  //                tables
  // 5 faces with 3 edges each
  int f_i[4][15]={     {4,7,0,    4,2,5,  4,9,1,  4,3,10,    4,8,6},
                       {4,7,0,    8,5,9,  4,9,1,  4,3,10,    4,8,6},
                       {6,7,10,   4,2,5,  4,9,1,  4,3,10,    4,8,6},
                       {6,7,10,   8,5,9,  4,9,1,  4,3,10,    4,8,6}  };

  int f_dir_i[4][15]={ {1,0,1-e2, 1,e4,1, 1,1,e2, 1,1-e4,0,  1,1,0},
                       {1,0,1-e2, 1,0,0,  1,1,e2, 1,1-e4,0,  1,1,1},
                       {1,0,0,    1,e4,1, 1,1,e2, 1,1-e4,0,  1,0,0},
                       {0,0,0,    0,0,0,  1,1,e2, 1,1-e4,0,  1,0,1}  };

  // 5 regions with 4 faces each
  int r_i[4][20]={ {10,14,4,2,   14,11,5,1, 11,12,6,0,  12,13,7,8,  13,10,3,9},
                   {10,14,4,2,   14,12,11,1,11,5,0,6,   12,13,7,8,  13,10,3,9},
                   {13,14,4,10,  14,11,5,1, 11,12,6,0,  12,13,7,8,  10,2,3,9},
                   {13,14,4,10,  14,12,11,1,11,5,0,6, 12,13,7,8,  10,2,3,9} };

  int r_dir_i[4][20]={ {0,1,0,0, 0,1,0,0,  0,1,parent_face_dirs[2],0,
    0,1,parent_face_dirs[2],parent_face_dirs[3],   0,1,0,parent_face_dirs[3]},
                       {0,1,0,1,       0,1,1,1,    0,0,1,parent_face_dirs[2],
    0,1,parent_face_dirs[2],parent_face_dirs[3],   0,1,0,parent_face_dirs[3]},
                       {0,1,1,1,       0,1,1,0,    0,1,parent_face_dirs[2],0,
    0,1,parent_face_dirs[2],parent_face_dirs[3],   0,0,1,parent_face_dirs[3]},
                       {0,1,1,1,       0,1,1,1,    0,1,1,parent_face_dirs[2],
    0,1,parent_face_dirs[2],parent_face_dirs[3],   0,1,1,parent_face_dirs[3]} };

  //==========================================

  // get info from parent edge 2
  plist=get_split_edges(parent_edges[2]);
  verts[0]=(pVertex)PList_item(plist,0);
  edges[0]=(pEdge)PList_item(plist,1);
  if(parent_verts[0]==E_vertex(edges[0],0) || parent_verts[0]==E_vertex(edges[0],1))
    edges[1]=(pEdge)PList_item(plist,2);
  else{
    edges[1]=edges[0];
    edges[0]=(pEdge)PList_item(plist,2);
  }

  // get info from parent edge 4
  plist=get_split_edges(parent_edges[4]);
  verts[1]=(pVertex)PList_item(plist,0);
  edges[2]=(pEdge)PList_item(plist,1);
  if(parent_verts[1]==E_vertex(edges[2],0) || parent_verts[1]==E_vertex(edges[2],1))
    edges[3]=(pEdge)PList_item(plist,2);
  else{
    edges[3]=edges[2];
    edges[2]=(pEdge)PList_item(plist,2);
  }

  // create the interior edge
  edges[4]=M_createE(pmesh,verts[0],verts[1],g_entity);

  // get info from parent face 0
  plist=get_split_faces_2(parent_faces[0]);
  edges[5]=(pEdge)PList_item(plist,0);
  edges[6]=(pEdge)PList_item(plist,1);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  faces[2]=(pFace)PList_item(plist,4);

  // get info from parent face 1
  plist=get_split_faces_2(parent_faces[1]);
  edges[7]=(pEdge)PList_item(plist,0);
  edges[8]=(pEdge)PList_item(plist,1);
  faces[3]=(pFace)PList_item(plist,2);
  faces[4]=(pFace)PList_item(plist,3);
  faces[5]=(pFace)PList_item(plist,4);

  //get info from parent face 2
  plist=get_split_faces_1(parent_faces[2]);
  edges[9]=(pEdge)PList_item(plist,0);
  faces[6]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[6],(pEntity)parent_edges[1]) )
    // faces[6] is bounded by parent edge 1
    faces[7]=(pFace)PList_item(plist,2);
  else {
    // faces[6] is not bounded parent edge 1
    faces[7]=faces[6];
    faces[6]=(pFace)PList_item(plist,2);
  }

  // get info from parent face 3
  plist=get_split_faces_1(parent_faces[3]);
  edges[10]=(pEdge)PList_item(plist,0);
  faces[8]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[8],(pEntity)parent_edges[5]) )
    // faces[8] is bounded by parent edge 5
    faces[9]=(pFace)PList_item(plist,2);
  else {
    // faces[8] is not bounded by parent edge 5
    faces[9]=faces[8];
    faces[8]=(pFace)PList_item(plist,2);
  }

  /* create the 5 interior faces such that:
     1. all the faces use the interior edge positively
     2. the interior edge is the first edge  */
  for(j=0; j<5; j++) {
    for(i=0; i<3; i++) {
      f_edges[i]= edges[f_i[k][l]];
      f_dir[i]= f_dir_i[k][l];
      ++l;
    }
    faces[10+j]=M_createF(pmesh,3,f_edges,f_dir,g_entity);
  }

  /*
    create the 5 regions
    The regions created here have the correct face order
  */

  // select the negatively used interior face as face 0
  l=0;
  for(j=0; j<5; j++) {
    for(i=0; i<4; i++) {
      r_faces[i]= faces[r_i[k][l]];
      r_dir[i]= r_dir_i[k][l];
      ++l;
    }
    regions[j]=M_createR(pmesh,4,r_faces,r_dir,g_entity);
  }

  // return the new regions and new edges 
  if( newRgns ) {
    for(j=0; j<5; j++) 
      PList_append(newRgns,regions[j]);
  }
  if( newEdges ) {
    for(j=4; j<11; j++) 
      PList_append(newEdges, edges[j]);
  }

  return;
}

/*
 *  sub-template with three marked edges
 *  case 2: edge 0, 1 and 3 are marked
 *          there are 4 splitting possibilities
 *
 *  MeshAdapt V1.0 Created by Xiangrong Li 05/15/99
 */
void meshTemplate::sub_template_3_2(pEdge parent_edges[6], pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, int k, pPList newRgns, pPList newEdges)
{
  pVertex verts[2];  // 2 vertices to create the interior edge
  pEdge edges[11];    // 11 edges to create 5 interior faces
  pFace faces[15];    // 15 faces to create 5  regions
  pFace r_faces[4];  // the 4 faces to create a region
  pEdge f_edges[3];  // the 3 edges to create a face
  pRegion regions[5];// the two regions created by this template
  int f_dir[3];      // the orientation of the 3 edges of a face
  int r_dir[4];      // the orientation of the 4 faces of a region
  int e1,e3;
  pPList plist;
  int i,j=0;
  int l=0;

  // determine the orientation of parent edge 2 and 4
  if(E_vertex(parent_edges[1],0)==parent_verts[1])
     e1=1;
  else
     e1=0;

  if(E_vertex(parent_edges[3],0)==parent_verts[0])
     e3=1;
  else
     e3=0;

  //==============================================
  //                tables
  // 5 faces with 3 edges each
  int f_i[4][15]={     {5,8,10,   6,9,7,  4,10,1,   4,3,9,    4,8,6},
                       {4,2,5,    6,9,7,  4,10,1,   4,3,9,    4,8,6},
                       {5,8,10,   4,7,0,  4,10,1,   4,3,9,    4,8,6},
                       {4,2,5,    4,7,0,  4,10,1,   4,3,9,    4,8,6} };

  int f_dir_i[4][15]={ {1,1,1,    1,1,1,  1,1,1-e1, 1,e3,0,  1,0,1},
                       {1,1-e3,1, 0,1,1,  1,1,1-e1, 1,e3,0,  1,0,0},
                       {1,0,1,    1,0,e1, 1,1,1-e1, 1,e3,0,  1,1,1},
                       {1,1-e3,1, 1,0,e1, 1,1,1-e1, 1,e3,0,  1,1,0} };

  // 5 regions with 4 faces each
  int r_i[4][20]={ {10,0,5,8,   11,2,6,3, 12,14,10,1,  13,12,9,7,  14,13,4,11},
                   {10,14,5,1,  11,2,6,3, 12,10,8,0,   13,12,9,7,  14,13,4,11},
                   {10,0,5,8,   14,11,4,2,  12,14,10,1,  13,12,9,7,  11,13,3,6},
                   {10,14,5,1,  14,11,4,2,  11,13,3,6, 13,12,9,7,  12,10,8,0}};

  int r_dir_i[4][20]={ {0,0,0,parent_face_dirs[3],  0,0,parent_face_dirs[2],0,  0,1,1,0,
                        0,1,parent_face_dirs[3],parent_face_dirs[2],   0,1,0,1},
                       {0,1,0,1,      0,1,parent_face_dirs[2],0,    0,1,parent_face_dirs[3],1,
                        0,1,parent_face_dirs[3],parent_face_dirs[2],   0,1,0,1},
                       {0,0,1,parent_face_dirs[3],   0,1,1,0,    0,1,1,0,
                        0,1,parent_face_dirs[3],parent_face_dirs[2],   0,1,1,parent_face_dirs[2]},
                       {0,1,1,1,      0,1,1,1,       0,1,1,parent_face_dirs[2],
                        0,1,parent_face_dirs[3],parent_face_dirs[2],   0,1,parent_face_dirs[3],1} };

  //==========================================

  // get info from parent edge 1
  plist=get_split_edges(parent_edges[1]);
  verts[0]=(pVertex)PList_item(plist,0);
  edges[0]=(pEdge)PList_item(plist,1);
  if(parent_verts[1]==E_vertex(edges[0],0) || parent_verts[1]==E_vertex(edges[0],1))
    edges[1]=(pEdge)PList_item(plist,2);
  else{
    edges[1]=edges[0];
    edges[0]=(pEdge)PList_item(plist,2);
  }

  // get info from parent edge 3
  plist=get_split_edges(parent_edges[3]);
  verts[1]=(pVertex)PList_item(plist,0);
  edges[2]=(pEdge)PList_item(plist,1);
  if(parent_verts[0]==E_vertex(edges[2],0) || parent_verts[0]==E_vertex(edges[2],1))
    edges[3]=(pEdge)PList_item(plist,2);
  else{
    edges[3]=edges[2];
    edges[2]=(pEdge)PList_item(plist,2);
  }

  // create the interior edge
  edges[4]=M_createE(pmesh,verts[0],verts[1],g_entity);

  // get info from parent face 0
  plist=get_split_faces_2(parent_faces[0]);
  edges[5]=(pEdge)PList_item(plist,0);
  edges[6]=(pEdge)PList_item(plist,1);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  faces[2]=(pFace)PList_item(plist,4);

  // get info from parent face 1
  plist=get_split_faces_2(parent_faces[1]);
  edges[7]=(pEdge)PList_item(plist,0);
  edges[8]=(pEdge)PList_item(plist,1);
  faces[3]=(pFace)PList_item(plist,2);
  faces[4]=(pFace)PList_item(plist,3);
  faces[5]=(pFace)PList_item(plist,4);

  //get info from parent face 2
  plist=get_split_faces_1(parent_faces[2]);
  edges[9]=(pEdge)PList_item(plist,0);
  faces[6]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[6],(pEntity)parent_edges[4]) )
    faces[7]=(pFace)PList_item(plist,2);
  else {
    faces[7]=faces[6];
    faces[6]=(pFace)PList_item(plist,2);
  }

  // get info from parent face 3
  plist=get_split_faces_1(parent_faces[3]);
  edges[10]=(pEdge)PList_item(plist,0);
  faces[8]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[8],(pEntity)parent_edges[2]) )
    faces[9]=(pFace)PList_item(plist,2);
  else {
    faces[9]=faces[8];
    faces[8]=(pFace)PList_item(plist,2);
  }

  /* create the 5 interior faces such that:
     1. all the faces use the interior edge positively
     2. the interior edge is the first edge  */
  for(j=0; j<5; j++) {
    for(i=0; i<3; i++) {
      f_edges[i]= edges[f_i[k][l]];
      f_dir[i]= f_dir_i[k][l];
      ++l;
    }
    faces[10+j]=M_createF(pmesh,3,f_edges,f_dir,g_entity);
  }

  /*
    create the 5 regions
    The regions created here have the correct face order
  */

  // select the negatively used interior face as face 0
  l=0;
  for(j=0; j<5; j++) {
    for(i=0; i<4; i++) {
      r_faces[i]= faces[r_i[k][l]];
      r_dir[i]= r_dir_i[k][l];
      ++l;
    }
    regions[j]=M_createR(pmesh,4,r_faces,r_dir,g_entity);
  }

  if( newRgns ) {
    for(j=0; j<5; j++) 
      PList_append(newRgns,regions[j]);
  }
  if( newEdges ) {
    for(j=4; j<11; j++) 
      PList_append(newEdges,edges[j]);
  }

  return;
}

/*
 *  split a region with three marked edges
 *  case 3: edge 0,2,3 are marked.
 *          there are still 8 possibilities -- k=0~7
 *  this routine take care of two possibilities (k=0 && k=7) 
 *
 *  MeshAdapt V1.0 Created by Xiangrong Li 05/16/99
 *                 modified 6/28/01 by Xiangrong Li
 */
pVertex meshTemplate::sub_template_3_3_a(pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, int k, pPList newRgns, pPList newEdges)
{
  pFace r_faces[4];  // the 4 faces to create a region
  int r_dir[4];      // the orientation of the 4 faces
  pEdge f_edges[3];  // the 3 edges to create a face
  int f_dir[3];      // the orientation of the 3 edges
  pRegion region;    // the region created

  pVertex centroid;      // the centroid of this tetahedra
  int size=8;            // size of the list
  pFace faces[8];        // face list of a polygon
  int dirs[8];           // direction of each face
  pGEntity g_entities[8];// classified model of the new region associated with each face

  pEdge edges[3];        // the three edges to be tried swap later
  pVertex verts[6];      // the three vertices to be tried collapsed to

  double xyz[]={0.0, 0.0, 0.0};
  double par[]={0.0,0.0,0.0};
  pPList plist;
  int i;

  // get info from parent face 0
  plist=get_split_faces_2(parent_faces[0]);
  f_edges[0]=(pEdge)PList_item(plist,1);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  r_faces[1]=(pFace)PList_item(plist,4);
  edges[0]=(pEdge)PList_item(plist,0);  // we always collect these info
  verts[0]=F_edOpVt(faces[1],edges[0]);
  verts[1]=F_edOpVt(faces[0],edges[0]);


  // get info from parent face 1
  plist=get_split_faces_2(parent_faces[1]);
  f_edges[1]=(pEdge)PList_item(plist,1);
  faces[2]=(pFace)PList_item(plist,2);
  faces[3]=(pFace)PList_item(plist,3);
  r_faces[2]=(pFace)PList_item(plist,4);
  edges[1]=(pEdge)PList_item(plist,0); // we always collect these info
  verts[2]=F_edOpVt(faces[3],edges[1]);
  verts[3]=F_edOpVt(faces[2],edges[1]);

  // get info from parent face 3
  plist=get_split_faces_2(parent_faces[3]);
  f_edges[2]=(pEdge)PList_item(plist,1);
  faces[4]=(pFace)PList_item(plist,2);
  faces[5]=(pFace)PList_item(plist,3);
  r_faces[3]=(pFace)PList_item(plist,4);
  edges[2]=(pEdge)PList_item(plist,0); // we always collect these info
  verts[4]=F_edOpVt(faces[5],edges[2]);
  verts[5]=F_edOpVt(faces[4],edges[2]);

  // create the interior face opposite to vertex 0
  if(k==0) {
    f_dir[0]=1;
    f_dir[1]=1;
    f_dir[2]=1;
  } else if(k==7) {
    f_dir[0]=0;
    f_dir[1]=0;
    f_dir[2]=0;
  } else
    cout << "sub_template_3_3_a: pb" << endl;

  r_faces[0]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  // create the region containing parent vertex 0
  if(k==0) {
    r_dir[0]=0;
    r_dir[1]=0;
    r_dir[2]=0;
    r_dir[3]=0;
  } else if(k==7) {
    r_dir[0]=0;
    r_dir[1]=1;
    r_dir[2]=1;
    r_dir[3]=1;
  } else
    cout << "sub_template_3_3_a: pb" << endl;

  region=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  if( newRgns )
    PList_append(newRgns,region);
  if( newEdges ) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,f_edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,f_edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,f_edges[2]);
  }

  // set up the polyhedron
  faces[7]=parent_faces[2];
  dirs[7]=parent_face_dirs[2];
  g_entities[7]=g_entity;

  faces[6]= r_faces[0];
  dirs[6]=1;
  g_entities[6]=g_entity;

  for(i=0; i<6; i++) {
    g_entities[i]=g_entity;
    if(k==0)
      dirs[i]=0;
    else if(k==7)
      dirs[i]=1;
    else
      cout << "sub_template_3_3_a: pb" << endl;
  }

  // calculate the centroid and interpolate the metric tensor
  pMSize pScenter = templatesUtil::wedgeCenter(verts,xyz, pSizeField);

  // create the centroid and the regions inside polyhedron
  //#ifndef AOMD_
  centroid= M_createVP2(pmesh, xyz, par, 0, g_entity);
  //#else
  //  EN_getDataInt((pEntity)PassIdRegion,vtIdTag,&i);
  //  centroid= M_createVP2(pmesh, xyz, par, i, g_entity);
  //  EN_deleteData((pEntity)PassIdRegion,vtIdTag);
  //#endif
  pSizeField->setSize((pEntity)centroid,pScenter);
  faces_vert_create_regions(pmesh,centroid,size,faces,dirs,g_entities,newRgns,newEdges);

  

  // remember the centroid vertex for later processing
  pPList entlist=PList_new();
  for(i=0; i<3; i++)
  {

    if (E_typeInBL(edges[i]))
      continue;

    PList_append(entlist,edges[i]);
    PList_append(entlist,verts[2*i]);
    PList_append(entlist,verts[2*i+1]);
  }
  if (PList_size(entlist))
  {
    EN_attachDataPtr((pEntity)centroid,ptr_reff,entlist);
    PList_append(steinerVerts,centroid);
  }
  else
  {
    PList_delete(entlist);
  }

  return centroid;
}

/*
 *  MeshAdapt V1.0 Created by Xiangrong Li 05/16/99
 */
void meshTemplate::sub_template_3_3_b(pEdge parent_edges[6], pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, int k, pPList newRgns, pPList newEdges)
{
  pFace r_faces[4];  // the 4 faces to create a region
  int r_dir[4];      // the orientation of the 4 faces
  pEdge f_edges[3];  // the 3 edges to create a face
  int f_dir[3];      // the orientation of the 3 edges

  pRegion region[4]; // the 4 regions created
  pFace faces[13];   // the 13 faces to create the 4 regions
  pEdge edges[7];    // the 7 edges to create the 3 interior faces
  pPList plist;

  int dir;
  int i,j;
  int l=0;
  --k;  // so possible k=0,1,2,3,4,5

  int e_i[6]={5,1,1,4,5,4};
  int v_i[6]={3,2,2,1,3,1};
  if(E_vertex(parent_edges[e_i[k]],0) == parent_verts[v_i[k]])
    dir=1;
  else
    dir=0;

  //====================================================
  //                tables
  // 3 interior faces with 3 edges each
  int f_i[6][9]={  {2,4,6,     1,3,0,     1,4,5},
                   {2,4,6,     0,3,5,     1,3,6},
                   {2,4,6,     0,3,5,     1,4,5},
                   {2,4,6,     1,0,5,     2,3,5},
                   {2,4,6,     1,3,0,     2,3,5},
                   {2,4,6,     1,0,5,     1,3,6}   };

  int f_dir_i[6][9]={  {0,1,1,   1,0,dir,  1,1,0  },
                       {1,0,1,   dir,1,0,  0,1,1  },
                       {0,0,1,   dir,1,0,  1,0,0  },
                       {1,1,0,   0,dir,1,  1,0,1  },
                       {0,1,0,   1,0,dir,  0,0,1  },
                       {1,0,0,   0,dir,1,  0,1,0  }  };

  // 4 regions with 4 faces each
  int r_i[6][16]={ {10,3,6,9,     12,2,10,8,    11,12,5,7,     11,0,4,1},
                   {10,3,6,9,     12,2,5,10,    11,1,12,8,     11,7,4,0},
                   {10,3,6,9,     12,2,10,8,    11,1,5,12,     11,7,4,0},
                   {10,3,6,9,     12,10,5,8,    11,2,4,12,     11,7,0,1},
                   {10,3,6,9,     12,10,5,8,    11,2,12,7,     11,0,4,1},
                   {10,3,6,9,     12,2,5,10,    11,12,4,8,     11,7,0,1}      };

  int r_dir_i[6][16]={ {0,1,0,0,    0,1,1,0,      0,1,0,0,     1,parent_face_dirs[2],0,1},
                       {0,0,1,0,    0,0,1,1,      0,0,1,0,     1,0,1,parent_face_dirs[2]},
                       {0,1,1,0,    0,1,1,0,      0,1,1,1,     1,0,1,parent_face_dirs[2]},
                       {0,0,0,1,    0,1,0,1,      0,0,0,1,     1,1,parent_face_dirs[2],0},
                       {0,1,0,1,    0,1,0,1,      0,1,1,1,     1,parent_face_dirs[2],0,1},
                       {0,0,1,1,    0,0,1,1,      0,1,1,1,     1,1,parent_face_dirs[2],0}     };

  //=====================================================

  // get the info directly available from the parent tet
  edges[0]=parent_edges[e_i[k]];
  faces[0]=parent_faces[2];

  // get info from parent face 0
  plist=get_split_faces_2(parent_faces[0]);
  edges[1]=(pEdge)PList_item(plist,0);
  edges[2]=(pEdge)PList_item(plist,1);
  faces[1]=(pFace)PList_item(plist,2);
  faces[2]=(pFace)PList_item(plist,3);
  faces[3]=(pFace)PList_item(plist,4);

  // get info from parent face 1
  plist=get_split_faces_2(parent_faces[1]);
  edges[3]=(pEdge)PList_item(plist,0);
  edges[4]=(pEdge)PList_item(plist,1);
  faces[4]=(pFace)PList_item(plist,2);
  faces[5]=(pFace)PList_item(plist,3);
  faces[6]=(pFace)PList_item(plist,4);

  // get info from parent face 3
  plist=get_split_faces_2(parent_faces[3]);
  edges[5]=(pEdge)PList_item(plist,0);
  edges[6]=(pEdge)PList_item(plist,1);
  faces[7]=(pFace)PList_item(plist,2);
  faces[8]=(pFace)PList_item(plist,3);
  faces[9]=(pFace)PList_item(plist,4);

  // create the 3 interior faces
  // use the edge on face 0 as the first edge
  for(j=0; j<3; j++) {
    for(i=0; i<3; i++) {
      f_edges[i]= edges[f_i[k][l]];
      f_dir[i]= f_dir_i[k][l];
      ++l;
    }
    faces[10+j]=M_createF(pmesh,3,f_edges,f_dir,g_entity);
  }

  /*
    create the 4 regions
    The regions created here have the correct face order
  */

  // select the negatively used interior face as face 0
  l=0;
  for(j=0; j<4; j++) {
    for(i=0; i<4; i++) {
      r_faces[i]= faces[r_i[k][l]];
      r_dir[i]= r_dir_i[k][l];
      ++l;
    }
    region[j]=M_createR(pmesh,4,r_faces,r_dir,g_entity);
  }

  // return new regions and new edges
  if( newRgns ) {
    for(j=0; j<4; j++) 
      PList_append(newRgns,region[j]);
  }
  if( newEdges ) {
    for(j=1; j<7; j++) 
      PList_append(newEdges,edges[j]);
  }

  return;
}

/*
 *  split a region with edge 0,1,2 marked
 *  MeshAdapt V1.0 Created by Xiangrong Li 05/18/99
 */
void meshTemplate::sub_template_3_4(pEdge parent_edges[6], pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, pPList newRgns, pPList newEdges)
{
  pFace r_faces[4];  // the 4 faces to create a region
  int r_dir[4];      // the orientation of the 4 faces
  pEdge f_edges[3];  // the 3 edges to create a face
  int f_dir[3];      // the orientation of the 3 edges

  pRegion regions[4];// the 4 regions created
  pFace faces[13];   // the 13 faces to create the 4 regions
  pEdge edges[6];    // the 6 edges to create the 3 interior faces

  pPList plist;
  pVertex verts[3];
  int n[3];

  // get the split faces and edges of parent face 0
  plist=get_split_faces_3(parent_faces[0]);
  faces[0]=(pFace)PList_item(plist,6);
  verts[0]=parent_verts[0];
  verts[1]=parent_verts[1];
  verts[2]=parent_verts[2];
  templatesUtil::map_vertices(parent_faces[0],verts,n);
  faces[1]=(pFace)PList_item(plist,n[0]+3);
  faces[2]=(pFace)PList_item(plist,n[1]+3);
  faces[3]=(pFace)PList_item(plist,n[2]+3);
  edges[0]=(pEdge)PList_item(plist,n[0]);
  edges[1]=(pEdge)PList_item(plist,n[1]);
  edges[2]=(pEdge)PList_item(plist,n[2]);

  // get the split faces and edge of parent face 1
  plist=get_split_faces_1(parent_faces[1]);
  edges[3]=(pEdge)PList_item(plist,0);
  faces[4]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[4],(pEntity)parent_edges[3]) )
    faces[5]=(pFace)PList_item(plist,2);
  else {
    faces[5]=faces[4];
    faces[4]=(pFace)PList_item(plist,2);
  }

  // get the split faces and edge of parent face 2
  plist=get_split_faces_1(parent_faces[2]);
  edges[4]=(pEdge)PList_item(plist,0);
  faces[6]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[6],(pEntity)parent_edges[4]) )
    faces[7]=(pFace)PList_item(plist,2);
  else {
    faces[7]=faces[6];
    faces[6]=(pFace)PList_item(plist,2);
  }

  // get the split faces and edge of parent face 3
  plist=get_split_faces_1(parent_faces[3]);
  edges[5]=(pEdge)PList_item(plist,0);
  faces[8]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[8],(pEntity)parent_edges[5]) )
    faces[9]=(pFace)PList_item(plist,2);
  else {
    faces[9]=faces[8];
    faces[8]=(pFace)PList_item(plist,2);
  }

  // create the three interior faces such that:
  //  (1) the new middle region will use them positively
  //  (2) use the edge on face 0 as first edge

  // Based on the above, the directions for 3 new faces are the same as below:
  if(parent_face_dirs[0])
    f_dir[0]=0;
  else
    f_dir[0]=1;
  f_dir[1]=1;
  f_dir[2]=0;

  // create face 10
  f_edges[0]= edges[0];
  f_edges[1]= edges[3];
  f_edges[2]= edges[5];
  faces[10]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  // create face 11
  f_edges[0]= edges[1];
  f_edges[1]= edges[4];
  f_edges[2]= edges[3];
  faces[11]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  // create face 12
  f_edges[0]= edges[2];
  f_edges[1]= edges[5];
  f_edges[2]= edges[4];
  faces[12]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  /*
    create the four regions
    The regions created here have the correct face order
  */

  // create region 0. It contains parent vertex 0 and uses face 10 as the first face
  r_faces[0]= faces[10];
  r_faces[1]= faces[1];   // e0 of face 0
  r_faces[2]= faces[4];   // e1 of face 0
  r_faces[3]= faces[9];   // e2 of face 0
  r_dir[0]= 0;
  r_dir[1]= parent_face_dirs[0];
  r_dir[2]= parent_face_dirs[1];
  r_dir[3]= parent_face_dirs[3];
  regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  // create region 1. It contains parent vertex 1 and uses face 11 as the first face
  r_faces[0]= faces[11];
  r_faces[1]= faces[2];   // e0 of face 0
  r_faces[2]= faces[6];   // e1 of face 0
  r_faces[3]= faces[5];   // e2 of face 0
  r_dir[0]= 0;
  r_dir[1]= parent_face_dirs[0];
  r_dir[2]= parent_face_dirs[2];
  r_dir[3]= parent_face_dirs[1];
  regions[1]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  // create region 2. It contains parent vertex 2 and uses face 12 as the first face
  r_faces[0]= faces[12];
  r_faces[1]= faces[3];    // e0 of face 0
  r_faces[2]= faces[8];    // e1 of face 0
  r_faces[3]= faces[7];    // e2 of face 0
  r_dir[0]= 0;
  r_dir[1]= parent_face_dirs[0];
  r_dir[2]= parent_face_dirs[3];
  r_dir[3]= parent_face_dirs[2];
  regions[2]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  // create middle region. It uses face 10 as the first face, positively
  r_faces[0]= faces[10];
  r_faces[1]= faces[12];   // e2 of face 0
  r_faces[2]= faces[11];   // e1 of face 0
  r_faces[3]= faces[0];    // e0 of face 0
  r_dir[0]= 1;
  r_dir[1]= 1;
  r_dir[2]= 1;
  r_dir[3]= parent_face_dirs[0];
  regions[3]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  if( newRgns ) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
    PList_append(newRgns,regions[3]);
  }
  if( newEdges ) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[4]);
    PList_append(newEdges,edges[5]);
  }

  return;
}

/*
 *  Edge 0,1,2,3 are marked
 *  There are 4 possible templates. All are implemented here
 *  MeshAdapt V1.0 Created by Xiangrong Li 05/19/99
 */
void meshTemplate::sub_template_4_1(pEdge parent_edges[6], pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, int k, pPList newRgns, pPList newEdges)
{
  pEdge edges[13];   // 13 edges to create  interior faces
  pFace faces[18];   // 15 faces to create 5  regions
  pFace r_faces[4];  // the 4 faces to create a region
  pEdge f_edges[3];  // the 3 edges to create a face
  pRegion regions[6];// the five/six regions created by this template
  int f_dir[3];      // the orientation of the 3 edges of a face
  int r_dir[4];      // the orientation of the 4 faces of a region

  pVertex verts[3];
  pPList plist;
  int n[3];
  int e1=0,e3=0;
  int i,j;
  int l=0;

  if(E_vertex(parent_edges[1],0)==parent_verts[1])
     e1=1;

  if(E_vertex(parent_edges[3],0)==parent_verts[0])
     e3=1;

  //==============================================
  //                tables
  int nf[]={6,6,4,6};  // # of faces created for different templates
  int nr[]={6,6,5,6};  // # of regions will be created for different templates

  // edge lookup table to create faces
  int f_i[4][18]=    { {0,4,7,   2,5,3,   12,4,2,   12,7,1,   12,6,9,  12,11,5},
                       {0,4,7,   12,3,8,  12,4,2,   12,7,1,   12,6,9,  12,11,5},
                       {0,4,7,   0,3,6,   2,5,3,    1,6,5,    0,0,0,   0,0,0},
                       {0,4,7,   12,3,8,  12,4,2,   12,7,1,   1,6,5,   12,11,5}
                     };

  int f_dir_i[4][18]={ {1-parent_face_dirs[0],1,1,    1-parent_face_dirs[0],1,1,
                        1,0,1-parent_face_dirs[0],    1,1,parent_face_dirs[0],
                        1,0,1-e1,                     1,e3,0                     },
                       {1-parent_face_dirs[0],0,1,    1,0,e1,
                        1,1,1-parent_face_dirs[0],    1,1,parent_face_dirs[0],
                        1,0,1-e1,                     1,e3,0                     },
                       {1-parent_face_dirs[0],1,0,    1-parent_face_dirs[0],0,1,
                        1-parent_face_dirs[0],1,1,    1-parent_face_dirs[0],0,0,
                        0,0,0,                        0,0,0                      },
                       {1-parent_face_dirs[0],0,0,    1,0,e1,
                        1,1,1-parent_face_dirs[0],    1,0,parent_face_dirs[0],
                        1-parent_face_dirs[0],0,0,    1,e3,0                     }
                     };

  // face lookup table to create regions
  int r_i[4][24]={     {12,1,6,11,  13,3,7,4,   15,14,12,0,  14,17,5,13,  16,15,10,2,  17,16,9,8},
                       {12,1,6,11,  15,14,12,0, 14,13,5,3,   13,17,4,7,   16,15,10,2,  17,16,9,8},
                       {12,1,6,11,  13,12,5,10, 14,3,7,4,    15,2,9,8,    13,15,14,0,  0,0,0,0},
                       {12,1,6,11,  14,13,5,3,  13,17,4,7,   15,14,12,0,  17,15,10,16, 16,2,9,8}
                 };

  int r_dir_i[4][24]={ {0,parent_face_dirs[0],0,0,
                        0,parent_face_dirs[0],parent_face_dirs[2],0,
                        0,1,1,parent_face_dirs[0],
                        0,1,0,1,
                        0,1,0,parent_face_dirs[0],
                        0,1,0,parent_face_dirs[2]                     },
                       {0,parent_face_dirs[0],1,0,
                        0,1,1,parent_face_dirs[0],
                        0,1,1,parent_face_dirs[0],
                        0,1,1,parent_face_dirs[2],
                        0,1,0,parent_face_dirs[0],
                        0,1,0,parent_face_dirs[2]                     },
                       {0,parent_face_dirs[0],0,1,
                        0,1,0,1,
                        0,parent_face_dirs[0],parent_face_dirs[2],0,
                        0,parent_face_dirs[0],1,parent_face_dirs[2],
                        1,1,1,parent_face_dirs[0],
                        0,0,0,0},
                       {0,parent_face_dirs[0],1,1,
                        0,1,1,parent_face_dirs[0],
                        0,1,1,parent_face_dirs[2],
                        0,1,1,parent_face_dirs[0],
                        0,1,1,1,
                        0,parent_face_dirs[0],1,parent_face_dirs[2]   }
                     };
  //==========================================

  // get the split faces and edge of parent face 0
  plist=get_split_faces_3(parent_faces[0]);
  faces[0]=(pFace)PList_item(plist,6);
  verts[0]=parent_verts[0];
  verts[1]=parent_verts[2];
  verts[2]=parent_verts[1];
  templatesUtil::map_vertices(parent_faces[0],verts,n);
  faces[1]=(pFace)PList_item(plist,n[0]+3);
  faces[2]=(pFace)PList_item(plist,n[1]+3);
  faces[3]=(pFace)PList_item(plist,n[2]+3);
  edges[0]=(pEdge)PList_item(plist,n[0]);
  edges[1]=(pEdge)PList_item(plist,n[1]);
  edges[2]=(pEdge)PList_item(plist,n[2]);

  // get info from parent face 1
  plist=get_split_faces_2(parent_faces[1]);
  edges[3]=(pEdge)PList_item(plist,0);
  edges[4]=(pEdge)PList_item(plist,1);
  faces[4]=(pFace)PList_item(plist,2);
  faces[5]=(pFace)PList_item(plist,3);
  faces[6]=(pFace)PList_item(plist,4);

  // get info from parent face 2
  plist=get_split_faces_1(parent_faces[2]);
  edges[5]=(pEdge)PList_item(plist,0);
  faces[7]=(pFace)PList_item(plist,1);
  if( F_inClosure(faces[7],(pEntity)parent_edges[4]) )
    faces[8]=(pFace)PList_item(plist,2);
  else {
    faces[8]=faces[7];
    faces[7]=(pFace)PList_item(plist,2);
  }

  // get info from parent face 3
  plist=get_split_faces_2(parent_faces[3]);
  edges[6] =(pEdge)PList_item(plist,0);
  edges[7] =(pEdge)PList_item(plist,1);
  faces[9] =(pFace)PList_item(plist,2);
  faces[10]=(pFace)PList_item(plist,3);
  faces[11]=(pFace)PList_item(plist,4);

  if (k!=2){
    // create the interior edge

    // 1. get info from edge 1
    plist=get_split_edges(parent_edges[1]);
    verts[0]=(pVertex)PList_item(plist,0);
    edges[8]=(pEdge)PList_item(plist,1);
    if(E_vertex(edges[8],0)==parent_verts[1] || E_vertex(edges[8],1)==parent_verts[1])
      edges[9]=(pEdge)PList_item(plist,2);
    else {
      edges[9]=edges[8];
      edges[8]=(pEdge)PList_item(plist,2);
    }

    // 2. get info from edge 3
    plist=get_split_edges(parent_edges[3]);
    verts[1] =(pVertex)PList_item(plist,0);
    edges[10]=(pEdge)PList_item(plist,1);
    if(E_vertex(edges[10],0)==parent_verts[0] || E_vertex(edges[10],1)==parent_verts[0])
      edges[11]=(pEdge)PList_item(plist,2);
    else {
      edges[11]=edges[10];
      edges[10]=(pEdge)PList_item(plist,2);
    }

    // create the interior edge
    edges[12]=M_createE(pmesh,verts[0],verts[1],g_entity);
  }

  // create the interior faces
  for(j=0; j<nf[k]; j++) {
    for(i=0; i<3; i++) {
      f_edges[i]= edges[f_i[k][l]];
      f_dir[i]= f_dir_i[k][l];
      ++l;
    }
    faces[12+j]=M_createF(pmesh,3,f_edges,f_dir,g_entity);
  }

  /*
    create the regions
    The regions created here have the correct face order
  */
  l=0;
  for(j=0; j<nr[k]; j++) {
    for(i=0; i<4; i++) {
      r_faces[i]= faces[r_i[k][l]];
      r_dir[i]= r_dir_i[k][l];
      ++l;
    }
    regions[j]=M_createR(pmesh,4,r_faces,r_dir,g_entity);
  }

  if( newRgns ) {
    for(j=0; j<nr[k]; j++) 
      PList_append(newRgns,regions[j]);
  }
  if( newEdges ) {
    if (k!=2)
      PList_append(newEdges,edges[12]);
    for(j=0; j<8; j++) 
      PList_append(newEdges,edges[j]);
  }
    
  return;
}

/*
 * split a region with four marked edges
 * Case 1: edge 1,2,3,4 are marked. There are 16 possibilities.
 * MeshAdapt V1.0 Created 05/21/99 by Xiangrong Li
 *                modified 6/28/01 by Xiangrong Li
 */
void meshTemplate::sub_template_4_2_a(pEdge parent_edges[6], pFace parent_faces[4], pVertex parent_verts[4], pGEntity g_entity, int k, pPList newRgns, pPList newEdges)
{
  pFace r_faces[4];  // the 4 faces to create a region
  int r_dir[4];      // the orientation of the 4 faces
  pEdge f_edges[3];  // the 3 edges to create a face
  int f_dir[3];      // the orientation of the 3 edges

  pRegion regions[6];// the 6 regions created
  pFace faces[18];   // the 18 faces to create the 4 regions
  pEdge edges[13];   // the 13 edges to create the 3 interior faces
  pVertex verts[2];  // the 2 vertices to create the interior edge

  pPList plist;
  int i,j;
  int l=0;

  int e1=0,e3=0;
  if(k==5 || k==7 || k==11 || k==13 || k==14 || k==15){
    if(E_vertex(parent_edges[2],0)==parent_verts[0])
      e1=1;
    if(E_vertex(parent_edges[4],0)==parent_verts[1])
      e3=1;

    // get info from parent edge 2
    plist=get_split_edges(parent_edges[2]);
    verts[0]=(pVertex)PList_item(plist,0);
    edges[0]=(pEdge)PList_item(plist,1);
    if(E_vertex(edges[0],0)==parent_verts[0] || E_vertex(edges[0],1)==parent_verts[0])
      edges[1]=(pEdge)PList_item(plist,2);
    else {
      edges[1]=edges[0];
      edges[0]=(pEdge)PList_item(plist,2);
    }

    // get info from parent edge 4
    plist=get_split_edges(parent_edges[4]);
    verts[1]=(pVertex)PList_item(plist,0);
    edges[2]=(pEdge)PList_item(plist,1);
    if(E_vertex(edges[2],0)==parent_verts[1] || E_vertex(edges[2],1)==parent_verts[1])
      edges[3]=(pEdge)PList_item(plist,2);
    else {
      edges[3]=edges[2];
      edges[2]=(pEdge)PList_item(plist,2);
    }
  }
  else {
    if(E_vertex(parent_edges[1],0)==parent_verts[1])
      e1=1;
    if(E_vertex(parent_edges[3],0)==parent_verts[0])
      e3=1;

    // get info from parent edge 1
    plist=get_split_edges(parent_edges[1]);
    verts[0]=(pVertex)PList_item(plist,0);
    edges[0]=(pEdge)PList_item(plist,1);
    if(E_vertex(edges[0],0)==parent_verts[1] || E_vertex(edges[0],1)==parent_verts[1])
      edges[1]=(pEdge)PList_item(plist,2);
    else {
      edges[1]=edges[0];
      edges[0]=(pEdge)PList_item(plist,2);
    }

    // get info from parent edge 3
    plist=get_split_edges(parent_edges[3]);
    verts[1]=(pVertex)PList_item(plist,0);
    edges[2]=(pEdge)PList_item(plist,1);
    if(E_vertex(edges[2],0)==parent_verts[0] || E_vertex(edges[2],1)==parent_verts[0])
      edges[3]=(pEdge)PList_item(plist,2);
    else {
      edges[3]=edges[2];
      edges[2]=(pEdge)PList_item(plist,2);
    }
  }

  //====================================================
  //                tables
  // 6 interior faces with 3 edges each
  int f_i[16][18]={ {4,2,5,     4,7,0,     4,11,1,   4,3,9,    4,12,6,    4,8,10},
                    {5,7,12,    4,7,0,     4,11,1,   4,3,9,    4,12,6,    4,8,10},
                    {4,2,5,     5,10,7,    4,11,1,   4,3,9,    4,12,6,    4,8,10},
                    {0,0,0,     0,0,0,     0,0,0,    0,0,0,    0,0,0,     0,0,0},
                    {4,2,5,     4,7,0,     4,11,1,   8,9,11,   4,12,6,    4,8,10},
                    {5,7,12,    4,2,5,     4,9,1,    8,9,11,   4,10,6,    4,8,12},
                    {4,2,5,     5,10,7,    4,11,1,   8,9,11,   4,12,6,    4,8,10},
                    {4,7,0,     4,2,5,     4,9,1,    8,9,11,   4,10,6,    4,8,12},
                    {4,2,5,     4,7,0,     6,11,9,   4,3,9,    4,12,6,    4,8,10},
                    {5,7,12,    4,7,0,     6,11,9,   4,3,9,    4,12,6,    4,8,10},
                    {4,2,5,     5,10,7,    6,11,9,   4,3,9,    4,12,6,    4,8,10},
                    {4,7,0,     4,2,5,     6,11,9,   4,3,11,   4,10,6,    4,8,12},
                    {0,0,0,     0,0,0,     0,0,0,    0,0,0,    0,0,0,     0,0,0},
                    {5,7,12,    4,2,5,     4,9,1,    4,3,11,   4,10,6,    4,8,12},
                    {4,7,0,     5,10,7,    4,9,1,    4,3,11,   4,10,6,    4,8,12},
                    {4,7,0,     4,2,5,     4,9,1,    4,3,11,   4,10,6,    4,8,12}
                  };

  int f_dir_i[16][18]={ {1,1-e3,1,  1,0,e1,   1,0,1-e1,  1,e3,1,  1,1,0,  1,1,0},
                        {0,1,1,     1,0,e1,   1,0,1-e1,  1,e3,1,  1,1,1,  1,1,0},
                        {1,1-e3,1,  1,1,0,    1,0,1-e1,  1,e3,1,  1,1,0,  1,0,0},
                        {0,0,0,     0,0,0,    0,0,0,     0,0,0,   0,0,0,  0,0,0},
                        {1,1-e3,1,  1,0,e1,   1,0,1-e1,  1,0,1,   1,1,0,  1,1,1},
                        {0,1,1,     1,1-e3,1, 1,0,1-e1,  1,0,1,   1,1,0,  1,0,1},
                        {1,1-e3,1,  1,0,0,    1,0,1-e1,  0,0,1,   1,1,0,  1,0,1},
                        {1,0,e1,    1,1-e3,1, 1,0,1-e1,  0,0,1,   1,1,0,  1,1,1},
                        {1,1-e3,1,  1,0,e1,   1,0,1,     1,e3,1,  1,0,0,  1,1,0},
                        {0,1,0,     1,0,e1,   0,0,1,     1,e3,1,  1,0,1,  1,1,0},
                        {1,1-e3,1,  1,1,0,    1,0,1,     1,e3,1,  1,0,0,  1,0,0},
                        {1,0,e1,    1,1-e3,1, 0,0,1,     1,e3,1,  1,0,0,  1,1,0},
                        {0,0,0,     0,0,0,    0,0,0,     0,0,0,   0,0,0,  0,0,0},
                        {0,1,0,     1,1-e3,1, 1,0,1-e1,  1,e3,1,  1,1,0,  1,0,0},
                        {1,0,e1,    1,0,0,    1,0,1-e1,  1,e3,1,  1,1,1,  1,1,0},
                        {1,0,e1,    1,1-e3,1, 1,0,1-e1,  1,e3,1,  1,1,0,  1,1,0}
                     };

  // 6 regions with 4 faces each
  int r_i[16][24]={{16,12,11,1,   12,13,3,0,   13,17,4,8,   17,15,5,7,   14,16,10,2,   15,14,9,6},
                   {12,0,3,11,    16,13,12,1,  13,17,4,8,   17,15,5,7,   14,16,10,2,   15,14,9,6},
                   {16,12,11,1,   12,17,4,13,  13,0,8,3,    17,15,5,7,   14,16,10,2,   15,14,9,6},
                   {0,0,0,0,      0,0,0,0,     0,0,0,0,     0,0,0,0,     0,0,0,0,      0,0,0,0},
                   {16,12,11,1,   12,13,3,0,   13,17,4,8,   17,14,15,7,  14,16,10,2,   15,5,6,9},
                   {12,0,3,11,    17,13,4,12,  13,16,8,1,   16,14,7,2,   14,17,15,10,  15,5,6,9},
                   {16,12,11,1,   12,17,4,13,  13,0,8,3,    17,14,15,7,  14,16,10,2,   15,5,6,9},
                   {17,12,4,11,   12,13,3,0,   13,16,8,1,   16,14,7,2,   14,17,15,10,  15,5,6,9},
                   {16,12,11,1,   12,13,3,0,   13,17,4,8,   17,15,5,7,   15,16,10,14,  14,2,9,6},
                   {12,0,3,11,    16,13,12,1,  13,17,4,8,   17,15,5,7,   15,16,10,14,  14,2,9,6},
                   {16,12,11,1,   12,17,4,13,  13,0,8,3,    17,15,5,7,   15,16,10,14,  14,2,9,6},
                   {17,12,4,11,   12,13,3,0,   13,16,8,1,   16,15,7,14,  15,17,5,10,   14,2,9,6},
                   {0,0,0,0,      0,0,0,0,     0,0,0,0,     0,0,0,0,     0,0,0,0,      0,0,0,0},
                   {12,0,3,11,    17,13,4,12,  13,16,8,1,   16,14,7,2,   14,15,6,9,    15,17,5,10},
                   {17,12,4,11,   12,16,13,1,  13,0,8,3,    16,14,7,2,   14,15,6,9,    15,17,5,10},
                   {17,12,4,11,   12,13,3,0,   13,16,8,1,   16,14,7,2,   14,15,6,9,    15,17,5,10}
                 };

  int r_dir_i[16][24]={{0,1,0,0,  0,1,0,0,     0,1,0,0,    0,1,0,0,   0,1,0,0,   0,1,0,0},
                       {0,1,0,0,  0,1,1,1,     0,1,0,0,    0,1,0,0,   0,1,0,1,   0,1,0,0},
                       {0,1,0,0,  0,1,1,1,     0,0,0,1,    0,1,1,0,   0,1,0,0,   0,1,0,0},
                       {0,0,0,0,  0,0,0,0,     0,0,0,0,    0,0,0,0,   0,0,0,0,   0,0,0,0},
                       {0,1,0,0,  0,1,0,0,     0,1,0,1,    0,1,1,1,   0,1,0,0,   0,0,1,0},
                       {0,1,0,0,  0,1,0,1,     0,1,1,1,    0,1,1,1,   0,1,1,0,   0,0,1,0},
                       {0,1,0,0,  0,1,1,1,     0,0,1,1,    0,1,1,1,   0,1,0,0,   0,1,1,0},
                       {0,1,1,0,  0,1,1,1,     0,1,1,1,    0,1,1,1,   0,1,1,0,   0,1,1,0},
                       {0,1,1,0,  0,1,0,0,     0,1,0,0,    0,1,0,0,   0,1,1,1,   0,0,1,0},
                       {0,1,0,1,  0,1,1,1,     0,1,0,0,    0,1,0,0,   0,1,1,1,   0,1,1,0},
                       {0,1,1,0,  0,1,1,1,     0,0,0,1,    0,1,1,0,   0,1,1,1,   0,0,1,0},
                       {0,1,1,1,  0,1,1,1,     0,1,0,1,    0,1,0,1,   0,1,1,1,   0,1,1,0},
                       {0,0,0,0,  0,0,0,0,     0,0,0,0,    0,0,0,0,   0,0,0,0,   0,0,0,0},
                       {0,1,0,1,  0,1,0,1,     0,1,1,1,    0,1,1,1,   0,1,1,1,   0,1,0,1},
                       {0,1,1,1,  0,1,1,0,     0,0,1,1,    0,1,1,0,   0,1,1,1,   0,1,1,1},
                       {0,1,1,1,  0,1,1,1,     0,1,1,1,    0,1,1,1,   0,1,1,1,   0,1,1,1}
                     };

  //=====================================================

  // create the interior edge
  edges[4]=M_createE(pmesh,verts[0],verts[1],g_entity);

  // get info from parent face 0
  plist=get_split_faces_2(parent_faces[0]);
  edges[5]=(pEdge)PList_item(plist,0);
  edges[6]=(pEdge)PList_item(plist,1);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  faces[2]=(pFace)PList_item(plist,4);

  // get info from parent face 1
  plist=get_split_faces_2(parent_faces[1]);
  edges[7]=(pEdge)PList_item(plist,0);
  edges[8]=(pEdge)PList_item(plist,1);
  faces[3]=(pFace)PList_item(plist,2);
  faces[4]=(pFace)PList_item(plist,3);
  faces[5]=(pFace)PList_item(plist,4);

  // get info from parent face 2
  plist=get_split_faces_2(parent_faces[2]);
  edges[9]= (pEdge)PList_item(plist,0);
  edges[10]=(pEdge)PList_item(plist,1);
  faces[6]= (pFace)PList_item(plist,2);
  faces[7]= (pFace)PList_item(plist,3);
  faces[8]= (pFace)PList_item(plist,4);

  // get info from parent face 3
  plist=get_split_faces_2(parent_faces[3]);
  edges[11]=(pEdge)PList_item(plist,0);
  edges[12]=(pEdge)PList_item(plist,1);
  faces[9]= (pFace)PList_item(plist,2);
  faces[10]=(pFace)PList_item(plist,3);
  faces[11]=(pFace)PList_item(plist,4);

  // create the 6 interior faces
  // use the edge on face 0 as the first edge
  for(j=0; j<6; j++) {
    for(i=0; i<3; i++) {
      f_edges[i]= edges[f_i[k][l]];
      f_dir[i]= f_dir_i[k][l];
      ++l;
    }
    faces[12+j]=M_createF(pmesh,3,f_edges,f_dir,g_entity);
  }

  /*
    create the 6 regions
    The regions created here have the correct face order
  */

  // select the negatively used interior face as face 0
  l=0;
  for(j=0; j<6; j++) {
    for(i=0; i<4; i++) {
      r_faces[i]= faces[r_i[k][l]];
      r_dir[i]= r_dir_i[k][l];
      ++l;
    }
    regions[j]=M_createR(pmesh,4,r_faces,r_dir,g_entity);
  }

  if( newRgns ) {
    for(j=0; j<6; j++) 
      PList_append(newRgns,regions[j]);
  }
  if( newEdges ) {
    for(j=4; j<13; j++) 
      PList_append(newEdges,edges[j]);
  }

  // check if this is the shorter diagonal edge
  double d0, d1;
  pVertex opVerts[2];
  opVerts[0]=F_edOpVt(faces[16],edges[4]);
  opVerts[1]=F_edOpVt(faces[17],edges[4]);
  d0=pSizeField->lengthSq(verts[0], verts[1]);
  d1=pSizeField->lengthSq(opVerts[0],opVerts[1]); 
  if( d1 < 0.9*d0 ) {
    PList_append(ambigEdges,edges[4]);
    PList_append(ambigEdges,F_edOpVt(faces[16],edges[4]));
    PList_append(ambigEdges,F_edOpVt(faces[17],edges[4]));
  }

  return;
}

/*
 * split a region with four marked edges
 * Case 2: edge 1,2,3,4 are marked. for k=3 and k=12. Centroid vertex is introduced.
 * MeshAdapt V1.0 Created by Xiangrong Li 05/21/99
 *                modified 6/28/01
 */
pVertex meshTemplate::sub_template_4_2_b(pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, pPList newRgns, pPList newEdges)
{
  pVertex centroid;       // the centroid of this tetahedra
  int size=12;            // size of the face list
  pFace faces[12];        // face list of a polygon
  int dirs[12];           // direction of each face
  pGEntity g_entities[12];// classified model of the new region associated with each face

  pEdge edges[4];         // the ambiguous edges. To be used later to eliminate centroid Add 6/28/01
  pVertex verts[8];       // collect info to be used later to eliminate centroid  Add 6/28/01

  double xyz[]={0.0, 0.0, 0.0};
  double par[]={0.0, 0.0, 0.0};

  pPList plist;
  int i;

  // get info from parent face 0
  plist=get_split_faces_2(parent_faces[0]);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  faces[2]=(pFace)PList_item(plist,4);
  for(i=0;i<3;i++) {
    dirs[i]=parent_face_dirs[0];
    g_entities[i]=g_entity;
  }

  // collect info for delete steiner
  edges[0]=(pEdge)PList_item(plist,0);
  verts[0]=F_edOpVt(faces[1],edges[0]);
  verts[1]=F_edOpVt(faces[0],edges[0]);
  // collect new edges if newEdges is defined
  if( newEdges ) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,(pEdge)PList_item(plist,1));
  }

  // get info from parent face 1
  plist=get_split_faces_2(parent_faces[1]);
  faces[3]=(pFace)PList_item(plist,2);
  faces[4]=(pFace)PList_item(plist,3);
  faces[5]=(pFace)PList_item(plist,4);
  for(i=3;i<6;i++) {
    dirs[i]=parent_face_dirs[1];
    g_entities[i]=g_entity;
  }

  // collect info for delete steiner
  edges[1]=(pEdge)PList_item(plist,0);
  verts[2]=F_edOpVt(faces[4],edges[1]);
  verts[3]=F_edOpVt(faces[3],edges[1]);
  // collect new edges if newEdges is defined
  if( newEdges ) {
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,(pEdge)PList_item(plist,1));
  }

  // get info from parent face 2
  plist=get_split_faces_2(parent_faces[2]);
  faces[6]= (pFace)PList_item(plist,2);
  faces[7]= (pFace)PList_item(plist,3);
  faces[8]= (pFace)PList_item(plist,4);
  for(i=6;i<9;i++) {
    dirs[i]=parent_face_dirs[2];
    g_entities[i]=g_entity;
  }

  // collect info for delete steiner
  edges[2]=(pEdge)PList_item(plist,0);
  verts[4]=F_edOpVt(faces[7],edges[2]);
  verts[5]=F_edOpVt(faces[6],edges[2]);
  // collect new edges if newEdges is defined
  if( newEdges ) {
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,(pEdge)PList_item(plist,1));
  }

  // get info from parent face 3
  plist=get_split_faces_2(parent_faces[3]);
  faces[9]= (pFace)PList_item(plist,2);
  faces[10]=(pFace)PList_item(plist,3);
  faces[11]=(pFace)PList_item(plist,4);
  for(i=9;i<12;i++) {
    dirs[i]=parent_face_dirs[3];
    g_entities[i]=g_entity;
  }
  
  // collect info for delete steiner
  edges[3]=(pEdge)PList_item(plist,0);
  verts[6]=F_edOpVt(faces[10],edges[3]);
  verts[7]=F_edOpVt(faces[9],edges[3]);
  // collect new edges if newEdges is defined
  if( newEdges ) {
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,(pEdge)PList_item(plist,1));
  }

  // calculate the centroid and interpolate tesnor field
  pMSize pScenter = templatesUtil::tetCenter(parent_verts,xyz,pSizeField);

  // create the centroid and the regions inside the polyhedron
  //#ifndef AOMD_
  centroid = M_createVP2(pmesh, xyz, par, 0, g_entity);
  //#else
  //  EN_getDataInt((pEntity)PassIdRegion,vtIdTag,&i);
  //  centroid= M_createVP2(pmesh, xyz, par, i, g_entity);
  //  EN_deleteData((pEntity)PassIdRegion,vtIdTag);
  //#endif
  pSizeField->setSize((pEntity)centroid,pScenter);
  faces_vert_create_regions(pmesh,centroid,size,faces,dirs,g_entities,newRgns,newEdges);

  // remember the centroid vertex for later processing
  pPList entlist=PList_new();
  for(i=0; i<4; i++)
  {

    if (E_typeInBL(edges[i]))
      continue;

    PList_append(entlist,edges[i]);
    PList_append(entlist,verts[2*i]);
    PList_append(entlist,verts[2*i+1]);
  }
  if (PList_size(entlist))
  {
    EN_attachDataPtr((pEntity)centroid,ptr_reff,entlist);
    PList_append(steinerVerts,centroid);
  }
  else
  {
    PList_delete(entlist);
  }

  return centroid;
}

/*
 *  Split a region with edge 1,2,3,4,5 marked. 4 possibilites
 *  MeshAdapt V1.0         Xiangrong Li 05/24/99
 */
void meshTemplate::sub_template_5(pEdge parent_edges[6], pFace parent_faces[4], int parent_face_dirs[4], pVertex parent_verts[4], pGEntity g_entity, int k, pPList newRgns, pPList newEdges)
{
  pFace r_faces[4];  // the 4 faces to create a region
  int r_dir[4];      // the orientation of the 4 faces
  pEdge f_edges[3];  // the 3 edges to create a face
  int f_dir[3];      // the orientation of the 3 edges

  pRegion regions[7];// the 7 regions created
  pFace faces[21];   // the 21 faces to create the 7 regions
  pEdge edges[13];   // the 13 edges to create the 7 interior faces
  pVertex verts[3];

  pPList plist;
  int n[3];
  int e1=0,e3=0;
  int i,j;
  int l=0;

  if(k==0) {
    if(E_vertex(parent_edges[1],0) == parent_verts[1])
      e1=1;
    if(E_vertex(parent_edges[3],0) == parent_verts[0])
      e3=1;

    // get info from parent edge 1
    plist=get_split_edges(parent_edges[1]);
    verts[0]=(pVertex)PList_item(plist,0);
    edges[0]=(pEdge)PList_item(plist,1);
    if(parent_verts[2]==E_vertex(edges[0],0) || parent_verts[2]==E_vertex(edges[0],1))
      edges[0]=(pEdge)PList_item(plist,2);

    // get info from parent edge 3
    plist=get_split_edges(parent_edges[3]);
    verts[1]=(pVertex)PList_item(plist,0);
    edges[1]=(pEdge)PList_item(plist,1);
    if(parent_verts[3]==E_vertex(edges[1],0) || parent_verts[3]==E_vertex(edges[1],1))
      edges[1]=(pEdge)PList_item(plist,2);
  }
  else {
    if(E_vertex(parent_edges[2],0) == parent_verts[0])
      e1=1;
    if(E_vertex(parent_edges[4],0) == parent_verts[3])
      e3=1;

    // get info from parent edge 2
    plist=get_split_edges(parent_edges[2]);
    verts[0]=(pVertex)PList_item(plist,0);
    edges[0]=(pEdge)PList_item(plist,1);
    if(parent_verts[2]==E_vertex(edges[0],0) || parent_verts[2]==E_vertex(edges[0],1))
      edges[0]=(pEdge)PList_item(plist,2);

    // get info from parent edge 4
    plist=get_split_edges(parent_edges[4]);
    verts[1]=(pVertex)PList_item(plist,0);
    edges[1]=(pEdge)PList_item(plist,1);
    if(parent_verts[3]==E_vertex(edges[1],0) || parent_verts[3]==E_vertex(edges[1],1))
      edges[1]=(pEdge)PList_item(plist,2);
  }

  //==============================================================
  //                tables
  // 7 interior faces with 3 edges each
  int f_i[4][21]={     {2,1,3,   2,5,0,   4,11,8,    6,9,12,   2,10,4,   2,6,7,  2,12,8},
                       {3,5,10,  2,1,3,   4,11,8,    6,9,12,   2,7,4,    2,6,10, 2,9,11},
                       {2,5,0,   3,7,5,   4,11,8,    6,9,12,   2,7,4,    2,6,10, 2,9,11},
                       {2,5,0,   2,1,3,   4,11,8,    6,9,12,   2,7,4,    2,6,10, 2,9,11}
                 };

  int f_dir_i[4][21]={ {1,1-e3,1,
                        1,0,   e1,
                        1,1-parent_face_dirs[3],1-parent_face_dirs[2],
                        1,1-parent_face_dirs[2],1-parent_face_dirs[3],
                        1,1-parent_face_dirs[3],0,
                        1,1,parent_face_dirs[2],
                        1,parent_face_dirs[3],1-parent_face_dirs[2]   },
                       {0,1,1-parent_face_dirs[3],
                        1,e3,1,
                        0,1-parent_face_dirs[3],1-parent_face_dirs[2],
                        1,1-parent_face_dirs[2],1-parent_face_dirs[3],
                        1,parent_face_dirs[2],0,
                        1,0,1-parent_face_dirs[3],
                        1,1-parent_face_dirs[2],parent_face_dirs[3]   },
                       {1,0,e1,
                        1,1-parent_face_dirs[2],0,
                        1,1-parent_face_dirs[3],1-parent_face_dirs[2],
                        0,1-parent_face_dirs[2],1-parent_face_dirs[3],
                        1,parent_face_dirs[2],1,
                        1,1,1-parent_face_dirs[3],
                        1,1-parent_face_dirs[2],parent_face_dirs[3]   },
                       {1,0,e1,
                        1,e3,1,
                        0,1-parent_face_dirs[3],1-parent_face_dirs[2],
                        0,1-parent_face_dirs[2],1-parent_face_dirs[3],
                        1,parent_face_dirs[2],0,
                        1,1,1-parent_face_dirs[3],
                        1,1-parent_face_dirs[2],parent_face_dirs[3]}
                      };

  // 7 regions with 4 faces each
  int r_i[4][28]={ {18,14,11,1,  14,15,3,0,   15,19,4,7,   19,20,17,6,  20,18,10,16,  16,2,12,8,  17,5,9,13},
                   {14,0,3,11,   19,15,4,14,  15,18,7,1,   18,20,6,16,  20,19,17,10,  16,2,12,8,  17,5,9,13},
                   {19,14,4,11,  14,18,15,1,  15,0,7,3,    18,20,6,16,  20,19,17,10,  16,2,12,8,  17,5,9,13},
                   {19,14,4,11,  14,15,3,0,   15,18,7,1,   18,20,6,16,  20,19,17,10,  16,2,12,8,  17,5,9,13}
                 };

  int r_dir_i[4][28]={ {0,1,parent_face_dirs[3],0,
                        0,1,0,0,
                        0,1,0,parent_face_dirs[2],
                        0,1,1,parent_face_dirs[2],
                        0,1,parent_face_dirs[3],1,
                        0,0,parent_face_dirs[3],parent_face_dirs[2],
                        0,0,parent_face_dirs[2],parent_face_dirs[3]   },
                       {0,1,0,parent_face_dirs[3],
                        0,1,0,1,
                        0,1,parent_face_dirs[2],1,
                        0,1,parent_face_dirs[2],1,
                        0,1,1,parent_face_dirs[3],
                        0,1,parent_face_dirs[3],parent_face_dirs[2],
                        0,0,parent_face_dirs[2],parent_face_dirs[3]   },
                       {0,1,1,parent_face_dirs[3],
                        0,1,1,0,
                        0,0,parent_face_dirs[2],1,
                        0,1,parent_face_dirs[2],1,
                        0,1,1,parent_face_dirs[3],
                        0,0,parent_face_dirs[3],parent_face_dirs[2],
                        0,1,parent_face_dirs[2],parent_face_dirs[3]   },
                       {0,1,1,parent_face_dirs[3],
                        0,1,1,1,
                        0,1,parent_face_dirs[2],1,
                        0,1,parent_face_dirs[2],1,
                        0,1,1,parent_face_dirs[3],
                        0,1,parent_face_dirs[3],parent_face_dirs[2],
                        0,1,parent_face_dirs[2],parent_face_dirs[3]   }
                     };
  //===========================================================

  // create the interior edge
  edges[2]=M_createE(pmesh,verts[0],verts[1],g_entity);

  // get info from parent face 0
  plist=get_split_faces_2(parent_faces[0]);
  edges[3]=(pEdge)PList_item(plist,0);
  edges[4]=(pEdge)PList_item(plist,1);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  faces[2]=(pFace)PList_item(plist,4);

  // get info from parent face 1
  plist=get_split_faces_2(parent_faces[1]);
  edges[5]=(pEdge)PList_item(plist,0);
  edges[6]=(pEdge)PList_item(plist,1);
  faces[3]=(pFace)PList_item(plist,2);
  faces[4]=(pFace)PList_item(plist,3);
  faces[5]=(pFace)PList_item(plist,4);

  // get info from parent face 2
  plist=get_split_faces_3(parent_faces[2]);
  faces[6]=(pFace)PList_item(plist,6);
  verts[0]=parent_verts[1];
  verts[1]=parent_verts[2];
  verts[2]=parent_verts[3];
  templatesUtil::map_vertices(parent_faces[2],verts,n);
  faces[7]=(pFace)PList_item(plist,n[0]+3);
  faces[8]=(pFace)PList_item(plist,n[1]+3);
  faces[9]=(pFace)PList_item(plist,n[2]+3);
  edges[7]=(pEdge)PList_item(plist,n[0]);
  edges[8]=(pEdge)PList_item(plist,n[1]);
  edges[9]=(pEdge)PList_item(plist,n[2]);

  // get info from parent face 3
  plist=get_split_faces_3(parent_faces[3]);
  faces[10]=(pFace)PList_item(plist,6);
  verts[0]=parent_verts[0];
  verts[1]=parent_verts[2];
  verts[2]=parent_verts[3];
  templatesUtil::map_vertices(parent_faces[3],verts,n);
  faces[11]=(pFace)PList_item(plist,n[0]+3);
  faces[12]=(pFace)PList_item(plist,n[1]+3);
  faces[13]=(pFace)PList_item(plist,n[2]+3);
  edges[10]=(pEdge)PList_item(plist,n[0]);
  edges[11]=(pEdge)PList_item(plist,n[1]);
  edges[12]=(pEdge)PList_item(plist,n[2]);

  // create the 6 interior faces
  // use the edge on face 0 as the first edge
  for(j=0; j<7; j++) {
    for(i=0; i<3; i++) {
      f_edges[i]= edges[f_i[k][l]];
      f_dir[i]= f_dir_i[k][l];
      ++l;
    }
    faces[14+j]=M_createF(pmesh,3,f_edges,f_dir,g_entity);
  }

  /*
    create the 4 regions
    The regions created here have the correct face order
  */

  // select the negatively used interior face as face 0
  l=0;
  for(j=0; j<7; j++) {
    for(i=0; i<4; i++) {
      r_faces[i]= faces[r_i[k][l]];
      r_dir[i]= r_dir_i[k][l];
      ++l;
    }
    regions[j]=M_createR(pmesh,4,r_faces,r_dir,g_entity);
  }

  if( newRgns ) {
    for(j=0; j<7; j++) 
      PList_append(newRgns,regions[j]);
  }
  if( newEdges ) {
    for(j=2; j<13; j++) 
      PList_append(newEdges,edges[j]);
  }
  
  // check if this is the shorter diagonal edge
  double d0, d1;
  pVertex opVerts[2];
  opVerts[0]=F_edOpVt(faces[18],edges[2]);
  opVerts[1]=F_edOpVt(faces[19],edges[2]);
  d0=pSizeField->lengthSq(verts[0], verts[1]);
  d1=pSizeField->lengthSq(opVerts[0],opVerts[1]); 
  if( d1 < 0.9*d0 ) {
    PList_append(ambigEdges,edges[2]);
    PList_append(ambigEdges,F_edOpVt(faces[18],edges[2]));
    PList_append(ambigEdges,F_edOpVt(faces[19],edges[2]));
  }

  return;
}

/*
   All edges are marked
 */
void meshTemplate::sub_template_6(pRegion region,
				  pEdge parent_edges[6], 
				  pFace parent_faces[4],
				  int parent_face_dirs[4], 
				  pVertex parent_verts[4], 
				  pGEntity g_entity, 
				  pPList newRgns, 
				  pPList newEdges)
{
  pEdge edges[13];    // the 13 edges to form the interior pyrimid
  pFace faces[24];    // the 24 faces to create the 8 interior regions
  pFace r_faces[4];   // the 4 faces to create the 1 regions
  pEdge f_edges[3];   // the 3 edges to create a face
  pRegion regions[8]; // the 8 regions created by this template
  int f_dirs[3];       // the orientation of the 3 edges of a face
  int r_dirs[4];       // the orientation of the 4 faces of a region
  pVertex verts[3];
  int n[3];
  pVertex vert0,vert5;// the two middle edge vertices
  pPList plist;

  // get the split faces and edge of parent face 0
  plist=get_split_faces_3(parent_faces[0]);   // 0,1,2 edges match 3,4,5 faces seperately
  faces[0]=(pFace)PList_item(plist,6);        // 6 the middle face
  verts[0]=parent_verts[0];
  verts[1]=parent_verts[2];
  verts[2]=parent_verts[1];
  templatesUtil::map_vertices(parent_faces[0],verts,n);
  faces[1]=(pFace)PList_item(plist,n[0]+3);
  faces[2]=(pFace)PList_item(plist,n[1]+3);
  faces[3]=(pFace)PList_item(plist,n[2]+3);
  edges[0]=(pEdge)PList_item(plist,n[0]);
  edges[1]=(pEdge)PList_item(plist,n[1]);
  edges[2]=(pEdge)PList_item(plist,n[2]);

  // get the split faces and edge of parent face 1
  plist=get_split_faces_3(parent_faces[1]);
  faces[4]=(pFace)PList_item(plist,6);
  verts[0]=parent_verts[0];
  verts[1]=parent_verts[1];
  verts[2]=parent_verts[3];
  templatesUtil::map_vertices(parent_faces[1],verts,n);
  faces[5]=(pFace)PList_item(plist,n[0]+3);
  faces[6]=(pFace)PList_item(plist,n[1]+3);
  faces[7]=(pFace)PList_item(plist,n[2]+3);
  edges[3]=(pEdge)PList_item(plist,n[0]);
  edges[4]=(pEdge)PList_item(plist,n[1]);
  edges[5]=(pEdge)PList_item(plist,n[2]);

  // get the split faces and edge of parent face 2
  plist=get_split_faces_3(parent_faces[2]);
  faces[8]=(pFace)PList_item(plist,6);
  verts[0]=parent_verts[1];
  verts[1]=parent_verts[2];
  verts[2]=parent_verts[3];
  templatesUtil::map_vertices(parent_faces[2],verts,n);
  faces[9] = (pFace)PList_item(plist,n[0]+3);
  faces[10]= (pFace)PList_item(plist,n[1]+3);
  faces[11]= (pFace)PList_item(plist,n[2]+3);
  edges[6]=(pEdge)PList_item(plist,n[0]);
  edges[7]=(pEdge)PList_item(plist,n[1]);
  edges[8]=(pEdge)PList_item(plist,n[2]);

  // get the split faces and edge of parent face 3
  plist=get_split_faces_3(parent_faces[3]);
  faces[12]=(pFace)PList_item(plist,6);
  verts[0]=parent_verts[0];
  verts[1]=parent_verts[3];
  verts[2]=parent_verts[2];
  templatesUtil::map_vertices(parent_faces[3],verts,n);
  faces[13]= (pFace)PList_item(plist,n[0]+3);
  faces[14]= (pFace)PList_item(plist,n[1]+3);
  faces[15]= (pFace)PList_item(plist,n[2]+3);
  edges[9]=(pEdge)PList_item(plist,n[0]);
  edges[10]=(pEdge)PList_item(plist,n[1]);
  edges[11]=(pEdge)PList_item(plist,n[2]);

  // get the mid-vertex of edge 0 & 5 . 
  plist=get_split_edges(parent_edges[0]);
  vert0=(pVertex)PList_item(plist,0);
  plist=get_split_edges(parent_edges[5]);
  vert5=(pVertex)PList_item(plist,0);

  // create edge 12,  0-->5
  edges[12]=M_createE(pmesh,vert0,vert5,g_entity);

  // create the 4 interior faces of the pyrimid
  // Define the face such that edges[12] is the 1st edge and it is used in positive direction
  f_edges[0]=edges[12];
  f_edges[1]=edges[8];
  f_edges[2]=edges[4];
  f_dirs[0]=1;
  f_dirs[1]=parent_face_dirs[2];
  if (parent_face_dirs[1]) f_dirs[2]=0;
  else f_dirs[2]=1;
  faces[16]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

  f_edges[1]=edges[11];
  f_edges[2]=edges[0];
  f_dirs[1]=parent_face_dirs[3];
  if (parent_face_dirs[0]) f_dirs[2]=0;
  else f_dirs[2]=1;
  faces[17]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

  f_edges[1]=edges[10];
  f_edges[2]=edges[3];
  if (parent_face_dirs[3]) f_dirs[1]=0;
  else f_dirs[1]=1;
  f_dirs[2]=parent_face_dirs[1];
  faces[18]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

  f_edges[1]=edges[7];
  f_edges[2]=edges[2];
  if (parent_face_dirs[2]) f_dirs[1]=0;
  else f_dirs[1]=1;
  f_dirs[2]=parent_face_dirs[0];
  faces[19]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

  // create the 4 corner faces with normal inside the pyrimid
  // 1. the face opposite to vertex 0
  f_edges[0]=edges[0];
  f_edges[1]=edges[9];
  f_edges[2]=edges[3];
  f_dirs[0]=parent_face_dirs[0];
  f_dirs[1]=parent_face_dirs[3];
  f_dirs[2]=parent_face_dirs[1];
  faces[20]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

  // 2.the face opposite to vertex 1
  f_edges[0]=edges[2];
  f_edges[1]=edges[4];
  f_edges[2]=edges[6];
  f_dirs[0]=parent_face_dirs[0];
  f_dirs[1]=parent_face_dirs[1];
  f_dirs[2]=parent_face_dirs[2];
  faces[21]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

  // 3.the face opposite to vertex 2
  f_edges[0]=edges[1];
  f_edges[1]=edges[7];
  f_edges[2]=edges[11];
  f_dirs[0]=parent_face_dirs[0];
  f_dirs[1]=parent_face_dirs[2];
  f_dirs[2]=parent_face_dirs[3];
  faces[22]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

  // 4.the face opposite to vertex 3
  f_edges[0]=edges[5];
  f_edges[1]=edges[10];
  f_edges[2]=edges[8];
  f_dirs[0]=parent_face_dirs[1];
  f_dirs[1]=parent_face_dirs[3];
  f_dirs[2]=parent_face_dirs[2];
  faces[23]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

  // create the 4 corner regions
  // the regions created are in correct face order
  r_faces[0]=faces[20];
  r_faces[1]=faces[5];      // e2 of r_faces[0]
  r_faces[2]=faces[13];     // e1 of r_faces[0]
  r_faces[3]=faces[1];      // e0 of r_faces[0]
  r_dirs[0]=1;
  r_dirs[1]=parent_face_dirs[1];
  r_dirs[2]=parent_face_dirs[3];
  r_dirs[3]=parent_face_dirs[0];
  regions[0]=M_createR(pmesh,4,r_faces,r_dirs,g_entity);

  r_faces[0]=faces[21];
  r_faces[1]=faces[9];
  r_faces[2]=faces[6];
  r_faces[3]=faces[3];
  r_dirs[0]=1;
  r_dirs[1]=parent_face_dirs[2];
  r_dirs[2]=parent_face_dirs[1];
  r_dirs[3]=parent_face_dirs[0];
  regions[1]=M_createR(pmesh,4,r_faces,r_dirs,g_entity);

  r_faces[0]=faces[22];
  r_faces[1]=faces[15];
  r_faces[2]=faces[10];
  r_faces[3]=faces[2];
  r_dirs[0]=1;
  r_dirs[1]=parent_face_dirs[3];
  r_dirs[2]=parent_face_dirs[2];
  r_dirs[3]=parent_face_dirs[0];
  regions[2]=M_createR(pmesh,4,r_faces,r_dirs,g_entity);

  r_faces[0]=faces[23];
  r_faces[1]=faces[11];
  r_faces[2]=faces[14];
  r_faces[3]=faces[7];
  r_dirs[0]=1;
  r_dirs[1]=parent_face_dirs[2];
  r_dirs[2]=parent_face_dirs[3];
  r_dirs[3]=parent_face_dirs[1];
  regions[3]=M_createR(pmesh,4,r_faces,r_dirs,g_entity);

  // create the 4 regions inside pyrimid
  r_faces[0]=faces[16];
  r_faces[1]=faces[4];
  r_faces[2]=faces[23];
  r_faces[3]=faces[18];
  r_dirs[0]=1;
  r_dirs[1]=parent_face_dirs[1];
  r_dirs[2]=0;
  r_dirs[3]=0;
  regions[4]=M_createR(pmesh,4,r_faces,r_dirs,g_entity);

  r_faces[0]=faces[16];
  r_faces[1]=faces[19];
  r_faces[2]=faces[8];
  r_faces[3]=faces[21];
  r_dirs[0]=0;
  r_dirs[1]=1;
  r_dirs[2]=parent_face_dirs[2];
  r_dirs[3]=0;
  regions[5]=M_createR(pmesh,4,r_faces,r_dirs,g_entity);

  r_faces[0]=faces[17];
  r_faces[1]=faces[0];
  r_faces[2]=faces[22];
  r_faces[3]=faces[19];
  r_dirs[0]=1;
  r_dirs[1]=parent_face_dirs[0];
  r_dirs[2]=0;
  r_dirs[3]=0;
  regions[6]=M_createR(pmesh,4,r_faces,r_dirs,g_entity);

  r_faces[0]=faces[17];
  r_faces[1]=faces[18];
  r_faces[2]=faces[12];
  r_faces[3]=faces[20];
  r_dirs[0]=0;
  r_dirs[1]=1;
  r_dirs[2]=parent_face_dirs[3];
  r_dirs[3]=0;
  regions[7]=M_createR(pmesh,4,r_faces,r_dirs,g_entity);

  // return the new regions
  int i;
  if( newRgns ) {
    for(i=0;i<8;i++)
      PList_append(newRgns,regions[i]);
  }
  if( newEdges ) {
    for(i=0;i<13;i++)
      PList_append(newEdges,edges[i]);
  }

  // set classification info
  if(ChildToParent) {
    void *tmpPtr;
    if(!EN_getDataPtr((pEntity)region,ChildToParent,&tmpPtr)) 
      tmpPtr=(void *)region;
    EN_attachDataPtr((pEntity)edges[12],ChildToParent,tmpPtr);
    for(i=16;i<24;++i)
      EN_attachDataPtr((pEntity)faces[i],ChildToParent,tmpPtr);
    for(i=0;i<8;++i)
      EN_attachDataPtr((pEntity)regions[i],ChildToParent,tmpPtr);
  } 
  
  return;
}


/*
  Given a polyhedron and a vertex inside, create regions
  Created by Xiangrong Li 05/18/99
*/
void meshTemplate::faces_vert_create_regions(pMesh mesh,pVertex vert,int size,pFace *faces,
					       int *dirs,pGEntity *g_entities, 
					       pPList newRgns,pPList newEdges)
{
  int i;
  pRegion region;

  for(i=0; i<size; i++) {
    region=face_vert_create_region(mesh,vert,faces[i],dirs[i],g_entities[i],newEdges);
    if( newRgns )
      PList_append(newRgns,region);
  }
  return;
}


pRegion meshTemplate::face_vert_create_region(pMesh mesh,pVertex vert,
			pFace face, int dir, pGEntity g_entity, pPList newEdges)
{
  pEdge edges[3];
  pFace faces[4];
  int   r_dirs[4];
  pRegion region;
  int i;

  for(i=0; i<3; i++)
     edges[i]= F_edge(face,i);

  // use the given face as face 0
  faces[0]=face;
  r_dirs[0]=dir;

  if(r_dirs[0]) {
    // create or get the face[1] connecting edge 2 and vert
    faces[1]=get_face_by_edge_vert(mesh,edges[2],vert,g_entity,newEdges);

    // we define faces[1] such that it always uses edges[2] positively
    if(F_dirUsingEdge(faces[0],edges[2]))
      r_dirs[1]=0;
    else
      r_dirs[1]=1;

    // create or get the face[2] connecting edge 1 and vert
    faces[2]=get_face_by_edge_vert(mesh,edges[1],vert,g_entity,newEdges);

    // we define faces[2] such that it always uses edges[1] positively
    if(F_dirUsingEdge(faces[0],edges[1]))
      r_dirs[2]=0;
    else
      r_dirs[2]=1;

    // create or get the face[3] connecting edge 0 and vert
    faces[3]=get_face_by_edge_vert(mesh,edges[0],vert,g_entity,newEdges);

    // we define faces[3] such that it always uses edges[0] positively
    if(F_dirUsingEdge(faces[0],edges[0]))
      r_dirs[3]=0;
    else
      r_dirs[3]=1;
  }
  else{

    // In determining the orientation, we use the fact that the new face
    // is created such that it uses the given edge positively
    faces[1]=get_face_by_edge_vert(mesh,edges[0],vert,g_entity,newEdges);
    faces[2]=get_face_by_edge_vert(mesh,edges[1],vert,g_entity,newEdges);
    faces[3]=get_face_by_edge_vert(mesh,edges[2],vert,g_entity,newEdges);

    r_dirs[1]=F_dirUsingEdge(faces[0],edges[0]);
    r_dirs[2]=F_dirUsingEdge(faces[0],edges[1]);
    r_dirs[3]=F_dirUsingEdge(faces[0],edges[2]);
  }

  // the region faces are in correct order
  region=M_createR(mesh,4,faces,r_dirs,g_entity);
  return region;
}


/*
   Find the face containing the given edge and vertex
   if no such face exist, create a new one
*/
pFace meshTemplate::get_face_by_edge_vert(pMesh mesh, pEdge edge,pVertex vert, 
					  pGEntity g_entity,pPList newEdges)
{
  pEdge edges[3];
  int f_dirs[3];
  pVertex verts[2];
  pFace face;
  int i;

  // get one edge connecting the given vert and edge
  verts[0]=E_vertex(edge,0);
  edges[2]=get_edge_by_verts(mesh,verts[0],vert,g_entity,newEdges);

  // find the face and return  if it exists
  for(i=0;i<E_numFaces(edge);i++){
    face=E_face(edge,i);
    if(F_edge(face,0)==edges[2] ||
       F_edge(face,1)==edges[2] ||
       F_edge(face,2)==edges[2])
      return face;
  }

  // get another edge
  verts[1]=E_vertex(edge,1);
  edges[1]=get_edge_by_verts(mesh,verts[1],vert,g_entity,newEdges);

  // the face does not exist, create it
  // the new face will use the given edge as first edge, positively
  edges[0]=edge;
  f_dirs[0]=1;

  if(E_vertex(edges[1],0)==vert)
    f_dirs[1]=0;
  else
    f_dirs[1]=1;

  if(E_vertex(edges[2],0)==vert)
    f_dirs[2]=1;
  else
    f_dirs[2]=0;

  return M_createF(mesh,3,edges,f_dirs,g_entity);
}

/*
   Find the edge containing the two given vertices
   if no such edge exist, create a new one
*/
pEdge meshTemplate::get_edge_by_verts(pMesh mesh, pVertex v0, pVertex v1,
				      pGEntity g_entity, pPList newEdges)
{
  int i;
  pEdge edge;

  // find the edge if it exists
  for(i=0;i<V_numEdges(v1);i++){
    edge=V_edge(v1,i);
    if(E_otherVertex(edge,v1)==v0)  return edge;
  }

  // edge does not exist, create it
  edge=M_createE(mesh,v0,v1,g_entity);
  if( newEdges )
    PList_append(newEdges,edge);
  return edge;
}
/*
// given 4 vertices, compute its center and interpolate its mesh size
pMSize meshTemplate::tetCenter(pVertex parent_verts[4], double xyz[3])
{
  double coords[3];
  pMSize pS;
  int i;
  pPList verts=PList_new();
  for(i=0; i<4; i++) {
    PList_append(verts,(pEntity)parent_verts[i]);
    V_coord(parent_verts[i],coords);
    xyz[0] += coords[0];
    xyz[1] += coords[1];
    xyz[2] += coords[2];
  }
  for(i=0; i<3; i++) xyz[i] /= 4.0;

  pS=pSizeField->getSize(xyz,verts);
  PList_delete(verts);
  return pS;
}

pMSize meshTemplate::wedgeCenter(pVertex parent_verts[6], double xyz[3])
{
  double coords[3];
  pMSize pS;
  int i;
  for(i=0; i<6; i++) {
    V_coord(parent_verts[i],coords);
    xyz[0] += coords[0];
    xyz[1] += coords[1];
    xyz[2] += coords[2];
  }
  for(i=0; i<3; i++) xyz[i] /= 6.0;

  // this seems bad, but may reasonable
  pPList verts=PList_new();
  PList_append(verts,(pEntity)parent_verts[0]);
  PList_append(verts,(pEntity)parent_verts[1]);
  pS=pSizeField->getSize(xyz,verts);
  PList_delete(verts);
  return pS;
}
*/
