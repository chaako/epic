/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Hugues de Cougny
  Creation  : Mar., 94
  Modifi.   : Pascal Frey, Feb., 95
  Function  :
    Checks if collapsing would cause some topological violation
    This is not needed for surface meshes since the equivalent of
    this check is already performed in OM_chkClps
    ifdef MPI, assume vert1 NOT on part. bdry

-------------------------------------------------------------------------*/
#include "FMDB.h"
#include "MeshTools.h"

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
 #include <stdlib.h>
#endif

#include <map>

using namespace std;

int E_chkColapsFcs(pVertex vert1, pVertex vert2, pEdge ledge)
{
  pPList faces_1,faces_2;
  map<pEdge,pFace> edges_faces;
  pRegion region0, region1;
  pFace  face_1,face_2;
  eType  gmtyp1,gmtyp2;
  pEdge  kedge_1,kedge_2,edge;
  void  *temp1,*temp2;
  int j, jj, flag;

  /* Get the faces connected to vert1 and vert2 */
  faces_1 = V_faces(vert1);
  faces_2 = V_faces(vert2);

  map<pEdge,pFace>::iterator iter_FE;

  typedef map<pEdge,pFace>::value_type entry;

  // pPList edges_1 = PList_new();

  temp1=0;
  while (face_1 = (pFace)PList_next(faces_1,&temp1)) {
    flag = 0;
    kedge_1 = 0;
    for ( j= 0 ; j< 2 ; j++ ) {
       edge =  F_edge(face_1,j);

       if ( edge == ledge ) {
          flag= 1;
          break;
       }

       if ( E_vertex(edge,0) != vert1 && E_vertex(edge,1) != vert1 ) {
	 kedge_1 = edge;
         for ( jj=j+1; jj< 3; jj++ ) {
            if ( ledge ==  F_edge(face_1,jj) ) {
              flag == 1;
              break;
            }
         }
	 break;
       }
    }
    if ( flag == 1 ) continue; 
    if ( kedge_1 == 0 ) kedge_1 = F_edge(face_1,2);
    // PList_append(edges_1,kedge_1);
    edges_faces.insert(entry(kedge_1,face_1));
  }

  temp2=0;
  while (face_2 = (pFace)PList_next(faces_2,&temp2)) {
    flag = 0;
    kedge_2 = 0;
    for ( j= 0 ; j< 2 ; j++ ) {
       edge =  F_edge(face_2,j);

       if ( edge == ledge ) {
          flag= 1;
          break;
       }

       if ( E_vertex(edge,0) != vert2 && E_vertex(edge,1) != vert2 ) {
	 kedge_2 = edge;
         for ( jj=j+1; jj< 3; jj++ ) {
            if ( ledge ==  F_edge(face_2,jj) ) {
              flag == 1;
              break;
            }
         }
	 break;
       }
    }
    if( flag == 1 ) continue;
    if ( kedge_2 == 0 ) kedge_2 = F_edge(face_2,2);

    iter_FE = edges_faces.find(kedge_2);
    if ( iter_FE != edges_faces.end() ) {
        face_1 = (*iter_FE).second;
        gmtyp1= (eType)F_whatInType(face_1);
        region0 = F_region(face_1,0);
        region1 = F_region(face_1,1);

        gmtyp2= (eType)F_whatInType(face_2);

	if (gmtyp1==Tface && gmtyp2==Tface) {
	  /* Both faces are classified on model face. Cannot collapse */
	  PList_delete(faces_1);
	  PList_delete(faces_2);
         // PList_delete(edges_1);
	  return(0);
	}
	else {
	  if ( ( region0 && !R_inClosure(region0,face_2) ) && 
	       ( region1 && !R_inClosure(region1,face_2) ) ) {
	    /* The 2 faces do not bound a mesh region connected to ledge.
	       Cannot collapse */
	    PList_delete(faces_1);
	    PList_delete(faces_2);
           // PList_delete(edges_1);
	    return(0);
	  }
	}
    }
  }

  PList_delete(faces_1);
  PList_delete(faces_2);
  // PList_delete(edges_1);

  return(1);
}

