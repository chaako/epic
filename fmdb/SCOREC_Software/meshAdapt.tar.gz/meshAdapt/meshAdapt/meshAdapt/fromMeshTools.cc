#include "fromMeshTools.h"
#include "paraAdapt.h"
#include "AdaptUtil.h"
#include "Eswap.h"
#include "Fswap.h"
#include "Macros.h"
#include "PList.h"
#include "mEntity.h"
#include "BLUtil.h"
#include <math.h>
#include <stdio.h>



#include <sys/types.h>
#include <sys/times.h>
#include <time.h>
#ifdef _HPUX_SOURCE
#include <sys/unistd.h>
#else
#include <unistd.h>
#endif

#ifdef MSC
#include <wtypes.h>		// needed for type WORD to be used by winbase.h
#include <winbase.h>	// so that we can get the real local time in milisec	
#include <time.h>		// to get user time in clock ticks
#endif

#ifdef AOMD_
#include "FMDB_cint.h"
#include "FMDB_Internals.h"
#ifdef MA_PARALLEL
#include "ParUtil.h"
#endif
#endif

#ifdef CURVE
#include "curveUtil.h"
#include "templateUtil.h"
using namespace curveUtil;
using namespace templatesUtil;
#endif //CURVE

myTimer::myTimer() 
: TimeLastResetCPU(0)
{
  reset();
}

void myTimer::reset() 
{
  TimeLastResetCPU = computeElapsedCPU();
  TimeLastResetWallClock = computeElapsedWallClock();
}

double myTimer::elapsedCPU() const
{
  return computeElapsedCPU() - TimeLastResetCPU;
}

long myTimer::elapsedWallClock() const
{
  return computeElapsedWallClock() - TimeLastResetWallClock;
}

double myTimer::computeElapsedCPU() const
{
  struct tms buf;
  long   clk_tck=sysconf(_SC_CLK_TCK);
 
  if (times(&buf)!=-1)
    /* Get system time and user time in micro-seconds. */
    return(((double)buf.tms_utime+(double)buf.tms_stime)/clk_tck);
  else
    return 0.;
}

long myTimer::computeElapsedWallClock() const
{
  struct tms buf;
  clock_t t;
  long   clk_tck=sysconf(_SC_CLK_TCK);
  
  t = times(&buf);
  if (t!=-1)
    return( ((double)t)/clk_tck);
  else
    return 0.;
}

ostream& operator<<(ostream& os, const myTimer& s)
{
  os << "\n\tCPU time: " << s.elapsedCPU() << " secs \t";
  os << " clock time: " << s.elapsedWallClock() << " secs\n";
  return os;
}


#ifndef AOMD_
// functions in meshTools but removed from MeshSim 5.0 

  int P_getMaxInt(int size)
{
  return size;
}
  
  pEdge F_vtOpEd(pFace face,pVertex vert)
  {
    pEdge   edge ;
    int     i ;
    
    if ( F_numEdges(face)!=3 )
      return(0) ;
    for ( i=0 ; i<3 ; i++ ) {
      edge = F_edge(face,i);
      if ( E_vertex(edge,0)!=vert && E_vertex(edge,1)!=vert )
	return(edge) ;
    }
    return((pEdge)0) ;
  }
 
  pVertex F_edOpVt(pFace face, pEdge edge)
  {
    int i , numEdges ;
    pEdge edge_1 ;
    pVertex vert ;
    
    numEdges = F_numEdges(face) ;
    for ( i = 0 ; i < numEdges ; i++ )
      {
	edge_1 = F_edge(face,i) ;
	if ( edge != edge_1 )
	  {
	    /* Found an edge other than the given edge */
	    vert = E_vertex(edge_1,0) ;
	    if ( vert != E_vertex(edge,0) &&
		 vert != E_vertex(edge,1) )
	      return vert ;
	    else
	      return E_vertex(edge_1,1) ;
	  }
      }
    return 0;
  }
  
  
#endif // end of ifndef AOMD_


//extern "C" F_SwapConfig fsc;
//extern "C" SwapConfig sc;
//extern "C" void (*swapFct[5])(SwapConfig *);

extern F_SwapConfig fsc;
extern SwapConfig sc;
extern void (*swapFct[5])(SwapConfig *);

namespace fromMeshTools {

#ifdef MA_PARALLEL

  void sendReclassifiedEntity(pMesh mesh, pEntity ent, int chDir)
  {
    if( ! EN_onCB(ent) )
      return;

    IPComMan *CM = ParUtil::Instance()->ComMan();
    
    int pid;
    std::vector<std::pair<pEntity,int> > remotePtrs;
    std::vector<std::pair<pEntity,int> >::iterator remoteIter;
    EN_getRemoteCopies(mesh,ent, remotePtrs);

    for( remoteIter=remotePtrs.begin(); 
	 remoteIter!=remotePtrs.end(); ++remoteIter ) {

      pid=remoteIter->second;
      classificationPack *msg_send=(classificationPack *)CM->alloc_msg(sizeof(classificationPack));

      msg_send->ent=remoteIter->first;
      msg_send->chDir=chDir;
      msg_send->par[0]=0.;
      msg_send->par[1]=0.;
      switch( EN_type(ent) ) {
      case Tedge: 
	msg_send->type=E_whatInType((pEdge)ent);
	msg_send->tag=GEN_tag(E_whatIn((pEdge)ent));
	break;
      case Tface:
	msg_send->type=F_whatInType((pFace)ent);
	msg_send->tag=GEN_tag(F_whatIn((pFace)ent));
	break;
      case Tvertex:
	msg_send->type=V_whatInType((pVertex)ent);
	msg_send->tag=GEN_tag(F_whatIn((pVertex)ent));
	if( msg_send->type == Gedge ) {
	  msg_send->par[0]=P_param1(V_point((pVertex)ent));
	} 
	else if (msg_send->type == Gface ) {
	  double par0,par1;
	  int patch;
	  P_param2(V_point((pVertex)ent),&par0, &par1, &patch);
	  msg_send->par[0]=par0;
	  msg_send->par[1]=par1;
	}
	break;
      default:
	adaptUtil::Info("oops, you are sending a mesh region !!!");
      }

      CM->send(pid, (void*)msg_send);
      CM->free_msg(msg_send);
//        adaptUtil::Info(castbuf->tag,"model entity tag sent out (sendReclassifiedEntity)");
//        adaptUtil::Info(castbuf->type,"model entity type sent out(sendReclassifiedEntity)");
    }
    return;
  }


  /*
    update inconsistent classification and orientation on partition boundary 
    local mesh modifications may introduce. Such mesh modification includes:
    edge collapsing, region collapsing and swapping a boundary edge.

    meshSnap has function for similar purpose (receiveSnapInfo), which also 
    consider vertex motions and update the vertex list to be snapped.

    created:  1/11/2004   -li
  */
  void syncClassification(pMesh pmesh)
  {
    int etype, gtype, gtag;
    pGEntity gent;
    pGModel model = M_model(pmesh);
    
    IPComMan *CM = ParUtil::Instance()->ComMan();
    void *msg_recv;
    int pid_from;
    while(int rc = CM->receive(msg_recv, &pid_from))
    {    
        classificationPack *castbuf=(classificationPack *)msg_recv;
	gtype=castbuf->type;
	gtag=castbuf->tag;
	gent=GM_entityByTag(model,gtype,gtag);
	
	switch( EN_type(castbuf->ent) ) {
	case Gedge: {
	  etype=E_whatInType((pEdge)castbuf->ent);
	  if( etype==gtype ) {
	    // if classifications are in the same level, the tags should be the same
	    if( GEN_tag(E_whatIn((pEdge)castbuf->ent)) != gtag )
	      adaptUtil::Error("Inconsistent edge classification on CB");
	  } else {
	    // in case of different level, set classification to be the lower level
	    E_setWhatIn((pEdge)castbuf->ent,gent);
	    adaptUtil::Info("synchronized an edge classification inconsistecncy on CB");
	  }
	  if( castbuf->chDir )
	    adaptUtil::Warning("we do not consider flip edge direction yet");
	  break;
	}
	
	case Gface: {
	  etype=F_whatInType((pFace)castbuf->ent);
	  if( etype==gtype ) {
	    if( GEN_tag(F_whatIn((pEdge)castbuf->ent)) != gtag )
	      adaptUtil::Error("Inconsistent face classification on CB");
	  } else {
	    F_setWhatIn((pFace)castbuf->ent,gent);
	    adaptUtil::Info("synchronized a face classification inconsistecncy on CB");
	  }
	  if( castbuf->chDir )
	    F_chDir((pFace)castbuf->ent);
	  break;
	}
	
	case Gvertex: {
	  etype=V_whatInType((pVertex)castbuf->ent);
	  if( etype==gtype ) {
	    // if classifications are in the same level, the tags should be the same
	    if( GEN_tag(F_whatIn((pVertex)castbuf->ent)) != gtag )
	      adaptUtil::Error("Inconsistent face classification on CB");
	  } else if (etype < gtype) {
	    adaptUtil::Warning("etype < gtype (syncClassification)");
	  } else {
	    // if different level, set classification to be the lower level
	    V_setWhatIn((pVertex)castbuf->ent,gent);
	    adaptUtil::Info("synchronized a face classification inconsistecncy on CB");
	    if( gtype==Gface || gtype==Gedge )
	      FMDB_P_setParametricPos (V_point((pVertex)castbuf->ent) , 
				       castbuf->par[0], castbuf->par[1], 0);
	  }   
	  break;
	}
	
	default:
	  adaptUtil::Error("received an unexpected mesh region");
	}
        CM->free_msg(msg_recv);	
    }
    
// #ifdef DEBUG
//     printf("(%d) autopack says %d messages, received %d\n",
// 	   M_Pid(),recvcount,receive);
// #endif
  }

#endif  // MA_PARALLEL


  std::vector<pVertex> *E_swpCfgVerts(pEdge edge, int c) {
    std::vector<pVertex> *verts=0;
    pVertex rvert[8];
    double  xyz[4][3];
    int     j,t,v,c2;
    
    /* check if swap configuration already available */
    if (sc.edge != edge)
      if (!fromMeshTools::E_numSwpCfg(edge))
	return 0;
    
    if (!c && !sc.nbr_triangles)
      /* This is the special case where only configuration is valid       */
      /* unless the resulting mesh will violate topological compatibility */
      /* (this is checked during the actual swap operation)               */
      /* Return empty list                                                */
      /* return PList_new(); */
      return new std::vector<pVertex >;
    
    if (c >= sc.nbr_trianguls)
      return 0;
    
    /* Have to find the c'th *topologically valid* configuration */
    for (c2 = 0, j = -1; c2 < sc.nbr_trianguls; c2++) {
      if (sc.topoValidCfg[c2]) j++;
      if (j == c) break;
    }
    
    verts = new std::vector<pVertex >; 
    /* verts = PList_new(); */
    /* evaluate the triangles of the c'th configuration */
    for ( j=0 ; j < sc.nbr_triangles_2 ; j++ ) {
      t = sc.trianguls[c2][j];
      
      /* top region */
      rvert[0] = sc.pverts[sc.triangles[t][0]] ;
      rvert[1] = sc.pverts[sc.triangles[t][1]] ;
      rvert[2] = sc.pverts[sc.triangles[t][2]] ;
      rvert[3] = sc.top_vert ;
      for ( v=0 ; v<4 ; v++ ) 
	verts->push_back(rvert[v]);

      /*      PList_append(verts,rvert[v]);  */
      
      /* bottom region */
      rvert[0] = sc.pverts[sc.triangles[t][0]] ;
      rvert[1] = sc.pverts[sc.triangles[t][2]] ;
      rvert[2] = sc.pverts[sc.triangles[t][1]] ;
      rvert[3] = sc.bot_vert ;
      for ( v=0 ; v< 4 ; v++ ) 
	verts->push_back(rvert[v]);

      /* PList_append(verts,rvert[v]);  */
    }
    return verts;
  }
  
  
  /* Intersect line with line (Both line segments on same plane) */
  void MT_intLineLine2(double L_XYZ[2][3], double l_xyz[2][3],
		       int *int_nbr, double int_xyz[3])
  {
    double LVEC[3];
    double lvec[3];
    double normal[3];
    int max_dim;
    double max_val;
    int dim;
    int ind;
    double A[2][2];
    double B[2];
    double den;
    double s;
    double t;
    double int_xyz2[3];
    
    /*
      1 intersection
      unless lines are strictly parallel
    */
    
    *int_nbr= 1;
    
    /*
      To find intersection,
      have to resolve a system of 3 eqns with 2 unknowns
      Do not consider axis closest to plane normal
    */
    
    diffVt(l_xyz[1],l_xyz[0],lvec);
    diffVt(L_XYZ[1],L_XYZ[0],LVEC);
    crossProd(lvec,LVEC,normal);
    
    max_dim= 0;
    max_val= fabs(normal[0]);
    for ( dim= 1 ; dim< 3 ; dim++ ) {
      if ( fabs(normal[dim]) > max_val ) {
	max_dim= dim;
	max_val= fabs(normal[dim]);
      }
    }
    
    ind= 0;
    for ( dim= 0 ; dim< 3 ; dim++ ) {
      if ( dim == max_dim ) continue;
      A[ind][0]= LVEC[dim];
      A[ind][1]= -lvec[dim];
      B[ind]= l_xyz[0][dim] - L_XYZ[0][dim];
      ind++;
    }
    
    den= A[0][0]*A[1][1]-A[0][1]*A[1][0];
    
    if ( den == 0.0 ) {
      *int_nbr= 0;
      return;
    }
    
    s= (B[0]*A[1][1]-A[0][1]*B[1])/den;
    t= (A[0][0]*B[1]-B[0]*A[1][0])/den;
    
    /*
      Get intersection location
      s is parametric rep. on L
      t is parametric rep. on l
      Both should give same answer
      Only consider L
    */
    
    for ( dim= 0 ; dim< 3 ; dim++ ) {
      int_xyz[dim]= L_XYZ[0][dim]+s*LVEC[dim];
    }
    
    for ( dim= 0 ; dim< 3 ; dim++ ) {
    int_xyz2[dim]= l_xyz[0][dim]+t*lvec[dim];
    }
    
  }
  
  
  /* given a triangle, calculate the cosines of internal angles 
     Note that the cosine may be negative */
  void XYZ_FAngles(dArray *xyz, double *cosangs) {
    double v01[3],v02[3],v12[3], nv01[3], nv02[3], nv12[3];

    /* calculate the vectors */
    diffVt(xyz[1],xyz[0],v01);
    diffVt(xyz[2],xyz[0],v02);
    diffVt(xyz[2],xyz[1],v12);
    
    /* normalize these vectors */
    normVt (v01,nv01);
    normVt (v02,nv02);
    normVt (v12,nv12);
    
    /* calculate the cosine angles of the triangle */
    cosangs[0] = dotProd(nv01,nv02);
    cosangs[1] = -dotProd(nv01,nv12);
    cosangs[2] = dotProd(nv02,nv12);
    
    return;
  }
  
  
  /* this routine have specific considerations used by snapping procedure */
  int E_evalSwpOnGFace(pEdge swpedge, pGEntity GFace, pPList &TPM00, 
		       double *newsml, double *maxAngtoNormal) 
  {
    pFace f[2], tmpf;
    pVertex fv[6];
    int i,j;
    double big, sml[2], angToNormal[2], xyz[3][3], cosangs[3];
    

    /* If edge classified on model edge, no can do! */
    if (E_whatIn(swpedge) != GFace)
      return 0; 
    
    /* If it is not a 2-manifold situation, cannot swap either */
    if (E_numFaces(swpedge) != 2)
      return 0;
    
    /* Get faces connected to edge such that prediction of */
    /* vertices of the new faces will be easy              */
    for (i = 0; i < 2; i++)
      f[i] = E_face(swpedge,i);
    if (!F_dirUsingEdge(f[0],swpedge)) {
      tmpf = f[0];
      f[0] = f[1];
      f[1] = tmpf;
    }
    
    /* Vertices of new faces in correct order */
    for (i = 0; i < 2; i++)
      fv[i] = fv[!i+3] = F_edOpVt(f[i],swpedge);
    fv[2] = E_vertex(swpedge,1); fv[5] = E_vertex(swpedge,0);
    
    for (i = 0; i < 2; i++) {
      for (j = 0; j < 3; j++)
	V_coord(fv[3*i+j],xyz[j]);
      XYZ_FAngles(xyz,cosangs);
      big = MIN(cosangs[0],MIN(cosangs[1],cosangs[2]));
      sml[i]=MAX(cosangs[0],MAX(cosangs[1],cosangs[2]));
      if (C_equal(fabs(big),1.0))
	return 0;
      angToNormal[i]=adaptUtil::F_angleToGNormal(fv[3*i],fv[3*i+1],fv[3*i+2],(pGFace)GFace);
      if( angToNormal[i] < M_getTolerance() )
	return 0;
    }
    *maxAngtoNormal=MIN(angToNormal[0],angToNormal[1]);
    *newsml=MAX(sml[0],sml[1]);
    
    /* We also have to check if the swap will create two coincident faces.
       Can happen in some situations when an face already exists between
       the vertices of a to-be-created face - e.g. at a model vertex
       where two model faces share two model edges
    */
    
    tmpf=F_exists(Tvertex,(pEntity)fv[0],(pEntity)fv[1],(pEntity)fv[2],0);
    if( tmpf && PList_inList(TPM00,(pEntity)tmpf) )
      return 0;
    
    tmpf=F_exists(Tvertex,(pEntity)fv[3],(pEntity)fv[4],(pEntity)fv[5],0);
    if( tmpf && PList_inList(TPM00,(pEntity)tmpf) )
      return 0;
    
    return adaptUtil::E_swpCheckPer(swpedge);
  }
  
  
  /* this implementation is different from the one in meshTools */
  //// Note by QLU:
  // at this point, it seems that it does not distinguish between straight-sided and curved edges
  // curving will take place after the collapse in the caller routine templateUtil::Edge_colaps
  // have not dig in yet
  //// Aug 14, 2010
  int E_colaps(pMesh mesh, 
	       pEdge cedge, 
	       pVertex vertd, 
	       pVertex vertr, 
	       CBFunction CB, 
	       void *userData,
	       pPList eregs, // delRegs 
#ifdef MATCHING
               pPList *newEds,
               pPList *newFcs,
#endif
	       pPList *newReg)   // this routine allocate space
  {  
    pRegion region;
    pFace face, bdryFace, f[2];
    pEdge edge, e[2];
    pVertex vt, vertices[2];
    pGEntity gent;
    pPList tmpList, efaces;
    pFace faces[4];
    pEdge edges[3];
    int f_dirs[4], e_dirs[3] ;
    void *temp1=0, *temp2=0;
    int i,j,k,dir;
    int local = 0;

    if (!eregs) {
      eregs = E_regions(cedge);
      local = 1;
    }
    *newReg=PList_new();

#ifdef MATCHING
    *newEds = PList_new();
    *newFcs = PList_new();
#endif

    if( PList_size(eregs)==0 ) {
      efaces=E_faces(cedge);
#ifndef MATCHING
      E_colapsOnGFace(mesh,cedge,vertd,vertr,CB,userData,efaces,newReg);
#else
      E_colapsOnGFace(mesh,cedge,vertd,vertr,CB,userData,efaces,newEds,newFcs);
#endif
      PList_delete(efaces);
      return 1;
    }

    pMeshDataId entPtr=MD_newMeshDataId("entPtr");
    pMeshDataId dirInt=MD_newMeshDataId("dirInt");

    // figure out faces to be merged
    temp1 = 0;
    while (region = (pRegion)PList_next(eregs,&temp1)) {
      tmpList = R_faces(region,1);
      temp2 = 0;
      while (face = (pFace)PList_next(tmpList, &temp2)) {
	if (!F_inClosure(face,(pEntity)cedge))
	  if (F_inClosure(face,(pEntity)vertd))
	    f[0] = face;  /* face that will be deleted */
	  else
	    f[1] = face;  /* face that will replace deleted face */
      }
      PList_delete(tmpList);
      EN_attachDataPtr((pEntity)f[0],entPtr,f[1]);

      edge=F_vtOpEd(f[0],vertd);
      if( F_whatInType(f[0]) < F_whatInType(f[1]) )
	// should use the normal and classification of f[0]
      {
	  int chDir=0;
	  F_setWhatIn(f[1],F_whatIn(f[0]));
	  if( F_dirUsingEdge(f[1],edge)!=F_dirUsingEdge(f[0],edge) ) {
	    F_chDir(f[1]);
	    chDir=1;
	  }
#ifdef MA_PARALLEL
	  sendReclassifiedEntity(mesh,(pEntity)f[1],chDir);
#endif	    
      }
      else
	// use the normal and classification of f[1]
      {
        if( F_dirUsingEdge(f[1],edge)==F_dirUsingEdge(f[0],edge) ) 
          EN_attachDataInt((pEntity)f[0],dirInt,1);
        else
          EN_attachDataInt((pEntity)f[0],dirInt,-1);
      }
    }

    // figure out edges to be merged
    efaces = E_faces(cedge);
    temp1 = 0;
    while (face = (pFace)PList_next(efaces, &temp1)) {
      tmpList = F_edges(face,1,0);
      temp2 = 0;
      while (edge = (pEdge)PList_next(tmpList,&temp2)) {
	if (edge != cedge)
	  if (E_inClosure(edge,(pEntity)vertd))
	    e[0] = edge;  /* edge that will be deleted */
	  else
	    e[1] = edge;  /* edge that will replace deleted edge */
      }
      PList_delete(tmpList);
      EN_attachDataPtr((pEntity)e[0],entPtr,e[1]);
      
      if( E_whatInType(e[0]) < E_whatInType(e[1]) ) {
	E_setWhatIn(e[1],E_whatIn(e[0]));
#ifdef MA_PARALLEL
	sendReclassifiedEntity(mesh,(pEntity)e[1],0);
#endif		 
      }
   
      if( E_vertex(e[0],0)==E_vertex(e[1],0) ||
	  E_vertex(e[0],1)==E_vertex(e[1],1) )
	EN_attachDataInt((pEntity)e[0],dirInt,1);
      else
	EN_attachDataInt((pEntity)e[0],dirInt,-1);
    }
    PList_delete(efaces);

    // now, create the new mesh of the cavity
    pPList oldCavity=V_regions(vertd);
    temp1 = 0;
    while (region = (pRegion)PList_next(oldCavity,&temp1)) 
      {
	if( PList_inList(eregs,(pEntity)region) )
	  continue;
	bdryFace=R_vtOpFc(region,vertd);

	// loop over the faces
	for( i=0;i<R_numFaces(region);i++ ) {
	  face=R_face(region,i);
	  f_dirs[i]=R_dirUsingFace(region,face);
	  if( face==bdryFace ) {
	    faces[i]=face;
	    continue;
	  }
	  if( EN_getDataInt((pEntity)face,dirInt,&dir) && dir==-1 )
	    f_dirs[i] = !f_dirs[i]; 
	  if( EN_getDataPtr((pEntity)face,entPtr,&temp2) ) 
	    faces[i]=(pFace)temp2;
	  else {
      
	    // loop over the edges
	    for( j=0;j<F_numEdges(face);j++ ) {
	      edge=F_edge(face,j);
	      e_dirs[j]=F_dirUsingEdge(face,edge);
	      if( F_inClosure(bdryFace,(pEntity)edge) ) {
		edges[j]=edge;
		continue;
	      }
	      if( EN_getDataInt((pEntity)edge,dirInt,&dir) && dir==-1 )
		e_dirs[j] = !e_dirs[j]; 
	      if( EN_getDataPtr((pEntity)edge,entPtr,&temp2) ) 
		edges[j]=(pEdge)temp2;
	      else {
          
		// loop over the two vertices
		for( k=0;k<2;k++ ) {
		  vt=E_vertex(edge,k);
		  if( vt==vertd )
		    vertices[k]=vertr;
		  else
		    vertices[k]=vt;
		}
          
		// create edge inside the cavity 
		gent=E_whatIn(edge);
		edges[j]=M_createE(mesh,vertices[0], vertices[1], gent);
#ifdef MATCHING
                if(PBC_isPbcOnGEntity(gent))
                  PList_appUnique(*newEds, edges[j]);
#endif
		EN_attachDataPtr((pEntity)edge,entPtr,edges[j]);
	      }
	    }
      
	    // create face inside the cavity
	    gent=F_whatIn(face);
	    faces[i]=M_createF(mesh, 3, edges, e_dirs, gent);
#ifdef MATCHING
                if(PBC_isPbcOnGEntity(gent))
                  PList_appUnique(*newFcs, faces[i]);
#endif
	    EN_attachDataPtr((pEntity)face,entPtr,faces[i]);
	  }
	}

	// create new regions
	gent=(pGEntity)R_whatIn(region);
	PList_append(*newReg, M_createR(mesh, 4, faces, f_dirs, gent) );
      }

    if (local)
      PList_delete(eregs);

    // activate the callback
    if( CB ) 
      (CB)(oldCavity,*newReg,userData,ECOLAPS,(pEntity)vertd);

    /* Now actually delete the entities connected to vertd */
    temp1 = 0;
    while (region = (pRegion)PList_next(oldCavity,&temp1))
      M_removeRegion(mesh, region);
    PList_delete(oldCavity);

    pPList vfaces=V_faces(vertd);
    temp1 = 0;
    while (face = (pFace)PList_next(vfaces,&temp1))
      M_removeFace(mesh, face);
    PList_delete(vfaces);

    pPList vedges=PList_new();
    for( i=0; i<V_numEdges(vertd); i++ ) {
      edge=V_edge(vertd,i);
      PList_append(vedges,(pEntity)edge);
    }
    temp1 = 0;
    while( edge=(pEdge)PList_next(vedges,&temp1) )
      M_removeEdge(mesh, edge);
    PList_delete(vedges);

    M_removeVertex(mesh,vertd);

    MD_deleteMeshDataId(entPtr);
    MD_deleteMeshDataId(dirInt);

    return 1 ;
  }


  int E_colapsOnGFace(pMesh mesh, 
		      pEdge cedge, 
		      pVertex vertd, 
		      pVertex vertr,
		      CBFunction CB, 
		      void *userData,
		      pPList efaces,   //faces connected to the edge to be deleted
#ifdef MATCHING
                      pPList *newEds,
#endif
		      pPList *newFaces)//new faces to fill the 2D cavity 
  {
    pFace face;
    pEdge e[2], edge, bdryEdge,edges[3] ;
    pVertex vt, vertices[2];
    pPList fedges;
    pGEntity gent;
    int e_dirs[3];
    int j,k,dir;
    void *temp1=0, *temp2=0;

    pMeshDataId entPtr=MD_newMeshDataId("entPtr");
    pMeshDataId dirInt=MD_newMeshDataId("dirInt");

    /* First figure out what adjacencies must be replaced */
    
    /* Find edge-connected regions to polygonal cavity whose faces must */
    /* be updated to use new edges                                      */
    
    temp1 = 0;
    while (face = (pFace)PList_next(efaces, &temp1)) {
      fedges = F_edges(face,0,0);
      temp2 = 0;
      while (edge = (pEdge)PList_next(fedges,&temp2)) {
	if (edge != cedge)
	  if (E_inClosure(edge,(pEntity)vertd))
	    e[0] = edge;    // the edge to be replaced
	  else
	    e[1] = edge;
      }
      PList_delete(fedges);
      EN_attachDataPtr((pEntity)e[0],entPtr,e[1]);

      if( E_vertex(e[0],0)==E_vertex(e[1],0) ||
	  E_vertex(e[0],1)==E_vertex(e[1],1) )
	EN_attachDataInt((pEntity)e[0],dirInt,1);
      else
	EN_attachDataInt((pEntity)e[0],dirInt,-1);
    }

    // now, create the new mesh of the cavity
    pPList oldCavity=V_faces(vertd);
    temp1 = 0;
    while (face = (pFace)PList_next(oldCavity,&temp1)) 
      {
	if( PList_inList(efaces,(pEntity)face) )
	  continue;
	bdryEdge=F_vtOpEd(face,vertd);

	// loop over the three edges
	for( j=0;j<3;j++ ) {
	  edge=F_edge(face,j);
	  e_dirs[j]=F_dirUsingEdge(face,edge);
	  if( edge==bdryEdge ) {
	    edges[j]=edge;
	    continue;
	  }
	  if( EN_getDataInt((pEntity)edge,dirInt,&dir) && dir==-1 )
	    e_dirs[j] = !e_dirs[j]; 
	  if( EN_getDataPtr((pEntity)edge,entPtr,&temp2) ) 
	    edges[j]=(pEdge)temp2;
	  else {
          
	    // loop over the two vertices
	    for( k=0;k<2;k++ ) {
	      vt=E_vertex(edge,k);
	      if( vt==vertd )
		vertices[k]=vertr;
	      else
		vertices[k]=vt;
	    }
          
	    // create edge inside the cavity 
	    gent=E_whatIn(edge);
	    edges[j]=M_createE(mesh,vertices[0], vertices[1], gent);
#ifdef MATCHING
            if(PBC_isPbcOnGEntity(gent))
              PList_appUnique(*newEds, edges[j]);
#endif
	    EN_attachDataPtr((pEntity)edge,entPtr,edges[j]);
	  }
	}
      
	// create face inside the cavity
	gent=F_whatIn(face);
	PList_append(*newFaces,M_createF(mesh, 3, edges, e_dirs, gent));
      }

    // activate the callback
    if( CB ) 
      (CB)(oldCavity,*newFaces,userData,ECOLAPS,(pEntity)vertd);

    /* Now actually delete the entities connected to vertd */
    temp1 = 0;
    while (face = (pFace)PList_next(oldCavity,&temp1))
      M_removeFace(mesh, face);
    PList_delete(oldCavity);

    pPList vedges=PList_new();
    for( j=0; j<V_numEdges(vertd); j++ ) {
      edge=V_edge(vertd,j);
      PList_append(vedges,(pEntity)edge);
    }
    temp1 = 0;
    while( edge=(pEdge)PList_next(vedges,&temp1) )
      M_removeEdge(mesh, edge);
    PList_delete(vedges);

    M_removeVertex(mesh,vertd);

    MD_deleteMeshDataId(entPtr);
    MD_deleteMeshDataId(dirInt);
    return 1 ;
  }



  int E_swap(pMesh mesh,
	     pEdge edge,
	     int c, 
	     CBFunction CB, 
	     void *userData, 
	     pPList *newRegions)  // this routine allocate space
  {
    pVertex e_verts[2], tvert[MAX_TRIANGLES][3], oppV[2], vert_2;
    pGEntity egent;
    pGRegion gregions[2], greg;
    pRegion frgn;
    pEdge   edge_2, quadEdge[2];
    pFace face, eface[2], nuface[2];
    pVertex tgt_vert=0;
    int     i,j,Dir,t, c2, tri_nbr,flag, fGFaceDir=-1;
    int     found, qeDir[2], nonManif=0;
    void   *temp, *temp1, *temp3, *temp4 ;
    pPList  faces,edges,eregs,dsc_verts;
    
    /* Get the default classification */
    egent = E_whatIn(edge);
    eregs = E_regions(edge);
    if( PList_size(eregs)==0 ) {    
      E_swapOnGFace(mesh, edge, egent, CB, userData, newRegions);
      PList_delete(eregs);
      return 1;
    }
    greg = R_whatIn((pRegion)PList_item(eregs,0));
    
    /* check if swap configuration already available */
    if (sc.edge != edge)
      if (!fromMeshTools::E_numSwpCfg(edge)) {
	*newRegions = PList_new();
        PList_delete(eregs);
	return 0;
      }

    sc.edge = 0;
    
    /*  Get 2 end vertices */
    for ( i=0 ; i<2 ; i++ ) 
      e_verts[i]= E_vertex(edge,i);
    
    /* Check if edge is being swapped on a non-manifold face */
    if (GEN_type(egent) == Gface) {
      if (GF_region((pGFace)egent,0) && GF_region((pGFace)egent,1)) {
	
	/* On the non-manifold model face itself, the change in the */
	/* triangulation will be a diagonal swap of the quad formed */
	/* by the two mesh faces of the mesh edge classified on the */
	/* the model face. Collect this info in a specific manner   */
	/* (according to a template) so that later on it will be    */
	/* possible to figure out the orientation of 2 new faces    */
	/* classified on the model face                             */
	
	for (j = 0, i = 0; (j < E_numFaces(edge)) && (i < 2); j++) {
	  face = E_face(edge,j);
	  if (F_whatInType(face) == Gface) {
	    eface[i] = face;
	    oppV[i] = F_edOpVt(face,edge);
	    i++;
	  }
	}
	
	if( (F_region(eface[0],0) && F_region(eface[0],1)) && 
	    (F_region(eface[1],0) && F_region(eface[1],1)) )
	  {
	    
	    nonManif = 1;

	    /* Should we use the modeler interface call C_F_region here? */
	    gregions[0] = GF_region((pGFace)egent,0); 
	    gregions[1] = GF_region((pGFace)egent,1);
	    
	    if (F_dirUsingEdge(eface[0], edge)) {
	      temp = eface[0]; eface[0] = eface[1]; eface[1] = (pFace)temp;
	      temp = oppV[0]; oppV[0] = oppV[1]; oppV[1] = (pVertex)temp;
	    }
	
	    /* Get a pair of opposite edges of the 'quad' and the way they */
	    /* use the connected mesh face classified on the model face    */
	    /* In the swapped cfg, these 2 edges will still belong to 2    */
	    /* different mesh faces classified on the model face and these */
	    /* faces will continue to use the edges in the same sense      */
	    
	    quadEdge[0] = F_vtOpEd(eface[0], e_verts[1]);
	    qeDir[0] = F_dirUsingEdge(eface[0], quadEdge[0]);
	    quadEdge[1] = F_vtOpEd(eface[1], e_verts[0]);
	    qeDir[1] = F_dirUsingEdge(eface[1], quadEdge[1]);
	    
	    /* Also determine orientation of mesh faces w.r.t. model face */
	    
	    if (gregions[0] != gregions[1]) {
	      if (frgn = F_region(eface[0],0))
		fGFaceDir = ((pGRegion)R_whatIn(frgn) == gregions[0]);
	      else if (frgn = F_region(eface[0],1))
		fGFaceDir = ((pGRegion)R_whatIn(frgn) == gregions[1]);
	      else
		fGFaceDir = 1;
	    }
	    else {
	      /* Have to determine it differently. How?*/
	      fGFaceDir = 1;
	    }
	  }
      }
    }

    *newRegions = PList_new();
    if (!c && !sc.nbr_triangles)
      /* This is the special case where only configuration is valid       */
      /* unless the resulting mesh will violate topological compatibility */
      /* (this is checked during the actual swap operation)               */
      {
#ifdef DEBUG
	printf("Info: delete a boundary region (E_swap)\n");
#endif
        PList_delete(eregs);
	return E_swap2Fac(mesh, edge);
      }
    
    if (c >= sc.nbr_trianguls) {
      PList_delete(eregs);
      return 0;
    }
    
    /* Have to find the c'th *topologically valid* configuration */
    for (c2 = 0, j = -1; c2 < sc.nbr_trianguls; c2++) {
      if (sc.topoValidCfg[c2]) j++;
      if (j == c) break;
    }
    
    /* evaluate the triangles of the c'th configuration */
    for ( j=0 ; j < sc.nbr_triangles_2 ; j++ ) {
      t = sc.trianguls[c2][j];
      tvert[j][0] = sc.pverts[sc.triangles[t][0]] ;
      tvert[j][1] = sc.pverts[sc.triangles[t][1]] ;
      tvert[j][2] = sc.pverts[sc.triangles[t][2]] ;   
    }
    
    if (nonManif) {
      /* Classify the edge being swapped and the connected faces on the */
      /* model face as being classified in the interior                 */
      
      E_setWhatIn(edge,(pGEntity)greg);
      F_setWhatIn(eface[0],(pGEntity)greg);
      F_setWhatIn(eface[1],(pGEntity)greg);
    }
    
    /* Get direction and classification information of faces and edges on 
       the boundary of the cavity associated with 'edge' 
       ('Dir'and information wrt edges is needed when it is classified on Gface)
    */
    E_getCavityBdry(edge,eregs,&faces,&edges,&Dir);

    /* Process 'edges' have to find proper target vertex */
    /* Recreate boundary faces that are deleted? - rvg 4/19/95 */
    flag= 0;
    temp = 0 ;
    while ( edge_2 = (pEdge)PList_next(edges,&temp) ) {
      /* Choose a vertex which does not belong to
	 the two vertices of the deleted edge, these
	 are the faces that were deleted as one of the
	 edges were connected to the edge being swapped */
      for ( j= 0 ; j< 2 ; j++ ) {
	tgt_vert= E_vertex(edge_2,j);
	if ( tgt_vert != e_verts[0]
	     && tgt_vert != e_verts[1] ) {
	  flag= 1;
	  break;
	}
      }
      if ( flag == 1 ) break;
    }
    E_vrtCrtFaces(mesh,edges,tgt_vert);
    
    /* Create new regions */
    tri_nbr = sc.nbr_triangles_2;
    PList_delete(*newRegions); /* This is silly but a whole bunch of routines */
    /* don't check if *newRegions is 0 and until   */
    /* they change, it'll have to stay this way    */
    *newRegions = E_swpCrtRegs(mesh,tri_nbr,tvert,e_verts,(pGEntity)greg,faces,Dir) ;
    PList_delete(edges);
    PList_delete(faces);
    
    // call callback
    if( CB ) 
      (CB)(eregs,*newRegions,userData,ESWAP,(pEntity)edge);
    
    temp = 0 ;
    while ( frgn = (pRegion)PList_next(eregs,&temp) ) 
    	M_removeRegion(mesh,frgn);
    
    faces=E_faces(edge);
    temp1 = 0 ;
    while ( face = (pFace)PList_next(faces, &temp1) ) 
        M_removeFace(mesh,face);
	  
    M_removeEdge(mesh,edge);
      
    PList_delete(faces) ;
    PList_delete(eregs);
    
    if (!nonManif) 
      return (1);
    
    /* Swapped on non-manifold model face after faking an interior swap  */
    /* Now we have to correct the classifications and possibly face dirs */
    
    /* new edge that has been created */
    edge = E_exists(oppV[0],oppV[1]);
    if (!edge)
      printf("FATAL:Illegal swap cfg. for non-manifold model (E_swap)\n");
    E_setWhatIn(edge,egent);

    for (j = 0; j < 2; j++) {
      found = 0; i = 0; nuface[j] = 0;
      while (!found && (i < E_numFaces(edge))) {
	face = E_face(edge,i);
	if (F_edOpVt(face,edge) == e_verts[j]) {
	  nuface[j] = face;
	  found = 1;
	}
	i++;
      }
      if (!found) 
	printf("FATAL:Illegal swap cfg. for non-manifold model (E_swap)\n");
    }
    
    for (j = 0; j < 2; j++) {
      /* Reclassify mesh face on model face */
      F_setWhatIn(nuface[j],egent);
      
      /* Check the orientation of the face; nuface[0] should use edge between */
      /* e_verts[0] and oppV[0] (quadEdge[0]) in the same sense as eface[0]   */
      /* (qeDir[0]); Similarly, nuface[1] is made up of oppV[0], e_verts[1]   */
      /* and oppV[1]; It should use edge between e_verts[1] and oppV[1]       */
      /* (quadEdge[1]) in the same sense as eface[1] (qeDir[1])               */
      
      if (F_dirUsingEdge(nuface[j], quadEdge[j]) != qeDir[j])
	F_chDir(nuface[j]);    
    }
    
    /* Now that we have the correct orientations for the face, it is easy to  */
    /* assign the right classificationss to the other newly created entities  */
    
    E_swapReclassifyNM(*newRegions, egent, fGFaceDir);
    
    return 1;
  }

  int E_swap2Fac(pMesh mesh, pEdge edge) {
    pRegion  rgn, tmp_rgn;
    pGEntity rement ;
    pFace    e_faces[2],r_faces[4],reg_faces[4],e_face ;
    pEdge    op_edge,tmp_edge ;
    pVertex  e_verts[4],op_verts[2],item ;
    pPList   vlist ;
    int      i,l,dir,idir,dirs[4],numFaces ;
    int      etype;
    void *temp = 0 ;
    int chDir2=0, chDir3=0;
    
    /*------ 2. get 2 end vertices of edge */
    e_verts[0] = E_vertex(edge,0);
    e_verts[1] = E_vertex(edge,1);
    
    /* get the vertices of the region */
    pPList templist = E_regions(edge);
    rgn = (pRegion)PList_item(templist,0);
    PList_delete(templist);

    vlist = R_vertices(rgn,1) ;
    l = 0 ;
    temp = 0 ;
    while ( item = (pVertex)PList_next(vlist,&temp)) {
      if ( item == e_verts[0] || item == e_verts[1] )
	continue ;
      op_verts[l++] = item ;
    }
    PList_delete(vlist) ;
    
    /* get the opposite edge yo e_verts */
    op_edge = E_exists(op_verts[0], op_verts[1]) ;
    
    /* check if the opposite edge is classified on the boundary */
    etype = E_whatInType(op_edge);
    if (etype!=Gregion)
      return(0);
    /* find the edge classification */
    rement = E_whatIn(edge) ;
    
    /* find the four faces of the region */
    numFaces = R_numFaces(rgn) ;
    for ( i = 0 ; i < numFaces ; i++ ) {
      r_faces[i] = R_face(rgn,i) ;
      dirs[i] = R_faceDir(rgn,i) ;
    }
    e_faces[0] = E_face(edge,0) ;
    e_faces[1] = E_face(edge,1) ;
    
    /* Find faces of region with respect to a local mapping of element faces
       faces[0] is face connected to edge and uses edge in same orientation
       faces[1] is face connected to edge and uses edge in oppos orientation
       faces[2] is face connected to op_edge and first vertex of edge
       faces[3] is face connected to op_edge and second vertex of edge */
    reg_faces[0] = e_faces[0] ;
    reg_faces[1] = e_faces[1] ;
    l = 2 ;
    for ( i=0 ; i<4 ; i++ ) {
      if ( r_faces[i] == reg_faces[0] || r_faces[i] == reg_faces[1] )
	continue ;
      reg_faces[l++] = r_faces[i] ;
    }
    dir = F_dirUsingEdge(reg_faces[0],edge) ;
    if ( !dir ) {
      /* Edge is used in the opposite orientation, swap the faces */
      reg_faces[0] = e_faces[1] ;
      reg_faces[1] = e_faces[0] ;
    }
    tmp_edge = F_edge(reg_faces[0],0) ;
    if ( tmp_edge == edge )
      tmp_edge = F_edge(reg_faces[0],1) ;
    op_verts[0] = E_vertex(tmp_edge,0) ;
    op_verts[1] = E_vertex(tmp_edge,1) ;
    if ( op_verts[0] == e_verts[0] || op_verts[0] == e_verts[1] )
      e_verts[2] = op_verts[1] ;
    else
      e_verts[2] = op_verts[0] ;
    tmp_edge = F_edge(reg_faces[1],0) ;
    
    if ( tmp_edge == edge )
      tmp_edge = F_edge(reg_faces[1],1) ;
    op_verts[0] = E_vertex(tmp_edge,0) ;
    op_verts[1] = E_vertex(tmp_edge,1) ;
    if ( op_verts[0] == e_verts[0] || op_verts[0] == e_verts[1] )
      e_verts[3] = op_verts[1] ;
    else
      e_verts[3] = op_verts[0] ;
    
    tmp_edge = F_edge(reg_faces[2],0) ;
    if ( tmp_edge == op_edge )
      tmp_edge = F_edge(reg_faces[2],1) ;
    op_verts[0] = E_vertex(tmp_edge,0) ;
    op_verts[1] = E_vertex(tmp_edge,1) ;
    if ( op_verts[0] == e_verts[1] || op_verts[1] == e_verts[1] ) {
      e_face = reg_faces[2] ;
      reg_faces[2] = reg_faces[3] ;
      reg_faces[3] = e_face ;
    }
    op_verts[0] = E_vertex(op_edge,0) ;
    op_verts[1] = E_vertex(op_edge,1) ;
    if ( op_verts[0] == e_verts[2] )
      idir = 1 ;
    else
      idir = -1 ;
    dir = F_dirUsingEdge(reg_faces[2],op_edge) ;
    if ( dir == 0 )
      dir = -1 ;
    else
      dir = 1 ;
    if ( dir*idir == 1 ) {
      F_chDir(reg_faces[2]) ;
      chDir2=1;
    }
    
    dir = F_dirUsingEdge(reg_faces[3],op_edge) ;
    if ( dir == 0 )
      dir = -1 ;
    else
      dir = 1 ;
    if ( dir*idir == -1 ) {
      F_chDir(reg_faces[3]) ;
      chDir3=1;
    }
    
    /* delete region face and edges */
    M_removeRegion(mesh,rgn) ;
    M_removeFace(mesh,reg_faces[0]) ;
    M_removeFace(mesh,reg_faces[1]) ;
    M_removeEdge(mesh,edge) ;
    
    /* change the classifications */
    F_setWhatIn(reg_faces[2],rement) ;
    F_setWhatIn(reg_faces[3],rement) ;
    E_setWhatIn(op_edge,rement) ;
    
#ifdef MA_PARALLEL
    sendReclassifiedEntity(mesh, (pEntity)reg_faces[2], chDir2);
    sendReclassifiedEntity(mesh, (pEntity)reg_faces[3], chDir3);
    sendReclassifiedEntity(mesh, (pEntity)op_edge, 0);
#endif
    
    return(1) ;
  }


  pEdge E_swapOnGFace(pMesh mesh, pEdge swpedge, pGEntity gface,	  
		      CBFunction CB, void *userData, pPList *newFcs)
  {
    pGEntity gent;
    pVertex v[2], vnew[2];
    pEdge e[4], edge, newe, edg2[4];
    pFace f[2], newf[2], tmpf;
    pPList tmpl;
    int i, j, dir[4],dir2[4];
    
    pPList oldFcs=PList_new();
    *newFcs = PList_new();
    
    gent = E_whatIn(swpedge);
    if( gent!=gface )
      return 0;
    
    if (E_numFaces(swpedge) != 2)
      return 0;
    
    for (i = 0; i < 2; i++) {
      v[i] = E_vertex(swpedge,i);
      f[i] = E_face(swpedge,i);
      PList_append(oldFcs,f[i]);
      if (F_whatIn(f[i]) != gface)
	return 0;
    }
    
    if (!F_dirUsingEdge(f[0],swpedge)) {
      tmpf = f[0];
      f[0] = f[1];
      f[1] = tmpf;
    }
    
    for (i = 0; i < 2; i++)
      vnew[i] = F_edOpVt(f[i],swpedge);
    
    for (i = 0; i < 2; i++) {
      for (j = 0; j < 3; j++) {
	edge = F_edge(f[i],j);
	if (edge == swpedge) continue;
	
	if (E_inClosure(edge,(pEntity)v[0])) {
	  e[i] = edge;
	  dir[i] = F_edgeDir(f[i],j);
	}
	else {
	  e[i+2] = edge;
	  dir[i+2] = F_edgeDir(f[i],j);
	}
      }
    }
    
    newe = M_createE(mesh, vnew[0], vnew[1], gface);
    if (!newe) {
      printf("WARN: Could not create edge (E_swapOnGFace)\n");
      return 0;
    }
    
    edg2[0] = newe; edg2[1] = e[3]; edg2[2] = e[2];
    dir2[0] = 1; dir2[1] = dir[3]; dir2[2] = dir[2];
    newf[0] = M_createF(mesh, 3, edg2, dir2, gface);
    if (!newf[0]) {
      M_removeEdge(mesh, newe);
      printf("WARN: Could not create face (E_swapOnGFace)\n");
      return 0;
    }
    
    edg2[0] = newe; edg2[1] = e[0]; edg2[2] = e[1];
    dir2[0] = 0; dir2[1] = dir[0]; dir2[2] = dir[1];
    newf[1] = M_createF(mesh, 3, edg2, dir2, gface);
    if (!newf[1]) {
      M_removeFace(mesh, newf[0]);
      M_removeEdge(mesh, newe);
      printf("WARN: Could not create face (E_swapOnGFace)\n");
      return 0;
    }
    
    PList_append(*newFcs,newf[0]);
    PList_append(*newFcs,newf[1]);
    
    /* call callback */
    if( CB ) 
      (CB)(oldFcs,*newFcs,userData,ESWAP,(pEntity)swpedge);
    PList_delete(oldFcs);
    
    /* deletion */
    M_removeFace(mesh, f[0]); /* There shouldn't be any floating edges */
    M_removeFace(mesh, f[1]); 

    M_removeEdge(mesh, swpedge);
    
    *newFcs = PList_new();
    PList_append(*newFcs,newf[0]);
    PList_append(*newFcs,newf[1]);
    
    return newe;
  }
  

  pVertex E_split(pMesh mesh,
		  pEdge edge,
		  double *xyz,
		  double *parm,
		  CBFunction CB, 
		  void *userData, 
		  pPList *newEnt)  // this routine allocate space 
  {
    pPList newRgnList;
    pPList oldRgnList;
    pVertex vnew, v0=E_vertex(edge,0),v1=E_vertex(edge,1) ;
    pGEntity fgent,rgent,edgeGeomEnt = E_whatIn(edge);
    pEdge oppedg,edg, e1, e2, enew, fedge[4], fedges2[3];
    pPList eregions,efaces,newFaceList ;
    int i,iedge,edir[4],bfdir[2],fcount,ecount,count,fdir1[4],fdir2[4] ;
    int edir2[3];
    pFace face,face1,face2,bface[2],rface1[4],rface2[4] ;
    pRegion region,rnew ;
    void *temp,*temp1 ;
    
    newRgnList = PList_new();
    oldRgnList = PList_new();
    newFaceList = PList_new();
    efaces = PList_new();
    
    eregions = E_regions(edge);
    for(iedge=0; iedge<E_numFaces(edge); iedge++)
      PList_append(efaces,E_face(edge,iedge));
    
    /* create a new vertex */
    vnew = M_createVP(mesh, xyz[0], xyz[1], xyz[2], parm, 0, edgeGeomEnt);
    
    /*  use the new vertex to break the edge into two  */
    e1 = M_createE(mesh,v0,vnew,edgeGeomEnt);
    e2 = M_createE(mesh,vnew,v1,edgeGeomEnt);

#ifdef CURVE__    
    if(E_numPoints(edge)){ // if splitting a curved edge
      if(1){    // if geometric model is not available
	E_setPoint(e1,curveUtil::extractPt(mesh,edge,0.25));
	E_setPoint(e2,curveUtil::extractPt(mesh,edge,0.75));
      }
      else{
	double coords[2][3];
	double par[2][3];
	templatesUtil::middlePoint(e1,0.5,coords[0],par[0]);
	templatesUtil::middlePoint(e2,0.5,coords[1],par[1]);
	pPoint pt[2];
	pt[0]=P_new();
	pt[1]=P_new();
	
	P_setPos(pt[0], coords[0][0], coords[0][1], coords[0][2]);
	P_setPos(pt[1], coords[1][0], coords[1][1], coords[1][2]);
	
	E_setPoint(e1, pt[0]);
	FMDB_P_setParametricPos(pt[0], par[0][0], par[0][1], par[0][2]);
	
	E_setPoint(e2, pt[1]);
	FMDB_P_setParametricPos(pt[1], par[1][0], par[1][1], par[1][2]);
      }
             
    }

#endif //CURVE

    /* split each face connected to the edge by creating an edge between vnew and
       the vertex opposite to edge, attach each new face to the edge that is not
       split and use it during creation of new regions. */
    temp = 0;
    while( (face=(pFace)PList_next(efaces,&temp)) ) {
      fgent = F_whatIn(face);
      /* create a new edge between vnew and the vertex opposite the edge on this face */
      enew = M_createE(mesh,vnew,F_edOpVt(face,edge),fgent);    
      
      /* get the ordered edge list such that the first edge in the list is the
	 edge being split */
      fedge[0] = edge ;
      for( i=0; i< F_numEdges(face); i++) {
	edg = F_edge(face,i);
	if(edg==edge) {
	  edir[0] = F_edgeDir(face,i);
	  break ;
	}
      }
      fedge[1] = F_edge(face,(i+1)%3);
      edir[1] = F_edgeDir(face,(i+1)%3);
      fedge[2] = F_edge(face,(i+2)%3);
      edir[2] = F_edgeDir(face,(i+2)%3);
      if(edir[0]) {        
	/* define face1 */
	/*      face1 = create_F(mesh,e1,enew,fedge[2],(pEdge)0,
		edir[0],edir[0],edir[2],0,fgent);
	*/
	fedges2[0] = e1; fedges2[1] = enew; fedges2[2] = fedge[2];
	edir2[0] = edir[0]; edir2[1] = edir[0]; edir2[2] = edir[2];
	face1 = M_createF(mesh, 3, fedges2, edir2, fgent);
	
	/* define face2 */
	/*
	  face2 = create_F(mesh,e2,fedge[1],enew,(pEdge)0,
	  edir[0],edir[1],(1-edir[0]),0,fgent);
	*/
	fedges2[0] = e2; fedges2[1] = fedge[1]; fedges2[2] = enew;
	edir2[0] = edir[0]; edir2[1] = edir[1]; edir2[2] = 1-edir[0];
	face2 = M_createF(mesh, 3, fedges2, edir2, fgent);
	
	/* attach face1 to the fedge[2] */
	EN_attachDataP((pEntity)fedge[2],"_Esp",(void *)face1);
	
	/* attach face2 to the fedge[1] */
	EN_attachDataP((pEntity)fedge[1],"_Esp",(void *)face2);
      }
      else {        
	/* define face1 */
	/*
	  face1 = create_F(mesh,e1,fedge[1],enew,(pEdge)0,
	  edir[0],edir[1],edir[0],0,fgent);
	*/
	fedges2[0] = e1; fedges2[1] = fedge[1]; fedges2[2] = enew;
	edir2[0] = edir[0]; edir2[1] = edir[1]; edir2[2] = edir[0];
	face1 = M_createF(mesh, 3, fedges2, edir2, fgent);
	
	/* define face2 */
	/*
	  face2 = create_F(mesh,e2,enew,fedge[2],(pEdge)0,
	  edir[0],(1-edir[0]),edir[2],0,fgent);
	*/
	fedges2[0] = e2; fedges2[1] = enew; fedges2[2] = fedge[2];
	edir2[0] = edir[0]; edir2[1] = 1-edir[0]; edir2[2] = edir[2];
	face2 = M_createF(mesh, 3, fedges2, edir2, fgent);
	
	/* attach face1 to the fedge[1] */
	EN_attachDataP((pEntity)fedge[1],"_Esp",(void *)face1);
	
	/* attach face2 to the fedge[2] */
	EN_attachDataP((pEntity)fedge[2],"_Esp",(void *)face2);
      }
      
      /* attach enew to face */
      EN_attachDataP((pEntity)face,"_Esp",(void *)enew);
      
      EN_attachDataP((pEntity)face1,"_Esp",face);
      EN_attachDataP((pEntity)face2,"_Esp",face);
      
      PList_append(newFaceList,face1);
      PList_append(newFaceList,face2);
    }
    if (eregions) {
      /* at this point the edge and all faces connected to it have been split,*/
      /* need to split each connected mesh region into two                    */
      temp = 0;
      while( (region = (pRegion)PList_next(eregions, &temp)) ) {
	rgent = (pGEntity)R_whatIn(region);
	/* create an internal face to split the region, need to get the edges
	   for this internal face and also the two faces that do not bound the
	   the edge being split */
	fcount=ecount=0;
	for(i=0; i<R_numFaces(region); i++) {
	  face = R_face(region,i);
	  if( F_inClosure(face,(pEntity)edge) )
	    fedge[ecount++] = (pEdge)EN_dataP((pEntity)face,"_Esp");
	  else {
	    bface[fcount] = face ;
	    bfdir[fcount++] = R_faceDir(region,i);
	  }
	}
	/* the third edge is the opposite edge */
	oppedg = R_gtOppEdg(region,edge);
	fedge[2] = oppedg;
	
	/* figure out the directions and the order of the edges, assume fedge[0]
	   is used in the direction of its definition */
	edir[0] = 1;
	if( E_vertex(fedge[0],1) != E_vertex(fedge[1],0) && 
	    E_vertex(fedge[0],1) != E_vertex(fedge[1],1) )  {
	  /* swap fedge[1], fedge[2] */
	  edg = fedge[1] ;
	  fedge[1] = fedge[2] ;
	  fedge[2] = edg ;
	}
	if( E_vertex(fedge[0],1) == E_vertex(fedge[1],0))
	  edir[1] = 1;
	else
	  edir[1] = 0;
	if( E_vertex(fedge[0],0) == E_vertex(fedge[2],1))
	  edir[2] = 1;
	else
	  edir[2] = 0;
      
	/* faces faces for region 1 */
	rface1[0] = bface[0] ;
	fdir1[0] = bfdir[0] ;
	/*
	  rface1[1] = rface2[1] = create_F(mesh,fedge[0],fedge[1],fedge[2],0,
	  edir[0],edir[1],edir[2],0,rgent);
	*/
	fedges2[0] = fedge[0]; fedges2[1] = fedge[1]; fedges2[2] = fedge[2];
	edir2[0] = edir[0]; edir2[1] = edir[1]; edir2[2] = edir[2];
	rface1[1] = rface2[1] = M_createF(mesh, 3, fedges2, edir2, rgent);
	count = 2;
	for(i=0; i<F_numEdges(bface[0]); i++) {
	  edg = F_edge(bface[0],i);
	  if( edg != oppedg ) {
	    rface1[count] = (pFace)EN_dataP((pEntity)edg,"_Esp");
	    fdir1[count] = R_dirUsingFace(region,(pFace)EN_dataP((pEntity)rface1[count],"_Esp"));
	    count++;
	  }
	  else {
	    if( F_dirUsingEdge(rface1[1],oppedg) == F_edgeDir(bface[0],i))
	      fdir1[1] = 1 - fdir1[0] ;
	    else
	      fdir1[1] = fdir1[0] ;         
	  }
	}
	
	/* faces faces for region 2 */
	rface2[0] = bface[1] ;
	fdir2[0] = bfdir[1] ;
	count = 2;
	for(i=0; i < F_numEdges(bface[1]); i++) {
	  edg = F_edge(bface[1],i);
	  if( edg != oppedg ) {
	    rface2[count] = (pFace)EN_dataP((pEntity)edg,"_Esp");
	    fdir2[count] = R_dirUsingFace(region,(pFace)EN_dataP((pEntity)rface2[count],"_Esp"));
	    count++;
	  }
	}
	
	fdir2[1] = 1 - fdir1[1] ;
	
	
	PList_append(oldRgnList,region);
	
	/*
	  rnew = create_R(mesh,rface1[0],rface1[1],rface1[2],rface1[3],0,0,
	  fdir1[0],fdir1[1],fdir1[2],fdir1[3],0,0,rgent);
	*/
	rnew = M_createR(mesh, 4, rface1, fdir1, rgent);
	PList_append(newRgnList,rnew);
	
	/*
	  rnew = create_R(mesh,rface2[0],rface2[1],rface2[2],rface2[3],0,0,
	  fdir2[0],fdir2[1],fdir2[2],fdir2[3],0,0,rgent);
	*/
	rnew = M_createR(mesh, 4, rface2, fdir2, rgent);
	PList_append(newRgnList,rnew);
      }
    }
    
    // call callback
    if( CB )
    {
      pPList newEdges=PList_new();
      PList_append(newEdges, e1);
      PList_append(newEdges, e2);
      pPList oldEdges = PList_new();
      PList_append(oldEdges, edge); 
      (CB)(oldEdges,newEdges,userData,E_REFINE,(pEntity)vnew); 
      PList_delete(oldEdges);
      PList_delete(newEdges);
/*
      if( PList_size(eregions)==0 )
        // surface mesh
        (CB)(efaces,newFaceList,userData,ESPLIT,(pEntity)vnew);
      else
        // volume mesh
        (CB)(oldRgnList,newRgnList,userData,ESPLIT,(pEntity)vnew);
*/
    }    
    /* delete the old regions */
    temp1=0;
    while( (region = (pRegion)PList_next(oldRgnList,&temp1)) ) 
      M_removeRegion(mesh, region);
    PList_delete(oldRgnList);
    
    /* delete the edge, its connected faces */    
    temp = 0;
    while( (face=(pFace)PList_next(efaces,&temp)) ) {
      EN_removeData((pEntity)face,"_Esp");
      for(i=0; i<F_numEdges(face); i++) {
	e1 = F_edge(face,i);
      if( e1 != edge )
        EN_removeData((pEntity)e1,"_Esp");
      }
      M_removeFace(mesh, face);
    }
    temp = 0;
    while( (face1=(pFace)PList_next(newFaceList,&temp)) )
      EN_removeData((pEntity)face1,"_Esp");
    
    if (eregions && PList_size(eregions)) {
      *newEnt = newRgnList;
      PList_delete(newFaceList);
    }
    else {
      *newEnt = newFaceList;
      PList_delete(newRgnList);
    }
    
    if (eregions) PList_delete(eregions);
    PList_delete(efaces);
    
    M_removeEdge(mesh,edge);
    return vnew ;
  }


  pVertex TopGrowth_E_split(pMesh mesh,
                            pEdge edge,
                            double *xyz,
                            double *parm,
                            CBFunction CB,
                            void *userData,
                            pPList *newEnt)  // this routine allocate space
  {

    if( !EN_isBLEntity((pEntity)edge) ||
        E_typeInBL(edge)!=eGROWTH ) {
      cout<<"\nError in fromMeshTools::TopGrowth_E_split()"<<endl;
      cout<<"edge is NOT a BL entity and/or growth edge"<<endl;
      exit(0);
    }

    pPList newRgnList;
    pPList oldRgnList;
    pVertex vnew, v0, v1, vtx;
    pGEntity fgent, rgent, egment = E_whatIn(edge);
    // fedge is used for quad. and fedges2 for tri. (keep array size as 4)
    pEdge oppedg, edg, e1, e2, enew, fedge[4], fedges2[4];
    pPList eregions, efaces, newFaceList ;
    // keep array size for edge dirs. as 4 and for face dirs. as 5
    int i, iedge, numEdges, edir[4], edir2[4], ecount, count1, count2, fdir1[5], fdir2[5];
    pFace face, face1, face2, topFace, fc, rface1[5], rface2[5] ;
    pRegion region, rnew ;
    void *temp;

    // should be more careful in assigning level and surfTag
    int level = EN_levelInBL((pEntity)edge);
    // v0 is taken to be the vertex at lower level
    v0 = E_vertex(edge,0);
    if(level==EN_levelInBL((pEntity)v0))
      v0 = E_vertex(edge,1);
    v1 = E_otherVertex(edge,v0);

    newRgnList = PList_new();
    oldRgnList = PList_new();
    newFaceList = PList_new();
    efaces = PList_new();

    eregions = E_regions(edge);

    // check if any transition elements
    for(int iRgn=0; iRgn<PList_size(eregions); iRgn++) {
      if(((pRegion)PList_item(eregions,iRgn))->getType()!=PRISM) {
        cout<<"\nError in fromMeshTools::TopGrowth_E_split()"<<endl;
        cout<<"edge bounds element other than prism/wedge"<<endl;
        exit(0);
      }
    }

    // check if the edge is the top most growth edge
    if(!V_atBLInterface(v1)) {
      cout<<"\nError in fromMeshTools::TopGrowth_E_split()"<<endl;
      cout<<"edge is NOT the top most growth edge"<<endl;
      exit(0);
    }

    double mtol = M_getTolerance();
    double exyz[2][3];
    V_coord(v0,exyz[0]);
    V_coord(v1,exyz[1]);
    double t = adaptUtil::ParOnLinearEdge(exyz,xyz);
    if(t-mtol>1. || t+mtol<0.) {
      cout<<"\nError in fromMeshTools::TopGrowth_E_split()"<<endl;
      cout<<"specified location is quiet OFF the edge"<<endl;
      cout<<" v0  : "<<exyz[0][0]<<" "<<exyz[0][1]<<" "<<exyz[0][2]<<endl;
      cout<<" v1  : "<<exyz[1][0]<<" "<<exyz[1][1]<<" "<<exyz[1][2]<<endl;
      cout<<" xyz : "<<xyz[0]<<" "<<xyz[1]<<" "<<xyz[2]<<endl;
      exit(0);
    }

    // collect the vertical quad faces
    // all the faces would be vertical quad. faces
    // (transition elements not supported)
    int numFaces = E_numFaces(edge);
    for(iedge=0; iedge<numFaces; iedge++)
      PList_append(efaces,E_face(edge,iedge));

    vnew = M_createVP2(mesh,xyz,parm,0,egment);

    /*  use the new vertex to break the edge into two  */
    /* e1 is new growth edge and e2 is interior volume edge*/
    e1 = M_createE(mesh,v0,vnew,egment);
    e2 = M_createE(mesh,vnew,v1,egment);

    /* split each quad. face connected to the "edge" by creating an
       edge connecting new vertex and opp. higher level vertex into
       triangular and quad. face */
    temp = 0;
    while( (face=(pFace)PList_next(efaces,&temp)) ) {
      fgent = F_whatIn(face);
      /* create a new edge between vnew and the higher level vertex on this face */
      numEdges = F_numEdges(face);
      for(int iEdge=0; iEdge<numEdges; iEdge++) {
        edg = F_edge(face,iEdge);
        if(edg==edge)
          continue;
        if(E_inClosure(edg,(pEntity)v1)) {
          oppedg = edg;
          break;
        }
      }
      enew = M_createE(mesh,vnew,E_otherVertex(oppedg,v1),fgent);

      /* get the ordered edge list such that the first edge in the list is the
         edge being split */
      fedge[0] = e1;
      fedges2[0] = e2;
      for( i=0; i<numEdges; i++) {
        edg = F_edge(face,i);
        if(edg==edge) {
          if(E_vertex(e1,0)==E_vertex(edge,0))
            edir[0] = F_dirUsingEdge(face,edge);
          else
            edir[0] = 1-F_dirUsingEdge(face,edge);
          edir2[0] = edir[0];
          break ;
        }
      }
      int otherEdgeTriFace = 0;
      ecount = 1;
      for(int iEdge=1; iEdge<numEdges; iEdge++) {
        edg = F_edge(face,(i+iEdge)%numEdges);
        if(edg==oppedg) {
          fedge[iEdge] = enew;
          if(E_vertex(enew,1)==E_vertex(oppedg,1))
            edir[iEdge] = F_dirUsingEdge(face,oppedg);
          else
            edir[iEdge] = 1-F_dirUsingEdge(face,oppedg);
          fedges2[ecount] = oppedg;
          edir2[ecount++] = F_dirUsingEdge(face,oppedg);
          continue;
        }
        fedge[iEdge] = edg;
        edir[iEdge] = F_dirUsingEdge(face,edg);
        // do this only once (as fedges2 are for trianglular face)
        if(!otherEdgeTriFace) {
          otherEdgeTriFace = 1;
          fedges2[ecount] = enew;
          // opp. dir. to e2 (zeroth vertex for enew and e2 is vnew)
          edir2[ecount++] = 1-edir2[0];
        }
      }

      face1 = M_createF(mesh, 4, fedge, edir, fgent);
      face2 = M_createF(mesh, 3, fedges2, edir2, fgent);

      // fedge[2] is the other growth edge
      /* attach face1 to the fedge[2] */
      EN_attachDataP((pEntity)fedge[2],"_Esp",(void *)face1);

      // oppedg is the top most edge, i.e., at BL interface
      /* attach face2 to the oppedg */
      EN_attachDataP((pEntity)oppedg,"_Esp",(void *)face2);

      /* attach enew to face */
      EN_attachDataP((pEntity)face,"_Esp",(void *)enew);

      EN_attachDataP((pEntity)face1,"_Esp",face);
      EN_attachDataP((pEntity)face2,"_Esp",face);

      PList_append(newFaceList,face1);
      PList_append(newFaceList,face2);
    }

    if (PList_size(eregions)) {
      /* at this point the edge and all faces connected to it have been
         split, need to split each connected mesh region into two */
      temp = 0;
      while( (region = (pRegion)PList_next(eregions, &temp)) ) {
        rgent = (pGEntity)R_whatIn(region);
        /* create an internal face to split the region, need to get the edges
           for this internal face and also the faces that do not bound the
           the edge being split */
        ecount=0;
        for(i=0; i<R_numFaces(region); i++) {
          face = R_face(region,i);
          if( F_inClosure(face,(pEntity)edge) )
            fedge[ecount++] = (pEdge)EN_dataP((pEntity)face,"_Esp");
          else {
            if(F_inClosure(face,(pEntity)v1)) {
              topFace = face;
              /* the third edge is the opposite edge */
              oppedg = F_vtOpEd(face,v1);
              fedge[2] = oppedg;
            }
          }
        }

        /* figure out the directions and the order of the edges,
           use similar to topFace */
        // fedge[0] is used negatively and fedge[1] is used positively
        edir[0] = 0;
        edir[1] = 1;
        edir[2] = F_dirUsingEdge(topFace,oppedg);
        i = edir[2];
        // second/end vertex of fedge[0] is always other than vnew
        // compare it with oppedg's i-th vertex (i.e., based on its usage)
        if(E_vertex(fedge[0],1)!=E_vertex(oppedg,i)) {
          /* swap fedge[0], fedge[1] */
          edg = fedge[0];
          fedge[0] = fedge[1];
          fedge[1] = edg;
        }

        fc = M_createF(mesh, 3, fedge, edir, rgent);

        count1 = 0;
        count2 = 0;
        /* faces for region 1 and 2 */
        for(i=0; i<R_numFaces(region); i++) {
          face = R_face(region,i);
          if( F_inClosure(face,(pEntity)edge) ) {
            edg = (pEdge)EN_dataP((pEntity)face,"_Esp");
            // other than vnew
            vtx = E_vertex(edg,1);
            // there are other ways to get this edge
            edg = V_growthEdge(vtx,-1);
            rface1[count1] = (pFace)EN_dataP((pEntity)edg,"_Esp");
            fdir1[count1] = R_dirUsingFace(region,(pFace)EN_dataP((pEntity)rface1[count1],"_Esp"));

            edg = 0;
            // there are other ways to get this edge
            edg = E_exists(vtx,v1);
            if(edg) {
              rface2[count2] = (pFace)EN_dataP((pEntity)edg,"_Esp");
              fdir2[count2] = R_dirUsingFace(region,(pFace)EN_dataP((pEntity)rface2[count2],"_Esp"));
            }
            else {
              cout<<"\nError in fromMeshtools::TopGrowth_E_split()"<<endl;
              cout<<"could NOT find the required edge to create new non-BL region"<<endl;
              exit(0);
            }
          }
          else {
            if(face==topFace) {
              rface1[count1] = fc;
              fdir1[count1] = R_dirUsingFace(region,topFace);

              rface2[count2] = topFace;
              fdir2[count2] = R_dirUsingFace(region,topFace);
            }
            else {
              rface1[count1] = face;
              fdir1[count1] = R_dirUsingFace(region,face);

              // topFace containing v1 for rface2 has been accounted
              if(F_inClosure(face,(pEntity)v0)) {
                rface2[count2] = fc;
                fdir2[count2] = 1-R_dirUsingFace(region,topFace);
              }
              else {
                // decrement count2 to compensate for the increment that will be done in this loop
                count2--;
              }
            }
          }
          count1++;
          count2++;
        }

        PList_append(oldRgnList,region);

        rnew = M_createR(mesh, count1, rface1, fdir1, rgent);
        PList_append(newRgnList,rnew);

        rnew = M_createR(mesh, count2, rface2, fdir2, rgent);
        PList_append(newRgnList,rnew);
      }
    }

    // call callback
    if( CB )
      {
        if( PList_size(eregions)==0 )
          // surface mesh
          (CB)(efaces,newFaceList,userData,TOPGESPLIT,(pEntity)vnew);
        else
          // volume mesh
          (CB)(oldRgnList,newRgnList,userData,TOPGESPLIT,(pEntity)vnew);
      }

    // label and unlabel BL entities using new and old regions, respectively
    temp = 0;
    while( (region = (pRegion)PList_next(newRgnList,&temp)) ) {
      if(region->getType()==PRISM) {
        for(int iFace=0; iFace<R_numFaces(region); iFace++) {
          face = R_face(region,iFace);
          // face is labelled or not
          if(!EN_isBLEntity((pEntity)face)) {
            numEdges = F_numEdges(face);
            if(numEdges==4)
              // top level vertical quad face
              EN_labelBLEntity((pEntity)face,level,fVERTICAL_QUAD);
            else if(numEdges==3) {
              // top level layer (triangular) face
              EN_labelBLEntity((pEntity)face,level,fLAYER);

              for(int iEdge=0; iEdge<numEdges; iEdge++) {
                edg = F_edge(face,iEdge);
                if(!EN_isBLEntity((pEntity)edg))
                  // top most layer edge
                  EN_labelBLEntity((pEntity)edg,level,eLAYER);
              }
            }
            else {
              cout<<"\nError in fromMeshTools::TopGrowth_E_split()"<<endl;
              cout<<"face topo. [num. edges="<<numEdges<<"] NOT supported (while labelling BL entities)"<<endl;
              exit(0);
            }
          }
          else if (face->getType() == TRI)
          {
            pBLayer pbl = EN_getBL(face);
            int bl_size = EG_getNumOfEntities(pbl);
            pRegion reg_del = pbl->getEntity(bl_size-1);
            pbl->removeEntity(reg_del);
            pbl->addEntity(region); 

            /// Assign BL ptr to the newly created layer face
            if (iFace == 0)
              face = R_face(region, 4);
            else
              face = R_face(region, 0);
            pMeshDataId egTag = MD_lookupMeshDataId("EntityGroupTag");
            EN_attachDataPtr(face, egTag, pbl);
          }
        }
        EN_labelBLEntity((pEntity)region,level,rREGULAR);
      }
      else if(region->getType()==PYRAMID) {
        cout<<"\nError in fromMeshTools::TopGrowth_E_split()"<<endl;
        cout<<"transition elements not supported (while labelling BL entities)"<<endl;
        exit(0);
      }
    }
    if (level == 0)
      EN_labelBLEntity((pEdge)vnew,level,vORIGINATING);
    else
      EN_labelBLEntity((pEdge)vnew,level,vREGULAR);
    EN_labelBLEntity((pEdge)e1,level,eGROWTH);

    /* delete the old regions */
    temp = 0;
    while( (region = (pRegion)PList_next(oldRgnList,&temp)) ) {

      for(int iFace=0; iFace<R_numFaces(region); iFace++) {
        face = R_face(region,iFace);
        if(F_inClosure(face,(pEntity)v1)) {
          if(!EN_isBLEntity((pEntity)face))
            continue;

          EN_unlabelBLEntity((pEntity)face);

          numEdges = F_numEdges(face);
          for(int iEdge=0; iEdge<numEdges; iEdge++) {
            edg = F_edge(face,iEdge);
            if( EN_isBLEntity((pEntity)edg) &&
                E_inClosure(edg,(pEntity)v1) )
              EN_unlabelBLEntity((pEntity)edg);
          }
        }
      }

      EN_unlabelBLEntity((pEntity)region);

      M_removeRegion(mesh, region);
    }
    PList_delete(oldRgnList);

    EN_unlabelBLEntity((pEntity)v1);
    // actually this is already unlabelled
    EN_unlabelBLEntity((pEntity)edge);

    /* delete the edge, its connected faces */
    temp = 0;
    while( (face=(pFace)PList_next(efaces,&temp)) ) {
      EN_removeData((pEntity)face,"_Esp");
      for(i=0; i<F_numEdges(face); i++) {
        edg = F_edge(face,i);
      if( edg != edge ||
          !E_inClosure(edg,(pEntity)v0))
        EN_removeData((pEntity)edg,"_Esp");
      }
      M_removeFace(mesh, face);
    }

    temp = 0;
    while( (face=(pFace)PList_next(newFaceList,&temp)) )
      EN_removeData((pEntity)face,"_Esp");

    if (eregions && PList_size(eregions)) {
      *newEnt = newRgnList;
      PList_delete(newFaceList);
    }
    else {
      *newEnt = newFaceList;
      PList_delete(newRgnList);
    }

    if (eregions) PList_delete(eregions);
    PList_delete(efaces);

    M_removeEdge(mesh,edge);
    return vnew;
  }



  pVertex R_split(pMesh mesh, pRegion region, double *xyz, pPList *newReg) 
  { 
    pGEntity gent = (pGEntity)R_whatIn(region);
    pFace face[4];
    pVertex vnew = 0;
    pPList flist;
    int i, rfdir[4];
    double par[3]={0,0,0};
    
    /* first store usage of faces by the to-be-deleted region */
    for (i = 0; i < 4; i++) {
      face[i] = R_face(region,i);
      rfdir[i] = R_faceDir(region,i);
    }
    
    /* delete the region */
    M_removeRegion(mesh, region);
    
    /* create a new vertex */
    vnew  = M_createVP(mesh, xyz[0], xyz[1], xyz[2], par, 0, gent);
    
    /* finally, create new regions by connecting the boundary */
    /* faces of the cavity to the vnew                        */
    *newReg = PList_new() ;
    for (i = 0; i < 4; i++) {
      region = F_vrtCrtReg(mesh,face[i],rfdir[i],vnew,gent);
      PList_append(*newReg,region);
    }
    
    if (!PList_size(*newReg)) {
      PList_delete(*newReg);
      *newReg = 0;
    }
    
    return vnew ;
  } 



  /*
    3D face Swap operations are performed thru 3->2, 2->3 and 2->2
    transformations. returns 1 if the swap is realized 0 if not.
  */
  int F_swap(pMesh mesh,
	     pFace face,
	     double tol,
	     CBFunction CB, 
	     void *userData, 
	     pPList* delRegs,
	     pPList* newRegs)
  {
    int i,j,k,ok;
    pRegion newregion;
    pVertex vop[2];
    pFace faced1,faced2;
    pPList fvlist,rvlist;
    pGEntity gen;
    pVertex vertex,v[2];
    pFace nface[3][3],nrface[4],newfaces[3],newface;
    int   ndir[3][3],nedir[3],nfdir[4];
    pEdge edge,nedge[3],newedge;
    
    *newRegs=PList_new();
    *delRegs=PList_new();
    
    if( fsc.face != face ) 
      return 0;
    
    /* Transformation thru non-manifold regions are forbidened */
    gen=F_whatIn(face);
    if(gen && GEN_type(gen)==Tface) 
      return(0);
    
    switch (fsc.swapType) {
      
    case TRI2TWO: 
      
      /* find the vertex which is not in the third region */    
      fvlist=F_vertices(face,1);
      rvlist=R_vertices(fsc.thirdReg,1);
      
      for(i=0;i<PList_size(fvlist);++i){
	vertex=(pVertex)PList_item(fvlist,i);
	ok=0;
	for(j=0;j<PList_size(rvlist);++j)
	  if(PList_item(rvlist,j)==vertex){
	    ok=1;
	    break;
	  }
	if(!ok) 
	  break;
      }
      
      if(ok){
	printf("WARN: region face connect. wrong  (F_swap)\n");
	return(0);
      }
      
      /* find the other vertices of the face */
      
      k=0;
      for(i=0;i<PList_size(fvlist);++i){
	if(PList_item(fvlist,i)!=vertex){
	  v[k]=(pVertex)PList_item(fvlist,i);
	  ++k;
	}
      }
      
      PList_delete(fvlist);
      PList_delete(rvlist);
      
      /* should be ok */
      PList_append(*delRegs,fsc.oppRegs[0]);
      PList_append(*delRegs,fsc.oppRegs[1]);
      PList_append(*delRegs,fsc.thirdReg);
      
      for(i=0;i<2;++i) {
	for(j=0;j<2;++j){
	  nface[i][j]=R_vtOpFc(fsc.oppRegs[i],v[j]);
	  ndir[i][j]=R_dirUsingFace(fsc.oppRegs[i],nface[i][j]);
	}
	
	nface[2][i]=R_vtOpFc(fsc.thirdReg,v[i]);
	ndir[2][i]=R_dirUsingFace(fsc.thirdReg,nface[2][i]);
      }
      
      /* create entities bottom up*/
      
      for(i=0;i<3;++i){
	nedge[i]=F_vtOpEd(nface[i][0],v[1]);
	nedir[i]=!(F_dirUsingEdge(nface[i][0],nedge[i]) ^ ndir[i][0]);
      }
      E_reorder(nedge,nedir,3);
      newface=M_createF(mesh,3,nedge,nedir,gen);
      
      for(i=0;i<2;++i){
	nrface[0]=nface[0][i];
	nrface[1]=nface[1][i];
	nrface[2]=nface[2][i];
	nrface[3]=newface;
	nfdir[0]=ndir[0][i];
	nfdir[1]=ndir[1][i];
	nfdir[2]=ndir[2][i];
	nfdir[3]=i;
	newregion=M_createR(mesh,4,nrface,nfdir,gen);
	PList_append(*newRegs,newregion);
      }
      
      /* call callback  */
      if( CB ) 
	(CB)(*delRegs,*newRegs,userData,FSWAP,(pEntity)face);
      
      /* remove entities top down */
      
      faced1=R_vtOpFc(fsc.oppRegs[0],vertex);
      faced2=R_vtOpFc(fsc.oppRegs[1],vertex);
      
      M_removeRegion(mesh,fsc.oppRegs[0]);
      M_removeRegion(mesh,fsc.oppRegs[1]);
      M_removeRegion(mesh,fsc.thirdReg);
      
      M_removeFace(mesh,face);
      M_removeFace(mesh,faced1);
      M_removeFace(mesh,faced2);
      
      M_removeEdge(mesh,E_exists(v[0],v[1]));
      
      return(1);
      
    case TWO2TRI:
      
      for(i=0;i<2;++i)
	vop[i]=R_fcOpVt(fsc.oppRegs[i],face);  
      
      /* keep the original orientation */
      fvlist=F_vertices(face,1);
      
      for(i=0;i<2;++i)
	for(j=0;j<3;++j){
	  nface[i][j]=R_vtOpFc(fsc.oppRegs[i],(pVertex)PList_item(fvlist,j));
	  ndir[i][j]=R_dirUsingFace(fsc.oppRegs[i],nface[i][j]);
	}
      
      /* should be ok */
      PList_append(*delRegs,fsc.oppRegs[0]);
      PList_append(*delRegs,fsc.oppRegs[1]);
      
      
      /* create entities bottom up*/
      newedge=M_createE(mesh,vop[0],vop[1],gen);
      
      for(i=0;i<3;++i){
	nedge[0]=F_vtOpEd(nface[0][i],(pVertex)PList_item(fvlist,(i+1)%3));
	nedge[1]=F_vtOpEd(nface[1][i],(pVertex)PList_item(fvlist,(i+1)%3));
	nedge[2]=newedge;
	nedir[0]=1-!(F_dirUsingEdge(nface[0][i],nedge[0]) ^ ndir[0][i]);
	nedir[1]=1-!(F_dirUsingEdge(nface[1][i],nedge[1]) ^ ndir[1][i]);
	if(E_vertex(nedge[0],nedir[0])==vop[0])
	  nedir[2]=1;
	else
	  nedir[2]=0;
	E_reorder(nedge,nedir,3);		
	newfaces[i]=M_createF(mesh,3,nedge,nedir,gen);      
      }
      
      
      for(i=0;i<3;++i){
	nrface[0]=nface[0][i];
	nrface[1]=nface[1][i];
	nrface[2]=newfaces[i];
	nrface[3]=newfaces[(i+2)%3];
	nfdir[0]=ndir[0][i];
	nfdir[1]=ndir[1][i];
	nfdir[2]=1;
	nfdir[3]=0;
	newregion=M_createR(mesh,4,nrface,nfdir,gen);
	PList_append(*newRegs,newregion);
      }
      PList_delete(fvlist);
      
      /*  call callback  */
      if( CB ) 
	(CB)(*delRegs,*newRegs,userData,FSWAP,(pEntity)face);
      
      /* remove entities top down */
      M_removeRegion(mesh,fsc.oppRegs[0]);
      M_removeRegion(mesh,fsc.oppRegs[1]);
      
      M_removeFace(mesh,face);
      
      return(1);
      
    case TWO2TWO:
      /* actually an edge swap of volume mesh */
      
      /* there is only one configuration, so no issue of finding the best */
      k=E_defaultRegionSwpCfg (edge);
      if ( k!=-1 )
	/* apply edge swap */
	ok=E_swap(mesh,edge,k,CB,userData,newRegs);
      else
	ok=0;
      
      if( !ok ) 
	/* this face swap is invalid */
	printf("WARNING: should evaluate before the actual application (F_swap)\n");
      
      else
	{
	  PList_append(*delRegs,fsc.oppRegs[0]);
	  PList_append(*delRegs,fsc.oppRegs[1]);
	}
      
      return(ok);
    }
    
  }

  
  /*  Given a cavity associated with a mesh edge, collect classification
      and direction information on cavity boundary needed to retriangulate
      the cavity.   (Needed by E_swap())
  */  
  void E_getCavityBdry(pEdge ledge,       
		       pPList regions,
		       pPList *faces,
		       pPList *edges, 
		       int *modelDir)
  {
    pGEntity g_entity,eg_entity;
    pRegion region;
    pFace face,face_2;
    pEdge edge,edge_2,edge_list[3] ;
    pVertex vert_2;
    int i,j,type,nbr,k,dir,m,flag,etype,numEdges,found,ledgeDeleted;
    void *temp=0,*temp1=0,*temp2=0 ,*temp3=0 ,*temp4=0 ;
    
    *faces = PList_new() ;
    *edges = PList_new() ;
    *modelDir = -1 ;
    
    temp = 0 ;
    while ( region = (pRegion)PList_next(regions,&temp) ) {
      nbr = R_numFaces(region) ;
      for ( j= 0 ; j< nbr ; j++ ) {
	face = R_face(region,j);
	/* Check if edge is in closure of face */
	if ( !F_inClosure(face,(pEntity)ledge )) {
	  dir = R_faceDir(region,j);
	  EN_attachDataI((pEntity)face,"fdir",dir) ;
	  PList_append(*faces,face) ;
	}
	else {
	  if ( F_whatInType(face) == Gface ) 
	    *modelDir = R_faceDir(region,j) ;
	}
      }
    }
    
    for( i=0; i<E_numFaces(ledge); i++ ) {
      face=E_face(ledge,i);
      /* 'face' is disconnected, it may be on a model face or
	 an interior face, if it is on a model face, its original
	 direction and classification need to be stored */
      g_entity = F_whatIn(face);
      type = F_whatInType(face);
      if ( type == Gface && F_inClosure(face,(pEntity)ledge) ) {
	/* Check if 'face' is bounded by 'ledge' and bounded by 'ledge',
	   store information about the edges, these faces will be deleted */
	for ( k= 0 ; k< 3 ; k++ ) {
	  edge = F_edge(face,k ) ;
	  dir = F_edgeDir(face,k);
	  
	  /* If 'edge' not in 'edges', put it in
	     otherwise, take it out, these are possible holes in
	     the polyhedron */
	  if ( PList_inList(*edges, edge ) ) {
	    /* Edge is in the list, remove it from the list */
	    EN_removeData((pEntity)edge,"edir") ;
	    EN_removeData((pEntity)edge,"ecls") ;
	    PList_remItem(*edges, edge) ;
	  }
	  else {
	    /* Edge is not in the list, add it to the list */
	    EN_attachDataI((pEntity)edge,"edir",dir) ;
	    EN_attachDataP((pEntity)edge,"ecls",g_entity) ;
	    PList_append(*edges,edge) ;
	  }
	}
      }
    }
    
    return;
  }


  /*    Given a set of mesh edges and a vertex,
	create faces by connecting the edges to the vertex
	Note: The created faces receive the classification
	of the faces they are replacing  -needed by E_swap()
  */
  void E_vrtCrtFaces(pMesh OM_mesh, pPList edgeList, pVertex vert)
  {
    pEdge edge;
    pGEntity g_entity;
    int dir;
    int found;
    int j;
    pVertex vert_1;
    pFace face;
    void *temp = 0 ;
    
    temp = 0 ;
    while ( edge = (pEdge)PList_next(edgeList, &temp ) )
      {
	g_entity = (pGEntity)EN_dataP((pEntity)edge,"ecls") ;
	dir = EN_dataI((pEntity)edge,"edir") ;
	
	/*
	  Check if 'edge' is bounded by 'vert'
	*/
	if ( !E_inClosure(edge,(pEntity)vert) )
	  /* If edge is not bounded by vert, create a new face for this edge */
	  face = E_vrtCrtFc(OM_mesh, edge,vert,g_entity,dir);
	
	/* Remove the data item attached to the edge */
	EN_removeData((pEntity)edge,"edir") ;
	EN_removeData((pEntity)edge,"ecls") ;
      }
  }
  


  /* Retriangulate the polyhedron    neede by E_swap() */
  pPList E_swpCrtRegs(pMesh mesh, int tri_nbr, pVertex tri_verts[][3], 
		      pVertex e_verts[2],pGEntity rg_entity, pPList faceList,
		      int modelDir )
  {
    pGEntity g_entity_2;
    pVertex opp_vert,vert,f_verts[3],f_verts_2[3],e_verts_2[2];
    pEdge   edge;
    pFace   face,face_2,face_3;
    pRegion region,region_2;
    pPList  plist,new_regions;
    int     i,j,k,m,dir,dir_3,flag,status,status_2,type_2,numFaces;
    void   *temp = 0 ;
    int   type ;
    
    /* Triangulate the polygon, given by the list of
       vertices as all the created faces are classified in region,
       the direction of the face(s) does not matter
       Triangulate the polyhedron */
    new_regions = PList_new() ;
    
    for ( i=0 ; i<tri_nbr ; i++ ) {
      /* For each new triangle in the triangulation
	 create a face and two new regions */
      /* Collect the vertices of the newly created triangle */
      for ( j= 0 ; j< 3 ; j++ )
	f_verts[j]= tri_verts[i][j];
      /* Create an edge (if not already there) from f_verts[0] to f_verts[1]  */
      e_verts_2[0] = f_verts[0];
      e_verts_2[1] = f_verts[1];
      /* Check for the existance of the edge in the database */
      edge = E_exists(e_verts_2[0],e_verts_2[1]);
      if ( !edge )
	edge =  M_createE(mesh, e_verts_2[0], e_verts_2[1], rg_entity);
      
      /* Create face that connects to f_verts[2] */
      dir= 1;
      face = E_vrtCrtFc(mesh,edge,f_verts[2],rg_entity,dir);
      
      /* Create region that connects to e_verts */
      /* Since we need to know the direction the new region
	 will use the base face, check for any existing face
	 whose use is known, for each face create two new regions */       
      for ( j= 0 ; j< 2 ; j++ ) {
	plist= F_vertices(face,1) ;
	temp = 0 ;
	k = 0 ;
	while ( vert = (pVertex)PList_next(plist,&temp) ) 
	  f_verts[k++] = vert ;
	PList_delete(plist);
	flag = 0;
	for ( k= 0 ; k< 3 ; k++ ) {
	  /* Need to create the other three faces for the regions,
	     first check if the already exisit in the database and
	     if we know how the face is used in the definition of
	     the region, if we know any face whose orientation is
	     known we use that face in the creation of the region 
	     connecting it to the vertex of the edge */
	  if ( k == 0 ) {
	    f_verts_2[0]= f_verts[0];
	    f_verts_2[1]= f_verts[1];
	    f_verts_2[2]= e_verts[j];
	    opp_vert= f_verts[2];
	  }  
	  else if ( k == 1 ) {
	    f_verts_2[0]= f_verts[1];
	    f_verts_2[1]= f_verts[2];
	    f_verts_2[2]= e_verts[j];
	    opp_vert= f_verts[0];
	  }  
	  else if ( k == 2 ) {
	    f_verts_2[0]= f_verts[2];
	    f_verts_2[1]= f_verts[0];
	    f_verts_2[2]= e_verts[j];
	    opp_vert= f_verts[1];
	  }
	  face_2 = F_exists(Tvertex,(pEntity)f_verts_2[0],(pEntity)f_verts_2[1],(pEntity)f_verts_2[2],0);
	  /* If the face does not exist, continue */
	  if ( !face_2 ) continue;
	  /* Face is in the database see if we can use the direction
	     information from the face */

	  /* if the face is on the boundary of cavity */
	  if(  PList_inList(faceList,face_2) ) {
	    /* Use the stored direction */
	    dir_3 = EN_dataI((pEntity)face_2,"fdir") ;
	    flag = 1 ;
	  }

	  g_entity_2 = F_whatIn(face_2);
	  type = GEN_type(g_entity_2);
	  if ( !flag && type == Gregion ) {
	    /*  Because of order faces and regions are created
		Assume there is exactly 1 region connected to it 
	        This is true only if the face is not on cavity bounfary  -li*/
	    region_2 = F_region(face_2,0);
	    if ( region_2 == 0 ) region_2= F_region(face_2,1);
	    if ( region_2 != 0 ) {
	      /* We have found one region which uses the face,
		 use the face in the other orientation */
	      numFaces = R_numFaces(region_2) ;
	      for ( m= 0 ; m < numFaces ; m++ ) {
		face_3 = R_face(region_2,m);
		dir_3  = R_faceDir(region_2,m);
		/* Flip the direction */
		dir_3 = 1 - dir_3 ;
		if ( face_3 == face_2 ) {
		  break;
		}
	      }
	      if ( m == numFaces )
		printf("FATAL: Inconsistecny in mesh (E_swpCrtRegs)\n");
	      flag= 1;
	      break;
	    }
	  }
	  if ( !flag && type==Gface ) {
	    /*Has to be a face coming from 'edges_vert_create_faces'
	      New region will that face the same way as the old face
	      These are new faces created on the model faces, hence
	      will use the same direction as used by the previous face */
	    dir_3 = modelDir ;
	    if ( dir_3 == -1 )
	      printf("FATAL: Face created on model face  (E_swpCrtRegs)\n") ;
	    flag = 1 ;
	  }
	  /* See if we have found one face for which we know the direction */  
	  if ( flag == 1 ) break;
	}
	if ( !flag )
	  printf("FATAL: Can't find a face with known direction (E_swpCrtRegs)\n");
	/* Found a face and direction, create the region by connecting it
	   to the opposite vertex */
	region = F_vrtCrtReg(mesh,face_2,dir_3,opp_vert,rg_entity) ;
	/* Add the newly created region to the list */
	PList_append(new_regions,region) ;
      }
    }
    /* Loop over all the entities in faceList and delete any
       data to the face */
    temp  = 0 ;
    while ( face = (pFace)PList_next(faceList,&temp) )
      EN_removeData((pEntity)face,"fdir") ;
    /* Return the list of newly created regions */
    return new_regions ;
  }
  

  void E_reorder(pEdge* elist,int* edir, int n)
  {
    pEdge* nelist;
    int* nedir;
    int i,k,cnt;
    pVertex vertex;
    
    nelist=(pEdge*)calloc(n,sizeof(pEdge));
    nedir=(int*)calloc(n,sizeof(int));
    
    nelist[0]=elist[0];
    nedir[0]=edir[0];
    
    vertex=E_vertex(elist[0],edir[0]);
    cnt=1;
    do{
      for(i=1;i<n;++i){
	if(EN_dataI((pEntity)elist[i],"atla")) continue;
	for(k=0;k<2;++k)
	  if(E_vertex(elist[i],k)==vertex){
	    nelist[cnt]=elist[i];
	    nedir[cnt]=edir[i];
	    EN_attachDataI((pEntity)elist[i],"atla",1);
	    vertex=E_vertex(elist[i],!k);
	    ++cnt;
	    break;
	  }
      }
    }while(cnt<n);
    
    for(i=0;i<n;++i){
      EN_removeData((pEntity)elist[i],"atla");
      elist[i]=nelist[i];
      edir[i]=nedir[i];
    }
    
    free(nelist);
    free(nedir);
    
  }   

  int E_defaultRegionSwpCfg (pEdge edge)
  {
    int i, num; 
    
    num = fromMeshTools::E_numSwpCfg (edge); 
    for (i=0; i<num; i++) {
      if(E_evalSwpCfg (edge, i)) 
	return i;
    }
    return -1;
  }

  /* Given a mesh edge and a vertex, create a mesh face
     by connecting the mesh edge to the vertex
  */
  pFace E_vrtCrtFc(pMesh mesh, pEdge edge, pVertex vert,
		   pGEntity g_entity, int dir)
  {
    int i, ii;
    pVertex verts[3], vert1, vert2, vert3;
    pEdge edges[3];
    pVertex e_verts[2];
    int status;
    pEdge f_edges[3];
    pEdge f_edges_2[3];
    pEdge e_temp;
    int f_dirs[3];
    int type;
    pGEntity g_entity_1;
    int type_1;
    pFace face ;
    int link_nbr;
    
    type = GEN_type(g_entity);
    
    for ( i= 0 ; i< 2 ; i++ ) 
      verts[i]= E_vertex(edge,i) ;
    
    verts[2]= vert;
    edges[0]= edge;
    
    /* Create edge from 'verts[1]' to 'verts[2]' if not already there */
    
    e_verts[0]= verts[1];
    e_verts[1]= verts[2];
    edges[1] = E_exists(e_verts[0],e_verts[1]) ;
    if ( edges[1] == NULL )
      edges[1] = M_createE(mesh, e_verts[0], e_verts[1], g_entity) ;
    
    /* Create edge from 'verts[0]' to 'verts[2]' if not already there */
    
    e_verts[0]= verts[0];
    e_verts[1]= verts[2];
    edges[2] = E_exists(e_verts[0],e_verts[1]);
    if ( edges[2] == NULL )
      edges[2] = M_createE(mesh, e_verts[0], e_verts[1], g_entity);

    /* Create face 0-1-2 or 0-2-1 if not already there */
    
    if ( dir == 1 ) {
      f_edges[0]= edges[0];
      f_edges[1]= edges[1];
      f_edges[2]= edges[2];
    }
    else if ( dir == 0 ) {
      f_edges[0]= edges[0];
      f_edges[1]= edges[2];
      f_edges[2]= edges[1];
    }
    /* Check if the face exists, if not create the face */
    face = F_exists(Tedge,(pEntity)f_edges[0],(pEntity)f_edges[1],(pEntity)f_edges[2],0);
    if ( !face ) {
      for (i = 0; i < 3; i++) {
	vert1 = E_vertex(f_edges[i],1) ;
	ii = (i+1)%3;
	vert2 = E_vertex(f_edges[ii],0);
	vert3 = E_vertex(f_edges[ii],1);
     if( vert1 != vert2 && vert1 != vert3 )
       f_dirs[i] = 0 ;
     else 
       f_dirs[i] = 1 ;     
      }
      face = M_createF(mesh, 3, f_edges, f_dirs, g_entity);
    }
    else 
      {
	/* Face is exisiting in the database , may be we just need to
	   change the classification of the faces */
	g_entity_1 = F_whatIn(face);
	type_1= GEN_type(g_entity_1);
	if ( type_1 > type ) 
	  {
	    /* It is an interior face whose classification is
	       getting changed */
	    F_setWhatIn(face,g_entity);
	    
	    /*
	      Possibly reverse orientation of face
	    */
	    
	    for ( i= 0 ; i< 3 ; i++ ) 
	      f_edges_2[i]= F_edge(face,i);
	    
	    while ( f_edges_2[0] != f_edges[0] ) 
	      {
		e_temp= f_edges_2[0];
		f_edges_2[0]= f_edges_2[1];
		f_edges_2[1]= f_edges_2[2];
		f_edges_2[2]= e_temp;
	      }
	    if ( f_edges_2[1] != f_edges[1] )
	      F_chDir(face);
	  }
      }
    
    return face ;
  }


  pRegion F_vrtCrtReg(pMesh mesh, pFace face,
		      int dir, /* How the face should be used by region */
		      pVertex vert,
		      pGEntity rg_entity)
  {
    int i,numEdges;
    pEdge edges[6];
    pVertex verts[4], vert1, vert2, vert3;
    pVertex e_verts[2];
    int status;
    pEdge f_edges[3];
    pFace r_faces[4];
    int f_dirs[3], edgeDir[3];
    int r_dirs[4];
    pGEntity g_entity;
    int type;
    int flag;
    pRegion region_2;
    pFace face_2;
    pEdge edge;
    int j;
    pEdge edge_2;
    int dir_2;
    int ind;
    int k,ii;
    int gregion1;
    int gregion2;
    int e_dir;
    int e_dir_2,nedge;
    pPList edgeList ;
    void *temp = 0 ;
    pRegion region ;
    
    /* Get the list of vertices for the face */
    edgeList = F_edges(face,1,NULL) ;
    temp = 0 ;
    k = 0 ;
    while ( edge = (pEdge)PList_next(edgeList,&temp))
      {
	edges[k] = edge ;
	k++ ;
      }
    PList_delete(edgeList) ;
    
    edgesToVerts(edges,verts) ;
    
    verts[3]= vert;
    
    /* Create edge from 'verts[2]' to 'verts[3]' if not already there */
    
    e_verts[0]= verts[2];
    e_verts[1]= verts[3];
    edges[3]  = E_exists(e_verts[0],e_verts[1]);
    if ( !edges[3] )
      edges[3] = M_createE(mesh,e_verts[0],e_verts[1],rg_entity);
    
    /* Create edge from 'verts[0]' to 'verts[3]' if not already there */
    
    e_verts[0]= verts[0];
    e_verts[1]= verts[3];
    edges[4] = E_exists(e_verts[0],e_verts[1]);
    if ( !edges[4] )
      edges[4] = M_createE(mesh,e_verts[0],e_verts[1],rg_entity);
    
    /* Create edge from 'verts[1]' to 'verts[3]' if not already there */
    
    e_verts[0]= verts[1];
    e_verts[1]= verts[3];
    edges[5] = E_exists(e_verts[0],e_verts[1]);
    if ( !edges[5] )
      edges[5] = M_createE(mesh,e_verts[0],e_verts[1],rg_entity);
    
    /*
      / Create face 0-4-5 if not already there
    */
    
    f_edges[0]= edges[0];
    f_edges[1]= edges[4];
    f_edges[2]= edges[5];
    r_faces[0] = F_exists(Tedge,(pEntity)f_edges[0],(pEntity)f_edges[1],(pEntity)f_edges[2],0);
    if ( !r_faces[0] ) {
      for (i = 0; i < 3; i++) {
	vert1 = E_vertex(f_edges[i],1) ;
	ii = (i+1)%3;
	vert2 = E_vertex(f_edges[ii],0);
	vert3 = E_vertex(f_edges[ii],1);
	if( vert1 != vert2 && vert1 != vert3 )
	  f_dirs[i] = 0 ;
	else 
	  f_dirs[i] = 1 ;     
      }
      r_faces[0] = M_createF(mesh, 3, f_edges, f_dirs, rg_entity);
    }
    
    /*
      / Create face 1-3-5 if not already there
    */
    
    f_edges[0]= edges[1];
    f_edges[1]= edges[3];
    f_edges[2]= edges[5];
    r_faces[1] = F_exists(Tedge,(pEntity)f_edges[0],(pEntity)f_edges[1],(pEntity)f_edges[2],0);
    if ( !r_faces[1] ) {
      for (i = 0; i < 3; i++) {
	vert1 = E_vertex(f_edges[i],1) ;
	ii = (i+1)%3;
	vert2 = E_vertex(f_edges[ii],0);
	vert3 = E_vertex(f_edges[ii],1);
	if( vert1 != vert2 && vert1 != vert3 )
	  f_dirs[i] = 0 ;
	else 
	  f_dirs[i] = 1 ;     
      }
      r_faces[1] = M_createF(mesh, 3, f_edges, f_dirs, rg_entity);
    }
    
    
    /*
      / Create face 2-3-4 if not already there
    */
    
    f_edges[0]= edges[2];
    f_edges[1]= edges[3];
    f_edges[2]= edges[4];
    r_faces[2] = F_exists(Tedge,(pEntity)f_edges[0],(pEntity)f_edges[1],(pEntity)f_edges[2],0);
    if ( !r_faces[2] ) {
      for (i = 0; i < 3; i++) {
	vert1 = E_vertex(f_edges[i],1) ;
	ii = (i+1)%3;
	vert2 = E_vertex(f_edges[ii],0);
	vert3 = E_vertex(f_edges[ii],1);
	if( vert1 != vert2 && vert1 != vert3 )
	  f_dirs[i] = 0 ;
	else 
	  f_dirs[i] = 1 ;     
      }
      r_faces[2] = M_createF(mesh, 3, f_edges, f_dirs, rg_entity);
    }
    
    r_faces[3] = face;
    r_dirs[3]  = dir;
    
    /*
      it is easy to tell how the other faces are used
      by to-be created pmesh region, if we know the direction
      of one if the face, if we consider the tet as a manifold
      solid, then for the two faces sharing an edge,
      if both the edges use the edge in the same direction then
      the direction in which the region should be used is different
      else it is the same
    */
    
    /* Collect the three edges of the face */
    numEdges = F_numEdges(face) ;
    
    for ( i = 0 ; i < numEdges ; i++ )
      {
	edges[i] = F_edge(face,i) ;
	edgeDir[i] = F_edgeDir(face,i) ;
      }
    
    for ( i= 0 ; i< 3 ; i++ ) 
      {
	/*       
		 Get the edge common to 'face'
		 and r_faces[i]
		 Compare how the common edge is used
		 by 'face' and 'r_faces[i]'
	*/       
	
	flag= 0; 
	for ( j = 0 ; j< 3 ; j++ ) 
	  {
	    edge = edges[j] ;
	    for ( k = 0 ; k< 3 ; k++ ) {
	      edge_2 = F_edge(r_faces[i],k);
	      if ( edge_2 == edge ) {
		e_dir = edgeDir[j];
		e_dir_2 = F_edgeDir(r_faces[i],k);
		flag= 1;
		break;
	      }  
	    }     
	    if ( flag == 1 ) break;
	  }        
	
	if ( e_dir_2 == e_dir )
	  r_dirs[i] = 1 - dir ;
	else   
	  r_dirs[i]= dir;
      }
    
    /* Create region */
    region = M_createR(mesh, 4, r_faces, r_dirs, rg_entity);
  
    return region ;
  }


  /* Given 3 edges (that would form a face),
     return the 3 corresponding vertices in same order
     as the 3 edges
  */
  void edgesToVerts(pEdge edges[3], pVertex verts[3])
  {
    int i;
    int j;
    pVertex e_verts[3][2];
    
    /*
      / verts[0..2] have same orientation as edges[0..2]
      / verts[0] connects edges[0] and edges[2]
    */
    
    for ( i= 0 ; i< 3 ; i++ ) {
      for ( j= 0 ; j< 2 ; j++ ) {
	e_verts[i][j]= E_vertex(edges[i],j);
      }
    }
    
    verts[0]= e_verts[0][0];
    
    if ( e_verts[2][0] != verts[0] && e_verts[2][1] != verts[0] ) {
      verts[0]= e_verts[0][1];
    }
    
    if ( e_verts[2][0] == verts[0] ) {
      verts[2]= e_verts[2][1];
    }
    else {
      verts[2]= e_verts[2][0];
    }
    
    if ( e_verts[1][0] == verts[2] ) {
      verts[1]= e_verts[1][1];
    }
    else {
      verts[1]= e_verts[1][0];
    }
    
  }


  void BL_addRegsIntoBLs(vector<pRegion> &newRegs, int iLvl)
  {
    pFace pFaceFace;
    pRegion pRegionRgn;
    pBLayer pBLayerBL;
    int iFaceTypeInBL;

    for (int iRgn = 0; iRgn < newRegs.size(); ++iRgn)
    {
      pRegionRgn = newRegs[iRgn];
      for (int iFace = 0; iFace < R_numFaces(pRegionRgn); ++iFace)
      {
        pFaceFace = R_face(pRegionRgn, iFace);
        iFaceTypeInBL = F_typeInBL(pFaceFace);
        if ((iFaceTypeInBL == fLAYER || iFaceTypeInBL == fTRANSITION) && EN_levelInBL(pFaceFace) == iLvl)
        {
          pBLayerBL = EN_getBL(pFaceFace);
          EG_addEntity(pBLayerBL, (pEntity)pRegionRgn);
          break;
        }
      }
    }
  }


  // Here we have assumed the ordering of mesh entities of prismatic elements 
  int Layer_E_colaps(pMesh mesh, 
		     vector<pEdge>& elist, 
		     pVertex vertd, 
		     pVertex vertr, 
		     CBFunction CB, 
		     void *userData,
		     pPList *newRegs)   // this routine allocate space 
  {

    int linearMode = 1;
    if( CB ) {
      // if call back function is made available we
      // might have to change the instants where old regions are deleted
      // probably need to invoke call back function for each layer edge collapse

      // HACK for cases with linear modes only
      // for linear modes invoke call back function using deleted vertices
      // as no vertex is created

      if(!linearMode) {
        cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
        cout<<"call back function NOT supported as of now"<<endl;
        exit(0);
      }
    }

    int numFaces;
    int listSize = elist.size();
    pEdge interfaceEdge = elist[listSize-1];
    pVertex topVD = E_vertex(interfaceEdge,0);
    if(vertd!=V_getOriginatingNode(topVD))
      topVD = E_vertex(interfaceEdge,1);
    pVertex topVR = E_otherVertex(interfaceEdge,topVD);

    vector<pEdge> edgesAtBLIntfc;
    V_edgesAtBLInterface(topVD, edgesAtBLIntfc);

    vector<pFace> facesAtBLIntfc;
    V_facesAtBLInterface(topVD, facesAtBLIntfc);
    int numFacesAtBLIntfc = facesAtBLIntfc.size();

    int numZeroLvlFcsBLIntfc = 0;
    for(int iFace=0; iFace<numFacesAtBLIntfc; iFace++) {
      pFace intfcFace = facesAtBLIntfc[iFace];
      // do NOT count iterface face at level zero with interfaceEdge
      if( F_whatInType(intfcFace)== 2 &&
	  !F_inClosure(intfcFace,(pEntity)interfaceEdge) )
	numZeroLvlFcsBLIntfc++;
    }

    pEdge edge = elist[0];
    if(E_whatInType(edge)==Gface) {
      int n1 = 0;
      pGEntity gface = E_whatIn(edge);
      if (GF_region((pGFace)gface,0)) n1++;
      if (GF_region((pGFace)gface,1)) n1++;
      if (n1 == 2) {
//	cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
//	cout<<"zero level layer edge classified on non-manifold face"<<endl;
//	exit(0);
      }
    }
    //     else {
    //       cout<<"\nWarning in fromMeshTools::Layer_E_colaps()"<<endl;
    //       cout<<"zero level layer edge NOT classified on model face\n"<<endl;
    //       return 0;
    //     }

    // collapse from higher tot. num. layers to lower tot. num. layers
    int higherToLower = 0;
    int totNumLayers, absMinMax[2], edgeMinMax[2];

    vector<pVertex> vd_GC;
//    vector<pVertex> vd_GCEdges;
    vector<pVertex> vr_GC;
//    vector<pVertex> vr_GCEdges;
    BL_getGrowthCurveNodes(vertd, vd_GC); 
//    BL_getGrowthCurveEdges(vertd, vd_GCEdges);
//    BL_getGCNodesFromGCEdges(vd_GCEdges, vd_GC);
    BL_getGrowthCurveNodes(vertr, vr_GC);
//    BL_getGrowthCurveNodes(vertr, vr_GCEdges);
//    BL_getGCNodesFromGCEdges(vr_GCEdges, vr_GC);
    totNumLayers = vd_GC.size()-1;//V_totNumLayers(vertd);
    absMinMax[0] = totNumLayers; absMinMax[1] = totNumLayers;
    edgeMinMax[0] = totNumLayers; edgeMinMax[1] = totNumLayers;
    totNumLayers = vr_GC.size()-1;//V_totNumLayers(vertr);
    if(totNumLayers<edgeMinMax[0]) {
      higherToLower = 1;
      edgeMinMax[0] = totNumLayers;
    }
    else if(totNumLayers>edgeMinMax[1])
      edgeMinMax[1] = totNumLayers;

    pEdge lyrEdg;
    vector<pEdge> vLyrEdgs;
    V_layerEdges(vertd, vLyrEdgs);
    int numLayerEdges = vLyrEdgs.size();
    for(int iLayerEdge=0; iLayerEdge<numLayerEdges; iLayerEdge++) {
      edge = vLyrEdgs[iLayerEdge];

      /// This is somewhat expensive, look at other alternatives.
      vector<pVertex> otherVtxStack;
      BL_getGrowthCurveNodes(E_otherVertex(edge,vertd), otherVtxStack);

      totNumLayers = otherVtxStack.size()-1;//V_totNumLayers(E_otherVertex(edge,vertd));
      if(totNumLayers<absMinMax[0])
	absMinMax[0] = totNumLayers;
      if(totNumLayers>absMinMax[1])
	absMinMax[1] = totNumLayers;
    }

    int start[4] = {0,absMinMax[0]+1,edgeMinMax[0]+1,edgeMinMax[1]+1};
    int end[4] = {absMinMax[0]+1,edgeMinMax[0]+1,edgeMinMax[1]+1,absMinMax[1]+1};

    *newRegs = PList_new();

    pMeshDataId entPtrID = MD_newMeshDataId("entPtr");
    pMeshDataId extraEntPtrID = MD_newMeshDataId("extraEntPtr");
    // --- lowerEntPtrID
    //     pMeshDataId lowerEntPtrID = MD_newMeshDataId("lowerEntPtr");
    pMeshDataId dirIntID = MD_newMeshDataId("dirInt");

//    pGrowthCurve gcD = V_growthCurve(vertd);
//    pGrowthCurve gcR = V_growthCurve(vertr);
//    pPList nodesD = gcD->getNodesOnGC();
//    pPList nodesR = gcR->getNodesOnGC();

    int level, surfTag, blEntType;
    pFace r_faces[5];
    int r_dirs[5];
    pEdge f_edges[4];
    int f_dirs[4];
    pVertex vertex, e_verts[2];
    pGEntity gent;

    int vdListSize = vd_GC.size();//pList_size(nodesD);
    pVertex curVD, curVR, vertexD, vertexR, vt;
    pEdge curEdge, e[2], cedge, bdryEdge;
    pFace face, f[2], verticalFace[2], bdryFace;
    pRegion region, newRegion;
    int atInterface[2];
    int numEdges, numLyrFcs, numRgns, geDir, dir;
    void *temp;
    pPList eregs, fverts, tmpList, zeroLevelCavityNodes = PList_new();
    vector <pVertex> vregs;
    vector<pEdge> lyrFcs, lyrEdges;
    vector<pRegion> eNonBLRegs;

    /// Calculate new initial BLs number and figure out BLs to be deleted
    V_BLRegions(vertd,1,vregs);
    int num_vd_regs = vregs.size();
//    int num_ed_regs = E_numRegions(elist[0]);
    int num_new_BLs; 

    pBLayer *old_BLs = new pBLayer[num_vd_regs];

    /// Get the cavity BLs to be able to remove later
    for (int iReg = 0; iReg < num_vd_regs; ++iReg)
    {
      region = vregs[iReg];
      old_BLs[iReg] = EN_getBL(region);
      EG_clear(old_BLs[iReg]);
    }

    int numModes = 4;
    // it is possible that intermediate modes are OFF
    for(int iMode=0; iMode<numModes; iMode++) {
      // loop over edges in "elist"
      for(int iList=start[iMode]; iList<end[iMode]; iList++) {

	if(iList<vdListSize)
	  curVD = vd_GC[iList];

	if(iList<listSize)
	  curEdge = elist[iList];

	curVR = E_otherVertex(curEdge,curVD);
      
	geDir = 0;
	// only first two modes will have growth edges merged
	if(iList<end[1]-1) {
	  e[0] = V_growthEdge(curVD,1);
	  e[1] = V_growthEdge(curVR,1);	
	  for(int iVert=0; iVert<2; iVert++) {
	    if( E_vertex(e[0],iVert)==curVD &&
		E_vertex(e[1],iVert)==curVR ) {
	      geDir = 1;
	      break;
	    }
	  }
	
	  EN_attachDataInt((pEntity)e[0],dirIntID,geDir);
	  EN_attachDataPtr((pEntity)e[0],entPtrID,(void *)e[1]);
	}

	// figure out the layer and transition edges to be merged
	E_layerAndTransitionFaces(curEdge,iList,lyrFcs);
	numLyrFcs = lyrFcs.size();
	for(int iFace=0; iFace<numLyrFcs; iFace++) {
	  atInterface[0] = 1; atInterface[1] = 1;
	  face = lyrFcs[iFace];
	  numEdges = F_numEdges(face);
	  for(int iEdge=0; iEdge<numEdges; iEdge++) {
	    edge = F_edge(face,iEdge);
	    if(edge!=curEdge) {
	      if(E_inClosure(edge,(pEntity)curVD)) {
		e[0] = edge; /*edge that will be deleted*/
		if(!E_atBLInterface(e[0])) {
		  atInterface[0] = 0;
		  verticalFace[0] = E_verticalFace(e[0],1);
		}
	      }
	      else {
		e[1] = edge; /*edge that will replace deleted edge*/
		if(!E_atBLInterface(e[1])) {
		  atInterface[1] = 0;
		  verticalFace[1] = E_verticalFace(e[1],1);
		}
	      }
	    }
	  }

	  int eModifyData = 0;
	  // some conditions might be redundant (like iMode==2, interface[0] etc. )
	  // if(iList==start[2] && EN_levelInBL((pEntity)e[0])<iList)
	  if(iMode==2 && EN_levelInBL((pEntity)e[0])<iList)
	    eModifyData = 1;

	  if(EN_getDataPtr((pEntity)e[0],entPtrID,(void **)&temp)) {
	    EN_modifyDataPtr((pEntity)e[0],entPtrID,(void *)e[1]);
	    if(!eModifyData) {
	      cout<<"Layer_E_colaps() - ERROR - data already attached with entPtrID to e[0] "<<endl;
	      exit(0);
	    }
	  }
	  else
	    EN_attachDataPtr((pEntity)e[0],entPtrID,(void *)e[1]);

	  if(!atInterface[0] && !atInterface[1])
	    EN_attachDataPtr((pEntity)verticalFace[0],entPtrID,(void *)verticalFace[1]);

	  if(E_whatInType(e[0]) < E_whatInType(e[1])) {
	    if(!iList)
	      E_setWhatIn(e[1],E_whatIn(e[0]));
#ifdef DEBUG
	    else {
	      // e[0] must be zero level layer edge and e[1] must not be at zero level
	      if(EN_levelInBL((pEntity)e[0]) || !EN_levelInBL((pEntity)e[1])) {
		cout<<"Layer_E_colaps() - ERROR - classification error with e[0] and e[1]"<<endl;
		exit(0);
	      }
	    }
#endif
	  }

	  int eDir;
	  if( E_vertex(e[0],0)==E_vertex(e[1],0) ||
	      E_vertex(e[0],1)==E_vertex(e[1],1) )
	    eDir = 1;
	  else
	    eDir = 0;

	  if(EN_getDataInt((pEntity)e[0],dirIntID,&dir)) {
	    EN_modifyDataInt((pEntity)e[0],dirIntID,eDir);
	    if(!eModifyData) {
	      cout<<"Layer_E_colaps() - ERROR - data already attached with dirIntID to e[0] "<<endl;
	      exit(0);
	    }
	  }
	  else
	    EN_attachDataInt((pEntity)e[0],dirIntID,eDir);
	  
	  if(!atInterface[0] && !atInterface[1]) {
	    // it can happen that the other end of an edge which is not at BL interface do not have an upward growth curve
	    // growth edge was used to determine the face usage
	    // 	    edge = V_growthEdge(E_otherVertex(e[0],curVD),1);
	    // edge = V_growthEdge(E_otherVertex(e[1],curVR),1);
	    if(F_whatInType(verticalFace[0]) < F_whatInType(verticalFace[1])) {
	      // use the normal and classification of verticalFace[0]
	      F_setWhatIn(verticalFace[1],F_whatIn(verticalFace[0]));
	      // 	      if(F_dirUsingEdge(verticalFace[1],edge)!=F_dirUsingEdge(verticalFace[0],edge))
	      // 		F_chDir(verticalFace[1]);
	      if(eDir) {
		if(F_dirUsingEdge(verticalFace[1],e[1])!=F_dirUsingEdge(verticalFace[0],e[0]))
		  F_chDir(verticalFace[1]);
	      }
	      else {
		if(F_dirUsingEdge(verticalFace[1],e[1])==F_dirUsingEdge(verticalFace[0],e[0]))
		  F_chDir(verticalFace[1]);
	      }
	    }
	    else {
	      // use the normal and classification of verticalFace[1]
	      // 	      if(F_dirUsingEdge(verticalFace[1],edge)==F_dirUsingEdge(verticalFace[0],edge))
	      // 		EN_attachDataInt((pEntity)verticalFace[0],dirIntID,1);
	      // 	      else
	      // 		EN_attachDataInt((pEntity)verticalFace[0],dirIntID,0);
	      if(eDir) {
		if(F_dirUsingEdge(verticalFace[1],e[1])==F_dirUsingEdge(verticalFace[0],e[0]))
		  EN_attachDataInt((pEntity)verticalFace[0],dirIntID,1);
		else
		  EN_attachDataInt((pEntity)verticalFace[0],dirIntID,0);
	      }
	      else {
		if(F_dirUsingEdge(verticalFace[1],e[1])!=F_dirUsingEdge(verticalFace[0],e[0]))
		  EN_attachDataInt((pEntity)verticalFace[0],dirIntID,1);
		else
		  EN_attachDataInt((pEntity)verticalFace[0],dirIntID,0);
	      }
	    }
	  }
	} // loop over layer and transition faces ends

	// this condition could be possible in first mode itself
	if(iList==edgeMinMax[1]) // if(iList==end[numModes-1]-1)
        {
	  // merge info. at BL interface is attached before
	  // collapsing the top most layer or transition edge (i.e., at BL interface)
	  // this is done in case layer or transition edge is being merged
	  // ----
	  // figure out faces to be merged

	  E_nonBLRegions(interfaceEdge, eNonBLRegs);

	  void *temp1 = 0;
	  void *temp2 = 0;
          for (int iReg = 0; iReg < eNonBLRegs.size(); ++iReg)
          {
            region = eNonBLRegs[iReg];
//	  while (region = (pRegion)PList_next(eNonBLRegs,&temp1)) {
            // R_faces() may not provide correct info. (which seems dangerous) in case of 
            // higherToLower when merging takes place in last iteration of second mode
            // (i.e., iList=end[1]-1 and iMode==1)
            // probably due to intr. vol tet(s). with all BL nodes
	    // tmpList = R_faces(region,1);
            int numRFaces = R_numFaces(region);
	    temp2 = 0;
	    // while (face = (pFace)PList_next(tmpList, &temp2)) {
            for(int iFace=0; iFace<numRFaces; iFace++) {
              face = R_face(region,iFace);
	      if (!F_inClosure(face,(pEntity)curEdge))
		if (F_inClosure(face,(pEntity)curVD))
		  f[0] = face;  /* face that will be deleted */
		else
		  f[1] = face;  /* face that will replace deleted face */
	    // }
            }
	    // PList_delete(tmpList);

	    int fModifyData = 1;
	    if(EN_getDataPtr((pEntity)f[0],entPtrID,&temp)) {
	      // do NOT modify the data as the old data attached will be
	      // useful in coverting interface faces into transition tets.
	      // the face which replaces this f[0] is found by F_exists
	      // data on f[0] is modified later in case of "bdryEdge" while
	      // converting interface faces into transition tets.
	      // note data in this case might not be useful as this 
	      // face would not be used to form any non-BL region
	      // transfer BL info onto f[1] from f[0] based on iMode

              // in case of higherToLower data should match
              // as it might have got attached in last iteration of second mode 
              // (iList==end[1]-1 and iMode==1)
              // when merge takes place
              // probably due to intr. vol. tet(s). with all BL nodes
              if(higherToLower && temp!=f[1]) {
		cout<<"Layer_E_colaps() - attach face data to f[0] do NOT match for higherToLower="<<higherToLower<<""<<endl;
                exit(0); 
              }

	      // EN_modifyDataPtr((pEntity)f[0],entPtrID,f[1]);

	      fModifyData = 0;

	      // face at BL interface can have old data attached to it
	      // probably region has all BL nodes
//	      if(!PList_inList(facesAtBLIntfc,(void *)f[0])) {
              if (std::find(facesAtBLIntfc.begin(), facesAtBLIntfc.end(), f[0]) == facesAtBLIntfc.end())
              {
		cout<<"Layer_E_colaps() - error in attach data to f[0] "<<endl;
		exit(0);
	      }
	    }
	    else
	      EN_attachDataPtr((pEntity)f[0],entPtrID,f[1]);
	  
	    edge=F_vtOpEd(f[0],curVD);
	    if(F_typeInBL(f[0])) {
              // in case of higherToLower, f[1] might already be labeled
	      if(!higherToLower && F_typeInBL(f[1])) {
		cout<<"Layer_E_colaps() - faces, f[0] and f[1], of non-BL region are BL entity"<<endl;
		exit(0);
	      }

	      // from f[0] to f[1]
	      if(!F_typeInBL(f[1])) {
	        EN_mergeBLInfo((pEntity)f[1],(pEntity)f[0]);
	        if(iMode>=2)
		  F_correctTypeAndLevelInBL(f[1]);
	        // use normal/direction of BL face
	        if( F_dirUsingEdge(f[1],edge)!=F_dirUsingEdge(f[0],edge) )
		  F_chDir(f[1]);
              }
	    }

	    if( F_whatInType(f[0]) < F_whatInType(f[1]) )
	      // should use the normal and classification of f[0]
	      {
		int changeCls = 1;
		if(F_typeInBL(f[0]) && EN_levelInBL((pEntity)f[0])==0) {
		  changeCls = fModifyData;
#ifdef DEBUG
//		  if(!PList_inList(facesAtBLIntfc,(void *)f[0])) {
                  if (std::find(facesAtBLIntfc.begin(), facesAtBLIntfc.end(), f[0]) == facesAtBLIntfc.end())
                  {
		    cout<<"Layer_E_colaps() - zero level BL face of non-BL region NOT at BL interface"<<endl;
		    exit(0);
		  }
#endif
		}

		if(changeCls) {
		  int chDir=0;  
		  F_setWhatIn(f[1],F_whatIn(f[0]));
		  if( F_dirUsingEdge(f[1],edge)!=F_dirUsingEdge(f[0],edge) ) {
		    F_chDir(f[1]);
		    chDir=1;
		  }
#ifdef MA_PARALLEL
                  sendReclassifiedEntity(mesh,(pEntity)f[1],chDir);
#endif
		}
	      }
	    else
	      // use the normal and classification of f[1]
	      {
		int fDir;
		if( F_dirUsingEdge(f[1],edge)==F_dirUsingEdge(f[0],edge) ) 
		  fDir = 1;
		else
		  fDir = 0;

		if(EN_getDataInt((pEntity)f[0],dirIntID,&dir)) {
                  if(higherToLower and dir!=fDir) {
                    cout<<"Layer_E_colaps() - attach dir. data to f[0] do NOT match for higherToLower="<<higherToLower<<""<<endl;
                    exit(0);
                  }
		  if(fModifyData)
		    EN_modifyDataInt((pEntity)f[0],dirIntID,fDir);
                }
		else
		  EN_attachDataInt((pEntity)f[0],dirIntID,fDir);
	      }
	  }

	  // figure out edges to be merged
	  pPList efaces = E_faces(curEdge);
	  temp1 = 0;
	  while (face = (pFace)PList_next(efaces, &temp1)) {
	    // merge info. for BL faces have been already taken care of
	    if(!F_typeInBL(face)) {
	      tmpList = F_edges(face,1,0);
	      temp2 = 0;
	      e[0]=0; e[1]=0;
	      while (edge = (pEdge)PList_next(tmpList,&temp2)) {
		if (edge != curEdge)
		  if (E_inClosure(edge,(pEntity)curVD))
		    e[0] = edge;  /* edge that will be deleted */
		  else
		    e[1] = edge;  /* edge that will replace deleted edge */
	      }	
	      PList_delete(tmpList);
	  
	      if(e[0] && e[1]) {
                int eNoData = 1;
		if(EN_getDataPtr((pEntity)e[0],entPtrID,&temp2)) {
		  // data in case of edge must be modified as old data
		  // is not really useful to form new faces 
		  // while converting interface faces to transition tets.
		  // transfer BL info onto e[1] from e[0] based on iMode

                  // in case of higherToLower data should match
                  // as it might have got attached in last iteration of second mode
                  // (iList==end[1]-1 and iMode==1)
                  // when merge takes place
                  // probably due to intr. vol. tet(s). with all BL nodes
                  if(higherToLower && temp2!=e[1]) {
                    cout<<"Layer_E_colaps() - attach edge data to e[0] do NOT match for higherToLower="<<higherToLower<<""<<endl;
                    exit(0);
                  }

                  eNoData = 0;
		  EN_modifyDataPtr((pEntity)e[0],entPtrID,e[1]);
//		  if(!PList_inList(edgesAtBLIntfc,(void *)e[0])) {
                  if (std::find(edgesAtBLIntfc.begin(), edgesAtBLIntfc.end(), e[0]) == edgesAtBLIntfc.end())
                  {
		    cout<<"Layer_E_colaps() - error in attach data ptr to e[0] "<<endl;
		    exit(0);
		  }
		}
		else
		  EN_attachDataPtr((pEntity)e[0],entPtrID,e[1]);
	      
		if(E_typeInBL(e[0])) {
                  // in case of higherToLower, e[1] might already be labeled
		  if(!higherToLower && E_typeInBL(e[1])) {
		    cout<<"Layer_E_colaps() - edges, e[0] and e[1], of non-BL face are BL entity"<<endl;
		    cout<<endl;
		    exit(0);
		  }

		  // from e[0] to e[1]
                  if(!E_typeInBL(e[1])) {
		    EN_mergeBLInfo((pEntity)e[1],(pEntity)e[0]);
		    if(iMode>=2)
		      E_correctTypeAndLevelInBL(e[1]);
                  }
		}
	      
		if( E_whatInType(e[0]) < E_whatInType(e[1]) ) {
		  int changeCls = 1;
		  if(E_typeInBL(e[0]) && EN_levelInBL((pEntity)e[0])==0) {
		    changeCls = eNoData;
#ifdef DEBUG
//		    if(!PList_inList(edgesAtBLIntfc,(void *)e[0])) {
                    if (std::find(edgesAtBLIntfc.begin(), edgesAtBLIntfc.end(), e[0]) == edgesAtBLIntfc.end())
                    {
		      cout<<"Layer_E_colaps() - zero level BL edge of non-BL face NOT at BL interface"<<endl;
		      exit(0);
		    }
#endif
		  }

		  if(changeCls)
                  {
#ifdef MA_PARALLEL
                    sendReclassifiedEntity(mesh,(pEntity)e[1],0);
#endif
		    E_setWhatIn(e[1],E_whatIn(e[0]));
                  }
		}

                int dirData;
                if( E_vertex(e[0],0)==E_vertex(e[1],0) ||
                    E_vertex(e[0],1)==E_vertex(e[1],1) )
                  dirData = 1;
                else
                  dirData = 0;

		if(EN_getDataInt((pEdge)e[0],dirIntID,&dir)) {
                  if(!higherToLower) {
		    cout<<"Layer_E_colaps() - error in attach data int to e[0] "<<endl;
		    exit(0);
                  }
                  else if(dir!=dirData) {
                    cout<<"Layer_E_colaps() - attach dir. data to e[0] do NOT match for higherToLower="<<higherToLower<<""<<endl;
		    exit(0);
                  }
		}
                else
		  EN_attachDataInt((pEntity)e[0],dirIntID,dirData);
	      }
	    }
	  }
	  PList_delete(efaces);
	}

	if(iMode<2) {
	  // if one (or both) end node of edgeDel has zero tot. num. of layers
	  // this may serve as lower face or zero level face at BL interface in iMode 2 and/or 3
	  if(!edgeMinMax[0]) {
#ifdef DEBUG
	    // this will happen only when iList==0
	    if(iList) {
	      cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
	      cout<<"iList="<<iList<<" when one (or both) end node of edgeDel has zero tot. num. of layers\n"<<endl;
	      exit(0);
	    }
#endif

	    // zero level BL faces
	    V_layerFaces(vertd,lyrFcs);
	    numLyrFcs = lyrFcs.size();
	    for(int iFace=0; iFace<numLyrFcs; iFace++) {
	      face = lyrFcs[iFace];

	      if(F_inClosure(face,(pEntity)curEdge) ||
                 EN_getDataPtr((pEntity)face,entPtrID,(void **)&temp))
		continue;

	      bdryEdge = F_vtOpEd(face,vertd);
	      numEdges = F_numEdges(face);
	      for(int iEdge=0; iEdge<numEdges; iEdge++) {
		edge = F_edge(face,iEdge);
		f_dirs[iEdge] = F_dirUsingEdge(face,edge);
		if (edge==bdryEdge) {
		  f_edges[iEdge] = edge;
		  continue;
		}
		
		if(EN_getDataInt((pEntity)edge,dirIntID,&dir) && !dir)
		  f_dirs[iEdge] = !f_dirs[iEdge];
		if(EN_getDataPtr((pEntity)edge,entPtrID,(void **)&temp))
		  f_edges[iEdge] = (pEdge)temp;
		else {
		  
		  for(int iVert=0; iVert<2; iVert++) {
		    vt = E_vertex(edge,iVert);
		    if(vt==vertd)
		      e_verts[iVert] = vertr;
		    else
		      e_verts[iVert] = vt;
		  }

		  gent = E_whatIn(edge);
		  f_edges[iEdge] = M_createE(mesh,e_verts[0],e_verts[1],gent);

		  // must ze zero
		  level = EN_levelInBL((pEntity)edge);
//		  surfTag = EN_blSurfaceTag((pEntity)edge);
		  // must be eLAYER
		  blEntType = E_typeInBL(edge);
		  EN_labelBLEntity((pEntity)f_edges[iEdge],level,blEntType);

		  EN_attachDataPtr((pEntity)edge,entPtrID,f_edges[iEdge]);
		}
	      }

	      gent = F_whatIn(face);
	      pFace newFace = M_createF(mesh,numEdges,f_edges,f_dirs,gent);
	      
	      level = EN_levelInBL((pEntity)face);
//	      surfTag = EN_blSurfaceTag((pEntity)face);
	      blEntType = F_typeInBL(face);
	      EN_labelBLEntity((pEntity)newFace,level,blEntType);

	      EN_attachDataPtr((pEntity)face,entPtrID,newFace);

	      // collect zero level cavity nodes with the help of "bdryEdge"
	      if(!higherToLower && numZeroLvlFcsBLIntfc && edgeMinMax[1]) {
		for(int iVert=0; iVert<2; iVert++) {
		  vertex = E_vertex(bdryEdge,iVert);
		  PList_appUnique(zeroLevelCavityNodes,(void *)vertex);
		}
	      }
	    }
	  }

	  if(!iList) {
	    // nodesD and nodesR would be still valid as they are new copy
//	    v_deleteBLData(vertd);
	  }
	  else {
	    // get lower vertd and layer or transition edge
	    vertexD = vd_GC[iList-1];//(pVertex)PList_item(nodesD,iList-1);
	    vertexR = vr_GC[iList-1];//(pVertex)PList_item(nodesR,iList-1);
	    cedge = elist[iList-1];

	    // vregs = V_regions(vertexD); // --- this should also work for 1st and 2nd mode
	    V_BLRegions(vertexD,iList,vregs);
	    numRgns = vregs.size();
	    eregs = E_regions(cedge);
            vector<pRegion> newRegions;
	    for(int iRgn=0; iRgn<numRgns; iRgn++) {
	      region = vregs[iRgn];

	      if(PList_inList(eregs,(pEntity)region))
		continue;

	      int rTopoType = region->getType();
	      int foundLowerFace = 0;
	      // get lower level layer or transition face (triangular face)
	      numFaces = R_numFaces(region);
	      for(int iFace=0; iFace<numFaces; iFace++) {
		face = R_face(region,iFace);
		// "iList" is the level of the BL region
		if(EN_levelInBL((pEntity)face)<iList) {
		  foundLowerFace = 1;
		  break;
		}
	      }

	      if(!foundLowerFace) {
		cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		cout<<"lower level layer or transition face NOT found"<<endl;
		exit(0);
	      }

	      if(F_numEdges(face)!=3) {
		cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		cout<<"lower level layer or transition face is NOT a triangular face"<<endl;
		exit(0);
	      }

	      bdryEdge = F_vtOpEd(face,vertexD);
	      // for 1st and 2nd mode transition tet. will not have bdryFace
	      if(rTopoType!=TET) {
		bdryFace = E_verticalFace(bdryEdge,1);
		// bdryFace = E_otherFace(bdryEdge,face,region);
	      }
	      else
		bdryFace = 0;

	      numFaces = R_numFaces(region);
	      for(int iFace=0; iFace<numFaces; iFace++) {
		face = R_face(region,iFace);
		r_dirs[iFace] = R_dirUsingFace(region,face);
		// vertical bdry. face NOT to be touched
		if(face==bdryFace) {
		  r_faces[iFace] = face;
		  continue;
		}

		if(EN_getDataInt((pEntity)face,dirIntID,&dir) && !dir)
		  r_dirs[iFace] = !r_dirs[iFace];
		if(EN_getDataPtr((pEntity)face,entPtrID,(void **)&temp))
		  r_faces[iFace] = (pFace)temp;
		else {
		  numEdges = F_numEdges(face);
		  for(int iEdge=0; iEdge<numEdges; iEdge++) {
		    edge = F_edge(face,iEdge);
		    f_dirs[iEdge] = F_dirUsingEdge(face,edge);
		    if( bdryFace && F_inClosure(bdryFace,(pEntity)edge) ||
			edge==bdryEdge ) {
		      f_edges[iEdge] = edge;
		      continue;
		    }
		
		    if(EN_getDataInt((pEntity)edge,dirIntID,&dir) && !dir)
		      f_dirs[iEdge] = !f_dirs[iEdge];

		    if(EN_getDataPtr((pEntity)edge,entPtrID,(void **)&temp))
		      f_edges[iEdge] = (pEdge)temp;
		    else {
		  
		      for(int iVert=0; iVert<2; iVert++) {
			vt = E_vertex(edge,iVert);
			if(vt==vertexD)
			  e_verts[iVert] = vertexR;
			else if(vt==curVD)
			  e_verts[iVert] = curVR;
			else
			  e_verts[iVert] = vt;
		      }

                      // consider last iteration for iMode==1 in case when higherToLower is true
                      // i.e., when iList==end[1]-1 or iList==edgeMinMax[0]
                      // in this case the edge might exist probably when
                      // intr. vol. tet(s). have all BL nodes
                      // in this case the edge would merge on to interior edge but the
                      // data is not yet attached and is difficult to do so 
                      // by using eNonBLRegs for interfaceEdge 
                      // as top node may be at a much higher level 
                      // (difficult to pass the info. on levels much lower than 1)
                      f_edges[iEdge] = 0;
                      if(higherToLower && iList==end[1]-1  && iMode==1)
                        f_edges[iEdge] = E_exists(e_verts[0],e_verts[1]);
                      if(f_edges[iEdge]) {
                        // must be interior edge
                        if(E_typeInBL(f_edges[iEdge])) {
                          cout<<"\nError in Layer_E_colaps()..."<<endl;
                          cout<<"for last iteration for second mode [iMode=1] and higherToLower, existing edge is a BL edge\n"<<endl;
                          exit(0);
                        }
                        int dirData = 1;
                        if(E_vertex(f_edges[iEdge],0)!=e_verts[0]) {
                          dirData = 0;
		          f_dirs[iEdge] = !f_dirs[iEdge];
                        }
                        if(EN_getDataInt((pEntity)edge,dirIntID,&dir)) {
                          cout<<"\nError in Layer_E_colaps()..."<<endl;
                          cout<<"for last iteration for second mode [iMode=1] and higherToLower, dir. data already attached to edge\n"<<endl;
                          exit(0);
                        }
                        // attach dir. data (ent. data with entPtrID is done later)
                        EN_attachDataInt((pEntity)edge,dirIntID,dirData);
                      }
                      else {
    		        gent = E_whatIn(edge);
		        f_edges[iEdge] = M_createE(mesh,e_verts[0],e_verts[1],gent);
                      }

		      level = EN_levelInBL((pEntity)edge);
//		      surfTag = EN_blSurfaceTag((pEntity)edge);
		      // must be eLAYER or eTRANSITION
		      blEntType = E_typeInBL(edge);
		      EN_labelBLEntity((pEntity)f_edges[iEdge],level,blEntType);

		      EN_attachDataPtr((pEntity)edge,entPtrID,f_edges[iEdge]);
		    } // edge inside cavity
		  } // loop over edges of particular face of a prism

                  // consider last iteration for iMode==1 in case when higherToLower is true
                  // i.e., when iList==end[1]-1 or iList==edgeMinMax[0]
                  // in this case the face might exist probably when
                  // intr. vol. tet(s). have all BL nodes
                  // in this case the face would merge on to interior face but the
                  // data is not yet attached and is difficult to do so
                  // by using eNonBLRegs for interfaceEdge
                  // as top node may be at a much higher level
                  // (difficult to pass the info. on levels much lower than 1)
                  // also must be tri. face

                  // in this process a region around face will be updated based on r_dirs[iFace]
                  // R_faces() for that region may not provide correct info. 
                  // (which seems dangerous) in case of higherToLower
                  // when merging takes place in last iteration of second mode
                  // (i.e., iList=end[1]-1 and iMode==1)
                  // probably due to intr. vol tet(s). with all BL nodes
                  r_faces[iFace] = 0;
                  if(higherToLower && iList==end[1]-1 && iMode==1 && numEdges==3)
                    r_faces[iFace] = F_exists(Tedge,f_edges[0],f_edges[1],f_edges[2],0);
                  if(r_faces[iFace]) {
                    // must be interior face
                    if(F_typeInBL(r_faces[iFace])) {
                      cout<<"\nError in Layer_E_colaps()..."<<endl;
                      cout<<"for last iteration for second mode [iMode=1] and higherToLower, existing face is a BL face\n"<<endl;
                      exit(0);
                    }
                    if(EN_levelInBL((pEntity)face)<EN_levelInBL((pEntity)region)) {
                      cout<<"\nError in Layer_E_colaps()..."<<endl;
                      cout<<"for last iteration for second mode [iMode=1] and higherToLower, face exists for region face other than upper face\n"<<endl;
                      exit(0);
                    }
                    int dirData = 1;
                    // if both faces use bdryEdge in same direction then region will use the faces in same direction
                   // face is really lower face using bdryEdge
                    if(F_dirUsingEdge(r_faces[iFace],bdryEdge)!=F_dirUsingEdge(face,bdryEdge)) {
                      dirData = 0;
                      r_dirs[iFace] = !r_dirs[iFace];
                    }
                    if(EN_getDataInt((pEntity)face,dirIntID,&dir)) {
                       cout<<"\nError in Layer_E_colaps()..."<<endl;
                       cout<<"for last iteration for second mode [iMode=1] and higherToLower, dir. data already attached to face\n"<<endl;
                        exit(0);
                     }
                    // attach dir. data (ent. data with entPtrID is done later)
                    EN_attachDataInt((pEntity)face,dirIntID,dirData);
                  }
                  else {
		    gent = F_whatIn(face);
		    r_faces[iFace] = M_createF(mesh,numEdges,f_edges,f_dirs,gent);
                  }

		  level = EN_levelInBL((pEntity)face);
//		  surfTag = EN_blSurfaceTag((pEntity)face);
		  blEntType = F_typeInBL(face);
		  EN_labelBLEntity((pEntity)r_faces[iFace],level,blEntType);

		  EN_attachDataPtr((pEntity)face,entPtrID,r_faces[iFace]);
		} // face inside cavity
	      } // loop over faces of region

	      gent = (pGEntity)R_whatIn(region);
	      newRegion = M_createR(mesh,numFaces,r_faces,r_dirs,gent);
	      PList_append(*newRegs,(void *)newRegion);
              newRegions.push_back(newRegion);

	      level = EN_levelInBL((pEntity)region);
//	      surfTag = EN_blSurfaceTag((pEntity)region);
	      blEntType = R_typeInBL(region);
	      EN_labelBLEntity((pEntity)newRegion,level,blEntType);
	    }
	    PList_delete(eregs);

            /// Put region into its correspondent BL
            if (iList == 1)
            {
              num_new_BLs = newRegions.size();
              pBLayer pBLayerBL;
              for (int iBL = 0; iBL < num_new_BLs; iBL++)
              {
                pBLayerBL = M_createEntGrp(mesh, 3);
                EG_addEntity(pBLayerBL, (pEntity)newRegions[iBL]);
              }
            }
            else
            {
              BL_addRegsIntoBLs(newRegions, iList-1);
            }

	    numRgns = vregs.size();
	    for(int iRgn=0; iRgn<numRgns; iRgn++) {
	      region = vregs[iRgn];
	      EN_unlabelBLEntity((pEntity)region);
	      M_removeRegion(mesh,region);
	    }

	    pPList delFaces = V_faces(vertexD);
	    numFaces = PList_size(delFaces);
	    for(int iFace=0; iFace<numFaces; iFace++) {
	      face = (pFace)PList_item(delFaces,iFace);
	      EN_unlabelBLEntity((pEntity)face);
	      if(EN_getDataInt((pEntity)face,dirIntID,&dir))
		EN_deleteData((pEntity)face,dirIntID);
	      if(EN_getDataPtr((pEntity)face,entPtrID,(void **)&temp))
		EN_deleteData((pEntity)face,entPtrID);
	      M_removeFace(mesh,face);
	    }
	    PList_delete(delFaces);

	    numEdges = V_numEdges(vertexD);
	    pPList delEdges = PList_new();
	    // need to collect all the edges first and then delete them
	    for(int iEdge=0; iEdge<numEdges; iEdge++)
	      PList_append(delEdges,(void *) V_edge(vertexD,iEdge));
	    for(int iEdge=0; iEdge<numEdges; iEdge++) {
	      edge = (pEdge)PList_item(delEdges,iEdge);
	      EN_unlabelBLEntity((pEntity)edge);
	      if(EN_getDataInt((pEntity)edge,dirIntID,&dir))
		EN_deleteData((pEntity)edge,dirIntID);
	      if(EN_getDataPtr((pEntity)edge,entPtrID,(void **)&temp))
		EN_deleteData((pEntity)edge,entPtrID);
	      M_removeEdge(mesh,edge);
	    }
	    PList_delete(delEdges);

            // activate the callback
            // HACK for cases with linear modes only
            pPList oldRegs = PList_new();
            pPList newRegs = PList_new();
            if( CB && linearMode)
              (CB)(oldRegs,newRegs,userData,LECOLAPS,(pEntity)vertexD);
            PList_delete(oldRegs);
            PList_delete(newRegs);

	    EN_unlabelBLEntity((pEntity)vertexD);	
	    M_removeVertex(mesh,vertexD);
	
	    // 	    if(atInterface) {
	    // 	      lyrEdges = V_layerEdges(curVD);
	    // 	      numEdges = PList_size(lyrEdges);
	    // 	      for(int iEdge=0; iEdge<numEdges; iEdge++) {
	    // 		edge = (pEdge)PList_item(lyrEdges,iEdge);
	    // 		if(EN_getDataInt((pEntity)edge,dirIntID,&dir)) {
	    // 		  // only delete for edges to be merged
	    // 		  // for newly created edges it would be used in E_colaps at interface
	    // 		  EN_deleteData((pEdge)edge,dirIntID);
	    // 		  EN_deleteData((pEdge)edge,entPtrID);
	    // 		}
	    // 	      }
	    // 	      PList_delete(lyrEdges);
	    // 	    }
	  } // if (iList) ends
	}
	else { // 3rd and 4th mode
	  // "iList" will be greater than zero for 3rd and 4th modes

	  // get lower vertd and layer or transition edge
	  // "vertexD" and "cedge" would remain the same in the loop otherwise
	  // "vertexD" can be same as "curVD" and "cedge" can be same as "curEdge"
	  if(iList-1<vdListSize)
	    vertexD = vd_GC[iList-1];//(pVertex)PList_item(nodesD,iList-1);
	  if(iList-1<listSize)
	    cedge = elist[iList-1];
	  vertexR = E_otherVertex(cedge,vertexD);

	  V_BLRegions(vertexD,iList,vregs);
	  numRgns = vregs.size();

          vector<pEdge> eBLregs;
	  E_BLRegions(cedge,iList,eBLregs);
          vector<pRegion> newRegions;
	  for(int iRgn=0; iRgn<numRgns; iRgn++) {
	    region = vregs[iRgn];

            if (std::find(eBLregs.begin(), eBLregs.end(), region) != eBLregs.end())
	      continue;

	    pFace lowerFace = 0;
	    // get lower level layer or transition face (triangular face)
	    numFaces = R_numFaces(region);
	    for(int iFace=0; iFace<numFaces; iFace++) {
	      face = R_face(region,iFace);
	      // "iList" is the level of the BL region
	      if(EN_levelInBL((pEntity)face)<iList) {
		lowerFace = face;
		break;
	      }
	    }

	    if(!lowerFace) {
	      cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
	      cout<<"lower level layer or transition face NOT found"<<endl;
	      exit(0);
	    }

	    if(F_numEdges(lowerFace)!=3) {
	      cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
	      cout<<"lower level layer or transition face is NOT a triangular face"<<endl;
	      exit(0);
	    }

	    int rTopoType = region->getType();
	    // if "higherToLower" is 1 then transition tet. is collapsed
	    if(iMode==2 && higherToLower && (rTopoType==TET || rTopoType==PYRAMID)) {
	      if(rTopoType==TET) {
		pPList redges = R_edges(region,1);
		numEdges = PList_size(redges);
		for(int iEdge=0; iEdge<numEdges; iEdge++) {
		  edge = (pEdge)PList_item(redges,iEdge);
//		  if(E_inClosure(edge,(pEntity)vertexD))
//		    PList_appUnique(delEdges,edge);
		}
		PList_delete(redges);

		numFaces = R_numFaces(region);
		for(int iFace=0; iFace<numFaces; iFace++) {
		  face = R_face(region,iFace);
//		  if(F_inClosure(face,(pEntity)vertexD))
//		    PList_appUnique(delFaces,face);
		}
	      
		// transfer data from lowerFace to op. face
		edge = F_vtOpEd(lowerFace,vertexD);
		face = E_otherFace(edge,lowerFace,region);
		if(EN_getDataPtr((pEntity)lowerFace,entPtrID,(void **)&temp)) {
                  pFace tempCheck;
		  if(EN_getDataPtr((pEntity)face,entPtrID,(void **)&tempCheck)) {
                    // face data might be already attached in case of merge 
                    // probably when intr. vol tet(s). have all BL nodes
                    if(temp!=tempCheck) {
    		      cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
                      cout<<"face data on lower and op. face do not match\n"<<endl;
                      exit(0);
                    }
                  }
                  else
		    EN_attachDataPtr((pEntity)face,entPtrID,(void *)temp);

		  int fDir;
		  if(F_dirUsingEdge(lowerFace,edge)==F_dirUsingEdge(face,edge))
		    fDir = 1;
		  else
		    fDir = 0;

                  int dirData;
		  if(!EN_getDataInt((pEntity)lowerFace,dirIntID,&dir))
                    dirData = fDir;
		  else {
		    int mapFDir[2] = {1-dir,dir};
                    dirData = mapFDir[fDir];
		  }
		  if(EN_getDataInt((pEntity)face,dirIntID,&dir)) {
                    // dir. data might be already attached in case of merge 
                    // probably when intr. vol tet(s). have all BL nodes
                    if(dirData!=dir) {
    		      cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
                      cout<<"dir. data on lower and op. face do not match\n"<<endl;
                      exit(0);
                    }
                  }
                  else
		    EN_attachDataInt((pEntity)face,dirIntID,dirData);
		}
		else {
		  cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		  cout<<"data NOT attached to lower face of transition tet. for transfer [higherToLower="<<higherToLower<<"]"<<endl;
		  cout<<endl;
		  exit(0);
		}
	      }

	      // transfer data from lower edge of vertical face to upper edge of vertical face
	      numFaces = R_numFaces(region);
	      for(int iFace=0; iFace<numFaces; iFace++) {
		face = R_face(region,iFace);
		if( F_typeInBL(face)==fVERTICAL_TRI && 
		    F_inClosure(face,(pEntity)vertexD) ) {
		  pEdge lowerEdge, upperEdge;
		  for(int iEdge=0; iEdge<3; iEdge++) {
		    edge = F_edge(face,iEdge);
		    if(E_typeInBL(edge)!=eGROWTH) {
		      if(EN_levelInBL(edge)<iList)
			lowerEdge = edge;
		      else
			upperEdge = edge;
		    }
		  }

		  // if upperEdge is not because of merge
		  // as because if it is due to merge then the useful data has been attached, see E_layerAndTransitionFaces() above
		  if(!EN_getDataInt((pEntity)upperEdge,dirIntID,&dir)) {
		    if(EN_getDataPtr((pEntity)lowerEdge,entPtrID,(void **)&temp)) {
		      EN_attachDataPtr((pEntity)upperEdge,entPtrID,(void *)temp);
		      int eDir;
		      if(E_vertex(lowerEdge,0)==E_vertex(upperEdge,0) || E_vertex(lowerEdge,1)==E_vertex(upperEdge,1))
			eDir = 1;
		      else
			eDir = 0;

                      int dirData;
		      if(!EN_getDataInt((pEntity)lowerEdge,dirIntID,&dir))
                        dirData = eDir;
		      else {
			int mapEDir[2] = {1-dir,dir};
			dirData = mapEDir[eDir];
		      }
                      // no data attached to upperEdge with dirIntID
                      EN_attachDataInt((pEntity)upperEdge,dirIntID,dirData);
		    }
		    else {
		      cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		      cout<<"data NOT attached to lower edge of vertical face of transition tet./pyr. for transfer [higherToLower="<<higherToLower<<"]"<<endl;
		      cout<<endl;
		      exit(0);
		    }
		  }
		}
	      }

	      if(rTopoType==TET)
		continue;
	    }

	    bdryEdge = F_vtOpEd(lowerFace,vertexD);
	    if(!E_atBLInterface(bdryEdge))
	      bdryFace = E_verticalFace(bdryEdge,1);
	    else {
	      // this is possible in 3rd and 4th mode for "higherToLower=1"
	      bdryFace = 0;
	      if(!higherToLower) {
		cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		cout<<"bdry. face must exist [iMode="<<iMode<<",higherToLower="<<higherToLower<<"]"<<endl;
		cout<<endl;
		exit(0);
	      }
	    }
	    
	    // this is not at interface and will be unique for each region
//	    PList_appUnique(delFaces,lowerFace);

	    // clean edges at BL interface of lower face
	    // for first iteration of the 3rd mode, i.e., iMode==2 and iList==start[2]
	    // this data was attached in previous iteration
	    // check that edge is not merging (use dirIntID for this purpose)
	    // if the edge is merging then do not delete data attached to it 
	    // (as in this case the data is attached in this iteration, see E_layerAndTransitionFaces() above)
	    // also if edge has data associated with extraEntPtrID then do not delete data as it is attached in this iteration
	    // (data associated with extraEntPtrID is cleaned in the end of each iteration or level)
	    // lower face must be a triangle (layer or transition face)
	    if(iList==start[2] && iMode==2) {
	      for(int iEdge=0; iEdge<3; iEdge++) {
		edge = F_edge(lowerFace,iEdge);
		int entAtBLInterface = E_atBLInterface(edge);
		if(entAtBLInterface) {
		  // check that edge is not merging (use dirIntID for this purpose)
		  if( !EN_getDataInt((pEntity)edge,dirIntID,&dir) &&
		      !EN_getDataPtr((pEntity)edge,extraEntPtrID,(void **)&temp) &&
		      EN_getDataPtr((pEntity)edge,entPtrID,(void **)&temp) ) {
		    EN_deleteData((pEntity)edge,entPtrID);
		  // --- lowerEntPtrID
		  // 		  // may need this to convert layer or transition face into transition tet.
		  // 		  // in case of 3rd mode and !higherToLower, i.e., "iMode" is 2 and "higherToLower" is 0
		  // 		  EN_attachDataPtr((pEntity)edge,lowerEntPtrID,(void *)temp);
		}
		  // this is not needed for iMode==2 and iList==start[2]
		  // 		if(EN_getDataPtr((pEntity)edge,extraEntPtrID,(void **)&temp))
		  // 		  EN_deleteData((pEntity)edge,extraEntPtrID);
		}
	      }
	    }

	    numFaces = R_numFaces(region);
	    for(int iFace=0; iFace<numFaces; iFace++) {
	      face = R_face(region,iFace);
	      r_dirs[iFace] = R_dirUsingFace(region,face);
	      // vertical bdry. face NOT to be touched
	      if(face==bdryFace) {
		r_faces[iFace] = face;
		continue;
	      }

	      if(EN_getDataInt((pEntity)face,dirIntID,&dir) && !dir)
		r_dirs[iFace] = !r_dirs[iFace];

	      if(EN_getDataPtr((pEntity)face,entPtrID,(void **)&temp))
		r_faces[iFace] = (pFace)temp;
	      else {
		if(lowerFace==face) {
		  cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		  cout<<"lower level layer or transition face of region do NOT have data attached"<<endl;
		  cout<<endl;
		  exit(0);
		}

		numEdges = F_numEdges(face);
		for(int iEdge=0; iEdge<numEdges; iEdge++) {
		  edge = F_edge(face,iEdge);
		  f_dirs[iEdge] = F_dirUsingEdge(face,edge);
		  if( bdryFace && F_inClosure(bdryFace,(pEntity)edge) ||
		      edge==bdryEdge ) {
		    f_edges[iEdge] = edge;
		    continue;
		  }

		  blEntType = E_typeInBL(edge);
		  // any growth edge or layer and transition edge at level "iList-1" in closure of "vertexD"
		  // later we also check if edge (in "delEdges") is at BL interface -- ??
//		  if( (blEntType==eGROWTH || EN_levelInBL((pEntity)edge)!=iList) &&
//		      E_inClosure(edge,(pEntity)vertexD) )
//		    PList_appUnique(delEdges,edge);
		  if( blEntType==eGROWTH && 
		      E_inClosure(edge,(pEntity)vertexD) ) {
		    // can also use V_growthEdge(vertexD,1) when "higherToLower" is 1
		    f_edges[iEdge] = 0;
		    continue;
		  }

		  if(EN_getDataInt((pEntity)edge,dirIntID,&dir) && !dir)
		    f_dirs[iEdge] = !f_dirs[iEdge];
		  if(EN_getDataPtr((pEntity)edge,entPtrID,(void **)&temp))
		    f_edges[iEdge] = (pEdge)temp;
		  else {
		    int ev_levels[2];
		    level = 0;
		    for(int iVert=0; iVert<2; iVert++) {
		      vt = E_vertex(edge,iVert);

		      // 		      if(vt==curVD)
		      // 			e_verts[iVert] = curVR;
		      // 		      else if(vt==vertexD)
		      // 			if(vertexD==curVD)
		      // 			  e_verts[iVert] = curVR;
		      // 			else
		      // 			  e_verts[iVert] = vertexR;

		      // if curVD==vertexD use curVR and if curVD!=vertexD then vertexR==curVR
		      if(vt==curVD || vt==vertexD)
			e_verts[iVert] = curVR;
		      else
			e_verts[iVert] = vt;
		      ev_levels[iVert] = EN_levelInBL((pEntity)e_verts[iVert]);
		      if(level<ev_levels[iVert])
			level = ev_levels[iVert];
		    }

#ifdef DEBUG
		    if(e_verts[0]==e_verts[1]) {
		      cout<<"Layer_E_colaps - Error - e_verts[0]==e_verts[1]"<<endl;
		      exit(0);
		    }
		    if(E_exists(e_verts[0],e_verts[1])) {
		      cout<<"Layer_E_colaps - Error - edge exists between e_verts[0] and e_verts[1]"<<endl;
		      exit(0);
		    }
#endif

		    if(iMode==2 && !higherToLower && (!ev_levels[0] || !ev_levels[1])) {
		      // if "edge" is classified on model edge
		      // use "gent" of the vertical face on cedge 
		      if(E_whatInType(edge)==Gedge)
			gent = F_whatIn(E_verticalFace(cedge,1));
		      else
			gent = F_whatIn(face);
		    }
		    else
		      gent = E_whatIn(edge);
		    f_edges[iEdge] = M_createE(mesh,e_verts[0],e_verts[1],gent);

		    // level = EN_levelInBL((pEntity)edge);
//		    surfTag = EN_blSurfaceTag((pEntity)edge);
		    // must be eLAYER or eTRANSITION
		    // blEntType = E_typeInBL(edge);
		    if(ev_levels[0]==ev_levels[1])
		      blEntType = eLAYER;
		    else
		      blEntType = eTRANSITION;
		    // level is max. of ev_levels
		    // level must be "iList" as "iList-1" would have been processed in the previous iteration
		    EN_labelBLEntity((pEntity)f_edges[iEdge],level,blEntType);

		    EN_attachDataPtr((pEntity)edge,entPtrID,f_edges[iEdge]);
		  } // edge inside cavity
		} // loop over edges of particular face of BL region

		blEntType = F_typeInBL(face);
		if(blEntType==fVERTICAL_TRI || blEntType==fVERTICAL_QUAD) {

//		  PList_appUnique(delFaces,face);

		  level = EN_levelInBL((pEntity)face);

		  int f_dirs_tmp[4];
		  pEdge f_edges_tmp[4];
		  // make a copy
		  for(int iEdge=0; iEdge<numEdges; iEdge++) {
		    f_dirs_tmp[iEdge] = f_dirs[iEdge];
		    f_edges_tmp[iEdge] = f_edges[iEdge];
		  }

		  if(iMode==3) {

#ifdef DEBUG
		    if(numEdges==3 && F_exists(Tedge,f_edges[0],f_edges[1],f_edges[2],0)) {
		      cout<<"Layer_E_colaps - Error - tri. face exists [iMode="<<iMode<<"]"<<endl;
		      exit(0);
		    }
#endif

		    gent = F_whatIn(face);
		    r_faces[iFace] = M_createF(mesh,numEdges,f_edges,f_dirs,gent);
	      
		    // level and type for face would remain the same 
		    // fVERTICAL_TRI (fTRANSITION is taken care in later, see above "if" condition on blEntType)
		    level = EN_levelInBL((pEntity)face);
		    blEntType = F_typeInBL(face);
//		    surfTag = EN_blSurfaceTag((pEntity)face);

		    EN_labelBLEntity((pEntity)r_faces[iFace],level,blEntType);

		    EN_attachDataPtr((pEntity)face,entPtrID,r_faces[iFace]);

		    continue;
		  }

		  if(!higherToLower) {
		    f_edges[2] = V_growthEdge(vertexR,1);

		    for(int iEdge=0; iEdge<numEdges; iEdge++) {
		      if(E_typeInBL(f_edges_tmp[iEdge])==eGROWTH) {
			f_edges[0] = f_edges_tmp[iEdge];
			f_dirs[0] = f_dirs_tmp[iEdge];

			for(int iEdge2=0; iEdge2<2; iEdge2++) {
			  int feIndex=(iEdge2+1+iEdge)%numEdges;
			  f_edges[2*iEdge2+1] = f_edges_tmp[feIndex];
			  f_dirs[2*iEdge2+1] = f_dirs_tmp[feIndex];
			}

			break;
		      }
		    }

		    pVertex mapEVtx[2] = {vertexR,curVR};
		    f_dirs[2] = 1;
		    if(E_vertex(f_edges[2],0)!=mapEVtx[EN_levelInBL((pEntity)f_edges[1])-iList+1])
		      f_dirs[2] = 0;

		    numEdges += 1;
		    blEntType = fVERTICAL_QUAD;
		  }
		  else {
		    // vertical triangular face of pyramid bounding growth edge on vertexD will form NULL face 
		    // (do NOT take care of f_edges etc. in thiscase)
		    for(int iEdge=0; iEdge<numEdges; iEdge++) {
		      // if(E_typeInBL(f_edges_tmp[iEdge])==eGROWTH && E_inClosure(f_edges_tmp[iEdge],vertexD))
		      if(!f_edges[iEdge])
                      {
			for(int iEdge2=0; iEdge2<3; iEdge2++) {
			  int eIndex = (iEdge2+iEdge+1)%4;
			  f_edges[iEdge2] = f_edges_tmp[eIndex];
			  f_dirs[iEdge2] = f_dirs_tmp[eIndex];
			}
			break;
		      }
		    }

		    numEdges -= 1;
		    blEntType = fVERTICAL_TRI;
		  }
		}
		else {
		  // transition or layer face
		  // must be triangle
		  int fe_transition_found = 0;
		  for(int iEdge=0; iEdge<numEdges; iEdge++) {
		    blEntType = E_typeInBL(f_edges[iEdge]);
		    if(blEntType==eTRANSITION) {
		      fe_transition_found = 1;
		      blEntType = fTRANSITION;
		      break;
		    }
		  }
		  if(!fe_transition_found)
		    blEntType = fLAYER;
		}

		if(numEdges>=3) {

#ifdef DEBUG
		  if(numEdges==3 && F_exists(Tedge,f_edges[0],f_edges[1],f_edges[2],0)) {
		    cout<<"Layer_E_colaps - Error - tri. face exists"<<endl;
		    exit(0);
		  }
		  if(numEdges==4 && F_exists(Tedge,f_edges[0],f_edges[1],f_edges[2],f_edges[3])) {
		    cout<<"Layer_E_colaps - Error - tri. face exists"<<endl;
		    exit(0);
		  }
#endif

		  gent = F_whatIn(face);
		  r_faces[iFace] = M_createF(mesh,numEdges,f_edges,f_dirs,gent);
	      
		  // level for face would remain the same
		  // (except for ones created from layer and transition faces at interface to form transition tets. when "higherToLower" is 0 during 3rd mode)
		  // level = EN_levelInBL((pEntity)face);
		  level = iList;
//		  surfTag = EN_blSurfaceTag((pEntity)face);
		  // blEntType = F_typeInBL(face);
		  EN_labelBLEntity((pEntity)r_faces[iFace],level,blEntType);

		  EN_attachDataPtr((pEntity)face,entPtrID,r_faces[iFace]);
		}
		else
		  r_faces[iFace] = 0;
	      } // face inside cavity
	    } // loop over faces of region

	    // make a copy
	    int r_dirs_tmp[5];
	    pFace r_faces_tmp[5] = {0,0,0,0,0};
	    for(int iFace=0; iFace<numFaces; iFace++) {
	      r_dirs_tmp[iFace] = r_dirs[iFace];
	      r_faces_tmp[iFace] = r_faces[iFace];
	    }

	    if(iMode==3) {
	      // topo. type, BL type and level remains the same
	      numFaces = R_numFaces(region);
	      blEntType = R_typeInBL(region);
	    }
	    else if(rTopoType==TET) {
	      // case with higherToLower (and Rtet) has been taken care of before
	      // i.e., in which transition tet. is collapsed

	      pEdge interEdge = 0;
	      numEdges = F_numEdges(lowerFace);
	      for(int iEdge=0; iEdge<numEdges; iEdge++) {
		edge = F_edge(lowerFace,iEdge);
		if(E_atBLInterface(edge)) {
		  interEdge = edge;
		  break;
		}
	      }

	      if(!interEdge) {
		cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		cout<<"interface edge for lower face of transition tet. NOT found [higherToLower="<<higherToLower<<"]"<<endl;
		cout<<endl;
		exit(0);
	      }

	      if(EN_getDataInt((pEntity)interEdge,dirIntID,&dir)) {
		// EN_getDataPtr((pEntity)interEdge,entPtrID,(void **)&temp);

		// "temp" may be interior edge
		// due to such cases F_exists() is applied
		// if no face exists then create one
		// r_faces_tmp[4] = E_verticalFace((pEdge)temp,-1);
		r_faces_tmp[4] = F_exists(Tvertex,vertexR,curVR,E_otherVertex(interEdge,vertexD),0);
	      }
	      else if(EN_getDataPtr((pEntity)interEdge,extraEntPtrID,(void **)&temp)) {
		// fifth entry is empty for tet.
		// r_dirs_tmp[4] is determined later based on side of CG wrt to face normal
		r_faces_tmp[4] = (pFace)temp;
	      }

	      // this is ALSO possible if "temp" (data attached to interEdge with entPtrID in case of merge) is interior edge and no face exits
	      if(!r_faces_tmp[4]) {
		// create new vertical triangular face
		f_edges[0] = E_exists(E_otherVertex(interEdge,vertexD),vertexR);
		if(E_vertex(f_edges[0],1)==vertexR)
		  f_dirs[0] = 1;
		else
		  f_dirs[0] = 0;

		// higherToLower is 0
		// hence vertexR has an upward growth edge
		f_edges[1] = V_growthEdge(vertexR,1);
		if(E_vertex(f_edges[1],0)==vertexR)
		  f_dirs[1] = 1;
		else
		  f_dirs[1] = 0;
		// this edge was created while creating upper transition face of tet.
		if(EN_getDataPtr((pEntity)interEdge,entPtrID,(void **)&temp))
		  f_edges[2] = (pEdge)temp;
		else {
		  cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		  cout<<"could NOT find data attached to edge for transition tet. [higherToLower="<<higherToLower<<"]"<<endl;
		  cout<<endl;
		  exit(0);
		}
		if(E_vertex(f_edges[2],0)==curVR)
		  f_dirs[2] = 1;
		else
		  f_dirs[2] = 0;

#ifdef DEBUG
		if(F_exists(Tedge,f_edges[0],f_edges[1],f_edges[2],0)) {
		  cout<<"Layer_E_colaps - Error - tri. face exists over uterface edge of BL tet."<<endl;
		  exit(0);
		}
#endif

		// use "gent" of region
		// gent = (pGRegin)R_whatIn(region);

// 		// use "gent" of edge at BL interface (interEdge)
// 		// use model classification from interEdge
// 		// new vertical face will be on the model entity onto which the edge resides
// 		if(EN_levelInBL((pEntity)interEdge)==0 || E_whatInType(interEdge)==1) {
// 		  cout<<"\nLayer_E_colaps - Error - edge at BL interface of zero level encountered [E_whatInType="<<E_whatInType(interEdge)<<"]\n"<<endl;
// 		  exit(0);
// 		}
// 		gent = E_whatIn(interEdge);

		// if "interEdge" is classified on model edge
		// use "gent" of the vertical face on cedge 
		// as this new triangular face on interEdge will contain it
		// if "interEdge" is classified on model face or model region
		// use "gent" of the region
		if(E_whatInType(interEdge)==Gedge)
		  gent = F_whatIn(E_verticalFace(cedge,1));
		else
		  gent = (pGEntity)R_whatIn(region);
		face = M_createF(mesh,3,f_edges,f_dirs,gent);

		// fifth entry is empty for tet.
		// r_dirs_tmp[4] is determined later based on side of CG wrt to face normal
		r_faces_tmp[4] = face;

		// level = iList;
		level = EN_levelInBL((pEntity)region);
//		surfTag = EN_blSurfaceTag((pEntity)region);
		// BL face type
		blEntType = fVERTICAL_TRI;
		// create new vertical triangular face
		EN_labelBLEntity((pEntity)r_faces_tmp[4],level,blEntType);

		EN_attachDataPtr((pEntity)interEdge,extraEntPtrID,r_faces_tmp[4]);
	      }

	      double rgn_cg[3] = {0.,0.,0.}, v_xyz[3];
	      pPList rverts = R_vertices(region,1);
	      int numVerts = PList_size(rverts);
	      for(int iVert=0; iVert<numVerts; iVert++) {
		pVertex rvtx = (pVertex)PList_item(rverts,iVert);
		if(rvtx==vertexD)
		  rvtx = vertexR;
		V_coord(rvtx,v_xyz);

		for(int iComp=0; iComp<3; iComp++)
		  rgn_cg[iComp] += v_xyz[iComp];
	      }
	      PList_delete(rverts);

	      V_coord(curVR,v_xyz);
	      for(int iComp=0; iComp<3; iComp++) {
		rgn_cg[iComp] += v_xyz[iComp];
		rgn_cg[iComp] /= 5;
	      }

	      // find out the face usage based on the side CG of the region lies wrt face
	      int fside = adaptUtil::XYZ_wrtFace(r_faces_tmp[4],rgn_cg);
	      if(!fside) {
		cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		cout<<"region cg lies on the mesh face"<<endl;
		cout<<endl;
		exit(0);
	      }
	      else {
		if(fside==1)
		  r_dirs_tmp[4] = 0;
		else
		  // i.e., fside==-1
		  r_dirs_tmp[4] = 1;
	      }

	      // initialize to NULL for safety
	      r_faces[0] = 0;
	      // rearrange faces
	      for(int iFace=0; iFace<5; iFace++) {
		if(F_numEdges(r_faces_tmp[iFace])==4) {
		  r_faces[0] = r_faces_tmp[iFace];
		  r_dirs[0] = r_dirs_tmp[iFace];
		  break;
		}
	      }

	      pPList fedges = F_edges(r_faces[0],1-r_dirs[0],0);
	      numEdges = PList_size(fedges);
	      for(int iFace=0; iFace<5; iFace++) {
		if(r_faces_tmp[iFace]==r_faces[0])
		  continue;
		for(int iEdge=0; iEdge<numEdges; iEdge++) {
		  edge = (pEdge)PList_item(fedges,iEdge);
		  if(F_inClosure(r_faces_tmp[iFace],(pEntity)edge)) {
		    r_faces[iEdge+1] = r_faces_tmp[iFace];
		    r_dirs[iEdge+1] = r_dirs_tmp[iFace];
		    break;
		  }
		}
	      }
	      PList_delete(fedges);

	      numFaces = 5;
	      // BL region/element type
	      blEntType = rTRANSITION_PYR;
	    }
	    else if(rTopoType==PYRAMID) {
	      // rearrange faces
	      if(!higherToLower) {
		EN_getDataPtr((pEntity)lowerFace,entPtrID,(void **)&temp);
		r_faces[0] = (pFace)temp;
		for(int iFace=0; iFace<5; iFace++) {
		  if(r_faces_tmp[iFace]==r_faces[0]) {
		    r_dirs[0] = r_dirs_tmp[iFace];
		    break;
		  }
		}

		pPList fedges = F_edges(r_faces[0],1-r_dirs[0],0);
		numEdges = PList_size(fedges);
		for(int iFace=0; iFace<5; iFace++) {
		  if(r_faces_tmp[iFace]==r_faces[0])
		    continue;
		  int found_edge = 0;
		  for(int iEdge=0; iEdge<numEdges; iEdge++) {
		    edge = (pEdge)PList_item(fedges,iEdge);
		    if(F_inClosure(r_faces_tmp[iFace],(pEntity)edge)) {
		      r_faces[iEdge+1] = r_faces_tmp[iFace];
		      r_dirs[iEdge+1] = r_dirs_tmp[iFace];
		      found_edge = 1;
		      break;
		    }
		  }
		  // if no edge is in closure then it is the top face
		  if(!found_edge) {
		    r_faces[4] = r_faces_tmp[iFace];
		    r_dirs[4] = r_dirs_tmp[iFace];
		  }
		}
		PList_delete(fedges);

		numFaces = 5;
		blEntType = rREGULAR;
	      }
	      else {
		EN_getDataPtr((pEntity)lowerFace,entPtrID,(void **)&temp);
		r_faces[0] = (pFace)temp;
		for(int iFace=0; iFace<5; iFace++) {
		  if(r_faces_tmp[iFace]==r_faces[0]) {
		    r_dirs[0] = r_dirs_tmp[iFace];
		    break;
		  }
		}

		pPList fedges = F_edges(r_faces[0],1-r_dirs[0],0);
		numEdges = PList_size(fedges);
		for(int iFace=0; iFace<5; iFace++) {
		  if(!r_faces_tmp[iFace] || r_faces_tmp[iFace]==r_faces[0])
		    continue;
		  for(int iEdge=0; iEdge<numEdges; iEdge++) {
		    edge = (pEdge)PList_item(fedges,iEdge);
		    if(F_inClosure(r_faces_tmp[iFace],(pEntity)edge)) {
		      r_faces[iEdge+1] = r_faces_tmp[iFace];
		      r_dirs[iEdge+1] = r_dirs_tmp[iFace];
		      break;
		    }
		  }
		}
		PList_delete(fedges);

		numFaces = 4;
		blEntType = rTRANSITION_TET;
	      }
	    }
	    else if(rTopoType==PRISM) {
	      // rearrange faces
	      if(!higherToLower) {
		cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		cout<<"wedge element encountered for higherToLower=0 while creating new regions [iMode="<<iMode<<"]"<<endl;
		cout<<endl;
		exit(0);
	      }
	      else {
		// initialize to NULL for safety
		r_faces[0] = 0;
		// rearrange faces
		for(int iFace=0; iFace<5; iFace++) {
		  if(F_numEdges(r_faces_tmp[iFace])==4) {
		    r_faces[0] = r_faces_tmp[iFace];
		    r_dirs[0] = r_dirs_tmp[iFace];
		    break;
		  }
		}

		pPList fedges = F_edges(r_faces[0],1-r_dirs[0],0);
		numEdges = PList_size(fedges);
		for(int iFace=0; iFace<5; iFace++) {
		  if(r_faces_tmp[iFace]==r_faces[0])
		    continue;
		  for(int iEdge=0; iEdge<numEdges; iEdge++) {
		    edge = (pEdge)PList_item(fedges,iEdge);
		    if(F_inClosure(r_faces_tmp[iFace],(pEntity)edge)) {
		      r_faces[iEdge+1] = r_faces_tmp[iFace];
		      r_dirs[iEdge+1] = r_dirs_tmp[iFace];
		      break;
		    }
		  }
		}
		PList_delete(fedges);

		numFaces = 5;
		blEntType = rTRANSITION_PYR;
	      }
	    }
	    else {
	      cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
	      cout<<"region topo. ["<<rTopoType<<"] NOT supported while creating new regions"<<endl;
	      cout<<endl;
	      exit(0);
	    }

	    gent = (pGEntity)R_whatIn(region);
	    newRegion = M_createR(mesh,numFaces,r_faces,r_dirs,gent);
	    PList_append(*newRegs,(void *)newRegion);
            newRegions.push_back(newRegion);

	    // level for region would remain the same 
	    // (except for ones created from layer and transition faces at interface to transition tets. when "higher ToLower" is 0 during 3rd mode)
	    level = EN_levelInBL((pEntity)region);
//	    surfTag = EN_blSurfaceTag((pEntity)region);
	    // blEntType = R_typeInBL(region);
	    EN_labelBLEntity((pEntity)newRegion,level,blEntType);
	  }

          BL_addRegsIntoBLs(newRegions, iList-1);

	  // convert interface layer and/or transition faces into transition tets. when "higherToLower" is 0
	  if(iMode==2 && !higherToLower) {
            vector<pRegion> newRegions;
	    for(int iFaceAtBLIntfc=0; iFaceAtBLIntfc<numFacesAtBLIntfc; iFaceAtBLIntfc++) {
	      face = facesAtBLIntfc[iFaceAtBLIntfc];

	      // no need to check for F_inClosure(face,(pEntity)cedge) except for level zero
	      // do NOT use F_atBLInterface(face) as lower level BL regions have been deleted in previous iteration
	      // this case can also include zero level layer faces
	      level = EN_levelInBL((pEntity)face);
	      if(level<iList) {

		if(!level && F_inClosure(face,(pEntity)interfaceEdge))
		  continue;
		
		if(!EN_getDataPtr((pEntity)face,entPtrID,(void **)&temp)) {
		  cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		  cout<<"data NOT attached to face at BL interface [iMode="<<iMode<<",iList="<<iList<<"]"<<endl;
		  cout<<endl;
		  exit(0);
		}
		r_faces[0] = (pFace)temp;

		// region is used later (in case iList==1)
		region = F_region(face,0);
		if(!region)
		  region = F_region(face,1);
		else if(F_region(face,1) && F_whatInType(face)==Gface) {
		  cout<<"\nLayer_E_colaps - Error - face at BL interface exists on non-manif model face\n"<<endl;
		  exit(0);
		}
		r_dirs[0] = R_dirUsingFace(region,face);

		bdryEdge = F_vtOpEd(face,vertexD);

		int flipFace = 0;
		if(r_dirs[0])
		  flipFace = 1;

		// modify r_dirs[0] after deciding on flipFace
		if(EN_getDataInt((pEntity)face,dirIntID,&dir))
		  if(!dir)
		    r_dirs[0] = !r_dirs[0];

		// face is a layer or transition face (triangular)
		pPList fedges = F_edges(face,1-flipFace,0);
		for(int iEdge=0; iEdge<3; iEdge++) {
		  edge = (pEdge)PList_item(fedges,iEdge);

		  // if bdryEdge then create new face (transition face) 
		  // do check if transition face exists 
		  // (can happen if face at BL interface is merging to non-BL face)
		  // and attach new face to the face at BL interface, "face", with the help of entPtrID
		  if(edge==bdryEdge) {
		    int no_e_fexists = 0;
		    for(int iEdge2=0; iEdge2<3; iEdge2++) {
		      pEdge f_edge = (pEdge)PList_item(fedges,iEdge2);

		      f_dirs[iEdge2] = F_dirUsingEdge(face,f_edge);

		      if(iEdge==iEdge2) {
			f_edges[iEdge2] = bdryEdge;
		      }
		      else {
			int ev_levels[2];
			level = 0;
			if(EN_getDataInt((pEntity)f_edge,dirIntID,&dir)) { // if merging
			  if(!dir)
			    f_dirs[iEdge2] = !f_dirs[iEdge2];

			  EN_getDataPtr((pEntity)f_edge,entPtrID,(void **)&temp);
			  f_edges[iEdge2] = (pEdge)temp;
			}
			else {
			  // do NOT use EN_getDataPtr((pEntity)f_edge,entPtrID,(void **)&temp)
			  // as it may have old data (i.e., edge between E_otherVertex(f_edge,vertexD) and vertexR)
			  f_edges[iEdge2] = E_exists(E_otherVertex(f_edge,vertexD),curVR);
			  if(f_edges[iEdge2]) {
			    if( E_vertex(f_edge,0)==E_vertex(f_edges[iEdge2],0) ||
				E_vertex(f_edge,1)==E_vertex(f_edges[iEdge2],1) )
			      f_dirs[iEdge2] = f_dirs[iEdge2];
			    else
			      f_dirs[iEdge2] = 1-f_dirs[iEdge2];
			  }
			  else {
			    for(int iVert=0; iVert<2; iVert++) {
			      vt = E_vertex(f_edge,iVert);

			      if(vt==vertexD)
				e_verts[iVert] = curVR;
			      else
				e_verts[iVert] = vt;
			      ev_levels[iVert] = EN_levelInBL((pEntity)e_verts[iVert]);
			      if(level<ev_levels[iVert])
				level = ev_levels[iVert];
			    }

// 			    // use model classification from f_edge
// 			    // check that f_edge is NOT at level zero
// 			    if(EN_levelInBL((pEntity)f_edge)==0) {
// 			      cout<<"\nLayer_E_colaps - Error - face at BL interface with zero level edge encountered\n"<<endl;
// 			      exit(0);
// 			    }

			    // if "f_edge" is classified on model edge
			    // use "gent" of the vertical face on cedge 
			    // if "f_edge" is classified on model face or model region
			    // use "gent" of the region connected to face at BL interface
			    if(!ev_levels[0] || !ev_levels[1]) {
			      if(E_whatInType(f_edge)==Gedge)
				gent = F_whatIn(E_verticalFace(cedge,1));
			      else
				gent = (pGEntity)R_whatIn(region);
			    }
			    else
			      gent = E_whatIn(f_edge);
			    f_edges[iEdge2] = M_createE(mesh,e_verts[0],e_verts[1],gent);

			    no_e_fexists++;
//			    surfTag = EN_blSurfaceTag((pEntity)f_edge);
			    // --- osahni must be eLAYER or eTRANSITION
			    // must be eTRANSITION
			    // the possible layer edge is bdryEdge itself
			    if(ev_levels[0]==ev_levels[1]) {
			      blEntType = eLAYER;
			      cout<<"\nLayer_E_colaps() - Error - level of transition edge end vertices same 1\n"<<endl;
			      exit(0);
			    }
			    else
			      blEntType = eTRANSITION;
			    // level is max. of ev_levels
			    // level must be "iList" as "iList-1" would have been processed in the previous iteration
			    EN_labelBLEntity((pEntity)f_edges[iEdge2],level,blEntType);

			    // attach this as it may be useful for interior volume mesh
			    if(!EN_getDataPtr((pEntity)f_edge,entPtrID,(void **)&temp))
			      EN_attachDataPtr((pEntity)f_edge,entPtrID,f_edges[iEdge2]);
			    else
			      EN_modifyDataPtr((pEntity)f_edge,entPtrID,f_edges[iEdge2]);
			  }
			}
		      }
		    }

		    // use model classification from face at BL interface
		    // check that face is NOT zero level face
// 		    if(EN_levelInBL((pEntity)face)==0) {
// 		      cout<<"\nLayer_E_colaps - Error - zero level face at BL interface encountered\n"<<endl;
// 		      exit(0);
// 		    }


// 		    if(flipFace) {
// 		      for(int iEDir=0; iEDir<3; iEDir++)
// 			f_dirs[iEDir] = 1-f_dirs[iEDir];
// 		    }

		    r_faces[iEdge+1] = 0;
		    if(!no_e_fexists)
		      r_faces[iEdge+1] = F_exists(Tedge,f_edges[0],f_edges[1],f_edges[2],0);
		    if(r_faces[iEdge+1]) {
		      
		      // bdryEdge == f_edges[iEdge]
		      // if both faces use bdryEdge in same direction region will use the faces in opposite direction
		      if(F_dirUsingEdge(r_faces[iEdge+1],bdryEdge)==f_dirs[iEdge])
			r_dirs[iEdge+1] = 1-r_dirs[0];
		      else
			r_dirs[iEdge+1] = r_dirs[0];

		      // use EN_modifyDataPtr() as face already has data attached to it with entPtrID
		      EN_modifyDataPtr((pEntity)face,entPtrID,r_faces[iEdge+1]);

		      continue;
		    }

		    if(flipFace) {
		      for(int iEDir=0; iEDir<3; iEDir++)
			f_dirs[iEDir] = 1-f_dirs[iEDir];
		    }

		    // transition face must be classified on model region
// 		    if(!EN_levelInBL((pEntity)face))
// 		      gent = F_whatIn(region);
// 		    else
// 		      gent = F_whatIn(face);
		    gent = (pGEntity)R_whatIn(region);
		    r_faces[iEdge+1] = M_createF(mesh,3,f_edges,f_dirs,gent);
		    r_dirs[iEdge+1] = 1-r_dirs[0];
		    if(flipFace && !EN_getDataInt((pEntity)face,dirIntID,&dir))
		      r_dirs[iEdge+1] = 1-r_dirs[iEdge+1];

		    // if F_exists - then it was labeled during merge info. based on iMode
		    blEntType = fTRANSITION;
//		    surfTag = EN_blSurfaceTag((pEntity)face);
		    level = iList;

		    EN_labelBLEntity((pEntity)r_faces[iEdge+1],level,blEntType);

		    // use EN_modifyDataPtr() as face already has data attached to it with entPtrID
		    EN_modifyDataPtr((pEntity)face,entPtrID,r_faces[iEdge+1]);

		    if(flipFace) {
		      if(!EN_getDataInt((pEntity)face,dirIntID,&dir))
			EN_attachDataInt((pEntity)face,dirIntID,0);
		      else {
			// if flipFace is true then data attached with dirIntID must be false/0
			if(dir) {
			  cout<<"\nLayer_E_colaps() - Error - error in flipping face\n"<<endl;
			  exit(0);
			}

		      }
		    }

		    continue;
		  }

		  pVertex oEVtx = E_otherVertex(edge,vertexD);
		  // initialize to NULL
		  r_faces[iEdge+1] = 0;
		  if(EN_getDataPtr((pEntity)edge,extraEntPtrID,(void **)&temp))
		    r_faces[iEdge+1] = (pFace)temp;
		  else if(EN_getDataInt((pEntity)edge,dirIntID,&dir)) {
		    // if edge is a merging edge then get the merging face
		    // --- EN_getDataPtr((pEntity)edge,entPtrID,(void **)&temp);

		    r_faces[iEdge+1] = F_exists(Tvertex,vertexR,curVR,oEVtx,0);
		  }

		  // create face such that order of vertices are vertexR, curVR and oEVtx, i.e., E_otherVertex(edge,vertexD)
		  if(!r_faces[iEdge+1]) {
		    int ev_levels[2];
		    level = 0;
		    f_edges[0] = V_growthEdge(vertexR,1);
		    f_dirs[0] = 1;
		    if(E_vertex(f_edges[0],0)!=vertexR)
		      f_dirs[0] = 0;

		    // for edge with no BL region at "iList" level this can be old data (i.e., edge between oEVtx and vertexR)
		    // if(EN_getDataPtr((pEntity)edge,entPtrID,(void **)&temp))		     
		    f_edges[1] = (pEdge)E_exists(oEVtx,curVR);
		    if(!f_edges[1]) {
		      for(int iVert=0; iVert<2; iVert++) {
			vt = E_vertex(edge,iVert);

			if(vt==vertexD)
			  e_verts[iVert] = curVR;
			else
			  e_verts[iVert] = vt;
			ev_levels[iVert] = EN_levelInBL((pEntity)e_verts[iVert]);
			if(level<ev_levels[iVert])
			  level = ev_levels[iVert];
		      }

// 		      // use model classification from edge
// 		      if(EN_levelInBL((pEntity)edge)==0) {
// 			cout<<"\nLayer_E_colaps - Error - face at BL interface with zero level edge encountered 2\n"<<endl;
// 			exit(0);
// 		      }

		      // if "edge" is classified on model edge
		      // use "gent" of the vertical face on cedge
		      // if "edge" is classified on model face or model region
		      // use "gent" of the region connected to face at BL interface
		      if(!ev_levels[0] || !ev_levels[1]) {
			if(E_whatInType(edge)==Gedge)
			  gent = F_whatIn(E_verticalFace(cedge,1));
			else
			  gent = (pGEntity)R_whatIn(region);
		      }
		      else
			gent = E_whatIn(edge);
		      f_edges[1] = M_createE(mesh,e_verts[0],e_verts[1],gent);

//		      surfTag = EN_blSurfaceTag((pEntity)edge);
		      // must be eTRANSITION
		      if(ev_levels[0]==ev_levels[1]) {
			blEntType = eLAYER;
			cout<<"\nLayer_E_colaps() - Error - level of transition edge end vertices same 2\n"<<endl;
			exit(0);
		      }
		      else
			blEntType = eTRANSITION;

		      // level is max. of ev_levels
		      // level must be "iList" as "iList-1" would have been processed in the previous iteration
		      EN_labelBLEntity((pEntity)f_edges[1],level,blEntType);

		      // attach this as it may be useful for interior volume mesh
		      if(!EN_getDataPtr((pEntity)edge,entPtrID,(void **)&temp))
			EN_attachDataPtr((pEntity)edge,entPtrID,f_edges[1]);
		      else
			EN_modifyDataPtr((pEntity)edge,entPtrID,f_edges[1]);
		    }
		    f_dirs[1] = 1;
		    if(E_vertex(f_edges[1],0)!=curVR)
		      f_dirs[1] = 0;

		    f_edges[2] = E_exists(oEVtx,vertexR);
		    f_dirs[2] = 1;
		    if(E_vertex(f_edges[2],1)!=vertexR)
		      f_dirs[2] = 0;

// 		    // use model classification from edge
// 		    // new vertical face will be on the model entity onto which the edge resides
// 		    if(EN_levelInBL((pEntity)edge)==0) {
// 		      cout<<"\nLayer_E_colaps - Error - face at BL interface with zero level edge encountered 3\n"<<endl;
// 		      exit(0);
// 		    }

		    // if "edge" is classified on model edge
		    // use "gent" of the vertical face on cedge 
		    // as this new triangular face on interEdge will contain it
		    // if "edge" is classified on model face or model region
		    // use "gent" of the region connected to face at BL interface
		    if(EN_levelInBL((pEntity)edge)==0) {
		      if(E_whatInType(edge)==Gedge)
			gent = F_whatIn(E_verticalFace(cedge,1));
		      else
			gent = (pGEntity)R_whatIn(region);
		    }
		    else
		      gent = E_whatIn(edge);

		    r_faces[iEdge+1] = M_createF(mesh,3,f_edges,f_dirs,gent);

		    blEntType = fVERTICAL_TRI;
//		    surfTag = EN_blSurfaceTag((pEntity)face);
		    level = iList;
		    EN_labelBLEntity((pEntity)r_faces[iEdge+1],level,blEntType);

		    // no data attached with extraEntPtrID to edge
		    EN_attachDataPtr((pEntity)edge,extraEntPtrID,r_faces[iEdge+1]);
		  }

		  double rgn_cg[3] = {0.,0.,0.}, v_xyz[3];
		  pPList fverts = F_vertices(face,1);
		  for(int iVert=0; iVert<3; iVert++) {
		    pVertex fvtx = (pVertex)PList_item(fverts,iVert);
		    if(fvtx==vertexD)
		      fvtx = vertexR;
		    V_coord(fvtx,v_xyz);

		    for(int iComp=0; iComp<3; iComp++)
		      rgn_cg[iComp] += v_xyz[iComp];
		  }
		  PList_delete(fverts);

		  V_coord(curVR,v_xyz);
		  for(int iComp=0; iComp<3; iComp++) {
		    rgn_cg[iComp] += v_xyz[iComp];
		    rgn_cg[iComp] /= 4;
		  }

		  // find out the face usage based on the side CG of the region lies wrt face
		  int fside = adaptUtil::XYZ_wrtFace(r_faces[iEdge+1],rgn_cg);
		  if(!fside) {
		    cout<<"\nError in fromMeshTools::Layer_E_colaps()"<<endl;
		    cout<<"transition tet. (region) cg lies on the mesh face"<<endl;
		    cout<<endl;
		    exit(0);
		  }
		  else {
		    if(fside==1) {
		      // should work for non-manif. model too
		      if(F_whatInType(r_faces[iEdge+1])<3) {
			F_chDir(r_faces[iEdge+1]);
			r_dirs[iEdge+1] = 1;
		      }
		      else
			r_dirs[iEdge+1] = 0;
		    }
		    else
		      // i.e., fside==-1
		      r_dirs[iEdge+1] = 1;
		  }

		  // except bdryEdge of the face
//		  PList_appUnique(delEdges,edge);
		}
		PList_delete(fedges);

		gent = (pGEntity)R_whatIn(region);
		newRegion = M_createR(mesh,4,r_faces,r_dirs,gent);
		PList_append(*newRegs,(void *)newRegion);
                newRegions.push_back(newRegion);

		blEntType = rTRANSITION_TET;
//		surfTag = EN_blSurfaceTag((pEntity)face);
		level = iList;
		EN_labelBLEntity((pEntity)newRegion,level,blEntType);
	      }
	    }

            BL_addRegsIntoBLs(newRegions, iList-1);
	    // add the interface faces to be cleaned -- ??
	  }

	  int deleteData = 1;
// 	  // for the last iteration of 3rd or 4th mode loop do not delete data attached to entities at BL interface
// 	  if(iList==end[numModes-2]-1 || iList==end[numModes-1]-1)
	  if(iList==end[numModes-1]-1)
	    deleteData = 0;

	  numRgns = vregs.size();
	  for(int iRgn=0; iRgn<numRgns; iRgn++) {
	    region = vregs[iRgn];
	    EN_unlabelBLEntity((pEntity)region);
	    M_removeRegion(mesh,region);
	  }

	  pPList delFaces = V_faces(vertexD);
	  numFaces = PList_size(delFaces);
	  for(int iFace=0; iFace<numFaces; iFace++) {
	    face = (pFace)PList_item(delFaces,iFace);
	    // probably no need to check for BL interface
	    // as delFaces list do not contain them
	    // even do not need to use deleteData
	    // as face at BL inerface is NOT in delFaces
	    // int isEntAtBLInterface = F_atBLInterface(face);
	    // if(deleteData || !isEntAtBLInterface) {

	    if(!F_typeInBL(face))
	      continue;

	    int fTypeInBL = F_typeInBL(face);
	    int fLevelInBL = EN_levelInBL((pEntity)face);

	    if(fTypeInBL==fTRANSITION && fLevelInBL>=iList)
	      continue;

	    if(fLevelInBL>iList)
	      continue;

            int isEntAtBLInterface = 0;
            if (std::find(facesAtBLIntfc.begin(), facesAtBLIntfc.end(), face) != facesAtBLIntfc.end())
              isEntAtBLInterface = 1;
//	    int isEntAtBLInterface = PList_inList(facesAtBLIntfc,(void *)face);

	    if(!isEntAtBLInterface) {
	      if(EN_getDataInt((pEntity)face,dirIntID,&dir))
		EN_deleteData((pEntity)face,dirIntID);
	      if(EN_getDataPtr((pEntity)face,entPtrID,(void **)&temp))
		EN_deleteData((pEntity)face,entPtrID);
	    }
	    // if(!PList_inList(facesAtBLIntfc,(void *)face))
	    if(!isEntAtBLInterface)
            {
	      EN_unlabelBLEntity((pEntity)face);
	      M_removeFace(mesh,face);
	    }
            // } 
	  }
	  PList_delete(delFaces);

	  numEdges = V_numEdges(vertexD);
	  // need to collect all the edges first and then delete them
          vector<pEdge> delEdges;
	  for(int iEdge=0; iEdge<numEdges; iEdge++)
            delEdges.push_back(V_edge(vertexD,iEdge));

	  // --- lowerEntPtrID
	  // CLEAN data associated with lowerEntPtrID (probably for all concerned edges)

	  for(int iEdge=0; iEdge<numEdges; iEdge++) {
            edge = delEdges[iEdge]; 
	     // edge = V_edge(vertexD,iEdge);

	    // to protect ones attached with the help of non-BL faces of curEdge
	    // in case of higherToLower delete the upward growth edge on vertexD for iMode==2
	    if(!E_typeInBL(edge) || (!higherToLower && EN_levelInBL((pEntity)edge)>=iList) || (higherToLower && EN_levelInBL((pEntity)edge)>iList-(iMode-2)))
	      continue;

	    // int isEntAtBLInterface = E_atBLInterface(edge);
//	    int isEntAtBLInterface = PList_inList(edgesAtBLIntfc,(void *)edge);
            int isEntAtBLInterface = 0;
            if (std::find(edgesAtBLIntfc.begin(), edgesAtBLIntfc.end(), edge) != edgesAtBLIntfc.end())
              isEntAtBLInterface = 1;
  
	    if(!isEntAtBLInterface || (iMode!=3 && deleteData))
// 	    if(deleteData || !isEntAtBLInterface)
// 	    if( (iMode==2 && (!isEntAtBLInterface || deleteData)) ||
// 		(iMode==3 && !isEntAtBLInterface) )
            {
	      if(EN_getDataInt((pEntity)edge,dirIntID,&dir))
		EN_deleteData((pEntity)edge,dirIntID);
	      if(EN_getDataPtr((pEntity)edge,entPtrID,(void **)&temp))
		EN_deleteData((pEntity)edge,entPtrID);
	    }
	    // data associated with extraEntPtrID is cleaned in each iteration of the loop
	    if(iMode==2) {
	      if(EN_getDataPtr((pEntity)edge,extraEntPtrID,(void **)&temp))
		EN_deleteData((pEntity)edge,extraEntPtrID);
	    }
	    if(!isEntAtBLInterface) {
	      EN_unlabelBLEntity((pEntity)edge);
	      M_removeEdge(mesh,edge);
	    }
	  }
	 
	  // 	  // need to delete GC for originating node
	  // 	  if(iList==1) {
	  // 	    // update the adj. gc list for GCs
	  // 	    pGrowthCurve gcOther;
	  // 	    // V_layerEdges() is used here as vertex is at zeroth level (i.e., onode)
	  // 	    lyrEdges = V_layerEdges(vertexR);
	  // 	    numEdges = PList_size(lyrEdges);
	  // 	    for(int iEdge=0; iEdge<numEdges; iEdge++) {
	  // 	      edge = (pEdge)PList_item(lyrEdges,iEdge);
	  // 	      vt = E_otherVertex(edge,vertexR);
	  // 	      gcOther = V_growthCurve(vt);
	  // 	      // this will add only if it doesn't exist in adj. gc list
	  // 	      gcR->addAdjacentGCInList(gcOther);
	  // 	      // this will add only if it doesn't exist in adj. gc list
	  // 	      gcOther->addAdjacentGCInList(gcR);
	  // 	      // this will delete only if it exists in adj. gc list
	  // 	      gcOther->deleteAdjacentGCInList(gcD);
	  // 	    }
	  // 	    PList_delete(lyrEdges);
	  
	  // 	    gcR->deleteAdjacentGCInList(gcD);
	  // 	    // nodesD and nodesR would be still valid as they are new copy
	  // 	    V_deleteBLData(vertexD);
	  // 	  }

	  // this condition may be true for either 3rd or 4th mode
	  // if((iMode==2 && higherToLower) || iList==end[numModes-1]-1)
	  if(iMode==2 && higherToLower)
          {
            // activate the callback
            // HACK for cases with linear modes only
            pPList oldRegs = PList_new();
            pPList newRegs = PList_new();
            if( CB && linearMode)
              (CB)(oldRegs,newRegs,userData,LECOLAPS,(pEntity)vertexD);
            PList_delete(oldRegs);
            PList_delete(newRegs);

	    EN_unlabelBLEntity((pEntity)vertexD);	
	    M_removeVertex(mesh,vertexD);
	  }
	}
      } // loop over "elist" ends (top most layer edge NOT included)
    }

    // this is silly 
    // NEED TO WORK ON THIS
    // -- seems doing pPList *list; *list = PList_new(); 
    // -- for two lists fails (without deleting the first)
//     pPList newRegsInterfaceTmp = PList_new();
//     pPList *newRegsInterface = &newRegsInterfaceTmp;
//     PList_delete(*newRegsInterface);
    pPList newRegsInterface;

    E_nonBLRegions(interfaceEdge, eNonBLRegs);

    numRgns = eNonBLRegs.size();
    for(int iRgn=0; iRgn<numRgns; iRgn++) {
      region = eNonBLRegs[iRgn];
      // EN_unlabelBLEntity((pEntity)region);
      M_removeRegion(mesh,region);
    }

    // this should work as we have deleted the old entities
    // E_colaps(mesh,interfaceEdge,topVD,topVR,CB,userData,eNonBLRegs,&newRegsInterface);

    // eNonBLRegs must be removed from following routine's interface
    // as E_colapsOnBLInterface() do NOT use eNonBLRegs anymore
    // (FOR TIME BEING eNonBLRegs still passed - remove after rigorous testing)
    newRegsInterface = E_colapsOnBLInterface(mesh,topVD,topVR,CB,userData);
    PList_appPList(*newRegs,newRegsInterface);
    PList_delete(newRegsInterface);

    pPList newONodes = PList_new();
    // if one (or both) end node of edgeDel has zero tot. num. of layers
    if(!edgeMinMax[0]) {
      if(!higherToLower && numZeroLvlFcsBLIntfc && edgeMinMax[1]) {
	// use zero level cavity nodes that collected with the help of "bdryEdge" in 1st mode (i.e., iMode==0) for iList==0
	int numZeroLevelCavityNodes = PList_size(zeroLevelCavityNodes);
	for(int iNode=0; iNode<numZeroLevelCavityNodes; iNode++) {
	  vertex = (pVertex)PList_item(zeroLevelCavityNodes,iNode);
          vector<pVertex> vNonBLFacesOnBLSurfaces;
	  V_nonBLFacesOnBLSurfaces(vertex, vNonBLFacesOnBLSurfaces);
	  void *temp1=0;
//	  while(face = (pFace)PList_next(vNonBLFacesOnBLSurfaces,&temp1)) {
          for (int iFace = 0; iFace < vNonBLFacesOnBLSurfaces.size(); ++iFace)
          {
            face = vNonBLFacesOnBLSurfaces[iFace];
	    // --- non-BL faces
// 	    if(EN_isBLEntity((pEntity)face))
// 	      continue;

	    level = 0;
	    // use surf. tag of face
	    gent = F_whatIn(face);
	    surfTag = GEN_tag(gent);

	    fverts = F_vertices(face,1);
	    // must be a triangle
	    for(int iVert=0; iVert<3; iVert++) {
	      vertex = (pVertex)PList_item(fverts,iVert);
	      if(V_typeInBL((pEntity)vertex))
		continue;

	      // here order of routines is important
	      // blEntType is not really needed in case of vertex
	      EN_labelBLEntity((pEntity)vertex,level,vORIGINATING);
//	      V_setTotNumLayers(vertex,0);
//	      V_newGrowthCurve(vertex);
	      PList_append(newONodes,(void *)vertex);
	    }
	    PList_delete(fverts);

	    // must be a triangle
	    for(int iEdge=0; iEdge<3; iEdge++) {
	      edge = F_edge(face,iEdge);
	      if(E_typeInBL(edge))
		continue;

	      blEntType = eLAYER;
	      EN_labelBLEntity((pEntity)edge,level,blEntType);
	    }

	    blEntType = fLAYER;
	    EN_labelBLEntity((pEntity)face,level,blEntType);
	  }
	}
      }
      else if(!vr_GC.size())//V_totNumLayers(vertr)) {
      {
	// vertr is at zero level

	pPList v_regs = V_regions(vertr);
	numRgns = PList_size(v_regs);
	int foundBLRgn = 0;
	for(int iRgn=0; iRgn<numRgns; iRgn++) {
	  region = (pRegion)PList_item(v_regs,iRgn);
	  if(R_isBLEntity((pEntity)region)) {
	    foundBLRgn = 1;
	    break;
	  }
	}
	PList_delete(v_regs);

	if(foundBLRgn) {
          vector<pFace> vNonBLFacesOnBLSurfaces;
	  V_nonBLFacesOnBLSurfaces(vertr, vNonBLFacesOnBLSurfaces);
	  void *temp1=0;
//	  while(face = (pFace)PList_next(vNonBLFacesOnBLSurfaces,&temp1)) {
          for (int iFace = 0; iFace < vNonBLFacesOnBLSurfaces.size(); ++iFace)
          {
            face = vNonBLFacesOnBLSurfaces[iFace];
	    // --- non-BL faces
// 	    if(EN_isBLEntity((pEntity)face))
// 	      continue;

	    level = 0;
	    // use surf. tag of face
	    gent = F_whatIn(face);
	    surfTag = GEN_tag(gent);

	    fverts = F_vertices(face,1);
	    // must be a triangle
	    for(int iVert=0; iVert<3; iVert++) {
	      vertex = (pVertex)PList_item(fverts,iVert);
	      if(V_typeInBL((pEntity)vertex))
		continue;

	      // here order of routines is important
	      // blEntType is not really needed in case of vertex
	      EN_labelBLEntity((pEntity)vertex,level,vORIGINATING);
//	      V_setTotNumLayers(vertex,0);
//	      V_newGrowthCurve(vertex);
	      PList_append(newONodes,(void *)vertex);
	    }
	    PList_delete(fverts);

	    // must be a triangle
	    for(int iEdge=0; iEdge<3; iEdge++) {
	      edge = F_edge(face,iEdge);
	      if(E_typeInBL(edge))
		continue;

	      blEntType = eLAYER;
	      EN_labelBLEntity((pEntity)edge,level,blEntType);
	    }

	    blEntType = fLAYER;
	    EN_labelBLEntity((pEntity)face,level,blEntType);
	  }
	}
      }
    }
    // this was allocated irrespective of any case and/or mode
    PList_delete(zeroLevelCavityNodes);

/*
    int numNewONodes = PList_size(newONodes);
    for(int iONode=0; iONode<numNewONodes; iONode++) {
      vertex = (pVertex)PList_item(newONodes,iONode);
      // this will also add GC on new ONode to adj. gc's list
      buildGrowthCurve(vertex);
    }
    PList_delete(newONodes);


    // need to delete GC for originating node --- already deleted
    // update the adj. gc list for GCs
    pGrowthCurve gcOther;
    // V_layerEdges() is used here as vertex is at zeroth level (i.e., onode)
    V_layerEdges(vertr, lyrEdges);
    numEdges = lyrEdges.size();
    for(int iEdge=0; iEdge<numEdges; iEdge++) {
      edge = lyrEdges[iEdge];
//       if(EN_levelInBL((pEntity)edge)!=0)
// 	continue;

      vt = E_otherVertex(edge,vertr);
      if(vt==vertd)
	continue;

      gcOther = V_growthCurve(vt);
      // this will add only if it doesn't exist in adj. gc list
      gcR->addAdjacentGCInList(gcOther);
      // this will add only if it doesn't exist in adj. gc list
      gcOther->addAdjacentGCInList(gcR);
      // this will delete only if it exists in adj. gc list
      gcOther->deleteAdjacentGCInList(gcD);
    }
    gcR->deleteAdjacentGCInList(gcD);
*/
//     mvtkAddMList(*newRegs);
//     mvtkActivate();
//     mvtkRemoveAllMEnts();

    for (int iBL = 0; iBL < num_vd_regs; ++iBL)
    {
//      EG_clear(old_BLs[iBL]);
      M_removeEntGrp(mesh, old_BLs[iBL]);
    }
    delete [] old_BLs;

    MD_deleteMeshDataId(entPtrID);
    MD_deleteMeshDataId(extraEntPtrID);
    // --- lowerEntPtrID
    //     MD_deleteMeshDataId(lowerEntPtrID);
    MD_deleteMeshDataId(dirIntID);

    return 1;
  }

  pPList E_colapsOnBLInterface(pMesh mesh, pVertex vertd, pVertex vertr, CBFunction CB, void *userData) {
    
    pRegion region, newRegion;
    pFace face, bdryFace, f[2];
    pEdge edge, e[2];
    pVertex vt, vertices[2];
    pGEntity gent;
    pPList tmpList, efaces;
    pFace faces[4];
    pEdge edges[3];
    int f_dirs[4], e_dirs[3] ;
    void *temp1=0, *temp2=0;
    int i,j,k,dir;
    int local = 0;

//     if (!eregs) {
//       eregs = E_nonBLRegions(cedge);
//       local = 1;
//     }
    
    pPList newReg=PList_new();

//     if( PList_size(eregs)==0 ) {   
//       cout<<"\nError in E_colapsOnBLInterface()"<<endl;
//       cout<<"NO non-BL regions found at interface edge"<<endl;
//       exit(0);
//     }

    // need to look up as we call this routine from Layer_E_colaps()
    pMeshDataId entPtr=MD_lookupMeshDataId("entPtr");
    if(!entPtr) {
      cout<<"\nError in E_colapsOnBLInterface()"<<endl;
      cout<<"NO mesh data ID found with <entPtr>"<<endl;
      exit(0);
    }
    pMeshDataId dirInt=MD_lookupMeshDataId("dirInt");
    if(!dirInt) {
      cout<<"\nError in E_colapsOnBLInterface()"<<endl;
      cout<<"NO mesh data ID found with <dirInt>"<<endl;
      exit(0);
    }

    // now, create the new mesh of the non-BL cavity at BL interface
    // "oldCavity" would be all old interface (non-BL) regions
    // as old BL regions connected to vertd (which is top of stack)
    // have been processed (deleted) in Layer_E_colaps()
    pPList oldCavity=V_regions(vertd);
    temp1 = 0;
    while (region = (pRegion)PList_next(oldCavity,&temp1)) 
      {
// 	if( PList_inList(eregs,(pEntity)region) )
// 	  continue;
	bdryFace=R_vtOpFc(region,vertd);

	// loop over the four faces (interface regions are tets)
	for( i=0;i<4;i++ ) {
	  face=R_face(region,i);
	  f_dirs[i]=R_dirUsingFace(region,face);

	  if( face==bdryFace ) {
	    faces[i]=face;
	    continue;
	  }

	  if( EN_getDataInt((pEntity)face,dirInt,&dir) && !dir )
	    f_dirs[i] = !f_dirs[i]; 
	  if( EN_getDataPtr((pEntity)face,entPtr,&temp2) )
	    faces[i]=(pFace)temp2;
	  else {
      
	    // loop over the three edges (i.e., triangular face of tets)
	    for( j=0;j<3;j++ ) {
	      edge=F_edge(face,j);
	      e_dirs[j]=F_dirUsingEdge(face,edge);
	      if( F_inClosure(bdryFace,(pEntity)edge) ) {
		edges[j]=edge;
		continue;
	      }
	      if( EN_getDataInt((pEntity)edge,dirInt,&dir) && !dir )
		e_dirs[j] = !e_dirs[j]; 
	      if( EN_getDataPtr((pEntity)edge,entPtr,&temp2) ) 
		edges[j]=(pEdge)temp2;
	      else {
          
		// loop over the two vertices
		for( k=0;k<2;k++ ) {
		  vt=E_vertex(edge,k);
		  if( vt==vertd )
		    vertices[k]=vertr;
		  else
		    vertices[k]=vt;
		}

#ifdef DEBUG
		if(E_exists(vertices[0],vertices[1])) {
		  cout<<"E_colapsAtBLInterface - Error - edges exists"<<endl;
		  exit(0);
		}
#endif

		// create edge inside the cavity 
		gent=E_whatIn(edge);
		edges[j]=M_createE(mesh,vertices[0], vertices[1], gent);
		EN_attachDataPtr((pEntity)edge,entPtr,edges[j]);
	      }
	    }

#ifdef DEBUG
		if(F_exists(Tedge,edges[0],edges[1],edges[2],0)) {
		  cout<<"E_colapsAtBLInterface - Error - face exists"<<endl;
		  exit(0);
		}
#endif

	    // create face inside the cavity
	    gent=F_whatIn(face);
	    faces[i]=M_createF(mesh, 3, edges, e_dirs, gent);
	    EN_attachDataPtr((pEntity)face,entPtr,faces[i]);	    
	  }
	}

	// create new regions
	gent=(pGEntity)R_whatIn(region);
	newRegion=M_createR(mesh, 4, faces, f_dirs, gent);
	PList_append(newReg,newRegion);
      }

//     if (local)
//       PList_delete(eregs);

    // activate the callback
    if( CB ) 
      (CB)(oldCavity,newReg,userData,ECOLAPS,(pEntity)vertd);

    /* Now actually delete the entities connected to vertd */
    temp1 = 0;
    while (region = (pRegion)PList_next(oldCavity,&temp1))
      M_removeRegion(mesh, region);
    PList_delete(oldCavity);

    pPList vfaces=V_faces(vertd);
    temp1 = 0;
    while (face = (pFace)PList_next(vfaces,&temp1)) {
      if(F_typeInBL(face))
	EN_unlabelBLEntity((pEntity)face);

      if(EN_getDataInt((pEntity)face,dirInt,&dir))
	EN_deleteData((pEntity)face,dirInt);
      if(EN_getDataPtr((pEntity)face,entPtr,(void **)&temp2))
	EN_deleteData((pEntity)face,entPtr);
      M_removeFace(mesh, face);
    }
    PList_delete(vfaces);

    // need to collect all the edges first and then delete them
    pPList vedges=PList_new();
    for( i=0; i<V_numEdges(vertd); i++ ) {
      edge=V_edge(vertd,i);
      PList_append(vedges,(pEntity)edge);
    }
    temp1 = 0;
    while( edge=(pEdge)PList_next(vedges,&temp1) ) {
      if(E_typeInBL(edge))
	EN_unlabelBLEntity((pEntity)edge);

      if(EN_getDataInt((pEntity)edge,dirInt,&dir))
	EN_deleteData((pEntity)edge,dirInt);
      if(EN_getDataPtr((pEntity)edge,entPtr,(void **)&temp2))
	EN_deleteData((pEntity)edge,entPtr);      
      M_removeEdge(mesh, edge);
    }
    PList_delete(vedges);

    if(V_typeInBL((pEntity)vertd))      	
      EN_unlabelBLEntity((pEntity)vertd);

    M_removeVertex(mesh,vertd);

    return newReg;
  }

  // Here we have assumed the ordering of mesh entities of prismatic elements 
  int Layer_E_swap(pMesh mesh,
		   vector<pEdge>& elist,
		   int c,
		   CBFunction CB,
		   void *userData,
		   pPList *newRegions)  // this routine allocate space
  {
    
    int linearMode = 1;
    if( CB ) {
      // if call back function is made available we
      // might have to change the instants where old regions are deleted
      // probably need to invoke call back function for each layer edge swap

      // HACK for cases with linear modes only
      // for linear modes do not need to invoke call back function
      // as no vertex is deleted or crerated

      if(!linearMode) {
        cout<<"\nError in fromMeshTools::Layer_E_swap()"<<endl;
        cout<<"call back function NOT supported as of now"<<endl;
        exit(0);
      }
    }

    pEdge edge, storeNewEdge;
    pFace face;
    pRegion region, newRegion;

    pPList oldFaces = PList_new();
    pPList oldRgns = PList_new();

    int index;
    int listSize = elist.size();

//    int surfTag = EN_blSurfaceTag((pEntity)PList_item(elist,0));
    pGEntity modelSurface, modelRegion, g_ent;
    modelSurface = E_whatIn(elist[0]);
    // modelRegion = E_whatIn((pEdge)PList_item(elist,1));
    
    vector<pFace> layerFaces;
    pFace layerFcs[2];
    pFace botFcs[2], topFcs[2];
    pRegion origRegions[2];

    // used to create new mesh entities
    pVertex e_vtx[2];
    pEdge f_tri_edges[3];
    int f_tri_dirs[3];
    pEdge f_quad_edges[4];
    int f_quad_dirs[4];
    pFace r_faces[5];
    int r_dirs[5];

    pBLayer old_BLs[2], pBLayerNewBL;

    // this contains all the new regions created 
    // (i.e., ones contained in 2 stacks)
    *newRegions = PList_new();

    edge = elist[0];

    // get the four concerned growth curves 
    // (i.e., at four corners of quad. cavity)
    // GCs[0] - v0 of "edge", GCs[2] - v1 of "edge"
    // GCs[1] - opp. vt. of face using "edge" negatively
    // GCs[3] - opp. vt. of face using "edge" positively
    vector<pVertex> GCs[4];
//    GCs[0] = V_growthCurve(E_vertex(edge,0));
//    GCs[2] = //V_growthCurve(E_vertex(edge,1));
    BL_getGrowthCurveNodes(E_vertex(edge,0),GCs[0]);
    BL_getGrowthCurveNodes(E_vertex(edge,1),GCs[2]);
    
    E_layerFaces(edge, layerFaces);
    int level[3], posEdgeCounter = 0;
    pPList vlist;
    for(int iFace=0; iFace<2; iFace++) {
      face = layerFaces[iFace];

      int iGC=1,iFC=0;
      if(F_dirUsingEdge(face,edge)) {
	posEdgeCounter++;
	// layerFcs[1] is the face using edge positively
	iFC=1;
	// GCs[3] is the growht curve at opp. vt. of face
	// using "edge" positively
	iGC=3;
      }
      layerFcs[iFC] = face;
//      GCs[iGC] = V_growthCurve(F_edOpVt(face,edge));
      BL_getGrowthCurveNodes(F_edOpVt(face,edge),GCs[iGC]);
      
      // checking for transition elements
      vlist = F_vertices(face,1);
      // assuming layer face to be triangular
      for(int iVert=0; iVert<3; iVert++)
      { 
        vector<pVertex> GC_nbrs;
        BL_getGrowthCurveNodes((pVertex)PList_item(vlist,iVert),GC_nbrs);
        level[iVert] = GC_nbrs.size();
//	level[iVert] = V_totNumLayers((pVertex)PList_item(vlist,iVert));
      }
      PList_delete(vlist);
      if( level[0]!=level[1] ||
	  level[0]!=level[2] ) {
	// for transition element can work with minimal level
	cout<<"\nError in fromMeshTools::Layer_E_swap()"<<endl;
	cout<<"transition elements NOT supported [iFace="<<iFace<<"]"<<endl;
	exit(0);
      }
    }

    /// MAYBE MAKES SENCE TO JUST USE V_growthEdge(vertex,1) WHERE NEEDED
    vector<pEdge> GCEdges[4];
    for (int iEdge = 0; iEdge < 4; iEdge++)
      BL_getGrowthCurveEdges(GCs[iEdge][0], GCEdges[iEdge]);

    if( posEdgeCounter==0 ||
	posEdgeCounter==2 ) {
      cout<<"\nError in fromMeshTools::Layer_E_swap()"<<endl;
      cout<<"zero level layer edge used by layer faces in same way"<<endl;
      exit(0);
    }

    for(int iRgn=0; iRgn<2; iRgn++) {
      origRegions[iRgn] = F_region(layerFcs[iRgn],0);
      if(!origRegions[iRgn])	  
	origRegions[iRgn] = F_region(layerFcs[iRgn],1);

      /// Get the old BLs to delete later
      old_BLs[iRgn] = EN_getBL(origRegions[iRgn]);
      EG_clear(old_BLs[iRgn]);
    }

    // the old vertical quad. faces (above edges in "elist" to be swapped)
//    pPList origVerticalFacesList = GC_verticalFaces(GCs[0], GCs[2]);
    edge = E_exist(GCs[0][0], GCs[2][0]); 
    vector<pFace> origVerticalFacesList;
    BL_getVerticalFacesByEdge(edge, origVerticalFacesList);
    

    vector<pEdge> layerEdgesList[4];
    vector<pFace> verticalFacesList[4];
    for(int iNode=0; iNode<4; iNode++) 
    {
      edge = E_exist(GCs[iNode][0], GCs[(iNode+1)%4][0]);
      BL_getHorizontalEdgesByEdge(edge, layerEdgesList[iNode]);
      BL_getVerticalFacesByEdge(edge, verticalFacesList[iNode]);
//      layerEdgesList[iNode] = GC_layerAndTransitionEdges(GCs[iNode], GCs[(iNode+1)%4]);
//      verticalFacesList[iNode] = GC_verticalFaces(GCs[iNode],  GCs[(iNode+1)%4]);
    }

    // at first we handle the zero level layer edge
    // create the new (layer) edges and (layer) faces 
    // on this level and upper level
    // create the new (vertical) quad. face above the edge
    // also create the new regions on upper level 
    // (label all new bl entities)
    // delete the old (layer) edge and (layer) faces on this level
    // delete the old (vertical) quad. face above the edge
    // also delete the old regions on upper level 
    // (unlabel all old bl entities)

    // CAUTION: as we label new and unlabel old mesh entities 
    // within the loop be sure while using any routine from BLUtils
    
    int ef_order[2][2][2] = {{{1,2},{3,0}}, {{2,1},{0,3}}};
    for(int iLevel=0; iLevel<2; iLevel++) {
      e_vtx[0]=GCs[1][iLevel];
      e_vtx[1]=GCs[3][iLevel];

//       if(iLevel) {
// 	ef_order[0][0]=2;ef_order[0][1]=1;
// 	ef_order[1][0]=0;ef_order[1][1]=3;
//       }
//       else {
// 	ef_order[0][0]=1;ef_order[0][1]=2;
// 	ef_order[1][0]=3;ef_order[1][1]=0;
//       }

      g_ent = modelSurface;
      if(iLevel) {
	g_ent = (pGEntity)R_whatIn(origRegions[0]); // modelRegion;
	// old layer faces at upper level
	for(int iFace=0; iFace<2; iFace++)
	  layerFcs[iFace] = F_otherTriFcPrism(layerFcs[iFace],
					      origRegions[iFace]);
	  // layerFcs[iFace] = R_face(origRegions[iFace],4);
      }
      
      f_tri_edges[0] = M_createE(mesh,e_vtx[0],e_vtx[1],g_ent);
      EN_labelBLEntity((pEntity)f_tri_edges[0],iLevel,eLAYER);
      
      edge = elist[iLevel];
      if(!iLevel) {
	// EN_unlabelBLEntity((pEntity)edge);
	// M_removeEdge(mesh,edge);
      }  

      // required for the new vertical quad. face
      f_quad_edges[iLevel*2] = f_tri_edges[0];
      f_quad_dirs[iLevel*2] = iLevel;

      // store the new level one edge (layer edge)
      // for next level vertical quad. face
      if(iLevel)
	storeNewEdge = f_tri_edges[0];

      int whichFace[4] = {0,0,1,1};
      int rFaceDir[2];
      for(int iFace=0; iFace<2; iFace++)
        rFaceDir[iFace] = R_dirUsingFace(origRegions[iFace],layerFcs[iFace]);
      for(int iFace=0; iFace<2; iFace++) {
	// way depends on level and face usage
	int whichWay = iLevel*rFaceDir[iFace];
	// int fe_dir_0[2][2] = {{0,1}, {1,0}};
	f_tri_dirs[0] = ABS(iFace-whichWay);

	// which old face needed to know how new face 
	// use any edge (of the quad. cavity)
	// (new face uses any edge of quad. cavity same way/dir as old face)
	// int whichFace = ABS(iLevel-iFace);
	for(int iEdge=1; iEdge<3; iEdge++) {
	  index = ef_order[whichWay][iFace][iEdge-1];
	  f_tri_edges[iEdge] = layerEdgesList[index][iLevel];
	  f_tri_dirs[iEdge] = F_dirUsingEdge(layerFcs[whichFace[index]],
                                             f_tri_edges[iEdge]);
          if(rFaceDir[whichFace[index]]!=rFaceDir[iFace])
            f_tri_dirs[iEdge] = 1-f_tri_dirs[iEdge];
	  // whichFace = 1-whichFace;
	} // loop over two old edges

	face =  M_createF(mesh,3,f_tri_edges,f_tri_dirs,g_ent);
	EN_labelBLEntity((pEntity)face,iLevel,fLAYER);
	
	if(!iLevel) {
	  // the level one layer faces would be handled later
	  // EN_unlabelBLEntity((pEntity)layerFcs[iFace]);
	  // M_removeFace(mesh,layerFcs[iFace]);
	  PList_appUnique(oldFaces,layerFcs[iFace]);
	}

	// store the newly created layer faces appropriately
	// would be required to create next level regions in bl
	if(iLevel)
	  topFcs[iFace] = face;
	else
	  botFcs[iFace] = face;
      } // loop over two layer faces

      if(iLevel) {
	for(int iEdge=0; iEdge<2; iEdge++) {
	  index = 2*iEdge+1;
	  f_quad_edges[index] = GCEdges[index][0];//GCs[index][0];
	  f_quad_dirs[index] = 0;
	  if(GCs[index][0]==E_vertex(f_quad_edges[index],iEdge))
	    f_quad_dirs[index] = 1;
	}

	// create the new vertical quad. face
	pFace newVertFace = M_createF(mesh,4,f_quad_edges,f_quad_dirs,g_ent);
	EN_labelBLEntity((pEntity)newVertFace,1,fVERTICAL_QUAD);

	face = origVerticalFacesList[0];
	// EN_unlabelBLEntity((pEntity)face);
	// M_removeFace(mesh,face);
	PList_appUnique(oldFaces,face);

	int rvface_index[2][3]={{1,2,3}, {2,3,1}};
	for(int iRgn=0; iRgn<2; iRgn++) {

	  region = origRegions[iRgn];
	  r_faces[0] = botFcs[iRgn];
	  // must be 1 (as points outside the level one region)
	  // (may work if not 1)
	  face = F_otherTriFcPrism(layerFcs[iRgn],region);
	  r_dirs[0] = R_dirUsingFace(region,face);

	  int vfindex = rvface_index[1-r_dirs[0]][2];
	  r_faces[vfindex] = newVertFace;
	  r_dirs[vfindex] = iRgn;

	  r_faces[4] = topFcs[iRgn];
	  // must be 1 (as points outside the region)
	  // (may not be 1)
	  r_dirs[4] = R_dirUsingFace(region,layerFcs[iRgn]);
	  
	  int whichRgn[4] = {0,0,1,1};
	  for(int iFace=1; iFace<3; iFace++) {
	    // as the bottom face (on model bdry.) points outside the prism
	    // we use quad. faces related to e2, e1, e0 of bottom face
	    // that is why ef_order for iLevel=1 can be used even
	    // though bottom face was created with ef_order at iLevel=0
	    // NOW we take care of ef_order based on bot. face usage by region
	    index = ef_order[r_dirs[0]][iRgn][iFace-1];
	    vfindex = rvface_index[1-r_dirs[0]][iFace-1];
	    r_faces[vfindex] = verticalFacesList[index][0];
	    r_dirs[vfindex] = R_dirUsingFace(origRegions[whichRgn[index]],
					     r_faces[vfindex]);
	    // whichRgn = 1-whichRgn;
	  }
	
	  // create and label new region (prism)
	  newRegion = M_createR(mesh,5,r_faces,r_dirs,g_ent);
	  EN_labelBLEntity((pEntity)newRegion,iLevel,rREGULAR);
	  PList_append(*newRegions,newRegion);

	  // unlabel and delete the orig. region
	  // EN_unlabelBLEntity((pEntity)region);  
	  // M_removeRegion(mesh,region);
	  PList_appUnique(oldRgns,region);

          pBLayerNewBL = M_createEntGrp(mesh, 3);
          EG_addEntity(pBLayerNewBL, (pEntity)newRegion);

	} // loop over new regions

      } // if iLevel==1

    } // loop over two levels

    // loop over edges other than bottom and top most edge
    // (i.e., other than edges on model surface and at interface)
    // in each step of the loop ---
    // create the new (layer) edge and (layer) faces on upper level
    // create the new (vertical) quad. face above the edge
    // also create the new regions on upper level
    // (label all new bl entities)
    // delete the old (layer) edge and (layer) faces on this level
    // delete the old (vertical) quad. face above the edge
    // also delete the old regions on upper level 
    // (unlabel all old bl entities)

    // CAUTION: as we label new and unlabel old mesh entities 
    // within the loop be sure while using any routine from BLUtils

    int upperLevel;
//     ef_order[0][0]=2;ef_order[0][1]=1;
//     ef_order[1][0]=0;ef_order[1][1]=3;
    g_ent = (pGEntity)R_whatIn(origRegions[0]); // modelRegion;
    for(int iList=1; iList<listSize-1; iList++) {
      upperLevel = iList+1;

      e_vtx[0]=GCs[1][upperLevel];
      e_vtx[1]=GCs[3][upperLevel];

      edge = elist[iList];
      // EN_unlabelBLEntity((pEntity)edge);
      // M_removeEdge(mesh,edge);

      vector<pRegion> newRegs;

      for(int iRgn=0; iRgn<2; iRgn++) {
	region = origRegions[iRgn];
	// update the origRegions for the next step of the loop
	origRegions[iRgn] = adaptUtil::F_otherRgn(layerFcs[iRgn],region);
	if(!origRegions[iRgn]) {
	  cout<<"\nError in fromMeshTools::Layer_E_swap()"<<endl;
	  cout<<"other region do NOT exist ["<<iList<<","<<iRgn<<"]"<<endl;
	  exit(0);
	}
      }

      for(int iFace=0; iFace<2; iFace++) {
	// EN_unlabelBLEntity((pEntity)layerFcs[iFace]);
	// M_removeFace(mesh,layerFcs[iFace]);
	PList_appUnique(oldFaces,layerFcs[iFace]);

	// old layer faces at upper level
	layerFcs[iFace] = F_otherTriFcPrism(layerFcs[iFace],
					    origRegions[iFace]);
	// layerFcs[iFace] = R_face(origRegions[iFace],4);
	
	// update the botFcs with topFcs as we proceed in the loop
	botFcs[iFace] = topFcs[iFace];
      }
      
      f_tri_edges[0] = M_createE(mesh,e_vtx[0],e_vtx[1],g_ent);
      EN_labelBLEntity((pEntity)f_tri_edges[0],upperLevel,eLAYER);
      
      edge = elist[upperLevel];    

      // required for the new vertical quad. face
      f_quad_edges[0] = storeNewEdge;
      f_quad_dirs[0] = 0;
      f_quad_edges[2] = f_tri_edges[0];
      f_quad_dirs[2] = 1;

      // update the new edge (layer edge) 
      // for next step of the loop
      // (to create vertical quad. face)
      storeNewEdge = f_tri_edges[0];

      int whichFace[4] = {0,0,1,1};
      int rFaceDir[2];
      for(int iFace=0; iFace<2; iFace++)
	rFaceDir[iFace] = R_dirUsingFace(origRegions[iFace],layerFcs[iFace]);
      for(int iFace=0; iFace<2; iFace++) {
	// way depends on face usage
	int whichWay = rFaceDir[iFace];
	// int fe_dir_0[2][2] = {{0,1}, {1,0}};
	f_tri_dirs[0] = ABS(iFace-whichWay);

	// which old face needed to know how new face 
	// use any edge (of the quad. cavity)
	// (new face uses any edge of quad. cavity same way/dir as old face)
	// int whichFace = 1-iFace;
	for(int iEdge=1; iEdge<3; iEdge++) {
	  index = ef_order[whichWay][iFace][iEdge-1];
	  f_tri_edges[iEdge] = layerEdgesList[index][upperLevel];
	  f_tri_dirs[iEdge] = F_dirUsingEdge(layerFcs[whichFace[index]],
					     f_tri_edges[iEdge]);
          if(rFaceDir[whichFace[index]]!=rFaceDir[iFace])
            f_tri_dirs[iEdge] = 1-f_tri_dirs[iEdge];
	  // whichFace = 1-whichFace;
	} // loop over two old layer edges at upperLevel

	face =  M_createF(mesh,3,f_tri_edges,f_tri_dirs,g_ent);
	EN_labelBLEntity((pEntity)face,upperLevel,fLAYER);

	topFcs[iFace] = face;
      } // loop over two layer faces
      
      for(int iEdge=0; iEdge<2; iEdge++) {
	index = 2*iEdge+1;
	f_quad_edges[index] = GCEdges[index][iList];//GCs[index][iList];
	f_quad_dirs[index] = 0;
	if(GCs[index][iList]==E_vertex(f_quad_edges[index],iEdge))
	  f_quad_dirs[index] = 1;
      }

      // create the new vertical quad. face
      pFace newVertFace = M_createF(mesh,4,f_quad_edges,f_quad_dirs,g_ent);
      EN_labelBLEntity((pEntity)newVertFace,upperLevel,fVERTICAL_QUAD);

      face = origVerticalFacesList[iList];
      // EN_unlabelBLEntity((pEntity)face);
      // M_removeFace(mesh,face);
      PList_appUnique(oldFaces,face);

      int rvface_index[2][3]={{1,2,3}, {2,3,1}};
      for(int iRgn=0; iRgn<2; iRgn++) {

	region = origRegions[iRgn];
	r_faces[0] = botFcs[iRgn];
	// must be 0 (as points inside the region)
	// (may work if not 0)
	face = F_otherTriFcPrism(layerFcs[iRgn],region);
	r_dirs[0] = R_dirUsingFace(region,face);

	int vfindex = rvface_index[1-r_dirs[0]][2];
	r_faces[vfindex] = newVertFace;
	r_dirs[vfindex] = iRgn;

	r_faces[4] = topFcs[iRgn];
	// must be 1 (as points outside the region)
	// (may not be 1)
	r_dirs[4] = R_dirUsingFace(region,layerFcs[iRgn]);

	// when r_dirs[0] is 0 (normal points inside)
	//  for new region 0
	//   r_faces[1] = iList face in verticalFacesList[2]
	//   r_dirs[1] = r_faces[1] used by origRegions[1]
	//   r_faces[2] = iList face in verticalFacesList[1]
	//   r_dirs[2] = r_faces[2] used by origRegions[0]
	//  for new region 1
	//   r_faces[1] = iList face in verticalFacesList[0]
	//   r_dirs[1] = r_faces[1] used by origRegions[0]
	//   r_faces[2] = iList face in verticalFacesList[3]
	//   r_dirs[2] = r_faces[2] used by origRegions[1]
	// when r_dirs[0] is 1 (normal points outside)
	//  for new region 0
	//   r_faces[2] = iList face in verticalFacesList[2]
	//   r_dirs[2] = r_faces[1] used by origRegions[1]
	//   r_faces[3] = iList face in verticalFacesList[1]
	//   r_dirs[3] = r_faces[2] used by origRegions[0]
	//  for new region 1
	//   r_faces[2] = iList face in verticalFacesList[0]
	//   r_dirs[2] = r_faces[1] used by origRegions[0]
	//   r_faces[3] = iList face in verticalFacesList[3]
	//   r_dirs[3] = r_faces[2] used by origRegions[1]
	int whichRgn[4] = {0,0,1,1};
	for(int iFace=1; iFace<3; iFace++) {
	  // as the bottom face points inside the prism
	  // we use quad. faces related to e0, e1, e2 of bottom face
	  // that is why ef_order initialized before loop 
	  // can be used for the whole loop
	  // NOW we take care of ef_order based on bot. face usage by region
	  index = ef_order[1-r_dirs[0]][iRgn][iFace-1];
	  vfindex = rvface_index[1-r_dirs[0]][iFace-1];
	  r_faces[vfindex] = verticalFacesList[index][iList];
	  r_dirs[vfindex] = R_dirUsingFace(origRegions[whichRgn[index]],
					   r_faces[vfindex]);
	  // whichRgn = 1-whichRgn;
	}	  

	// create and label new region (prism)
	newRegion = M_createR(mesh,5,r_faces,r_dirs,g_ent);
	EN_labelBLEntity((pEntity)newRegion,upperLevel,rREGULAR);
	PList_append(*newRegions,newRegion);
  
        newRegs.push_back(newRegion);
	
	// unlabel and delete the orig. region
	// EN_unlabelBLEntity((pEntity)region);  
	// M_removeRegion(mesh,region);
	PList_appUnique(oldRgns,region);
	
      } // loop over new regions

      BL_addRegsIntoBLs(newRegs, iList); 
    } // loop over elist ends (zeroth and top most edges NOT included)

    // delete the supporting lists
//    PList_delete(origVerticalFacesList);
//    for(int iNode=0; iNode<4; iNode++) {
//     PList_delete(layerEdgesList[iNode]);
//      PList_delete(verticalFacesList[iNode]);
//    }	

    // update the adjacency list in GCs
//    GCs[0]->deleteAdjacentGCInList(GCs[2]);    
//    GCs[2]->deleteAdjacentGCInList(GCs[0]);

//    GCs[1]->addAdjacentGCInList(GCs[3]);
//    GCs[3]->addAdjacentGCInList(GCs[1]);

    // if old top most layer edge is classified on a model face 
    // then update the classification of newly created
    // top most (layer) edge and (layer) faces
    // if non-manifold this is NOT taken care in E_swapOnBLInterface()
    edge = elist[listSize-1];
    g_ent = E_whatIn(edge);
    if(E_whatInType(edge)==2) {
      E_setWhatIn(storeNewEdge,g_ent);
      F_setWhatIn(topFcs[0],g_ent);
      F_setWhatIn(topFcs[1],g_ent);

#ifdef MA_PARALLEL
      sendReclassifiedEntity(mesh, (pEntity)topFcs[0], r_dirs[0]);
      sendReclassifiedEntity(mesh, (pEntity)topFcs[1], r_dirs[1]);
      sendReclassifiedEntity(mesh, (pEntity)storeNewEdge, 0);
#endif

    }
    
//     pPList eregsTmp = E_regions(edge);
//     pPList eregs = PList_new();
//     int size = PList_size(eregsTmp);
//     for(int iRgn=0; iRgn<size; iRgn++) {
//       region = (pRegion)PList_item(eregsTmp,iRgn);
//       if(!EN_isBLEntity((pEntity)region))
// 	PList_append(eregs,region);
//     }
//     PList_delete(eregsTmp);

    vector<pRegion> eregs_vec;
    E_nonBLRegions(edge,eregs_vec);

    pPList eregs = PList_new();
    for (int iReg = 0; iReg < eregs_vec.size(); ++iReg)
      PList_append(eregs, (void*)eregs_vec[iReg]);

    // with this we are done with swap in the stack of prisms 
    // (currently, cannot handle transition elements)
    // now triangulate the cavity formed in the interface region
    pPList interfaceRgns;
    // for call back function would probably have to 
    // change the arguments of routine - E_swapOnBLInterface()
    interfaceRgns = E_swapOnBLInterface(mesh,edge,eregs,c, oldRgns, oldFaces);

    PList_appPList(*newRegions,interfaceRgns);
    PList_delete(interfaceRgns);
    PList_delete(eregs);

//     for(int iRgn=0; iRgn<PList_size(*newRegions); iRgn++) {
//       mvtkAddMEnt((pRegion)PList_item(*newRegions,iRgn));
//     }
//     mvtkActivate();
//     mvtkRemoveAllMEnts();

    int delSize = PList_size(oldRgns);
    for(int iDel=0; iDel<delSize; iDel++) {
      region = (pRegion)PList_item(oldRgns,iDel);
      EN_unlabelBLEntity((pEntity)region);
      M_removeRegion(mesh,region);
    }
    PList_delete(oldRgns);

    delSize = PList_size(oldFaces);
    for(int iDel=0; iDel<delSize; iDel++) {
      face = (pFace)PList_item(oldFaces,iDel);
      EN_unlabelBLEntity((pEntity)face);
      M_removeFace(mesh,face);
    }
    PList_delete(oldFaces);

    delSize = elist.size();
    for(int iDel=0; iDel<delSize; iDel++) {
      edge = elist[iDel];
      EN_unlabelBLEntity((pEntity)edge);
      M_removeEdge(mesh,edge);
    }
    // do NOT delete elist as LayerEdgeSwapMod uses it
    // over and over (i.e., it is cleared and updated after every apply)

    /// Delete old BLs
    for (int iBL = 0; iBL < 2; ++iBL)
    {
//      EG_clear(old_BLs[iBL]);
      M_removeEntGrp(mesh, old_BLs[iBL]);
    }

    return 1;
  }

  pPList E_swapOnBLInterface(pMesh mesh, pEdge edge, pPList eregs, int c, pPList oldRgns, pPList oldFaces) {
    
    pRegion region;
//     pPList eregsTmp = E_regions(edge);
//     pPList eregs = PList_new();
//     int size = PList_size(eregsTmp);
//     for(int iRgn=0; iRgn<size; iRgn++) {
//       region = (pRegion)PList_item(eregsTmp,iRgn);
//       if(!EN_isBLEntity((pEntity)region))
// 	PList_append(eregs,region);
//     }
//     PList_delete(eregsTmp); 
    
    /* check if swap configuration already available */
    if (sc.edge != edge)
      if (!fromMeshTools::E_numSwpCfg(edge)) {
	// *newRegions = PList_new();
	// return 0;
	cout<<"\nError in fromMeshTools::E_swapOnBLInterface()"<<endl;
	cout<<"swap configuration is NOT already available"<<endl;
	exit(0);
      }
    
    sc.edge = 0;
    
    int i;
    pVertex e_verts[2];
    /*  Get 2 end vertices */
    for ( i=0 ; i<2 ; i++ ) 
      e_verts[i]= E_vertex(edge,i);
    
    int j, nonManif=0, qeDir[2], fGFaceDir=-1;
    pVertex oppV[2];
    pEdge  quadEdge[2];
    pFace face, eface[2];
    pRegion frgn;
    void *temp;
    pGRegion gregions[2];
    pGEntity egent = E_whatIn(edge);
    pGEntity greg = (pGEntity)R_whatIn((pRegion)PList_item(eregs,0));

    /* Check if interface edge is being swapped on a non-manifold face */
    if (GEN_type(egent) == Gface) {
      if (GF_region((pGFace)egent,0) && GF_region((pGFace)egent,1)) {
	
	/* On the non-manifold model face itself, the change in the */
	/* triangulation will be a diagonal swap of the quad formed */
	/* by the two mesh faces of the mesh edge classified on the */
	/* the model face. Collect this info in a specific manner   */
	/* (according to a template) so that later on it will be    */
	/* possible to figure out the orientation of 2 new faces    */
	/* classified on the model face                             */
	
	for (j = 0, i = 0; (j < E_numFaces(edge)) && (i < 2); j++) {
	  face = E_face(edge,j);
	  if (F_whatInType(face) == Gface) {
	    eface[i] = face;
	    oppV[i] = F_edOpVt(face,edge);
	    i++;
	  }
	}
	
	if( (F_region(eface[0],0) && F_region(eface[0],1)) && 
	    (F_region(eface[1],0) && F_region(eface[1],1)) )
	  {
	    
	    nonManif = 1;

	    /* Should we use the modeler interface call C_F_region here? */
	    gregions[0] = GF_region((pGFace)egent,0); 
	    gregions[1] = GF_region((pGFace)egent,1);
	    
	    if (F_dirUsingEdge(eface[0], edge)) {
	      temp = eface[0]; eface[0] = eface[1]; eface[1] = (pFace)temp;
	      temp = oppV[0]; oppV[0] = oppV[1]; oppV[1] = (pVertex)temp;
	    }
	
	    /* Get a pair of opposite edges of the 'quad' and the way they */
	    /* use the connected mesh face classified on the model face    */
	    /* In the swapped cfg, these 2 edges will still belong to 2    */
	    /* different mesh faces classified on the model face and these */
	    /* faces will continue to use the edges in the same sense      */
	    
	    quadEdge[0] = F_vtOpEd(eface[0], e_verts[1]);
	    qeDir[0] = F_dirUsingEdge(eface[0], quadEdge[0]);
	    quadEdge[1] = F_vtOpEd(eface[1], e_verts[0]);
	    qeDir[1] = F_dirUsingEdge(eface[1], quadEdge[1]);
	    
	    /* Also determine orientation of mesh faces w.r.t. model face */
	    
	    if (gregions[0] != gregions[1]) {
	      if (frgn = F_region(eface[0],0))
		fGFaceDir = ((pGRegion)R_whatIn(frgn) == gregions[0]);
	      else if (frgn = F_region(eface[0],1))
		fGFaceDir = ((pGRegion)R_whatIn(frgn) == gregions[1]);
	      else
		fGFaceDir = 1;
	    }
	    else {
	      /* Have to determine it differently. How?*/
	      fGFaceDir = 1;
	    }
	  }
      }
    }
    
    // pPList *newRegions;
     // *newRegions = PList_new();
    if (!c && !sc.nbr_triangles)
      /* This is the special case where only configuration is valid       */
      /* unless the resulting mesh will violate topological compatibility */
      /* (this is checked during the actual swap operation)               */
      {	
	cout<<"\nError in fromMeshTools::E_swapOnBLInterface()"<<endl;
	cout<<"special case of E_swp2Fac detected in bdry. layer mesh"<<endl;
	exit(0);
      }
    
    int c2, t;
    pVertex tvert[MAX_TRIANGLES][3];

    if (c >= sc.nbr_trianguls)
      return 0;
    
    /* Have to find the c'th *topologically valid* configuration */
    for (c2 = 0, j = -1; c2 < sc.nbr_trianguls; c2++) {
      if (sc.topoValidCfg[c2]) j++;
      if (j == c) break;
    }
    
    /* evaluate the triangles of the c'th configuration */
    for ( j=0 ; j < sc.nbr_triangles_2 ; j++ ) {
      t = sc.trianguls[c2][j];
      tvert[j][0] = sc.pverts[sc.triangles[t][0]] ;
      tvert[j][1] = sc.pverts[sc.triangles[t][1]] ;
      tvert[j][2] = sc.pverts[sc.triangles[t][2]] ;   
    }
    
    if (nonManif) {
      /* Classify the edge being swapped and the connected faces on the */
      /* model face as being classified in the interior                 */
      
      E_setWhatIn(edge,(pGEntity)greg);
      F_setWhatIn(eface[0],(pGEntity)greg);
      F_setWhatIn(eface[1],(pGEntity)greg);
    }

    int Dir, nbr, dir;
    int *modelDir = &Dir;
    *modelDir = -1;
    pEdge ledge = edge;
    pPList faces = PList_new(), regions = eregs;
    /* based on E_getCavityBdry() */
    temp = 0;
    while ( region = (pRegion)PList_next(regions,&temp) ) {
      nbr = R_numFaces(region) ;
      for ( j= 0 ; j< nbr ; j++ ) {
	face = R_face(region,j);
	/* Check if edge is in closure of face */
	if ( !F_inClosure(face,(pEntity)ledge )) {
	  dir = R_faceDir(region,j);
	  EN_attachDataI((pEntity)face,"fdir",dir) ;
	  PList_append(faces,face) ;
	}
	else {
	  if ( F_whatInType(face) == Gface ) 
	    *modelDir = R_faceDir(region,j) ;
	}
      }
    }

    /* Create new regions */
    int tri_nbr = sc.nbr_triangles_2;
    // PList_delete(*newRegions); /* This is silly but a whole bunch of routines */
    /* don't check if *newRegions is 0 and until   */
    /* they change, it'll have to stay this way    */
    pPList newregions = PList_new();
    PList_delete(newregions);
    newregions = E_swpCrtRegs(mesh,tri_nbr,tvert,e_verts,(pGEntity)greg,faces,Dir) ;
    PList_delete(faces);

//     temp = 0 ;
//     while ( frgn = (pRegion)PList_next(eregs,&temp) ) 
//       M_removeRegion(mesh,frgn);
    PList_appPListUnique(oldRgns,eregs);

    faces=E_faces(edge);
//     temp = 0 ;
//     while ( face = (pFace)PList_next(faces, &temp) ) {
//       if( F_typeInBL(face)!=fVERTICAL_QUAD ||
// 	  F_typeInBL(face)!=fVERTICAL_TRI )
// 	M_removeFace(mesh,face);
//     }
    PList_appPListUnique(oldFaces,faces);
    PList_delete(faces) ;

    // edge is deleted in Layer_E_swap()  
//     M_removeEdge(mesh,edge);

    if (!nonManif) {
      // return *newRegions;
      return newregions;
    }
    else {
      cout<<"\nError in fromMeshTools::E_swapOnBLInterface()"<<endl;
      cout<<"cannot handle non-manifold model as of now"<<endl;
      exit(0);
    }

  }


  /* also works for layer edges (at interface) */
  int E_numSwpCfg(pEdge edge) {
    pGEntity mface, greg=0;
    pRegion  region,cur_region,nxt_region;
    pFace    face, face_2,cur_face,nxt_face;
    pEdge    edge_2, edge_3, gfedge;
    pPList   eregs;
    pVertex  verts[4], gfverts[2], vtx;
    int      etype = E_whatInType(edge);
    int      i,j,k,n=0,nbr=0,numFaces, numEdges, dir, dir_2, nonManif=0, ncfg=0;
    int      found = 0, count = 0, c, t;
    void     *temp = 0;
    pVertex e_verts[2];
    int link_nbr;
    int *ngb_pids[2];
    int PInumtids;
    int PImytid;
    int link_nbrs[2];
    int ngb_pid;
    pVertex ngb_vert;
    int status;

    if (etype == Gedge)
      return(0) ;

    /* Check if the edge is on a non-manifold face - need to manage */
    /* data differently in that case                                */
    if ( etype == Gface ) {
      /* check if model face is used by less/more than one model
         region (non-manifold)                              */
      mface = E_whatIn(edge) ;
      if (GF_region((pGFace)mface,0)) n++;
      if (GF_region((pGFace)mface,1)) n++;
      if (n == 0)
        return(-2) ;
      else if (n == 2)
        nonManif = 1;
    }
/*
#ifdef MPI
    //  Cannot do if edge on part. bdry

    link_nbr= pmdb_en_num_iplinks(edge);
    if ( link_nbr > 0 ) {
      return(0);
    }
#endif
*/
    /* get 'face' that connects to edge. if one classified Tface, take that
       one, otherwise take any (e.g. last one) */

    int iFRgn = 0;
    int BLEdge = EN_isBLEntity((pEntity)edge);
    numFaces = E_numFaces(edge) ;
    if(!BLEdge) {
      for ( i= 0 ; i < numFaces ; i++ ) {
        face = E_face(edge,i) ;
        if ( F_whatInType(face) == Gface )
          break ;
      }
    }
    else {
      int foundIntrFc = 0;
      for ( i= 0 ; i < numFaces ; i++ ) {
        face = E_face(edge,i) ;

        // edge at interface (assuming it to be in the interior)
        if(F_whatInType(face) == Gface && !nonManif)
          return 0;

        if ( F_atBLInterface(face,&iFRgn)==1 ) {
          foundIntrFc = 1;
          break ;
        }
      }

      if(!foundIntrFc) {
        cout<<"\nError in fromMeshTools::E_numSwpCfg()"<<endl;
        cout<<"interface face NOT found"<<endl;
        exit(0);
      }
    }

    /* keep track of 0 region connected to face */
    if ( !(region = F_region(face,iFRgn)) ) {
      region = F_region(face,1-iFRgn) ;
      if ( !region ) {
        // ErrorHandler("Invalid or incomplete tet mesh?","E_numSwpCfg",WARN);
        adaptUtil::Error("E_numSwpCfg - Invalid or incomplete tet mesh?");
        return 0;
      }
    }

    /* determine right away which of the 2 end-vertices of 'edge' is the top
       (bottom) w/r to the orientation associated polygon */

    verts[0] = F_edOpVt(face,edge);
    verts[1] = R_fcOpVt(region,face);
    verts[2] = E_vertex(edge,0);
    verts[3] = E_vertex(edge,1);

    /* get 'edge_2' connecting verts[0], verts[1] */
    edge_2 = E_exists(verts[0],verts[1]) ;

    /* Get the face which is adjacent to the "face" along the
       vertex "verts[0]" for the region */

    numEdges = F_numEdges(face);

    for ( i = 0 ; i < numEdges ; i++ ) {
      if ( (edge_3 = F_edge(face,i)) != edge ) {
        face_2 = E_otherFace(edge_3,face,region) ;
        if ( F_edOpVt(face_2,edge_2) == verts[2] )
          break ;
      }
    }

    if ( !face_2 ) {
      // ErrorHandler("missing face","E_getSwpVrt",WARN) ;
      adaptUtil::Error("E_getSwpVrt - missing face");
      return 0;
    }

    /* get how the region use that face */
    dir = R_dirUsingFace(region,face_2) ;

    /* get how the face use the segment verts[0]-verts[1] */
    dir_2 = F_dirUsingEdge(face_2,edge_2) ;

    if ( E_vertex(edge_2,0) != verts[0] )
      dir_2 = 1 - dir_2 ;

    /* Now we have got all the information necessary for
       determining the top and the bottom vertex, return
       the vertices */

    sc.top_vert= verts[2] ;
    sc.bot_vert= verts[3] ;
    if ( dir_2 != dir )  {
      sc.top_vert= verts[3];
      sc.bot_vert= verts[2];
    }

    /* Start at one of the face connected to the edge being
       swapped, get the opposite vertex for the face,
       1) Include this vertex in the list of vertices for the face
       2) Get the other face and the region from the given face
       3) Break out of the loop if we hit the start region or NULL
    */

    /* Also, for the case where the edge is classified on a model face   */
    /* store the two vertices opposite to edge and classified on closure */
    /* of model face - will be useful for the non-manifold case          */

    gfverts[0] = verts[0]; /* Already have this from before */

    nbr = 0 ;
    cur_face = face ;
    cur_region = region ;
    while ( 1 ) {
      if ((cur_face != face) && (F_whatInType(cur_face) == Gface))
        gfverts[1] = F_edOpVt(cur_face,edge);

      if ( nbr > MAX_POLVERTS ) {
        // ErrorHandler("too many vertices","E_getSwpVrt",WARN) ;
        adaptUtil::Error("E_getSwpVrt - too many vertices");
        return(0) ;
      }
      sc.pverts[nbr] = F_edOpVt(cur_face,edge) ;
      nbr++ ;
      if ( !cur_region )
        break;

      nxt_face = E_otherFace(edge,cur_face,cur_region) ;
      /* get the next region */

      nxt_region = F_region(nxt_face,0) ;
      if ( !nxt_region || nxt_region == cur_region ) {
        nxt_region = F_region(nxt_face,1) ;
        if ( nxt_region == cur_region )
          nxt_region = NULL ;
      }

      if(BLEdge && F_atBLInterface(nxt_face)==1)
        nxt_region = NULL;

      if ( nxt_region == region )
        break;

      /* change of variables */
      cur_face = nxt_face;
      cur_region = nxt_region;
    }

    /* check if any edges exist between non-consecutive vertices of the
       polygon, these will cause invalid mesh on swapping */

    if ( nbr >= 4 ) {
      for ( i=0 ; i <nbr ; i++ )
        for ( j=(i+2) ; j<nbr-1 ; j++ )
          if (E_exists(sc.pverts[i],sc.pverts[j]))
            return(0) ;
    }

    sc.edge = edge; /* set the edge for which configuration is computed */

    if (nbr > 7)
      return 0;
    else if (nbr == 2) {
      sc.nbr_triangles = 0;  /* used in E_swap to identify this special case */

      if(BLEdge) {
        return 0;
//      cout<<"\nError in fromMeshTools::E_numSwpCfg()"<<endl;
//      cout<<"special case of E_swp2Fac detected in bdry. layer mesh"<<endl;
//      exit(0);
      }
/*
#ifdef MPI
      //  Check if opposite edge on part. bdry

      edge_2= E_exists(sc.pverts[0],sc.pverts[1]);
      if ( edge_2 == 0 ) {
        ErrorHandler("pb !","E_numSwpCfg",FATAL);
      }
      link_nbr= pmdb_en_num_iplinks(edge_2);
      if ( link_nbr > 0 ) {
        return(0);
      }
#endif
*/
      return 1;
    }
    swapFct[nbr-3](&sc);
    for (i = 0; i < sc.nbr_triangles; i++) sc.valid[i] = 0;


    // OK 1  return 1;

    /*
      If edge classified on model face,
      cannot swap if new edge already there
      Check added by de Cougny as the code was upgraded to MPI
    */

    if ( etype == Gface ) {

      e_verts[0] = gfverts[0];
      e_verts[1] = gfverts[1];
      edge_2= E_exists(e_verts[0],e_verts[1]);
      if ( edge_2 != 0 ) {
        return(0);
      }
#if 0
#ifdef MPI
      /*
        The edge is not there on proc but could be off proc
        Be conservative:
        Do not do anything if the 2 verts are ngbing
        the same proc, since it s a necessary reason
        for the edge to exist off proc
      */

      MPI_Comm_rank(MPI_COMM_WORLD,&PImytid);
      MPI_Comm_size(MPI_COMM_WORLD,&PInumtids);

      for ( j= 0 ; j< 2 ; j++ )
        ngb_pids[j]= (int *)calloc(PInumtids,sizeof(int));
      for ( j= 0 ; j< 2 ; j++ ) {
        link_nbrs[j]= pmdb_en_num_iplinks(e_verts[j]);
        for ( k= 0 ; k< link_nbrs[j] ; k++ ) {
          pmdb_en_iplink(e_verts[j],k,&ngb_pid,&ngb_vert);
          ngb_pids[j][k]= ngb_pid;
        }
      }
      status= FALSE;
      for ( j= 0 ; j< link_nbrs[0] ; j++ ) {
        for ( k= 0 ; k< link_nbrs[1] ; k++ ) {
          if ( ngb_pids[1][k] == ngb_pids[0][j] ) {
            status= TRUE;
            break;
          }
        }
        if ( status == TRUE ) break;
      }
      for ( j= 0 ; j< 2 ; j++ )
        free(ngb_pids[j]);

      if ( status == TRUE ) {
        return(0);
      }
#endif
#endif
    } /* End if type == FACE */


    ncfg = sc.nbr_trianguls;

    for (c = 0; c < sc.nbr_trianguls; c++)
      sc.topoValidCfg[c] = 1;


    if (nonManif) {
      /* if the edge is classified on a non-manifold face, the only configs */
      /* that are valid are those that include a connection between the 2   */
      /* vertices of the polygon that are classified on the closure of the  */
      /* model face.                                                        */

      for (c = 0; c < sc.nbr_trianguls; c++) {

        /* Check the connections of the c'th configuration */
        for (j = 0, found = 0; (j < sc.nbr_triangles_2) && !found; j++) {
          t = sc.trianguls[c][j];

          for (k = 0, count = 0; k < 3; k++) {
            vtx = sc.pverts[sc.triangles[t][k]];
            if (vtx == gfverts[0] || vtx == gfverts[1])
              count++;
          }

          /* If both the opposite vertices were found in the polygon */
          /* then the desired edge exists in this config             */
          found = (count == 2) ? 1 : 0;
        }

        if (!found) {
          /* Necessary connection does not exist; */
          /* flag this triangulation as invalid   */
          sc.topoValidCfg[c] = 0;
          ncfg--;
        }
      }
    }

    return ncfg;
  }


}   // namespace ends
