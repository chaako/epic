/*
  common interface for local modifications:
  - edge collapse
  - edge/face swap
  - edge split
  - vertex motions
  - region collapse on model boundary
  - two splits followed by a collapse
  - a split  followed by a collapse

  Updated: 2/23/01
           6/15/01
           8/05/02  add the option to control volume/area change
*/
#ifndef _H_LocMeshMod
#define _H_LocMeshMod

#include "sizeFieldBase.h"
#include "meanRatio.h"
#include "EvalResults.h"
#include "MeshTools.h"

/* type of model geometry */
typedef enum modelType { 
  PARAM, 
  NOPARAM 
} modelType;

class locMeshMod
{
 protected:
  /* the mesh */
  pMesh mesh;
  /* the mesh size field */
  pSField pSizeField;
  /* the measures to evaluate the local modification */
  MeanRatio *shpMeasure;
  /* the result container for the modification */
  evalResults *results;
  /* indicate if the classified model has parameter values */
  modelType model_type;
  /* control if calculation continues when there is a valid but 
     not acceptable region. If 1, continues*/
  int AcptControl;
  /* volume/area conservation control: 0 - not care; 1 - care volume/area */ 
  /* note that we do not care the volume change due to the vertex motion */
  int checkVolume;    
  double dV_limit,dA_limit;
  /* set callback function */
  CBFunction function_CB;     // the callback function
  void *userData_CB;          // the data set by the user and to be passed
  CBFunc_move CB_move;      
  void *userData_CB_move;   

  /* indicate a possible pre-repositioning of a mesh vertex */
  pVertex vertMv;
  double target[3];
#ifdef CURVE
  bool quadratic; // May 1, 2010, QLU
#endif //CURVE
 public:
  locMeshMod(pMesh p, pSField sf, MeanRatio *m, evalResults *r):
    mesh(p), pSizeField(sf), shpMeasure(m), results(r), model_type(PARAM),
    AcptControl(0), checkVolume(0), vertMv(0), function_CB(0), CB_move(0) {}
  virtual ~locMeshMod() {}

  /* set member data individually */
#ifdef CURVE
  void setCurved() { quadratic=true; }
  void unsetCurved() { quadratic=false; }
  
#endif //CURVE
  void setShapeMeasure(MeanRatio *m) { shpMeasure=m; }
  void setResultHolder(evalResults *r) { results=r; }
  void setModelType(modelType t) { model_type=t; }
  void setAcptControl(int t) { AcptControl=t; }
  void setCheckVolume(double dv, double da) { checkVolume=1; dV_limit=dv; dA_limit=da; }
  void setVertMotion(pVertex v, double *t)
    { vertMv=v; target[0]=t[0]; target[1]=t[1]; target[2]=t[2]; results->reset(); }
  void setCallback(CBFunction CB, void * userData)
    { function_CB=CB; userData_CB=userData; }
  void setCallback (CBFunc_move CB, void *userData)
    { CB_move=CB; userData_CB_move=userData; }

  /* get private data */
  MeanRatio *getShapeMeasure() { return shpMeasure; }
  evalResults *getResultHolder() { return results; }

  /* the common interface */
  
  /* check the topology validity of this modification */
  virtual int topoCheck() = 0;
  /* ensure no element turning inside out, and geometry similarity for bdry entity */
  virtual int geomCheck() = 0;
  /* retrieve size information */
  virtual int sizeCheck() = 0;
  /* get the mesh regions to be affected by this modification */
  virtual void getAffectedRgns(pPList *) = 0;
  /* perform the modification with new elements not returned */
  virtual int apply() = 0;
  /* perform the modification with new elements returned */
  virtual int apply(pPList *) = 0;

  /* return the type of this modification */
  virtual modType type() = 0;
  
};

#endif
