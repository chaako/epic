#ifndef _H_EdgeCollapsMod
#define _H_EdgeCollapsMod

#include "LocMeshMod.h"

#include <map> // May 1, 2010, QLU

class edgeCollapsMod: public locMeshMod
{
 public:
  
  edgeCollapsMod(const edgeCollapsMod &);
  edgeCollapsMod(pMesh,pSField,MeanRatio *,evalResults *);
  edgeCollapsMod(pMesh,pSField,MeanRatio *,evalResults *,pVertex,double *);
  ~edgeCollapsMod() { }

  /* the common local modification interface */
  virtual int topoCheck();
  virtual int geomCheck();
  virtual int sizeCheck();
  virtual void getAffectedRgns(pPList *);
  virtual int apply();
  virtual int apply(pPList *);
#ifdef MATCHING
  int apply(pPList*, pPList*, pPList*);
#endif
  virtual modType type() { return ECOLAPS; }

  /* specific member functions for edge collapse */
  void setCollaps(pEdge e, pVertex d, pVertex r) 
    { edgeDel=e; vd=d; vr=r; results->reset(); }

  pEdge edgeD() { return edgeDel; }
  pVertex vertD() { return vd; }
  pVertex vertR() { return vr; }
  void bdryCheck() { flag=1; }

 private:
  pEdge edgeDel;
  pVertex vd;
  pVertex vr;
  int flag;    // for boundary check
  std::map <pVertex, pPoint> newEdgeNodes;  // May 1, 2010, QLU
 protected:
  /* functions to check parametric span on periodic model face/edge */
  int GF_checkPeriodicSpan(pGFace);
  int GE_checkPeriodicSpan(pGEdge);
};

/**
   implementation of (copy) constructors
   consider linear case as default
   quadratic = false to start with
   
   May 1, 2010, QLU
*/
inline edgeCollapsMod::edgeCollapsMod(const edgeCollapsMod &x)
  : locMeshMod(x.mesh, x.pSizeField, x.shpMeasure, x.results) 
{
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;    
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;
  CB_move=x.CB_move;
  userData_CB_move=x.userData_CB_move;

  edgeDel=x.edgeDel;
  vd=x.vd;
  vr=x.vr;
  flag=x.flag;

  vertMv=x.vertMv;
  target[0]=x.target[0];
  target[1]=x.target[1];
  target[2]=x.target[2];
#ifdef CURVE
  quadratic = x.quadratic; // May 1, 2010, QLU
#endif // CURVE
}

inline edgeCollapsMod:: edgeCollapsMod(pMesh p, pSField mf, MeanRatio *m,
				       evalResults *r)
  : locMeshMod(p,mf,m,r)
{
 edgeDel=0; 
 vd=0; 
 vr=0; 
 flag=0;
#ifdef CURVE
 quadratic = false; // May 1, 2010, QLU
#endif //CURVE
}

inline edgeCollapsMod::edgeCollapsMod(pMesh p, pSField mf, MeanRatio *m,
				      evalResults *r, 
				      pVertex v, double *t)
  : locMeshMod(p,mf,m,r), edgeDel(0), vd(0), vr(0), flag(0)
{ 
  vertMv=v;
  target[0]=t[0];
  target[1]=t[1];
  target[2]=t[2];
#ifdef CURVE
  quadratic = false; // May 1, 2010, QLU
#endif //CURVE
}

#endif

