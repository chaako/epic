/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Rao Garimella
  Creation  : 
  Modifi.   : 
  Function  :
    Evaluate if the regions/faces created by collapsing an edge are valid
    Procedure uses comparison of model face to mesh face normal to see if
    mesh faces are inside out. Since it is known that is not the most robust
    way of checking validity, this routine may be rewritten sometime 
    AND ITS ARGUMENTS MIGHT CHANGE
-------------------------------------------------------------------------*/
#include "FMDB.h"
#include "fromMeshTools.h"
#include "Defines.h"

int E_evalColapsOnGFace(pMesh mesh, pEdge cedge, pVertex vertd, pVertex vertr,
			double *normal){
  pPList vfaces, fverts;
  pVertex vertex, fv[4];
  pFace face;
  void *temp1=0, *temp2=0;
  double oxyz[4][3],xyz[4][3],cosangs[3],fnormal[3],v01[3],v02[3];
  int i=0,j,num,ok;
  
  for(i=0;i<4;++i) fv[i]=(pVertex)0;
  vfaces = V_faces(vertd);
  temp1 = 0;
  while (face = (pFace) PList_next(vfaces,&temp1)) {
    if (F_inClosure(face,cedge)) continue;

    fverts = F_vertices(face,1);
    num=PList_size(fverts);
    temp2 = 0; i = 0;
    while (vertex = (pVertex) PList_next(fverts, &temp2)) {
      fv[i] = vertex;
      V_coord(vertex,xyz[i]);
      for (j = 0; j < 3; j++) oxyz[i][j] = xyz[i][j];
      if (vertex == vertd) {
	fv[i] = vertr;
	V_coord(vertr,xyz[i]);
      }
      i++;
    }
    PList_delete(fverts);

    /* We have to check if the colapse will create two coincident faces.
       Can happen in some situations when an face already exists between
       the vertices of a to-be-created face - e.g. at a model vertex
       where two model faces share two model edges
       */
    
    if (F_exists(Tvertex,fv[0],fv[1],fv[2],fv[3])) {
      PList_delete(vfaces);
      return 0;
    }

    diffVt(oxyz[1],oxyz[0],v01);
    diffVt(oxyz[2],oxyz[0],v02);
    crossProd(v01,v02,fnormal);
    normVt(fnormal,fnormal);
    /*
    if (!XYZ_FAngles(xyz,fnormal,cosangs)) {
      PList_delete(vfaces);
      return 0;
    }
    */
    
    if(num==3)
      ok=XYZ_checkFlatTri(xyz,fnormal);
    else
      if(num==4)
	ok=XYZ_checkFlatQuad(xyz,fnormal);
    else
      MT_ErrorHandler("Face having more than 4 vertices not suported",
		   "E_evalColapseOnGFace",WARN);
    if(ok){
      PList_delete(vfaces);
      return(0);
    }

  }

  PList_delete(vfaces);
  return 1;
}
		  
