#ifndef _H_SNAP
#define _H_SNAP

#include "AdaptUtil.h"
#include "VertMotionMod.h"
#include "scorecSSList.h"
#include "meanRatio.h"
#include <list>
using std::list;

#ifdef MA_PARALLEL
#include "pmMigrationCallbacks.h"
#include <algorithm>
//using AOMD::pmMigrationCallbacks;
using std::pair;
#endif

class meshSnap {

 public:
  meshSnap(pMesh,pSField);
  meshSnap(pMesh, pSField, std::list<pVertex> *p);
  ~meshSnap();

  /// 1 - thickness, 2 - snapping
  void setBLAdapt(int value) { BLAdapt = value; }
  int getBLAdapt() { return BLAdapt; }

  void setCounterMax(int max) { counterMax = max; }
  void setDefaultCounterMax() { counterMax = 1; }
  int getCounterMax() { return counterMax; }

  void GetTarget(pVertex, double *&);
  void freeTarget(pVertex);
  void append(pVertex, double *);
  void remove(pVertex);
  void setModelType(modelType p) { model_type=p; }
  void setCallback (CBFunction, void *);
  void setCallback (CBFunc_move, void *);
  void setMinLenSq(double u) { lowerLenSqBound=u; }
  void setDefaultMinLenSq() { lowerLenSqBound=SNAP_LOWERLENSQBOUND; }
  void setMaxLenRatioSq(double u) { upperLenSqBound=u; }
  void setDefaultMaxLenSq() { upperLenSqBound=SNAP_UPPERLENSQBOUND; }
  void setGeoSimCheck(int c) { GeoSimCheck=c; }

  void GetSetRemovedVtx(std::set<pVertex> &pSetRemovedVtx);

#ifdef MA_PARALLEL
  int run(pmMigrationCallbacks&);
  int M_removeDissimFaces(pmMigrationCallbacks&);
#else
  int run();
  int M_removeDissimFaces();
#endif
//  SCOREC::Util::scorecSSList<pVertex> *getUnSnappedVerts() { return pSnaplist; }

 protected:

  int BLAdapt;
 
  int counterMax;
 
  /* the user input data that drive vertex snapping  */
  pMesh pmesh;
  pSField pSizeField;
  int nullFieldFlag;
  double lowerLenSqBound;
  double upperLenSqBound;
  modelType model_type;
  int GeoSimCheck;            // default=1: check geometry similarity after snapping
  std::list<pVertex> *pSnaplist; // the vertex list to be snapped

  /* handles used  */
  pMeshDataId ptr_xyz;      // a handle to attach the target location of snapping vertices 
  pMeshDataId int_snap;     // a handle used in cavity-construction & vertex motions
  pMeshDataId ptr_remesh;   // a handle used in cavity-construction 

  pMeshDataId int_geoSim;   // a handle to indicate if geometric similarity is checked
  pMeshDataId ptr_GFparams; // a handle to store re-paramertized values on GFace 

  /* callback function for mesh modifications */
  CBFunction function_CB;     // the callback function
  void *userData_CB;          // the data set by the user and to be passed
  CBFunc_move CB_move;        // activated by vertex motion
  void *userData_CB_move;   

  // private data for collectiong information
  int nToFPP;
  int nEclps;
  int nLEclps;
  int nRclps;
  int nEswap;
  int nFswap;
  int nVmove;
  int nSpltClps;
  int nTwoSpltClps;
  int nEsplt;
  int nByMod;
  int nNewVerts;

  /* mesh tolerance */
  double mtol;

  /* this list is used to hold removed verticies that remain in the snap list */ 
  std::set<pVertex> pRemovedVerts;

  /* shape measure used throughout the module*/
  MeanRatio *shpMeasure;
  evalResults *result;

  /* ---- the internal data used when snapping a specific vertex ---- */

  /* used by snapping through local mesh modification */
  pVertex vert;         // the current vertex to be snapped
  double *target;       // a possible location to move

  int valid;            // indicate if moving to target is valid: 1-valid; 0-not valid    
  SCOREC::Util::scorecSSList<pRegion> *pb_regions;    // list of problem mesh regions
  pPList pb_faces;      // list of not geometry similar mesh faces
  double int_xyz[3];    // the location to move the snapping vertex 

  pPList comEdges;      // common mesh edges shared by problem regions on FPP
  pFace pb_face;        // one of the problem faces on the first problem plane
  pRegion pb_region;    // the region bounded by "vert" and "pb_face"
  
  /* used by cavity meshing */
  pPList coveredVts;   // list of vertices initially at B(P(M00))
  pPList coveredEds;   // list of edges initially at B(P(M00)) 

  /* ---- end of internal data ----*/  

  // determine & apply local mesh modification
  void apply(std::list<pVertex>::iterator &, pMeshMod);
  void computeTarget(pVertex);
  int checkSnapTarget(pVertex);
  void freeReparam(pVertex);
  void delete_vertex(pVertex);
  void FirstPbPlane(double[3]);
  void commonEdges(pPList);
  void clpsToFPP(pMeshMod *);
  int getLocMod(pMeshMod *);
  int clpsTetEdges(pMeshMod *);
  void eliminateCommonEdge(pEdge,pEclpsMod,pMeshMod *,double *);
  int clpsBdryPbTet(SCOREC::Util::scorecSSListIter<pVertex> *);
  int swapOrsplitPbTet(pMeshMod *);
  void splitEntOnCloseGEnt(pEntity[4], pMeshMod *);
  int  localOpt();
  vertMotionsMod *VertexMotion();

  // check & fix geometric similarity
  int V_checkGeoSim();
  int fixGeoSim(pFace, list<pFace> *, int, SCOREC::Util::scorecSSList<pFace> *, int&);
  int isFacesGeoSimiliar(pPList *); 

  int V_snapValid2D();
  int snapSurfaceMesh();

  // determine & retriangulate a boundary cavity
  int cavity_retriangulation(pVertex, double *, pPList &);
  int isTriangulationValid(pPList *, pVertex, double *);
  //  void copyLocalSurfMesh(pMesh, pPList *, pVertex, pPList *, pPList *);  
  int newsurfTrigulation(pMesh, pPList *, pVertex, double[3], pPList *, pPList *);
  void improveNewSurfMesh(pGFace, pPList &, pPList, pVertex);
  int ensureSimilarity(pPList &,pPList &,pVertex);
  void traceReplacedBdry(SCOREC::Util::scorecSSList<pFace> &, pPList &);
  int removeIntersections(pPList &, pPList &, SCOREC::Util::scorecSSList<pFace> &, pGRegion, SCOREC::Util::scorecSSList<pFace>&);
  int processIntersection_1(pGRegion, pPList &, pPList &, SCOREC::Util::scorecSSList<pFace> &);
  int processIntersection_2(pGRegion, pPList &, pPList &, SCOREC::Util::scorecSSList<pFace> &, int);
  void removeDiscEntities(pGRegion, pPList &, SCOREC::Util::scorecSSList<pFace> &);
  void reclassifyReplacedBdry(pGRegion, SCOREC::Util::scorecSSList<pFace> &);
  void expandCavity(pRegion, SCOREC::Util::scorecSSList<pFace> &, pPList *, int);
  int expandCavityAtBdry(pFace, pFace, pPList &, SCOREC::Util::scorecSSList<pFace> &, pPList *, int);
  int splitSnapBPM00(pFace, pPList &, SCOREC::Util::scorecSSList<pFace> &, pPList *, int);
  int updateBPM00(pPList &, SCOREC::Util::scorecSSList<pFace> &);
  int E_numSSListFace(SCOREC::Util::scorecSSList<pFace> &,pEdge);
  int reshapeTPM00(pFace, pFace, pPList &);
  void deleteFace(pFace, pPList *,int);
  void removeCloseEntities(pPList &,pPList &,SCOREC::Util::scorecSSList<pFace> &);
  void interpMSizeAtVertex(pVertex vertex,pPList cavity);
#ifdef DEBUG
  void checkCavity(pPList);
#endif

#ifdef MA_PARALLEL
  pMeshDataId numReceive; 
  
  void unifySnapList();
  void unifySnapListBL();
  int run_2(pPList&, pmMigrationCallbacks&);
  int sendSnapInfo(pVertex, int);
  int receiveSnapInfo(list<pEntity>& , int*);
  pEntity F_inClosureCBEnt(pFace);
  int V_inPairList(list<pair<pEntity,pEntity> >&, pVertex);
  void deleteDimReduction(list<pair<pEntity,pEntity> >&, list<pEntity>&, pmMigrationCallbacks&);
  void deleteDimReduction(std::list<pFace>&, pmMigrationCallbacks&);
  int migrateMesh(list<pair<pEntity,pEntity> >&, list<pEntity>&, pmMigrationCallbacks&);
  int migrateMeshForSnapBL(list<pair<pEntity,pEntity> >&, list<pEntity>&, pmMigrationCallbacks&);
  int migrateMesh_2(std::list<pEntity>&, std::list<pFace>&, pmMigrationCallbacks&);
 
#else
  int run_2(pPList &);
#endif
};

#endif

