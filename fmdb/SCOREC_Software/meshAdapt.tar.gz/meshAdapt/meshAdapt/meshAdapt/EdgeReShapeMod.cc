#ifdef CURVE

#include "EdgeReShapeMod.h"
#include "curveMesh.h"
#include "AdaptUtil.h"
#include "curveUtil.h"
#include <iostream>
#include <math.h>

using namespace adaptUtil;
using namespace curveUtil;

// find the key edges for the region
void  edgeReShapeMod::findKeyEdges(pPList *elist)
{
  
  int j, ee_id[4][3] = {{0, 2, 3},{1, 0, 4},{2, 1, 5},{3, 5, 4}};
  pEdge edge;
  
  // get the edges of the region
  pPList relist = R_edges(theRegion, 1);

  for(j=0; j<3; j++) {
    edge = (pEdge)PList_item(relist, ee_id[keyIndex][j]);
    PList_appUnique(*elist, edge);
    keyDirs[edge] = j;
  }
  
  PList_delete(relist);

  return;
  
}

int edgeReShapeMod::apply(pPList *elist) {
  pPoint pt = E_point(keyEdge, 0);
  P_setPos(pt, new_xyz[0], new_xyz[1], new_xyz[2]);
  *elist = E_regions(keyEdge);
}
 
// compute the middle point target
int edgeReShapeMod::computeMiddlePtTarget()
{

  pEdge edges[3], edge;
  pPList relist = R_edges(theRegion, 1);
  
  int i, k, l, j, flag = 0, ee_id[4][3] = {{0, 2, 3}, {1, 0, 4}, {2, 1, 5},{3, 5, 4}};
  double v[3][3], vxyz[3], nv[3][3], shape;
  pVertex vert; ;
  double cv[3], mvxyz[3], dist, detj, len;
  double vtxyz[2][3], ptxyz[3];
  
  // find the three edges;
  edges[0] = keyEdge;
  for(k = 0, l=1; k<3; k++) {
    edge = (pEdge)PList_item(relist, ee_id[keyIndex][k]);
    if(edge != edges[0])
      edges[l++] = edge;
  }

  PList_delete(relist);
  
  // retrieve the control points of the three edges
  E_bezierCtrlPt(edges[0], v[0]);
  pPoint pt;
  if(E_numPoints(edges[0])) {
    pt = E_point(edges[0], 0);
    old_xyz[0] = P_x(pt);
    old_xyz[1] = P_y(pt);
    old_xyz[2] = P_z(pt);
  }
  else {
    pt = P_new();
    E_bezierCtrlPt(edges[0], old_xyz);
    P_setPos(pt, old_xyz[0], old_xyz[1], old_xyz[2]);
    E_setPoint(edges[0], pt);
  }
  
  
  for(int ll=0; ll<2; ll++)
    V_coord(E_vertex(edges[0], ll), vtxyz[ll]);
  
  if(E_whatInType(edges[0]) == 3) {

    if(keyDirs[keyEdge] == 1) {
      E_bezierCtrlPt(edges[1], v[2]);
      E_bezierCtrlPt(edges[2], v[1]);
    }else{
      E_bezierCtrlPt(edges[1], v[1]);
      E_bezierCtrlPt(edges[2], v[2]);
    }


    // retrieve the vertex 
    pPList rvlist = R_vertices(theRegion, 1);
    vert = (pVertex)PList_item(rvlist, keyIndex);
    V_coord(vert, vxyz);
    PList_delete(rvlist);
  
    // compute the three norms
    for(int ll=0; ll<3; ll++)
      diffVt(v[ll], vxyz, nv[ll]);
  
    crossProd(nv[1], nv[2], cv);
    detj = dotProd(cv, nv[0]);
    
    // compute the distance of the point to the plance
    dist = fabs(dotProd(cv, nv[0]))/sqrt(dotProd(cv, cv));
    
    // compute the mirror points (Bezier)
    len = sqrt(dotProd(cv, cv));
    for(int ll=0; ll<3; ll++)
      mvxyz[ll] = 1.5*dist*cv[ll]/len + v[0][ll];
  
  }else{
    // use blending mapping to compute the location for the edges on the model face
    pPList eflist = E_faces(edges[0]);
    pFace faces[2],f;
    int count = 0;
    for(int ll=0; ll<PList_size(eflist); ll++){
      f = (pFace)PList_item(eflist, ll);
      if(F_whatInType(f) == 2)
	faces[count++] = f;
    }
    PList_delete(eflist);
    
    computePtForOppEdge(edges[0], faces, mvxyz);
    
    diffVt(mvxyz, old_xyz, cv);
    
    len = sqrt(dotProd(cv, cv));
    
    dist = len;
  }
  
  // adjust the computed mv
  for(int ll=0; ll<3; ll++)
    ptxyz[ll] = 0.25*(vtxyz[0][ll] + vtxyz[1][ll]) + 0.5*mvxyz[ll];
  
  P_setPos(pt, ptxyz[0], ptxyz[1], ptxyz[2]);
  
  // check whether theRegion has been fixed
  int numIter = 2, new_index;
  crShpInfo csi;
  
  
  // retrieve the worst shape associated with the edges[0]
  double worstShape, newWorstShape, invalidShape, newInvalidShape; 
  pPList erlist = E_regions(edges[0]);
  int ok;
  double best_xyz[3];
  newInvalidRegions = PList_new();
  R_worstShape(&erlist, worstShape, invalidShape,  &newInvalidRegions);
  
  for(int ll=0; ll<3; ll++)
    best_xyz[ll] = ptxyz[ll];
  
  ok = PList_size(newInvalidRegions);
  
  while(1) {
    if(numIter==10)
      break;
    
    if(E_whatInType(edges[0]) == 3) {
      for(int ll=0; ll<3; ll++)
	mvxyz[ll] = (5.+(double)numIter)*dist*cv[ll]/len + v[0][ll];
    }
    else{
      // use bisection
      for(int ll=0; ll<3; ll++)
	mvxyz[ll] = 0.5*(v[0][ll] + mvxyz[ll]);
    }

    for(int ll=0; ll<3; ll++)
      ptxyz[ll] = 0.25*(vtxyz[0][ll] + vtxyz[1][ll]) + 0.5*mvxyz[ll];  
    P_setPos(pt, ptxyz[0], ptxyz[1], ptxyz[2]);

    PList_delete(newInvalidRegions);
    newInvalidRegions = PList_new();

    R_worstShape(&erlist, newWorstShape, newInvalidShape, &newInvalidRegions);
    
    if(!ok && PList_size(newInvalidRegions)) // the tried shape starts to cause invalid regions
      break;
    
    if(ok && !PList_size(newInvalidRegions)){ // the tried shape starts to eliminate all of the regions
      ok = 0; 
      invalidShape = newInvalidShape;
      worstShape = newWorstShape;
      for(int ll=0; ll<3; ll++)
	best_xyz[ll] = ptxyz[ll];
      continue;
    }
    
    if((newWorstShape < worstShape))// worst shape decreases
      break;
    
    if(ok && newInvalidShape < invalidShape)
      break;
        
    if((newWorstShape > worstShape) && (newInvalidShape >= invalidShape)) {
      invalidShape = newInvalidShape;
      worstShape = newWorstShape;
      for(int ll=0; ll<3; ll++)
	best_xyz[ll] = ptxyz[ll];
    } 
    numIter++;
  }

  PList_delete(erlist);
  
  
  for(int ll=0; ll<3; ll++)
    ptxyz[ll] = best_xyz[ll];
  P_setPos(pt, ptxyz[0], ptxyz[1], ptxyz[2]);

  flag = PList_size(newInvalidRegions);
  if(!ok || !flag) {
    results->setWorstShape(worstShape);
    PList_delete(newInvalidRegions);
    return 0;
  }
  else{     
    if(PList_inList(newInvalidRegions, (void*)theRegion))
      results->setWorstShape(-BIG_NUMBER);
    else
      results->setWorstShape(worstShape);
    PList_delete(newInvalidRegions);
    return flag;
  }
  
  return flag;
}



// check the validity of curving interior edge
int edgeReShapeMod::geomCheck()
{
  
  void *temp;
  pPList erlist = E_regions(keyEdge);
  pRegion rgn;
  int flag = 1, newindex, oldindex;
  double shape;
  crShpInfo csi;
  double worst2 = BIG_NUMBER;
  pPList newRlist = PList_new();
  map<pRegion, int> rgn_index;

  temp = 0;
  while(rgn = (pRegion)PList_next(erlist, &temp)) {
    if(!CR_isValid(rgn, &csi)) {
      PList_appUnique(newRlist, rgn);
      rgn_index[rgn] = csi.index;
    }else{
      if(csi.shape < worst2)
	worst2 = csi.shape;
    }
  }
  
  if(PList_size(newRlist)) {
    // There are some regions that are still invalid, but it may have two invalid corners
    temp=0;
    int ok2;
    pPoint pt = E_point(keyEdge, 0);
    double xyz[3];
    xyz[0] = P_x(pt); xyz[1] = P_y(pt); xyz[2] = P_z(pt);
    
    resetEdge();
    while(rgn = (pRegion)PList_next(newRlist, &temp)) {
      ok2 = CR_isValid(rgn, &csi);
      newindex = rgn_index[rgn];
      oldindex = csi.index;
      // The old shape is valid, the reshape only cause one invalid corner
      if(ok2 && (newindex < 4))
	continue;

      // The old shape has two invalid corners, while the reshape fix one
      if(!ok2 && (oldindex>3) && (newindex<4))
	continue;

      // Tough region, hard to fix
      flag=0;
    }
    
    P_setPos(pt, xyz[0], xyz[1], xyz[2]);
  }
  
  if(flag)
    results->setWorstShape(worst2);
  

  PList_delete(newRlist);
  PList_delete(erlist);

  return flag;
}

void edgeReShapeMod::getAffectedRgns(pPList *affrgns)
{  
  *affrgns = E_regions(keyEdge); 
  return;
}


void edgeReShapeMod::resetEdge()
{

  
  pPoint pt = E_point(keyEdge, 0);
  P_setPos(pt, old_xyz[0], old_xyz[1], old_xyz[2]);
  
}

#endif /* CURVE */
