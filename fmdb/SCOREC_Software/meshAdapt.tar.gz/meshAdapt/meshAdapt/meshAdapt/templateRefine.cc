#include "templateRefine.h"
#include "templateUtil.h"
#include "AdaptUtil.h"
#include "EdgeSwapMod.h"
#include "NullSField.h"
#include "meanRatio.h"
#include "fromMeshTools.h"
#include "MeshSize.h"

#include <stdio.h>
#include <math.h>
#include <vector>
#include <algorithm>
#include <iostream>

#include "BLUtil.h"

#ifdef AOMD_
#include "PList.h"
#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#include "mEntity.h"
#ifdef MA_PARALLEL
#include "paraAdapt.h"
#endif
#endif

#ifdef CURVE
#include "curveMesh.h"
#endif

#ifdef MVTK
#include "mvtk.h"
#endif

#include <set>
using std::set;

using std::cout;
using std::endl; 

int meshTemplate_counter=0;

meshTemplate::meshTemplate(pMesh m, pSField pf)
  : pmesh(m), pSizeField(pf), model_type(0), ChildToParent(0), function_CB(0)
{
  meshTemplate_counter++;
  char strI[28], strP[28];
  sprintf(strI,"refdref_indicator%d",meshTemplate_counter);
  sprintf(strP,"pointerToPList%d",meshTemplate_counter);
  int_reff=MD_newMeshDataId(strI);
  ptr_reff=MD_newMeshDataId(strP);
  split_id = MD_newMeshDataId("splitID");
  diagonalSelectionID = MD_newMeshDataId("Diagonals for BL stack");
//  ptr_update = MD_newMeshDataId("update_links_on_cb");
  pRefEdges=new std::list<pEdge >;
  pRefBLEdges=new std::list<pEdge >;
  pRefNonBLEdges = new std::list<pEdge>;
  steinerVerts=PList_new();
  ambigEdges=PList_new();

  curved2DSurface = 1;

  if( !pSizeField )
    { pSizeField=new NullSField(); nullFieldFlag=1; }
  else
    nullFieldFlag=0;
#ifdef AOMD_
#ifdef MA_PARALLEL
  vtIdTag=MD_newMeshDataId("vtIdTag");
#endif
#endif   
}


meshTemplate::meshTemplate(pMesh m, pSField pf, int s, 
			   std::vector< std::pair<pVertex,double *> > *p)
  : pmesh(m), pSizeField(pf), model_type(s), ChildToParent(0), function_CB(0)
{
  meshTemplate_counter++;
  char strI[28], strP[28];
  sprintf(strI,"refdref_indicator%d",meshTemplate_counter);
  sprintf(strP,"pointerToPList%d",meshTemplate_counter);
  int_reff=MD_newMeshDataId(strI);
  ptr_reff=MD_newMeshDataId(strP);
  split_id = MD_newMeshDataId("splitID");
  diagonalSelectionID = MD_newMeshDataId("Diagonals for BL stack");
//  ptr_update = MD_newMeshDataId("update_links_on_cb");
  pRefEdges=new std::list<pEdge >;
  pRefBLEdges=new std::list<pEdge >;
  pRefNonBLEdges = new std::list<pEdge>;
  steinerVerts=PList_new();
  ambigEdges=PList_new();

  curved2DSurface = 1;

  if(model_type)
    pSnap=p;

  if( !pSizeField )
    { pSizeField=new NullSField(); nullFieldFlag=1; }
  else
    nullFieldFlag=0;
#ifdef AOMD_
#ifdef MA_PARALLEL
  vtIdTag=MD_newMeshDataId("vtIdTag");
#endif
#endif
}

meshTemplate::~meshTemplate()
{
  MD_deleteMeshDataId(int_reff);
  MD_deleteMeshDataId(ptr_reff);
  MD_deleteMeshDataId(split_id);
  MD_deleteMeshDataId(diagonalSelectionID);
  delete pRefEdges;
  delete pRefBLEdges;
  delete pRefNonBLEdges;
  PList_delete(steinerVerts);
  PList_delete(ambigEdges);

  if( nullFieldFlag )
    delete (NullSField *)pSizeField;

#ifdef AOMD_
#ifdef MA_PARALLEL
  MD_deleteMeshDataId(vtIdTag);
#endif
#endif
  if( ChildToParent )
    MD_deleteMeshDataId(ChildToParent);
}


void meshTemplate::setCallback( CBFunction CB, void * userData )
{
  function_CB=CB;
  userData_CB=userData;
}

void meshTemplate::callCallback(pEntity old, pPList newElements, pVertex newv)
{
  if( function_CB ) {
    pPList oldElements=PList_new();
    PList_append(oldElements,old);
    (function_CB)(oldElements,newElements,userData_CB,R_REFINE,(pEntity)newv);
    PList_delete(oldElements);
  } 
  return;
}

pPList meshTemplate::getAttachPList(pEntity ent)
{
  void *temp_ptr;
  if(EN_getDataPtr(ent,ptr_reff,&temp_ptr))
    return (pPList)temp_ptr;
  return 0;
}

/* 
   tag/untag a mesh edge
*/
int meshTemplate::setRefineLevel(pEdge ed,int level)
{
  int value;
  static int count=0;
  
  switch( level ) {
  case 0:
    if( EN_getDataInt((pEntity)ed,int_reff,&value) ) 
    {
      EN_deleteData((pEntity)ed,int_reff);
      if (E_typeInBL(ed))
        pRefBLEdges->remove(ed);
      else
      {
        pRefEdges->remove(ed);  // O(N) - I hate doing this
        pRefNonBLEdges->remove(ed);
      }
    }
    else
      return 0;

    break;
  case 1:
    if (!EN_okTo(SPLIT,(pEntity)ed)) 
    {
      if( count < 4 ) 
      {
	pVertex v0,v1;
	pMSize ps0,ps1;
	double xyz[3];
	v0=E_vertex(ed,0);
	v1=E_vertex(ed,1);
	ps0=pSizeField->getSize(v0);
	ps1=pSizeField->getSize(v1);
	V_coord(v0,xyz);
#ifdef DEBUG
	adaptUtil::Warning("an edge not split due to constraint");
	printf("         length=%f size=(%f %f), coords=(%f %f %f)\n",
	       sqrt(pSizeField->lengthSq(ed)),ps0->size(0),ps1->size(0),xyz[0],xyz[1],xyz[2]); 
#endif
      }
      count++;
      return 0;
    }

    if(!EN_getDataInt((pEntity)ed,int_reff, &value)) 
    {
      EN_attachDataInt((pEntity)ed,int_reff,1);  

      if (E_typeInBL(ed))
        pRefBLEdges->push_back(ed);
      else
        pRefEdges->push_back(ed);
    }
    else
      return 0;

    break;
  default:
    adaptUtil::Warning("incorrect level");
  }
  
  return 1;
}


int meshTemplate::getRefineLevel(pEdge ed)
{
  int value;
  if(!EN_getDataInt((pEntity)ed,int_reff, &value)) 
    return 0;
  return value;
}


void meshTemplate::setClassification()
{
  ChildToParent=MD_newMeshDataId("pointerToClassifiedParentMesh");
}


/*
  The main routine for mesh refinement
  Last modification: 
    12/06/01  fix the bug in traversing mesh entities for non-manifold model
*/
void meshTemplate::run()
{  
  pRegion region;
  pFace face;
  pEdge edge;
  int value,j;
  std::list<pFace > refFaces;
  std::list<pRegion > refRegions;
  std::list<pEdge>::iterator eIt;
  pGModel model=M_model(pmesh);

  myTimer tt; 

#ifdef AOMD_
#ifdef MA_PARALLEL
  M_unifyTaggedEntities(int_reff, pRefEdges);
//  M_attachUniqueId(pmesh, vtIdTag);
#endif
#endif

#ifdef DEBUG
iNumPyrTemplate.clear();
iNumPyr.clear();
iNumNegPyr.clear();
iNumNegTet.clear();

#endif


// *******************************************
// 		Edge Refinement
//********************************************
  // traverse all mesh edges  
  tt.reset();
  for(eIt=pRefEdges->begin();eIt!=pRefEdges->end();++eIt) 
  {
    edge = *eIt;
    // collect mesh faces to be refined
    for( j=0; j<E_numFaces(edge); ++j ) {
      face=E_face(edge,j);
      if(!EN_getDataInt((pEntity)face,int_reff,&value)) {
	refFaces.push_back(face);
	EN_attachDataInt((pEntity)face,int_reff,1);  
      }
    }
    // split the edge, and delete if it's possible
    if(E_refine(edge)) 
    {
      delete_edge(edge,1);
    }
  }
  pRefEdges->clear();
  pRefNonBLEdges->clear();

//  cout<<"Edge Refinement time: "<<tt.elapsedCPU()<<endl;

// *******************************************
// 		Face Refinement
//********************************************i

  /// Add interface faces
  deque<pFace>::iterator interfIt;
  int numIntFaces = refInterfaceFaces.size();
  for (interfIt = refInterfaceFaces.begin(); interfIt != refInterfaceFaces.end(); ++interfIt)
  {
    face = *interfIt;
    if (!EN_getDataInt((pEntity)face,int_reff,&value))
      EN_attachDataInt((pEntity)face,int_reff,1);
    refFaces.push_back(face);
  }
  refInterfaceFaces.clear();

  // traverse all mesh faces
  tt.reset();
  std::list<pFace>::iterator fIt;
  for(fIt=refFaces.begin();fIt!=refFaces.end();++fIt) 
  {
    EN_deleteData((pEntity)(*fIt),int_reff);

    // collect mesh regions to be refined
    for( j=0; j<2; ++j ) {
      region=F_region(*fIt,j);
      if( region && !EN_getDataInt((pEntity)region,int_reff,&value)) {
	refRegions.push_back(region);
	EN_attachDataInt((pEntity)region,int_reff,1);  
      }
    }

    if(F_refine(*fIt))
    {
      delete_face(*fIt,1);
    }
  }

#ifdef AOMD_
#ifdef MA_PARALLEL
  // ents_to_update already contains BL entities to update, if any
  M_update_CB_Links(entities_to_update, ptr_reff);
  entities_to_update.clear();
  M_updateOwnership(pmesh);
#endif
#endif

//  cout<<"Face Refinement time: "<<tt.elapsedCPU()<<endl;

// *******************************************
// 		Region Refinement
//********************************************

  /// Add interface regions
  deque<pRegion>::iterator intRegIter;
  for (intRegIter = refInterfaceRegions.begin(); intRegIter != refInterfaceRegions.end(); intRegIter++)
  {
    region = *intRegIter;
    if(!EN_getDataInt((pEntity)region,int_reff,&value)) 
      EN_attachDataInt((pEntity)region,int_reff,1);
    refRegions.push_back(region);
  }
  refInterfaceRegions.clear();

  tt.reset(); 
  // traverse all mesh regions
  std::list<pRegion>::iterator rIt;
  for(rIt=refRegions.begin();rIt!=refRegions.end();++rIt)
  {
    EN_deleteData((pEntity)(*rIt),int_reff);
    R_refine(*rIt,0,0);
  }
    // try to eliminate vertices introduced when splitting regions
  deleteSteiner();
//  cout<<"Region Refinement time: "<<tt.elapsedCPU()<<endl; 

#ifdef DEBUG
for (int iPid = 0; iPid < P_size(); ++iPid)
{
if (P_pid() == iPid)
  {
std::map<int,int>::iterator MapIt;
for (MapIt = iNumPyrTemplate.begin(); MapIt != iNumPyrTemplate.end(); ++MapIt)
  printf("[%d]: Pyramid templates were applied: [%d] - %d times\n", P_pid(), MapIt->first, MapIt->second);

for (MapIt = iNumPyr.begin(); MapIt != iNumPyr.end(); ++MapIt)
  printf("[%d]: template (%d) created %d pyramids\n", P_pid(), MapIt->first, MapIt->second);

for (MapIt = iNumNegPyr.begin(); MapIt != iNumNegPyr.end(); ++MapIt)
  printf("[%d]: template {%d} resulted in %d pyramids with negative volumes\n", P_pid(), MapIt->first, MapIt->second);

for (MapIt = iNumNegTet.begin(); MapIt != iNumNegTet.end(); ++MapIt)
  printf("[%d]: template {{%d}} resulted in %d tets with negative volumes\n", P_pid(), MapIt->first, MapIt->second);
  }
  MPI_Barrier(MPI_COMM_WORLD);
}
#endif

  return;
}


// refine a mesh region regardless of its neighboring regions
// return: the template Id (0~63)
//         new tets and edges if the assocaited list is not NULL
int meshTemplate::R_refine(
  pRegion region,     // the tet to be refined
  pPList newRegs,     // return child tets created if not NULL
  pPList newEdges)    // return child segments created if not NULL
{
  int filter[]={1,2,4,8,16,32};
  pEdge edge;
  pFace face;
  int value, flag=0, bit=0, i=0;
  void *iter=0;
  pPList pElist;

  if( function_CB && newRegs==0 ) {
    flag=1;
    newRegs=PList_new();
  }

  int reg_type = region->getType();
  switch (reg_type)
  {
    case PRISM: 
      /// As for now, it is assumed that only edges of triangular faces are marked,
      /// and the ones which correspondent opposite to each other on the QUADs are always marked
//      pEdge edge;
      face = R_face(region, 0);
      for (int iEdge = 0; iEdge < 3; iEdge++)
      {
        edge = F_edge(face, iEdge);
        if(EN_getDataInt((pEntity)edge,int_reff,&value))
          bit++;
      }
      pElist = R_edges(region,1);
      switch (bit) 
      {
      case 0 : break;
      case 1 : template_reg_prism_1(region,pElist,newRegs,newEdges);
        break;
      case 2 : template_reg_prism_2(region,pElist,newRegs,newEdges);
        break;
      case 3 : template_reg_prism_3(region,pElist,newRegs,newEdges);
        break;
      default:
        cout<<"[Region Type: PRISM] refinement template "<<bit<<" undefined for bl prism"<<endl;
      }

      PList_delete(pElist);
      break;

    case PYRAMID:
      face = R_face(region, 0);

      /// It is assumed for now that the quad face can be split only into 2 quads, so if at least one edge of quad face is marked, 
      /// the opposite MUST be marked for refinement
      for (int iEdge = 0; iEdge < 4; iEdge++)
      {
        edge = F_edge(face, iEdge);
        if(EN_getDataInt((pEntity)edge,int_reff,&value))
        {
          bit = 10;
          break;
        }
      }        
      pElist = R_edges(region,1);
      for (int iEdge = 4; iEdge < 8; ++iEdge)
      {
        edge = (pEdge)PList_item(pElist, iEdge);
        if(EN_getDataInt((pEntity)edge,int_reff,&value))
          bit += 1;;
      } 

      /// Find out if the tri face is a BL faces. If only quad face is split (bit = 10), then it doesn't matter
      if (bit != 10)
      {
        for (int iFace = 1; iFace < 5; ++iFace)
        {
          face = R_face(region, iFace);
          if (F_typeInBL(face) == fVERTICAL_TRI)
          {
            int iMarkedEdge = 0;
            for (int iEdge = 0; iEdge < 3; ++iEdge)
            {
              edge = F_edge(face, iEdge);
              if(EN_getDataInt((pEntity)edge,int_reff,&value))
                iMarkedEdge++;
            }
            if (iMarkedEdge)
            {
              bit += 3;
            }
          }
        }
      }

#ifdef DEBUG
newRegs = PList_new();
#endif

      switch (bit) 
      {
        case 0: break;
        case 1: template_reg_pyramid_1(region,pElist, newRegs,newEdges); break;
        case 2: template_reg_pyramid_2(region,pElist, newRegs,newEdges); break;
        case 3: template_reg_pyramid_3(region,pElist, newRegs,newEdges); break;
        case 4: template_reg_pyramid_4(region,pElist, newRegs,newEdges); break;
        case 5: template_reg_pyramid_tri_bisect(region,pElist, newRegs,newEdges); break;
        case 7: template_reg_pyramid_tri_bisect_2(region,pElist, newRegs,newEdges); break;
        case 10: template_reg_pyramid_quad_0(region,pElist, newRegs,newEdges); break;
        case 11: template_reg_pyramid_quad_1(region,pElist, newRegs,newEdges); break;
        case 12: template_reg_pyramid_quad_2(region,pElist, newRegs,newEdges); break;
        case 13: template_reg_pyramid_quad_3(region,pElist, newRegs,newEdges); break;
        case 14: template_reg_pyramid_quad_4(region,pElist, newRegs,newEdges); break;
        case 15: template_reg_pyramid_quad_tri_bisect(region,pElist, newRegs,newEdges); break;
        case 17: template_reg_pyramid_quad_tri_bisect_2(region,pElist, newRegs,newEdges); break;
        case 20: template_reg_pyramid_quad_2_tri_bisect(region,pElist, newRegs,newEdges); break;
      }
/*
#ifdef DEBUG      
pMeshDataId dataId = MD_lookupMeshDataId("check pyramids");
for (int iRgn = 0; iRgn < PList_size(newRegs); ++iRgn)
{
  pRegion pRegionRgn = (pRegion)PList_item(newRegs, iRgn);
  EN_attachDataInt(pRegionRgn, dataId, bit);
}
PList_delete(newRegs);
#endif
*/      

#ifdef DEBUG
iNumPyrTemplate[bit]++;    
#if 0    
{
int iChild = 0;
for (int iRgn = 0; iRgn < PList_size(newRegs); ++iRgn)
{
  region = (pRegion)(PList_item(newRegs, iRgn));
  if (region->getType() == PYRAMID)
  {
    iNumPyr[bit]++;
    if (R_Volume2(region) < 0.)
      iNumNegPyr[bit]++;
  }
  if (region->getType() == TET)
  {
    if (R_Volume2(region) < 0.)
      iNumNegTet[bit]++;
  }  
}
}
#endif
#endif
 
      PList_delete(pElist);
      break;

    case HEX: break;

    case TET: 
  // find the refinement template of the region
  pElist=R_edges(region,1);
  while(edge=(pEdge)PList_next(pElist,&iter)) {
    if(EN_getDataInt((pEntity)edge,int_reff,&value))
      bit = bit | filter[i];
    ++i;
  }

  // refine the region
  switch (bit) {
  case 0: break;
  case 1: template_1(region,pElist,0,newRegs,newEdges); break;
  case 2: template_1(region,pElist,1,newRegs,newEdges); break;
  case 3: template_2_1(region,pElist,2,newRegs,newEdges); break;
  case 4: template_1(region,pElist,2,newRegs,newEdges); break;
  case 5: template_2_1(region,pElist,1,newRegs,newEdges); break;
  case 6: template_2_1(region,pElist,0,newRegs,newEdges); break;
  case 7: template_3_4(region,pElist,0,newRegs,newEdges); break;
  case 8: template_1(region,pElist,3,newRegs,newEdges); break;
  case 9: template_2_1(region,pElist,3,newRegs,newEdges); break;
  case 10: template_2_2(region,pElist,1,newRegs,newEdges); break;
  case 11: template_3_2(region,pElist,0,newRegs,newEdges); break;
  case 12: template_2_1(region,pElist,9,newRegs,newEdges); break;
  case 13: template_3_3(region,pElist,0,newRegs,newEdges); break;
  case 14: template_3_1(region,pElist,2,newRegs,newEdges); break;
  case 15: template_4_1(region,pElist,0,newRegs,newEdges); break;
  case 16: template_1(region,pElist,4,newRegs,newEdges); break;
  case 17: template_2_1(region,pElist,4,newRegs,newEdges); break;
  case 18: template_2_1(region,pElist,6,newRegs,newEdges); break;
  case 19: template_3_3(region,pElist,1,newRegs,newEdges); break;
  case 20: template_2_2(region,pElist,2,newRegs,newEdges); break;
  case 21: template_3_1(region,pElist,0,newRegs,newEdges); break;
  case 22: template_3_2(region,pElist,1,newRegs,newEdges); break;
  case 23: template_4_1(region,pElist,1,newRegs,newEdges); break;
  case 24: template_2_1(region,pElist,5,newRegs,newEdges); break;
  case 25: template_3_4(region,pElist,1,newRegs,newEdges); break;
  case 26: template_3_1(region,pElist,4,newRegs,newEdges); break;
  case 27: template_4_1(region,pElist,3,newRegs,newEdges); break;
  case 28: template_3_2(region,pElist,3,newRegs,newEdges); break;
  case 29: template_4_1(region,pElist,4,newRegs,newEdges); break;
  case 30: template_4_2(region,pElist,0,newRegs,newEdges); break;
  case 31: template_5(region,pElist,5,newRegs,newEdges); break;
  case 32: template_1(region,pElist,5,newRegs,newEdges); break;
  case 33: template_2_2(region,pElist,0,newRegs,newEdges); break;
  case 34: template_2_1(region,pElist,7,newRegs,newEdges); break;
  case 35: template_3_1(region,pElist,1,newRegs,newEdges); break;
  case 36: template_2_1(region,pElist,10,newRegs,newEdges); break;
  case 37: template_3_2(region,pElist,2,newRegs,newEdges); break;
  case 38: template_3_3(region,pElist,2,newRegs,newEdges); break;
  case 39: template_4_1(region,pElist,2,newRegs,newEdges); break;
  case 40: template_2_1(region,pElist,11,newRegs,newEdges); break;
  case 41: template_3_1(region,pElist,3,newRegs,newEdges); break;
  case 42: template_3_2(region,pElist,5,newRegs,newEdges); break;
  case 43: template_4_2(region,pElist,2,newRegs,newEdges); break;
  case 44: template_3_4(region,pElist,3,newRegs,newEdges); break;
  case 45: template_4_1(region,pElist,9,newRegs,newEdges); break;
  case 46: template_4_1(region,pElist,10,newRegs,newEdges); break;
  case 47: template_5(region,pElist,4,newRegs,newEdges); break;
  case 48: template_2_1(region,pElist,8,newRegs,newEdges); break;
  case 49: template_3_2(region,pElist,4,newRegs,newEdges); break;
  case 50: template_3_4(region,pElist,2,newRegs,newEdges); break;
  case 51: template_4_1(region,pElist,6,newRegs,newEdges); break;
  case 52: template_3_1(region,pElist,5,newRegs,newEdges); break;
  case 53: template_4_2(region,pElist,1,newRegs,newEdges); break;
  case 54: template_4_1(region,pElist,7,newRegs,newEdges); break;
  case 55: template_5(region,pElist,3,newRegs,newEdges); break;
  case 56: template_3_3(region,pElist,3,newRegs,newEdges); break;
  case 57: template_4_1(region,pElist,5,newRegs,newEdges); break;
  case 58: template_4_1(region,pElist,8,newRegs,newEdges); break;
  case 59: template_5(region,pElist,2,newRegs,newEdges); break;
  case 60: template_4_1(region,pElist,11,newRegs,newEdges); break;
  case 61: template_5(region,pElist,1,newRegs,newEdges); break;
  case 62: template_5(region,pElist,0,newRegs,newEdges); break;
  case 63: template_63(region,pElist,1,newRegs,newEdges); break;
  default:
    std::cerr << "Error: refinement template "<< bit << " unexpected"<< std::endl;
  }
  PList_delete(pElist);
  }

  if( flag ) 
    PList_delete(newRegs);

  return bit;
}


// refine a mesh face regardless of its neighboring faces
int meshTemplate::F_refine(pFace face)
{
  /// With QUAD faces we can only do bisection for now
  if (face->getType() == QUAD)
  {
    bisect_quad(face);
    return 2;
  }

  pEntity ent;;
  int bit=0, value, i;

  // find the refinement pattern for the face
  for(i=0;i<3;i++) {
    ent=(pEntity)F_edge(face,i);
    if(EN_getDataInt(ent,int_reff,&value) )
      ++bit;
  }

  // refine the face
  switch (bit) {
  case 1:  get_split_faces_1(face);  break;
  case 2:  get_split_faces_2(face);  break;
  case 3:  get_split_faces_3(face);  break;
  default:
    break;
  }
 
  return bit;
}

// refine a mesh edge 
int meshTemplate::E_refine(pEdge edge)
{
  int value;

  if(EN_getDataInt((pEntity)edge,int_reff,&value) && value==1) {
    get_split_edges(edge);
    return 1;
  }
  return 0;
}

/*
 * if DelRegionOnly = 0
 *    just remove the region (suppose there are no data attached)
 * else
 *    delete a region and its attached data. if its downward dounding mesh entities
 *    are not used by other mesh entities, remove them too
 */
void meshTemplate::delete_region(pRegion region, int DelRegionOnly)
{
  pFace r_faces[4];
  void *temp=0;
  int i;

  if(DelRegionOnly) {
    // delete the attached data
    if(EN_getDataPtr((pEntity)region, ptr_reff, &temp)) {
      PList_delete((pPList)temp);
      EN_deleteData((pEntity)region, int_reff);
      EN_deleteData((pEntity)region, ptr_reff);
    }
    // remove classification info
    if(ChildToParent && 
       EN_getDataPtr((pEntity)region,ChildToParent,&temp))
      EN_deleteData((pEntity)region,ChildToParent);

    // get all faces and edges adjacent to this region
    for (i= 0; i< 4; i++)
      r_faces[i]= R_face(region,i);

    // delete region
    M_removeRegion(pmesh,region);

    // delete faces if they could be
    for (i=0; i<4; i++)
      delete_face(r_faces[i],1);
  }
  else 
    M_removeRegion(pmesh,region);
}


/*
  Remove a face and its attached data if it could be
M
  if ifDeleteEdge=0, all bounding edges will be retained;
  if ifDeleteEdge=1, the bounding edges and vertices will be removed if it could be
*/
void meshTemplate::delete_face(pFace face, int ifDeleteEdges)
{
  void *temp_ptr,*ent;
  pPList plist;

  if (F_region(face,0)==0 && F_region(face,1)==0) {
    // face has no region using it
    
    if(EN_getDataPtr((pEntity)face,ptr_reff,&temp_ptr)) {
      EN_deleteData((pEntity)face,ptr_reff);
      plist=(pPList)temp_ptr;
      PList_delete(plist);
    }

    // remove classification info
    if(ChildToParent && 
       EN_getDataPtr((pEntity)face,ChildToParent,&ent)) {
      EN_deleteData((pEntity)face,ChildToParent);
      if(EN_getDataPtr((pEntity)ent,ptr_reff,&temp_ptr))
	EN_deleteData((pEntity)ent,ptr_reff);
    }

    pEdge edges[3];
    int i;
    if(ifDeleteEdges) {
      for(i=0;i<3;i++)
        edges[i]=F_edge(face,i);
    }
    
    M_removeFace(pmesh, face);
    
    if(ifDeleteEdges) {
      for(i=0;i<3;i++)
        delete_edge(edges[i],1);
    }
  }
}

/*
  Remove an edge and its attached data if it could be
*/
void meshTemplate::delete_edge(pEdge edge, int ifDeleteVert)
{
  void *temp_ptr, *ent;
  pPList plist;
  int value;

  if (E_numFaces(edge)==0) {
    // edge has no face using it
    if(EN_getDataPtr((pEntity)edge,ptr_reff,&temp_ptr)) {
      EN_deleteData((pEntity)edge, ptr_reff);
      plist=(pPList)temp_ptr;
      PList_delete(plist);
    }
    if(EN_getDataInt((pEntity)edge,int_reff,&value)) 
      EN_deleteData((pEntity)edge, int_reff);
    if(ChildToParent && 
       EN_getDataPtr((pEntity)edge,ChildToParent,&ent)) {
      EN_deleteData((pEntity)edge,ChildToParent);
      if(EN_getDataPtr((pEntity)ent,ptr_reff,&temp_ptr))
	EN_deleteData((pEntity)ent,ptr_reff);
    }

    pVertex vt[2];
    int i;
    if(ifDeleteVert) {
      for(i=0;i<2;i++)
        vt[i]=E_vertex(edge,i);
    }

// check if edge has mid-point 
// if so, delete the point
    if(E_numPoints(edge)){
      pPoint pt = E_point(edge, 0);
      P_delete(pt);
    }

    M_removeEdge(pmesh, edge);

    if(ifDeleteVert)
      for(i=0;i<2;i++) 
	delete_vertex(vt[i]);
  }
}


/* 
   Remove a vertex if could be
*/ 
void meshTemplate::delete_vertex(pVertex vt)
{
  if(!V_numEdges(vt)) {

    void *temp;
    if(ChildToParent && 
       EN_getDataPtr((pEntity)vt,ChildToParent,&temp))
      EN_deleteData((pEntity)vt,ChildToParent);

    if( pSizeField )
      pSizeField->deleteSize((pEntity)vt);

    M_removeVertex(pmesh,vt);
  }
}


/*
  Octa-sect a tet N times regardless of its neighbore
  the initial tet and the refined tets will both exist in the result mesh
  Created 3/7/2002 -Li
*/
void meshTemplate::R_refineN(pRegion rgn,int N,pPList *newRgns)
{
  pRegion region;
  void *iter;
  pPList rgns, pElist;
  std::vector<pRegion> rgnVec;
  std::vector<pRegion>::iterator it;

  *newRgns=PList_new();
  rgnVec.push_back(rgn);

  for( int i=0; i<N; i++ ) {
    for(it=rgnVec.begin();it!=rgnVec.end();++it) {
      pElist=R_edges(*it,1);
      rgns=PList_new();
      template_63(*it,pElist,i,rgns,0);
      PList_delete(pElist);
      PList_app2Lst(newRgns,rgns,0);
      PList_delete(rgns);
    }

    rgnVec.clear();
    iter=0;
    while( (region=(pRegion)PList_next(*newRgns,&iter)) )
      rgnVec.push_back(region);
    if( i != N-1 ) 
      PList_clear(*newRgns);
  }

  return;  
}

/*
  Here,we view the parent mesh as model of the refined mesh
  Get the classified parent of a child mesh entity. If giving a mesh entity
  of the parent mesh, itself will be returned
  Created: 3/7/2002   -li
*/
pEntity meshTemplate::EN_whatIn(pEntity ent) 
{
  void *tmpPtr;
  if(EN_getDataPtr(ent,ChildToParent,&tmpPtr)) 
    return (pEntity)tmpPtr;
  return ent;
}

/*
  delete a list of regions, also their downward mesh entities if could
  Created: 3/7/2002  -li
*/
void meshTemplate::delete_Children(pPList rgns)
{
  pRegion region;
  void *iter=0;
  while( region=(pRegion)PList_next(rgns,&iter) )
    delete_region(region,1);
  return;
}

/*
  1. find the swap+collapse to eliminate interior vertices introduced by
     subtemplate_3_3_a and subtemplate_4_2_b
  2. for ambibuous templates, select the shortest diagonal edge by 
     split+collapse
   created   6/28/01   Xiangrong Li 
   modified  9/30/01             Li
             6/22/02             Li
*/
void meshTemplate::deleteSteiner() 
{
  pEdge edge;
  pVertex vt,vd;
  int count=0;
  int i, flag;
  std::vector<pEdge> swpd;
  std::vector<pEdge>::iterator swpdIter;

  pPList deletedEdges = PList_new();

  if( PList_size(steinerVerts) ) {
    pVertex vr[4],vv[4];
    pEdge swapedge[4];
    double dist[4], max;
    int j,k,l,m,num;
    void *iter_1;
    void *temp_ptr;
    void *iter=0;

    double xyz[4][3];
    std::vector<pVertex> *verts;
    std::vector<pVertex>::iterator vtIter;
    pPList newRegs;

#ifdef DEBUG
    adaptUtil::Info((int)PList_size(steinerVerts),"steiner points are inserted by templates");
#endif
    pVertex pVertexVtx;
    pRegion pRegionRgn;    

    while( vd=(pVertex)PList_next(steinerVerts,&iter) ) 
    {
      // retrieve attached data
      EN_getDataPtr((pEntity)vd,ptr_reff,&temp_ptr);
      num=PList_size((pPList)temp_ptr)/3;
      iter_1=0; 
      for( i=0; i<num; i++ ) {
	swapedge[i]=(pEdge)PList_next((pPList)temp_ptr,&iter_1);
	vr[i]=(pVertex)PList_next((pPList)temp_ptr,&iter_1);
	vv[i]=(pVertex)PList_next((pPList)temp_ptr,&iter_1);
      }
      EN_deleteData((pEntity)vd,ptr_reff);
      PList_delete((pPList)temp_ptr);

      // see if any of these edges has been swapped
      flag=0;
      for( i=0; i<num; i++ ) {
        swpdIter = std::find(swpd.begin(),swpd.end(),swapedge[i]); 
        if( swpdIter!=swpd.end() )
	  { ++flag; break; }
      }

      // if any swap has occured, try edge collapse
      if( flag ) {
	
	// determine an edge collapse
	for( i=0; i<num; i++ ) {
	  edge=E_exists(vd,vr[i]);
	  if( !E_chkClpTopo(vd,edge) )  continue;
	  if( !E_evalColaps(pmesh,edge,vd,vr[i]) ) 
//          if (!E_chkColaps(&vd,&vr[i],edge))
            continue;
	  pSizeField->deleteSize((pEntity)vd);
	  templatesUtil::Edge_colaps(pmesh,edge,vd,vr[i],function_CB,userData_CB,&newRegs);
	  PList_delete(newRegs);
	  count++;
	  break;
	}
      }
      
      // if none swap occured, we need evaluate swap+collapse
      else {
	double tol=M_getTolerance();
	int okVol=0, okCfg=0;

        // find the index of the longest edge
	for( i=0; i<num; i++ ) 
	  dist[i]=adaptUtil::E_lengthSq(swapedge[i]);
	
	flag=0;
	for( i=0; i<num; i++ ) {
	  k=0; max=dist[0];
	  for( j=1; j<num; j++ ) 
	    if( dist[j]>max )  
	      { max=dist[j]; k=j; }
	  dist[k]=0.0;
	  
	  // see if the longest edge can be swapped
	  if( E_whatInType(swapedge[k])==Gedge ) 
	    continue;
#ifdef AOMD_
#ifdef MA_PARALLEL
          if (EN_onCB(swapedge[k]))
            continue;
#endif
#endif

          /// Can't handle cases involving any topology other than tets
          int iValidRgn = 1;
          for (int iVtx = 0; iVtx < 2; ++iVtx)
          {
            pVertexVtx = E_vertex(swapedge[k], iVtx);
            pPList vregs = V_regions(pVertexVtx);
            for (int iRgn = 0; iRgn < PList_size(vregs); ++iRgn)
            {
              pRegionRgn = (pRegion)PList_item(vregs, iRgn);
              if (pRegionRgn->getType() != TET)
              {
                iValidRgn = 0;
                PList_delete(vregs);
                break;
              }
            }
            if (iValidRgn)
              PList_delete(vregs);
            else
              break;
          }
          if (!iValidRgn)
            continue;


	  for(j=0;j<E_numSwpCfg(swapedge[k]);j++) 
          {
	    verts=fromMeshTools::E_swpCfgVerts(swapedge[k],j);
            vtIter=verts->begin();
	    iter_1=0;
	    okVol=1;
	    okCfg=0;
	    for(l=0;l<verts->size()/4;l++) {
	      flag=0;
	      for(m=0;m<4;m++) {
		//vt=(pVertex)PList_next(verts,&iter_1);
                vt=*vtIter;
                vtIter++;
		V_coord(vt,xyz[m]);
		if( vt==vr[k] ) flag++;
		if( vt==vv[k] ) flag++;
	      }
	      if( flag==2 ) okCfg=1;
              if( XYZ_volume (xyz) < tol )
                { okVol=0; break; }
            }
            delete verts;
            //PList_delete(verts);
            if ( okVol && okCfg ) break;
          }
          if ( okVol && okCfg ) break;
        }

	// perform swap 
	if( okVol && okCfg ) {
	  //PList_append(swappedEdges,swapedge[k]);
          swpd.push_back(swapedge[k]);
	  templatesUtil::Edge_swap(pmesh,swapedge[k],j,function_CB,userData_CB,&newRegs); 
	  PList_delete(newRegs);

	  // evaluate collapse
	  edge=E_exists(vd,vr[k]);
	  if( !edge )
	    continue; 
	  if( !E_chkClpTopo(vd,edge) ) 
	    continue; 
	  if( !E_evalColaps(pmesh,edge,vd,vr[k]) ) 
//          if (!E_chkColaps(&vd,&vr[k],edge))
	    continue; 	  
	  pSizeField->deleteSize((pEntity)vd);
	  templatesUtil::Edge_colaps(pmesh,edge,vd,vr[k],function_CB,userData_CB,&newRegs);
	  PList_delete(newRegs);
	  count++;

          PList_append(deletedEdges,edge);
	}
      }
    }
    PList_clear(steinerVerts);
  #ifdef DEBUG
    adaptUtil::Info(count,"of them are removed by swap+collapse operations");
  #endif
  }

  MeanRatio *shpMeasure=new MeanRatio(pSizeField);
  evalResults *result=new evalResults();
  edgeSwapMod eswp(pmesh,pSizeField,shpMeasure,result);
  eswp.setCallback(function_CB,userData_CB);
  eswp.setModelType(NOPARAM);

  PList_clear(ambigEdges);
  #ifdef DEBUG
  adaptUtil::Info((int)PList_size(ambigEdges), "ambiguous edges");
  #endif

  // select shorter diagonal in case ambiguous
  count=0;
  int count2=0;
  void *iter=0;
  while( (edge=(pEdge)PList_next(ambigEdges,&iter)) ) 
  { 
      vt=(pVertex)PList_next(ambigEdges,&iter);
      vd=(pVertex)PList_next(ambigEdges,&iter);
      swpdIter = std::find(swpd.begin(),swpd.end(),edge);
      if( swpdIter!=swpd.end() )
      {
        // can delete "edge" from "swpd"
        swpd.erase(swpdIter);
        count2++;
        continue;
      }
      if(PList_inList(deletedEdges,edge)) {
        PList_remItem(deletedEdges,edge);
        count2++;
        continue;
      }

#ifdef AOMD_
#ifdef MA_PARALLEL
      // check if the edge is on PB
      if (EN_onCB(edge))
	continue;
#endif
#endif
      eswp.setSwapEdge((pEdge)edge);
      if( !eswp.topoCheck() ) continue;
      if( !eswp.geomCheck(vt,vd) ) continue;
      if( result->getWorstShape() > adaptUtil::E_worstShp(shpMeasure,0,edge) ) {
        eswp.apply();
        ++count;
      }
    }

#ifdef DEBUG_
  adaptUtil::Info(count,"swaps applied (refineTemplates)");
  adaptUtil::Info(count2,"swaps+collapse applied (refineTemplates)");
#endif
  delete shpMeasure;
  delete result;

  PList_delete(deletedEdges);
  PList_clear(ambigEdges);
  
  return;
}


#ifdef AOMD_
void meshTemplate::M_countSteinerPoints(pMesh pm, std::list<pEdge> *rgns)
{
  int filter[]={1,2,4,8,16,32};
  pRegion region;
  pEdge edge;
  int value, bit, i;
  void *iter;

  pPList pElist;
  RIter rIt=M_regionIter(pm);
  while( (region=RIter_next(rIt)) ) {
    
    // find the refinement template of the region
    pElist=R_edges(region,1);
    iter=0;i=0; bit=0;
    while(edge=(pEdge)PList_next(pElist,&iter)) {
      if(EN_getDataInt((pEntity)edge,int_reff,&value))
	bit = bit | filter[i];
      ++i;
    }
    
    // identify the templates that may need insert steiner vertex
    switch (bit) {
    case 13: count_template_3_3a(region,0,rgns); break;
    case 19: count_template_3_3a(region,1,rgns); break;
    case 38: count_template_3_3a(region,2,rgns); break;
    case 56: count_template_3_3a(region,3,rgns); break;
    case 30: count_template_4_2b(region,0,rgns); break;
    case 43: count_template_4_2b(region,2,rgns); break;
    case 53: count_template_4_2b(region,1,rgns); break;
    }
    PList_delete(pElist);
  }
  RIter_delete(rIt);
  return;
} 
	 
void meshTemplate::count_template_3_3a(pRegion region,int id,std::list<pRegion> *rgns)
{
  pFace parent_faces[4];
  int r_dirs[4];
  int k;

  int Find[4][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2},      {1,2,0,3}      };

  // Mapping the ordered faces into the correspondent sub_template
  pPList ordered_faces=R_faces(region,1);
  parent_faces[0] = (pFace)PList_item(ordered_faces,Find[id][0]);
  parent_faces[1] = (pFace)PList_item(ordered_faces,Find[id][1]);
  parent_faces[2] = (pFace)PList_item(ordered_faces,Find[id][2]);
  parent_faces[3] = (pFace)PList_item(ordered_faces,Find[id][3]);
  PList_delete(ordered_faces);

  // get the face use of parent faces
  r_dirs[0] = R_dirUsingFace(region,parent_faces[0]);
  r_dirs[1] = R_dirUsingFace(region,parent_faces[1]);
  r_dirs[2] = R_dirUsingFace(region,parent_faces[2]);
  r_dirs[3] = R_dirUsingFace(region,parent_faces[3]);

  // find the pattern k for sub-templates
  k=0;
  if(r_dirs[0]) k = k | 1;
  if(r_dirs[1]) k = k | 2;
  if(r_dirs[3]) k = k | 4;

  // split the region
  if(k==0 || k==7) 
    rgns->push_back(region);
  return;
}


void meshTemplate::count_template_4_2b(pRegion region,int id,std::list<pRegion> *rgns)
{
  pFace parent_faces[4];
  int r_dirs[4];
  int i,k=0;

  int filter[]={1,2,4,8};
  int Find[4][4]={ {0,1,2,3},     {0,2,3,1},     {0,3,1,2}  };

  // Mapping the ordered faces into the correspondent sub_template
  pPList ordered_faces=R_faces(region,1);
  parent_faces[0] = (pFace)PList_item(ordered_faces,Find[id][0]);
  parent_faces[1] = (pFace)PList_item(ordered_faces,Find[id][1]);
  parent_faces[2] = (pFace)PList_item(ordered_faces,Find[id][2]);
  parent_faces[3] = (pFace)PList_item(ordered_faces,Find[id][3]);
  PList_delete(ordered_faces);

  // get the face use of parent faces
  r_dirs[0] = R_dirUsingFace(region,parent_faces[0]);
  r_dirs[1] = R_dirUsingFace(region,parent_faces[1]);
  r_dirs[2] = R_dirUsingFace(region,parent_faces[2]);
  r_dirs[3] = R_dirUsingFace(region,parent_faces[3]);

  // find the sub-template
  for(i=0; i<4; i++)
    if(r_dirs[i])
      k= k | filter[i];

  // split the region
  if(k==3 || k==12) 
    rgns->push_back(region);
  return;
}


#endif

int EN_isTagRef(pEntity ent)
{
  pMeshDataId tag_reff = MD_lookupMeshDataId("refdref_indicator1");
  int iVal;
  if (EN_getDataInt(ent, tag_reff, &iVal))
    return 1;

  return 0;
}



/*
#ifdef AOMD_
#ifdef MA_PARALLEL

void meshTemplate::SetNewCBLinks()
{
  pPList elist;
  int recvcount;
  int receive=0;
  RemotePointer temp, remotePtr;
  int flag;
  int i;

  while( !AP_recv_count(&recvcount) || receive<recvcount ) {

    void *msg;
    int from;
    int tag;
    int size;
    int rc=AP_recv(MPI_ANY_SOURCE,MPI_ANY_TAG,AP_BLOCKING|AP_DROPOUT,
                   &msg, &size, &from, &tag);

    if( rc ) {

      switch ( tag ) {
      case 1: {
        pVertex midvert;
        pEdge edges[2];
        Edge_template* castbuf=(Edge_template *)msg;
        pEdge edge=castbuf->receiver;
        pVertex LocalMatchVert;

        // find the local vertex bounded by 1st attached edge
        flag=1;
        for( i=0; i<2; i++ ) {
          LocalMatchVert=E_vertex(edge,i);
	  if( LocalMatchVert == castbuf->matchVert )
	    { flag=0; break; }
	}
        if( flag ) 
          adaptUtil::Error("Vertex mismatchs for edge (SetNewCBLinks)");

        // retrieve the local new edges and vertex
        elist=get_split_edges(castbuf->receiver);
        midvert=(pVertex)PList_item(elist,0);
        edges[0]=(pEdge)PList_item(elist,1);
        if( LocalMatchVert==E_vertex(edges[0],0) || LocalMatchVert==E_vertex(edges[0],1) ) 
          edges[1]=(pEdge)PList_item(elist,2);
        else {
#ifdef DEBUG
          adaptUtil::Info(" so match the PartBdry mesh entities are required!!");
#endif
          edges[1]=edges[0];
          edges[0]=(pEdge)PList_item(elist,2);
        }

        // set links: remotecopy list
	EN_addRemoteCopy(pmesh, (pEntity)midvert, castbuf->midVertPtr.second, 
			 (pEntity)(castbuf->midVertPtr.first));
	for( i=0; i<2; i++ ) {
	  EN_addRemoteCopy(pmesh, (pEntity)edges[i], castbuf->edgesPtr[i].second, 
			   (pEntity)(castbuf->edgesPtr[i].first));
	}

        ++receive;
        AP_free(msg);
        break;
      }

      case 2:{
        pEdge edge;
        pFace faces[2];
        Face_template1* castbuf=(Face_template1 *)msg;
        pFace face=castbuf->receiver;
        pEdge LocalMatchEdge;

        // calculate the mapping local edge bounded by 1st attached face
	//	printf("%d:  received match %p\n",P_pid(),castbuf->matchEdge);
        flag=1;
        for( i=0; i<3; i++ ) {
          LocalMatchEdge=F_edge(face,i);
	  //	  printf("%d:  LocalMatchEdge=%p  i=%d\n", P_pid(),LocalMatchEdge,i);
	  if( LocalMatchEdge == castbuf->matchEdge ) 
	    { flag=0;break; }
	}
        if( flag ) 
          adaptUtil::Error("Edge mismatchs (SetNewCBLinks)");

        // retrieve the new local edges and faces
        elist=get_split_faces_1(castbuf->receiver);
        edge=(pEdge)PList_item(elist,0);
        faces[0]=(pFace)PList_item(elist,1);
        if( F_inClosure(faces[0],(pEntity)LocalMatchEdge) )
          // faces[0] is bounded by LocalMatchEdge
          faces[1]=(pFace)PList_item(elist,2);
        else {
          // faces[0] is bounded by LocalMatchEdge
          faces[1]=faces[0];
          faces[0]=(pFace)PList_item(elist,2);
        }

        // set links : remotecopy list
	EN_addRemoteCopy(pmesh, (pEntity)edge, castbuf->edgePtr.second, 
			 (pEntity)(castbuf->edgePtr.first));
	for( i=0; i<2; i++ ) {
	  EN_addRemoteCopy(pmesh, (pEntity)faces[i], castbuf->facesPtr[i].second, 
			   (pEntity)(castbuf->facesPtr[i].first));
	}

        ++receive;
        AP_free(msg);
        break;
      }

      case 3:{
        pEdge edges[2];
        pFace faces[3];
        Face_template2* castbuf=(Face_template2 *)msg;

        // retrieve the new local edges and faces
        elist=get_split_faces_2(castbuf->receiver);
        edges[0]=(pEdge)PList_item(elist,0);
        edges[1]=(pEdge)PList_item(elist,1);
        faces[0]=(pFace)PList_item(elist,2);
        faces[1]=(pFace)PList_item(elist,3);
        faces[2]=(pFace)PList_item(elist,4);

        // set links: remotecopy list
	for( i=0; i<2; i++ ) {
	  EN_addRemoteCopy(pmesh, (pEntity)edges[i], castbuf->edgesPtr[i].second, 
			   (pEntity)(castbuf->edgesPtr[i].first));
	}
	for( i=0; i<3; i++ ) {
	  EN_addRemoteCopy(pmesh, (pEntity)faces[i], castbuf->facesPtr[i].second, 
			   (pEntity)(castbuf->facesPtr[i].first));
	}

        ++receive;
        AP_free(msg);
        break;
      }

      case 4:{
        pEdge edges[3];
        pFace faces[4];
        Face_template3* castbuf=(Face_template3 *)msg;
        pFace face=castbuf->receiver;
        pPList verts;
	pVertex vertex;
	void *iter=0;
        int n[3];


        // calculate the array to map new entities (3 mesh edges and 4 mesh faces) 
	// with their remote copies
        verts = F_vertices(face,1);
        flag=0; i=-1;
	while( vertex=(pVertex)PList_next(verts,&iter) ) {
	  i++;
	  if( castbuf->vertices[0] == vertex )  { n[i]=0; ++flag; continue; }
	  if( castbuf->vertices[1] == vertex )  { n[i]=1; ++flag; continue; }
	  if( castbuf->vertices[2] == vertex )  { n[i]=2; ++flag; continue; }
	}
	
	PList_delete(verts);
        if( flag != 3 )
          adaptUtil::Error("Vertex mismatchs for face ");  

        // retrieve the new local edges and faces
        elist=get_split_faces_3(castbuf->receiver);
        edges[0]=(pEdge)PList_item(elist,n[0]);
        edges[1]=(pEdge)PList_item(elist,n[1]);
        edges[2]=(pEdge)PList_item(elist,n[2]);
        faces[0]=(pFace)PList_item(elist,n[0]+3);
        faces[1]=(pFace)PList_item(elist,n[1]+3);
        faces[2]=(pFace)PList_item(elist,n[2]+3);
        faces[3]=(pFace)PList_item(elist,6);

        // set links: remotecopy list
	for( i=0; i<3; i++ ) {
	  EN_addRemoteCopy(pmesh, (pEntity)edges[i], castbuf->edgesPtr[i].second, 
			   (pEntity)(castbuf->edgesPtr[i].first));
	}
	for( i=0; i<4; i++ ) {
	  EN_addRemoteCopy(pmesh, (pEntity)faces[i], castbuf->facesPtr[i].second, 
			   (pEntity)(castbuf->facesPtr[i].first));
	}

        ++receive;
        AP_free(msg);
        break;
      }

      default:
        printf("Error: message received with unexpected tag %d", tag);
      }
    }
  }
  
#ifdef DEBUG
  if( recvcount != receive ) 
    printf("(%d) autopack says %d messages but received %d", P_pid(), recvcount, receive);
#endif
}

#endif // MA_PARALLEL
#endif // AOMD 
*/
