/*
  This class provides necessary computation when no mesh size
  field is available
*/
#ifndef _H_NullSField
#define _H_NullSField

#include "sizeFieldBase.h"
#include "AdaptTypes.h"

class NullSField : public SFieldBase
{
 public:
  NullSField() {}
  ~NullSField() {}

  virtual  int type() { return 0; }

  // geometric computation
  virtual double lengthSq(pEdge);
  virtual double areaSq(pFace);
  virtual double volume(pRegion);

  virtual double lengthSq(dArray, dArray, pMSize);
  virtual double lengthSq(dArray, dArray, pMSize, pMSize );
  virtual double lengthSq(pVertex,pVertex);
  virtual double areaSq(dArray[3], pMSize, dArray);
  virtual double volume(dArray[4], pMSize);
  virtual double angleSq(dArray, dArray, pMSize);

  virtual void decomposeMetricTensor(pVertex, dArray) {return;}
  virtual pMSize decomposeMetricTensor(pMSize, dArray) {return 0;}

  // compute location of center point
  virtual void center(pEdge, dArray, pMSize *);
  virtual double center(pVertex,pVertex,dArray,pMSize *);

#ifdef MATCHING
  virtual void center(pVertex,pVertex, double, dArray,pMSize *);
#endif  

  // set the size at a vertex 
  virtual void setSize(pEntity, pMSize) {return;}
  virtual void setSize(pEntity, dArray[3], dArray) {return;}
  virtual void setSize(pEntity, double) {return;}
  virtual void deleteSize(pEntity) {return;}

  // get the size at a point or a vertex
  virtual pMSize getSize(dArray, pEntity) {return 0;}
  virtual pMSize getSize(dArray, pPList) {return 0;}
  virtual pMSize getSize(pVertex) {return 0;}
  virtual pMSize getSize(pEntity, dArray, dArray, pEntity) {return 0;}

  virtual void interpolate(pMSize,pMSize,double,pMSize *) {return;}
};


#endif
