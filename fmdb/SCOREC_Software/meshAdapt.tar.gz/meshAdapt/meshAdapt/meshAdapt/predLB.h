#ifndef _PREDLB
#define _PREDLB
#include "MeshSize.h"

#ifdef AOMD_
#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#ifdef MA_PARALLEL
#include "SF_MigrationCallbacks.h"

#ifdef MA_PARALLEL
int PredLB(pMeshMdl mesh, pSField field, pMeshDataId SolutionID, int nVar);
#endif 

#endif /* MA_PARALLEL */
#endif /* AOMD_ */
#endif
