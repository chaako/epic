#include <iostream>

// #include "mvtk.h"

#include "templateRefine.h"
#include "templateUtil.h"
#include "BLUtil.h"
#include "mEntity.h"

//#include "SimMeshTools.h"

using namespace std;

extern pMeshDataId blEdgeTypeID, blFaceTypeID, blRegionTypeID;

void meshTemplate::template_prism_1(pRegion region,
				    pPList newRgns,
				    pPList newEdges) {

  int value;
  pVertex parent_verts[6];
  pEdge parent_edges[9];
  pFace parent_faces[5];
  pPList plist;
  int parent_f_dirs[5];

//   mvtkAddMEnt((pEntity)region);
//   mvtkActivate();
//   mvtkRemoveMEnt((pEntity)region);
//   mvtkRemoveAllMEnts();

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pPList ordered_verts=R_vertices(region,1);
  for(int iVert=0; iVert<6; iVert++)
    parent_verts[iVert] = (pVertex)PList_item(ordered_verts,iVert);
  PList_delete(ordered_verts);

  pPList ordered_edges=R_edges(region,1);
  for(int iEdge=0; iEdge<9; iEdge++)
    parent_edges[iEdge] = (pEdge)PList_item(ordered_edges,iEdge);
  PList_delete(ordered_edges);

  for(int iFace=0; iFace<5; iFace++) {
    parent_faces[iFace] = R_face(region,iFace);
    // parent_f_dirs[iFace] = R_dirUsingFace(region,parent_faces[iFace]);
    parent_f_dirs[iFace] = R_faceDir(region,iFace);
  }

  pEdge edges[4];    // the 4 edges to create one interior quad face 
  pFace faces[9];    // the 9 faces to create two new regions  
  pFace r_faces[5];  // the 5 faces to create a new region
  pRegion regions[2];// the two regions created by this template

  int f_dir[4];      // the orientation of the 4 edges of a face
  int r_dir[5];      // the orientation of the 5 faces of a region
  
  int order;
  for(int iEdge=0; iEdge<3; iEdge++) {
    if( EN_getDataInt((pEntity)parent_edges[iEdge],int_reff,&value) && 
	value==1 ) {
      order = (iEdge+2)%3;
      break;
    }
  }
  // int mapOrder[3] = {0,1,2};
  int mapOrder[3] = {(order+0)%3,(order+1)%3,(order+2)%3};
  
  faces[6] = parent_faces[order+1];
  faces[7] = parent_faces[(order+2)%3+1];
 
  edges[0]=parent_edges[order+3];
  if(parent_verts[order]==E_vertex(edges[0],0))
    f_dir[0]=1;
  else
    f_dir[0]=0;

  plist=get_split_faces_1(parent_faces[4]);
  edges[1]=(pEdge)PList_item(plist,0);
  if(parent_verts[order+3]==E_vertex(edges[1],0))
    f_dir[1]=1;
  else
    f_dir[1]=0;

  faces[0]=(pFace)PList_item(plist,1);
  if(F_inClosure(faces[0],(pEntity)parent_edges[order+6])) {
    faces[1]=(pFace)PList_item(plist,2);
  }
  else {
    faces[1]=faces[0];
    faces[0]=(pFace)PList_item(plist,2);
  }

  plist = get_bisected_faces(parent_faces[(order+1)%3+1]);
  edges[2]=(pEdge)PList_item(plist,0);
  pPList plist1=get_split_edges(parent_edges[(order+1)%3]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[2],1))
    f_dir[2]=1;
  else
    f_dir[2]=0;

  faces[2]=(pFace)PList_item(plist,1);
  if(F_inClosure(faces[2],(pEntity)parent_edges[(order+1)%3+3])) {
    faces[3]=(pFace)PList_item(plist,2);
  }
  else {
    faces[3]=faces[2];
    faces[2]=(pFace)PList_item(plist,2);
  }

  plist=get_split_faces_1(parent_faces[0]);
  edges[3]=(pEdge)PList_item(plist,0);
  if(parent_verts[order]==E_vertex(edges[3],1))
    f_dir[3]=1;
  else
    f_dir[3]=0;

  faces[4]=(pFace)PList_item(plist,1);
  if(F_inClosure(faces[4],(pEntity)parent_edges[order])) {
    faces[5]=(pFace)PList_item(plist,2);
  }
  else {
    faces[5]=faces[4];
    faces[4]=(pFace)PList_item(plist,2);
  }
  
  faces[8] = M_createF(pmesh,4,edges,f_dir,g_entity);

  int way[3] = {1,2,3};

  if(parent_f_dirs[0]) {
    way[0]=3;way[1]=1;way[2]=2;
  }

  // for regions[0], it will use face 3 positively
  r_faces[0]=faces[4];
  r_faces[way[0]]=faces[8];
  r_faces[way[1]]=faces[6];
  r_faces[way[2]]=faces[2];
  r_faces[4]=faces[0];
  r_dir[0]=parent_f_dirs[0];
  r_dir[way[0]]=1;
  r_dir[way[1]]=parent_f_dirs[order+1];
  r_dir[way[2]]=parent_f_dirs[(order+1)%3+1];
  r_dir[4]=parent_f_dirs[4];
  regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);
  
  // regions[1] will use face 1 negatively
  r_faces[0]=faces[5];
  r_faces[way[0]]=faces[8];
  r_faces[way[1]]=faces[3];
  r_faces[way[2]]=faces[7];
  r_faces[4]=faces[1];
  r_dir[0]=parent_f_dirs[0];
  r_dir[way[0]]=0;
  r_dir[way[1]]=parent_f_dirs[(order+1)%3+1];
  r_dir[way[2]]=parent_f_dirs[(order+2)%3+1];
  r_dir[4]=parent_f_dirs[4];
  regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity); 

  if (R_typeInBL(region))
  {
    int level = EN_levelInBL((pEntity)region);
    int level0 = EN_levelInBL((pEntity)parent_faces[0]);
    int level1 = EN_levelInBL((pEntity)parent_faces[4]);

    if(!EN_isBLEntity((pEntity)edges[3]))
      EN_labelBLEntity((pEntity)edges[3],level0,eLAYER);
    if(!EN_isBLEntity((pEntity)faces[4]))
      EN_labelBLEntity((pEntity)faces[4],level0,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[5]))
      EN_labelBLEntity((pEntity)faces[5],level0,fLAYER);

    if(!EN_isBLEntity((pEntity)edges[1]))
      EN_labelBLEntity((pEntity)edges[1],level1,eLAYER);
    if(!EN_isBLEntity((pEntity)faces[0]))
      EN_labelBLEntity((pEntity)faces[0],level1,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[1]))
      EN_labelBLEntity((pEntity)faces[1],level1,fLAYER);

    if(!EN_isBLEntity((pEntity)edges[2]))
      EN_labelBLEntity((pEntity)edges[2],level,eGROWTH);
    if(!EN_isBLEntity((pEntity)faces[2]))
      EN_labelBLEntity((pEntity)faces[2],level,fVERTICAL_QUAD);
    if(!EN_isBLEntity((pEntity)faces[3]))
      EN_labelBLEntity((pEntity)faces[3],level,fVERTICAL_QUAD);

    EN_labelBLEntity((pEntity)faces[8],level,fVERTICAL_QUAD);
 
    for(int iRgn=0; iRgn<2; iRgn++) 
      EN_labelBLEntity((pEntity)regions[iRgn],level,rREGULAR);
/*
    if(!E_typeInBL(edges[3]))
      EN_attachDataInt((pEntity)edges[3],blEdgeTypeID,eLAYER);
    if(!F_typeInBL(faces[4]))
      EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[5]))
      EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fLAYER);

    if(!E_typeInBL(edges[1]))
      EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
    if(!F_typeInBL(faces[0]))
      EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[1]))
      EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);      

    if(!E_typeInBL(edges[2]))
      EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eGROWTH);
    if(!F_typeInBL(faces[2]))
      EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[3]))
      EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fVERTICAL_QUAD);

    EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fVERTICAL_QUAD);

    for(int iRgn=0; iRgn<2; iRgn++)
      EN_attachDataInt((pEntity)regions[iRgn],blRegionTypeID,rREGULAR);
*/
  }

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
  } 

  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[(order+1)%3+1],0);
  delete_face(parent_faces[4],0);

  // delete edges if it can be
  delete_edge(parent_edges[(order+1)%3],0);
  delete_edge(parent_edges[(order+1)%3+6],0);

}

void meshTemplate::template_prism_2(pRegion region,
				    pPList newRgns,
				    pPList newEdges) {

  int value;
  pVertex parent_verts[6];
  pEdge parent_edges[9];
  pFace parent_faces[5];
  pPList plist, plist1;
  int parent_f_dirs[5];

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pPList ordered_verts=R_vertices(region,1);
  for(int iVert=0; iVert<6; iVert++)
    parent_verts[iVert] = (pVertex)PList_item(ordered_verts,iVert);
  PList_delete(ordered_verts);

  pPList ordered_edges=R_edges(region,1);
  for(int iEdge=0; iEdge<9; iEdge++)
    parent_edges[iEdge] = (pEdge)PList_item(ordered_edges,iEdge);
  PList_delete(ordered_edges);

  for(int iFace=0; iFace<5; iFace++) {
    parent_faces[iFace] = R_face(region,iFace);
    parent_f_dirs[iFace] = R_faceDir(region,iFace);
  }

  pEdge edges[7];    // the 7 edges to create two interior quad faces
  int edges_dir[7];  // the orientation of 7 edges
  pFace faces[13];   // the 13 faces to create three new regions
  pEdge f_edges[4];  // the 4 edges to create a new face
  pFace r_faces[5];  // the 5 faces to create a new region
  pRegion regions[3];// the three regions created by this template

  int f_dir[4];      // the orientation of the 4 edges of a face
  int r_dir[5];      // the orientation of the 5 faces of a region
  
  int order;
  // the modification operation is applied for the stack of prisms
  // hence, we need "ambig" to decide which diagonal 
  // of the triangular faces has been selected for the whole stack
  int ambig; // (-1:left & 1:right)
  for(int iEdge=0; iEdge<3; iEdge++) {
    if( !EN_getDataInt((pEntity)parent_edges[iEdge],int_reff,&value) ||
	value!=1 ) {
      order = (iEdge+2)%3;
      break;
    }
  }
  // int mapOrder[3] = {0,1,2};
  int mapOrder[3] = {(order+0)%3,(order+1)%3,(order+2)%3};

  faces[4] = parent_faces[(order+1)%3+1];

  plist = get_bisected_faces(parent_faces[order+1]);
  edges[0]=(pEdge)PList_item(plist,0);
  plist1=get_split_edges(parent_edges[order]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[0],0))
    edges_dir[0]=1;
  else 
    edges_dir[0]=0;

  faces[0]=(pFace)PList_item(plist,1);
  if(F_inClosure(faces[0],(pEntity)parent_edges[order+3])) {
    faces[1]=(pFace)PList_item(plist,2);
  }
  else {
    faces[1]=faces[0];
    faces[0]=(pFace)PList_item(plist,2);
  }

  plist=get_split_faces_2(parent_faces[4]);
  edges[1]=(pEdge)PList_item(plist,1);
  plist1=get_split_edges(parent_edges[order+6]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[1],0))
    edges_dir[1]=1;
  else
    edges_dir[1]=0;

  edges[4]=(pEdge)PList_item(plist,0);
  if(E_inClosure(edges[4],(pEntity)parent_verts[(order+1)%3+3])) {
    // left case
    ambig=-1;
    plist1=get_split_edges(parent_edges[(order+2)%3+6]);
  }
  else {
    // right case
    ambig=1;
    plist1=get_split_edges(parent_edges[order+6]);
  }

  if((pVertex)PList_item(plist1,0)==E_vertex(edges[4],0))
    edges_dir[4]=1;
  else
    edges_dir[4]=0;
  
  faces[8]=(pFace)PList_item(plist,4);
  faces[9]=(pFace)PList_item(plist,3);
  faces[10]=(pFace)PList_item(plist,2);
  
  plist = get_bisected_faces(parent_faces[(order+2)%3+1]);
  edges[2]=(pEdge)PList_item(plist,0);
  plist1=get_split_edges(parent_edges[(order+2)%3+6]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[2],0))
    edges_dir[2]=1;
  else
    edges_dir[2]=0;

  faces[2]=(pFace)PList_item(plist,1);
  if(F_inClosure(faces[2],(pEntity)parent_edges[order+3])) {
    faces[3]=(pFace)PList_item(plist,2);
  }
  else{
    faces[3]=faces[2];
    faces[2]=(pFace)PList_item(plist,2);
  }

  plist=get_split_faces_2(parent_faces[0]);
  edges[3]=(pEdge)PList_item(plist,1);
  plist1=get_split_edges(parent_edges[(order+2)%3]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[3],0))
    edges_dir[3]=1;
  else
    edges_dir[3]=0;

  edges[6]=(pEdge)PList_item(plist,0);
  if(ambig==-1) {
    // left case
    if(parent_verts[(order+1)%3]==E_vertex(edges[6],0))
      edges_dir[6]=1;
    else
      edges_dir[6]=0;
  }
  else {
    // right case
    if(parent_verts[(order+2)%3]==E_vertex(edges[6],0))
      edges_dir[6]=1;
    else
      edges_dir[6]=0;
  }

  faces[5]=(pFace)PList_item(plist,4);
  faces[6]=(pFace)PList_item(plist,3);
  faces[7]=(pFace)PList_item(plist,2);

  if(ambig==-1) {
    edges[5]=parent_edges[(order+1)%3+3];
    if(parent_verts[(order+1)%3]==E_vertex(edges[5],1))
      edges_dir[5]=1;
    else
      edges_dir[5]=0;
  }
  else {
    edges[5]=parent_edges[(order+2)%3+3];
    if(parent_verts[(order+2)%3]==E_vertex(edges[5],1))
      edges_dir[5]=1;
    else
      edges_dir[5]=0;
  }

  // create the two interior quad faces
  f_edges[0]=edges[0];
  f_edges[1]=edges[1];
  f_edges[2]=edges[2];
  f_edges[3]=edges[3];
  f_dir[0]=edges_dir[0];
  f_dir[1]=edges_dir[1];
  f_dir[2]=edges_dir[2];
  f_dir[3]=edges_dir[3];
  faces[11] = M_createF(pmesh,4,f_edges,f_dir,g_entity);
  
  f_edges[0]=edges[4];
  f_edges[1]=edges[5];
  f_edges[2]=edges[6];
  f_dir[0]=edges_dir[4];
  f_dir[1]=edges_dir[5];
  f_dir[2]=edges_dir[6];
  if(ambig==-1) {
    f_edges[3]=edges[2];
    f_dir[3]=1-edges_dir[2];
  }
  else {
    f_edges[3]=edges[0];
    f_dir[3]=edges_dir[0];
  }
  faces[12]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  int way[3]; // = {1,2,3};
  if(!parent_f_dirs[0]) {
    way[0]=1;
    way[1]=2;
    way[2]=3;
  }
  else {
    way[0]=3;
    way[1]=1;
    way[2]=2;
  }

  // create the three regions (prisms)
  // for regions[0], it will use face 2 negatively
  r_faces[0]=faces[5];
  r_faces[way[0]]=faces[11];
  r_faces[way[1]]=faces[2];
  r_faces[way[2]]=faces[0];
  r_faces[4]=faces[8];
  r_dir[0]=parent_f_dirs[0];
  r_dir[way[0]]=0;
  r_dir[way[1]]=parent_f_dirs[(order+2)%3+1];
  r_dir[way[2]]=parent_f_dirs[order+1];
  r_dir[4]=parent_f_dirs[4];
  regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  int way1[3] = {1,2,3};
  int way2[3] = {1,2,3};

  if(ambig==-1) {
    if(parent_f_dirs[0]) {
      way1[0]=3;way1[1]=2;way1[2]=1;
      way2[0]=3;way2[1]=1;way2[2]=2;
    }
  }
  else {
    if(!parent_f_dirs[0]) {
      way1[0]=2;way1[1]=3;way1[2]=1;
      way2[0]=3;way2[1]=1;way2[2]=2;
    }
  }

  if(ambig==-1) {
    // for regions[1], it will use faces 2 & 3 positively
    r_faces[0]=faces[6];
    r_faces[way[0]]=faces[12];
    r_faces[way[1]]=faces[11];
    r_faces[way[2]]=faces[1];
    r_faces[4]=faces[9];
    r_dir[0]=parent_f_dirs[0];
    r_dir[way[0]]=1;
    r_dir[way[1]]=1;
    r_dir[way[2]]=parent_f_dirs[order+1];
    r_dir[4]=parent_f_dirs[4];
    regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

    // for regions[2], it will use face 1 negatively
    r_faces[0]=faces[7];
    r_faces[way[0]]=faces[12];
    r_faces[way[1]]=faces[4];
    r_faces[way[2]]=faces[3];
    r_faces[4]=faces[10];
    r_dir[0]=parent_f_dirs[0];
    r_dir[way[0]]=0;
    r_dir[way[1]]=parent_f_dirs[(order+1)%3+1];
    r_dir[way[2]]=parent_f_dirs[(order+2)%3+1];
    r_dir[4]=parent_f_dirs[4];
    regions[2]=M_createR(pmesh,5,r_faces,r_dir,g_entity);
  }
  else {
    // for regions[1], it will use face 2 positively & face 3 negatively
    r_faces[0]=faces[6];
    r_faces[way[0]]=faces[11];
    r_faces[way[1]]=faces[12];
    r_faces[way[2]]=faces[3];
    r_faces[4]=faces[9];
    r_dir[0]=parent_f_dirs[0];
    r_dir[way[0]]=1;
    r_dir[way[1]]=0;
    r_dir[way[2]]=parent_f_dirs[(order+2)%3+1];
    r_dir[4]=parent_f_dirs[4];
    regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

    // for regions[2], it will use face 3 positively
    r_faces[0]=faces[7];
    r_faces[way[0]]=faces[12];
    r_faces[way[1]]=faces[1];
    r_faces[way[2]]=faces[4];
    r_faces[4]=faces[10];
    r_dir[0]=parent_f_dirs[0];
    r_dir[way[0]]=1;
    r_dir[way[1]]=parent_f_dirs[order+1];
    r_dir[way[2]]=parent_f_dirs[(order+1)%3+1];
    r_dir[4]=parent_f_dirs[4];
    regions[2]=M_createR(pmesh,5,r_faces,r_dir,g_entity);
  }

  if (R_typeInBL(region))
  {
    int level = EN_levelInBL((pEntity)region);
    int level0 = EN_levelInBL((pEntity)parent_faces[0]);
    int level1 = EN_levelInBL((pEntity)parent_faces[4]);

    if(!EN_isBLEntity((pEntity)edges[3]))
      EN_labelBLEntity((pEntity)edges[3],level0,eLAYER);
    if(!EN_isBLEntity((pEntity)edges[6]))
      EN_labelBLEntity((pEntity)edges[6],level0,eLAYER);
    if(!EN_isBLEntity((pEntity)faces[5]))
      EN_labelBLEntity((pEntity)faces[5],level0,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[6]))
      EN_labelBLEntity((pEntity)faces[6],level0,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[7]))
      EN_labelBLEntity((pEntity)faces[7],level0,fLAYER);

    if(!EN_isBLEntity((pEntity)edges[1]))
      EN_labelBLEntity((pEntity)edges[1],level1,eLAYER);
    if(!EN_isBLEntity((pEntity)edges[4]))
      EN_labelBLEntity((pEntity)edges[4],level1,eLAYER);
    if(!EN_isBLEntity((pEntity)faces[8]))
      EN_labelBLEntity((pEntity)faces[8],level1,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[9]))
      EN_labelBLEntity((pEntity)faces[9],level1,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[10]))
      EN_labelBLEntity((pEntity)faces[10],level1,fLAYER);

    if(!EN_isBLEntity((pEntity)edges[0]))
      EN_labelBLEntity((pEntity)edges[0],level,eGROWTH);
    if(!EN_isBLEntity((pEntity)edges[2]))
      EN_labelBLEntity((pEntity)edges[2],level,eGROWTH);
    if(!EN_isBLEntity((pEntity)faces[0]))
      EN_labelBLEntity((pEntity)faces[0],level,fVERTICAL_QUAD);
    if(!EN_isBLEntity((pEntity)faces[1]))
      EN_labelBLEntity((pEntity)faces[1],level,fVERTICAL_QUAD);
    if(!EN_isBLEntity((pEntity)faces[2]))
      EN_labelBLEntity((pEntity)faces[2],level,fVERTICAL_QUAD);
    if(!EN_isBLEntity((pEntity)faces[3]))
      EN_labelBLEntity((pEntity)faces[3],level,fVERTICAL_QUAD);

    EN_labelBLEntity((pEntity)faces[11],level,fVERTICAL_QUAD);
    EN_labelBLEntity((pEntity)faces[12],level,fVERTICAL_QUAD);

    for(int iRgn=0; iRgn<3; iRgn++) 
      EN_labelBLEntity((pEntity)regions[iRgn],level,rREGULAR);
/*
    if(!E_typeInBL(edges[3]))
      EN_attachDataInt((pEntity)edges[3],blEdgeTypeID,eLAYER);
    if(!E_typeInBL(edges[6]))
      EN_attachDataInt((pEntity)edges[6],blEdgeTypeID,eLAYER);
    if(!F_typeInBL(faces[5]))
      EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[6]))
      EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[7]))
      EN_attachDataInt((pEntity)faces[7],blFaceTypeID,fLAYER);

    if(!E_typeInBL(edges[1]))
      EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
    if(!E_typeInBL(edges[4]))
      EN_attachDataInt((pEntity)edges[4],blEdgeTypeID,eLAYER);
    if(!F_typeInBL(faces[8]))
      EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[9]))
      EN_attachDataInt((pEntity)faces[9],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[10]))
      EN_attachDataInt((pEntity)faces[10],blFaceTypeID,fLAYER);

    if(!E_typeInBL(edges[0]))
      EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eGROWTH);
    if(!E_typeInBL(edges[2]))
      EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eGROWTH);
    if(!F_typeInBL(faces[0]))
      EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[1]))
      EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[2]))
      EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[3]))
      EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fVERTICAL_QUAD);

    EN_attachDataInt((pEntity)faces[11],blFaceTypeID,fVERTICAL_QUAD);
    EN_attachDataInt((pEntity)faces[12],blFaceTypeID,fVERTICAL_QUAD);

    for(int iRgn=0; iRgn<3; iRgn++)
      EN_attachDataInt((pEntity)regions[iRgn],blRegionTypeID,rREGULAR);
*/
  }

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[4]);
    PList_append(newEdges,edges[6]);   
  } 
  
  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[order+1],0);
  delete_face(parent_faces[(order+2)%3+1],0);
  delete_face(parent_faces[4],0);

  // delete edges if it can be
  delete_edge(parent_edges[order],0);
  delete_edge(parent_edges[(order+2)%3],0);
  delete_edge(parent_edges[order+6],0);
  delete_edge(parent_edges[(order+2)%3+6],0);

}

void meshTemplate::template_prism_3(pRegion region,
				    pPList newRgns,
				    pPList newEdges) {

  pVertex parent_verts[6];
  pEdge parent_edges[9];
  pFace parent_faces[5];
  pPList plist, plist1;
  int parent_f_dirs[5];

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pPList ordered_verts=R_vertices(region,1);
  for(int iVert=0; iVert<6; iVert++)
    parent_verts[iVert] = (pVertex)PList_item(ordered_verts,iVert);
  PList_delete(ordered_verts);

  pPList ordered_edges=R_edges(region,1);
  for(int iEdge=0; iEdge<9; iEdge++)
    parent_edges[iEdge] = (pEdge)PList_item(ordered_edges,iEdge);
  PList_delete(ordered_edges);

  for(int iFace=0; iFace<5; iFace++) {
    parent_faces[iFace] = R_face(region,iFace);
    // parent_f_dirs[iFace] = R_dirUsingFace(region,parent_faces[iFace]);
    parent_f_dirs[iFace] = R_faceDir(region,iFace);
  }

  pEdge edges[9];    // the 9 edges to create two interior quad faces
  int edges_dir[9];  // the orientation of 9 edges
  pFace faces[17];   // the 17 faces to create three new regions
  pEdge f_edges[4];  // the 4 edges to create a new face
  pFace r_faces[5];  // the 5 faces to create a new region
  pRegion regions[4];// the two regions created by this template

  int f_dir[4];      // the orientation of the 4 edges of a face
  int r_dir[5];      // the orientation of the 5 faces of a region
  
  int order=0, order1[3];
  int mapOrder[3] = {(order+0)%3,(order+1)%3,(order+2)%3};

  plist = get_bisected_faces(parent_faces[order+1]);
  edges[0]=(pEdge)PList_item(plist,0);
  plist1=get_split_edges(parent_edges[order]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[0],0))
    edges_dir[0]=1;
  else
    edges_dir[0]=0;

  faces[0]=(pFace)PList_item(plist,1);
  if(F_inClosure(faces[0],(pEntity)parent_edges[order+3])) {
    faces[1]=(pFace)PList_item(plist,2);
  }
  else {
    faces[1]=faces[0];
    faces[0]=(pFace)PList_item(plist,2);
  }

  plist=get_split_faces_3(parent_faces[4]);
  faces[11]=(pFace)PList_item(plist,6);
  for(int iVert=0; iVert<3; iVert++) {
    for(int iList=0; iList<3; iList++) {
      if(F_inClosure((pFace)PList_item(plist,iList+3),
		     (pEntity)parent_verts[(order+iVert)%3+3])) {
	order1[iVert]=iList;
	break;
      }
    }
  }

  edges[1]=(pEdge)PList_item(plist,order1[0]);
  faces[10]=(pFace)PList_item(plist,order1[0]+3);
  edges[5]=(pEdge)PList_item(plist,order1[1]);
  faces[12]=(pFace)PList_item(plist,order1[1]+3);
  edges[7]=(pEdge)PList_item(plist,order1[2]);
  faces[13]=(pFace)PList_item(plist,order1[2]+3);

  plist1=get_split_edges(parent_edges[order+6]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[1],0))
    edges_dir[1]=1;
  else
    edges_dir[1]=0;

  if((pVertex)PList_item(plist1,0)==E_vertex(edges[5],0))
    edges_dir[5]=1;
  else
    edges_dir[5]=0;

  plist1=get_split_edges(parent_edges[(order+2)%3+6]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[7],0))
    edges_dir[7]=1;
  else
    edges_dir[7]=0;

  plist = get_bisected_faces(parent_faces[(order+2)%3+1]);
  edges[2]=(pEdge)PList_item(plist,0);
  plist1=get_split_edges(parent_edges[(order+2)%3+6]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[2],0))
    edges_dir[2]=1;
  else
    edges_dir[2]=0;

  faces[5]=(pFace)PList_item(plist,1);
  if(F_inClosure(faces[5],(pEntity)parent_edges[order+3])) {
    faces[4]=(pFace)PList_item(plist,2);
  }
  else {
    faces[4]=faces[5];
    faces[5]=(pFace)PList_item(plist,2);
  }

  plist=get_split_faces_3(parent_faces[0]);
  faces[7]=(pFace)PList_item(plist,6);
  for(int iVert=0; iVert<3; iVert++) {
    for(int iList=0; iList<3; iList++) {
      if(F_inClosure((pFace)PList_item(plist,iList+3),
		     (pEntity)parent_verts[(order+iVert)%3])) {
	order1[iVert]=iList;
	break;
      }
    }
  }
  
  edges[3]=(pEdge)PList_item(plist,order1[0]);
  faces[6]=(pFace)PList_item(plist,order1[0]+3);
  edges[4]=(pEdge)PList_item(plist,order1[1]);
  faces[8]=(pFace)PList_item(plist,order1[1]+3);
  edges[6]=(pEdge)PList_item(plist,order1[2]);
  faces[9]=(pFace)PList_item(plist,order1[2]+3);

  plist1=get_split_edges(parent_edges[order]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[3],1))
    edges_dir[3]=1;
  else
    edges_dir[3]=0;

  if((pVertex)PList_item(plist1,0)==E_vertex(edges[4],1))
    edges_dir[4]=1;
  else
    edges_dir[4]=0;

  plist1=get_split_edges(parent_edges[(order+2)%3]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[6],1))
    edges_dir[6]=1;
  else
    edges_dir[6]=0;

  plist = get_bisected_faces(parent_faces[(order+1)%3+1]);
  edges[8]=(pEdge)PList_item(plist,0);

  plist1=get_split_edges(parent_edges[(order+1)%3]);
  if((pVertex)PList_item(plist1,0)==E_vertex(edges[8],1))  
    edges_dir[8]=1;
  else 
    edges_dir[8]=0;

  faces[2]=(pFace)PList_item(plist,1);
  if(F_inClosure(faces[2],(pEntity)parent_edges[(order+1)%3+3])) {
    faces[3]=(pFace)PList_item(plist,2);
  }
  else {
    faces[3]=faces[2];
    faces[2]=(pFace)PList_item(plist,2);
  }

  // create the three interior faces
  f_edges[0]=edges[0];
  f_edges[1]=edges[1];
  f_edges[2]=edges[2];
  f_edges[3]=edges[3];
  f_dir[0]=edges_dir[0];
  f_dir[1]=edges_dir[1];
  f_dir[2]=edges_dir[2];
  f_dir[3]=edges_dir[3];
  faces[14] = M_createF(pmesh,4,f_edges,f_dir,g_entity);

  f_edges[0]=edges[8];
  f_edges[1]=edges[5];
  f_edges[2]=edges[0];
  f_edges[3]=edges[4];
  f_dir[0]=1-edges_dir[8];
  f_dir[1]=1-edges_dir[5];
  f_dir[2]=1-edges_dir[0];
  f_dir[3]=1-edges_dir[4];
  faces[15] = M_createF(pmesh,4,f_edges,f_dir,g_entity);

  f_edges[0]=edges[2];
  f_edges[1]=edges[7];
  f_edges[2]=edges[8];
  f_edges[3]=edges[6];
  f_dir[0]=1-edges_dir[2];
  f_dir[1]=edges_dir[7];
  f_dir[2]=edges_dir[8];
  f_dir[3]=edges_dir[6];
  faces[16] = M_createF(pmesh,4,f_edges,f_dir,g_entity);

  int way[3]; // = {1,2,3};
  if(parent_f_dirs[0]) {
    way[0]=1;
    way[1]=2;
    way[2]=3;
  }
  else {
    way[0]=3;
    way[1]=1;
    way[2]=2;
  }

  // create the four regions (prisms)
  // for regions[0], it will use face 2 negatively  
  r_faces[0]=faces[6];
  r_faces[way[0]]=faces[14];
  r_faces[way[1]]=faces[5];
  r_faces[way[2]]=faces[0];
  r_faces[4]=faces[10];
  r_dir[0]=parent_f_dirs[0];
  r_dir[way[0]]=0;
  r_dir[way[1]]=parent_f_dirs[(order+2)%3+1];
  r_dir[way[2]]=parent_f_dirs[order+1];
  r_dir[4]=parent_f_dirs[4];
  regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  R_faceDir(regions[0],0);
  R_faceDir(regions[0],1);
  R_faceDir(regions[0],2);
  R_faceDir(regions[0],3);
  R_faceDir(regions[0],4);

  // for regions[1], it will use face 3 negatively
  r_faces[0]=faces[8];
  r_faces[way[0]]=faces[15];
  r_faces[way[1]]=faces[1];
  r_faces[way[2]]=faces[2];
  r_faces[4]=faces[12];
  r_dir[0]=parent_f_dirs[0];
  r_dir[way[0]]=0;
  r_dir[way[1]]=parent_f_dirs[order+1];
  r_dir[way[2]]=parent_f_dirs[(order+1)%3+1];
  r_dir[4]=parent_f_dirs[4];
  regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  // for regions[2], it will use face 1 negatively
  r_faces[0]=faces[9];
  r_faces[way[0]]=faces[16];
  r_faces[way[1]]=faces[3];
  r_faces[way[2]]=faces[4];
  r_faces[4]=faces[13];
  r_dir[0]=parent_f_dirs[0];
  r_dir[way[0]]=0;
  r_dir[way[1]]=parent_f_dirs[(order+1)%3+1];
  r_dir[way[2]]=parent_f_dirs[(order+2)%3+1];
  r_dir[4]=parent_f_dirs[4];
  regions[2]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  // for regions[3], it will use -
  // face 1 positively, face 2 positively & face 3 positively
  r_faces[0]=faces[7];
  r_faces[way[0]]=faces[14];
  r_faces[way[1]]=faces[15];
  r_faces[way[2]]=faces[16];
  r_faces[4]=faces[11];
  r_dir[0]=parent_f_dirs[0];
  r_dir[way[0]]=1;
  r_dir[way[1]]=1;
  r_dir[way[2]]=1;
  r_dir[4]=parent_f_dirs[4];
  regions[3]=M_createR(pmesh,5,r_faces,r_dir,g_entity);
    
  if (R_typeInBL(region))
  {
    int level = EN_levelInBL((pEntity)region);
    int level0 = EN_levelInBL((pEntity)parent_faces[0]);
    int level1 = EN_levelInBL((pEntity)parent_faces[4]);

    if(!EN_isBLEntity((pEntity)edges[3]))
      EN_labelBLEntity((pEntity)edges[3],level0,eLAYER);
    if(!EN_isBLEntity((pEntity)edges[4]))
      EN_labelBLEntity((pEntity)edges[4],level0,eLAYER);
    if(!EN_isBLEntity((pEntity)edges[6]))
      EN_labelBLEntity((pEntity)edges[6],level0,eLAYER);
    if(!EN_isBLEntity((pEntity)faces[6]))
      EN_labelBLEntity((pEntity)faces[6],level0,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[7]))
      EN_labelBLEntity((pEntity)faces[7],level0,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[8]))
      EN_labelBLEntity((pEntity)faces[8],level0,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[9]))
      EN_labelBLEntity((pEntity)faces[9],level0,fLAYER);

    if(!EN_isBLEntity((pEntity)edges[1]))
      EN_labelBLEntity((pEntity)edges[1],level1,eLAYER);
    if(!EN_isBLEntity((pEntity)edges[5]))
      EN_labelBLEntity((pEntity)edges[5],level1,eLAYER);
    if(!EN_isBLEntity((pEntity)edges[7]))
      EN_labelBLEntity((pEntity)edges[7],level1,eLAYER);
    if(!EN_isBLEntity((pEntity)faces[10]))
      EN_labelBLEntity((pEntity)faces[10],level1,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[11]))
      EN_labelBLEntity((pEntity)faces[11],level1,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[12]))
      EN_labelBLEntity((pEntity)faces[12],level1,fLAYER);
    if(!EN_isBLEntity((pEntity)faces[13]))
      EN_labelBLEntity((pEntity)faces[13],level1,fLAYER);

    if(!EN_isBLEntity((pEntity)edges[0]))
      EN_labelBLEntity((pEntity)edges[0],level,eGROWTH);
    if(!EN_isBLEntity((pEntity)edges[2]))
      EN_labelBLEntity((pEntity)edges[2],level,eGROWTH);
    if(!EN_isBLEntity((pEntity)edges[8]))
      EN_labelBLEntity((pEntity)edges[8],level,eGROWTH);
    if(!EN_isBLEntity((pEntity)faces[0]))
      EN_labelBLEntity((pEntity)faces[0],level,fVERTICAL_QUAD);
    if(!EN_isBLEntity((pEntity)faces[1]))
      EN_labelBLEntity((pEntity)faces[1],level,fVERTICAL_QUAD);
    if(!EN_isBLEntity((pEntity)faces[2]))
      EN_labelBLEntity((pEntity)faces[2],level,fVERTICAL_QUAD);
    if(!EN_isBLEntity((pEntity)faces[3]))
      EN_labelBLEntity((pEntity)faces[3],level,fVERTICAL_QUAD);
    if(!EN_isBLEntity((pEntity)faces[4]))
      EN_labelBLEntity((pEntity)faces[4],level,fVERTICAL_QUAD);
    if(!EN_isBLEntity((pEntity)faces[5]))
      EN_labelBLEntity((pEntity)faces[5],level,fVERTICAL_QUAD);

    EN_labelBLEntity((pEntity)faces[14],level,fVERTICAL_QUAD);
    EN_labelBLEntity((pEntity)faces[15],level,fVERTICAL_QUAD);
    EN_labelBLEntity((pEntity)faces[16],level,fVERTICAL_QUAD);

    for(int iRgn=0; iRgn<4; iRgn++) 
      EN_labelBLEntity((pEntity)regions[iRgn],level,rREGULAR);
/*
    if(!E_typeInBL(edges[3]))
      EN_attachDataInt((pEntity)edges[3],blEdgeTypeID,eLAYER);
    if(!E_typeInBL(edges[4]))
      EN_attachDataInt((pEntity)edges[4],blEdgeTypeID,eLAYER);
    if(!E_typeInBL(edges[6]))
      EN_attachDataInt((pEntity)edges[6],blEdgeTypeID,eLAYER);
    if(!F_typeInBL(faces[6]))
      EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[7]))
      EN_attachDataInt((pEntity)faces[7],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[8]))
      EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[9]))
      EN_attachDataInt((pEntity)faces[9],blFaceTypeID,fLAYER);

    if(!E_typeInBL(edges[1]))
      EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
    if(!E_typeInBL(edges[5]))
      EN_attachDataInt((pEntity)edges[5],blEdgeTypeID,eLAYER);
    if(!E_typeInBL(edges[7]))
      EN_attachDataInt((pEntity)edges[7],blEdgeTypeID,eLAYER);
    if(!F_typeInBL(faces[10]))
      EN_attachDataInt((pEntity)faces[10],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[11]))
      EN_attachDataInt((pEntity)faces[11],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[12]))
      EN_attachDataInt((pEntity)faces[12],blFaceTypeID,fLAYER);
    if(!F_typeInBL(faces[13]))
      EN_attachDataInt((pEntity)faces[13],blFaceTypeID,fLAYER);

    if(!E_typeInBL(edges[0]))
      EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eGROWTH);
    if(!E_typeInBL(edges[2]))
      EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eGROWTH);
    if(!E_typeInBL(edges[8]))
      EN_attachDataInt((pEntity)edges[8],blEdgeTypeID,eGROWTH);
    if(!F_typeInBL(faces[0]))
      EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[1]))
      EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[2]))
      EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[3]))
      EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[4]))
      EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[5]))
      EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fVERTICAL_QUAD);

    EN_attachDataInt((pEntity)faces[14],blFaceTypeID,fVERTICAL_QUAD);
    EN_attachDataInt((pEntity)faces[15],blFaceTypeID,fVERTICAL_QUAD);
    EN_attachDataInt((pEntity)faces[16],blFaceTypeID,fVERTICAL_QUAD);

    for(int iRgn=0; iRgn<4; iRgn++)
      EN_attachDataInt((pEntity)regions[iRgn],blRegionTypeID,rREGULAR);
*/
  }

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
    PList_append(newRgns,regions[3]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[4]);
    PList_append(newEdges,edges[5]);
    PList_append(newEdges,edges[6]);
    PList_append(newEdges,edges[7]);
    PList_append(newEdges,edges[8]);
  } 
  
  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);
  
  // delete faces if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);
  delete_face(parent_faces[4],0);

  // delete edges if it can be
  delete_edge(parent_edges[order],0);
  delete_edge(parent_edges[(order+1)%3],0);
  delete_edge(parent_edges[(order+2)%3],0);
  delete_edge(parent_edges[order+6],0);
  delete_edge(parent_edges[(order+1)%3+6],0);
  delete_edge(parent_edges[(order+2)%3+6],0);

}

void meshTemplate::template_transition_tet_1(pRegion region,
					     pPList newRgns,
					     pPList newEdges) {

  int numMarkedEdges=0, value;
  pEdge edge;
  pPList ordered_edges=R_edges(region,1);  
  for(int iEdge=0; iEdge<6; iEdge++) {
    edge=(pEdge)PList_item(ordered_edges,iEdge);
    if( EN_getDataInt((pEntity)edge,int_reff,&value) &&
	value==1 )
      numMarkedEdges++;
  }
  PList_delete(ordered_edges);

  switch(numMarkedEdges) {
  case 1 :
    template_transition_tet_1_a(region,newRgns,newEdges);
    break;
  case 2 :
    template_transition_tet_1_b(region,newRgns,newEdges);
    break;
  default:
    cout<<"\nError in template_transition_tet_1()..."<<endl;
    cout<<"could NOT understand refinement template [numMarkedEdges="<<numMarkedEdges<<"]"<<endl;
    exit(0);
  }
}

void meshTemplate::template_transition_tet_1_a(pRegion region,
					       pPList newRgns,
					       pPList newEdges) {
//   pVertex parent_verts[4];
//   pEdge parent_edges[6];
//   pFace parent_faces[4];
//   int parent_f_dirs[4];

  pPList plist, redges;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<4; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<6; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<4; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace]=R_faceDir(region,iFace);
//   }

  int bFaceDir;
  pFace bFace;
  int ftype;
  for(int iFace=0; iFace<4; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
/*
    if (!(F_typeInBL(bFace) == fTRANSITION || F_typeInBL(bFace) == fLAYER))
      continue;
    opp_reg = F_region(bFace,0);
    if (opp_reg == region)
    {
      opp_reg = F_region(bFace,1);
      if (!opp_reg)
        continue;
    }
    if (EN_RlevelInBL(opp_reg) < EN_RlevelInBL(region))
    {
*/
/*
  int rLevelInBL=EN_levelInBL((pEntity)region);
  for(int iFace=0; iFace<4; iFace++) {
    bFace=R_face(region,iFace);
    if(EN_levelInBL((pEntity)bFace)<rLevelInBL) {
*/
      bFaceDir=R_faceDir(region,iFace);
      break;
    }
  }

  // pEdge gEdge=V_growthEdge(R_fcOpVt(region,bFace),-1);

  redges=R_edges(region,1);
  pEdge gEdge;
  for(int iEdge=0; iEdge<6; iEdge++) {
    gEdge=(pEdge)PList_item(redges,iEdge);
    if(E_typeInBL(gEdge)==eGROWTH)
      break;
  }
  PList_delete(redges);

  // cEdge : edge common between bFace and uFace
  pEdge cEdge=R_gtOppEdg(region,gEdge);
  int cEdgeDir=F_dirUsingEdge(bFace,cEdge);

  pFace uFace=E_otherFace(cEdge,bFace,region);
  int uFaceDir=R_dirUsingFace(region,uFace); 

  pVertex vtx;
  if((bFaceDir+cEdgeDir)%2)
    vtx=E_vertex(cEdge,0);
  else
    vtx=E_vertex(cEdge,1);

  pEdge edges[3];    // the 3 edges to create one interior tri face 
  pFace faces[7];    // the 7 faces to create two new regions  
  pFace r_faces[4];  // the 4 faces to create a new region
  pRegion regions[2];// the two regions created by this template

  int f_dir[3];      // the orientation of the 3 edges of a face
  int r_dir[4];      // the orientation of the 4 faces of a region

  plist=get_split_faces_1(bFace);
  edges[0]=(pEdge)PList_item(plist,0);
  if(!bFaceDir) { // negative
    faces[0]=(pFace)PList_item(plist,1);
    faces[1]=(pFace)PList_item(plist,2);
  }
  else { // positive
    faces[0]=(pFace)PList_item(plist,2);
    faces[1]=(pFace)PList_item(plist,1);
  }

  plist=get_split_faces_1(uFace);
  edges[1]=(pEdge)PList_item(plist,0);
  if(uFaceDir) { // positive
    faces[2]=(pFace)PList_item(plist,1);
    faces[3]=(pFace)PList_item(plist,2);
  }
  else { // negative
    faces[2]=(pFace)PList_item(plist,2);
    faces[3]=(pFace)PList_item(plist,1);
  }

  faces[4]=R_vtOpFc(region,E_otherVertex(cEdge,vtx));
  faces[5]=R_vtOpFc(region,vtx);

  // edges[2]=R_gtOppEdg(region,cEdge);
  // edges[2]=F_vtOpEd(faces[4],vtx);
  edges[2]=gEdge;

  f_dir[0]=0;
  f_dir[1]=1;
  // if(E_vertex(edges[2],1)==F_edOpVt(bFace,cEdge))
  // edges is being used negatively
  if(E_vertex(edges[0],1)==E_vertex(edges[2],1))
    f_dir[2]=1;
  else
    f_dir[2]=0;

  faces[6]=M_createF(pmesh,3,edges,f_dir,g_entity);

  int f4Dir=R_dirUsingFace(region,faces[4]);
  int f5Dir=R_dirUsingFace(region,faces[5]);

  // create two new regions
  int mapFaces1[2][4]={0,6,4,2, 0,4,2,6};
  int mapFDirs1[2][4]={bFaceDir,0,f4Dir,uFaceDir, bFaceDir,f4Dir,uFaceDir,0};
  for(int iFace=0; iFace<4; iFace++) {
    r_faces[iFace]=faces[mapFaces1[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs1[bFaceDir][iFace];
  }
  regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  int mapFaces2[2][4]={1,6,3,5, 1,3,5,6};
  int mapFDirs2[2][4]={bFaceDir,1,uFaceDir,f5Dir, bFaceDir,uFaceDir,f5Dir,1};
  for(int iFace=0; iFace<4; iFace++) {
    r_faces[iFace]=faces[mapFaces2[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs2[bFaceDir][iFace];
  }
  regions[1]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
    EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);
  
  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eTRANSITION);
  if(!F_typeInBL(faces[2]))
   EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[3]))
    EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fTRANSITION);    

  EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fVERTICAL_TRI);

  for(int iRgn=0; iRgn<2; iRgn++)
    EN_attachDataInt((pEntity)regions[iRgn],blRegionTypeID,rTRANSITION_TET);
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[1]);
  }

  // BL edge type is eTRANSITION at "level"
  if(!E_typeInBL(edges[1]))
    EN_labelBLEntity((pEntity)edges[1],level,eTRANSITION);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[2]))
    EN_labelBLEntity((pEntity)faces[2],level,fTRANSITION);
  if(!F_typeInBL(faces[3]))
    EN_labelBLEntity((pEntity)faces[3],level,fTRANSITION);

  EN_labelBLEntity((pEntity)faces[6],level,fVERTICAL_TRI);

  for(int iRgn=0; iRgn<2; iRgn++)
    EN_labelBLEntity((pEntity)regions[iRgn],level,rTRANSITION_TET);


  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // delete faces if it can be
  delete_face(bFace,0);
  delete_face(uFace,0);

  // delete edge if it can be
  delete_edge(cEdge,0);

}

void meshTemplate::template_transition_tet_1_b(pRegion region,
					       pPList newRgns,
					       pPList newEdges) {
//   pVertex parent_verts[4];
//   pEdge parent_edges[6];
//   pFace parent_faces[4];
//   int parent_f_dirs[4];

  pPList plist, redges;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<4; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<6; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<4; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace] = R_faceDir(region,iFace);
//   }

  int bFaceDir;
  pFace bFace;
  int ftype;
  for(int iFace=0; iFace<4; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
      bFaceDir=R_faceDir(region,iFace);
      break;
    }
  }

  redges=R_edges(region,1);
  pEdge gEdge;
  for(int iEdge=0; iEdge<6; iEdge++) {
    gEdge=(pEdge)PList_item(redges,iEdge);
    if(E_typeInBL(gEdge)==eGROWTH)
      break;
  }
  PList_delete(redges);

  // cEdge : edge common between bFace and uFace
  pEdge cEdge=R_gtOppEdg(region,gEdge);
  int cEdgeDir=F_dirUsingEdge(bFace,cEdge);

  // mEdgeIndex is index of marked edge w.r.t cEdge
  int value, mEdgeIndex;
  pEdge mEdge;
  // base face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    pEdge edg=F_edge(bFace,iEdge);
    if(cEdge==edg) {
      for(int iEdge2=1; iEdge2<3; iEdge2++) {
	edg=F_edge(bFace,(iEdge+iEdge2)%3);
	if( EN_getDataInt((pEntity)edg,int_reff,&value) &&
	    value==1 ) {
	  mEdge=edg;
	  mEdgeIndex=iEdge2;
	  break;
	}
      }
      break;
    }
  }

  int mapCaseIndex[2][2]={1,0, 0,1};
  int caseIndex=mapCaseIndex[bFaceDir][mEdgeIndex-1];

  pFace uFace=E_otherFace(cEdge,bFace,region);
  int uFaceDir=R_dirUsingFace(region,uFace);

  pFace vFace=E_otherFace(mEdge,bFace,region);
  int vFaceDir=R_dirUsingFace(region,vFace);

  pEdge edges[3];    // the 3 or 4 edges to create one interior tri face 
  pFace faces[8];    // the 8 faces to create two new regions  
  pFace r_faces[5];  // the 4 or 5 faces to create a new region
  pRegion regions[2];// the two regions created by this template

  int f_dir[3];      // the orientation of the 3 edges of a face
  int r_dir[5];      // the orientation of the 4 or 5 faces of a region

  int mapIndex1[2][2][2]={{{2,1}, {1,2}},
                          {{1,2}, {2,1}}};
  plist=get_split_faces_1(bFace);
  edges[0]=(pEdge)PList_item(plist,0);
  faces[0]=(pFace)PList_item(plist,mapIndex1[caseIndex][bFaceDir][0]);
  faces[1]=(pFace)PList_item(plist,mapIndex1[caseIndex][bFaceDir][1]);

  int mapIndex2[2][2][2]={{{1,2}, {2,1}},
                          {{2,1}, {1,2}}};
  plist=get_split_faces_1(uFace);
  edges[1]=(pEdge)PList_item(plist,0);
  faces[2]=(pFace)PList_item(plist,mapIndex2[caseIndex][uFaceDir][0]);
  faces[3]=(pFace)PList_item(plist,mapIndex2[caseIndex][uFaceDir][1]);
 
  plist=get_bisected_faces(vFace);
  edges[2]=(pEdge)PList_item(plist,0);
  // quad face
  faces[4]=(pFace)PList_item(plist,1);
  // tri face
  faces[5]=(pFace)PList_item(plist,2);

  faces[6]=E_otherFace(gEdge,vFace,region);

  int mapEDir[2]={1-vFaceDir,vFaceDir};
  f_dir[0]=1;
  f_dir[1]=0;
  f_dir[2]=mapEDir[caseIndex];

  faces[7]=M_createF(pmesh,3,edges,f_dir,g_entity);

  int f6Dir=R_dirUsingFace(region,faces[6]);

  // create two new regions (tet. and pyramid)
  int mapFaces1[2][2][4]={{{0,7,5,2}, {0,5,2,7}},
                          {{0,7,2,5}, {0,2,5,7}}};
  int mapFDirs1[2][2][4]={{{bFaceDir,0,vFaceDir,uFaceDir}, {bFaceDir,vFaceDir,uFaceDir,0}},
                          {{bFaceDir,1,uFaceDir,vFaceDir}, {bFaceDir,uFaceDir,vFaceDir,1}}};
  for(int iFace=0; iFace<4; iFace++) {
    r_faces[iFace]=faces[mapFaces1[caseIndex][bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs1[caseIndex][bFaceDir][iFace];
  }
  regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);
  
  int mapFaces2[2][2][5]={{{4,7,1,6,3}, {4,1,6,3,7}},
                          {{4,7,3,6,1}, {4,3,6,1,7}}};
  int mapFDirs2[2][2][5]={{{vFaceDir,1,bFaceDir,f6Dir,uFaceDir}, {vFaceDir,bFaceDir,f6Dir,uFaceDir,1}},
                          {{vFaceDir,0,uFaceDir,f6Dir,bFaceDir}, {vFaceDir,uFaceDir,f6Dir,bFaceDir,0}}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces2[caseIndex][vFaceDir][iFace]];
    r_dir[iFace]=mapFDirs2[caseIndex][vFaceDir][iFace];
  }
  regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
    EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eTRANSITION);
  if(!F_typeInBL(faces[2]))
   EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[3]))
    EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fTRANSITION);

  if(!E_typeInBL(edges[2]))
    EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[4]))
   EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[5]))
    EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fVERTICAL_TRI);

  EN_attachDataInt((pEntity)faces[7],blFaceTypeID,fVERTICAL_TRI);

  EN_attachDataInt((pEntity)regions[0],blRegionTypeID,rTRANSITION_TET);
  EN_attachDataInt((pEntity)regions[1],blRegionTypeID,rTRANSITION_PYR);
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[1]);
  }

  // BL edge type is eTRANSITION at "level"
  if(!E_typeInBL(edges[1]))
    EN_labelBLEntity((pEntity)edges[1],level,eTRANSITION);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[2]))
    EN_labelBLEntity((pEntity)faces[2],level,fTRANSITION);
  if(!F_typeInBL(faces[3]))
    EN_labelBLEntity((pEntity)faces[3],level,fTRANSITION);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[2]))
    EN_labelBLEntity((pEntity)edges[2],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[4]))
    EN_labelBLEntity((pEntity)faces[4],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[5]))
    EN_labelBLEntity((pEntity)faces[5],level,fVERTICAL_TRI);

  EN_labelBLEntity((pEntity)faces[7],level,fVERTICAL_TRI);

  EN_labelBLEntity((pEntity)regions[0],level,rTRANSITION_TET);
  EN_labelBLEntity((pEntity)regions[1],level,rTRANSITION_PYR);


  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // initialize to zero for safety
  pEdge delEdges[2]={mEdge,0};
  for(int iEdge=0; iEdge<3; iEdge++) {
    pEdge edg=F_edge(vFace,iEdge);
    if(F_inClosure(uFace,(pEntity)edg))
      delEdges[1]=edg;
  }

  // delete faces if it can be
  delete_face(bFace,0);
  delete_face(uFace,0);
  delete_face(vFace,0);

  // delete edge if it can be
  delete_edge(delEdges[0],0);
  delete_edge(delEdges[1],0);

}

void meshTemplate::template_transition_tet_2(pRegion region,
					     pPList newRgns,
					     pPList newEdges) {
  int numMarkedEdges=0, value;
  pEdge edge;
  pPList ordered_edges=R_edges(region,1);  
  for(int iEdge=0; iEdge<6; iEdge++) {
    edge=(pEdge)PList_item(ordered_edges,iEdge);
    if( EN_getDataInt((pEntity)edge,int_reff,&value) &&
	value==1 )
      numMarkedEdges++;
  }
  PList_delete(ordered_edges);

  switch(numMarkedEdges) {
  case 3 :
    template_transition_tet_2_a(region,newRgns,newEdges);
    break;
  case 4 :
    template_transition_tet_2_b(region,newRgns,newEdges);
    break;
  default:
    cout<<"\nError in template_transition_tet_2()..."<<endl;
    cout<<"could NOT understand refinement template [numMarkedEdges="<<numMarkedEdges<<"]"<<endl;
    exit(0);
  }
}

void meshTemplate::template_transition_tet_2_a(pRegion region,
					       pPList newRgns,
					       pPList newEdges) {
//   pVertex parent_verts[4];
//   pEdge parent_edges[6];
//   pFace parent_faces[4];
//   int parent_f_dirs[4];

  pPList plist, redges;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<4; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<6; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<4; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace] = R_faceDir(region,iFace);
//   }

  int bFaceDir;
  pFace bFace;
  int ftype;
  for(int iFace=0; iFace<4; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
      bFaceDir=R_faceDir(region,iFace);
      break;
    }
  }

  redges=R_edges(region,1);
  pEdge gEdge;
  for(int iEdge=0; iEdge<6; iEdge++) {
    gEdge=(pEdge)PList_item(redges,iEdge);
    if(E_typeInBL(gEdge)==eGROWTH)
      break;
  }
  PList_delete(redges);

  // cEdge : edge common between bFace and uFace
  pEdge cEdge=R_gtOppEdg(region,gEdge);
  int cEdgeDir=F_dirUsingEdge(bFace,cEdge);

  // mEdgeIndex is index of marked edge w.r.t cEdge
  int value, mEdgeIndex;
  pEdge mEdge;
  // base face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    pEdge edg=F_edge(bFace,iEdge);
    if(cEdge==edg) {
      for(int iEdge2=1; iEdge2<3; iEdge2++) {
	edg=F_edge(bFace,(iEdge+iEdge2)%3);
	if( EN_getDataInt((pEntity)edg,int_reff,&value) &&
	    value==1 ) {
	  mEdge=edg;
	  mEdgeIndex=iEdge2;
	  break;
	}
      }
      break;
    }
  }

  int mapCaseIndex[2][2]={1,0, 0,1};
  int caseIndex=mapCaseIndex[bFaceDir][mEdgeIndex-1];

  pFace uFace=E_otherFace(cEdge,bFace,region);
  int uFaceDir=R_dirUsingFace(region,uFace);

  pFace vFace=E_otherFace(mEdge,bFace,region);
  int vFaceDir=R_dirUsingFace(region,vFace);

  pVertex vtx=F_edOpVt(vFace,gEdge);
  pVertex oVtx=E_otherVertex(cEdge,vtx);

  pEdge edges[6];    // the 5 or 6 edges to create two interior tri faces
  pFace faces[11];   // the 11 faces to create three new regions  
  pEdge f_edges[3];  // the 3 edges to create a new tri face
  pFace r_faces[5];  // the 4 or 5 faces to create a new region
  pRegion regions[3];// the three regions created by this template

  int f_dir[3];      // the orientation of the 3 edges of a face
  int r_dir[5];      // the orientation of the 4 or 5 faces of a region

  plist=get_split_faces_selected_2(bFace);
  edges[0]=(pEdge)PList_item(plist,0);
  edges[1]=(pEdge)PList_item(plist,1);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  faces[2]=(pFace)PList_item(plist,4);

  int ambig=0;
  if(!E_inClosure(edges[0],(pEntity)oVtx))
    ambig=1;

  plist=get_split_faces_selected_2(uFace);
  edges[2]=(pEdge)PList_item(plist,0);
  edges[3]=(pEdge)PList_item(plist,1);
  faces[3]=(pFace)PList_item(plist,2);
  faces[4]=(pFace)PList_item(plist,3);
  faces[5]=(pFace)PList_item(plist,4);

  plist=get_bisected_faces(vFace);
  edges[4]=(pEdge)PList_item(plist,0);
  faces[6]=(pFace)PList_item(plist,1);
  faces[7]=(pFace)PList_item(plist,2);

  faces[8]=R_vtOpFc(region,vtx);

  if(ambig)
    // edges[5]=R_gtOppEdg(region,cEdge);
    // edges[5]=F_vtOpEd(faces[8],vtx);
    edges[5]=gEdge;

  f_edges[0]=edges[0];
  f_edges[1]=edges[2];
  f_edges[2]=edges[4+ambig];

  int tmp_f_dir2;
  if(ambig) {
    if(E_vertex(f_edges[2],1)==F_edOpVt(bFace,cEdge))
      tmp_f_dir2=1;
    else
      tmp_f_dir2=0;
  }
  int mapEDirs1[2][2][3]={{{0,1,1-vFaceDir}, {1,0,tmp_f_dir2}},
			  {{0,1,vFaceDir}, {1,0,tmp_f_dir2}}};
  for(int iEdge=0; iEdge<3; iEdge++)
    f_dir[iEdge]=mapEDirs1[caseIndex][ambig][iEdge];
  faces[9]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  f_edges[0]=edges[1];
  f_edges[1]=edges[3];
  f_edges[2]=edges[4];
  int mapEDirs2[2][2][3]={{{1,0,1-vFaceDir}, {0,1,1-vFaceDir}},
			  {{1,0,vFaceDir}, {0,1,vFaceDir}}};
  for(int iEdge=0; iEdge<3; iEdge++)
    f_dir[iEdge]=mapEDirs2[caseIndex][ambig][iEdge];
  faces[10]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  int f8Dir=R_dirUsingFace(region,faces[8]);

  // create three new regions
  if(ambig) {
    int mapFaces1[2][2][4]={{{0,9,3,8}, {0,3,8,9}},
                            {{0,9,8,3}, {0,8,3,9}}};
    int mapFDirs1[2][2][4]={{{bFaceDir,1,uFaceDir,f8Dir}, {bFaceDir,uFaceDir,f8Dir,1}},
                            {{bFaceDir,0,f8Dir,uFaceDir}, {bFaceDir,f8Dir,uFaceDir,0}}};
    for(int iFace=0; iFace<4; iFace++) {
      r_faces[iFace]=faces[mapFaces1[caseIndex][bFaceDir][iFace]];
      r_dir[iFace]=mapFDirs1[caseIndex][bFaceDir][iFace];
    }
    regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

    int mapFaces2[2][2][5]={{{6,10,1,9,4}, {6,1,9,4,10}},
                            {{6,10,4,9,1}, {6,4,9,1,10}}};
    int mapFDirs2[2][2][5]={{{vFaceDir,1,bFaceDir,0,uFaceDir}, {vFaceDir,bFaceDir,0,uFaceDir,1}},
                            {{vFaceDir,0,uFaceDir,1,bFaceDir}, {vFaceDir,uFaceDir,1,bFaceDir,0}}};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces2[caseIndex][vFaceDir][iFace]];
      r_dir[iFace]=mapFDirs2[caseIndex][vFaceDir][iFace];
    }
    regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

    int mapFaces3[2][2][4]={{{2,10,7,5}, {2,7,5,10}},
                            {{2,10,5,7}, {2,5,7,10}}};
    int mapFDirs3[2][2][4]={{{bFaceDir,0,vFaceDir,uFaceDir}, {bFaceDir,vFaceDir,uFaceDir,0}},
                            {{bFaceDir,1,uFaceDir,vFaceDir}, {bFaceDir,uFaceDir,vFaceDir,1}}};
    for(int iFace=0; iFace<4; iFace++) {
      r_faces[iFace]=faces[mapFaces3[caseIndex][bFaceDir][iFace]];
      r_dir[iFace]=mapFDirs3[caseIndex][bFaceDir][iFace];
    }
    regions[2]=M_createR(pmesh,4,r_faces,r_dir,g_entity);
  }
  else {
    int mapFaces1[2][2][5]={{{6,9,0,8,3}, {6,0,8,3,9}},
                            {{6,9,3,8,0}, {6,3,8,0,9}}};
    int mapFDirs1[2][2][5]={{{vFaceDir,1,bFaceDir,f8Dir,uFaceDir}, {vFaceDir,bFaceDir,f8Dir,uFaceDir,1}},
                            {{vFaceDir,0,uFaceDir,f8Dir,bFaceDir}, {vFaceDir,uFaceDir,f8Dir,bFaceDir,0}}};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces1[caseIndex][vFaceDir][iFace]];
      r_dir[iFace]=mapFDirs1[caseIndex][vFaceDir][iFace];
    }
    regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

    int mapFaces2[2][2][4]={{{1,9,10,4}, {1,4,9,10}},
                            {{1,10,9,4}, {1,4,10,9}}};
    int mapFDirs2[2][2][4]={{{bFaceDir,0,1,uFaceDir}, {bFaceDir,uFaceDir,0,1}},
                            {{bFaceDir,0,1,uFaceDir}, {bFaceDir,uFaceDir,0,1}}};
    for(int iFace=0; iFace<4; iFace++) {
      r_faces[iFace]=faces[mapFaces2[caseIndex][bFaceDir][iFace]];
      r_dir[iFace]=mapFDirs2[caseIndex][bFaceDir][iFace];
    }
    regions[1]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

    int mapFaces3[2][2][4]={{{2,10,7,5}, {2,7,5,10}},
                            {{2,10,5,7}, {2,5,7,10}}};
    int mapFDirs3[2][2][4]={{{bFaceDir,0,vFaceDir,uFaceDir}, {bFaceDir,vFaceDir,uFaceDir,0}},
                            {{bFaceDir,1,uFaceDir,vFaceDir}, {bFaceDir,uFaceDir,vFaceDir,1}}};
    for(int iFace=0; iFace<4; iFace++) {
      r_faces[iFace]=faces[mapFaces3[caseIndex][bFaceDir][iFace]];
      r_dir[iFace]=mapFDirs3[caseIndex][bFaceDir][iFace];
    }
    regions[2]=M_createR(pmesh,4,r_faces,r_dir,g_entity);
  }

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
    EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[2]))
    EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[2]))
    EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eTRANSITION);
  if(!E_typeInBL(edges[3]))
    EN_attachDataInt((pEntity)edges[3],blEdgeTypeID,eTRANSITION);
  if(!F_typeInBL(faces[3]))
   EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[4]))
    EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[5]))
    EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fTRANSITION);

  if(!E_typeInBL(edges[4]))
    EN_attachDataInt((pEntity)edges[4],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[6]))
   EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[7]))
    EN_attachDataInt((pEntity)faces[7],blFaceTypeID,fVERTICAL_TRI);

  EN_attachDataInt((pEntity)faces[9],blFaceTypeID,fVERTICAL_TRI);
  EN_attachDataInt((pEntity)faces[10],blFaceTypeID,fVERTICAL_TRI);

  if(ambig) {
    EN_attachDataInt((pEntity)regions[0],blRegionTypeID,rTRANSITION_TET);
    EN_attachDataInt((pEntity)regions[1],blRegionTypeID,rTRANSITION_PYR);
    EN_attachDataInt((pEntity)regions[2],blRegionTypeID,rTRANSITION_TET);
  }
  else {
    EN_attachDataInt((pEntity)regions[0],blRegionTypeID,rTRANSITION_PYR);
    EN_attachDataInt((pEntity)regions[1],blRegionTypeID,rTRANSITION_TET);
    EN_attachDataInt((pEntity)regions[2],blRegionTypeID,rTRANSITION_TET);
  }
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!E_typeInBL(edges[1])) {
    EN_labelBLEntity((pEntity)edges[1],level-1,eLAYER);
    E_correctTypeAndLevelInBL(edges[1]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[1]);
  }
  if(!F_typeInBL(faces[2])) {
    EN_labelBLEntity((pEntity)faces[2],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[2]);
  }

  // BL edge type is eTRANSITION at "level"
  if(!E_typeInBL(edges[2]))
    EN_labelBLEntity((pEntity)edges[2],level,eTRANSITION);
  if(!E_typeInBL(edges[3]))
    EN_labelBLEntity((pEntity)edges[3],level,eTRANSITION);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[3]))
    EN_labelBLEntity((pEntity)faces[3],level,fTRANSITION);
  if(!F_typeInBL(faces[4]))
    EN_labelBLEntity((pEntity)faces[4],level,fTRANSITION);
  if(!F_typeInBL(faces[5]))
    EN_labelBLEntity((pEntity)faces[5],level,fTRANSITION);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[4]))
    EN_labelBLEntity((pEntity)edges[4],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[6]))
    EN_labelBLEntity((pEntity)faces[6],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[7]))
    EN_labelBLEntity((pEntity)faces[7],level,fVERTICAL_TRI);

  EN_labelBLEntity((pEntity)faces[9],level,fVERTICAL_TRI);
  EN_labelBLEntity((pEntity)faces[10],level,fVERTICAL_TRI);

  if(ambig) {
    EN_labelBLEntity((pEntity)regions[0],level,rTRANSITION_TET);
    EN_labelBLEntity((pEntity)regions[1],level,rTRANSITION_PYR);
    EN_labelBLEntity((pEntity)regions[2],level,rTRANSITION_TET);
  }
  else {
    EN_labelBLEntity((pEntity)regions[0],level,rTRANSITION_PYR);
    EN_labelBLEntity((pEntity)regions[1],level,rTRANSITION_TET);
    EN_labelBLEntity((pEntity)regions[2],level,rTRANSITION_TET);
  }

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[4]);
  }

    callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  int eCount=0;
  // initialize to zero for safety
  pEdge delEdges[2]={0,0};
  for(int iEdge=0; iEdge<3; iEdge++) {
    pEdge edg=F_edge(vFace,iEdge);
    if(E_inClosure(edg,(pEntity)vtx))
      delEdges[eCount++]=edg;
  }

  // delete faces if it can be
  delete_face(bFace,0);
  delete_face(uFace,0);
  delete_face(vFace,0);

  // delete edge if it can be
  delete_edge(delEdges[0],0);
  delete_edge(delEdges[1],0);
  delete_edge(cEdge,0);

}

void meshTemplate::template_transition_tet_2_b(pRegion region,
					       pPList newRgns,
					       pPList newEdges) {
//   pVertex parent_verts[4];
//   pEdge parent_edges[6];
//   pFace parent_faces[4];
//   int parent_f_dirs[4];

  pPList plist;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<4; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<6; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<4; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace] = R_faceDir(region,iFace);
//   }

  int bFaceDir;
  pFace bFace;
  int ftype;
  for(int iFace=0; iFace<4; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
      bFaceDir=R_faceDir(region,iFace);
      break;
    }
  }

  int value;
  pEdge cEdge;
  // base face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    cEdge=F_edge(bFace,iEdge);
    if( !EN_getDataInt((pEntity)cEdge,int_reff,&value) ||
	value!=1 )
      break;
  }

  int cEdgeDir=F_dirUsingEdge(bFace,cEdge);

  pFace uFace=E_otherFace(cEdge,bFace,region);
  int uFaceDir=R_dirUsingFace(region,uFace);

  pVertex vtx, oVtx;
  if((bFaceDir+cEdgeDir)%2)
    vtx=E_vertex(cEdge,0);
  else
    vtx=E_vertex(cEdge,1);
  oVtx = E_otherVertex(cEdge,vtx);

  pFace vFace1=R_vtOpFc(region,oVtx);
  int vFaceDir1=R_dirUsingFace(region,vFace1);

  pFace vFace2=R_vtOpFc(region,vtx);
  int vFaceDir2=R_dirUsingFace(region,vFace2);

  pEdge edges[6];    // the 6 edges to create two interior, tri and quad, faces
  pFace faces[12];   // the 12 faces to create three new regions
  pEdge f_edges[4];  // the 3 or 4 edges to create a new face
  pFace r_faces[5];  // the 4 or 5 faces to create a new region
  pRegion regions[3];// the three regions created by this template

  int f_dir[4];      // the orientation of the 3 or 4 edges of a face
  int r_dir[5];      // the orientation of the 4 or 5 faces of a region

  plist=get_split_faces_selected_2(bFace);
  edges[0]=(pEdge)PList_item(plist,0);
  edges[1]=(pEdge)PList_item(plist,1);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  faces[2]=(pFace)PList_item(plist,4);

  int ambig=0;
  if(!E_inClosure(edges[0],(pEntity)vtx))
    ambig=1;

  plist=get_split_faces_selected_2(uFace);
  edges[2]=(pEdge)PList_item(plist,0);
  edges[3]=(pEdge)PList_item(plist,1);
  faces[3]=(pFace)PList_item(plist,2);
  faces[4]=(pFace)PList_item(plist,3);
  faces[5]=(pFace)PList_item(plist,4);

  plist=get_bisected_faces(vFace1);
  edges[4]=(pEdge)PList_item(plist,0);
  faces[6]=(pFace)PList_item(plist,1);
  faces[7]=(pFace)PList_item(plist,2);

  plist=get_bisected_faces(vFace2);
  edges[5]=(pEdge)PList_item(plist,0);
  faces[8]=(pFace)PList_item(plist,1);
  faces[9]=(pFace)PList_item(plist,2);

  f_edges[0]=edges[1];
  f_edges[1]=edges[4];
  f_edges[2]=edges[3];
  f_edges[3]=edges[5];
  f_dir[0]=1-ambig;
  // see bisect_tri()
  f_dir[1]=vFaceDir1;
  f_dir[2]=0+ambig;
  // see bisect_tri()
  f_dir[3]=vFaceDir2;
  faces[10]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  f_edges[0]=edges[0];
  f_edges[1]=edges[2];
  f_edges[2]=edges[5-ambig];
  f_dir[0]=0;
  f_dir[1]=1;
  // see bisect_tri()
  if(ambig)
    f_dir[2]=1-vFaceDir1;
  else
    f_dir[2]=vFaceDir2;
  faces[11]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  // create three new regions
  if(ambig) {
    int mapFaces1[2][4]={0,11,7,3, 0,7,3,11};
    int mapFDirs1[2][4]={bFaceDir,0,vFaceDir1,uFaceDir, bFaceDir,vFaceDir1,uFaceDir,0};
    for(int iFace=0; iFace<4; iFace++) {
      r_faces[iFace]=faces[mapFaces1[bFaceDir][iFace]];
      r_dir[iFace]=mapFDirs1[bFaceDir][iFace];
    }
    regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

    int mapFaces2[5]={10,9,4,11,1};
    int mapFDirs2[5]={1,vFaceDir2,uFaceDir,1,bFaceDir};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces2[iFace]];
      r_dir[iFace]=mapFDirs2[iFace];
    }
    regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);
  }
  else {
    int mapFaces1[2][4]={0,11,3,9, 0,3,9,11};
    int mapFDirs1[2][4]={bFaceDir,1,uFaceDir,vFaceDir2, bFaceDir,uFaceDir,vFaceDir2,1};
    for(int iFace=0; iFace<4; iFace++) {
      r_faces[iFace]=faces[mapFaces1[bFaceDir][iFace]];
      r_dir[iFace]=mapFDirs1[bFaceDir][iFace];
    }
    regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

    int mapFaces2[5]={10,11,4,7,1};
    int mapFDirs2[5]={1,0,uFaceDir,vFaceDir1,bFaceDir};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces2[iFace]];
      r_dir[iFace]=mapFDirs2[iFace];
    }
    regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);
  }

  int mapFaces3[2][5]={2,10,8,6,5, 2,8,6,10,5};
  int mapFDirs3[2][5]={bFaceDir,0,vFaceDir2,vFaceDir1,uFaceDir, bFaceDir,vFaceDir2,vFaceDir1,0,uFaceDir};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces3[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs3[bFaceDir][iFace];
  }
  regions[2]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
    EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[2]))
    EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[2]))
    EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eTRANSITION);
  if(!E_typeInBL(edges[3]))
    EN_attachDataInt((pEntity)edges[3],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[3]))
   EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[4]))
    EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[5]))
    EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[4]))
    EN_attachDataInt((pEntity)edges[4],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[6]))
   EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[7]))
    EN_attachDataInt((pEntity)faces[7],blFaceTypeID,fVERTICAL_TRI);

  if(!E_typeInBL(edges[5]))
    EN_attachDataInt((pEntity)edges[5],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[8]))
   EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[9]))
    EN_attachDataInt((pEntity)faces[9],blFaceTypeID,fVERTICAL_TRI);

  EN_attachDataInt((pEntity)faces[10],blFaceTypeID,fVERTICAL_QUAD);
  EN_attachDataInt((pEntity)faces[11],blFaceTypeID,fVERTICAL_TRI);

  EN_attachDataInt((pEntity)regions[0],blRegionTypeID,rTRANSITION_TET);
  EN_attachDataInt((pEntity)regions[1],blRegionTypeID,rTRANSITION_PYR);
  EN_attachDataInt((pEntity)regions[2],blRegionTypeID,rREGULAR);
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!E_typeInBL(edges[1])) {
    EN_labelBLEntity((pEntity)edges[1],level-1,eLAYER);
    // probably do not need to correct type and level for edges[1]
    // E_correctTypeAndLevelInBL(edges[1]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[1]);
  }
  if(!F_typeInBL(faces[2])) {
    EN_labelBLEntity((pEntity)faces[2],level-1,fLAYER);
    // probably do not need to correct type and level for faces[2]
    // F_correctTypeAndLevelInBL(faces[2]);
  }

  // BL edge type is eTRANSITION at "level"
  if(!E_typeInBL(edges[2]))
    EN_labelBLEntity((pEntity)edges[2],level,eTRANSITION);
  // BL edge type is eLAYER at "level"
  if(!E_typeInBL(edges[3]))
    EN_labelBLEntity((pEntity)edges[3],level,eLAYER);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[3]))
    EN_labelBLEntity((pEntity)faces[3],level,fTRANSITION);
  if(!F_typeInBL(faces[4]))
    EN_labelBLEntity((pEntity)faces[4],level,fTRANSITION);
  // BL face type is fLAYER at "level"
  if(!F_typeInBL(faces[5]))
    EN_labelBLEntity((pEntity)faces[5],level,fLAYER);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[4]))
    EN_labelBLEntity((pEntity)edges[4],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[6]))
    EN_labelBLEntity((pEntity)faces[6],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[7]))
    EN_labelBLEntity((pEntity)faces[7],level,fVERTICAL_TRI);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[5]))
    EN_labelBLEntity((pEntity)edges[5],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[8]))
    EN_labelBLEntity((pEntity)faces[8],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[9]))
    EN_labelBLEntity((pEntity)faces[9],level,fVERTICAL_TRI);

  EN_labelBLEntity((pEntity)faces[10],level,fVERTICAL_QUAD);
  EN_labelBLEntity((pEntity)faces[11],level,fVERTICAL_TRI);

  EN_labelBLEntity((pEntity)regions[0],level,rTRANSITION_TET);
  EN_labelBLEntity((pEntity)regions[1],level,rTRANSITION_PYR);
  EN_labelBLEntity((pEntity)regions[2],level,rREGULAR);


  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[4]);
    PList_append(newEdges,edges[5]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // delete faces if it can be
  delete_face(bFace,0);
  delete_face(uFace,0);

  int eCount=0;
  // initialize to zero for safety
  pEdge delEdges[4]={0,0,0,0};
  for(int iEdge=0; iEdge<3; iEdge++) {
    pEdge edg=F_edge(vFace1,iEdge);
    if(E_inClosure(edg,(pEntity)vtx))
      delEdges[eCount++]=edg;
  }
  for(int iEdge=0; iEdge<3; iEdge++) {
    pEdge edg=F_edge(vFace2,iEdge);
    if(E_inClosure(edg,(pEntity)oVtx))
      delEdges[eCount++]=edg;
  }
  delete_face(vFace1,0);
  delete_face(vFace2,0);

  // delete edge if it can be
  delete_edge(delEdges[0],0);
  delete_edge(delEdges[1],0);
  delete_edge(delEdges[2],0);
  delete_edge(delEdges[3],0);

}

void meshTemplate::template_transition_tet_3(pRegion region,
					     pPList newRgns,
					     pPList newEdges) { 
//   pVertex parent_verts[4];
//   pEdge parent_edges[6];
//   pFace parent_faces[4];
//   int parent_f_dirs[4];

  pPList plist, redges;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<4; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<6; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<4; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace] = R_faceDir(region,iFace);
//   }

  int bFaceDir;
  pFace bFace;
  int ftype;
  for(int iFace=0; iFace<4; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
      bFaceDir=R_faceDir(region,iFace);
      break;
    }
  }

  // pEdge gEdge=V_growthEdge(R_fcOpVt(region,bFace),-1);

  redges=R_edges(region,1);
  pEdge gEdge;
  for(int iEdge=0; iEdge<6; iEdge++) {
    gEdge=(pEdge)PList_item(redges,iEdge);
    if(E_typeInBL(gEdge)==eGROWTH)
      break;
  }
  PList_delete(redges);

  pEdge cEdge=R_gtOppEdg(region,gEdge);

  // initialize to -1 for safety
  int offset[2]={-1,-1};

  // base face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    if(cEdge==F_edge(bFace,iEdge)) {
      offset[0]=iEdge;
      break;
    }
  }

  pFace uFace=E_otherFace(cEdge,bFace,region);
  int uFaceDir=R_dirUsingFace(region,uFace);

  // upper face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    if(cEdge==F_edge(uFace,iEdge)) {
      offset[1]=iEdge;
      break;
    }
  }

  // pFace vFace1=E_verticalFace(F_edge(bFace,(offset[0]+2)%3),1);
  pFace vFace1=E_otherFace(F_edge(bFace,(offset[0]+2)%3),bFace,region);
  int vFaceDir1=R_dirUsingFace(region,vFace1);

  // pFace vFace2=E_verticalFace(F_edge(bFace,(offset[0]+1)%3),1);
  pFace vFace2=E_otherFace(F_edge(bFace,(offset[0]+1)%3),bFace,region);
  int vFaceDir2=R_dirUsingFace(region,vFace2);

  pEdge edges[8];    // the 8 edges to create three interior, two tri and one quad, faces
  pFace faces[15];   // the 15 faces to create four new regions
  pEdge f_edges[4];  // the 3 or 4 edges to create a new face
  pFace r_faces[5];  // the 4 or 5 faces to create a new region
  pRegion regions[4];// the four regions created by this template

  int f_dir[4];      // the orientation of the 3 or 4 edges of a face
  int r_dir[5];      // the orientation of the 4 or 5 faces of a region

  int index_in_list[2][3];
  for(int i=0; i<2; i++)
    for(int j=0; j<3; j++)
      index_in_list[i][j]=(j+offset[i])%3;

  // if upper and lower face both points in or out
  if(bFaceDir==uFaceDir) {
    // swap the first two indices for the upper face
    int tmp_index=index_in_list[1][0];
    index_in_list[1][0]=index_in_list[1][1];
    index_in_list[1][1]=tmp_index;
  }

  plist=get_split_faces_3(bFace);
  for(int i=0; i<3; i++) {
    edges[i]=(pEdge)PList_item(plist,index_in_list[0][i]);
    faces[i]=(pFace)PList_item(plist,3+index_in_list[0][i]);
  }
  faces[3]=(pFace)PList_item(plist,6);

  plist=get_split_faces_3(uFace);
  for(int i=0; i<3; i++) {
    edges[3+i]=(pEdge)PList_item(plist,index_in_list[1][i]);
    faces[4+i]=(pFace)PList_item(plist,3+index_in_list[1][i]);
  }
  faces[7]=(pFace)PList_item(plist,6);

  plist=get_bisected_faces(vFace1);
  edges[6]=(pEdge)PList_item(plist,0);
  faces[8]=(pFace)PList_item(plist,1);
  faces[9]=(pFace)PList_item(plist,2);

  plist=get_bisected_faces(vFace2);
  edges[7]=(pEdge)PList_item(plist,0);
  faces[10]=(pFace)PList_item(plist,1);
  faces[11]=(pFace)PList_item(plist,2);

  int mapEdges1[3]={0,3,6};
  int mapEDirs1[2][3]={1,1-uFaceDir,1-vFaceDir1, 1,uFaceDir,vFaceDir1};
  for(int iEdge=0; iEdge<3; iEdge++) {
    f_edges[iEdge]=edges[mapEdges1[iEdge]];
    f_dir[iEdge]=mapEDirs1[bFaceDir][iEdge];
  }
  faces[12]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  int mapEdges2[3]={1,4,7};
  int mapEDirs2[2][3]={0,uFaceDir,vFaceDir2, 0,1-uFaceDir,1-vFaceDir2};
  for(int iEdge=0; iEdge<3; iEdge++) {
    f_edges[iEdge]=edges[mapEdges2[iEdge]];
    f_dir[iEdge]=mapEDirs2[bFaceDir][iEdge];
  }
  faces[13]=M_createF(pmesh,3,f_edges,f_dir,g_entity);

  int mapEdges3[2][4]={2,7,5,6, 2,6,5,7};
  int mapEDirs3[2][4]={0,1-vFaceDir2,uFaceDir,1-vFaceDir1, 1,1-vFaceDir1,uFaceDir,1-vFaceDir2};
  for(int iEdge=0; iEdge<4; iEdge++) {
    f_edges[iEdge]=edges[mapEdges3[bFaceDir][iEdge]];
    f_dir[iEdge]=mapEDirs3[bFaceDir][iEdge];
  }
  faces[14]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  // create four new regions
  int mapFaces1[2][4]={0,12,9,4, 0,4,9,12};
  int mapFDirs1[2][4]={bFaceDir,0,vFaceDir1,uFaceDir, bFaceDir,uFaceDir,vFaceDir1,1};
  for(int iFace=0; iFace<4; iFace++) {
    r_faces[iFace]=faces[mapFaces1[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs1[bFaceDir][iFace];
  }
  regions[0]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  int mapFaces2[2][4]={1,13,5,11, 1,11,5,13};
  int mapFDirs2[2][4]={bFaceDir,1,uFaceDir,vFaceDir2, bFaceDir,vFaceDir2,uFaceDir,0};
  for(int iFace=0; iFace<4; iFace++) {
    r_faces[iFace]=faces[mapFaces2[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs2[bFaceDir][iFace];
  }
  regions[1]=M_createR(pmesh,4,r_faces,r_dir,g_entity);

  int mapFaces3[2][5]={2,14,10,8,6, 2,8,10,14,6};
  int mapFDirs3[2][5]={bFaceDir,1,vFaceDir2,vFaceDir1,uFaceDir, bFaceDir,vFaceDir1,vFaceDir2,1,uFaceDir};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces3[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs3[bFaceDir][iFace];
  }
  regions[2]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  int mapFaces4[2][5]={14,3,13,7,12, 14,3,12,7,13};
  int mapFDirs4[5]={0,bFaceDir,0,uFaceDir,1};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces4[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs4[iFace];
  }
  regions[3]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[2]))
    EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
    EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[2]))
    EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[3]))
    EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[3]))
    EN_attachDataInt((pEntity)edges[3],blEdgeTypeID,eTRANSITION);
  if(!E_typeInBL(edges[4]))
    EN_attachDataInt((pEntity)edges[4],blEdgeTypeID,eTRANSITION);
  if(!E_typeInBL(edges[5]))
    EN_attachDataInt((pEntity)edges[5],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[4]))
   EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[5]))
    EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[6]))
    EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[7]))
    EN_attachDataInt((pEntity)faces[7],blFaceTypeID,fTRANSITION);

  if(!E_typeInBL(edges[6]))
    EN_attachDataInt((pEntity)edges[6],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[8]))
   EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[9]))
    EN_attachDataInt((pEntity)faces[9],blFaceTypeID,fVERTICAL_TRI);

  if(!E_typeInBL(edges[7]))
    EN_attachDataInt((pEntity)edges[7],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[10]))
   EN_attachDataInt((pEntity)faces[10],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[11]))
    EN_attachDataInt((pEntity)faces[11],blFaceTypeID,fVERTICAL_TRI);

  EN_attachDataInt((pEntity)faces[12],blFaceTypeID,fVERTICAL_TRI);
  EN_attachDataInt((pEntity)faces[13],blFaceTypeID,fVERTICAL_TRI);
  EN_attachDataInt((pEntity)faces[14],blFaceTypeID,fVERTICAL_QUAD);

  EN_attachDataInt((pEntity)regions[0],blRegionTypeID,rTRANSITION_TET);
  EN_attachDataInt((pEntity)regions[1],blRegionTypeID,rTRANSITION_TET);
  EN_attachDataInt((pEntity)regions[2],blRegionTypeID,rREGULAR);
  EN_attachDataInt((pEntity)regions[3],blRegionTypeID,rTRANSITION_PYR);
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!E_typeInBL(edges[1])) {
    EN_labelBLEntity((pEntity)edges[1],level-1,eLAYER);
    E_correctTypeAndLevelInBL(edges[1]);
  }
  if(!E_typeInBL(edges[2])) {
    EN_labelBLEntity((pEntity)edges[2],level-1,eLAYER);
    // probably do not need to correct type and level for edges[2]
    // E_correctTypeAndLevelInBL(edges[2]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[1]);
  }
  if(!F_typeInBL(faces[2])) {
    EN_labelBLEntity((pEntity)faces[2],level-1,fLAYER);
    // probably do not need to correct type and level for faces[2]
    // F_correctTypeAndLevelInBL(faces[2]);
  }
  if(!F_typeInBL(faces[3])) {
    EN_labelBLEntity((pEntity)faces[3],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[3]);
  }

  // BL edge type is eTRANSITION at "level"
  if(!E_typeInBL(edges[3]))
    EN_labelBLEntity((pEntity)edges[3],level,eTRANSITION);
  if(!E_typeInBL(edges[4]))
    EN_labelBLEntity((pEntity)edges[4],level,eTRANSITION);
  // BL edge type is eLAYER at "level"
  if(!E_typeInBL(edges[5]))
    EN_labelBLEntity((pEntity)edges[5],level,eLAYER);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[4]))
    EN_labelBLEntity((pEntity)faces[4],level,fTRANSITION);
  if(!F_typeInBL(faces[5]))
    EN_labelBLEntity((pEntity)faces[5],level,fTRANSITION);
  // BL face type is fLAYER at "level"
  if(!F_typeInBL(faces[6]))
    EN_labelBLEntity((pEntity)faces[6],level,fLAYER);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[7]))
    EN_labelBLEntity((pEntity)faces[7],level,fTRANSITION);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[6]))
    EN_labelBLEntity((pEntity)edges[6],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[8]))
    EN_labelBLEntity((pEntity)faces[8],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[9]))
    EN_labelBLEntity((pEntity)faces[9],level,fVERTICAL_TRI);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[7]))
    EN_labelBLEntity((pEntity)edges[7],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[10]))
    EN_labelBLEntity((pEntity)faces[10],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[11]))
    EN_labelBLEntity((pEntity)faces[11],level,fVERTICAL_TRI);

  EN_labelBLEntity((pEntity)faces[12],level,fVERTICAL_TRI);
  EN_labelBLEntity((pEntity)faces[13],level,fVERTICAL_TRI);
  EN_labelBLEntity((pEntity)faces[14],level,fVERTICAL_QUAD);

  EN_labelBLEntity((pEntity)regions[0],level,rTRANSITION_TET);
  EN_labelBLEntity((pEntity)regions[1],level,rTRANSITION_TET);
  EN_labelBLEntity((pEntity)regions[2],level,rREGULAR);
  EN_labelBLEntity((pEntity)regions[3],level,rTRANSITION_PYR);

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
    PList_append(newRgns,regions[3]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[4]);
    PList_append(newEdges,edges[5]);
    PList_append(newEdges,edges[6]);
    PList_append(newEdges,edges[7]);
  }

  callCallback((pEntity)region,newRgns,0);

  redges=R_edges(region,1);
  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // delete faces if it can be
  delete_face(bFace,0);
  delete_face(uFace,0);
  delete_face(vFace1,0);
  delete_face(vFace2,0);

  // delete edge if it can be
  for(int iEdge=0; iEdge<6; iEdge++) {
    pEdge delEdge=(pEdge)PList_item(redges,iEdge);
    if(delEdge==gEdge)
      continue;
    delete_edge(delEdge,0);
  }
  PList_delete(redges);

}

void meshTemplate::template_pyramid_1(pRegion region,
				      pPList newRgns,
				      pPList newEdges) {

  int numMarkedQEdges=0, value;
  pEdge edge;
  pFace qFace=R_face(region,0);
  // first face for pyramid is quad
  for(int iEdge=0; iEdge<4; iEdge++) {
    edge=F_edge(qFace,iEdge);
    if( EN_getDataInt((pEntity)edge,int_reff,&value) &&
	value==1 )
      numMarkedQEdges++;
  }

  switch(numMarkedQEdges) {
  case 2 :
    template_pyramid_1_a(region,newRgns,newEdges);
    break;
  case 0 :
    template_pyramid_1_b(region,newRgns,newEdges);
    break;
  default:
    cout<<"\nError in template_pyramid_1()..."<<endl;
    cout<<"could NOT understand refinement template [numMarkedQEdges="<<numMarkedQEdges<<"]"<<endl;
    exit(0);
  }

}

void meshTemplate::template_pyramid_1_a(pRegion region,
					pPList newRgns,
					pPList newEdges) {
//   pVertex parent_verts[5];
//   pEdge parent_edges[8];
//   pFace parent_faces[5];
//   int parent_f_dirs[5];

  pPList plist;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<5; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<8; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<5; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace]=R_faceDir(region,iFace);
//   }

  pFace qFace=R_face(region,0);
  int qFaceDir=R_faceDir(region,0);

  int bFaceDir, uFaceDir, uFaceIndex;
  pFace bFace, uFace;
  int ftype;
  for(int iFace=1; iFace<5; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
/*
    if (!(F_typeInBL(bFace) == fTRANSITION || F_typeInBL(bFace) == fLAYER))
      continue;
    opp_reg = F_region(bFace,0);
    if (opp_reg == region)
    {
      opp_reg = F_region(bFace,1);
      if (!opp_reg)
        continue;
    }
    if (EN_RlevelInBL(opp_reg) < EN_RlevelInBL(region))
    {
*/
/*
  int rLevelInBL = EN_levelInBL((pEntity)region);
  for(int iFace=1; iFace<5; iFace++) {
    bFace=R_face(region,iFace);
    if(EN_levelInBL((pEntity)bFace)<rLevelInBL) {
*/
      // uFaceIndex=(iFace-1+2)%4+1;
      uFaceIndex=(iFace+1)%4+1;
      uFace=R_face(region,uFaceIndex);

      bFaceDir=R_faceDir(region,iFace);
      uFaceDir=R_faceDir(region,uFaceIndex);
      break;
    }
  }

  int bEdgeIndex, uEdgeIndex, qIndex;
  pEdge bEdge, uEdge;
  for(int iEdge=0; iEdge<4; iEdge++) {
    bEdge=F_edge(qFace,iEdge);
    if(F_inClosure(bFace,(pEntity)bEdge)) {
      bEdgeIndex=iEdge;
      uEdgeIndex=(iEdge+2)%4;

      int mapQIndex[2][4]={{1,0,0,1}, {0,1,1,0}};
      qIndex=mapQIndex[qFaceDir][uEdgeIndex];

      uEdge=F_edge(qFace,uEdgeIndex);
      break;
    }
  }

  pEdge edges[3];    // the 3 edges to create one interior tri face 
  pFace faces[9];    // the 9 faces to create two new regions  
  pFace r_faces[5];  // the 5 faces to create a new region
  pRegion regions[2];// the two regions created by this template

  int f_dir[3];      // the orientation of the 3 edges of a face
  int r_dir[5];      // the orientation of the 5 faces of a region
  
  int mapIndex1[2][2]={{2,1}, {1,2}};
  plist=get_split_faces_1(bFace);
  edges[0]=(pEdge)PList_item(plist,0);
  faces[0]=(pFace)PList_item(plist,mapIndex1[bFaceDir][0]);
  faces[1]=(pFace)PList_item(plist,mapIndex1[bFaceDir][1]);

  int mapIndex2[2][2]={{1,2}, {2,1}};
  plist=get_split_faces_1(uFace);
  edges[1]=(pEdge)PList_item(plist,0);
  faces[2]=(pFace)PList_item(plist,mapIndex2[uFaceDir][0]);
  faces[3]=(pFace)PList_item(plist,mapIndex2[uFaceDir][1]);

  int mapIndex3[2][2]={{2,1}, {1,2}};
  plist=get_bisected_faces(qFace);
  edges[2]=(pEdge)PList_item(plist,0);
  faces[4]=(pFace)PList_item(plist,mapIndex3[qIndex][0]);
  faces[5]=(pFace)PList_item(plist,mapIndex3[qIndex][1]);

  int tmpfIndex[2]={(bEdgeIndex+1)%4,(uEdgeIndex+1)%4};
  int fIndex[2][2]={{tmpfIndex[1],tmpfIndex[0]}, {tmpfIndex[0],tmpfIndex[1]}};
  faces[6]=E_otherFace(F_edge(qFace,fIndex[qFaceDir][0]),qFace,region);
  faces[7]=E_otherFace(F_edge(qFace,fIndex[qFaceDir][1]),qFace,region);

  f_dir[0]=1;
  f_dir[1]=0;
  int mapEDir[2][2]={{1,0}, {0,1}};
  f_dir[2]=mapEDir[qIndex][qFaceDir];

  faces[8]=M_createF(pmesh,3,edges,f_dir,g_entity);

  int f6Dir=R_dirUsingFace(region,faces[6]);
  int f7Dir=R_dirUsingFace(region,faces[7]);
 
  // create two new regions
  int mapFaces1[2][5]={{4,8,2,6,0}, {4,2,6,0,8}};
  int mapFDirs1[2][5]={{qFaceDir,0,uFaceDir,f6Dir,bFaceDir}, {qFaceDir,uFaceDir,f6Dir,bFaceDir,0}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces1[qFaceDir][iFace]];
    r_dir[iFace]=mapFDirs1[qFaceDir][iFace];
  }
  regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  int mapFaces2[2][5]={{5,8,1,7,3}, {5,1,7,3,8}};
  int mapFDirs2[2][5]={{qFaceDir,1,bFaceDir,f7Dir,uFaceDir}, {qFaceDir,bFaceDir,f7Dir,uFaceDir,1}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces2[qFaceDir][iFace]];
    r_dir[iFace]=mapFDirs2[qFaceDir][iFace];
  }
  regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
    EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eTRANSITION);
  if(!F_typeInBL(faces[2]))
   EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[3]))
    EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fTRANSITION);

  if(!E_typeInBL(edges[2]))
    EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[4]))
   EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[5]))
    EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fVERTICAL_QUAD);

  EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fVERTICAL_TRI);

  for(int iRgn=0; iRgn<2; iRgn++)
    EN_attachDataInt((pEntity)regions[iRgn],blRegionTypeID,rTRANSITION_PYR);
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[1]);
  }

  // BL edge type is eTRANSITION at "level"
  if(!E_typeInBL(edges[1]))
    EN_labelBLEntity((pEntity)edges[1],level,eTRANSITION);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[2]))
    EN_labelBLEntity((pEntity)faces[2],level,fTRANSITION);
  if(!F_typeInBL(faces[3]))
    EN_labelBLEntity((pEntity)faces[3],level,fTRANSITION);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[2]))
    EN_labelBLEntity((pEntity)edges[2],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[4]))
    EN_labelBLEntity((pEntity)faces[4],level,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[5]))
    EN_labelBLEntity((pEntity)faces[5],level,fVERTICAL_QUAD);

  EN_labelBLEntity((pEntity)faces[8],level,fVERTICAL_TRI);

  for(int iRgn=0; iRgn<2; iRgn++)
    EN_labelBLEntity((pEntity)regions[iRgn],level,rTRANSITION_PYR);

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // delete faces if it can be
  delete_face(qFace,0);
  delete_face(bFace,0);
  delete_face(uFace,0);

  // delete edge if it can be
  delete_edge(bEdge,0);
  delete_edge(uEdge,0);

}

void meshTemplate::template_pyramid_1_b(pRegion region,
					pPList newRgns,
					pPList newEdges) {
//   pVertex parent_verts[5];
//   pEdge parent_edges[8];
//   pFace parent_faces[5];
//   int parent_f_dirs[5];

  pPList plist;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<5; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<8; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<5; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace]=R_faceDir(region,iFace);
//   }

  pFace qFace=R_face(region,0);
  int qFaceDir=R_faceDir(region,0);

  int bFaceDir, uFaceDir, uFaceIndex;
  pFace bFace, uFace;
  int ftype;
  for(int iFace=1; iFace<5; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
      // uFaceIndex=(iFace-1+2)%4+1;
      uFaceIndex=(iFace+1)%4+1;
      uFace=R_face(region,uFaceIndex);

      bFaceDir=R_faceDir(region,iFace);
      uFaceDir=R_faceDir(region,uFaceIndex);
      break;
    }
  }

  int value, mEdgeIndex, mEdgeDir, caseIndex;
  pEdge mEdge;
  // base face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    mEdge=F_edge(bFace,iEdge);
    if( EN_getDataInt((pEntity)mEdge,int_reff,&value) &&
        value==1) {
      mEdgeIndex=iEdge;
      mEdgeDir=F_edgeDir(bFace,iEdge);

      // next edge
      pEdge edg=F_edge(bFace,(iEdge+1)%3);
      int eInClsQFace=F_inClosure(qFace,(pEntity)edg);
      int mapCaseIndex[2][2]={{0,1}, {1,0}};
      caseIndex=mapCaseIndex[bFaceDir][eInClsQFace];

      break;
    }
  }

  int vtxIndex=(bFaceDir+mEdgeDir)%2;
  int mapVtxIndex[2]={vtxIndex,1-vtxIndex};
  pVertex vtx=E_vertex(mEdge,mapVtxIndex[caseIndex]);

  pFace vFace=E_otherFace(mEdge,bFace,region);
  int vFaceDir=R_dirUsingFace(region,vFace);

  pEdge edges[4];    // the 4 edges to create one interior quad face
  pFace faces[9];    // the 9 faces to create two new regions  
  pEdge f_edges[4];  // the 4 edges to create a new quad face
  pFace r_faces[5];  // the 5 faces to create a new region
  pRegion regions[2];// the two regions created by this template

  int f_dir[4];      // the orientation of the 4 edges of a face
  int r_dir[5];      // the orientation of the 5 faces of a region

  int mapIndex1[2][2][2]={{{1,2}, {2,1}},
		          {{2,1}, {1,2}}};
  plist=get_split_faces_1(bFace);
  edges[0]=(pEdge)PList_item(plist,0);
  faces[0]=(pFace)PList_item(plist,mapIndex1[caseIndex][bFaceDir][0]);
  faces[1]=(pFace)PList_item(plist,mapIndex1[caseIndex][bFaceDir][1]);

  int mapIndex2[2][2][2]={{{2,1}, {1,2}},
                          {{1,2}, {2,1}}};
  plist=get_split_faces_1(uFace);
  edges[1]=(pEdge)PList_item(plist,0);
  faces[2]=(pFace)PList_item(plist,mapIndex2[caseIndex][uFaceDir][0]);
  faces[3]=(pFace)PList_item(plist,mapIndex2[caseIndex][uFaceDir][1]);

  faces[4]=qFace;

  plist=get_bisected_faces(vFace);
  edges[2]=(pEdge)PList_item(plist,0);
  faces[5]=(pFace)PList_item(plist,1);
  faces[6]=(pFace)PList_item(plist,2);

  // int tmpfIndex[2]={(uFaceIndex-1+3)%4+1,(uFaceIndex-1+1)%4+1};
  int tmpfIndex[2]={(uFaceIndex+2)%4+1,uFaceIndex%4+1};
  faces[7]=R_face(region,tmpfIndex[caseIndex]);

  edges[3]=F_vtOpEd(faces[7],vtx);

  int tmp_e_dir=0;
  if(F_edOpVt(bFace,mEdge)!=E_vertex(edges[3],caseIndex))
    tmp_e_dir=1;
  int mapEdges1[2][4]={{0,2,1,3}, {0,3,1,2}};
  int mapEDirs1[2][4]={{0,vFaceDir,1,tmp_e_dir}, {1,tmp_e_dir,0,vFaceDir}};
  for(int iEdge=0; iEdge<4; iEdge++) {
    f_edges[iEdge]=edges[mapEdges1[caseIndex][iEdge]];
    f_dir[iEdge]=mapEDirs1[caseIndex][iEdge];
  }
  faces[8]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  int f7Dir=R_dirUsingFace(region,faces[7]);

  // create two new regions  
  int mapFaces1[2][2][5]={{{0,8,4,5,2}, {0,4,5,8,2}},
			  {{0,8,5,4,2}, {0,5,4,8,2}}};
  int mapFDirs1[2][2][5]={{{bFaceDir,0,qFaceDir,vFaceDir,uFaceDir}, {bFaceDir,qFaceDir,vFaceDir,0,uFaceDir}},
                          {{bFaceDir,0,vFaceDir,qFaceDir,uFaceDir}, {bFaceDir,vFaceDir,qFaceDir,0,uFaceDir}}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces1[caseIndex][bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs1[caseIndex][bFaceDir][iFace];
  }
  regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  int mapFaces2[2][5]={{8,7,3,6,1}, {8,6,3,7,1}};
  int mapFDirs2[2][5]={{1,f7Dir,uFaceDir,vFaceDir,bFaceDir}, {1,vFaceDir,uFaceDir,f7Dir,bFaceDir}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces2[caseIndex][iFace]];
    r_dir[iFace]=mapFDirs2[caseIndex][iFace];
  }
  regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
    EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[2]))
   EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[3]))
    EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fTRANSITION);

  if(!E_typeInBL(edges[2]))
    EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[5]))
   EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[6]))
    EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fVERTICAL_TRI);

  EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fVERTICAL_QUAD);

  EN_attachDataInt((pEntity)regions[0],blRegionTypeID,rREGULAR);
  EN_attachDataInt((pEntity)regions[1],blRegionTypeID,rTRANSITION_PYR);
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    // E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    // F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[1]);
  }

  // BL edge type is eLAYER at "level"
  if(!E_typeInBL(edges[1]))
    EN_labelBLEntity((pEntity)edges[1],level,eLAYER);
  // BL face type is fLAYER at "level"
  if(!F_typeInBL(faces[2]))
    EN_labelBLEntity((pEntity)faces[2],level,fLAYER);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[3]))
    EN_labelBLEntity((pEntity)faces[3],level,fTRANSITION);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[2]))
    EN_labelBLEntity((pEntity)edges[2],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[5]))
    EN_labelBLEntity((pEntity)faces[5],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[6]))
    EN_labelBLEntity((pEntity)faces[6],level,fVERTICAL_TRI);

  EN_labelBLEntity((pEntity)faces[8],level,fVERTICAL_QUAD);

  EN_labelBLEntity((pEntity)regions[0],level,rREGULAR);
  EN_labelBLEntity((pEntity)regions[1],level,rTRANSITION_PYR);

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // initialize to zero for safety
  pEdge delEdges[2]={mEdge,0};
  for(int iEdge=0; iEdge<3; iEdge++) {
    pEdge edg=F_edge(vFace,iEdge);
    if(F_inClosure(uFace,(pEntity)edg))
      delEdges[1]=edg;
  }

  // delete faces if it can be
  delete_face(bFace,0);
  delete_face(uFace,0);
  delete_face(vFace,0);

  // delete edge if it can be
  delete_edge(delEdges[0],0);
  delete_edge(delEdges[1],0);

}

void meshTemplate::template_pyramid_2(pRegion region,
				      pPList newRgns,
				      pPList newEdges) {

  int numMarkedQEdges=0, value;
  pEdge edge;
  pFace qFace=R_face(region,0);
  // first face for pyramid is quad
  for(int iEdge=0; iEdge<4; iEdge++) {
    edge=F_edge(qFace,iEdge);
    if( EN_getDataInt((pEntity)edge,int_reff,&value) &&
	value==1 )
      numMarkedQEdges++;
  }

  switch(numMarkedQEdges) {
  case 2 :
    template_pyramid_2_a(region,newRgns,newEdges);
    break;
  case 0 :
    template_pyramid_2_b(region,newRgns,newEdges);
    break;
  default:
    cout<<"\nError in template_pyramid_2()..."<<endl;
    cout<<"could NOT understand refinement template [numMarkedQEdges="<<numMarkedQEdges<<"]"<<endl;
    exit(0);
  } 

}

void meshTemplate::template_pyramid_2_a(pRegion region,
					pPList newRgns,
					pPList newEdges) {
//   pVertex parent_verts[5];
//   pEdge parent_edges[8];
//   pFace parent_faces[5];
//   int parent_f_dirs[5];

  pPList plist;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<5; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<8; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<5; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace]=R_faceDir(region,iFace);
//   }

  pFace qFace=R_face(region,0);
  int qFaceDir=R_faceDir(region,0);

  int bFaceDir, uFaceDir, uFaceIndex;
  pFace bFace, uFace;
  int ftype;

  for(int iFace=1; iFace<5; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
      // uFaceIndex=(iFace-1+2)%4+1;
      uFaceIndex=(iFace+1)%4+1;
      uFace=R_face(region,uFaceIndex);

      bFaceDir=R_faceDir(region,iFace);
      uFaceDir=R_faceDir(region,uFaceIndex);
      break;
    }
  }


  int bEdgeIndex, uEdgeIndex, qIndex;
  pEdge bEdge, uEdge;
  for(int iEdge=0; iEdge<4; iEdge++) {
    bEdge=F_edge(qFace,iEdge);
    if(F_inClosure(bFace,(pEntity)bEdge)) {
      bEdgeIndex=iEdge;
      uEdgeIndex=(iEdge+2)%4;

      int mapQIndex[2][4]={{1,0,0,1}, {0,1,1,0}};
      qIndex=mapQIndex[qFaceDir][uEdgeIndex];

      uEdge=F_edge(qFace,uEdgeIndex);
      break;
    }
  }

  int value, mEdgeIndex, mEdgeDir, caseIndex;
  pEdge mEdge;
  // base face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    mEdge=F_edge(bFace,iEdge);

    if(F_inClosure(qFace,(pEntity)mEdge))
      continue;

    if( EN_getDataInt((pEntity)mEdge,int_reff,&value) &&
        value==1) {
      mEdgeIndex=iEdge;
      mEdgeDir=F_edgeDir(bFace,iEdge);

      // next edge
      pEdge edg=F_edge(bFace,(iEdge+1)%3);
      int eInClsQFace=F_inClosure(qFace,(pEntity)edg);
      int mapCaseIndex[2][2]={{0,1}, {1,0}};
      caseIndex=mapCaseIndex[bFaceDir][eInClsQFace];

      break;
    }
  }

  int vtxIndex=(bFaceDir+mEdgeDir)%2;
  int mapVtxIndex[2]={vtxIndex,1-vtxIndex};
  pVertex vtx=E_vertex(mEdge,mapVtxIndex[caseIndex]);

  pFace vFace=E_otherFace(mEdge,bFace,region);
  int vFaceDir=R_dirUsingFace(region,vFace);

  pEdge edges[7];    // the 7 edges to create two interior, quad and quad/tri, faces
  pFace faces[13];   // the 13 faces to create three new regions
  pEdge f_edges[4];  // the 3 or 4 edges to create a new face
  pFace r_faces[5];  // the 5 faces to create a new region
  pRegion regions[3];// the three regions created by this template

  int f_dir[4];      // the orientation of the 3 or 4 edges of a face
  int r_dir[5];      // the orientation of the 5 faces of a region

  plist=get_split_faces_selected_2(bFace);
  edges[0]=(pEdge)PList_item(plist,0);
  edges[1]=(pEdge)PList_item(plist,1);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  faces[2]=(pFace)PList_item(plist,4);

  int ambig=0;
  if(E_inClosure(edges[0],(pEntity)vtx))
    ambig=1;

  plist=get_split_faces_selected_2(uFace);
  edges[2]=(pEdge)PList_item(plist,0);
  edges[3]=(pEdge)PList_item(plist,1);
  faces[3]=(pFace)PList_item(plist,2);
  faces[4]=(pFace)PList_item(plist,3);
  faces[5]=(pFace)PList_item(plist,4);

  int mapIndex1[2][2]={{1,2}, {2,1}};
  plist=get_bisected_faces(qFace);
  edges[4]=(pEdge)PList_item(plist,0);
  faces[6]=(pFace)PList_item(plist,mapIndex1[qIndex][0]);
  faces[7]=(pFace)PList_item(plist,mapIndex1[qIndex][1]);

  plist=get_bisected_faces(vFace);
  edges[5]=(pEdge)PList_item(plist,0);
  faces[8]=(pFace)PList_item(plist,1);
  faces[9]=(pFace)PList_item(plist,2);

  // int tmpfIndex[2]={(uFaceIndex-1+3)%4+1,(uFaceIndex-1+1)%4+1};
  int tmpfIndex[2]={(uFaceIndex+2)%4+1,uFaceIndex%4+1};
  faces[10]=R_face(region,tmpfIndex[caseIndex]);

  edges[6]=F_vtOpEd(faces[10],vtx);

  int tmp_e_dir=0;
  if(!ambig && F_edOpVt(bFace,mEdge)!=E_vertex(edges[6],caseIndex))
    tmp_e_dir=1;
  int mapEDir1[2][2]={{1,0}, {0,1}};
  int numEdges1[2]={4,3};
  int mapEdges1[2][2][4]={{{0,5,2,6}, {0,2,4,-1}},
			  {{0,6,2,5}, {0,2,4,-1}}};
  int mapEDirs1[2][2][4]={{{1,vFaceDir,0,tmp_e_dir}, {0,1,mapEDir1[qIndex][qFaceDir],-1}},
			  {{0,tmp_e_dir,1,vFaceDir}, {0,1,mapEDir1[qIndex][qFaceDir],-1}}};
  for(int iEdge=0; iEdge<numEdges1[ambig]; iEdge++) {
    f_edges[iEdge]=edges[mapEdges1[caseIndex][ambig][iEdge]];
    f_dir[iEdge]=mapEDirs1[caseIndex][ambig][iEdge];
  }
  faces[11]=M_createF(pmesh,numEdges1[ambig],f_edges,f_dir,g_entity);

  int mapEDir2[2][2]={{0,1}, {1,0}};
  int mapEdges2[2][4]={{1,5,3,4}, {1,4,3,5}};
  int mapEDirs2[2][2][4]={{{0,vFaceDir,1,1-mapEDir2[qIndex][qFaceDir]}, {1,vFaceDir,0,1-mapEDir2[qIndex][qFaceDir]}},
			  {{1,mapEDir2[qIndex][qFaceDir],0,vFaceDir}, {0,mapEDir2[qIndex][qFaceDir],1,vFaceDir}}};
  for(int iEdge=0; iEdge<4; iEdge++) {
    f_edges[iEdge]=edges[mapEdges2[caseIndex][iEdge]];
    f_dir[iEdge]=mapEDirs2[caseIndex][ambig][iEdge];
  }
  faces[12]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  int f10Dir=R_dirUsingFace(region,faces[10]);
  
  // create three new regions
  if(ambig) {
    int mapFaces1[2][2][5]={{{6,11,0,10,3}, {6,0,10,3,11}},
                            {{7,11,3,10,0}, {7,3,10,0,11}}};
    int mapFDirs1[2][2][5]={{{qFaceDir,1,bFaceDir,f10Dir,uFaceDir}, {qFaceDir,bFaceDir,f10Dir,uFaceDir,1}},
                            {{qFaceDir,0,uFaceDir,f10Dir,bFaceDir}, {qFaceDir,uFaceDir,f10Dir,bFaceDir,0}}};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces1[caseIndex][qFaceDir][iFace]];
      r_dir[iFace]=mapFDirs1[caseIndex][qFaceDir][iFace];
    }
    regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

    int mapFaces2[2][5]={{12,11,4,9,1}, {12,9,4,11,1}};
    int mapFDirs2[2][5]={{1,0,uFaceDir,vFaceDir,bFaceDir}, {1,vFaceDir,uFaceDir,1,bFaceDir}};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces2[caseIndex][iFace]];
      r_dir[iFace]=mapFDirs2[caseIndex][iFace];
    }
    regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

    int mapFaces3[2][2][5]={{{2,12,7,8,5}, {2,7,8,12,5}},
                            {{2,12,8,6,5}, {2,8,6,12,5}}};
    int mapFDirs3[2][2][5]={{{bFaceDir,0,qFaceDir,vFaceDir,uFaceDir}, {bFaceDir,qFaceDir,vFaceDir,0,uFaceDir}},
                            {{bFaceDir,0,vFaceDir,qFaceDir,uFaceDir}, {bFaceDir,vFaceDir,qFaceDir,0,uFaceDir}}};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces3[caseIndex][bFaceDir][iFace]];
      r_dir[iFace]=mapFDirs3[caseIndex][bFaceDir][iFace];
    }
    regions[2]=M_createR(pmesh,5,r_faces,r_dir,g_entity);
  }
  else {
    int mapFaces1[2][5]={{11,10,3,9,0}, {11,9,3,10,0}};
    int mapFDirs1[2][5]={{1,f10Dir,uFaceDir,vFaceDir,bFaceDir}, {1,vFaceDir,uFaceDir,f10Dir,bFaceDir}};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces1[caseIndex][iFace]];
      r_dir[iFace]=mapFDirs1[caseIndex][iFace];
    }
    regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

    int mapFaces2[2][2][5]={{{1,12,11,6,4}, {1,6,12,11,4}},
                            {{1,11,12,7,4}, {1,7,11,12,4}}};
    int mapFDirs2[2][2][5]={{{bFaceDir,1,0,qFaceDir,uFaceDir}, {bFaceDir,qFaceDir,1,0,uFaceDir}},
                            {{bFaceDir,0,1,qFaceDir,uFaceDir}, {bFaceDir,qFaceDir,0,1,uFaceDir}}};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces2[caseIndex][bFaceDir][iFace]];
      r_dir[iFace]=mapFDirs2[caseIndex][bFaceDir][iFace];
    }
    regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

    int mapFaces3[2][2][5]={{{2,12,7,8,5}, {2,7,8,12,5}},
                            {{2,12,8,6,5}, {2,8,6,12,5}}};
    int mapFDirs3[2][2][5]={{{bFaceDir,0,qFaceDir,vFaceDir,uFaceDir}, {bFaceDir,qFaceDir,vFaceDir,0,uFaceDir}},
                            {{bFaceDir,0,vFaceDir,qFaceDir,uFaceDir}, {bFaceDir,vFaceDir,qFaceDir,0,uFaceDir}}};
    for(int iFace=0; iFace<5; iFace++) {
      r_faces[iFace]=faces[mapFaces3[caseIndex][bFaceDir][iFace]];
      r_dir[iFace]=mapFDirs3[caseIndex][bFaceDir][iFace];
    }
    regions[2]=M_createR(pmesh,5,r_faces,r_dir,g_entity);
  }

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
  {
//    if (ambig)
//      EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fTRANSITION);
//    else
      EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);
  }
  if(!F_typeInBL(faces[2]))
    EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[2]))
  {
   if (ambig)
     EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eTRANSITION);
   else
     EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eLAYER);
  }

  if(!E_typeInBL(edges[3]))
    EN_attachDataInt((pEntity)edges[3],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[3]))
   EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[4]))
  {
    if (ambig)
      EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fTRANSITION);
    else
      EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fLAYER);
  }

  if(!F_typeInBL(faces[5]))
    EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[4]))
    EN_attachDataInt((pEntity)edges[4],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[6]))
    EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[7]))
    EN_attachDataInt((pEntity)faces[7],blFaceTypeID,fVERTICAL_QUAD);

  if(!E_typeInBL(edges[5]))
    EN_attachDataInt((pEntity)edges[5],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[8]))
    EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[9]))
    EN_attachDataInt((pEntity)faces[9],blFaceTypeID,fVERTICAL_TRI);

  int f11TypeInBL[2]={fVERTICAL_QUAD,fVERTICAL_TRI};
  EN_attachDataInt((pEntity)faces[11],blFaceTypeID,f11TypeInBL[ambig]);
  EN_attachDataInt((pEntity)faces[12],blFaceTypeID,fVERTICAL_QUAD);

  int rgnsTypeInBL[2][3]={{rTRANSITION_PYR,rREGULAR,rREGULAR}, {rTRANSITION_PYR,rTRANSITION_PYR,rREGULAR}};
  for(int iRgn=0; iRgn<3; iRgn++)
    EN_attachDataInt((pEntity)regions[iRgn],blRegionTypeID,rgnsTypeInBL[ambig][iRgn]);
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!E_typeInBL(edges[1])) {
    EN_labelBLEntity((pEntity)edges[1],level-1,eLAYER);
    // E_correctTypeAndLevelInBL(edges[1]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    if(ambig) {
      EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
      F_correctTypeAndLevelInBL(faces[1]);
    }
    else {
      EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
      // F_correctTypeAndLevelInBL(faces[1]);
    }
  }
  if(!F_typeInBL(faces[2])) {
    EN_labelBLEntity((pEntity)faces[2],level-1,fLAYER);
    // F_correctTypeAndLevelInBL(faces[2]);
  }

  if(!E_typeInBL(edges[2])) {
    if(ambig)
      EN_labelBLEntity((pEntity)edges[2],level,eTRANSITION);
    else
      EN_labelBLEntity((pEntity)edges[2],level,eLAYER);
  }
  // BL edge type is eLAYER at "level"
  if(!E_typeInBL(edges[3]))
    EN_labelBLEntity((pEntity)edges[3],level,eLAYER);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[3]))
    EN_labelBLEntity((pEntity)faces[3],level,fTRANSITION);
  if(!F_typeInBL(faces[4])) {
    if(ambig)
      EN_labelBLEntity((pEntity)faces[4],level,fTRANSITION);
    else
      EN_labelBLEntity((pEntity)faces[4],level,fLAYER);
  }
  // BL face type is fLAYER at "level"
  if(!F_typeInBL(faces[5]))
    EN_labelBLEntity((pEntity)faces[5],level,fLAYER);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[4]))
    EN_labelBLEntity((pEntity)edges[4],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[6]))
    EN_labelBLEntity((pEntity)faces[6],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[7]))
    EN_labelBLEntity((pEntity)faces[7],level,fVERTICAL_QUAD);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[5]))
    EN_labelBLEntity((pEntity)edges[5],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[8]))
    EN_labelBLEntity((pEntity)faces[8],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[9]))
    EN_labelBLEntity((pEntity)faces[9],level,fVERTICAL_TRI);

  int f11TypeInBL[2]={fVERTICAL_QUAD,fVERTICAL_TRI};
  EN_labelBLEntity((pEntity)faces[11],level,f11TypeInBL[ambig]);
  EN_labelBLEntity((pEntity)faces[12],level,fVERTICAL_QUAD);

  int rgnsTypeInBL[2][3]={{rTRANSITION_PYR,rREGULAR,rREGULAR}, {rTRANSITION_PYR,rTRANSITION_PYR,rREGULAR}};
  for(int iRgn=0; iRgn<3; iRgn++)
    EN_labelBLEntity((pEntity)regions[iRgn],level,rgnsTypeInBL[ambig][iRgn]);


  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[5]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // delete faces if it can be
  delete_face(bFace,0);
  delete_face(uFace,0);
  delete_face(qFace,0);

  int eCount=0;
  // initialize to zero for safety
  pEdge delEdges[2]={0,0};
  for(int iEdge=0; iEdge<3; iEdge++) {
    pEdge edg=F_edge(vFace,iEdge);
    if(E_inClosure(edg,(pEntity)vtx))
      delEdges[eCount++]=edg;
  }
  delete_face(vFace,0);

  // delete edge if it can be
  delete_edge(delEdges[0],0);
  delete_edge(delEdges[1],0);
  delete_edge(bEdge,0);
  delete_edge(uEdge,0);

}

void meshTemplate::template_pyramid_2_b(pRegion region,
					pPList newRgns,
					pPList newEdges) {
//   pVertex parent_verts[5];
//   pEdge parent_edges[8];
//   pFace parent_faces[5];
//   int parent_f_dirs[5];

  pPList plist;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<5; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<8; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<5; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace]=R_faceDir(region,iFace);
//   }

  pFace qFace=R_face(region,0);
  int qFaceDir=R_faceDir(region,0);

  int bFaceDir, uFaceDir, uFaceIndex;
  pFace bFace, uFace;
  int ftype;
  for(int iFace=1; iFace<5; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
      // uFaceIndex=(iFace-1+2)%4+1;
      uFaceIndex=(iFace+1)%4+1;
      uFace=R_face(region,uFaceIndex);

      bFaceDir=R_faceDir(region,iFace);
      uFaceDir=R_faceDir(region,uFaceIndex);
      break;
    }
  }

  int value, umEdgeDir;
  pEdge umEdge;
  // base face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    umEdge=F_edge(bFace,iEdge);
    if( !EN_getDataInt((pEntity)umEdge,int_reff,&value) ||
        value!=1) {
      umEdgeDir=F_edgeDir(bFace,iEdge);
      break;
    }
  }

  int vtxIndex[2]={1,0};
  pVertex vtx=E_vertex(umEdge,vtxIndex[(bFaceDir+umEdgeDir)%2]);
  pVertex oVtx=E_otherVertex(umEdge,vtx);
  pVertex mapVtx[2]={vtx,oVtx};

  pEdge edges[7];    // the 7 edges to create two interior quad faces
  pFace faces[13];   // the 13 faces to create three new regions
  pEdge f_edges[4];  // the 4 edges to create a new quad face
  pFace r_faces[5];  // the 5 faces to create a new region
  pRegion regions[3];// the three regions created by this template

  int f_dir[4];      // the orientation of the 4 edges of a face
  int r_dir[5];      // the orientation of the 5 faces of a region

  plist=get_split_faces_selected_2(bFace);
  edges[0]=(pEdge)PList_item(plist,0);
  edges[1]=(pEdge)PList_item(plist,1);
  faces[0]=(pFace)PList_item(plist,2);
  faces[1]=(pFace)PList_item(plist,3);
  faces[2]=(pFace)PList_item(plist,4);

  int ambig=0;
  if(!E_inClosure(edges[0],(pEntity)vtx))
    ambig=1;

  // int tmpVFaceIndex[2]={(uFaceIndex-1+1)%4+1,(uFaceIndex-1+3)%4+1};
  int tmpVFaceIndex[2]={uFaceIndex%4+1,(uFaceIndex+2)%4+1};
  int vFaceIndex[2][2]={{tmpVFaceIndex[1],tmpVFaceIndex[0]}, {tmpVFaceIndex[0],tmpVFaceIndex[1]}};

  int vFaceDir1=R_faceDir(region,vFaceIndex[ambig][0]);
  pFace vFace1=R_face(region,vFaceIndex[ambig][0]);

  int vFaceDir2=R_faceDir(region,vFaceIndex[ambig][1]);
  pFace vFace2=R_face(region,vFaceIndex[ambig][1]);

  plist=get_split_faces_selected_2(uFace);
  edges[2]=(pEdge)PList_item(plist,0);
  edges[3]=(pEdge)PList_item(plist,1);
  faces[3]=(pFace)PList_item(plist,2);
  faces[4]=(pFace)PList_item(plist,3);
  faces[5]=(pFace)PList_item(plist,4);

  plist=get_bisected_faces(vFace1);
  edges[4]=(pEdge)PList_item(plist,0);
  faces[6]=(pFace)PList_item(plist,1);
  faces[7]=(pFace)PList_item(plist,2);

  plist=get_bisected_faces(vFace2);
  edges[5]=(pEdge)PList_item(plist,0);
  faces[8]=(pFace)PList_item(plist,1);
  faces[9]=(pFace)PList_item(plist,2);

  faces[10]=qFace;

  for(int iEdge=0; iEdge<4; iEdge++) {
    pEdge edg=F_edge(qFace,iEdge);
    if(edg!=umEdge && E_inClosure(edg,(pEntity)mapVtx[ambig])) {
      edges[6]=edg;
      break;
    }
  }

  int mapEdges1[2][4]={{1,5,3,4}, {1,4,3,5}};
  int mapEDirs1[2][4]={{0,vFaceDir2,1,vFaceDir1}, {1,vFaceDir1,0,vFaceDir2}};
  for(int iEdge=0; iEdge<4; iEdge++) {
    f_edges[iEdge]=edges[mapEdges1[ambig][iEdge]];
    f_dir[iEdge]=mapEDirs1[ambig][iEdge];
  }
  faces[11]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  int tmp_e_dir=0;
  if(mapVtx[ambig]!=E_vertex(edges[6],ambig))
    tmp_e_dir=1;
  int mapEdges2[2][4]={{0,5,2,6}, {0,6,2,5}};
  int mapEDirs2[2][4]={{1,vFaceDir2,0,tmp_e_dir}, {0,tmp_e_dir,1,vFaceDir2}};
  for(int iEdge=0; iEdge<4; iEdge++) {
    f_edges[iEdge]=edges[mapEdges2[ambig][iEdge]];
    f_dir[iEdge]=mapEDirs2[ambig][iEdge];
  }
  faces[12]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  // create three new regions
  int mapFaces1[2][2][5]={{{0,12,10,8,3}, {0,10,8,12,3}},
                          {{0,12,8,10,3}, {0,8,10,12,3}}};
  int mapFDirs1[2][2][5]={{{bFaceDir,0,qFaceDir,vFaceDir2,uFaceDir}, {bFaceDir,qFaceDir,vFaceDir2,0,uFaceDir}},
                          {{bFaceDir,0,vFaceDir2,qFaceDir,uFaceDir}, {bFaceDir,vFaceDir2,qFaceDir,0,uFaceDir}}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces1[ambig][bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs1[ambig][bFaceDir][iFace];
  }
  regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  int mapFaces2[2][2][5]={{{1,12,11,6,4}, {1,6,12,11,4}},
                          {{1,11,12,6,4}, {1,6,11,12,4}}};
  int mapFDirs2[2][2][5]={{{bFaceDir,1,0,vFaceDir1,uFaceDir}, {bFaceDir,vFaceDir1,1,0,uFaceDir}},
                          {{bFaceDir,0,1,vFaceDir1,uFaceDir}, {bFaceDir,vFaceDir1,0,1,uFaceDir}}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces2[ambig][bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs2[ambig][bFaceDir][iFace];
  }
  regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  int mapFaces3[2][5]={{11,7,5,9,2}, {11,9,5,7,2}};
  int mapFDirs3[2][5]={{1,vFaceDir1,uFaceDir,vFaceDir2,bFaceDir}, {1,vFaceDir2,uFaceDir,vFaceDir1,bFaceDir}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces3[ambig][iFace]];
    r_dir[iFace]=mapFDirs3[ambig][iFace];
  }
  regions[2]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
    EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[2]))
    EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[2]))
    EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[3]))
    EN_attachDataInt((pEntity)edges[3],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[3]))
    EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[4]))
    EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[5]))
    EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fTRANSITION);

  if(!E_typeInBL(edges[4]))
    EN_attachDataInt((pEntity)edges[4],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[6]))
    EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[7]))
    EN_attachDataInt((pEntity)faces[7],blFaceTypeID,fVERTICAL_TRI);

  if(!E_typeInBL(edges[5]))
    EN_attachDataInt((pEntity)edges[5],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[8]))
    EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[9]))
    EN_attachDataInt((pEntity)faces[9],blFaceTypeID,fVERTICAL_TRI);

  EN_attachDataInt((pEntity)faces[11],blFaceTypeID,fVERTICAL_QUAD);
  EN_attachDataInt((pEntity)faces[12],blFaceTypeID,fVERTICAL_QUAD);

  EN_attachDataInt((pEntity)regions[0],blRegionTypeID,rREGULAR);
  EN_attachDataInt((pEntity)regions[1],blRegionTypeID,rREGULAR);
  EN_attachDataInt((pEntity)regions[2],blRegionTypeID,rTRANSITION_PYR);
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    // E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!E_typeInBL(edges[1])) {
    EN_labelBLEntity((pEntity)edges[1],level-1,eLAYER);
    // E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    // F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
    // F_correctTypeAndLevelInBL(faces[1]);
  }
  if(!F_typeInBL(faces[2])) {
    EN_labelBLEntity((pEntity)faces[2],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[2]);
  }

  // BL edge type is eLAYER at "level"
  if(!E_typeInBL(edges[2]))
    EN_labelBLEntity((pEntity)edges[2],level,eLAYER);
  if(!E_typeInBL(edges[3]))
    EN_labelBLEntity((pEntity)edges[3],level,eLAYER);
  // BL face type is fLAYER at "level"
  if(!F_typeInBL(faces[3]))
    EN_labelBLEntity((pEntity)faces[3],level,fLAYER);
  if(!F_typeInBL(faces[4]))
    EN_labelBLEntity((pEntity)faces[4],level,fLAYER);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[5]))
    EN_labelBLEntity((pEntity)faces[5],level,fTRANSITION);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[4]))
    EN_labelBLEntity((pEntity)edges[4],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[6]))
    EN_labelBLEntity((pEntity)faces[6],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[7]))
    EN_labelBLEntity((pEntity)faces[7],level,fVERTICAL_TRI);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[5]))
    EN_labelBLEntity((pEntity)edges[5],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[8]))
    EN_labelBLEntity((pEntity)faces[8],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[9]))
    EN_labelBLEntity((pEntity)faces[9],level,fVERTICAL_TRI);

  EN_labelBLEntity((pEntity)faces[11],level,fVERTICAL_QUAD);
  EN_labelBLEntity((pEntity)faces[12],level,fVERTICAL_QUAD);

  EN_labelBLEntity((pEntity)regions[0],level,rREGULAR);
  EN_labelBLEntity((pEntity)regions[1],level,rREGULAR);
  EN_labelBLEntity((pEntity)regions[2],level,rTRANSITION_PYR);

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[4]);
    PList_append(newEdges,edges[5]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // initialize to zero for safety
  int eCount=0;
  pEdge delEdges[4]={0,0,0,0};
  for(int iEdge=0; iEdge<3; iEdge++) {
    pEdge edg=F_edge(bFace,iEdge);
    if(!F_inClosure(qFace,(pEntity)edg))
      delEdges[eCount++]=edg;

    edg=F_edge(uFace,iEdge);
    if(!F_inClosure(qFace,(pEntity)edg))
      delEdges[eCount++]=edg;
  }

  // delete faces if it can be
  delete_face(bFace,0);
  delete_face(uFace,0);
  delete_face(vFace1,0);
  delete_face(vFace2,0);

  // delete edge if it can be
  delete_edge(delEdges[0],0);
  delete_edge(delEdges[1],0);
  delete_edge(delEdges[2],0);
  delete_edge(delEdges[3],0);

}

void meshTemplate::template_pyramid_3(pRegion region,
				      pPList newRgns,
				      pPList newEdges) {
//   pVertex parent_verts[5];
//   pEdge parent_edges[8];
//   pFace parent_faces[5];
//   int parent_f_dirs[5];

  pPList plist;

  pGEntity g_entity=(pGEntity)R_whatIn(region);

//   pPList ordered_verts=R_vertices(region,1);
//   for(int iVert=0; iVert<5; iVert++)
//     parent_verts[iVert]=(pVertex)PList_item(ordered_verts,iVert);
//   PList_delete(ordered_verts);

//   pPList ordered_edges=R_edges(region,1);
//   for(int iEdge=0; iEdge<8; iEdge++)
//     parent_edges[iEdge]=(pEdge)PList_item(ordered_edges,iEdge);
//   PList_delete(ordered_edges);

//   for(int iFace=0; iFace<5; iFace++) {
//     parent_faces[iFace]=R_face(region,iFace);
//     // parent_f_dirs[iFace]=R_dirUsingFace(region,parent_faces[iFace]);
//     parent_f_dirs[iFace]=R_faceDir(region,iFace);
//   }

  pFace qFace=R_face(region,0);
  int qFaceDir=R_faceDir(region,0);

  int bFaceDir, uFaceDir, uFaceIndex;
  pFace bFace, uFace;
  int ftype;
  for(int iFace=1; iFace<5; iFace++) {
    bFace=R_face(region,iFace);
    ftype = F_typeInBL(bFace);
    if ((ftype == fTRANSITION || ftype == fLAYER) && !F_region(bFace,1) && !EN_onCB(bFace))
    {
      // uFaceIndex=(iFace-1+2)%4+1;
      uFaceIndex=(iFace+1)%4+1;
      uFace=R_face(region,uFaceIndex);

      bFaceDir=R_faceDir(region,iFace);
      uFaceDir=R_faceDir(region,uFaceIndex);
      break;
    }
  }

  int bEdgeIndex, uEdgeIndex, qIndex;
  pEdge bEdge, uEdge;
  for(int iEdge=0; iEdge<4; iEdge++) {
    bEdge=F_edge(qFace,iEdge);
    if(F_inClosure(bFace,(pEntity)bEdge)) {
      bEdgeIndex=iEdge;
      uEdgeIndex=(iEdge+2)%4;

      int mapQIndex[2][4]={{1,0,0,1}, {0,1,1,0}};
      qIndex=mapQIndex[qFaceDir][uEdgeIndex];

      uEdge=F_edge(qFace,uEdgeIndex);
      break;
    }
  }

  // initialize to -1 for safety
  int offset[2]={-1,-1};

  // base face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    if(bEdge==F_edge(bFace,iEdge)) {
      offset[0]=iEdge;
      break;
    }
  }

  // upper face must be a triangle
  for(int iEdge=0; iEdge<3; iEdge++) {
    if(uEdge==F_edge(uFace,iEdge)) {
      offset[1]=iEdge;
      break;
    }
  }

  // pFace vFace1=E_verticalFace(F_edge(bFace,(offset[0]+1)%3),1);
  pFace vFace1=E_otherFace(F_edge(bFace,(offset[0]+1)%3),bFace,region);
  int vFaceDir1=R_dirUsingFace(region,vFace1);

  // pFace vFace2=E_verticalFace(F_edge(bFace,(offset[0]+2)%3),1);
  pFace vFace2=E_otherFace(F_edge(bFace,(offset[0]+2)%3),bFace,region);
  int vFaceDir2=R_dirUsingFace(region,vFace2);

  pEdge edges[9];    // the 9 edges to create three interior quad faces
  pFace faces[17];   // the 17 faces to create four new regions
  pEdge f_edges[4];  // the 4 edges to create a new quad face
  pFace r_faces[5];  // the 5 faces to create a new region
  pRegion regions[4];// the four regions created by this template

  int f_dir[4];      // the orientation of the 4 edges of a face
  int r_dir[5];      // the orientation of the 5 faces of a region

  int index_in_list[2][3];
  for(int i=0; i<2; i++)
    for(int j=0; j<3; j++)
      index_in_list[i][j]=(j+offset[i])%3;

  // if upper and lower face both points in or out
  if(bFaceDir==uFaceDir) {
    // swap the first two indices for the upper face
    int tmp_index=index_in_list[1][0];
    index_in_list[1][0]=index_in_list[1][1];
    index_in_list[1][1]=tmp_index;
  }

  plist=get_split_faces_3(bFace);
  for(int i=0; i<3; i++) {
    edges[i]=(pEdge)PList_item(plist,index_in_list[0][i]);
    faces[i]=(pFace)PList_item(plist,3+index_in_list[0][i]);
  }
  faces[3]=(pFace)PList_item(plist,6);

  plist=get_split_faces_3(uFace);
  for(int i=0; i<3; i++) {
    edges[3+i]=(pEdge)PList_item(plist,index_in_list[1][i]);
    faces[4+i]=(pFace)PList_item(plist,3+index_in_list[1][i]);
  }
  faces[7]=(pFace)PList_item(plist,6);

  plist=get_bisected_faces(vFace1);
  edges[6]=(pEdge)PList_item(plist,0);
  faces[8]=(pFace)PList_item(plist,1);
  faces[9]=(pFace)PList_item(plist,2);

  plist=get_bisected_faces(vFace2);
  edges[7]=(pEdge)PList_item(plist,0);
  faces[10]=(pFace)PList_item(plist,1);
  faces[11]=(pFace)PList_item(plist,2);

  int mapIndex[2][2][2]={{{1,2}, {2,1}},
                         {{2,1}, {1,2}}};
  plist=get_bisected_faces(qFace);
  edges[8]=(pEdge)PList_item(plist,0);
  faces[12]=(pFace)PList_item(plist,mapIndex[qIndex][bFaceDir][0]);
  faces[13]=(pFace)PList_item(plist,mapIndex[qIndex][bFaceDir][1]);

  int mapEDir1[2][2]={{0,1}, {1,0}};
  int mapEdges1[2][4]={{0,8,3,7}, {0,7,3,8}};
  int mapEDirs1[2][4]={{1,mapEDir1[qIndex][qFaceDir],1-uFaceDir,vFaceDir2}, {0,vFaceDir2,1-uFaceDir,1-mapEDir1[qIndex][qFaceDir]}};
  for(int iEdge=0; iEdge<4; iEdge++) {
    f_edges[iEdge]=edges[mapEdges1[bFaceDir][iEdge]];
    f_dir[iEdge]=mapEDirs1[bFaceDir][iEdge];
  }
  faces[14]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  int mapEDir2[2][2]={{1,0}, {0,1}};
  int mapEdges2[2][4]={{1,6,4,8}, {1,8,4,6}};
  int mapEDirs2[2][4]={{1,vFaceDir1,1-uFaceDir,mapEDir2[qIndex][qFaceDir]}, {0,1-mapEDir2[qIndex][qFaceDir],1-uFaceDir,vFaceDir1}};
  for(int iEdge=0; iEdge<4; iEdge++) {
    f_edges[iEdge]=edges[mapEdges2[bFaceDir][iEdge]];
    f_dir[iEdge]=mapEDirs2[bFaceDir][iEdge];
  }
  faces[15]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  int mapEdges3[2][4]={{2,7,5,6}, {2,6,5,7}};
  int mapEDirs3[2][4]={{1,1-vFaceDir2,1-uFaceDir,1-vFaceDir1}, {0,1-vFaceDir1,1-uFaceDir,1-vFaceDir2}};
  for(int iEdge=0; iEdge<4; iEdge++) {
    f_edges[iEdge]=edges[mapEdges3[bFaceDir][iEdge]];
    f_dir[iEdge]=mapEDirs3[bFaceDir][iEdge];
  }
  faces[16]=M_createF(pmesh,4,f_edges,f_dir,g_entity);

  // create four new regions
  int mapFaces1[2][5]={{0,14,10,12,4}, {0,12,10,14,4}};
  int mapFDirs1[2][5]={{bFaceDir,0,vFaceDir2,qFaceDir,uFaceDir}, {bFaceDir,qFaceDir,vFaceDir2,0,uFaceDir}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces1[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs1[bFaceDir][iFace];
  }
  regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  int mapFaces2[2][5]={{1,15,13,8,5}, {1,8,13,15,5}};
  int mapFDirs2[2][5]={{bFaceDir,0,qFaceDir,vFaceDir1,uFaceDir}, {bFaceDir,vFaceDir1,qFaceDir,0,uFaceDir}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces2[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs2[bFaceDir][iFace];
  }
  regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  int mapFaces3[2][5]={{16,2,11,6,9}, {16,2,9,6,11}};
  int mapFDirs3[2][5]={{0,bFaceDir,vFaceDir2,uFaceDir,vFaceDir1}, {0,bFaceDir,vFaceDir1,uFaceDir,vFaceDir2}};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces3[bFaceDir][iFace]];
    r_dir[iFace]=mapFDirs3[bFaceDir][iFace];
  }
  regions[2]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  int mapFaces4[2][3][5]={{{3,14,15,16,7}, {3,16,14,15,7}, {3,15,16,14,7}},
                          {{3,16,15,14,7}, {3,15,14,16,7}, {3,14,16,15,7}}};
  int mapFDirs4[5]={bFaceDir,1,1,1,uFaceDir};
  for(int iFace=0; iFace<5; iFace++) {
    r_faces[iFace]=faces[mapFaces4[bFaceDir][offset[0]][iFace]];
    r_dir[iFace]=mapFDirs4[iFace];
  }
  regions[3]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

//  int surfTag=EN_blSurfaceTag((pEntity)region);
  // int level=rLevelInBL;
  int level=EN_levelInBL((pEntity)region);
/*
  if(!E_typeInBL(edges[0]))
    EN_attachDataInt((pEntity)edges[0],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[1]))
    EN_attachDataInt((pEntity)edges[1],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[2]))
    EN_attachDataInt((pEntity)edges[2],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[0]))
    EN_attachDataInt((pEntity)faces[0],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[1]))
    EN_attachDataInt((pEntity)faces[1],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[2]))
    EN_attachDataInt((pEntity)faces[2],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[3]))
    EN_attachDataInt((pEntity)faces[3],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[3]))
    EN_attachDataInt((pEntity)edges[3],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[4]))
    EN_attachDataInt((pEntity)edges[4],blEdgeTypeID,eLAYER);
  if(!E_typeInBL(edges[5]))
    EN_attachDataInt((pEntity)edges[5],blEdgeTypeID,eLAYER);
  if(!F_typeInBL(faces[4]))
    EN_attachDataInt((pEntity)faces[4],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[5]))
    EN_attachDataInt((pEntity)faces[5],blFaceTypeID,fLAYER);
  if(!F_typeInBL(faces[6]))
    EN_attachDataInt((pEntity)faces[6],blFaceTypeID,fTRANSITION);
  if(!F_typeInBL(faces[7]))
    EN_attachDataInt((pEntity)faces[7],blFaceTypeID,fLAYER);

  if(!E_typeInBL(edges[6]))
    EN_attachDataInt((pEntity)edges[6],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[8]))
    EN_attachDataInt((pEntity)faces[8],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[9]))
    EN_attachDataInt((pEntity)faces[9],blFaceTypeID,fVERTICAL_TRI);

  if(!E_typeInBL(edges[7]))
    EN_attachDataInt((pEntity)edges[7],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[10]))
    EN_attachDataInt((pEntity)faces[10],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[11]))
    EN_attachDataInt((pEntity)faces[11],blFaceTypeID,fVERTICAL_TRI);

  if(!E_typeInBL(edges[8]))
    EN_attachDataInt((pEntity)edges[8],blEdgeTypeID,eGROWTH);
  if(!F_typeInBL(faces[12]))
    EN_attachDataInt((pEntity)faces[12],blFaceTypeID,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[13]))
    EN_attachDataInt((pEntity)faces[13],blFaceTypeID,fVERTICAL_QUAD);

  EN_attachDataInt((pEntity)faces[14],blFaceTypeID,fVERTICAL_QUAD);
  EN_attachDataInt((pEntity)faces[15],blFaceTypeID,fVERTICAL_QUAD);
  EN_attachDataInt((pEntity)faces[16],blFaceTypeID,fVERTICAL_QUAD);

  EN_attachDataInt((pEntity)regions[0],blRegionTypeID,rREGULAR);
  EN_attachDataInt((pEntity)regions[1],blRegionTypeID,rREGULAR);
  EN_attachDataInt((pEntity)regions[2],blRegionTypeID,rTRANSITION_PYR);
  EN_attachDataInt((pEntity)regions[3],blRegionTypeID,rREGULAR);
*/

  if(!E_typeInBL(edges[0])) {
    EN_labelBLEntity((pEntity)edges[0],level-1,eLAYER);
    // E_correctTypeAndLevelInBL(edges[0]);
  }
  if(!E_typeInBL(edges[1])) {
    EN_labelBLEntity((pEntity)edges[1],level-1,eLAYER);
    // E_correctTypeAndLevelInBL(edges[1]);
  }
  if(!E_typeInBL(edges[2])) {
    EN_labelBLEntity((pEntity)edges[2],level-1,eLAYER);
    // E_correctTypeAndLevelInBL(edges[2]);
  }
  if(!F_typeInBL(faces[0])) {
    EN_labelBLEntity((pEntity)faces[0],level-1,fLAYER);
    // F_correctTypeAndLevelInBL(faces[0]);
  }
  if(!F_typeInBL(faces[1])) {
    EN_labelBLEntity((pEntity)faces[1],level-1,fLAYER);
    // F_correctTypeAndLevelInBL(faces[1]);
  }
  if(!F_typeInBL(faces[2])) {
    EN_labelBLEntity((pEntity)faces[2],level-1,fLAYER);
    F_correctTypeAndLevelInBL(faces[2]);
  }
  if(!F_typeInBL(faces[3])) {
    EN_labelBLEntity((pEntity)faces[3],level-1,fLAYER);
    // F_correctTypeAndLevelInBL(faces[3]);
  }

  // BL edge type is eLAYER at "level"
  if(!E_typeInBL(edges[3]))
    EN_labelBLEntity((pEntity)edges[3],level,eLAYER);
  if(!E_typeInBL(edges[4]))
    EN_labelBLEntity((pEntity)edges[4],level,eLAYER);
  if(!E_typeInBL(edges[5]))
    EN_labelBLEntity((pEntity)edges[5],level,eLAYER);
  // BL face type is fLAYER at "level"
  if(!F_typeInBL(faces[4]))
    EN_labelBLEntity((pEntity)faces[4],level,fLAYER);
  if(!F_typeInBL(faces[5]))
    EN_labelBLEntity((pEntity)faces[5],level,fLAYER);
  // BL face type is fTRANSITION at "level"
  if(!F_typeInBL(faces[6]))
    EN_labelBLEntity((pEntity)faces[6],level,fTRANSITION);
  // BL face type is fLAYER at "level"
  if(!F_typeInBL(faces[7]))
    EN_labelBLEntity((pEntity)faces[7],level,fLAYER);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[6]))
    EN_labelBLEntity((pEntity)edges[6],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[8]))
    EN_labelBLEntity((pEntity)faces[8],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[9]))
    EN_labelBLEntity((pEntity)faces[9],level,fVERTICAL_TRI);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[7]))
    EN_labelBLEntity((pEntity)edges[7],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[10]))
    EN_labelBLEntity((pEntity)faces[10],level,fVERTICAL_QUAD);
  // BL face type is fVERTICAL_TRI at "level"
  if(!F_typeInBL(faces[11]))
    EN_labelBLEntity((pEntity)faces[11],level,fVERTICAL_TRI);

  // BL edge type is eGROWTH at "level"
  if(!E_typeInBL(edges[8]))
    EN_labelBLEntity((pEntity)edges[8],level,eGROWTH);
  // BL face type is fVERTICAL_QUAD at "level"
  if(!F_typeInBL(faces[12]))
    EN_labelBLEntity((pEntity)faces[12],level,fVERTICAL_QUAD);
  if(!F_typeInBL(faces[13]))
    EN_labelBLEntity((pEntity)faces[13],level,fVERTICAL_QUAD);

  EN_labelBLEntity((pEntity)faces[14],level,fVERTICAL_QUAD);
  EN_labelBLEntity((pEntity)faces[15],level,fVERTICAL_QUAD);
  EN_labelBLEntity((pEntity)faces[16],level,fVERTICAL_QUAD);

  EN_labelBLEntity((pEntity)regions[0],level,rREGULAR);
  EN_labelBLEntity((pEntity)regions[1],level,rREGULAR);
  EN_labelBLEntity((pEntity)regions[2],level,rTRANSITION_PYR);
  EN_labelBLEntity((pEntity)regions[3],level,rREGULAR);

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
    PList_append(newRgns,regions[2]);
    PList_append(newRgns,regions[3]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
    PList_append(newEdges,edges[3]);
    PList_append(newEdges,edges[4]);
    PList_append(newEdges,edges[5]);
    PList_append(newEdges,edges[6]);
    PList_append(newEdges,edges[7]);
    PList_append(newEdges,edges[8]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);

  // delete faces if it can be
  delete_face(qFace,0);
  delete_face(vFace1,0);
  delete_face(vFace2,0);

  // initialize to zero for safety
  pEdge delEdges[6]={0,0,0,0,0,0};
  for(int iEdge=0; iEdge<3; iEdge++) {
    delEdges[iEdge]=F_edge(bFace,iEdge);
    delEdges[iEdge+3]=F_edge(uFace,iEdge);
  }
  delete_face(bFace,0);
  delete_face(uFace,0);

  // delete edge if it can be
  for(int iEdge=0; iEdge<6; iEdge++)
    delete_edge(delEdges[iEdge],0);

}


void meshTemplate::template_reg_prism_1(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[9];
  pFace parent_faces[5];
  pVertex parent_verts[6];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  /// Look for the tagged edge
  int iTag;
  pEdge pEdgeEdge;
  for (int iEdge = 0; iEdge < 3; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if(EN_getDataInt((pEntity)pEdgeEdge, int_reff, &iTag))
    {
      iTag = iEdge;
      break;
    }
  }

  // mapping
  templatesUtil::mapping_template_prism(region,ordered_edges,iTag,parent_faces,parent_edges,parent_verts);

  pVertex pVertexNewVtx[6];
  pEdge pEdgeNewEdge[3];
  pRegion pRegionNewRgn[2];

  pPList plist;
  pVertex pVertexMidVtx[2];
  plist = get_split_edges(parent_edges[0]);
  pVertexMidVtx[0] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[6]);
  pVertexMidVtx[1] = (pVertex)PList_item(plist, 0);

  plist = get_bisected_faces(parent_faces[1]);
  pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);

  if(!E_typeInBL((pEntity)pEdgeNewEdge[0]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[0], blEdgeTypeID, eGROWTH);

  pVertexNewVtx[0] = pVertexMidVtx[0];
  pVertexNewVtx[1] = parent_verts[1];
  pVertexNewVtx[2] = parent_verts[2];
  pVertexNewVtx[3] = pVertexMidVtx[1];
  pVertexNewVtx[4] = parent_verts[4];
  pVertexNewVtx[5] = parent_verts[5];  
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[0]);


  pVertexNewVtx[1] = parent_verts[0];
  pVertexNewVtx[4] = parent_verts[3];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[1]);

  if( newRgns )
  {
    for (int iReg = 0; iReg < 2; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if ( newEdges )
  {
    plist = get_split_faces_1(parent_faces[0]);
    pEdgeNewEdge[1] = (pEdge)PList_item(plist, 0);
    plist = get_split_faces_1(parent_faces[4]);
    pEdgeNewEdge[2] = (pEdge)PList_item(plist, 0);

    for (int iEdge = 0; iEdge < 3; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[4],0);

  // delete edge if it can be
  delete_edge(parent_edges[0],0);
  delete_edge(parent_edges[6],0);
}


void meshTemplate::template_reg_prism_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[9];
  pFace parent_faces[5];
  pVertex parent_verts[6];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  /// Look for the tagged edge
  int iTag;
  pEdge pEdgeEdge;
  for (int iEdge = 0; iEdge < 3; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if(!EN_getDataInt((pEntity)pEdgeEdge, int_reff, &iTag))
    {
      iTag = iEdge;
      break;
    }
  }

  templatesUtil::mapping_template_prism(region,ordered_edges,iTag,parent_faces,parent_edges,parent_verts);

  pVertex pVertexNewVtx[6];
  pEdge pEdgeNewEdge[6];
  pRegion pRegionNewRgn[3];

  pPList plist;
  pVertex pVertexMidVtx[4];
  plist = get_split_edges(parent_edges[1]);
  pVertexMidVtx[0] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[7]);
  pVertexMidVtx[1] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[2]);
  pVertexMidVtx[2] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[8]);
  pVertexMidVtx[3] = (pVertex)PList_item(plist, 0);

  plist = get_bisected_faces(parent_faces[2]);
  pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
  if(!E_typeInBL((pEntity)pEdgeNewEdge[0]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[0], blEdgeTypeID, eGROWTH);

  plist = get_bisected_faces(parent_faces[3]);
  pEdgeNewEdge[1] = (pEdge)PList_item(plist, 0);
  if(!E_typeInBL((pEntity)pEdgeNewEdge[1]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[1], blEdgeTypeID, eGROWTH);

  plist = get_split_faces_2(parent_faces[0]);
  pEdgeNewEdge[2] = (pEdge)PList_item(plist, 0);
  pEdgeNewEdge[3] = (pEdge)PList_item(plist, 1);

  int iCase;
  if ((E_vertex(pEdgeNewEdge[2], 0) == parent_verts[0]) || (E_vertex(pEdgeNewEdge[0], 1) == parent_verts[0]))
    iCase = 0;
  else
    iCase = 1;

  if (iCase == 0)
  {
    pVertexNewVtx[0] = parent_verts[0];
    pVertexNewVtx[1] = pVertexMidVtx[0];
    pVertexNewVtx[2] = parent_verts[1];
    pVertexNewVtx[3] = parent_verts[3];
    pVertexNewVtx[4] = pVertexMidVtx[1];
    pVertexNewVtx[5] = parent_verts[4];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[0]);

    pVertexNewVtx[2] = pVertexMidVtx[2];
    pVertexNewVtx[5] = pVertexMidVtx[3];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[1]);
  }
  else
  {
    pVertexNewVtx[0] = parent_verts[1];
    pVertexNewVtx[1] = parent_verts[0];
    pVertexNewVtx[2] = pVertexMidVtx[2];
    pVertexNewVtx[3] = parent_verts[4];
    pVertexNewVtx[4] = parent_verts[3];
    pVertexNewVtx[5] = pVertexMidVtx[3];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[0]);

    pVertexNewVtx[1] = pVertexMidVtx[0];
    pVertexNewVtx[4] = pVertexMidVtx[1];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[1]);
  }
  
  pVertexNewVtx[0] = parent_verts[2];
  pVertexNewVtx[3] = parent_verts[5];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[2]);

  if( newRgns )
  {
    for (int iReg = 0; iReg < 3; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if ( newEdges )
  {
    plist = get_split_faces_2(parent_faces[4]);
    pEdgeNewEdge[4] = (pEdge)PList_item(plist, 0);
    pEdgeNewEdge[5] = (pEdge)PList_item(plist, 1);

    for (int iEdge = 0; iEdge < 6; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);
  delete_face(parent_faces[4],0);

  // delete edge if it can be
  delete_edge(parent_edges[1],0);
  delete_edge(parent_edges[7],0);
  delete_edge(parent_edges[2],0);
  delete_edge(parent_edges[8],0);

#ifdef DEBUG
iNumPyrTemplate[20+iCase]++;
#endif
}


void meshTemplate::template_reg_prism_3(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[9];
  pFace parent_faces[5];
  pVertex parent_verts[6];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  templatesUtil::mapping_template_prism(region,ordered_edges,0,parent_faces,parent_edges,parent_verts);

  pVertex pVertexNewVtx[6];
  pEdge pEdgeNewEdge[9];
  pRegion pRegionNewRgn[4];

  pPList plist;
  pVertex pVertexMidVtx[6];
  for (int iSurf = 0; iSurf < 2; ++iSurf)
  {
    for (int iVtx = 0; iVtx < 3; ++iVtx)
    {
      plist = get_split_edges(parent_edges[iVtx + iSurf*6]);
      pVertexMidVtx[iVtx + iSurf*3] = (pVertex)PList_item(plist, 0);
    }
  }

  pVertexNewVtx[0] = parent_verts[0];
  pVertexNewVtx[1] = pVertexMidVtx[0];
  pVertexNewVtx[2] = pVertexMidVtx[2];
  pVertexNewVtx[3] = parent_verts[3];
  pVertexNewVtx[4] = pVertexMidVtx[3];
  pVertexNewVtx[5] = pVertexMidVtx[5];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[0]);

  pVertexNewVtx[0] = pVertexMidVtx[1];
  pVertexNewVtx[3] = pVertexMidVtx[4];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[1]);

  pVertexNewVtx[2] = parent_verts[1];
  pVertexNewVtx[5] = parent_verts[4];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[2]);

  pVertexNewVtx[1] = parent_verts[2];
  pVertexNewVtx[4] = parent_verts[5];
  pVertexNewVtx[2] = pVertexMidVtx[2];
  pVertexNewVtx[5] = pVertexMidVtx[5];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[3]);

  for (int iFace = 0; iFace < 3; ++iFace)
  {
    plist = get_bisected_faces(parent_faces[iFace+1]);
    pEdgeNewEdge[iFace] = (pEdge)PList_item(plist, 0);
    if(!E_typeInBL((pEntity)pEdgeNewEdge[iFace]))
      EN_attachDataInt((pEntity)pEdgeNewEdge[iFace], blEdgeTypeID, eGROWTH);
  }

  if( newRgns )
  {
    for (int iReg = 0; iReg < 4; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if ( newEdges )
  {
    plist = get_split_faces_3(parent_faces[0]);
    pEdgeNewEdge[3] = (pEdge)PList_item(plist, 0);
    pEdgeNewEdge[4] = (pEdge)PList_item(plist, 1);
    pEdgeNewEdge[5] = (pEdge)PList_item(plist, 2);
    plist = get_split_faces_3(parent_faces[4]);
    pEdgeNewEdge[6] = (pEdge)PList_item(plist, 0);
    pEdgeNewEdge[7] = (pEdge)PList_item(plist, 1);
    pEdgeNewEdge[8] = (pEdge)PList_item(plist, 2);

    for (int iEdge = 0; iEdge < 9; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  for (int iFace = 0; iFace < 5; ++iFace)
    delete_face(parent_faces[iFace],0);

  // delete edge if it can be
  delete_edge(parent_edges[0],0);
  delete_edge(parent_edges[6],0);
  delete_edge(parent_edges[1],0);
  delete_edge(parent_edges[7],0);
  delete_edge(parent_edges[2],0);
  delete_edge(parent_edges[8],0);

}


void meshTemplate::template_reg_pyramid_quad_0(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int iTag;
  if (EN_getDataInt((pEntity)PList_item(ordered_edges, 0), int_reff, &iTag))
    iTag = 1;
  else
    iTag = 0;

  // mapping
  templatesUtil::mapping_template_pyr(region,ordered_edges,iTag,parent_faces,parent_edges,parent_verts);

  pPList plist = get_bisected_faces(parent_faces[0]);
  
  pEdge pEdgeNewEdge[3];
  pRegion pRegionNewRgn[2];
  pVertex pVertexNewVtx[5];  

  pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);

  /// Creating pyramids
  pVertexNewVtx[4] = parent_verts[4];

  /// First, find the orientation of each face to correctly construct the pyramid
  int iVDir[2] = {1, 0};
  int iChange = 0;
  int iOppDir[4] = {0, 3, 2, 1};
  pFace pFaceFaces[2];
  pFaceFaces[0] = (pFace)PList_item(plist, 1);
  if (F_inClosure(pFaceFaces[0], parent_edges[0]))
    pFaceFaces[1] = (pFace)PList_item(plist, 2);
  else
  {
    pFaceFaces[1] = pFaceFaces[0];
    pFaceFaces[0] = (pFace)PList_item(plist, 2);

    iChange = 1;
  }
  
  if (iChange != R_faceDir(region, 0))
  {
    iVDir[0] = 0;
    iVDir[1] = 1;
  }

  for (int iFace = 0; iFace < 2; ++iFace)
  {
    if(iVDir[iFace])
    {
      for (int iVtx = 0; iVtx < 4; ++iVtx)
        pVertexNewVtx[iVtx] = F_vertex(pFaceFaces[iFace], iVtx);
    }
    else
    {
      for (int iVtx = 0; iVtx < 4; ++iVtx)
        pVertexNewVtx[iVtx] = F_vertex(pFaceFaces[iFace], iOppDir[iVtx]);
    }
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[iFace]);    
  }

  if (newRgns)
  {
    PList_append(newRgns, pRegionNewRgn[0]);
    PList_append(newRgns, pRegionNewRgn[1]);
  }

  if (newEdges)
  {
    plist = get_split_faces_1(parent_faces[2]);
    pEdgeNewEdge[1] = (pEdge)PList_item(plist, 0);

    plist = get_split_faces_1(parent_faces[4]);
    pEdgeNewEdge[2] = (pEdge)PList_item(plist, 0);

    for (int iEdge = 0; iEdge < 3; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[0], 0);
  delete_face(parent_faces[2], 0);
  delete_face(parent_faces[4], 0);

  // delete edge if it can be
  delete_edge(parent_edges[1], 0);
  delete_edge(parent_edges[3], 0);
}


void meshTemplate::template_reg_pyramid_1(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  int iTag;
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pEdge pEdgeEdge;
  for (int iEdge = 4; iEdge < 8; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if (EN_getDataInt((pEntity)pEdgeEdge, int_reff, &iTag))
    {
      iTag = iEdge - 4;
      break;
    }
  }

  templatesUtil::mapping_template_pyr(region,ordered_edges,iTag,parent_faces,parent_edges,parent_verts);

  /// Child edges of splitted faces and interior ones
  pEdge pEdgeNewEdge[3];

  /// Set the vertices for new regions and create them
  pRegion pRegionNewRgn[3];
  pVertex pVertexNewVtx[5];

  /// Vertex ordering depends of the direction of the face in the parent region
  int iChange = 0;
  int iOppDir[4] = {0, 3, 2, 1};
  if (R_faceDir(region, 0) == 0)
  {
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(parent_faces[0], iVtx);
  }
  else
  {
    iChange = 1;
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(parent_faces[0], iOppDir[iVtx]);
  }

  /// Get the vertex from the edge split
  pPList plist = get_split_edges(parent_edges[4]);
  pVertexNewVtx[4] = (pVertex)PList_item(plist, 0);

  /// Create pyramid
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[0]);  
 
  /// Creating Tet 1
  pVertexNewVtx[0] = parent_verts[1];
  pVertexNewVtx[1] = parent_verts[4];
  pVertexNewVtx[2] = parent_verts[2];
  pVertexNewVtx[3] = pVertexNewVtx[4];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[1]);

  /// Creating Tet 2
  pVertexNewVtx[0] = pVertexNewVtx[4];
  pVertexNewVtx[1] = parent_verts[4];
  pVertexNewVtx[2] = parent_verts[2];
  pVertexNewVtx[3] = parent_verts[3];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);

  if( newRgns ) 
  {
    PList_append(newRgns, pRegionNewRgn[0]);
    PList_append(newRgns, pRegionNewRgn[1]);
    PList_append(newRgns, pRegionNewRgn[2]);
  }

  if( newEdges ) 
  {
    plist = get_split_faces_1(parent_faces[1]);
    pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
    PList_append(newEdges, pEdgeNewEdge[0]);

    plist = get_split_faces_1(parent_faces[4]);
    pEdgeNewEdge[1] = (pEdge)PList_item(plist, 0);
    PList_append(newEdges, pEdgeNewEdge[0]);

    pEdgeNewEdge[2] = E_exist(parent_verts[2], pVertexNewVtx[4]);
    PList_append(newEdges, pEdgeNewEdge[2]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[4],0);

  // delete edge if it can be
  delete_edge(parent_edges[4],0);

}


void meshTemplate::template_reg_pyramid_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  int iTag;
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];

  pEdge pEdgeEdge;
  int iInd[2], iTagEdge = 0;
  for (int iEdge = 4; iEdge < 8; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if (EN_getDataInt((pEntity)pEdgeEdge, int_reff, &iTag))
    {
      iInd[iTagEdge] = iEdge - 4;
      iTagEdge++;
    }
  }

  int iDiff = iInd[1] - iInd[0];
  int iChooseInd = 0;
  if (iDiff == 3)
    iChooseInd = 1;

  templatesUtil::mapping_template_pyr(region,ordered_edges,iInd[iChooseInd],parent_faces,parent_edges,parent_verts);

  /// One might want to implement additional check for the case of opposite edges such that the order of those is decided by the length 
  /// of the interior edge in the transformed space connecting middle vertex of parent_edges[0] and parent_verts[2]
  if (abs(iDiff) != 2)
    template_reg_pyramid_2_a(region, parent_faces, parent_edges, parent_verts, newRgns, newEdges);
  else
    template_reg_pyramid_2_b(region, parent_faces, parent_edges, parent_verts, newRgns, newEdges);
}


void meshTemplate::template_reg_pyramid_2_a(pRegion region, pFace parent_faces[5], pEdge parent_edges[8], pVertex parent_verts[5], pPList newRgns, pPList newEdges)
{

#ifdef DEBUG
iNumPyrTemplate[21]++;
#endif

  pVertex pVertexNewVtx[5];
  pEdge pEdgeNewEdge[5];
  pRegion pRegionNewRgn[4];

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pPList plist = get_split_faces_2(parent_faces[1]);
  pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
  pEdgeNewEdge[1] = (pEdge)PList_item(plist, 1);

  /// Define where the top-prism vertex is going to be depending on what diagonal edge connects
  pVertexNewVtx[4] = E_vertex(pEdgeNewEdge[0], 0);
  if (E_inClosure(parent_edges[0], pVertexNewVtx[4]))
    pVertexNewVtx[4] = E_vertex(pEdgeNewEdge[0], 1);

  /// Vertex ordering depends of the direction of the face in the parent region
  int iOppDir[4] = {0, 3, 2, 1};
  if (R_faceDir(region, 0) == 0)
  {
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(parent_faces[0], iVtx);
  }
  else
  {
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(parent_faces[0], iOppDir[iVtx]);
  }

  /// Create a pyramid
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[0]);  

  /// Get verts for the tet above or below the pyramid
  pVertexNewVtx[0] = E_otherVertex(pEdgeNewEdge[0], pVertexNewVtx[4]);
  if (pVertexNewVtx[0] == parent_verts[0])
    pVertexNewVtx[2] = parent_verts[3];
  else
    pVertexNewVtx[2] = parent_verts[2];
  pVertexNewVtx[1] = pVertexNewVtx[4];
  pVertexNewVtx[3] = E_otherVertex(pEdgeNewEdge[1], pVertexNewVtx[1]);
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[1]);

  pEdgeNewEdge[2] = E_exist(pVertexNewVtx[1], pVertexNewVtx[2]);

  /// Create two other tets
  pVertexNewVtx[0] = parent_verts[4];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);   

  pVertexNewVtx[3] = E_otherVertex(parent_edges[2], pVertexNewVtx[2]);
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);  

  if( newRgns )
  {
    for (int iReg = 0; iReg < 4; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if( newEdges )
  {
    plist = get_split_faces_1(parent_faces[2]);
    pEdgeNewEdge[3] = (pEdge)PList_item(plist, 0);

    plist = get_split_faces_1(parent_faces[4]);
    pEdgeNewEdge[4] = (pEdge)PList_item(plist, 0);

    for (int iEdge = 0; iEdge < 5; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[4],0);

  // delete edge if it can be
  delete_edge(parent_edges[4],0);
  delete_edge(parent_edges[5],0);
}


void meshTemplate::template_reg_pyramid_2_b(pRegion region, pFace parent_faces[5], pEdge parent_edges[8], pVertex parent_verts[5], pPList newRgns, pPList newEdges)
{
#ifdef DEBUG
iNumPyrTemplate[22]++;
#endif

  pVertex pVertexNewVtx[5];
  pEdge pEdgeNewEdge[6];
  pRegion pRegionNewRgn[5];

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pPList plist = get_split_edges(parent_edges[4]);
  pVertexNewVtx[4] = (pVertex)PList_item(plist, 0);

  /// Vertex ordering depends of the direction of the face in the parent region
  int iOppDir[4] = {0, 3, 2, 1};
  if (R_faceDir(region, 0) == 0)
  {
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(parent_faces[0], iVtx);
  }
  else
  {
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(parent_faces[0], iOppDir[iVtx]);
  }

  /// Create a pyramid
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[0]);

  pVertexNewVtx[0] = pVertexNewVtx[4];
  plist = get_split_edges(parent_edges[6]);
  pVertexNewVtx[1] = (pVertex)PList_item(plist, 0);

  /// Create other tets
  pVertexNewVtx[2] = parent_verts[2];
  pVertexNewVtx[3] = parent_verts[3];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[1]);  

  pVertexNewVtx[3] = parent_verts[1];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);  

  pVertexNewVtx[2] = parent_verts[4];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);

  pVertexNewVtx[3] = parent_verts[3];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);

  if( newRgns )
  {
    for (int iReg = 0; iReg < 5; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if( newEdges )
  {
    plist = get_split_faces_1(parent_faces[1]);
    pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
 
    plist = get_split_faces_1(parent_faces[2]);
    pEdgeNewEdge[1] = (pEdge)PList_item(plist, 0);

    plist = get_split_faces_1(parent_faces[3]);
    pEdgeNewEdge[2] = (pEdge)PList_item(plist, 0);

    plist = get_split_faces_1(parent_faces[4]);
    pEdgeNewEdge[3] = (pEdge)PList_item(plist, 0);

    pEdgeNewEdge[4] = E_exist(pVertexNewVtx[0], pVertexNewVtx[1]);
    pEdgeNewEdge[5] = E_exist(pVertexNewVtx[0], parent_verts[2]);

    for (int iEdge = 0; iEdge < 5; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);
  delete_face(parent_faces[4],0);

  // delete edge if it can be
  delete_edge(parent_edges[4],0);
  delete_edge(parent_edges[6],0);
}


void meshTemplate::template_reg_pyramid_3(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  printf("The template template_reg_pyramid_3 (3) is not implemented yet, the program will now exit \n");
  pFace pFaceFaces[5];
  pEdge pEdgeEdges[8];
  pVertex pVertexVtxs[5];

  for (int iFace = 0; iFace < 5; ++iFace)
    pFaceFaces[iFace] = R_face(region, iFace);

  for (int iEdge = 0; iEdge < 8; ++iEdge)
    pEdgeEdges[iEdge] = (pEdge)(PList_item(ordered_edges, iEdge));

  pPList rverts = R_vertices(region, 0);
  for (int iVtx = 0; iVtx < 5; ++iVtx )
    pVertexVtxs[iVtx] = (pVertex)(PList_item(rverts, iVtx));
  PList_delete(rverts);
  
  throw;
//  exit(0);
}


void meshTemplate::template_reg_pyramid_4(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  templatesUtil::mapping_template_pyr(region,ordered_edges,0,parent_faces,parent_edges,parent_verts);

  int iVtxMap[4][7] = {{0, 1, 3, 2, 0, 3, 2}, {1, 0, 2, 3, 1, 2, 3}, {3, 2, 0, 1, 3, 0, 1}, {2, 3, 1, 0, 2, 1, 0}};

  pVertex pVertexNewVtx[5];
  pEdge pEdgeNewEdge[11];
  pRegion pRegionNewRgn[7];

  int iEdge = 0;
  for (int iFace = 1; iFace < 5; ++iFace)
  {
    pPList plist = get_split_faces_2(parent_faces[iFace]);
    pEdgeNewEdge[iEdge] = (pEdge)PList_item(plist, 0);
    pEdgeNewEdge[iEdge+1] = (pEdge)PList_item(plist, 1);
    iEdge += 2;
  }

  int iCase;
  if ((E_vertex(pEdgeNewEdge[0], 0) == parent_verts[0]) || (E_vertex(pEdgeNewEdge[0], 1) == parent_verts[0]))
    iCase = 0;
  else
    iCase = 1;

  if ((E_vertex(pEdgeNewEdge[2], 0) == parent_verts[1]) || (E_vertex(pEdgeNewEdge[2], 1) == parent_verts[1]))
    iCase += 2;


#ifdef DEBUG
iNumPyrTemplate[40+iCase]++;
#endif

  pPList plist;
  pVertex pVertexMidVtx[4];
  for (int iVtx = 0; iVtx < 4; ++iVtx)
  {
    plist = get_split_edges(parent_edges[iVtx+4]);
    pVertexMidVtx[iVtx] = (pVertex)PList_item(plist, 0);
  }

  /// Vertex ordering depends of the direction of the face in the parent region
  int iOppDir[4] = {0, 3, 2, 1};
  if (R_faceDir(region, 0) == 0)
  {
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(parent_faces[0], iVtx);
  }
  else
  {
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(parent_faces[0], iOppDir[iVtx]);
  }
 
  /// Getting the pyramid
  pVertexNewVtx[4] = pVertexMidVtx[iVtxMap[iCase][1]];

  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[0]);

  pVertexNewVtx[0] = parent_verts[iVtxMap[iCase][0]];;
  pVertexNewVtx[1] = pVertexNewVtx[4];
  pVertexNewVtx[2] = parent_verts[iVtxMap[iCase][2]];
  pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][4]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[1]);

  pVertexNewVtx[0] = pVertexMidVtx[iVtxMap[iCase][5]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);

  pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][3]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);

  pVertexNewVtx[0] = parent_verts[iVtxMap[iCase][6]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);

  pVertexNewVtx[0] = parent_verts[4];
  pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][5]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[5]);  

  pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][4]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[6]);

/*
#ifdef DEBUG
pMeshDataId dataId = MD_lookupMeshDataId("check pyramids");
pMeshDataId ptrdataId = MD_lookupMeshDataId("check pyramids region");
for (int iRgn = 0; iRgn < 7; ++iRgn)
{
  pRegion pRegionRgn = pRegionNewRgn[iRgn];
  EN_attachDataInt(pRegionRgn, dataId, 40+iCase);
  EN_attachDataPtr(pRegionRgn, ptrdataId, region);
}
#endif
*/

  if( newRgns )
  {
    for (int iReg = 0; iReg < 7; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if ( newEdges )
  {
    pEdgeNewEdge[8] = E_exist(pVertexMidVtx[iVtxMap[iCase][1]], parent_verts[iVtxMap[iCase][2]]);
    pEdgeNewEdge[9] = E_exist(parent_verts[iVtxMap[iCase][2]], pVertexMidVtx[iVtxMap[iCase][3]]);
    pEdgeNewEdge[10] = E_exist(pVertexMidVtx[iVtxMap[iCase][1]], pVertexMidVtx[iVtxMap[iCase][5]]);

    for (int iEdge = 0; iEdge < 10; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  for (int iFace = 1; iFace < 5; ++iFace)
    delete_face(parent_faces[iFace], 0);

  // delete edge if it can be
  for (iEdge = 4; iEdge < 8; ++iEdge)
    delete_edge(parent_edges[iEdge], 0);

}


void meshTemplate::template_reg_pyramid_quad_1(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  int iTag;
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pEdge pEdgeEdge;
  for (int iEdge = 4; iEdge < 8; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if (EN_getDataInt((pEntity)pEdgeEdge, int_reff, &iTag))
    {
      iTag = iEdge - 4;
      break;
    }
  }

  templatesUtil::mapping_template_pyr(region,ordered_edges,iTag,parent_faces,parent_edges,parent_verts);

  /// Max number of edges of splitted faces and interior ones
  pEdge pEdgeNewEdge[7];

  /// Set the vertices for new regions and create them
  pRegion pRegionNewRgn[5];
  pVertex pVertexNewVtx[5];

  /// Defining the edge of the quad face which is on the top face having 3 child faces, the top face with 3 child faces and the side face with 2 childs
  int iCase;
  pEdge pEdgeTopEdge, pEdgeBotEdge;
  pFace pFaceTopFace, pFaceSideFace, pFaceBotFace;
  if (EN_getDataInt((pEntity)parent_edges[0], int_reff, &iTag))
  {
    iCase = 0;
    pEdgeTopEdge = parent_edges[0];
    pEdgeBotEdge = parent_edges[2];
    pFaceTopFace = parent_faces[1];
    pFaceSideFace = parent_faces[4];
    pFaceBotFace = parent_faces[3];
  }
  else
  {
    iCase = 2;
    pEdgeTopEdge = parent_edges[3];
    pEdgeBotEdge = parent_edges[1];
    pFaceTopFace = parent_faces[4];
    pFaceSideFace = parent_faces[1];
    pFaceBotFace = parent_faces[2];
  }

  /// Get the vertex from the edge split which is in closure of tri face
  pPList plist = get_split_edges(parent_edges[4]);
  pVertex pVertexMidVtx = (pVertex)PList_item(plist, 0);

  plist = get_split_faces_2(pFaceTopFace);
  pEdge pEdgeTopDiagEdge = (pFace)PList_item(plist, 0);
  pEdge pEdgeTopMidEdge = (pFace)PList_item(plist, 1);
  pVertex pVertexTopMid = E_vertex(pEdgeTopMidEdge, 0);
  if (pVertexTopMid == pVertexMidVtx)
    pVertexTopMid = E_vertex(pEdgeTopMidEdge, 1);

  pVertex pVertexTopDiag = E_vertex(pEdgeTopDiagEdge, 0);
  if (pVertexTopDiag == pVertexMidVtx || pVertexTopDiag == pVertexTopMid)
    pVertexTopDiag = E_vertex(pEdgeTopDiagEdge, 1);

//  int iCase = 1;
  if (pVertexTopDiag == parent_verts[4])
    iCase++;

#ifdef DEBUG
iNumPyrTemplate[110+iCase]++;
#endif

  plist = get_bisected_faces(parent_faces[0]);
  pEdge pEdgeCentrEdge = (pFace)PList_item(plist, 0);

  if(!E_typeInBL((pEntity)pEdgeCentrEdge))
    EN_attachDataInt((pEntity)pEdgeCentrEdge,blEdgeTypeID,eGROWTH);

  pVertex pVertexBotMid = E_otherVertex(pEdgeCentrEdge, pVertexTopMid);

  int iVDir[2] = {1, 0};
  int iChange = 0;
  int iOppDir[4] = {0, 3, 2, 1};
  pFace pFaceFace[2];
  pFaceFace[0] = (pFace)PList_item(plist, 1);
  pEdge pEdgeChk = parent_edges[2];
  if (iCase < 2)
    pEdgeChk = parent_edges[3];
  /// Get the correct vertex ordering
  if (F_inClosure(pFaceFace[0], pEdgeChk))
  {
    pFaceFace[1] = pFaceFace[0];
    pFaceFace[0] = (pFace)PList_item(plist, 2);

    iChange = 1;
  }
  else
    pFaceFace[1] = (pFace)PList_item(plist, 2);

  if (iChange != R_faceDir(region, 0))
  {
    iVDir[0] = 0;
    iVDir[1] = 1;
  }


  for (int iFace = 0; iFace < 2; ++iFace)
  {
    if (iVDir[iFace])
    {
      for (int iVtx = 0; iVtx < 4; ++iVtx)
      {
        pVertexNewVtx[iVtx] = F_vertex(pFaceFace[iFace], iVtx);
      }
    }
    else
    {
      for (int iVtx = 0; iVtx < 4; ++iVtx)
        pVertexNewVtx[iVtx] = F_vertex(pFaceFace[iFace], iOppDir[iVtx]);
    }
    if ((iFace == 0 && iCase == 1) || (iFace == 1 && iCase == 3))
      pVertexNewVtx[4] = parent_verts[4];
    else
      pVertexNewVtx[4] = pVertexMidVtx;
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[iFace]);
  }

  pVertex pVertexSideVtx, pVertexInt;
  if (iCase > 1)
  {
    pVertexSideVtx = parent_verts[1];
    pVertexNewVtx[0] = pVertexSideVtx;
    pVertexNewVtx[1] = parent_verts[4];
    pVertexNewVtx[2] = pVertexBotMid;
    pVertexNewVtx[3] = pVertexMidVtx;
    FMDB_Rgn_Create(pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);

    if (iCase == 2)
    {
      pVertexInt = parent_verts[2];

      pVertexNewVtx[0] = pVertexMidVtx;
      pVertexNewVtx[1] = parent_verts[4];
      pVertexNewVtx[2] = pVertexInt;
      pVertexNewVtx[3] = parent_verts[3];
      FMDB_Rgn_Create(pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);

      pVertexNewVtx[3] = pVertexBotMid;
      FMDB_Rgn_Create(pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);
    }
    else
    {
      pVertexNewVtx[0] = pVertexMidVtx;
      pVertexNewVtx[1] = pVertexBotMid;
      pVertexNewVtx[2] = pVertexTopMid;
      pVertexNewVtx[3] = parent_verts[4];
      FMDB_Rgn_Create(pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);     
    }
  }
  else
  {
    pVertexSideVtx = parent_verts[3];

    pVertexNewVtx[0] = pVertexSideVtx;
    pVertexNewVtx[1] = pVertexBotMid;
    pVertexNewVtx[2] = parent_verts[4];
    pVertexNewVtx[3] = pVertexMidVtx;

    FMDB_Rgn_Create(pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);

    if (iCase == 0)
    {
      pVertexInt = parent_verts[2];

      pVertexNewVtx[0] = pVertexMidVtx;
      pVertexNewVtx[1] = pVertexInt;
      pVertexNewVtx[2] = parent_verts[4];
      pVertexNewVtx[3] = parent_verts[1];
      FMDB_Rgn_Create(pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);

      pVertexNewVtx[3] = pVertexBotMid;
      FMDB_Rgn_Create(pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);
    }
    else
    {
      pVertexNewVtx[0] = pVertexMidVtx;
      pVertexNewVtx[1] = pVertexBotMid;
      pVertexNewVtx[2] = parent_verts[4];
      pVertexNewVtx[3] = pVertexTopMid;
      FMDB_Rgn_Create(pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);
    }
  }

  if( newRgns )
  {
    for (int iReg = 0; iReg < 4; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
    if (iCase == 0 || iCase == 2)
      PList_append(newRgns, pRegionNewRgn[4]);
  }

  if( newEdges )
  {
    pEdgeNewEdge[0] = pEdgeTopDiagEdge;
    pEdgeNewEdge[1] = pEdgeTopMidEdge;
    pEdgeNewEdge[2] = pEdgeCentrEdge;

    plist = get_split_faces_1(pFaceSideFace);
    pEdgeNewEdge[3] = (pEdge)PList_item(plist, 0);

    plist = get_split_faces_1(pFaceBotFace);
    pEdgeNewEdge[4] = (pEdge)PList_item(plist, 0);

    pEdgeNewEdge[5] = E_exist(pVertexBotMid, pVertexMidVtx);

    int iNumNewEdge = 6;
    if (iCase == 0 || iCase == 2)
    {
      iNumNewEdge++;
      pEdgeNewEdge[6] = E_exist(pVertexInt, pVertexMidVtx);
    }    

    for (int iEdge = 0; iEdge < iNumNewEdge; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[0],0);
  delete_face(pFaceTopFace,0);
  delete_face(pFaceBotFace,0);
  delete_face(pFaceSideFace,0);

  // delete edge if it can be
  delete_edge(parent_edges[4],0);
  delete_edge(pEdgeTopEdge, 0);
  delete_edge(pEdgeBotEdge, 0);
}


void meshTemplate::template_reg_pyramid_quad_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  int iTag;
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];

  pEdge pEdgeEdge;
  int iInd[2], iTagEdge = 0;
  for (int iEdge = 4; iEdge < 8; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if (EN_getDataInt((pEntity)pEdgeEdge, int_reff, &iTag))
    {
      iInd[iTagEdge] = iEdge - 4;
      iTagEdge++;
    }
  }

  int iDiff = iInd[1] - iInd[0];
  int iChooseInd = 0;
  if (iDiff == 3)
    iChooseInd = 1;

  templatesUtil::mapping_template_pyr(region,ordered_edges,iInd[iChooseInd],parent_faces,parent_edges,parent_verts);

  /// One might want to implement additional check for the case of opposite edges such that the order of those is decided by the length
  /// of the interior edge in the transformed space connecting middle vertex of parent_edges[0] and parent_verts[2]
  if (abs(iDiff) != 2)
    template_reg_pyramid_quad_2_a(region, parent_faces, parent_edges, parent_verts, newRgns, newEdges);
  else
  {
    template_reg_pyramid_quad_2_b(region, parent_faces, parent_edges, parent_verts, newRgns, newEdges);
  }
}


void meshTemplate::template_reg_pyramid_quad_2_a(pRegion region, pFace parent_faces[5], pEdge parent_edges[8], pVertex parent_verts[5], pPList newRgns, pPList newEdges)
{
  pVertex pVertexNewVtx[5];
  pEdge pEdgeNewEdge[9];
  pRegion pRegionNewRgn[6];
  pFace pFaceFaceMid[2];
  pVertex pVertexMid[2];

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int iTag, iCase;
  if (EN_getDataInt((pEntity)parent_edges[0], int_reff, &iTag))
    iCase = 0;
  else
    iCase = 1;

  pPList plist;
  if (iCase)
  {  
    plist = get_split_faces_2(parent_faces[2]);
    pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
    pEdgeNewEdge[1] = (pEdge)PList_item(plist, 1);
    if ((E_vertex(pEdgeNewEdge[0], 0) == parent_verts[4]) || (E_vertex(pEdgeNewEdge[0], 1) == parent_verts[4]))
      iCase = 2;
  }

#ifdef DEBUG
iNumPyrTemplate[120+iCase]++;
#endif

  int iVDir[2] = {0,1};
  int iChange = 0;
  int iOppDir[4] = {0, 3, 2, 1};
  switch (iCase)
  {
    case 0:
      pVertex pVertexSideVtx[2];
      plist = get_split_edges (parent_edges[4]);
      pVertexSideVtx[0] = (pVertex)PList_item(plist, 0);
      plist = get_split_edges (parent_edges[5]);
      pVertexSideVtx[1] = (pVertex)PList_item(plist, 0); 

      plist = get_bisected_faces(parent_faces[0]);
      pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
      if(!E_typeInBL((pEntity)pEdgeNewEdge[0]))
        EN_attachDataInt((pEntity)pEdgeNewEdge[0],blEdgeTypeID,eGROWTH);

      pFace pFaceSideFace[2];
      pFaceSideFace[0] = (pFace)PList_item(plist, 1);
      if (F_inClosure(pFaceSideFace[0], parent_edges[1]))
      {
        pFaceSideFace[1] = pFaceSideFace[0];
        pFaceSideFace[0] = (pFace)PList_item(plist, 2);

        iChange = 1;
      }
      else
        pFaceSideFace[1] = (pFace)PList_item(plist, 2);

      if (iChange == R_faceDir(region, 0))
      {
        iVDir[0] = 1;
        iVDir[1] = 0;
      }

      for (int iFace = 0; iFace < 2; ++iFace)
      {
        if (iVDir[iFace])
        {
          for (int iVtx = 0; iVtx < 4; ++iVtx)
          {
            pVertexNewVtx[iVtx] = F_vertex(pFaceSideFace[iFace], iVtx);
          }
        }
        else
        {
          for (int iVtx = 0; iVtx < 4; ++iVtx)
          {
            pVertexNewVtx[iVtx] = F_vertex(pFaceSideFace[iFace], iOppDir[iVtx]);
          }
        }
        pVertexNewVtx[4] = pVertexSideVtx[iFace];
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[iFace]);
      }

      plist = get_split_edges (parent_edges[0]);
      pVertexMid[0] = (pVertex)PList_item(plist, 0);
      plist = get_split_edges (parent_edges[2]);
      pVertexMid[1] = (pVertex)PList_item(plist, 0);

      pVertexNewVtx[0] = pVertexMid[1];
      pVertexNewVtx[1] = pVertexSideVtx[1];
      pVertexNewVtx[2] = pVertexSideVtx[0];
      pVertexNewVtx[3] = pVertexMid[0];
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);

      pVertexNewVtx[3] = parent_verts[4];
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);

      pVertexNewVtx[2] = parent_verts[2];
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);

      pVertexNewVtx[1] = parent_verts[3];
      pVertexNewVtx[2] = pVertexSideVtx[0];
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[5]);

      if( newRgns )
      {
        for (int iReg = 0; iReg < 6; ++iReg)
          PList_append(newRgns, pRegionNewRgn[iReg]);
      }

      if( newEdges )
      {
        plist = get_split_faces_1(parent_faces[2]);
        pEdgeNewEdge[1] = (pEdge)PList_item(plist, 0);
        plist = get_split_faces_1(parent_faces[3]);
        pEdgeNewEdge[2] = (pEdge)PList_item(plist, 0);
        plist = get_split_faces_1(parent_faces[4]);
        pEdgeNewEdge[3] = (pEdge)PList_item(plist, 0);
        plist = get_split_faces_3(parent_faces[1]);
        pEdgeNewEdge[4] = (pEdge)PList_item(plist, 0);
        pEdgeNewEdge[5] = (pEdge)PList_item(plist, 1);
        pEdgeNewEdge[6] = (pEdge)PList_item(plist, 2);
        pEdgeNewEdge[7] = E_exist(pVertexMid[1], pVertexSideVtx[0]);
        pEdgeNewEdge[8] = E_exist(pVertexMid[1], pVertexSideVtx[1]);

        for (int iEdge = 0; iEdge < 9; ++iEdge)
          PList_append(newEdges, pEdgeNewEdge[iEdge]);
      }
      break;
    
    case 1:
      plist = get_split_faces_2(parent_faces[1]);
      pEdgeNewEdge[2] = (pEdge)PList_item(plist, 0);
      pEdgeNewEdge[3] = (pEdge)PList_item(plist, 1);

#ifdef DEBUG
      plist = get_split_faces_2(parent_faces[4]);
      pEdge pEdgeChkEdge[2];
      pEdgeChkEdge[0] = (pEdge)PList_item(plist, 0);
      pEdgeChkEdge[1] = (pEdge)PList_item(plist, 1);      
      if ((E_vertex(pEdgeChkEdge[0], 0) == parent_verts[4]) || (E_vertex(pEdgeChkEdge[0], 1) == parent_verts[4]))
        printf("Error: 2 edges of opposite faces are in a different direction, case 121! \n");
#endif

      /// Define where the top-prism vertex is going to be depending on what diagonal edge connects
      pVertexNewVtx[4] = E_vertex(pEdgeNewEdge[2], 0);
      if (E_inClosure(parent_edges[0], pVertexNewVtx[4]))
        pVertexNewVtx[4] = E_vertex(pEdgeNewEdge[2], 1);

      plist = get_bisected_faces(parent_faces[0]);
      pEdgeNewEdge[4] = (pFace)PList_item(plist, 0);
      if(!E_typeInBL((pEntity)pEdgeNewEdge[4]))
        EN_attachDataInt((pEntity)pEdgeNewEdge[4],blEdgeTypeID,eGROWTH);
      /// 0 - face having parent_edge[0] in closure, 1 - opposite
      pFaceFaceMid[0] = (pFace)PList_item(plist, 1);
      if (F_inClosure(pFaceFaceMid[0], parent_edges[2]))
      {
        pFaceFaceMid[1] = pFaceFaceMid[0];
        pFaceFaceMid[0] = (pFace)PList_item(plist, 2);

        iChange = 1;
      }
      else
        pFaceFaceMid[1] = (pFace)PList_item(plist, 2);

      if (iChange == R_faceDir(region, 0))
      {
        iVDir[0] = 1;
        iVDir[1] = 0;
      }

      /// Create 2 pyramids
      for (int iFace = 0; iFace < 2; ++iFace)
      {
        if (iVDir[iFace])
        {
          for (int iVtx = 0; iVtx < 4; ++iVtx)
          {
            pVertexNewVtx[iVtx] = F_vertex(pFaceFaceMid[iFace], iVtx);
          }
        }
        else
        {
          for (int iVtx = 0; iVtx < 4; ++iVtx)
          {
            pVertexNewVtx[iVtx] = F_vertex(pFaceFaceMid[iFace], iOppDir[iVtx]);
          }
        }
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[iFace]);
      }

      /// 0 - vertex in the middle of parent_edge[1], 1 - vertex in the middle of parent_edge[3]
      plist = get_split_edges(parent_edges[1]);
      pVertexMid[0] = (pVertex)PList_item(plist, 0);
      plist = get_split_edges(parent_edges[3]);
      pVertexMid[1] = (pVertex)PList_item(plist, 0);

      /// Define based on which vertices the tets are built
      pVertexNewVtx[0] = E_vertex(pEdgeNewEdge[2], 0);
      pVertexNewVtx[1] = pVertexNewVtx[4];
      pVertexNewVtx[2] = E_otherVertex(pEdgeNewEdge[3], pVertexNewVtx[4]);
      if (pVertexNewVtx[0] == pVertexNewVtx[4])
        pVertexNewVtx[0] = E_vertex(pEdgeNewEdge[2], 1);

      if (pVertexNewVtx[0] == parent_verts[0])
      {
        pVertexNewVtx[3] = pVertexMid[1];
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);
        pVertexNewVtx[0] = parent_verts[3];
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);
      }
      else
      {
        pVertexNewVtx[3] = pVertexMid[0];
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);
        pVertexNewVtx[0] = parent_verts[2];
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);
      }

      pEdgeNewEdge[5] = E_exist(pVertexNewVtx[1], pVertexNewVtx[3]);

      pVertexNewVtx[3] = parent_verts[4];
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);
      pVertexNewVtx[2] = E_otherVertex(parent_edges[2], pVertexNewVtx[0]);
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[5]);

      if( newRgns )
      {
        for (int iReg = 0; iReg < 6; ++iReg)
          PList_append(newRgns, pRegionNewRgn[iReg]);
      }

      if( newEdges )
      {
        pEdgeNewEdge[6] = E_exist(pVertexNewVtx[0], pVertexNewVtx[1]);

        plist = get_split_faces_2(parent_faces[4]);
        pEdgeNewEdge[7] = (pEdge)PList_item(plist, 0);
        pEdgeNewEdge[8] = (pEdge)PList_item(plist, 1);

        for (int iEdge = 0; iEdge < 9; ++iEdge)
          PList_append(newEdges, pEdgeNewEdge[iEdge]);
      }
      
      break;

    case 2:
      plist = get_split_faces_2(parent_faces[1]);
      pEdgeNewEdge[2] = (pEdge)PList_item(plist, 0);
      pEdgeNewEdge[3] = (pEdge)PList_item(plist, 1);

#ifdef DEBUG
      plist = get_split_faces_2(parent_faces[4]);
      pEdge pEdgeChkEdges[2];
      pEdgeChkEdges[0] = (pEdge)PList_item(plist, 0);
      pEdgeChkEdges[1] = (pEdge)PList_item(plist, 1);
      if ((E_vertex(pEdgeChkEdges[0], 0) != parent_verts[4]) && (E_vertex(pEdgeChkEdges[0], 1) != parent_verts[4]))
        printf("Error: 2 edges of opposite faces are in a different direction, case 122! \n");
#endif

      /// Define where the top-prism vertex is going to be depending on what diagonal edge connects
      pVertexNewVtx[4] = E_vertex(pEdgeNewEdge[2], 0);
      if (E_inClosure(parent_edges[0], pVertexNewVtx[4]))
        pVertexNewVtx[4] = E_vertex(pEdgeNewEdge[2], 1);
      pVertex pVertexMidVtx = pVertexNewVtx[4];

      plist = get_bisected_faces(parent_faces[0]);
      pEdgeNewEdge[4] = (pFace)PList_item(plist, 0);
      if(!E_typeInBL((pEntity)pEdgeNewEdge[4]))
        EN_attachDataInt((pEntity)pEdgeNewEdge[4],blEdgeTypeID,eGROWTH);
      /// 0 - face having parent_edge[0] in closure, 1 - opposite
      pFaceFaceMid[0] = (pFace)PList_item(plist, 1);
      if (F_inClosure(pFaceFaceMid[0], parent_edges[2]))
      {
        pFaceFaceMid[1] = pFaceFaceMid[0];
        pFaceFaceMid[0] = (pFace)PList_item(plist, 2);

        iChange = 1;
      }
      else
        pFaceFaceMid[1] = (pFace)PList_item(plist, 2);

      if (iChange == R_faceDir(region, 0))
      {
        iVDir[0] = 1;
        iVDir[1] = 0;
      }

      /// Create 2 pyramids
      for (int iFace = 0; iFace < 2; ++iFace)
      {
        if (iVDir[iFace])
        {
          for (int iVtx = 0; iVtx < 4; ++iVtx)
          {
            pVertexNewVtx[iVtx] = F_vertex(pFaceFaceMid[iFace], iVtx);
          }
        }
        else
        {
          for (int iVtx = 0; iVtx < 4; ++iVtx)
          {
            pVertexNewVtx[iVtx] = F_vertex(pFaceFaceMid[iFace], iOppDir[iVtx]);
          }
        }
        if (iFace == 1)
          pVertexNewVtx[4] = parent_verts[4];
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[iFace]);
      }

      /// 0 - vertex in the middle of parent_edge[1], 1 - vertex in the middle of parent_edge[3]
      plist = get_split_edges(parent_edges[1]);
      pVertexMid[0] = (pVertex)PList_item(plist, 0);
      plist = get_split_edges(parent_edges[3]);
      pVertexMid[1] = (pVertex)PList_item(plist, 0);

      /// Define based on which vertices the tets are built
      pVertexNewVtx[0] = E_vertex(pEdgeNewEdge[2], 0);
      pVertexNewVtx[1] = pVertexMidVtx;
      pVertexNewVtx[2] = E_otherVertex(pEdgeNewEdge[3], pVertexMidVtx);
      if (pVertexNewVtx[0] == pVertexMidVtx)
        pVertexNewVtx[0] = E_vertex(pEdgeNewEdge[2], 1);

      if (pVertexNewVtx[0] == parent_verts[0])
      {
        pVertexNewVtx[3] = pVertexMid[1];
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);
      }
      else
      {
        pVertexNewVtx[3] = pVertexMid[0];
        FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);
      }

      pEdgeNewEdge[5] = E_exist(pVertexNewVtx[1], pVertexNewVtx[3]);

      pVertexNewVtx[0] = parent_verts[4];
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);
      pVertexNewVtx[2] = E_otherVertex(pEdgeNewEdge[4], pVertexNewVtx[3]);
      FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);

      if( newRgns )
      {
        for (int iReg = 0; iReg < 5; ++iReg)
          PList_append(newRgns, pRegionNewRgn[iReg]);
      }

      if( newEdges )
      {
        plist = get_split_faces_2(parent_faces[4]);
        pEdgeNewEdge[6] = (pEdge)PList_item(plist, 0);
        pEdgeNewEdge[7] = (pEdge)PList_item(plist, 1);

        for (int iEdge = 0; iEdge < 8; ++iEdge)
          PList_append(newEdges, pEdgeNewEdge[iEdge]);
      }

      break;
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[4],0);

  if (iCase == 0)
      delete_face(parent_faces[3],0);

  // delete edge if it can be
  if (iCase)
    iCase = 1;
  delete_edge(parent_edges[0+iCase],0);
  delete_edge(parent_edges[2+iCase],0);
  delete_edge(parent_edges[4],0);
  delete_edge(parent_edges[5],0);
}


void meshTemplate::template_reg_pyramid_quad_2_b(pRegion region, pFace parent_faces[5], pEdge parent_edges[8], pVertex parent_verts[5], pPList newRgns, pPList newEdges)
{
  printf("The template template_reg_pyramid_quad_2_b (12) is not implemented yet, the program will now exit \n");
  exit(0);

  pVertex pVertexNewVtx[5];
  pEdge pEdgeNewEdge[9];
  pRegion pRegionNewRgn[6];

  pVertex pVertexMid[2];
  pEdge pEdgeQuadSplit[2];
  pEdge pEdgeQuadNoSplit[2];
  pFace pFace2Split[2]; /// face 
  pFace pFace1Split[2];

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int iTag, iCase;
  if (EN_getDataInt((pEntity)parent_edges[0], int_reff, &iTag))
  {
    pEdgeQuadSplit[0] = parent_edges[0];
    pEdgeQuadSplit[1] = parent_edges[2];
    pEdgeQuadNoSplit[0] = parent_edges[1];
    pEdgeQuadNoSplit[1] = parent_edges[3];
    pFace2Split[0] = parent_faces[1];
    pFace2Split[1] = parent_faces[3];
    pFace1Split[0] = parent_faces[2];
    pFace1Split[1] = parent_faces[4];
    iCase = 0;
  }
  else
  {
    pEdgeQuadSplit[0] = parent_edges[1];
    pEdgeQuadSplit[1] = parent_edges[3];
    pEdgeQuadNoSplit[0] = parent_edges[0];
    pEdgeQuadNoSplit[1] = parent_edges[2];
    pFace1Split[0] = parent_faces[1];
    pFace1Split[1] = parent_faces[3];
    pFace2Split[0] = parent_faces[2];
    pFace2Split[1] = parent_faces[4];
    iCase = 1;
  }
  
  pVertex pVertexSideVtx[2];
  pPList plist = get_split_edges (parent_edges[4]);
  pVertexSideVtx[0] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges (parent_edges[6]);
  pVertexSideVtx[1] = (pVertex)PList_item(plist, 0);

  pVertexNewVtx[4] = pVertexSideVtx[0];

  plist = get_split_faces_2(pFace2Split[0]);
  pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
  pEdgeNewEdge[1] = (pEdge)PList_item(plist, 1); 

  /// Check if the pyramid os gonna be split into two by bisection or by introducing vertices on the edges of existent one
  int iSplitMidPyr = 0;
  if ((E_vertex(pEdgeNewEdge[0], 0) == parent_verts[4]) || (E_vertex(pEdgeNewEdge[0], 1) == parent_verts[4]))
    iSplitMidPyr = 1;

  pFace pFaceQuadFace[2];
  plist = get_bisected_faces(parent_faces[0]);
  pFaceQuadFace[0] = (pFace)PList_item(plist, 1);
  if (F_inClosure(pFaceQuadFace[0], pEdgeQuadNoSplit[1]))
  {
    pFaceQuadFace[1] = pFaceQuadFace[0];
    pFaceQuadFace[0] = (pFace)PList_item(plist, 2);
  }
  else
    pFaceQuadFace[1] = (pFace)PList_item(plist, 2);

  for (int iFace = 0; iFace < 2; ++iFace)
  {
    for (int iVtx = 0; iVtx < 4; ++iVtx)
    {
      pVertexNewVtx[iVtx] = F_vertex(pFaceQuadFace[iFace], iVtx);
    }
    pVertexNewVtx[4] = pVertexSideVtx[iFace];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[iFace]);
  }

  if (iSplitMidPyr)
  {
    plist = get_split_edges(pEdgeQuadSplit[0]);
    /// ... Needs further implementation
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  for (int iFace = 0; iFace < 5; ++iFace)
    delete_face(parent_faces[iFace],0);

  // delete edge if it can be
  delete_edge(pEdgeQuadSplit[0], 0);
  delete_edge(pEdgeQuadSplit[1], 0);
  delete_edge(parent_edges[4],0);
  delete_edge(parent_edges[6],0);

  
}


void meshTemplate::template_reg_pyramid_quad_3(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  printf("The template template_reg_pyramid_quad_3 (13) is not implemented yet, the program will now exit \n");
  exit(0);
}


void meshTemplate::template_reg_pyramid_quad_4(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int iTag;
  if (EN_getDataInt((pEntity)PList_item(ordered_edges, 0), int_reff, &iTag))
    iTag = 1;
  else
    iTag = 0;

  templatesUtil::mapping_template_pyr(region,ordered_edges,iTag,parent_faces,parent_edges,parent_verts);

  int iVtxMap[4][8] = {{0, 1, 5, 2, 3, 0, 3, 4}, {1, 0, 4, 3, 2, 1, 2, 5}, {0, 1, 5, 3, 2, 0, 2, 4}, {1, 0, 4, 2, 3, 1, 3, 5}};

  pVertex pVertexNewVtx[5];
  pEdge pEdgeNewEdge[14];
  pRegion pRegionNewRgn[9];

  int iEdge = 0;
  for (int iFace = 1; iFace < 4; iFace+=2)
  {
    pPList plist = get_split_faces_2(parent_faces[iFace]);
    pEdgeNewEdge[iEdge] = (pEdge)PList_item(plist, 0);
    pEdgeNewEdge[iEdge+1] = (pEdge)PList_item(plist, 1);
    iEdge += 2;
  }

  for (int iFace = 2; iFace < 5; iFace+=2)
  {
    pPList plist = get_split_faces_3(parent_faces[iFace]);
    pEdgeNewEdge[iEdge] = (pEdge)PList_item(plist, 0);
    pEdgeNewEdge[iEdge+1] = (pEdge)PList_item(plist, 1);
    pEdgeNewEdge[iEdge+2] = (pEdge)PList_item(plist, 2);
    iEdge += 3;
  }


  int iCase;
  if ((E_vertex(pEdgeNewEdge[0], 0) == parent_verts[0]) || (E_vertex(pEdgeNewEdge[0], 1) == parent_verts[0]))
    iCase = 0;
  else
    iCase = 1;

  if (iCase == 0 && (E_vertex(pEdgeNewEdge[2], 0) == parent_verts[2]) || (E_vertex(pEdgeNewEdge[2], 1) == parent_verts[2]))
    iCase += 2;
  else if (iCase == 1 && (E_vertex(pEdgeNewEdge[2], 0) == parent_verts[3]) || (E_vertex(pEdgeNewEdge[2], 1) == parent_verts[3]))
    iCase += 2;

#ifdef DEBUG
iNumPyrTemplate[140+iCase]++;
#endif

  pPList plist;
  pVertex pVertexMidVtx[6];
  for (int iVtx = 0; iVtx < 4; ++iVtx)
  {
    plist = get_split_edges(parent_edges[iVtx+4]);
    pVertexMidVtx[iVtx] = (pVertex)PList_item(plist, 0);
  }

  plist = get_split_edges(parent_edges[1]);
  pVertexMidVtx[4] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[3]);
  pVertexMidVtx[5] = (pVertex)PList_item(plist, 0);

  pFace pFaceQuadFace[2];
  plist = get_bisected_faces(parent_faces[0]);
  pEdgeNewEdge[10] = (pEdge)PList_item(plist, 0);
  if(!E_typeInBL((pEntity)pEdgeNewEdge[10]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[10],blEdgeTypeID,eGROWTH);

  int iVDir[2] = {0, 1};
  int iChange = 0;
  int iOppDir[4] = {0, 3, 2, 1};
  pFaceQuadFace[0] = (pFace)PList_item(plist, 1); 
  if (F_inClosure(pFaceQuadFace[0], parent_edges[2]))
  {
    pFaceQuadFace[1] = pFaceQuadFace[0];
    pFaceQuadFace[0] = (pFace)PList_item(plist, 2);

    iChange = 1;
  }
  else
    pFaceQuadFace[1] = (pFace)PList_item(plist, 2);

  if (iChange == R_faceDir(region, 0))
  {
    iVDir[0] = 1;
    iVDir[1] = 0;
  }


  /// Getting the pyramids
  for (int iFace = 0; iFace < 2; ++iFace)
  {
    if (iVDir[iFace])
    {
      for (int iVtx = 0; iVtx < 4; ++iVtx)
        pVertexNewVtx[iVtx] = F_vertex(pFaceQuadFace[iFace], iVtx);
    }
    else
    {
      for (int iVtx = 0; iVtx < 4; ++iVtx)
        pVertexNewVtx[iVtx] = F_vertex(pFaceQuadFace[iFace], iOppDir[iVtx]);
    }
    pVertexNewVtx[4] = pVertexMidVtx[iVtxMap[iCase][iFace*2+1]];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[iFace]);
  }

  pVertexNewVtx[0] = parent_verts[iVtxMap[iCase][0]];
  pVertexNewVtx[1] = pVertexMidVtx[iVtxMap[iCase][1]];
  pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][2]];
  pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][5]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);

  pVertexNewVtx[0] = pVertexMidVtx[iVtxMap[iCase][3]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);

  pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][7]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);

  if (iCase < 2)
  {
    pVertexNewVtx[1] = pVertexMidVtx[iVtxMap[iCase][6]];
    pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][5]];
  }
  else
    pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][6]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[5]);

  if (iCase < 2)
    pVertexNewVtx[3] = parent_verts[iVtxMap[iCase][4]];
  else
    pVertexNewVtx[1] = parent_verts[iVtxMap[iCase][4]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[6]);

  pVertexNewVtx[3] = parent_verts[4];

  if (iCase < 2)
    pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][5]];
  else
    pVertexNewVtx[1] = pVertexMidVtx[iVtxMap[iCase][1]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[7]);

  if (iCase < 2)
    pVertexNewVtx[1] = pVertexMidVtx[iVtxMap[iCase][1]];
  else
    pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][5]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[8]);

  if( newRgns )
  {
    for (int iReg = 0; iReg < 9; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if ( newEdges )
  {
    pEdgeNewEdge[11] = E_exist(pVertexMidVtx[iVtxMap[iCase][1]], pVertexMidVtx[iVtxMap[iCase][2]]);
    if (iCase < 2)
    {
      pEdgeNewEdge[12] = E_exist(pVertexMidVtx[iVtxMap[iCase][2]], pVertexMidVtx[iVtxMap[iCase][3]]);
      pEdgeNewEdge[13] = E_exist(pVertexMidVtx[iVtxMap[iCase][3]], pVertexMidVtx[iVtxMap[iCase][5]]);
    }
    else
    {
      pEdgeNewEdge[12] = E_exist(pVertexMidVtx[iVtxMap[iCase][1]], pVertexMidVtx[iVtxMap[iCase][3]]);
      pEdgeNewEdge[13] = E_exist(pVertexMidVtx[iVtxMap[iCase][3]], pVertexMidVtx[iVtxMap[iCase][7]]);
    } 

    for (int iEdge = 0; iEdge < 14; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  for (int iFace = 0; iFace < 5; ++iFace)
    delete_face(parent_faces[iFace], 0);

  // delete edge if it can be
  for (iEdge = 4; iEdge < 8; ++iEdge)
    delete_edge(parent_edges[iEdge], 0);
  delete_edge(parent_edges[1], 0);
  delete_edge(parent_edges[3], 0);

}


void meshTemplate::template_reg_pyramid_tri_bisect(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  int iTag;
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];

  pEdge pEdgeEdge;
  int iInd[2], iTagEdge = 0;
  for (int iEdge = 4; iEdge < 8; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if (EN_getDataInt((pEntity)pEdgeEdge, int_reff, &iTag))
    {
      iInd[iTagEdge] = iEdge - 4;
      iTagEdge++;
    }
  }

  int iDiff = iInd[1] - iInd[0];
  int iChooseInd = 0;
  if (iDiff == 3)
    iChooseInd = 1;

  templatesUtil::mapping_template_pyr(region,ordered_edges,iInd[iChooseInd],parent_faces,parent_edges,parent_verts);

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pVertex pVertexNewVtx[6];
  pEdge pEdgeNewEdge[3];
  pRegion pRegionNewRgn[2];
  
  pPList plist = get_split_edges(parent_edges[5]);
  pVertexNewVtx[1] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[4]);
  pVertexNewVtx[4] = (pVertex)PList_item(plist, 0);  

  pVertexNewVtx[0] = parent_verts[1];
  pVertexNewVtx[2] = parent_verts[2];
  pVertexNewVtx[3] = parent_verts[0];
  pVertexNewVtx[5] = parent_verts[3];

  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[0]);

  pVertexNewVtx[0] = pVertexNewVtx[4];
  pVertexNewVtx[3] = parent_verts[3];
  pVertexNewVtx[4] = parent_verts[4];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[1]);  

  plist = get_bisected_faces(parent_faces[1]);
  pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
  if(!E_typeInBL((pEntity)pEdgeNewEdge[0]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[0],blEdgeTypeID,eGROWTH);

  if( newRgns )
  {
    for (int iReg = 0; iReg < 2; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if ( newEdges )
  {
    plist = get_split_faces_1(parent_faces[4]);
    pEdgeNewEdge[1] = (pEdge)PList_item(plist, 0);
    plist = get_split_faces_1(parent_faces[2]);
    pEdgeNewEdge[2] = (pEdge)PList_item(plist, 0);

    for (int iEdge = 0; iEdge < 3; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[4],0);

  // delete edge if it can be
  delete_edge(parent_edges[4],0);
  delete_edge(parent_edges[5],0);
}


void meshTemplate::template_reg_pyramid_tri_bisect_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];

  pEdge pEdgeEdge;
  int iInd[2], iTagEdge = 0;
  for (int iEdge = 4; iEdge < 8; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if (!E_typeInBL(pEdgeEdge))
    {
      iInd[iTagEdge] = iEdge - 4;
      iTagEdge++;
    }
  }

  int iDiff = iInd[1] - iInd[0];
  int iChooseInd = 0;
  if (iDiff == 3)
    iChooseInd = 1;

  templatesUtil::mapping_template_pyr(region,ordered_edges,iInd[iChooseInd],parent_faces,parent_edges,parent_verts);

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int iVtxMap[4][7] = {{0, 1, 3, 3, 0, 2, 2}, {1, 0, 2, 2, 1, 3, 3}, {0, 1, 3, 2, 0, 2, 3}, {1, 0, 2, 3, 1, 3, 2}};

  pVertex pVertexNewVtx[6];
  pEdge pEdgeNewEdge[8];
  pRegion pRegionNewRgn[6];

  int iEdge = 0;
  pPList plist;
  for (int iFace = 1; iFace < 5; ++iFace)
  {
    if (iFace == 3)
    {
      plist = get_bisected_faces(parent_faces[iFace]);
      pEdgeNewEdge[iEdge] = (pEdge)PList_item(plist, 0);
      iEdge++;
    }
    else
    {
      plist = get_split_faces_2(parent_faces[iFace]);
      pEdgeNewEdge[iEdge] = (pEdge)PList_item(plist, 0);
      pEdgeNewEdge[iEdge+1] = (pEdge)PList_item(plist, 1);
      iEdge += 2;
    }
  }

  int iCase;
  if ((E_vertex(pEdgeNewEdge[0], 0) == parent_verts[0]) || (E_vertex(pEdgeNewEdge[0], 1) == parent_verts[0]))
    iCase = 0;
  else
    iCase = 1;

  if ((E_vertex(pEdgeNewEdge[2], 0) == parent_verts[1]) || (E_vertex(pEdgeNewEdge[2], 1) == parent_verts[1]))
    iCase += 2;

  pVertex pVertexMidVtx[4];
  for (int iVtx = 0; iVtx < 4; ++iVtx)
  {
    plist = get_split_edges(parent_edges[iVtx+4]);
    pVertexMidVtx[iVtx] = (pVertex)PList_item(plist, 0);
  }

  if (iCase < 2)
  {
    /// Getting the pyramid
    for (int iVtx = 0; iVtx < 4; ++iVtx)
      pVertexNewVtx[iVtx] = F_vertex(parent_faces[0], iVtx);
    pVertexNewVtx[4] = pVertexMidVtx[iVtxMap[iCase][1]];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[0]);

    pVertexNewVtx[0] = parent_verts[iVtxMap[iCase][2]];
    pVertexNewVtx[1] = pVertexMidVtx[iVtxMap[iCase][3]];
    pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][6]];
    pVertexNewVtx[3] = parent_verts[iVtxMap[iCase][5]];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[1]);

    pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][4]];
    pVertexNewVtx[3] = pVertexNewVtx[4];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);

    pVertexNewVtx[1] = parent_verts[iVtxMap[iCase][0]];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);

    pVertexNewVtx[0] = pVertexMidVtx[iVtxMap[iCase][3]];
    pVertexNewVtx[1] = parent_verts[4];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);

    pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][6]];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[5]);
  }
  else
  {
    pVertexNewVtx[0] = parent_verts[iVtxMap[iCase][0]];
    pVertexNewVtx[3] = E_otherVertex(parent_edges[0], pVertexNewVtx[0]);
    pVertexNewVtx[1] = pVertexMidVtx[iVtxMap[iCase][2]];
    pVertexNewVtx[2] = parent_verts[iVtxMap[iCase][6]];
    pVertexNewVtx[4] = pVertexMidVtx[iVtxMap[iCase][3]];
    pVertexNewVtx[5] = parent_verts[iVtxMap[iCase][5]];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[0]);

    pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][3]];
    pVertexNewVtx[4] = pVertexMidVtx[iVtxMap[iCase][1]];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[1]);

    pVertexNewVtx[2] = pVertexNewVtx[4];
    pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][4]];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);

    pVertexNewVtx[0] = parent_verts[4];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[3]);

    pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][3]];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[4]);
  }

  if(!E_typeInBL((pEntity)pEdgeNewEdge[4]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[4],blEdgeTypeID,eGROWTH);
  

  if( newRgns )
  {
    int iNumRgn = 5;
    if (iCase < 2)
      iNumRgn = 6;
    for (int iReg = 0; iReg < iNumRgn; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if ( newEdges )
  {
    int iNumNewEdge = 9;
    if (iCase < 2)
    {
      pEdgeNewEdge[7] = E_exist(pVertexMidVtx[iVtxMap[iCase][1]], parent_verts[iVtxMap[iCase][2]]);
      pEdgeNewEdge[8] = E_exist(pVertexMidVtx[iVtxMap[iCase][1]], pVertexMidVtx[iVtxMap[iCase][3]]);
      
    }
    else
    {
      iNumNewEdge = 8;
      pEdgeNewEdge[7] = E_exist(pVertexMidVtx[iVtxMap[iCase][1]], pVertexMidVtx[iVtxMap[iCase][2]]);
    }

    for (int iEdge = 0; iEdge < iNumNewEdge; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  for (int iFace = 1; iFace < 5; ++iFace)
    delete_face(parent_faces[iFace], 0);

  // delete edge if it can be
  for (iEdge = 4; iEdge < 8; ++iEdge)
    delete_edge(parent_edges[iEdge], 0);

}


void meshTemplate::template_reg_pyramid_quad_tri_bisect(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  int iTag;
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];

  pEdge pEdgeEdge;
  int iInd[2], iTagEdge = 0;
  for (int iEdge = 4; iEdge < 8; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if (EN_getDataInt((pEntity)pEdgeEdge, int_reff, &iTag))
    {
      iInd[iTagEdge] = iEdge - 4;
      iTagEdge++;
    }
  }

  int iDiff = iInd[1] - iInd[0];
  int iChooseInd = 0;
  if (iDiff == 3)
    iChooseInd = 1;

  templatesUtil::mapping_template_pyr(region,ordered_edges,iInd[iChooseInd],parent_faces,parent_edges,parent_verts);

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pVertex pVertexNewVtx[6];
  pEdge pEdgeNewEdge[6];
  pRegion pRegionNewRgn[3];

  pPList plist = get_split_faces_2(parent_faces[4]);
  pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
  pEdgeNewEdge[1] = (pEdge)PList_item(plist, 1);

  int iCase = 0;
  if ((E_vertex(pEdgeNewEdge[0], 0) == parent_verts[4]) || (E_vertex(pEdgeNewEdge[0], 1) == parent_verts[4]))
    iCase = 1;

  plist = get_split_edges(parent_edges[5]);
  pVertexNewVtx[1] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[4]);
  pVertexNewVtx[4] = (pVertex)PList_item(plist, 0);  
  plist = get_split_edges(parent_edges[1]);
  pVertexNewVtx[2] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[3]);
  pVertexNewVtx[5] = (pVertex)PList_item(plist, 0);

  pVertexNewVtx[0] = parent_verts[1];
  pVertexNewVtx[3] = parent_verts[0];

  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[0]);

  if (iCase == 0)
  {
    pVertexNewVtx[0] = pVertexNewVtx[1];
    pVertexNewVtx[3] = pVertexNewVtx[4];
    pVertexNewVtx[1] = parent_verts[2];
    pVertexNewVtx[4] = parent_verts[3];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[1]);

    pVertexNewVtx[2] = pVertexNewVtx[4];
    pVertexNewVtx[4] = parent_verts[4];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[2]);  
  }
  else
  {
    pVertexNewVtx[0] = pVertexNewVtx[4];
    pVertexNewVtx[3] = pVertexNewVtx[5];
    pVertexNewVtx[4] = parent_verts[4];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[1]);

    pVertexNewVtx[0] = parent_verts[3];
    pVertexNewVtx[1] = parent_verts[2];
    FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[2]);
  }

  if( newRgns )
  {
    for (int iReg = 0; iReg < 3; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  plist = get_bisected_faces(parent_faces[1]);
  pEdgeNewEdge[2] = (pEdge)PList_item(plist, 0);
  if(!E_typeInBL((pEntity)pEdgeNewEdge[2]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[2],blEdgeTypeID,eGROWTH);
  plist = get_bisected_faces(parent_faces[0]);
  pEdgeNewEdge[3] = (pEdge)PList_item(plist, 0);
  if(!E_typeInBL((pEntity)pEdgeNewEdge[3]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[3],blEdgeTypeID,eGROWTH);

  if ( newEdges )
  {
    plist = get_split_faces_2(parent_faces[2]);
    pEdgeNewEdge[4] = (pEdge)PList_item(plist, 0);
    pEdgeNewEdge[5] = (pEdge)PList_item(plist, 1);

    for (int iEdge = 0; iEdge < 6; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  delete_face(parent_faces[0],0);
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[4],0);

  // delete edge if it can be
  delete_edge(parent_edges[1],0);
  delete_edge(parent_edges[3],0);
  delete_edge(parent_edges[4],0);
  delete_edge(parent_edges[5],0);
}


void meshTemplate::template_reg_pyramid_quad_tri_bisect_2(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];

  pEdge pEdgeEdge;
  int iInd[2], iTagEdge = 0;
  for (int iEdge = 4; iEdge < 8; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(ordered_edges, iEdge);
    if (!E_typeInBL(pEdgeEdge))
    {
      iInd[iTagEdge] = iEdge - 4;
      iTagEdge++;
    }
  }

  int iDiff = iInd[1] - iInd[0];
  int iChooseInd = 0;
  if (iDiff == 3)
    iChooseInd = 1;

  templatesUtil::mapping_template_pyr(region,ordered_edges,iInd[iChooseInd],parent_faces,parent_edges,parent_verts);

  pGEntity g_entity = (pGEntity)R_whatIn(region);

  pVertex pVertexNewVtx[6];
  pEdge pEdgeNewEdge[12];
  pRegion pRegionNewRgn[7];

  int iVtxMap[2][7] = {{1, 0, 4, 2, 1, 5, 3}, {0, 1, 5, 3, 0, 4, 2}};   

  pPList plist;
  pVertex pVertexMidVtx[6];
  for (int iVtx = 0; iVtx < 4; ++iVtx)
  {
    plist = get_split_edges(parent_edges[iVtx+4]);
    pVertexMidVtx[iVtx] = (pVertex)PList_item(plist, 0);
  }

  plist = get_split_edges(parent_edges[1]);
  pVertexMidVtx[4] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[3]);
  pVertexMidVtx[5] = (pVertex)PList_item(plist, 0);

  plist = get_split_faces_2(parent_faces[1]);
  pEdgeNewEdge[0] = (pEdge)PList_item(plist, 0);
  pEdgeNewEdge[1] = (pEdge)PList_item(plist, 1);

  int iCase;
  if ((E_vertex(pEdgeNewEdge[0], 0) == parent_verts[0]) || (E_vertex(pEdgeNewEdge[0], 1) == parent_verts[0]))
    iCase = 1;
  else
    iCase = 0;

  pVertexNewVtx[0] = parent_verts[0];
  pVertexNewVtx[1] = parent_verts[1];
  pVertexNewVtx[2] = pVertexMidVtx[4];
  pVertexNewVtx[3] = pVertexMidVtx[5];
  pVertexNewVtx[4] = pVertexMidVtx[iVtxMap[iCase][1]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[0]);

  pVertexNewVtx[0] = parent_verts[iVtxMap[iCase][0]];  
  pVertexNewVtx[1] = pVertexNewVtx[4];
  pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][2]];
  pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][4]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[1]);

  pVertexNewVtx[0] = pVertexMidVtx[iVtxMap[iCase][3]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[2]);

  pVertexNewVtx[0] = pVertexMidVtx[iVtxMap[iCase][5]];
  pVertexNewVtx[1] = pVertexMidVtx[iVtxMap[iCase][6]];
  pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][3]];
  pVertexNewVtx[3] = pVertexMidVtx[iVtxMap[iCase][2]];
  pVertexNewVtx[4] = pVertexMidVtx[iVtxMap[iCase][1]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[3]);

  if (iCase == 0)
  {
    pVertexNewVtx[2] = parent_verts[3];
    pVertexNewVtx[5] = parent_verts[2];
  }
  else
  {
    pVertexNewVtx[2] = parent_verts[2];
    pVertexNewVtx[5] = parent_verts[3];
  }
  pVertexNewVtx[4] = pVertexMidVtx[iVtxMap[iCase][3]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[4]);

  pVertexNewVtx[3] = parent_verts[4];
  pVertexNewVtx[0] = pVertexMidVtx[iVtxMap[iCase][1]];
  pVertexNewVtx[2] = pVertexMidVtx[iVtxMap[iCase][3]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[5]);

  pVertexNewVtx[1] = pVertexMidVtx[iVtxMap[iCase][4]];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_TET, 4, pVertexNewVtx, pRegionNewRgn[6]);

  if( newRgns )
  {
    for (int iReg = 0; iReg < 7; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  plist = get_bisected_faces(parent_faces[0]);
  pEdgeNewEdge[8] = (pEdge)PList_item(plist, 0);
  if(!E_typeInBL((pEntity)pEdgeNewEdge[8]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[8],blEdgeTypeID,eGROWTH);
  plist = get_bisected_faces(parent_faces[3]);
  pEdgeNewEdge[9] = (pEdge)PList_item(plist, 0);
  if(!E_typeInBL((pEntity)pEdgeNewEdge[9]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[9],blEdgeTypeID,eGROWTH);

  if ( newEdges )
  {
    int iEdge = 2;
    for (int iFace = 2; iFace < 4; iFace+=2)
    {
      plist = get_split_faces_3(parent_faces[iFace]);
      pEdgeNewEdge[iEdge] = (pEdge)PList_item(plist, 0);
      pEdgeNewEdge[iEdge+1] = (pEdge)PList_item(plist, 1);
      pEdgeNewEdge[iEdge+2] = (pEdge)PList_item(plist, 2);
      iEdge += 3;
    }
    
    pEdgeNewEdge[10] = E_exist(pVertexMidVtx[iVtxMap[iCase][1]], pVertexMidVtx[iVtxMap[iCase][2]]);
    pEdgeNewEdge[11] = E_exist(pVertexMidVtx[iVtxMap[iCase][1]], pVertexMidVtx[iVtxMap[iCase][3]]);

    for (int iEdge = 0; iEdge < 12; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  for (int iFace = 0; iFace < 5; ++iFace)
    delete_face(parent_faces[iFace], 0);

  // delete edge if it can be
  for (int iEdge = 4; iEdge < 8; ++iEdge)
    delete_edge(parent_edges[iEdge], 0);
  delete_edge(parent_edges[1], 0);
  delete_edge(parent_edges[3], 0);
}


void meshTemplate::template_reg_pyramid_quad_2_tri_bisect(pRegion region, pPList ordered_edges, pPList newRgns, pPList newEdges)
{
  pEdge parent_edges[8];
  pFace parent_faces[5];
  pVertex parent_verts[5];
  pGEntity g_entity = (pGEntity)R_whatIn(region);

  int iTag;
  if (EN_getDataInt((pEntity)PList_item(ordered_edges, 0), int_reff, &iTag))
    iTag = 1;
  else
    iTag = 0;

  templatesUtil::mapping_template_pyr(region,ordered_edges,iTag,parent_faces,parent_edges,parent_verts);

  pVertex pVertexNewVtx[6];
  pEdge pEdgeNewEdge[9];
  pRegion pRegionNewRgn[4];

  pPList plist;
  pVertex pVertexMidVtx[6];
  for (int iVtx = 0; iVtx < 4; ++iVtx)
  {
    plist = get_split_edges(parent_edges[iVtx+4]);
    pVertexMidVtx[iVtx] = (pVertex)PList_item(plist, 0);
  }

  plist = get_split_edges(parent_edges[1]);
  pVertexMidVtx[4] = (pVertex)PList_item(plist, 0);
  plist = get_split_edges(parent_edges[3]);
  pVertexMidVtx[5] = (pVertex)PList_item(plist, 0);

  pVertexNewVtx[0] = parent_verts[1];
  pVertexNewVtx[1] = pVertexMidVtx[1];
  pVertexNewVtx[2] = pVertexMidVtx[4];
  pVertexNewVtx[3] = parent_verts[0];
  pVertexNewVtx[4] = pVertexMidVtx[0];
  pVertexNewVtx[5] = pVertexMidVtx[5];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[0]);

  pVertexNewVtx[0] = pVertexMidVtx[2];
  pVertexNewVtx[3] = pVertexMidVtx[3];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[1]);

  pVertexNewVtx[1] = parent_verts[2];
  pVertexNewVtx[4] = parent_verts[3];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PRISM, 6, pVertexNewVtx, pRegionNewRgn[2]);

  pVertexNewVtx[1] = pVertexMidVtx[3];
  pVertexNewVtx[2] = pVertexMidVtx[0];
  pVertexNewVtx[3] = pVertexMidVtx[1];
  pVertexNewVtx[4] = parent_verts[4];
  FMDB_Rgn_Create (pmesh, g_entity, FMDB_PYRAMID, 5, pVertexNewVtx, pRegionNewRgn[3]);

  int iEdge = 0;
  for (int iFace = 1; iFace < 4; iFace+=2)
  {
    plist = get_bisected_faces(parent_faces[iFace]);
    pEdgeNewEdge[iEdge] = (pEdge)PList_item(plist, 0);
    if(!E_typeInBL((pEntity)pEdgeNewEdge[iEdge]))
      EN_attachDataInt((pEntity)pEdgeNewEdge[iEdge],blEdgeTypeID,eGROWTH);
    iEdge++;
  }
  plist = get_bisected_faces(parent_faces[0]);
  pEdgeNewEdge[8] = (pEdge)PList_item(plist, 0);
  if(!E_typeInBL((pEntity)pEdgeNewEdge[8]))
    EN_attachDataInt((pEntity)pEdgeNewEdge[8],blEdgeTypeID,eGROWTH);

  if( newRgns )
  {
    for (int iReg = 0; iReg < 4; ++iReg)
      PList_append(newRgns, pRegionNewRgn[iReg]);
  }

  if ( newEdges )
  {
    for (int iFace = 2; iFace < 5; iFace+=2)
    {
      plist = get_split_faces_3(parent_faces[iFace]);
      pEdgeNewEdge[iEdge] = (pEdge)PList_item(plist, 0);
      pEdgeNewEdge[iEdge+1] = (pEdge)PList_item(plist, 1);
      pEdgeNewEdge[iEdge+2] = (pEdge)PList_item(plist, 2);
      iEdge += 3;
    }
    
    for (int iEdge = 0; iEdge < 9; ++iEdge)
      PList_append(newEdges, pEdgeNewEdge[iEdge]);
  }

  callCallback((pEntity)region,newRgns,0);

  // delete the region.
  delete_region(region,0);

  // delete face if it can be
  for (int iFace = 0; iFace < 5; ++iFace)
    delete_face(parent_faces[iFace], 0);

  // delete edge if it can be
  for (int iEdge = 4; iEdge < 8; ++iEdge)
    delete_edge(parent_edges[iEdge], 0);
  delete_edge(parent_edges[1], 0);
  delete_edge(parent_edges[3], 0);
}


void meshTemplate::layer_division_template_prism(pRegion region,
						 pPList newRgns,
						 pPList newEdges) {
/*
  int value;
  pVertex parent_verts[6];
  pEdge parent_edges[9];
  pFace parent_faces[5];
  pPList plist;
  int parent_f_dirs[5];

  pGEntity g_entity=(pGEntity)R_whatIn(region);

  pPList ordered_verts=R_vertices(region,1);
  for(int iVert=0; iVert<6; iVert++)
    parent_verts[iVert] = (pVertex)PList_item(ordered_verts,iVert);
  PList_delete(ordered_verts);

  pPList ordered_edges=R_edges(region,1);
  for(int iEdge=0; iEdge<9; iEdge++)
    parent_edges[iEdge] = (pEdge)PList_item(ordered_edges,iEdge);
  PList_delete(ordered_edges);

  for(int iFace=0; iFace<5; iFace++) {
    parent_faces[iFace] = R_face(region,iFace);
    // parent_f_dirs[iFace] = R_dirUsingFace(region,parent_faces[iFace]);
    parent_f_dirs[iFace] = R_faceDir(region,iFace);
  }

  pEdge edges[3];    // the 3 edges to create one new triangular layer face 
  pFace faces[9];    // the 9 faces to create two new regions  
  pFace r_faces[5];  // the 5 faces to create a new region
  pRegion regions[2];// the two regions created by this template

  int f_dir[3];      // the orientation of the 3 edges of a new face
  int r_dir[5];      // the orientation of the 5 faces of a new region

  faces[0] = parent_faces[0];
  faces[7] = parent_faces[4];

  for(int iVertFace=0; iVertFace<3; iVertFace++) {
    plist=get_bisected_faces(parent_faces[iVertFace+1]);

    edges[iVertFace]=(pEdge)PList_item(plist,0);
    pPList plist1=get_split_edges(parent_edges[iVertFace+3]);
    if((pVertex)PList_item(plist1,0)==E_vertex(edges[iVertFace],0))
      f_dir[iVertFace]=1;
    else
      f_dir[iVertFace]=0;

    faces[2*iVertFace+1]=(pFace)PList_item(plist,1);
    faces[2*iVertFace+2]=(pFace)PList_item(plist,2);
    if(!F_inClosure(faces[2*iVertFace+1],(pEntity)parent_edges[iVertFace])) {
      faces[2*iVertFace+1]=(pFace)PList_item(plist,2);
      faces[2*iVertFace+2]=(pFace)PList_item(plist,1);
    }
  }
  
  // new layer face
  faces[8] = M_createF(pmesh,3,edges,f_dir,g_entity);

  r_faces[0]=faces[0];
  r_faces[1]=faces[1];
  r_faces[2]=faces[3];
  r_faces[3]=faces[5];
  r_faces[4]=faces[8]; // new face
  r_dir[0]=parent_f_dirs[0];
  r_dir[1]=parent_f_dirs[1];
  r_dir[2]=parent_f_dirs[2];
  r_dir[3]=parent_f_dirs[3];
  r_dir[4]=1; // new face used positively
  regions[0]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

  r_faces[0]=faces[8]; // new face
  r_faces[1]=faces[2];
  r_faces[2]=faces[4];
  r_faces[3]=faces[6];
  r_faces[4]=faces[7];
  r_dir[0]=0; // new face used negatively
  r_dir[1]=parent_f_dirs[1];
  r_dir[2]=parent_f_dirs[2];
  r_dir[3]=parent_f_dirs[3];
  r_dir[4]=parent_f_dirs[4];
  regions[1]=M_createR(pmesh,5,r_faces,r_dir,g_entity);

//  int surfTag = EN_blSurfaceTag((pEntity)region);
//  int level = EN_levelInBL((pEntity)region);

  // the level for upper layer face has been updated after growth edge split
  // --- osahni
  // WARNING : DO NOT "level0" and "level1" values as such
  int level0 = EN_levelInBL((pEntity)parent_faces[0]);
  int level1 = EN_levelInBL((pEntity)parent_faces[4]);
  int iDir = 0;
  if(level0>level1)
    iDir = 1;

  for(int iVertFace=0; iVertFace<3; iVertFace++) {
    if(!E_typeInBL(edges[iVertFace])) {
      EN_labelBLEntity((pEntity)edges[iVertFace],level,eLAYER);

      // this has been done after growth edge split
      // EN_unlabelBLEntity((pEntity)parent_edges[iVertFace+(1-iDir)*6]);
      // EN_labelBLEntity((pEntity)parent_edges[iVertFace+(1-iDir)*6],level+1,eLAYER);
    }

    if(!F_typeInBL(faces[2*iVertFace+1]))
      EN_labelBLEntity((pEntity)faces[2*iVertFace+1],level+1*iDir,fVERTICAL_QUAD);
    if(!F_typeInBL(faces[2*iVertFace+2]))
      EN_labelBLEntity((pEntity)faces[2*iVertFace+2],level+1-1*iDir,fVERTICAL_QUAD);
  }

  EN_labelBLEntity((pEntity)faces[8],level,fLAYER);
  // this has been done after growth edge split
  // EN_unlabelBLEntity((pEntity)parent_faces[(1-iDir)*4]);
  // EN_labelBLEntity((pEntity)parent_faces[(1-iDir)*4],level+1,fLAYER);

  EN_labelBLEntity((pEntity)regions[0+iDir],level,rREGULAR);
  EN_labelBLEntity((pEntity)regions[1-iDir],level+1,rREGULAR);

  if(newRgns) {
    PList_append(newRgns,regions[0]);
    PList_append(newRgns,regions[1]);
  }
  
  if(newEdges) {
    PList_append(newEdges,edges[0]);
    PList_append(newEdges,edges[1]);
    PList_append(newEdges,edges[2]);
  } 
  
  callCallback((pEntity)region,newRgns,0);

  // delete the region
  // use delete_region with option "0"
  delete_region(region,0);
  
  // delete faces if it can be
  delete_face(parent_faces[1],0);
  delete_face(parent_faces[2],0);
  delete_face(parent_faces[3],0);

  // delete edges if it can be
  delete_edge(parent_edges[3],0);
  delete_edge(parent_edges[4],0);
  delete_edge(parent_edges[5],0);
*/
}
