/*
  this class contains all routines to visualize tetrahedral mesh 
  and its associated data for debugging meshAdapt purposes.

  It consists of three parts:
  1. visSim (mvtk) related tools to show the mesh in the middle of
     debugging;
  2. write out part of the mesh in .SMS version 2 format so that
     I can visuial them seperately using PATRAN, meshViewer,
     gmsh, DataExplorer 
  3. write the files to visualize the mesh metric field using Data
     explorer

  History:  mm/dd/yy
            01/08/03  Created    - Xiangrong li  
 */
#include "visUtil.h"
#include "AdaptUtil.h"
#include "MeshTools.h"
#include "MeshSize.h"
#include "sizeFieldBase.h"
#include "PWLinearSField.h"
#include "PList.h"
#include "FMDB_cint.h"
#include "FMDB_Internals.h"
#include <stdio.h>
#include <fstream>
#include <stdlib.h>
#include <unistd.h>
#include <map>
//#include <ctype.h>

using std::ifstream;

#ifdef MVTK
#include "mvtk.h"
#endif

namespace visUtil {

  // mvtk related tools

#ifdef MVTK

  void mvtkAddPList(pPList &l, float opacity, int color, int edge, int type)
  {
    pEntity ent;
    void *iter=0;
    int i,j;
    
    switch( type ) {
    case Tedge:
      while( ent=(pEntity)PList_next(l,&iter) ) {
	mvtkSetMEntOpacity(ent,opacity);
	mvtkSetMEntColorI(ent,color);
	mvtkAddMEnt(ent);
      }
      break;
    case Tface:
      while( ent=(pEntity)PList_next(l,&iter) ) {
	mvtkSetMEntOpacity(ent,opacity);
	mvtkSetMEntColorI(ent,color);
	mvtkAddMEnt(ent);
	if(edge && EN_type(ent)==Tface) {
	  for( i=0; i<3; i++ ) 
	    mvtkAddMEnt((pEntity)F_edge((pFace)ent,i));
	}      
      }
      break;
    case Tregion:
      pRegion region;
      while( region=(pRegion)PList_next(l,&iter) ) {
	for( i=0; i<R_numFaces(region); i++ ) {
	  ent=(pEntity)R_face(region,i);
	  mvtkSetMEntOpacity(ent,opacity);
	  mvtkSetMEntColorI(ent,color);
	  mvtkAddMEnt(ent);
	  if(edge && EN_type(ent)==Tface) {
	    for( j=0; j<3; j++ ) 
	      mvtkAddMEnt((pEntity)F_edge((pFace)ent,j));
	  }      
	}
      }
    }
    
    return;
  }
  
  void mvtkAddPList(pPList &l, int color)
  {
    pEntity ent;
    void *iter=0;
    
    while( ent=(pEntity)PList_next(l,&iter) ) {
      mvtkSetMEntColorI(ent,color);
      mvtkAddMEnt(ent);
    }
    return;
  }

  void mvtkShowMeshGface(pGModel model, pMesh mesh, int gfTag)
  {
    pGEntity gent=GM_entityByTag(model,Gface,gfTag);
    
    if( !gent || GEN_type(gent)!=Gface ) return;
    
    FIter fiter=M_classifiedFaceIter(mesh, gent, 0);
    pFace face;
    int i;
    
    while( face=FIter_next(fiter) ) {
      mvtkAddMEnt((pEntity)face);
      for( i=0; i<3; i++ ) 
	mvtkAddMEnt((pEntity)F_edge(face,i));
    }
    
    return;
  }
  
  void mvtkShowConnectedEdges(pVertex v) 
  {
    for( int i=0; i<V_numEdges(v); i++ ) 
      mvtkAddMEnt((pEntity)V_edge(v,i));
    return;
  }
  
  
  void mvtkAddMRgn(pRegion r)
  {
    pFace face;
    int i,j;
    for( i=0; i<4; i++ ) {
      face=R_face(r,i);
      mvtkAddMEnt((pEntity)face);
      for( j=0; j<3; j++ ) 
	mvtkAddMEnt((pEntity)F_edge(face,j));
    }
    return;
  }
  
  void mvtkShowCavity(pVertex v, pPList boldEnts) 
  {
    pRegion region;
    pFace face;
    pPList cavity=PList_new();
    pPList vRgns=V_regions(v);
    void *iter=0;
    while( (region=(pRegion)PList_next(vRgns,&iter)) )
      {
	face=R_vtOpFc(region,v);
	PList_append(cavity,face);
      }
    mvtkAddPList(cavity,0.3,4,1,Tface);
    mvtkShowConnectedEdges(v);
    if( boldEnts )
      mvtkAddPList(boldEnts,0);
    mvtkActivate();
    mvtkRemoveAllMEnts();
    PList_delete(cavity);
    PList_delete(vRgns);
  }
  
  void mvtkShowCavity_2(pVertex vd, pPList edges) 
  {
    pEdge edgeDel;
    void *iter=0;
    while( edgeDel=(pEdge)PList_next(edges,&iter) )
      {
	if( !E_chkClpTopo(vd,edgeDel) )
	  continue;
	
	pRegion region;
	pFace face;
	pPList cavity=PList_new();
	pPList elist=PList_new();
	pPList vRgns_2=PList_new();
	pPList vRgns=V_regions(vd);
	void *iter_2=0;
	void *iter_3=0;
	while( (region=(pRegion)PList_next(vRgns,&iter_2)) )
	  {
	    if( ! R_inClosure(region,(pEntity)edgeDel) ) 
	      {
		PList_append(vRgns_2,region);
		continue;
	      }
	    
	    for( int i=0; i<4; i++ ) {
	      face=R_face(region,i);
	      if( F_inClosure(face,(pEntity)edgeDel) )
		continue;
	      if( F_inClosure(face,(pEntity)vd) )
		PList_append(cavity,face);
	    }
	  }
	
	double ori[3], tar[3];
	pVertex vr=E_otherVertex(edgeDel,vd);
	V_coord(vd,ori);
	V_coord(vr,tar);
	adaptUtil::move_vertex(vd, tar);
	
	iter_2=0;
	while( (region=(pRegion)PList_next(vRgns_2,&iter_2)) )
	  {
	    face=R_vtOpFc(region,vd);
	    PList_append(cavity,face);
	    if( R_volume(region)<1.0e-10 )
	      mvtkSetMEntColorI((pEntity)face,0);
	    
	    pPList velist=R_edges(region,1);
	    iter_3=0;
	    pEdge ee;
	    while( ee=(pEdge)PList_next(velist,&iter_3) ) 
	      if( E_vertex(ee,0)==vd || E_vertex(ee,1)==vd )
		PList_append(elist,ee);
	    PList_delete(velist);
	  }
	
	mvtkAddPList(cavity,0.3,4,1,Tface);
	mvtkAddPList(elist,1,7,0,Tedge);
	mvtkAddMEnt((pEntity)vd);
	mvtkActivate();
	mvtkRemoveAllMEnts();
	PList_delete(cavity);
	PList_delete(vRgns);
	PList_delete(vRgns_2);
	PList_delete(elist);
	adaptUtil::move_vertex(vd, ori);
      }
    return;
  }
  
  void mvtkShowCavity(pEdge e) 
  {
    pRegion region;
    pFace face;
    int i;
    pPList cavity=PList_new();
    pPList eRgns=E_regions(e);
    void *iter=0;
    while( (region=(pRegion)PList_next(eRgns,&iter)) )
      {
	for( i=0; i<4; i++ ) {
	  face=R_face(region,i);
	  if( !F_inClosure(face,(pEntity)e) )
	    PList_append(cavity,face);
	}
      }
    mvtkAddPList(cavity,0.3,4,1,Tface);
    mvtkSetMEntColorI((pEntity)e,0);
    mvtkAddMEnt((pEntity)e);
    mvtkActivate();
    mvtkRemoveAllMEnts();
    PList_delete(cavity);
    PList_delete(eRgns);
  }

#endif  // end #ifdef MVTK


  // write out a part of the mesh

  void writeAFace(pFace worstFace)
  {
    pPList faces=PList_new();
    pPList fverts, vfaces;
    pVertex vert;
    pFace face;
    void *iter_2, *iter;
    PList_append(faces,worstFace);
    fverts=F_vertices(worstFace,1);
    iter=0;
    while( vert=(pVertex)PList_next(fverts,&iter) )
      {
	vfaces=V_faces(vert);
	iter_2=0;
	while( face=(pFace)PList_next(vfaces, &iter_2) )
	  PList_appUnique(faces,face);
	PList_delete(vfaces);
      }
    PList_delete(fverts);
    
    writeFaces(faces);
    PList_delete(faces);
  }

  void writeFaces(pPList faces)
  {
    pMesh tmpMesh=MS_newMesh(0);
    pMeshDataId localPtr=MD_newMeshDataId("ptrToTmpMesh");
    
    pEdge edges[3];       // the three bounding edges to create a new face
    int   e_dirs[3];      // the three orientations how a new face uses its edges
    pVertex vertices[2];  // the two bounding vertices of a new edge. Direction: [0]->[1]
    pFace fc;
    pEdge eg;
    pVertex vt;
    pPoint pt;
    double xyz[3];
    double par[3];
    pGEntity gent;
    int type;
    int j,k;
    
    void *temp_ptr;
    void *iter=0;
    while( fc=(pFace)PList_next(faces,&iter) )
      {
	// loop over the three edges
	for( j=0;j<3;j++ ) {
	  eg=F_edge(fc,j);
	  e_dirs[j]=F_dirUsingEdge(fc,eg);
	  if( EN_getDataPtr((pEntity)eg,localPtr,&temp_ptr) ) 
	    edges[j]=(pEdge)temp_ptr;
	  else {
	    
	    // loop over the two vertices
	    for( k=0;k<2;k++ ) {
	      vt=E_vertex(eg,k);
	      if( EN_getDataPtr((pEntity)vt,localPtr,&temp_ptr) ) 
		vertices[k]=(pVertex)temp_ptr;
	      else {
		
		// create vertex in local mesh and attach it to its matching vertex in pmesh
		pt=V_point(vt);
		xyz[0]=P_x(pt);  xyz[1]=P_y(pt);  xyz[2]=P_z(pt);
		gent=V_whatIn(vt);
		type=GEN_type(gent);
		par[0]=0.0;   par[1]=0.0;   par[2]=0.0;
		//               if( type==Gedge ) 
		//                 par[0]=P_param1(pt);
		//               else if( type==Gface )
		//                 P_param2(pt,&par[0],&par[1],(int*)&par[2]);
		
		vertices[k] = M_createVP2(tmpMesh,xyz,par,0,gent);
		EN_attachDataPtr((pEntity)vt,localPtr,vertices[k]);
	      }
	    }
	    
	    // create edge in local mesh and attach it to its matching edge in pmesh
	    gent=E_whatIn(eg);
	    edges[j]=M_createE(tmpMesh,vertices[0], vertices[1], gent);
	    EN_attachDataPtr((pEntity)eg,localPtr,edges[j]);
	  }
	}
	
	// create face in local mesh and attach it to its matching face in pmesh
	gent=F_whatIn(fc);
	M_createF(tmpMesh, 3, edges, e_dirs, gent);
      }
  
    iter=0;
    while( fc=(pFace)PList_next(faces,&iter) )
      {      
	for( j=0;j<3;j++ ) {
	  eg=F_edge(fc,j);
	  if( EN_getDataPtr((pEntity)eg,localPtr,&temp_ptr) ) {
	    EN_deleteData((pEntity)eg,localPtr);
	    for( k=0;k<2;k++ ) {
	      vt=E_vertex(eg,k);
	      if( EN_getDataPtr((pEntity)vt,localPtr,&temp_ptr) ) 
		EN_deleteData((pEntity)vt,localPtr);
	    }
	  }
	}
      }
    
//    M_writeSMS(tmpMesh,"partialMesh",2);
    
    MD_deleteMeshDataId(localPtr);
    M_delete(tmpMesh);
    return;
  }

  void writeRegions(pPList regions, int vers)
  {
    char sname[50];
    pMesh copyMesh=adaptUtil::copyRegions(regions, 0, 0);
    sprintf(sname,"partialMesh%d.sms",vers);
//    M_writeSMS(copyMesh,sname,2);
    M_delete(copyMesh);
    return;
  }

  // end of writing out a part of the mesh

  /// iWriteWithMesh should be =1 if the mesh is written along with size field. If the mesh stays the same, it should eb =0
  void writeSizeField(pMeshMdl mesh, pSField pf, const char* cFileName = ".", int iWriteWithMesh = 0) 
  { 
    pVertex vt;
    FILE *fout;
    pMSize pT;
    double* e;
    double h;
    int i;
    char nProc[8], file_name[128];

    int iNumParts;
    pPart pm;
    FMDB_Mesh_GetNumPart (mesh, &iNumParts);
    for (int iNP = 0; iNP < iNumParts; ++iNP)
    {
    FMDB_Mesh_GetPart (mesh, iNP, pm);
    sprintf(nProc,"%d", P_pid()*iNumParts+iNP);
    strcpy(file_name, cFileName);
    strcat(file_name,"/sizefield");
    strcat(file_name,nProc);
    strcat(file_name,".dat");
    VIter vit=M_vertexIter(pm);
    fout = fopen(file_name,"w");
//    fprintf(fout,"%d\n",M_numVertices(pm));
    int iCount = 1;
    while( vt=VIter_next(vit) ) 
    {
      pT=pf->getSize(vt);
      if (iWriteWithMesh)
        fprintf(fout,"%ld\n", iCount);
      else
        fprintf(fout,"%ld\n", EN_id(vt));
      iCount++;
      for( i=0; i<3; i++)
      {
        h=pT->size(i);
        e=pT->eigenvector(i);
        fprintf(fout,"%.16lf %.16lf %.16lf %.16lf\n", h, e[0], e[1], e[2]);
      }
    }
    VIter_delete (vit);
    fclose(fout);
    }

#ifdef MA_PARALLEL
    MPI_Barrier(MPI_COMM_WORLD);
#endif
    return;
  }

  struct sSizeFld
  {
    double h[3];
    double e[3][3];
  };

  void readSizeField(pMeshMdl mesh, pSField pf)
  {
    pPart pm;
    FMDB_Mesh_GetPart(mesh, 0, pm);

    pVertex vt;
    FILE *fout;
    double e[3];
    double h;
    int iSize;
    char cFileName[128];
    sprintf(cFileName,"sizefield%d.dat",P_pid());
    fout = fopen(cFileName,"r");
    int iNumVtx = M_numVertices(pm);

    std::map<int, sSizeFld> MapVtxIdSizeFld;
    int iVtxId, iCount = 0;
    for (int iIt = 0; iIt < iNumVtx; ++iIt)
    {
      sSizeFld SF;
      fscanf(fout,"%ld", &iVtxId);
//      fscanf(fout,"%lf", &h);
      for(iSize = 0; iSize < 3; iSize++)
      {
        fscanf(fout,"%lf %lf %lf %lf", &h, &e[0], &e[1], &e[2]);
        SF.h[iSize] = h;
        SF.e[iSize][0] = e[0];
        SF.e[iSize][1] = e[1];
        SF.e[iSize][2] = e[2];
      }
      MapVtxIdSizeFld[iVtxId] = SF;
    }

    VIter vit=M_vertexIter(pm);
    while( vt=VIter_next(vit) )
    {
      iVtxId = EN_id(vt);
      ((PWLsfield *)pf)->setSize((pEntity)vt, MapVtxIdSizeFld[iVtxId].e, MapVtxIdSizeFld[iVtxId].h);
    }
    VIter_delete (vit);
    fclose(fout);
    MapVtxIdSizeFld.clear();
    return;
  }


  void writeSizeField2(pMesh pm, pSField pf) 
  { 
    pVertex vt;
    FILE *fout;
    pMSize pT;
    double* e;
    int i;
    VIter vit=M_vertexIter(pm);
    fout = fopen("meshsize.dat","w");
    fprintf(fout,"%d 0\n",M_numVertices(pm));

    while( vt=VIter_next(vit) ) {
      pT=pf->getSize(vt);
      for( i=0; i<3; i++)
	fprintf(fout,"%10.8f ",pT->size(i));

      for( i=0; i<2; i++) {
	e=pT->eigenvector(i);
	fprintf(fout,"%10.8f %10.8f %10.8f ", e[0],e[1],e[2]);
      }
      fprintf(fout,"\n");
    }
    VIter_delete (vit);
    fclose(fout);
    return;
  }

  void readSizeField2(pMesh pm, pSField pf) 
  { 
    pVertex vt;
    double e[3][3];
    double h[3];
    int nv;
    double beta;

    VIter vit=M_vertexIter(pm);    
    ifstream fin("meshsize.dat");

    fin >> nv >> beta;

    while( vt=VIter_next(vit) ) {
      fin >> h[0] >> h[1] >> h[2];
      fin >> e[0][0] >>  e[0][1] >>  e[0][2];
      fin >> e[1][0] >>  e[1][1] >>  e[1][2];
      crossProd(e[0],e[1],e[2]);

      ((PWLsfield *)pf)->setSize((pEntity)vt,e,h);
    }
    VIter_delete (vit);
    fin.close ();

    if( beta >= 1.0 ) {
      double betas[3];
      betas[0]=beta; betas[1]=beta; betas[2]=beta;
      ((PWLsfield *)pf)->anisoSmooth(betas);
    }

    return;
  }
}
