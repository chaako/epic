#ifndef _H_analyticalSField
#define _H_analyticalSField

#include "sizeFieldBase.h"
#include "AdaptTypes.h"

class analyticalSField: public SFieldBase
{
 public:
  analyticalSField(sizeFunc f): sfunc(f), mtol(1.0e-14) {};
  ~analyticalSField() {};

  virtual int type() { return 2; }

  // geometric computation
  virtual double lengthSq(pEdge);
  virtual double areaSq(pFace);
  virtual double volume(pRegion);

  virtual double lengthSq(dArray, dArray, pMSize );
  virtual double lengthSq(dArray, dArray, pMSize, pMSize );
  virtual double lengthSq(pVertex,pVertex);
  virtual double areaSq(dArray[3], pMSize, dArray);
  virtual double volume(dArray[4], pMSize);
  virtual double angleSq(dArray, dArray, pMSize);

  // compute location of center point
  virtual void center(pEdge, dArray, pMSize *);
  virtual double center(pVertex,pVertex,dArray,pMSize *);

#ifdef MATCHING
  virtual void center(pVertex,pVertex, double, dArray,pMSize *);
#endif  

  // set/delete the size at an entity
  virtual void setSize(pEntity, pMSize) {return;}
  virtual void setSize(pEntity, double) {return;}
  virtual void deleteSize(pEntity) {return;}

  // get the size at a point/vertex 
  virtual pMSize getSize(dArray, pEntity);
  virtual pMSize getSize(dArray, pPList) {return 0;}
  virtual pMSize getSize(pVertex) {return 0;}

 protected:
  sizeFunc sfunc;
  double mtol;

  double center(dArray[2], double[3]);
};

#endif
