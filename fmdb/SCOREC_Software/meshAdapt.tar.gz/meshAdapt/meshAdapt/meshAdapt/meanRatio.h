#ifndef _H_meanRatio
#define _H_meanRatio

#include "FMDB.h"
#include "AdaptTypes.h"

class MeanRatio
{
 protected:
  double mtol;

  double acptValue;
  pSField pSF;
  int flag;


 public: 
  MeanRatio(pSField);
  ~MeanRatio();

  virtual int XYZ_shape(dArray[3],pMSize[3],dArray,double *);
  virtual int XYZ_shape(dArray[4],pMSize[4],double *);
  virtual int R_shape(pRegion, double *);
  virtual int F_shape(pFace, dArray, double *);

  int XYZ_shape(dArray[3],pMSize,dArray,double *);
  int XYZ_shape(dArray[4],pMSize,double *);

  void setAcptValue(double t) { acptValue=t; }
  void setDefaultAcptValue() { acptValue=1.0e-14; }

};

#endif
