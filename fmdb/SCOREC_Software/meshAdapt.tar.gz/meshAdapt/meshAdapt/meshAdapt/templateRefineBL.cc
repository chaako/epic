#include <iostream>
#include <list>
#include <vector>
#include <deque>

#include "templateRefine.h"
#include "BLUtil.h"
#include "mEntity.h"
#include "FMDB_cint.h"

using std::cout;
using std::endl;

using namespace std;

extern pMeshDataId blVertexTypeID, blEdgeTypeID, blFaceTypeID, blRegionTypeID, remLayerNumberID;
extern pMeshDataId split_id;

int meshTemplate::tagBLEdges(pEdge edge)
{
  vector<pEdge> edgesStack;
  BL_getHorizontalEdgesByEdge(edge, edgesStack);

  int nref = 0;
  for (int i = 0; i < edgesStack.size(); i++)
  {
    edge = edgesStack[i];

    if (setRefineLevel(edge,1))
      nref++;
  }
  return nref;
}


int meshTemplate::untagBLEdges(pEdge edge)
{
  vector<pEdge> edgesStack;
  BL_getHorizontalEdgesByEdge(edge, edgesStack);

  int nref = 0;
  for (int i = 0; i < edgesStack.size(); i++)
  {
    edge = edgesStack[i];
    if (setRefineLevel(edge,0))
      nref++;
  }
  return nref;
}


void meshTemplate::runBL() 
{

  pEdge edge;
  pFace face;
  pRegion region;

  int value, eTypeInBL;

  /// list of BLs to be refined
  deque<pBLayer> refBLFacesRegions;
  list<pEdge>::iterator eIt;

  /// list of faces adjacent to BL edges but not part of BL, i.e. part of an interface region, adjacent to BL locally or remotely
//  refInterfaceFaces.clear();
  /// list of interface regions to be refined
//  refInterfaceRegions.clear();

#ifdef AOMD_
#ifdef MA_PARALLEL
  M_unifyTaggedEntities(int_reff, pRefBLEdges);

  /// Some edges of the stack higher than the one communicating edges needed for refinement might not be tagged so need to check for all the stacks again
  for (eIt=pRefBLEdges->begin(); eIt!=pRefBLEdges->end(); eIt++)
  {
    edge = *eIt;
    if (EN_levelInBL(edge) == 0)
      tagBLEdges(edge);
  } 
//  M_attachUniqueId(pmesh, vtIdTag);
#endif
#endif

  // *******************************************
  // 		Layer Edge Refinement
  // *******************************************
  // traverse all tagged layer edges 
  int countLayerEdges=0, countTransitionEdges=0, countOtherBLEdges=0;
  int num_e_regions, num_e_faces, num_f_regions;
  pPList e_regs;
  pBLayer pbl;
  for(eIt=pRefBLEdges->begin(); eIt!=pRefBLEdges->end(); eIt++) 
  {
    edge = *eIt;
    eTypeInBL = E_typeInBL(edge);

/*
    if (!eTypeInBL)
    {
      pRefNonBLEdges->push_back(*eIt);
      // delete data even on non-BL edges for now as it will be done later for edges collected in pRefNonBLEdges
      EN_deleteData((pEntity)*eIt,int_reff);
      continue;
    }
*/

    num_e_faces = E_numFaces(edge);
    for (int i = 0; i < num_e_faces; i++)
    {
      face = E_face(edge, i);
      int f_type = F_typeInBL(face);

      if (f_type == fVERTICAL_QUAD)
      {
        if (EN_levelInBL(face) < 0 && EN_onCB(face))
          refInterfaceFaces.push_back(face);
        else
          continue;
      }

      /// Here the face on partition boundary can be the one which is detached from its boundary layer, or the one on top of BL
      if(EN_levelInBL(face) >= 0)
      {
        /// Layer and transition faces know about therir BL, so just add them to the list of refine BLs
        pbl = EN_getBL((pEntity)face);
        if (!EG_getDataInt((pEntityGroup)pbl,int_reff,&value))
        {
          EG_attachDataInt((pEntityGroup)pbl,int_reff,1);
          refBLFacesRegions.push_back(pbl);
        }

        /// This piece is to ensure that the interface region which is surrounded by two or more different boundary layers
        /// has put into the container for interior region refinement
        /// Probably need to change the way we collect BL regions and interface regions for refinement.
        /// We do not specifically collect the interface region adjacent to the layer (transition) edge
        /// assuming that it will be grabbed by another adjacent face which is not a BL face already, and this is
        /// not the case with two or more boundary layers adjacent to one interface region.
        if (face == BL_GetTopFace(pbl))
        {
          region = F_region(face, 0);
          if (R_isBLEntity(region))
            region = F_region(face, 1);
          if (region && !EN_getDataInt((pEntity)region,int_reff,&value))
          {
            EN_attachDataInt((pEntity)region,int_reff,1);
            refInterfaceRegions.push_back(region);
          }
        }
      }
      else //if (!f_type || li_DetachedInterfaceFaceOnCB)
      {
        /// All the other faces are faces of interface elements
        if (!EN_getDataInt((pEntity)face,int_reff,&value))
        {
          EN_attachDataInt((pEntity)face,int_reff,1);
          refInterfaceFaces.push_back(face);
/*
          num_f_regions = F_numRegions(face);
          for (int j = 0; j < num_f_regions; j++)
          {
            region = F_region(face, j);
            if (!EN_getDataInt((pEntity)region,int_reff,&value))
            {
              EN_attachDataInt((pEntity)region,int_reff,1);
              refInterfaceRegions.push_back(region);
            }
          }
*/
        }
      }
    }

    // split the edge (layer/transition), and delete it if possible
    if(E_refine(*eIt)) {
      if(eTypeInBL==eLAYER)
	countLayerEdges++;
      else
	countTransitionEdges++;
      // label the new bl edges
      labelNewBLEntities4LayerOrTransitionEdgeSplit(*eIt);
      delete_edge(*eIt,1);
    }
  }
  pRefBLEdges->clear();

#ifdef DEBUG
  cout<<"\nNumber of layer edges split : "<<countLayerEdges<<endl;
  if(countTransitionEdges)
    cout<<"Number of transition edges split : "<<countTransitionEdges<<endl;
  if(countOtherBLEdges)
    cout<<"\n\nWARNING : Number of non-layer or non-transition BL edges not addressed in refinement : "<<countOtherBLEdges<<"\n"<<endl;
#endif

  // *******************************************
  // 		Face refinement of BL stacks
  // *******************************************

  /// Loop over BLs, refine the top face, and depending on how it is refined, refine the rest in the stack.
  /// Then, refine the stack if vertical faces

  pMeshDataId vertFacesTag = MD_newMeshDataId("processed connected vertical face");
  pFace top_face;
  int stack_size, bit;
  vector<pFace> facesStack;
  deque<pBLayer>::iterator blIter;
  int countBaseTriTemplate1=0, countBaseTriTemplate2=0, countBaseTriTemplate3=0, countIntrFaces=0, countVertFaces=0;
  int countNonBLFaces=0, countInterfaceRgns=0, iFaceCount = 0;
  for (blIter = refBLFacesRegions.begin(); blIter != refBLFacesRegions.end(); blIter++)
  {
    iFaceCount++;

    /// Get the stack of layer and transition faces
    BL_getHorizontalFaces(*blIter, facesStack);
    stack_size = facesStack.size();
    face = facesStack[stack_size-1];
    pEdge edges[3];

    // find the refinement pattern for the surface mesh face
    bit = 0;
    for(int i=0; i<3; i++) {
      edge=F_edge(face,i);
      if(EN_getDataInt((pEntity)edge,int_reff,&value))
      {
        edges[bit] = edge;
        bit++;
      }
    }    

    // refine the face
    if (bit == 2)
    {
      /// This is to MAKE SURE ALL THE EDGES IN THE STACK ARE CHOSEN CORRECTLY!!!
      selectDiagonalOnStack(facesStack);
    }
    /// Face refinement of horizontal faces
    for(int i=0; i < stack_size; i++)
    {
      face = facesStack[i];
      switch (bit) 
      {
        case 1: get_split_faces_1(face); countBaseTriTemplate1++; delete_face(face,1); break;
        case 2: get_split_faces_selected_2(face); countBaseTriTemplate2++; delete_face(face,1); break;
        case 3: get_split_faces_3(face); countBaseTriTemplate3++; delete_face(face,1); break;
        default:  break;
      }
    }
    top_face = face;
/*
    /// This piece is to ensure that the interface region which is surrounded by two or more different boundary layers 
    /// has put into the container for interior region refinement
    /// Probably need to change the way we collect BL regions and interface regions for refinement. 
    /// We do not specifically collect the interface region adjacent to the layer (transition) edge
    /// assuming that it will be grabbed by another adjacent face which is not a BL face already, and this is 
    /// not the case with two or more boundary layers adjacent to one interface region.
    region = F_region(top_face, 0);
    if (R_isBLEntity(region))
      region = F_region(top_face, 1);
    if (region && !EN_getDataInt((pEntity)region,int_reff,&value))
    {
      EN_attachDataInt((pEntity)region,int_reff,1);
      refInterfaceRegions.push_back(region);
    }
*/
    /// Face refinement of vertical faces
    int f_type;
    for (int i = 0; i < bit; i++)
    {
      if (EN_getDataInt((pEntity)edges[i], vertFacesTag, &value) && value == 1)
        continue;
      EN_attachDataInt((pEntity)edges[i], vertFacesTag, 1);

      /// Get the stack of vertical faces
      BL_getVerticalFacesByEdge(edges[i], facesStack);

      for (int k = 0; k < facesStack.size(); k++)
      {
        face = facesStack[k];
        get_bisected_faces(face);
        countVertFaces++;
        delete_face(face,1);
      }
    }
  }

  /// Refine only part boundary interface faces
  deque<pFace>::iterator fIt;
  pFace pFaceFace;
  pEntity pEntityEnt;
  for (fIt = refInterfaceFaces.begin(); fIt != refInterfaceFaces.end(); fIt++)
  {
    pFaceFace = *fIt;
    if (EN_onCB(pFaceFace) && F_typeInBL(pFaceFace))
    {
      if(F_refine(pFaceFace)) 
      {
        /// Tag BL entities
        pPList childList;
        void *vPtr;
        EN_getDataPtr((pEntity)pFaceFace, ptr_reff, &vPtr);
        childList = (pPList)vPtr;
        for (int iEnt = 0; iEnt < PList_size(childList); ++iEnt)
        {
          pEntityEnt = (pEntity)PList_item(childList, iEnt);
          if (pEntityEnt->getLevel() == 2)
          {
            if (pFaceFace->getType() == TRI)
              EN_attachDataInt(pEntityEnt, blFaceTypeID, fLAYER);
            else
              EN_attachDataInt(pEntityEnt, blFaceTypeID, fVERTICAL_QUAD);
          }
          else
          {
            if (pFaceFace->getType() == TRI)
              EN_attachDataInt(pEntityEnt, blEdgeTypeID, eLAYER);
            else
              EN_attachDataInt(pEntityEnt, blEdgeTypeID, eGROWTH);
          }
        }

        countNonBLFaces++;
        delete_face(*fIt,1);
      }    
    }
  }

#ifdef DEBUG
  cout<<" template 1 : "<<countBaseTriTemplate1<<endl;
  cout<<" template 2 : "<<countBaseTriTemplate2<<endl;
  cout<<" template 3 : "<<countBaseTriTemplate3<<endl;

  countNonBLFaces = refInterfaceFaces.size();

  cout<<"\nNumber of vertical faces bisected : "<<countVertFaces<<endl;
  cout<<"\nNumber of interior vol. faces refined : "<<countIntrFaces<<endl;
  cout<<"\nNumber of non BL faces refined : "<<countNonBLFaces<<endl;
#endif

#ifdef AOMD_
#ifdef MA_PARALLEL
  /// ents_to_update already contains BL entities to update, if any
  /// update entity links across the boundary

  M_update_CB_Links(entities_to_update, ptr_reff);
  entities_to_update.clear();
  M_updateOwnership(pmesh);
#endif
#endif

  // *****************************************************************
  // 	      Region Refinement in BL
  // *****************************************************************
#ifdef DEBUG
  printf("Number of BL before adaptation: %d\n", M_numEntGrps(pmesh));
#endif

  int countBLRgns=0;
  pMeshDataId egTag = MD_lookupMeshDataId("EntityGroupTag");
  void *ptr;
  deque<pBLayer>::iterator blIter_rem;
  blIter = refBLFacesRegions.begin();
  while (blIter != refBLFacesRegions.end())
  {
    // Assuming the regions are in the order from bottom to top
    EntIter entBegIter = EG_beginEntity(*blIter);
    EntIter entEndIter = EG_endEntity(*blIter);
    EntIter entIter, entIter_rem;

    /// The order of the faces which are top faces of their correspondent BL at the current point
    pFace order_faces[4];

    entIter = entBegIter;
    region = *entIter;

    /// Find the zero-level face
//    face = R_face(region, 0);
    face = BL_GetZeroLvlFace(*blIter);
    bit = 0;
    for (int i = 0; i < 3; i++)
    {
      edge = F_edge(face, i);
      if(EN_getDataInt((pEntity)edge,int_reff,&value))
        bit++;
    }

    pBLayer* entGrps = new pBLayer[bit+1];
    for (int i = 0; i <= bit; i++)
      entGrps[i] = M_createEntGrp(pmesh, 3);

    /// Split the bottommost region, the produced ones will dictate which entity group the next ones in the stack belong to
    pPList newRegs = PList_new();

    ++entIter;
    EG_removeEntity(*blIter, region);

    R_refineBL(region, newRegs, 0, bit);
    countBLRgns++;

    /// Fill in the first regions of newly created BLs, and assign the top faces in the order_faces array
    for (int i = 0; i <= bit; i++)
    {
      region = (pRegion)PList_item(newRegs, i);
      for (int iFace = 0; iFace < R_numFaces(region); ++iFace)
      {
        face = R_face(region, iFace);
        if ((F_typeInBL(face) == fLAYER || F_typeInBL(face) == fTRANSITION) && F_whatInType(face) == 3)
        {
          order_faces[i] = face;
          break;
        }
      }
      EG_addEntity(entGrps[i], (pEntity)region);
    }
    PList_delete(newRegs);

//    for (; entIter != entEndIter; ++entIter)
    while (entIter != entEndIter)
    {
      region = *entIter;
      ++entIter;
      EG_removeEntity(*blIter, region);

      pPList newRegs = PList_new();
      R_refineBL(region, newRegs, 0, bit);
      countBLRgns++;

      /// ADD NEW REGIONS TO A NEWLY CREATED ENTITY GROUPS! 
      /// Decision process to insert the appropriate region into the EG it is supposed to be in
      /// Each stack has to remember its top face for the next refined regions to be put into correct BL
      int f_type;
      for (int i = 0; i <= bit; i++)
      {
        region = F_region(order_faces[i],0);
        if (!PList_inList(newRegs, region))
          region = F_region(order_faces[i],1);
        switch (region->getType())
        {
          case PRISM:
            face = R_face(region,4);
            if (face == order_faces[i])
              order_faces[i] = R_face(region,0);
            else
              order_faces[i] = face;
            break;
          case PYRAMID:
            for (int iFace = 1; iFace < 5; ++iFace)
            {
              face = R_face(region,iFace);
              f_type = F_typeInBL(face);
              if ((f_type == fTRANSITION || f_type == fLAYER) && face != order_faces[i])
              {
                order_faces[i] = face;
                break;
              }
            }
            break;
          case TET:
            for (int iFace = 0; iFace < 4; ++iFace)
            {
              face = R_face(region,iFace);
              f_type = F_typeInBL(face);
              if ((f_type == fTRANSITION || f_type == fLAYER) && face != order_faces[i])
              {
                order_faces[i] = face;
                break;
              }
            }
            break;
        }
        EG_addEntity(entGrps[i], (pEntity)region); 
      }
      PList_delete(newRegs);
    }

    /// Reverse classification of BL on regions and layer and transition faces
    for (int i = 0; i <= bit; i++)
    {
      BL_AssignBLLevelsToEnts(entGrps[i]);
    }

//    EG_clear(*blIter);
    delete [] entGrps;

    /// Delete BL
    blIter_rem = blIter;
    blIter++;
    M_removeEntGrp(pmesh, *blIter_rem);
  }

  MD_deleteMeshDataId(vertFacesTag);

  // *****************************************************************
  //          Region Refinement in Intr. Vol. Mesh
  //          (and ones sharing BL edge(s), i.e, interface elements)
  // *****************************************************************
/*
  deque<pRegion>::iterator intRegIter;
  for (intRegIter = refInterfaceRegions.begin(); intRegIter != refInterfaceRegions.end(); intRegIter++)
  {
    R_refine(*intRegIter,0,0);
    countInterfaceRgns++;
  }
*/
#ifdef DEBUG
  printf("Number of BL after adaptation: %d\n", M_numEntGrps(pmesh));
  cout<<"\nNumber of interface regions refined : "<<countInterfaceRgns<<endl;
#endif
/*
#ifdef DEBUG
  M_checkBLSplitFaces(pmesh);
#endif
*/

  // steiner verts. can exist due to some templates for intr. vol. mesh
  // do not take care of these verts.
  PList_clear(steinerVerts);
//   deleteSteiner();

}


// label the new entities created by split operation on layer edge
void meshTemplate::labelNewBLEntities4LayerOrTransitionEdgeSplit(pEdge edge)
{
  pPList plist;

  pVertex newV, oldV[2];
  pEdge newE[2];
  plist = get_split_edges(edge);
  newV = (pVertex)PList_item(plist,0);
  newE[0] = (pEdge)PList_item(plist,1);
  newE[1] = (pEdge)PList_item(plist,2);

  int eTypeInBL = E_typeInBL(edge);
  if(eTypeInBL==eLAYER || eTypeInBL==eTRANSITION) 
  {
    EN_attachDataInt((pEntity)newE[0],blEdgeTypeID,eTypeInBL);
    EN_attachDataInt((pEntity)newE[1],blEdgeTypeID,eTypeInBL);
  }

//  if (V_isOriginatingNode(E_vertex(edge,0)))
  if (EN_levelInBL(edge) == 0 || EN_remLevelInBL(edge) == 0)
    EN_attachDataInt(newV, blVertexTypeID, vORIGINATING);
  else
    EN_attachDataInt(newV, blVertexTypeID, vREGULAR);

  /// Interpolate first layer thickness height
  if (EN_levelInBL(edge) == 0)
  {
    double dVal, firstLayerThickness;
    pMeshDataId firstLayerThicknessID = MD_lookupMeshDataId("First Layer Thickness");
    oldV[0] = E_vertex(edge, 0);
    oldV[1] = E_vertex(edge, 1);

    if(EN_getDataDbl((pEntity)oldV[0], firstLayerThicknessID, &dVal))
    {
      firstLayerThickness = dVal;
      EN_getDataDbl((pEntity)oldV[1], firstLayerThicknessID, &dVal);
      firstLayerThickness += dVal;
      firstLayerThickness /= 2.;

      EN_attachDataDbl((pEntity)newV, firstLayerThicknessID, firstLayerThickness);
    }
  }
  
  if (EN_remLevelInBL(edge) > -1)
  {
    int iRemLvlBL = EN_remLevelInBL(edge);
    EN_attachDataInt(newV, remLayerNumberID, iRemLvlBL);
    EN_attachDataInt(newE[0], remLayerNumberID, iRemLvlBL);
    EN_attachDataInt(newE[1], remLayerNumberID, iRemLvlBL);    
  }        

/*
  if (V_whatInType(newV) < 3)
  {
    pMeshDataId notBLSnapID = MD_lookupMeshDataId("bl not snapped");
    EN_attachDataInt((pEntity)newV,notBLSnapID,1);
  }
*/
/*
  int level = EN_levelInBL((pEntity)edge);
  int surfTag = EN_blSurfaceTag((pEntity)edge);

  EN_labelBLEntity((pEntity)newV,level,surfTag);

  // for transition edge the BL type info. will be corrected later
  EN_labelBLEntity((pEntity)newE[0],level,surfTag,eLAYER);
  EN_labelBLEntity((pEntity)newE[1],level,surfTag,eLAYER);

  int eTypeInBL = E_typeInBL(edge);
  if(eTypeInBL==eLAYER) {
    if(level==0) {
      int totNumLayers[2];
      for(int iVert=0; iVert<2; iVert++)
        totNumLayers[iVert] = V_totNumLayers(E_vertex(edge,iVert));

      // split is propagated through the transition elements
      // hence new onode would have the maximum of the two number of layers
      int maxTotNumLayers = totNumLayers[0];
      if(totNumLayers[0]<totNumLayers[1])
        maxTotNumLayers = totNumLayers[1];
      V_setTotNumLayers(newV,maxTotNumLayers);
    }
  }
  else if(eTypeInBL==eTRANSITION) {
    E_correctTypeAndLevelInBL(newE[0]);
    E_correctTypeAndLevelInBL(newE[1]);
  }
  else {
    cout<<"\nError in labelNewBLEntities4LayerOrTransitionEdgeSplit()..."<<endl;
    cout<<"do NOT work for non-layer or non-transition edges as of now"<<endl;
    exit(0);
  }
*/
}

int meshTemplate::R_refineBL(pRegion region, pPList newRegs, pPList newEdges, int bit)
{
static int countPrism1 = 0, countPrism2 = 0, countPrism3 = 0;
static int countPyr1 = 0, countPyr2 = 0, countPyr3 = 0;
static int countTet1 = 0, countTet2 = 0, countTet3 = 0;

pMeshDataId prev_ref_temp = MD_lookupMeshDataId("PrevRefTemplate");

  int rtype = region->getType();
  switch(rtype)
  {
    case PRISM:
      switch (bit)
      {
        case 0 : break;
        case 1 : template_prism_1(region,newRegs,newEdges);
          break;
        case 2 : template_prism_2(region,newRegs,newEdges);
          break;
        case 3 : template_prism_3(region,newRegs,newEdges);
          break;
        default:
          cout<<"[Region Type: PRISM] refinement template "<<bit<<" undefined for bl prism"<<endl;
      }
      break;
    case PYRAMID:
      switch (bit) {
      case 0 : break;
      case 1 : template_pyramid_1(region,newRegs,newEdges);
        break;
      case 2 : template_pyramid_2(region,newRegs,newEdges);
        break;
      case 3 : template_pyramid_3(region,newRegs,newEdges);
        break;
      default:
        cout<<"\nError in R_refineBL()..."<<endl;
        cout<<"[refType:1] refinement template "<<bit<<" undefined for bl transition pyramid"<<endl;
      }
      break;
    case TET:
      switch (bit) {
      case 0 : break;
      case 1 : template_transition_tet_1(region,newRegs,newEdges);
        break;
      case 2 : template_transition_tet_2(region,newRegs,newEdges);
        break;
      case 3 : template_transition_tet_3(region,newRegs,newEdges);
        break;
      default:
        cout<<"\nError in R_refineBL()..."<<endl;
        cout<<"[refType:1] refinement template "<<bit<<" undefined for bl transition tet."<<endl;
      }
      break;
  }
}


/// Works in serial for now only!
void meshTemplate::Mesh_TetrahedralizePyramids(void)
{
  pFace pFaceFace;
  std::list<pRegion> ListPyrRgn;
  std::set<pFace> ListQuadFace;
  pRegion pRegionRgn, pRegionChdRgn[2];
  int iTetraRgn = 0;
  
  /// Tet-ze pyramids only which are outside of boundary layers
  FIter fit=M_faceIter(pmesh);
  while(pFaceFace = FIter_next(fit) )
  {
    if (pFaceFace->getType() != QUAD)
      continue;

    pRegion pRegionRgnChk[2] = {F_region(pFaceFace, 0), F_region(pFaceFace, 1)};

    if (pRegionRgnChk[0]->getType() != PYRAMID)
      continue;

    if ((pRegionRgnChk[1] && pRegionRgnChk[1]->getType() == PYRAMID) || !pRegionRgnChk[1])
    {
      if (EN_onCB(pFaceFace))
        ListQuadFace.insert(pFaceFace);
      else
      {
        get_tri_faces_of_quad(pFaceFace, 0, F_vertex(pFaceFace,0));
        ListPyrRgn.push_back(pRegionRgnChk[0]);
        if (pRegionRgnChk[1])
          ListPyrRgn.push_back(pRegionRgnChk[1]);
      }
    }
  }
  FIter_delete(fit);

  /// Synchronize those quad faces which have pyramids adjacent to them on both sides and split them
#ifdef MA_PARALLEL
  if (SCUTIL_CommSize() > 1)
  {
    IPComMan *CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int num_sent = 0, num_recvd = 0;
    CM->set_fixed_msg_size(sizeof(pFace));
    pFace* msg_send = (pFace*)CM->alloc_msg(sizeof(pFace));

    std::set<pFace>::iterator ListIt;
    for (ListIt = ListQuadFace.begin(); ListIt != ListQuadFace.end(); ++ListIt)
    {
      pFaceFace = *ListIt;
      std::vector<std::pair<int, pMeshEnt> > VecRemCpy;
      FMDB_Ent_GetAllRmt(pFaceFace, VecRemCpy);
      for (int iRC = 0; iRC < VecRemCpy.size(); ++iRC)
      {
        *msg_send = VecRemCpy[iRC].second;
        CM->send(VecRemCpy[iRC].first, (void*)msg_send);
      }
    }
    CM->free_msg(msg_send);
    CM->finalize_send();

    void* msg_recv;
    int pid_from;

    // recieve phase
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      pFaceFace = *(pFace*)msg_recv;
      if (ListQuadFace.count(pFaceFace))
      {
        get_tri_faces_of_quad(pFaceFace, 0, F_vertex(pFaceFace,0));
        ListPyrRgn.push_back(F_region(pFaceFace, 0));
      }
      CM->free_msg(msg_recv);
    }
  }
#endif

#ifdef AOMD_
#ifdef MA_PARALLEL
  // ents_to_update already contains BL entities to update, if any
  M_update_CB_Links(entities_to_update, ptr_reff);
  entities_to_update.clear();
  M_updateOwnership(pmesh);
#endif
#endif

  /// Split pyramids
  for (std::list<pRegion>::iterator ItListRgn = ListPyrRgn.begin(); ItListRgn != ListPyrRgn.end(); ++ItListRgn)
  {
    pRegionRgn = *ItListRgn;
    EN_unlabelBLEntAndDownAdjEnts(pRegionRgn);
    tetrahedronizePyramid(pRegionRgn, pRegionChdRgn);
    iTetraRgn++;
  }

#ifdef DEBUG
  if (iTetraRgn)
    printf("[%d]: Tetrahedralized %d pyramids\n", P_pid(), iTetraRgn);
#endif

  Mesh_AssignBLLevelsToAllBLEnts(pmesh);
#ifdef MA_PARALLEL
  Mesh_UnifyBLInterfaceOnCB(pmesh);
#endif
  Mesh_ClrHangingBLEntLvl(pmesh);
}


double cosAngleWedgeSkewTol = 0.9397;
double cosAngleWedgeWarpTol = 1./sqrt(2.);
double cosAngleStackSkewTol = 0.9397;
double cosAngleStackWarpTol = 1./sqrt(2.);

int checkWedgeForQuality(pRegion region);
int checkStackForQuality(pVertex *surfTriVerts, pVertex *topTriVerts);
int checkWedgeForQuality_XYZ(double *paramLimits, dArray *XYZ);



double GetBLFaceAspectRatio(pFace pFaceFace)
{
  double dMaxGrowthEdgeLen = 0., dMaxLayerEdgeLen = 0., dEdgeLength;
  pEdge pEdgeEdge;
  for (int iEdge = 0; iEdge < F_numEdges(pFaceFace); ++iEdge)
  {
    pEdgeEdge = F_edge(pFaceFace, iEdge);
    dEdgeLength = E_lengthSq(pEdgeEdge);
    if (E_typeInBL(pEdgeEdge) == eGROWTH)
    {
      if (dEdgeLength > dMaxGrowthEdgeLen)
        dMaxGrowthEdgeLen = dEdgeLength;
    }
    else
    {
      if (dEdgeLength > dMaxLayerEdgeLen)
        dMaxLayerEdgeLen = dEdgeLength;
    }
  }

  return dMaxGrowthEdgeLen / dMaxLayerEdgeLen;
}

int iCheckBLRgnAspectRatio(pRegion pRegionRgn, double dBLAspectRatioLimit)
{
  double dBLAspectRatio;
  pFace pFaceFace;
  /// Based on the aspect ratio of quad faces. If at least one quad face has lower AR, trim the region
  for (int iFace = 0; iFace < R_numFaces(pRegionRgn); ++iFace)
  {
    pFaceFace = R_face(pRegionRgn, iFace);
    if (pFaceFace->getType() != QUAD)
      continue;
    dBLAspectRatio = GetBLFaceAspectRatio(pFaceFace);
    /// If aspect ratio is 1./higher, tag the adjacent BLs by the number of the first level-1 needing tetrahedranization
    if (dBLAspectRatio > dBLAspectRatioLimit)
      return 1;
  }
  return 0;
}
//#ifdef MA_PARALLEL
//void meshTemplate::::Mesh_TetrahedronizeBLs_AspectRatio(pmMigrationCallbacks& userLB)
//#else
void meshTemplate::Mesh_TetrahedronizeBLs_AspectRatio(double dBLAspectRatioLimit)
//#endif
{
  pEdge pEdgeEdge;
  pFace pFaceFace;
  pRegion pRegionRgn;
  pBLayer pBLayerBL;
  std::vector<pFace> VecFaceStack;
  std::list<pFace> ListSplitQuadFace;
  std::list<pRegion> ListNonBLRgn;
  std::list<pBLayer> ListBL;

#ifdef MA_PARALLEL
  list<pEntity> entities_to_update;
#endif

//  double dBLAspectRatioCoeff = 0.64;//0.1055;//0.64;
  double dBLAspectRatio;
  int iTag;
  int iTetraRgn = 0;

  /// Get the stacks of vertical faces and find the first face having bigger aspect ratio than it's supposed to
  /// Then tag the rest of the quad faces to be split into tri-s.
  EIter eit = M_edgeIter(pmesh);
  while(pEdgeEdge = EIter_next(eit))
  {
    if (EN_levelInBL(pEdgeEdge) == 0)
    {
      int iFace, iNumFace;
      BL_getVerticalFacesByEdge(pEdgeEdge, VecFaceStack);
      iNumFace = VecFaceStack.size();
      for (iFace = 0; iFace < iNumFace; ++iFace)
      {
        pFaceFace = VecFaceStack[iFace];

        if (EN_getDataInt((pEntity)pFaceFace, int_reff, &iTag))
        {
          iFace = iNumFace;
          break;
        }

        dBLAspectRatio = GetBLFaceAspectRatio(pFaceFace);
        /// If aspect ratio is higher, tag the adjacent BLs by the number of the first level-1 needing tetrahedranization
        if (dBLAspectRatio > dBLAspectRatioLimit)
        {
          for (int iRgn = 0; iRgn < F_numRegions(pFaceFace); ++iRgn)
          {
            pRegionRgn = F_region(pFaceFace, iRgn);
            pBLayerBL = EN_getBL(pRegionRgn);
            if (pBLayerBL)
            {
              /// If BL was tagged already but this side starts the splitting process earlier, re-tag it
              if (EG_getDataInt(pBLayerBL, int_reff, &iTag))
              {
                if (iFace < iTag)
                {
                  EG_deleteData(pBLayerBL, int_reff);
                  EG_attachDataInt(pBLayerBL, int_reff, iFace);
                }
              }
              else
              {
                EG_attachDataInt(pBLayerBL, int_reff, iFace);
                ListBL.push_back(pBLayerBL);
              }
            }
          }
          break;
        }
      }
      /// This loop is only available if the face with higher aspect ratio is met
      for (; iFace < iNumFace; ++iFace)
      {
        pFaceFace = VecFaceStack[iFace];

        /// The face could be tagged by exploring other faces but higher than the current one
        if (EN_getDataInt((pEntity)pFaceFace, int_reff, &iTag))
          break;

        ListSplitQuadFace.push_back(pFaceFace);
        EN_attachDataInt((pEntity)pFaceFace, int_reff, 1);
      }
    }
  }
  EIter_delete(eit);


#ifdef AOMD_
#ifdef MA_PARALLEL
  M_unifyTaggedEntities(int_reff, &ListSplitQuadFace);
#endif
#endif

  /// Split quad faces into tri-s and get non-BL regions
  std::list<pFace>::iterator ListFaceIt;
  for(ListFaceIt = ListSplitQuadFace.begin(); ListFaceIt != ListSplitQuadFace.end(); ++ListFaceIt)
  {
    pFaceFace = *ListFaceIt;
/*
    for (int iEdge = 0; iEdge < 4; ++iEdge)
    {
      pEdgeEdge = F_edge(pFaceFace, iEdge);
      if (EN_levelInBL(pEdgeEdge) < EN_levelInBL(pFaceFace))
        break;
    }
//    get_tri_faces_of_quad(pFaceFace, pEdgeEdge, 0);
*/
    get_tri_faces_of_quad(pFaceFace, 0, F_vertex(pFaceFace,0));
    EN_deleteData((pEntity)pFaceFace, int_reff);

#ifdef MA_PARALLEL
    if (EN_onCB(pFaceFace))
      entities_to_update.push_back(pFaceFace);
#endif

    for (int iRgn = 0; iRgn < F_numRegions(pFaceFace); ++iRgn)
    {
      pRegionRgn = F_region(pFaceFace, iRgn);
      pBLayerBL = EN_getBL(pRegionRgn);
      if (!pBLayerBL)
      {
        ListNonBLRgn.push_back(pRegionRgn);
        EN_attachDataInt((pEntity)pRegionRgn, int_reff, 1);
      }
    }
  }

#ifdef AOMD_
#ifdef MA_PARALLEL
  // ents_to_update already contains BL entities to update, if any
  M_update_CB_Links(entities_to_update, ptr_reff);
  entities_to_update.clear();
  M_updateOwnership(pmesh);
#endif
#endif

  std::list<pRegion>::iterator ItListRgn;
  std::list<pBLayer>::iterator ItListBL;

  ListSplitQuadFace.clear();

  pRegion pRegionChdRgn[8];
  int  iTetReg[5] = {0, 0, 0, 0, 0};
  int iNumBLTrim = ListBL.size();
  /// split regions in BLs
  for (ItListBL = ListBL.begin(); ItListBL != ListBL.end(); ++ItListBL)
  {
    pBLayerBL = *ItListBL;
    EG_getDataInt(pBLayerBL, int_reff, &iTag);
    int iNumBL = 0, iNumTrimtFromLvl = iTag;
    pBLEntIter pBLEntIt;

    /// Skipping regions which don't need to be tet-d
    for (pBLEntIt= BL_GetBegEntIter(pBLayerBL); iNumBL < iTag; ++pBLEntIt, ++iNumBL);

    while (pBLEntIt != BL_GetEndEntIter(pBLayerBL))
    {
      pRegionRgn = *pBLEntIt;
      ++pBLEntIt;
      EG_removeEntity(pBLayerBL, pRegionRgn);
      EN_unlabelBLEntAndDownAdjEnts(pRegionRgn);

      int iTagFace;
      switch (pRegionRgn->getType())
      {
        case TET:
          break;
        case PYRAMID:
          tetrahedronizePyramid(pRegionRgn, pRegionChdRgn);
          break;
        case PRISM:
          iTagFace = 0;
          for (int iFace = 1; iFace < 4; ++iFace)
          {
            pFaceFace = R_face(pRegionRgn, iFace);
            if (check_is_face_split(pFaceFace))
            {
              iTagFace++;
            }
            else
            {
              ListSplitQuadFace.push_back(pFaceFace);
              EN_attachDataInt((pEntity)pFaceFace, int_reff, 1);
            }
          }
          int iRgn;
          switch(iTagFace)
          {
            case 1: tetrahedronizePyramidizeWedge_OneQuadFaceSplit(pRegionRgn, pRegionChdRgn); iTetReg[0]++; break;
            case 2: iRgn = tetrahedronizePyramidizeWedge(pRegionRgn, pRegionChdRgn);
              if (iRgn == 2)
                iTetReg[1]++;
              else
                iTetReg[2]++;
              break;
            case 3: iRgn = tetrahedronizeWedge(pRegionRgn, pRegionChdRgn);
              if (iRgn == 3)
                iTetReg[3]++;
              else
                iTetReg[4]++;
              break;
          }
          break;
        default:
          printf("Wrong entity to tetrahedronize!\n");
          break;
      }
      iTetraRgn++;
    }

    EG_deleteData(pBLayerBL, int_reff);
    if (iNumTrimtFromLvl == 1)
      M_removeEntGrp(pmesh, pBLayerBL);
  }

#ifdef AOMD_
#ifdef MA_PARALLEL
  M_unifyTaggedEntities(int_reff, &ListSplitQuadFace);
#endif
#endif


  /// Tet-ze pyramids only outside of boundary layers
  /// Should be moved upper in order to be able to unify links on the part boundary, or removed when we can deal with unstructured pyramids completely
  for(ListFaceIt = ListSplitQuadFace.begin(); ListFaceIt != ListSplitQuadFace.end(); ++ListFaceIt)
  {
    pFaceFace = *ListFaceIt;
    EN_deleteData((pEntity)pFaceFace, int_reff);
    pRegion pRegionRgnChk[2] = {F_region(pFaceFace, 0), F_region(pFaceFace, 1)};

#ifdef MA_PARALLEL
    if ((pRegionRgnChk[0]->getType() == PYRAMID && ((pRegionRgnChk[1] && pRegionRgnChk[1]->getType() == PYRAMID) || !pRegionRgnChk[1])) || EN_onCB(pFaceFace))
#else
    if (pRegionRgnChk[0]->getType() == PYRAMID && ((pRegionRgnChk[1] && pRegionRgnChk[1]->getType() == PYRAMID) || !pRegionRgnChk[1]))
#endif
    {
//      pEdgeEdge = F_edge(pFaceFace, 0);
//      get_tri_faces_of_quad(pFaceFace, pEdgeEdge, 0);
      get_tri_faces_of_quad(pFaceFace, 0, F_vertex(pFaceFace,0));

#ifdef MA_PARALLEL
    if (EN_onCB(pFaceFace))
    {
      entities_to_update.push_back(pFaceFace);

      pBLayerBL = EN_getBL(pRegionRgnChk[0]);
      if (pBLayerBL)
        EG_removeEntity(pBLayerBL, pRegionRgnChk[0]);
    }
#endif

      if (!EN_getDataInt((pEntity)pRegionRgnChk[0], int_reff, &iTag))
      {
        EN_attachDataInt((pEntity)pRegionRgnChk[0], int_reff, 1);
        ListNonBLRgn.push_back(pRegionRgnChk[0]);
      }
      if (pRegionRgnChk[1] && !EN_getDataInt((pEntity)pRegionRgnChk[1], int_reff, &iTag))
      {
        EN_attachDataInt((pEntity)pRegionRgnChk[1], int_reff, 1);
        ListNonBLRgn.push_back(pRegionRgnChk[1]);
      }
    }
  }


#ifdef AOMD_
#ifdef MA_PARALLEL
  // ents_to_update already contains BL entities to update, if any
  M_update_CB_Links(entities_to_update, ptr_reff);
  entities_to_update.clear();
  M_updateOwnership(pmesh);
#endif
#endif

  /// Split non BL regions
  for (ItListRgn = ListNonBLRgn.begin(); ItListRgn != ListNonBLRgn.end(); ++ItListRgn)
  {
    pRegionRgn = *ItListRgn;
    EN_deleteData((pEntity)pRegionRgn, int_reff);
    if (R_isBLEntity(pRegionRgn))
      EN_unlabelBLEntAndDownAdjEnts(pRegionRgn);

    int iTagFace;
    switch (pRegionRgn->getType())
    {
      case TET:
        break;
      case PYRAMID:
        tetrahedronizePyramid(pRegionRgn, pRegionChdRgn);
        break;
      case PRISM:
        iTagFace = 0;
        for (int iFace = 1; iFace < 4; ++iFace)
        {
          pFaceFace = R_face(pRegionRgn, iFace);
          if (check_is_face_split(pFaceFace))
            iTagFace++;
        }
        switch(iTagFace)
        {
          case 1: tetrahedronizePyramidizeWedge_OneQuadFaceSplit(pRegionRgn, pRegionChdRgn); break;
          case 2: tetrahedronizePyramidizeWedge(pRegionRgn, pRegionChdRgn); break;
          case 3: tetrahedronizeWedge(pRegionRgn, pRegionChdRgn); break;
        }
        break;
      default:
        printf("Wrong entity to tetrahedronize!\n");
        break;
    }
    iTetraRgn++;
  }

#ifdef DEBUG
  if (iTetraRgn)
  {
    printf("Tetrahedralized %d regions\n", iTetraRgn);
    for (int iTrim = 0; iTrim < 5; ++iTrim)
      printf("Trimming template %d was applied %d times\n", iTrim, iTetReg[iTrim]);
  }
#endif

  /// Collapses for pyramids and prisms must eb implemented
//  deleteSteiner();
  PList_clear(steinerVerts);
}


void meshTemplate::TagVerts(std::deque<pFace> &ListSplitQuadFace, std::deque<pVertex> &ListPrimaryVtx, std::deque<pVertex> &ListSecondaryVtx)
{
  pVertex pVertexVtx, pVertexOppVtx;
  pEdge pEdgeEdge, pEdgeOppEdge;
  pFace pFaceFace;
  int iTag, iTag2;
  int iLevel;
  void *vPtr;

  pMeshDataId tOnHold = MD_lookupMeshDataId("Edge on hold");
  pMeshDataId tVtxTag = MD_lookupMeshDataId("Vertex_prime_sec");
  pMeshDataId tFaceVtxTag = MD_lookupMeshDataId("Vertex to bisect from");

  for (int iFace = 0; iFace < ListSplitQuadFace.size(); ++iFace)
  {
    pFaceFace = ListSplitQuadFace[iFace];

    if (!EN_getDataInt((pEntity)pFaceFace, int_reff, &iTag))
      EN_attachDataInt((pEntity)pFaceFace, int_reff, 1);

    /// If face is still a BL face then the lower-level edge can be figured out through the level info
    /// Otherwise the edge was put on hold, use this info
    int iEdge = 0;
    if (F_typeInBL(pFaceFace))
    {
      iLevel = EN_levelInBL(pFaceFace);
      for (; iEdge < 4; ++iEdge)
      {
        pEdgeEdge = F_edge(pFaceFace, iEdge);
        if (EN_levelInBL(pEdgeEdge) < iLevel)
          break;
      }
    }
    else
    {
      if  (!EN_getDataPtr((pEntity)pFaceFace, tOnHold, &vPtr))
        iEdge = 4;
      else
        pEdgeEdge = (pEdge)vPtr;
    }
    if (iEdge == 4)
    {
      printf("Error: the lower-level edge was not found\n");
      exit(0);
    }

    /// Decide which vertex should be tagged as primary = originating for diagonal bisections, or secondary = not originating
    for (int iVert = 0; iVert < 2; ++iVert)
    {
      pVertexVtx = E_vertex(pEdgeEdge, iVert);
      if (EN_getDataInt((pEntity)pVertexVtx, tVtxTag, &iTag))
      {
        if(iTag == 1)
        {
          pVertexOppVtx = E_otherVertex(pEdgeEdge, pVertexVtx);
          if (!EN_getDataInt((pEntity)pVertexOppVtx, tVtxTag, &iTag))
          {
            EN_attachDataInt((pEntity)pVertexOppVtx, tVtxTag, 2);
            ListSecondaryVtx.push_back(pVertexOppVtx);
          }
          break;
        }
        else
          continue;
      }

      /// Look for the verts tagged around
      for (iEdge = 0; iEdge < V_numEdges(pVertexVtx); ++iEdge)
      {
        pEdgeOppEdge = V_edge(pVertexVtx, iEdge);
        pVertexOppVtx = E_otherVertex(pEdgeOppEdge, pVertexVtx);
        if (EN_getDataInt((pEntity)pVertexOppVtx, tVtxTag, &iTag) && iTag == 1)
        {
          if (!EN_getDataInt((pEntity)pVertexVtx, tVtxTag, &iTag))
          {
            EN_attachDataInt((pEntity)pVertexVtx, tVtxTag, 2);
            ListSecondaryVtx.push_back(pVertexVtx);
          }
          break;
        }
      }

      /// If no vertex is tagged as primary around, tag current vertex. If vertex is tagged as primary, make sure neighboring vertex is tagged
      if (!EN_getDataInt((pEntity)pVertexVtx, tVtxTag, &iTag))
      {
        EN_attachDataInt((pEntity)pVertexVtx, tVtxTag, 1);
        ListPrimaryVtx.push_back(pVertexVtx);

        pVertexOppVtx = E_otherVertex(pEdgeEdge, pVertexVtx);
        if (!EN_getDataInt((pEntity)pVertexOppVtx, tVtxTag, &iTag))
        {
          EN_attachDataInt((pEntity)pVertexOppVtx, tVtxTag, 2);
          ListSecondaryVtx.push_back(pVertexOppVtx);
        }
        break;
      }
    }

    pVertexOppVtx = E_otherVertex(pEdgeEdge, pVertexVtx);

    /// If both vertices are tagged as secondary, save for later consideration
    if (EN_getDataInt((pEntity)pVertexVtx, tVtxTag, &iTag) && EN_getDataInt((pEntity)pVertexOppVtx, tVtxTag, &iTag2))
    {
      if (iTag == 2 && iTag2 == 2)
      {
        if (!EN_getDataPtr((pEntity)pFaceFace, tOnHold, &vPtr))
          EN_attachDataPtr((pEntity)pFaceFace, tOnHold, (void*)pEdgeEdge);
      }
      else
      {
        if (iTag == 1)
          EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtx);
        else
          EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexOppVtx);
        if (EN_getDataPtr((pEntity)pFaceFace, tOnHold, &vPtr))
          EN_deleteData((pEntity)pFaceFace, tOnHold);
      }
    }
  }
}


void meshTemplate::ResolveConflictingFaces(std::deque<pFace> &ListSplitQuadFace)
{
  pVertex pVertexVtx[2], pVertexOppVtx[2];
  pEdge pEdgeEdge;
  pFace pFaceFace, pFaceAdjFace, pFaceOppFace[4];
  pRegion pRegionRgn[2];

  void *vPtr;
  int iTag, iNumAdjPrism;

  pMeshDataId tOnHold = MD_lookupMeshDataId("Edge on hold");
  pMeshDataId tVtxTag = MD_lookupMeshDataId("Vertex_prime_sec");
  pMeshDataId tFaceVtxTag = MD_lookupMeshDataId("Vertex to bisect from");

  /// Consider the face with the edge on hold attached since it's a conflicting one
  for (int iFaceIt = 0; iFaceIt < ListSplitQuadFace.size(); ++iFaceIt)
  {
    pFaceFace = ListSplitQuadFace[iFaceIt];

    if (!EN_getDataPtr((pEntity)pFaceFace, tOnHold, &vPtr))
      continue;

    pEdgeEdge = (pEdge)vPtr;
    iNumAdjPrism = 0;

    pVertexVtx[0] = E_vertex(pEdgeEdge, 0);
    pVertexVtx[1] = E_vertex(pEdgeEdge, 1);

    for (int iFace = 0; iFace < 4; ++iFace)
      pFaceOppFace[iFace] = 0;

    /// Find adjacent region(s) to a face, regions' quad faces to check and vertices opposite to the edge
    for (int iRgn = 0; iRgn < F_numRegions(pFaceFace); ++iRgn)
    {
      pRegionRgn[iRgn] = F_region(pFaceFace, iRgn);
      if (pRegionRgn[iRgn]->getType() == PYRAMID)
        continue;
    
      int iNumFace = 0; 
      pRegionRgn[iNumAdjPrism] = pRegionRgn[iRgn]; 
      for (int iFace = 0; iFace < 5; ++iFace)
      {
        pFaceAdjFace = R_face(pRegionRgn[iNumAdjPrism], iFace);
        if (pFaceAdjFace == pFaceFace)
          continue;
        if (pFaceAdjFace->getType() == QUAD)
        {
          pFaceOppFace[iNumAdjPrism*2 + iNumFace] = pFaceAdjFace;
          iNumFace++;
        }
        else
        {
          if (!F_inClosure(pFaceAdjFace, pEdgeEdge))
            continue;
          for (int iVtx = 0; iVtx < 3; ++iVtx)
          {
            pVertexOppVtx[iNumAdjPrism] = F_vertex(pFaceAdjFace, iVtx);
            if (pVertexOppVtx[iNumAdjPrism] != pVertexVtx[0] && pVertexOppVtx[iNumAdjPrism] != pVertexVtx[1])
              break; 
          }        
        }
      }
      iNumAdjPrism++;
    }

    /// Check if all opposite vertices are primary
    int iContinue;
    for (int iVtx = 0; iVtx < iNumAdjPrism; ++iVtx)
    {
      iContinue = 0;
      if (!EN_getDataInt((pEntity)pVertexOppVtx[iVtx], tVtxTag, &iTag))
        break;
      if (iTag != 1)
        break;
      iContinue = 1;
    }
    if (!iContinue)
    {
      EN_deleteData((pEntity)pFaceFace, int_reff);
      continue;
    }

    /// Otherwise the confusion will be solved
    EN_deleteData((pEntity)pFaceFace, tOnHold);
    
    /// If 2 adjacent regions are pyramids, use any vertex to bisect the face
    if (iNumAdjPrism == 0)
    {
      EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtx[0]);
      continue;
    }

    /// If only 1 prism is adjasent, check for how many quad faces are tagged for bisection
    if (iNumAdjPrism == 1)
    {
      int iNumTaggedFace = 0;
      for (int iFace = 0; iFace < 2; ++iFace)
      {
        if (EN_getDataInt((pEntity)pFaceOppFace[iFace], int_reff, &iTag))
        {
          pFaceAdjFace = pFaceOppFace[iFace];
          iNumTaggedFace++;
        }
      }
      /// If 2 quad faces are bisected, get any vertex for bisecting the current face
      if (iNumTaggedFace == 2)
      {
        EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtx[0]);
        continue;
      }

      /// If 0 faces are tagged for bisection, tag 1 of them
      if (iNumTaggedFace == 0)
      {
        pFaceAdjFace = pFaceOppFace[0];
        ListSplitQuadFace.push_back(pFaceAdjFace);
        EN_attachDataInt((pEntity)pFaceAdjFace, int_reff, 1);
        EN_attachDataPtr((pEntity)pFaceAdjFace, tFaceVtxTag, (void*)pVertexOppVtx[0]);
        if (EN_getDataPtr((pEntity)pFaceAdjFace, tOnHold, &vPtr))
          EN_deleteData((pEntity)pFaceAdjFace, tOnHold);
      }

      /// Use the vertex such that the diagonals share a common vertex. It should be a vertex not in closure of the face being bisected.
      for (int iVtx = 0; iVtx < 2; ++iVtx)
      {
        if (!F_inClosure(pFaceAdjFace, pVertexVtx[iVtx]))
        {
          EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtx[iVtx]);
          break;
        }
      }
    }
    else
    {
      int iNumTaggedFace[2] = {0, 0};
      pFace pFaceTaggedFace[2];
      for (int iRgn = 0; iRgn < 2; ++iRgn)
      {
        for (int iFace = 0; iFace < 2; ++iFace)
        {
          if (EN_getDataInt((pEntity)pFaceOppFace[iRgn*2 + iFace], int_reff, &iTag))
          {
            pFaceTaggedFace[iRgn] = pFaceOppFace[iRgn*2 + iFace];
            iNumTaggedFace[iRgn]++;
          }
        }
      }

      int iBit = 10*iNumTaggedFace[0] + iNumTaggedFace[1];
      switch(iBit)
      {
        case 0:
          /// Tag two additional faces sharing the same vertex
          EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtx[0]);
          for (int iRgn = 0; iRgn < 2; ++iRgn)
          {
            for (int iFace = 0; iFace < 2; ++iFace)
            {
              pFaceAdjFace = pFaceOppFace[iRgn*2 + iFace];
              if (F_inClosure(pFaceAdjFace, pVertexVtx[1]))
              {
                ListSplitQuadFace.push_back(pFaceAdjFace);
                EN_attachDataInt((pEntity)pFaceAdjFace, int_reff, 1);
                EN_attachDataPtr((pEntity)pFaceAdjFace, tFaceVtxTag, (void*)pVertexOppVtx[iRgn]);
                if (EN_getDataPtr((pEntity)pFaceAdjFace, tOnHold, &vPtr))
                  EN_deleteData((pEntity)pFaceAdjFace, tOnHold);
                break;
              }
            }
          }
          break;

        case 1:
        case 2:
        case 10:
        case 20:
          {
            /// Tag additionally one face sharing the same vertex with the tagged face(s)
            int iInd = 0;
            if (iNumTaggedFace[1])
              iInd = 1;

            pFaceAdjFace = pFaceTaggedFace[iInd];
	    pVertex pVertexVtxChk = pVertexVtx[0];
            if (!F_inClosure(pFaceAdjFace, pVertexVtxChk))
              pVertexVtxChk = pVertexVtx[1];

            /// Choose the face which has vertex in closure
            int iFaceInd = ((iInd+1)%2)*2;
            pFaceAdjFace = pFaceOppFace[iFaceInd];
            if (!F_inClosure(pFaceAdjFace, pVertexVtxChk))
              pFaceAdjFace = pFaceOppFace[iFaceInd + 1];

            if (pVertexVtxChk == pVertexVtx[1])
              pVertexVtxChk == pVertexVtx[0];

            ListSplitQuadFace.push_back(pFaceAdjFace);
            EN_attachDataInt((pEntity)pFaceAdjFace, int_reff, 1);
            EN_attachDataPtr((pEntity)pFaceAdjFace, tFaceVtxTag, (void*)pVertexOppVtx[(iInd+1)%2]);
            EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtxChk);
            if (EN_getDataPtr((pEntity)pFaceAdjFace, tOnHold, &vPtr))
              EN_deleteData((pEntity)pFaceAdjFace, tOnHold);
          }
          break;  

        case 11:
          {
            /// If 3 faces share the same vertex, use the opposite one, otherwise tag one more face
            pVertex pVertexVtxChk = 0;
            for (int iFace = 0; iFace < 2; ++iFace)
            {
              if (F_inClosure(pFaceTaggedFace[0], pVertexVtx[iFace]) && F_inClosure(pFaceTaggedFace[1], pVertexVtx[iFace]))
              {
                pVertexVtxChk = pVertexVtx[(iFace+1)%2];
                break;
              }
            }
            if (!pVertexVtxChk)
            {
              pFaceAdjFace = pFaceOppFace[0]; 
              if (pFaceAdjFace == pFaceTaggedFace[0])
                pFaceAdjFace = pFaceOppFace[1];

              ListSplitQuadFace.push_back(pFaceAdjFace);
              EN_attachDataInt((pEntity)pFaceAdjFace, int_reff, 1);
              EN_attachDataPtr((pEntity)pFaceAdjFace, tFaceVtxTag, (void*)pVertexOppVtx[0]);
              if (EN_getDataPtr((pEntity)pFaceAdjFace, tOnHold, &vPtr))
                EN_deleteData((pEntity)pFaceAdjFace, tOnHold);

              pVertexVtxChk = pVertexVtx[0];
              if (F_inClosure(pFaceAdjFace, pVertexVtxChk))
                pVertexVtxChk = pVertexVtx[1];

            }
            EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtxChk);
          }
          break;

        case 12:
        case 21:
          {
            /// Use vertex which does not share 3 tagged faces
            int iInd = 0;
            if (iNumTaggedFace[1] == 1)
              iInd = 1;

            pFaceAdjFace = pFaceTaggedFace[iInd];
            pVertex pVertexVtxChk = pVertexVtx[0];
            if (F_inClosure(pFaceAdjFace, pVertexVtxChk))
              pVertexVtxChk = pVertexVtx[1];

            EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtxChk);
          }
          break;

        case 22:
          {
            /// Use any vertex
            EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtx[0]);
          }
          break;
      }
    }
  }
}


void meshTemplate::TagAdditionalFaces(std::deque<pFace> &ListSplitQuadFace, std::deque<pVertex> &ListPrimaryVtx)
{
  pVertex pVertexVtx;
  pFace pFaceFace;
  pRegion pRegionRgn;  
  vector<pRegion> VecRgn;

  int iLevel, iTag, iNoTagFace, iCountQuadFaceBisect;

  pMeshDataId tVtxTag = MD_lookupMeshDataId("Vertex_prime_sec");
  pMeshDataId tFaceVtxTag = MD_lookupMeshDataId("Vertex to bisect from");

  for (int iVtx = 0; iVtx < ListPrimaryVtx.size(); ++iVtx)
  {
    pVertexVtx = ListPrimaryVtx[iVtx];
    EN_deleteData(pVertexVtx, tVtxTag);

    iLevel = EN_levelInBL(pVertexVtx);

    /// If no prisms are left around the vertex, no additional tagging is needed since everything what is left are pyramids
    if (iLevel < 0)
      continue;
    V_BLRegions(pVertexVtx, iLevel+1, VecRgn);

    for (int iRgn = 0; iRgn < VecRgn.size(); ++iRgn)
    {
      pFace pFaceNoTag[3] = {0, 0, 0};
      pRegionRgn = VecRgn[iRgn];
      iCountQuadFaceBisect = 0;
      iNoTagFace = 0;
      for (int iFace = 1; iFace < 4; ++iFace)
      {
        pFaceFace = R_face(pRegionRgn, iFace);
/*
        if (F_inClosure(pFaceFace, pVertexVtx) && !EN_getDataInt((pEntity)pFaceFace, int_reff, &iTag))
        {
          ListSplitQuadFace.push_back(pFaceFace);
          EN_attachDataInt((pEntity)pFaceFace, int_reff, 1);      
          EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtx);
        }
      }
*/

        if (EN_getDataInt((pEntity)pFaceFace, int_reff, &iTag))
          iCountQuadFaceBisect++;
        else
        {
          pFaceNoTag[iNoTagFace] = pFaceFace;
          iNoTagFace++;
        }
      }
 
      /// If one quad face is tagged, tag the one which has vertex in closure
      if (iCountQuadFaceBisect == 1)
      {
        for (int iFace = 0; iFace < iNoTagFace; ++iFace)
        {
          pFaceFace = pFaceNoTag[iFace];
          if (F_inClosure(pFaceFace, pVertexVtx))
          {
            ListSplitQuadFace.push_back(pFaceFace);
            EN_attachDataInt((pEntity)pFaceFace, int_reff, 1);      
            EN_attachDataPtr((pEntity)pFaceFace, tFaceVtxTag, (void*)pVertexVtx);
          }
        }
      }

    }
  }

  ListPrimaryVtx.clear();
}


void meshTemplate::TagFacesOnHangingPrisms(std::deque<pFace> &ListSplitQuadFace)
{
  pEdge pEdgeEdge, pEdgeUpEdge, pEdgeBotEdge, pEdgeUpEdges[3];
  pFace pFaceFace;
  pMeshDataId procTag = MD_lookupMeshDataId("ProcessedBLEdgeTag");
  pMeshDataId tOnHold = MD_lookupMeshDataId("Edge on hold");
  deque<pEdge> procEdges;
  int iVal;
  void *vPtr;
  pRegion pRegionRgn;
  pBLayer pBLayerBL;

  /// Loop over entity groups
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    pBLayerBL = (pBLayer)(*egIt);
    pBLEntIter entBegIter = BL_GetBegEntIter(pBLayerBL);
    pBLEntIter entEndIter = BL_GetEndEntIter(pBLayerBL);
    pBLEntIter entIter = entBegIter;

    int iLvl = 1;
    for (; entIter != entEndIter; ++entIter, ++iLvl)
    {
      pRegionRgn = *entIter;
      if (EN_levelInBL(pRegionRgn) != iLvl)
        break;
    }

    if (entIter == entEndIter)
      continue;

    /// Loop over quad faces to see which of them should be bisected
    int iNumUpEdge = 0;
    int iLevel = EN_levelInBL(pRegionRgn);
    for (int iFace = 1; iFace < 4; ++iFace)
    {
      pFaceFace = R_face(pRegionRgn, iFace);
      for (int iEdge = 0; iEdge < 4; ++iEdge)
      {
        pEdgeEdge = F_edge(pFaceFace, iEdge);
        if (E_typeInBL(pEdgeEdge) == eLAYER)
        {
          if (EN_levelInBL(pEdgeEdge) < iLevel)
            pEdgeBotEdge = pEdgeEdge;
          else
            pEdgeUpEdge = pEdgeEdge;
        }
      }

      int iCountQuadFace = 0;
      pFace pFaceFaceChk;
      for (int iFaceIt = 0; iFaceIt < E_numFaces(pEdgeBotEdge); ++iFaceIt)
      {
        pFaceFaceChk = E_face(pEdgeBotEdge, iFaceIt);
        if (pFaceFaceChk->getType() == QUAD)
          iCountQuadFace++;
      }  
      if (iCountQuadFace == 2)
        continue;

      pEdgeUpEdges[iNumUpEdge] = pEdgeUpEdge;
      iNumUpEdge++;
      if (!EN_getDataPtr((pEntity)pFaceFace, tOnHold, &vPtr) && !EN_getDataInt((pEntity)pFaceFace, int_reff, &iVal))
      {
        EN_attachDataPtr((pEntity)pFaceFace, tOnHold, (void*)pEdgeBotEdge);
        ListSplitQuadFace.push_back(pFaceFace);
      }
    }

    /// Apply bisection to all the quad faces in the following prisms, if any
    entIter++;
    for (; entIter != entEndIter; ++entIter)
    {
      pRegionRgn = *entIter;
      for (int iFace = 1; iFace < 4; ++iFace)
      {
        pFaceFace = R_face(pRegionRgn, iFace);
        for (int iEdge = 0; iEdge < iNumUpEdge; ++iEdge)
        {
          pEdgeEdge = pEdgeUpEdges[iEdge];
          if (F_inClosure(pFaceFace, pEdgeEdge))
          {
            if (!EN_getDataPtr((pEntity)pFaceFace, tOnHold, &vPtr) && !EN_getDataInt((pEntity)pFaceFace, int_reff, &iVal))
            {
              EN_attachDataPtr((pEntity)pFaceFace, tOnHold, (void*)pEdgeEdge);
              ListSplitQuadFace.push_back(pFaceFace);
            }
            /// Find the next edge to compare with
            for (int iEdgeIt = 0; iEdgeIt < 4; ++iEdgeIt)
            {
              pEdgeEdge = F_edge(pFaceFace, iEdgeIt);
              if (E_typeInBL(pEdgeEdge) == eLAYER && pEdgeEdge != pEdgeUpEdges[iEdge])
              {
                pEdgeUpEdges[iEdge] = pEdgeEdge;
              }
              break;
            }
            break;
          }
        }
      }
    }

  }
}


void meshTemplate::Mesh_AdaptiveTrimming_AspectRatio(double dBLAspectRatioLimit)
{
  pVertex pVertexVtx;
  pEdge pEdgeEdge;
  pFace pFaceFace;
  pRegion pRegionRgn;
  pBLayer pBLayerBL;
  std::vector<pFace> VecFaceStack;
  std::deque<pFace> ListSplitQuadFace;

  double dBLAspectRatio;
  int iTag;
  int iTetraRgn = 0;
  pRegion pRegionChdRgn[8];
  int  iTetReg[5] = {0, 0, 0, 0, 0};

  /// Get the stacks of vertical faces and find the first face having bigger aspect ratio than it's supposed to
  /// Then tag the rest of the quad faces to be split into tri-s. This gives the list of initial quad faces to be bisected
  EIter eit = M_edgeIter(pmesh);
  while(pEdgeEdge = EIter_next(eit))
  {
    if (EN_levelInBL(pEdgeEdge) == 0)
    {
      int iFace, iNumFace;
      BL_getVerticalFacesByEdge(pEdgeEdge, VecFaceStack);
      iNumFace = VecFaceStack.size();
      for (iFace = 0; iFace < iNumFace; ++iFace)
      {
        pFaceFace = VecFaceStack[iFace];

        if (EN_getDataInt((pEntity)pFaceFace, int_reff, &iTag))
          break;

        dBLAspectRatio = GetBLFaceAspectRatio(pFaceFace);
        /// If aspect ratio is higher, tag the adjacent BLs by the number of the first level-1 needing tetrahedranization
        if (dBLAspectRatio > dBLAspectRatioLimit)
        {
          ListSplitQuadFace.push_back(pFaceFace);
          EN_attachDataInt((pEntity)pFaceFace, int_reff, 1);
        }
      }
    }
  }
  EIter_delete(eit);

  if (!ListSplitQuadFace.size())
    return;

  pMeshDataId tOnHold = MD_newMeshDataId("Edge on hold");
  pMeshDataId tVtxTag = MD_newMeshDataId("Vertex_prime_sec");
  pMeshDataId tFaceVtxTag = MD_newMeshDataId("Vertex to bisect from");

  std::deque<pVertex> ListPrimaryVtx;
  std::deque<pVertex> ListSecondaryVtx;

  void *vPtr;
  int iCount = 0;
  int iFaceInitCount, iFaceVtxTagCount, iFaceResCount, iFaceAddCount, iFaceUniAddCount;
  while (ListSplitQuadFace.size())
  {
    iFaceInitCount = ListSplitQuadFace.size();

    TagVerts(ListSplitQuadFace, ListPrimaryVtx, ListSecondaryVtx);
    iFaceVtxTagCount = ListSplitQuadFace.size();

//    TagAdditionalFaces(ListSplitQuadFace, ListPrimaryVtx);
//    iFaceAddCount = ListSplitQuadFace.size();

    ResolveConflictingFaces(ListSplitQuadFace);
    iFaceResCount = ListSplitQuadFace.size();

    TagAdditionalFaces(ListSplitQuadFace, ListPrimaryVtx);
    iFaceAddCount = ListSplitQuadFace.size();

    for (int iVtx = 0; iVtx < ListSecondaryVtx.size(); ++iVtx)
    {
      EN_deleteData((pEntity)ListSecondaryVtx[iVtx], tVtxTag);
    }
    ListSecondaryVtx.clear();

    /// Bisect faces and trim regions
    std::deque<pRegion> ListRgn;
    std::deque<pFace>::iterator ItListFace = ListSplitQuadFace.begin(), ItListRemFace;
    int iFaceCount = -1;
    std::deque<pFace> ListFaceNextIter;
    for (int iFace = 0; iFace < ListSplitQuadFace.size(); ++iFace)
    {
      pFaceFace = ListSplitQuadFace[iFace];
      iFaceCount++;

      if (!EN_getDataInt((pEntity)pFaceFace, int_reff, &iTag))
      {
        ListFaceNextIter.push_back(pFaceFace);
        continue;
      }

      if (!EN_getDataPtr((pEntity)pFaceFace, tFaceVtxTag, &vPtr))
      {
        printf("Error: No vertex attached to a face to split from\n");
        exit(0);
      }
      else
      {
        pVertexVtx = (pVertex)vPtr;
        EN_deleteData((pEntity)pFaceFace, tFaceVtxTag);
      }

      /// Get the adjacent regions
      for (int iRgn = 0; iRgn < F_numRegions(pFaceFace); ++iRgn)
      {
        pRegionRgn = F_region(pFaceFace, iRgn);
        if (!EN_getDataInt((pEntity)pRegionRgn, int_reff, &iTag))
        {
          EN_attachDataInt((pEntity)pRegionRgn, int_reff, 1);
          ListRgn.push_back(pRegionRgn);
        }
      }

      get_tri_faces_of_quad(pFaceFace, 0, pVertexVtx);
      EN_deleteData((pEntity)pFaceFace, int_reff);
     
    }

    ListSplitQuadFace.clear();
    for (int iFace = 0; iFace < ListFaceNextIter.size(); ++iFace)
    {
      pFaceFace = ListFaceNextIter[iFace];
      ListSplitQuadFace.push_back(pFaceFace);
    }
    ListFaceNextIter.clear();

    std::deque<pBLayer> ListBLDel;
    for (int iRgn = 0; iRgn < ListRgn.size(); ++iRgn)
    {
      pRegionRgn = ListRgn[iRgn];
      EN_deleteData((pEntity)pRegionRgn, int_reff);

      pBLayerBL = 0;
      pBLayerBL = EN_getBL(pRegionRgn);
      if (pBLayerBL)
      {
        if (EN_levelInBL(pRegionRgn) == 0)
          ListBLDel.push_back(pBLayerBL);
        EG_removeEntity(pBLayerBL, pRegionRgn);
        EN_unlabelBLEntAndDownAdjEnts(pRegionRgn);
      }

      int iTagFace;
      switch (pRegionRgn->getType())
      {
        case TET:
          break;
        case PYRAMID:
          tetrahedronizePyramid(pRegionRgn, pRegionChdRgn);
          break;
        case PRISM:
          iTagFace = 0;
          for (int iFace = 1; iFace < 4; ++iFace)
          {
            pFaceFace = R_face(pRegionRgn, iFace);
            if (check_is_face_split(pFaceFace))
              iTagFace++;
          }
          int iRgn;
          switch(iTagFace)
          {
            case 1: tetrahedronizePyramidizeWedge_OneQuadFaceSplit(pRegionRgn, pRegionChdRgn); iRgn = 6; iTetReg[0]++; break;
            case 2: iRgn = tetrahedronizePyramidizeWedge(pRegionRgn, pRegionChdRgn);
              if (iRgn == 2)
                iTetReg[1]++;
              else
                iTetReg[2]++;
              break;
            case 3: iRgn = tetrahedronizeWedge(pRegionRgn, pRegionChdRgn);
              if (iRgn == 3)
                iTetReg[3]++;
              else
                iTetReg[4]++;
              break;
          }
          break;
        default:
          printf("Wrong entity to tetrahedronize!\n");
          break;
      }
      iTetraRgn++;
    }
    ListRgn.clear();

    /// Remove empty BLs
    for (int iBL = 0; iBL < ListBLDel.size(); ++iBL)
    {
      pBLayerBL = ListBLDel[iBL];
      M_removeEntGrp(pmesh, pBLayerBL);
    }
    ListBLDel.clear();

    TagFacesOnHangingPrisms(ListSplitQuadFace);

    iCount++;
  }

  MD_deleteMeshDataId(tOnHold);
  MD_deleteMeshDataId(tVtxTag);
  MD_deleteMeshDataId(tFaceVtxTag);

#ifdef DEBUG
  printf("Tetrahedronized %d regions\n", iTetraRgn);
  for (int iTrim = 0; iTrim < 5; ++iTrim)
  {
    if (iTetReg[iTrim])
      printf("Trimming template %d was applied %d times\n", iTrim, iTetReg[iTrim]);
  }
#endif
}


void meshTemplate::Mesh_AdaptiveDecompBL(double dBLAspectRatioLimit)
{
  pMeshDataId wedge_stack_id = MD_newMeshDataId("sizeOfWedgeStack");
  pMeshDataId bl_vtx_ptr_id = MD_newMeshDataId("startVtxForQuadFace");

  std::set<pVertex> curTrimBLSurfVerts, nextTrimBLSurfVerts, allTrimBLSurfVerts;
  std::deque<pFace> triangulateQuadFaces;
  std::set<pRegion> trimRgns;

  int reffTag;
  int trimRegionForQuality, trimStackForQuality;
  int wedgeStackSize, stackSizeTag;

  pVertex vertex, surfVert, surfTriVerts[3], topTriVerts[3];
  pEdge edge;
  pFace face, surfFace, curFace;
  pRegion region, pRegionRgn;
  pBLayer pBLayerBL;

  /// Traverse initial all BL prismatic stacks
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    pBLayerBL = (pBLayer)(*egIt);

    surfFace = BL_GetZeroLvlFace(pBLayerBL);
    for (int iVtx = 0; iVtx < 3; ++iVtx)
      surfTriVerts[iVtx] = F_vertex(surfFace, iVtx);
    
    // Traversing BL regions and trying to find those to trim
    EntIter entBegIter = EG_beginEntity(pBLayerBL);
    EntIter entEndIter = EG_endEntity(pBLayerBL);
    EntIter entIter, entIter_rem;

    trimRegionForQuality = 0;
    trimStackForQuality = 0;

    wedgeStackSize = 0;
    for (entIter = entBegIter; entIter != entEndIter; ++entIter)
    {
      pRegionRgn = *entIter;
      if((dBLAspectRatioLimit == 0. && checkWedgeForQuality(pRegionRgn)) || (dBLAspectRatioLimit > 0. && iCheckBLRgnAspectRatio(pRegionRgn, dBLAspectRatioLimit))) 
      {
        // if found a region requiring trim then trim all upper regions in stack
        trimRegionForQuality = 1;
        break;
      }

      wedgeStackSize++;      
    }

    pFace pFaceCurTopFace = R_face(pRegionRgn, 0);
    if (EN_levelInBL(pFaceCurTopFace) < EN_levelInBL(pRegionRgn))
      pFaceCurTopFace = R_face(pRegionRgn, 4);

    // top verts. are that of either full or partial stack of wedges
    for(int iVert=0; iVert<3; iVert++) // must be a triangle
      topTriVerts[iVert] = F_vertex(pFaceCurTopFace, iVert);

    EN_attachDataInt((pEntity)surfFace,wedge_stack_id,wedgeStackSize);

    for(int iVert=0; iVert<3; iVert++) 
    {
      surfVert = F_vertex(surfFace, iVert);
      if(trimRegionForQuality)
        allTrimBLSurfVerts.insert(surfVert); 
      if(EN_getDataInt((pEntity)surfVert,wedge_stack_id,&stackSizeTag)) 
      {
        if(stackSizeTag>wedgeStackSize)
          EN_modifyDataInt((pEntity)surfVert,wedge_stack_id,wedgeStackSize);
      }
      else 
      {
        // collect all zero level layer verts
        curTrimBLSurfVerts.insert(surfVert);
        EN_attachDataInt((pEntity)surfVert,wedge_stack_id,wedgeStackSize);
      }
    }

    if(wedgeStackSize<=1)
      continue;

    // check for quality of full or partial stack of wedges
    if(dBLAspectRatioLimit == 0. && checkStackForQuality(surfTriVerts,topTriVerts)) 
    {
      trimStackForQuality = 1;
      for(int iVert=0; iVert<3; iVert++) 
      {
        surfVert = surfTriVerts[iVert];
        allTrimBLSurfVerts.insert(surfVert);  
        EN_modifyDataInt((pEntity)surfVert,wedge_stack_id,0);
      }
      EN_modifyDataInt((pEntity)surfFace,wedge_stack_id,0);
    }
  }

  std::set<pVertex>::iterator sit_surf_vert, sit_surf_vert_end;

  /// Communicate surf vertices to unify those which originate stacks having trimming applied
#ifdef MA_PARALLEL
  if (SCUTIL_CommSize() > 1)
  {
    /// Initialize IPComMan
    IPComMan *CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int num_sent = 0, num_recvd = 0;
    int iSize = sizeof(pVertex) + 2*sizeof(int);
    CM->set_fixed_msg_size(iSize);
    void* msg_send = CM->alloc_msg(iSize);
    pVertex* vtxSend = (pVertex*)msg_send;
    int* iSend = (int*)((char*)msg_send + sizeof(pVertex));

    pVertex pVertexVtx;
    sit_surf_vert = curTrimBLSurfVerts.begin();
    sit_surf_vert_end = curTrimBLSurfVerts.end();
    while(sit_surf_vert != sit_surf_vert_end)
    {
      pVertexVtx = *sit_surf_vert;
      sit_surf_vert++;

      if (!EN_onCB(pVertexVtx))
        continue;

      std::vector<std::pair<int, pMeshEnt> > VtxRemCpy;
      FMDB_Ent_GetAllRmt(pVertexVtx, VtxRemCpy);

      /// Get the rem copy of the vertex and send its id
      EN_getDataInt(pVertexVtx, wedge_stack_id, &stackSizeTag);
      iSend[0] = stackSizeTag;
      iSend[1] = 0;
      if (allTrimBLSurfVerts.count(pVertexVtx))
        iSend[1] = 1;
      for (int iRC = 0; iRC < VtxRemCpy.size(); ++iRC)
      {
        *vtxSend = VtxRemCpy[iRC].second;
        CM->send(VtxRemCpy[iRC].first, msg_send);
      }
    }

    CM->free_msg(msg_send);
    CM->finalize_send();

    void* msg_recv;
    int pid_from;

    // recieve phase
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      vtxSend = (pVertex*)msg_recv;
      surfVert = *vtxSend;
      iSend = (int*)((char*)msg_recv + sizeof(pVertex));

      if (iSend[1] == 1)
        allTrimBLSurfVerts.insert(surfVert);
      /// Attach the minimum value possible
      if (EN_getDataInt(surfVert, wedge_stack_id, &stackSizeTag))
      {
        if (stackSizeTag > (iSend[0]))
          EN_modifyDataInt((pEntity)surfVert, wedge_stack_id, iSend[0]);
//        if (!allTrimBLSurfVerts.count(surfVert))
//          allTrimBLSurfVerts.insert(surfVert);
      }
      else
      {
        EN_attachDataInt((pEntity)surfVert, wedge_stack_id, iSend[0]);   
//        allTrimBLSurfVerts.insert(surfVert);        
      }

      CM->free_msg(msg_recv);
    }
  }
#endif  

/*
  sit_surf_vert = allTrimBLSurfVerts.begin();
  sit_surf_vert_end = allTrimBLSurfVerts.end();
  int iNumVtx = 0;
  while (sit_surf_vert != sit_surf_vert_end)
  {
    surfVert = *sit_surf_vert;
    sit_surf_vert++;
    if (EN_onCB(surfVert))
      iNumVtx++;
  }
  printf("%d: number of vtx on pb before pyramids loop is %d\n", P_pid(), iNumVtx);
*/

  /// Find pyramids on the wall surface
  FIter fit = M_faceIter(pmesh);
  while(face = FIter_next(fit)) 
  {
    // if not on model face or if quad. or if not on BL surf. then  continue
    if(F_whatInType(face) != Gface || face->getType() == QUAD)
      continue;

    region = F_region(face,0);
    if(!region)
      region = F_region(face,1);

    // consider only transition pyramids that covers quad. face of wedges
    if(region->getType() != PYRAMID)
      continue;

    surfFace = face;

    if(EN_getDataInt((pEntity)surfFace,wedge_stack_id,&stackSizeTag)) {
      cout<<"\nError in trimBLMeshForQuality()..."<<endl;
      cout<<"wedge stack size already attached to surf. face with pyramid\n"<<endl;
      exit(0);
    }
    EN_attachDataInt((pEntity)surfFace,wedge_stack_id,0);

    for (int iVtx = 0; iVtx < 3; ++iVtx)
    {
      surfVert = F_vertex(surfFace, iVtx);
      if(EN_getDataInt((pEntity)surfVert,wedge_stack_id,&stackSizeTag)) 
      {
        if(stackSizeTag>1) 
          EN_modifyDataInt((pEntity)surfVert,wedge_stack_id,1);
      }
      else 
      {
        // collect all zero level layer verts
        curTrimBLSurfVerts.insert(surfVert);
        EN_attachDataInt((pEntity)surfVert,wedge_stack_id,0);
      }
    }
  }
  FIter_reset(fit);

  sit_surf_vert = curTrimBLSurfVerts.begin();
  sit_surf_vert_end = curTrimBLSurfVerts.end();

  /// Identify the level difference where the trimming is going to start with
#ifdef MA_PARALLEL
  /// Initialize IPComMan
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  int num_sent = 0, num_recvd = 0;
  int iSize = sizeof(pVertex) + 2*sizeof(int);
  CM->set_fixed_msg_size(iSize);
  void* msg_send = CM->alloc_msg(iSize);
  pVertex* vtxSend = (pVertex*)msg_send;
  int* iSend = (int*)((char*)msg_send + sizeof(pVertex));
#endif  

  while(sit_surf_vert != sit_surf_vert_end) 
  {
    surfVert = *sit_surf_vert;
    sit_surf_vert++;

    int minmaxStackSize[2] = {100000000,0};
    void *vftemp = 0;
    pPList vfaces = V_faces(surfVert);
    while(face = (pFace)PList_next(vfaces,&vftemp)) {
      if(!EN_getDataInt((pEntity)face,wedge_stack_id,&stackSizeTag))
        continue;
      if(minmaxStackSize[0]>stackSizeTag)
        minmaxStackSize[0] = stackSizeTag;
      if(minmaxStackSize[1]<stackSizeTag)
        minmaxStackSize[1] = stackSizeTag;
    }
    PList_delete(vfaces);

#ifdef MA_PARALLEL
    if (EN_onCB(surfVert)) 
    {
      std::vector<std::pair<int, pMeshEnt> > VtxRemCpy;
      FMDB_Ent_GetAllRmt(surfVert, VtxRemCpy);

      /// Get the rem copy of the vertex and send its id
      EN_getDataInt(surfVert, wedge_stack_id, &stackSizeTag);
      iSend[0] = minmaxStackSize[0];
      iSend[1] = minmaxStackSize[1];
      for (int iRC = 0; iRC < VtxRemCpy.size(); ++iRC)
      {
        *vtxSend = VtxRemCpy[iRC].second;
        CM->send(VtxRemCpy[iRC].first, msg_send);
      }
    }
#endif

    /// The rest of different level vertices will be added in the receive phase if there are any
    if(minmaxStackSize[1]-minmaxStackSize[0]>1)
      allTrimBLSurfVerts.insert(surfVert); 
  }

#ifdef MA_PARALLEL
  CM->free_msg(msg_send);
  if (SCUTIL_CommSize() > 1)
  {
    CM->finalize_send();

    void* msg_recv;
    int pid_from;

    // recieve phase
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      vtxSend = (pVertex*)msg_recv;
      iSend = (int*)((char*)msg_recv + sizeof(pVertex));

      /// Attach the minimum value possible
      surfVert = *vtxSend;
      if (!allTrimBLSurfVerts.count(surfVert))
      {
        int minmaxStackSize[2] = {100000000,0};
        void *vftemp = 0;
        pPList vfaces = V_faces(surfVert);
        while(face = (pFace)PList_next(vfaces,&vftemp)) {
          if(!EN_getDataInt((pEntity)face,wedge_stack_id,&stackSizeTag))
            continue;
          if(minmaxStackSize[0]>stackSizeTag)
            minmaxStackSize[0] = stackSizeTag;
          if(minmaxStackSize[1]<stackSizeTag)
            minmaxStackSize[1] = stackSizeTag;
        }
        PList_delete(vfaces);
        if (minmaxStackSize[0] > iSend[0])
          minmaxStackSize[0] = iSend[0];
        if (minmaxStackSize[1] < iSend[0])
          minmaxStackSize[1] = iSend[1];        

        if(minmaxStackSize[1]-minmaxStackSize[0]>1)
          allTrimBLSurfVerts.insert(surfVert);
      }

      CM->free_msg(msg_recv);
    }
  }
#endif

  /// unify the difference in number of layers trimmiing is going to start with. if the difference is more than 1, decrease it
  int blLevel = 0;
  while(!P_getMaxInt(curTrimBLSurfVerts.empty())) 
  {
    nextTrimBLSurfVerts.clear();
    sit_surf_vert = curTrimBLSurfVerts.begin();
    sit_surf_vert_end = curTrimBLSurfVerts.end();

#ifdef MA_PARALLEL
    /// Initialize IPComMan
    IPComMan *CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    num_sent = 0;
    num_recvd = 0;
    iSize = sizeof(pVertex);
    CM->set_fixed_msg_size(iSize);
    msg_send = CM->alloc_msg(iSize);
    vtxSend = (pVertex*)msg_send;
#endif

    /// loop over current surf. verts.
    while(sit_surf_vert != sit_surf_vert_end) 
    { 
      surfVert = *sit_surf_vert;
      sit_surf_vert++;

      if(!EN_getDataInt((pEntity)surfVert,wedge_stack_id,&wedgeStackSize)) {
        cout<<"\nError in trimBLMeshForQuality()..."<<endl;
        cout<<"wedge stack size NOT attached to surf. vertex\n"<<endl;
        exit(0);
      }

      if(wedgeStackSize > blLevel) { // consider this surf. vertex later
        nextTrimBLSurfVerts.insert(surfVert);
        continue;
      }

      /// unify the difference in number of layers trimmiing is going to start with. if the difference is more than 1, decrease it
      int numEdges = V_numEdges(surfVert);
      for(int iEdge=0; iEdge<numEdges; iEdge++) {
        edge = V_edge(surfVert,iEdge);
        vertex = E_otherVertex(edge,surfVert);
        if(EN_getDataInt((pEntity)vertex,wedge_stack_id,&stackSizeTag)) {
          if(stackSizeTag > blLevel+1) { // wedgeStackSize==blLevel
            nextTrimBLSurfVerts.insert(vertex);
            allTrimBLSurfVerts.insert(vertex);
            EN_modifyDataInt((pEntity)vertex,wedge_stack_id,blLevel+1);

#ifdef MA_PARALLEL           
            /// remote copies should be notified about starting from blLevel+1 
            if (EN_onCB(vertex))
            {
              std::vector<std::pair<int, pMeshEnt> > VtxRemCpy;
              FMDB_Ent_GetAllRmt(surfVert, VtxRemCpy);

              /// Get the rem copy of the vertex and send its id
              for (int iRC = 0; iRC < VtxRemCpy.size(); ++iRC)
              {
                *vtxSend = VtxRemCpy[iRC].second;
                CM->send(VtxRemCpy[iRC].first, msg_send);
              }
            }
#endif
          }
        }
      } // loop over edges around a surf. vertex
    } // loop over current surf. vertices

#ifdef MA_PARALLEL
    CM->free_msg(msg_send);
    if (SCUTIL_CommSize() > 1)
    {
      CM->finalize_send();

      void* msg_recv;
      int pid_from;

      // recieve phase
      while(int rc = CM->receive(msg_recv, &pid_from))
      {
        vtxSend = (pVertex*)msg_recv;
        vertex = *vtxSend;

        nextTrimBLSurfVerts.insert(vertex);
        allTrimBLSurfVerts.insert(vertex);
        EN_modifyDataInt((pEntity)vertex,wedge_stack_id,blLevel+1);

        CM->free_msg(msg_recv);
      }
    }
#endif

    curTrimBLSurfVerts.clear();
//    nextTrimBLSurfVerts.unique();
    curTrimBLSurfVerts = nextTrimBLSurfVerts;
    blLevel++;
  }

/*
/// Traverse initial all BL prismatic stacks
int iCountVtx[3] = {0,0,0};
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    pBLayerBL = (pBLayer)(*egIt);

    surfFace = BL_GetZeroLvlFace(pBLayerBL);

    int iNumTgVtx = 0;
    for (int iVtx = 0; iVtx < 3; ++iVtx)
      if(allTrimBLSurfVerts.count(F_vertex(surfFace, iVtx)))
        iNumTgVtx++;

    if (iNumTgVtx)
      iCountVtx[iNumTgVtx-1]++;
  }
printf("[%d]: %d faces with tagged 3 vertesces, %d with 2 and %d with 1\n",P_pid(), iCountVtx[2], iCountVtx[1], iCountVtx[0]);
*/

#ifdef MA_PARALLEL
  SyncVtxIDsByOwner();
#endif

//  allTrimBLSurfVerts.unique();
  int numTrimBLSurfVerts = allTrimBLSurfVerts.size();

  sit_surf_vert = allTrimBLSurfVerts.begin();
  sit_surf_vert_end = allTrimBLSurfVerts.end();
  list<int> startVertFlags, trimLevels;
  list<pEdge> reffEdges;
  while(sit_surf_vert != sit_surf_vert_end) 
  {
    startVertFlags.clear();
    trimLevels.clear();
    reffEdges.clear();
    surfVert = *sit_surf_vert;
    sit_surf_vert++;

    if(!EN_getDataInt((pEntity)surfVert,wedge_stack_id,&wedgeStackSize)) {
      cout<<"\nError in trimBLMeshForQuality()..."<<endl;
      cout<<"during trim wedge stack size NOT attached to surf. vertex\n"<<endl;
      exit(0);
    }

    int numEdges = V_numEdges(surfVert);
    for(int iEdge=0; iEdge<numEdges; iEdge++) 
    {
      edge = V_edge(surfVert,iEdge);
      if(EN_getDataInt((pEntity)edge,int_reff,&reffTag))
        continue;
      vertex = E_otherVertex(edge,surfVert);
      if(!EN_getDataInt((pEntity)vertex,wedge_stack_id,&stackSizeTag))
        continue;

      reffEdges.push_back(edge); // surf. edge

      /// Decide which vertex to use to provide quad face bisection
      int startVertFlag = 1;
      int trimLevel = wedgeStackSize;
      if(stackSizeTag<wedgeStackSize) 
      {
        startVertFlag = 0;
        trimLevel = stackSizeTag;
      }
      else if(stackSizeTag == wedgeStackSize)  
      {
        if(allTrimBLSurfVerts.find(vertex) != sit_surf_vert_end)
        {
          pVertex minVtxId = getMinVtxIdByOwner(edge);
          if (minVtxId == vertex)
            startVertFlag = 0;
        }
      }

      startVertFlags.push_back(startVertFlag);
      trimLevels.push_back(trimLevel);
    } // loop over edges around a surf. vertex

    list<int>::iterator it_start_vert_flag, it_start_vert_flag_keep;
    list<int>::iterator it_trim_level, it_trim_level_keep;
    list<pEdge>::iterator it_reff_edge, it_reff_edge_end;
    it_reff_edge = reffEdges.begin();
    it_reff_edge_end = reffEdges.end();

    /// Tag surf. edges which have vertices originating bisection of quad faces
    while(it_reff_edge!=it_reff_edge_end) {
      edge = *it_reff_edge;
      it_reff_edge++;
      if(EN_getDataInt((pEntity)edge,int_reff,&reffTag)) {
        cout<<"\nError in trimBLMeshForQuality()..."<<endl;
        cout<<"during trim edge already tagged\n"<<endl;
        exit(0);
      }
      EN_attachDataInt((pEntity)edge,int_reff,1);
    }

    pVertex cStackVert = surfVert, nStackVert, startVtx;
    list<pEdge> nextReffEdges;
    set<pFace> lowerQFaces, nextLowerQFaces;
    set<pFace>::iterator it_lower_quad_end;
    blLevel = 0;
    while(!reffEdges.empty()) 
    {
      blLevel++;
      if(!cStackVert) {
        cout<<"\nError in trimBLMeshForQuality()..."<<endl;
        cout<<"during trim could NOT find vertex for start vertex\n"<<endl;
        exit(0);
      }

      nStackVert = 0;
      nextReffEdges.clear();
      nextLowerQFaces.clear();

      it_reff_edge = reffEdges.begin();
      it_reff_edge_end = reffEdges.end();

      it_start_vert_flag = startVertFlags.begin();
      it_trim_level = trimLevels.begin();

      it_lower_quad_end = lowerQFaces.end();

      if(reffEdges.size()!=startVertFlags.size()) {
        cout<<"\nError in trimBLMeshForQuality()..."<<endl;
        cout<<"during trim size mismatch in edges and start vertex flag\n"<<endl;
        exit(0);
      }

      if(reffEdges.size()!=trimLevels.size()) {
        cout<<"\nError in trimBLMeshForQuality()..."<<endl;
        cout<<"during trim size mismatch in edges and trim levels\n"<<endl;
        exit(0);
      }

      int noQuadFaces = 1;
      while(it_reff_edge!=it_reff_edge_end) 
      {
        pEdge reff_edge = *it_reff_edge;
        it_reff_edge++;
        int startVertFlag = *it_start_vert_flag;
        it_start_vert_flag_keep = it_start_vert_flag; // use it for erase
        it_start_vert_flag++;
        int trimLevel = *it_trim_level;
        it_trim_level_keep = it_trim_level; // use it for erase
        it_trim_level++;

        int numFaces = E_numFaces(reff_edge), cQFaces = 0;
        pFace qface = 0;
        for(int iFace=0; iFace<numFaces; iFace++) 
        {
          face = E_face(reff_edge,iFace);
          if(F_numEdges(face)!=4 || EN_getDataInt((pEntity)face,int_reff,&reffTag) || lowerQFaces.find(face)!=it_lower_quad_end)
            continue;

          qface = face;
          startVtx = cStackVert;
          if(!startVertFlag)
            startVtx = E_otherVertex(reff_edge,cStackVert);

          noQuadFaces = 0;
          cQFaces++;

          if(blLevel>trimLevel) 
          {
            EN_attachDataInt((pEntity)qface,int_reff,1);
            EN_attachDataPtr((pEntity)qface,bl_vtx_ptr_id,startVtx);
            triangulateQuadFaces.push_back(qface);

            for(int iRgn=0; iRgn<2; iRgn++) {
              region = F_region(qface,iRgn);
              if(region && !EN_getDataInt((pEntity)region,int_reff,&reffTag)) 
              {
                EN_attachDataInt((pEntity)region,int_reff,1);
                trimRgns.insert(region);
              }
            }
          }
          else
            nextLowerQFaces.insert(qface);
        } // loop over faces of a reff. edge

        if(cQFaces>1) {
          cout<<"\nError in trimBLMeshForQuality()..."<<endl;
          cout<<"more than one reff. quad. faces around a reff. edge\n"<<endl;
          exit(0);
        }

        if(!qface) {
          startVertFlags.erase(it_start_vert_flag_keep);
          trimLevels.erase(it_trim_level_keep);
          continue;
        }

        for(int iEdge=0; iEdge<4; iEdge++) 
        {
          if(reff_edge==F_edge(qface,iEdge)) 
          {
            nextReffEdges.push_back(F_edge(qface,(iEdge+2)%4));
            if(!nStackVert) 
            {
              if(E_inClosure(F_edge(qface,(iEdge+1)%4),(pEntity)cStackVert))
                nStackVert = E_otherVertex(F_edge(qface,(iEdge+1)%4),cStackVert);
              else if(E_inClosure(F_edge(qface,(iEdge+3)%4),cStackVert))
                nStackVert = E_otherVertex(F_edge(qface,(iEdge+3)%4),cStackVert);
              else {
                cout<<"\nError in trimBLMeshForQuality()..."<<endl;
                cout<<"current stack vertex NOT in closure of quad. face\n"<<endl;
                exit(0);
              }
            }
            break;
          }
        } // loop over edges of upper quad. face
      } // loop over reff. edges

      if(noQuadFaces) // when reached top face in stack
        break;

      cStackVert = nStackVert;

      lowerQFaces.clear();
      lowerQFaces = nextLowerQFaces;

      reffEdges.clear();
      reffEdges = nextReffEdges;
    }
  } // loop over trim surf. vertices

  /// Delete tags
  VIter vit = M_vertexIter(pmesh);
  while(vertex = VIter_next(vit)) {
    if(EN_getDataInt((pEntity)vertex,wedge_stack_id,&stackSizeTag))
      EN_deleteData((pEntity)vertex,wedge_stack_id);
    if (EN_getDataInt(vertex, split_id, &stackSizeTag))
      EN_deleteData(vertex, split_id);
  }
  VIter_delete(vit);

  EIter eit = M_edgeIter(pmesh);
  while(edge = EIter_next(eit)) {
    if(EN_getDataInt((pEntity)edge,int_reff,&reffTag))
      EN_deleteData((pEntity)edge,int_reff);
  }
  EIter_delete(eit);

  FIter_reset(fit);
  while(face = FIter_next(fit)) {
    if(EN_getDataInt((pEntity)face,wedge_stack_id,&stackSizeTag))
      EN_deleteData((pEntity)face,wedge_stack_id);
  }
  FIter_delete(fit);

  /// Bisect quad faces and update with the correspondent once which are in closure of regions detached from the BLs
#ifdef MA_PARALLEL
  pEntity *entSend;
  if (SCUTIL_CommSize() > 1)
  {
    /// Initialize IPComMan
    CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int iSize = 2*sizeof(pEntity);
    CM->set_fixed_msg_size(iSize);
    msg_send = CM->alloc_msg(iSize);
    entSend = (pEntity*)msg_send;
  }
#endif

  for(int iFace = 0; iFace < triangulateQuadFaces.size(); ++iFace)
  {
    face = triangulateQuadFaces[iFace];
    if(!EN_getDataInt((pEntity)face,int_reff,&reffTag)) // some may be unmarked during correction for wedges with only one marked quad. face
      continue;

    pVertex startVtx = 0; 
    EN_getDataPtr((pEntity)face,bl_vtx_ptr_id,(void**)&startVtx);

    /// Communicate quad faces to find out if some of them are not tagged since they are detached from BLs
#ifdef MA_PARALLEL
    if (EN_onCB(face))
    {
      std::vector<std::pair<int, pMeshEnt> > VecFaceRemCpy;
      FMDB_Ent_GetAllRmt(face, VecFaceRemCpy);
      for (int iRC = 0; iRC < VecFaceRemCpy.size(); ++iRC)
      {
        entSend[0] = VecFaceRemCpy[iRC].second;
        std::vector<std::pair<int, pMeshEnt> > VecVtxRemCpy;
        FMDB_Ent_GetAllRmt(startVtx, VecVtxRemCpy);
        for (int iVRC = 0; iVRC < VecVtxRemCpy.size(); ++iVRC)
        {
          if (VecFaceRemCpy[iRC].first == VecVtxRemCpy[iVRC].first)
          {
            entSend[1] = VecVtxRemCpy[iVRC].second;
            CM->send(VecFaceRemCpy[iRC].first, msg_send);
            break;
          }
        }
      }
    }
#endif    

    /// Bisect the face
    get_tri_faces_of_quad(face, 0, startVtx);
  }

#ifdef MA_PARALLEL
  if (SCUTIL_CommSize() > 1)
  {
    CM->free_msg(msg_send);
    CM->finalize_send();

    void* msg_recv;
    int pid_from;
    // recieve phase
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      entSend = (pEntity*)msg_recv;
      face = (pFace)(entSend[0]);
      pVertex startVtx;
      if (!EN_getDataPtr((pEntity)face,bl_vtx_ptr_id,(void**)&startVtx))
      {
        startVtx = (pVertex)(entSend[1]);
        get_tri_faces_of_quad(face, 0, startVtx);
           
        pRegionRgn = F_region(face, 0);
        EN_attachDataInt((pEntity)pRegionRgn, int_reff, 1);
        trimRgns.insert(pRegionRgn);
      }
      CM->free_msg(msg_recv);
    }

  /// Sync children faces on the part boundary
    M_update_CB_Links(entities_to_update, ptr_reff);
    entities_to_update.clear();
    M_updateOwnership(pmesh);
  }
#endif

  int iTetraRgn = 0;
  pRegion pRegionChdRgn[8];
  int  iTetReg[5] = {0, 0, 0, 0, 0};

  /// Trim regions
  for(std::set<pRegion>::iterator setIt = trimRgns.begin(); setIt != trimRgns.end(); ++setIt)
  {
    pRegionRgn = *setIt;

    if(!EN_getDataInt((pEntity)pRegionRgn,int_reff,&reffTag)) // some may be unmarked during correction for wedges with only one marked quad. face
      continue;

    /// Untag all BL data and delete BL structure if it's empty
    EN_unlabelBLEntAndDownAdjEnts(pRegionRgn);
    pBLayerBL = EN_getBL(pRegionRgn);
    if (pBLayerBL)
    {
      EG_removeEntity(pBLayerBL, pRegionRgn);
      if (EG_getNumOfEntities(pBLayerBL) == 0)
        M_removeEntGrp(pmesh, pBLayerBL);
    }

    int iTagFace;
    switch (pRegionRgn->getType())
    {
      case TET:
        break;
      case PYRAMID:
        tetrahedronizePyramid(pRegionRgn, pRegionChdRgn);
        break;
      case PRISM:
        iTagFace = 0;
        for (int iFace = 1; iFace < 4; ++iFace)
        {
          face = R_face(pRegionRgn, iFace);
          if (check_is_face_split(face))
            iTagFace++;
        }
        int iRgn;
        switch(iTagFace)
        {
          case 1: tetrahedronizePyramidizeWedge_OneQuadFaceSplit(pRegionRgn, pRegionChdRgn); iTetReg[0]++; break; /// Subdivision with interior vertex
          case 2: iRgn = tetrahedronizePyramidizeWedge(pRegionRgn, pRegionChdRgn);
            if (iRgn == 2)
              iTetReg[1]++; /// No interior vertex
            else
              iTetReg[2]++; /// Subdivision with interior vertex
            break;
          case 3: iRgn = tetrahedronizeWedge(pRegionRgn, pRegionChdRgn);
            if (iRgn == 3)
              iTetReg[3]++; /// No interior vertex
            else
              iTetReg[4]++; /// Subdivision with interior vertex
            break;
        }
        break;
      default:
        printf("Wrong entity to tetrahedronize!\n");
        break;
    }
    iTetraRgn++;
  }

  MD_deleteMeshDataId(bl_vtx_ptr_id);
  MD_deleteMeshDataId(wedge_stack_id);

  if (iTetReg[0] || iTetReg[2] || iTetReg[4])
    deleteSteiner();

#ifdef DEBUG
  if (iTetraRgn)
  {
    printf("[%d]: Tetrahedralized %d regions\n", P_pid(), iTetraRgn);
    for (int iTrim = 0; iTrim < 5; ++iTrim)
    {
      if (iTetReg[iTrim])
        printf("[%d]: Trimming template %d was applied %d times\n", P_pid(), iTrim, iTetReg[iTrim]);
    }

    if (iTetReg[0])
      printf("Warning! [%d]: Tetrahedralization templates with interior verts for region with only one quad face bisected were applied %d times\n", P_pid(), iTetReg[0]);
  }
#endif

  /// Tetrahedralize pyramids possibly left after trimming in the unstructured part of the domain
  Mesh_TetrahedralizePyramids();
}


int checkWedgeForQuality(pRegion region) 
{
  if(region->getType() != PRISM) 
  {
    cout<<"\nError in checkWedgeForQuality()..."<<endl;
    cout<<"region is NOT a wedge\n"<<endl;
    exit(0);
  }

  // fcSkew, fcTaper, fcWarp, rgnSkew, rgnTaper, rgnTwist and rgnShear
  double paramLimits[7] = {-1.0, 0.5, cosAngleWedgeWarpTol, cosAngleWedgeSkewTol, 0.25, -1.0, -1.0};

  double rxyz[6][3];

  int cRVert = 0;
  void *rvtemp = 0;
  pVertex vtx;
  pPList rverts = R_vertices(region,1);
  while(vtx = (pVertex)PList_next(rverts,&rvtemp))
    V_coord(vtx, rxyz[cRVert++]);
  PList_delete(rverts);

  return checkWedgeForQuality_XYZ(paramLimits,rxyz);
}

int checkStackForQuality(pVertex *surfTriVerts, pVertex *topTriVerts) 
{
  // fcSkew, fcTaper, fcWarp, rgnSkew, rgnTaper, rgnTwist and rgnShear
  double paramLimits[7] = {-1.0, -1.0, cosAngleStackWarpTol, cosAngleStackSkewTol, -1.0, -1.0, -1.0};

  double sxyz[6][3];
  for(int iVert=0; iVert<3; iVert++) {
    V_coord(surfTriVerts[iVert],sxyz[iVert]);
    V_coord(topTriVerts[iVert],sxyz[3+iVert]);
  }

  return checkWedgeForQuality_XYZ(paramLimits,sxyz);
}

int checkWedgeForQuality_XYZ(double *paramLimits, dArray *XYZ) 
{
  double eVector[4][3], gcVector[3][3], normal[2][3];
  int quad_fvidx[3][4] = {{0,1,4,3}, {1,2,5,4}, {2,0,3,5}};
  for(int iQuadFace=0; iQuadFace<3; iQuadFace++) {
    for(int iEdge=0; iEdge<4; iEdge++) {
      diffVt(XYZ[quad_fvidx[iQuadFace][(iEdge+1)%4]],XYZ[quad_fvidx[iQuadFace][iEdge]],eVector[iEdge]);
      normVt(eVector[iEdge],eVector[iEdge]);
    }
    for(int iComp=0; iComp<3; iComp++)
      gcVector[(iQuadFace+1)%3][iComp] = eVector[1][iComp];

    if(paramLimits[0]>0.) {
      // fcSkew is the max. of cosine of angle between layer and growth edges
      double fcSkew = 0., dotEdges;
      for(int iVert=0; iVert<2; iVert++) {
        for(int iLayer=0; iLayer<2; iLayer++) {
          dotEdges = fabs(dotProd(eVector[2*iLayer],eVector[2*iVert+1]));
          if(fcSkew<dotEdges)
            fcSkew = dotEdges;
        }
      }
      // convert this to 0.0 (poor) to 1.0 (good)
      fcSkew = 1.-fcSkew;
      if(fcSkew<paramLimits[0])
        return 1;
    }

    if(paramLimits[1]>0.) {
      double fcTaper = XYZ_distance2(XYZ[quad_fvidx[iQuadFace][3]],XYZ[quad_fvidx[iQuadFace][0]])/XYZ_distance2(XYZ[quad_fvidx[iQuadFace][2]],XYZ[quad_fvidx[iQuadFace][1]]);
      fcTaper = sqrt(fcTaper);
      if(fcTaper>1.)
        fcTaper = 1/fcTaper;
      if(fcTaper<paramLimits[1])
        return 1;
    }

    if(paramLimits[2]>0.) {
      // fcWarp is the min. of cosine of dihedral angle between two tri. faces of quad. 
      // (for both combinations, i.e., considering both diagonals)
      double dotTris, fcWarp = 1.;
      for(int iDiag=0; iDiag<2; iDiag++) {
        for(int iTri=0; iTri<2; iTri++) {
          crossProd(eVector[(2*iTri+iDiag)%4],eVector[(2*iTri+iDiag+1)%4],normal[iTri]);
          normVt(normal[iTri],normal[iTri]);
        }
        dotTris = dotProd(normal[0],normal[1]);
#ifdef DEBUG
        // if(dotTris<0.) {
        //   cout<<"\nWARNING in checkWedgeForQuality()..."<<endl;
        //   cout<<"quad. face ["<<iQuadFace+1<<"] seems to be too warped... \n"<<endl;
        //   cout<<endl;
        // }
#endif
        if(fcWarp>dotTris)
          fcWarp = dotTris;
      }
      if(fcWarp<paramLimits[2])
        return 1;
    }
  } // loop over quad. faces

  int tri_fvidx[2][3] = {{0,1,2}, {3,4,5}};
  double areaSqTriFc[2];
  for(int iTriFace=0; iTriFace<2; iTriFace++) {
    double v01[3], v02[3];
    diffVt(XYZ[tri_fvidx[iTriFace][1]],XYZ[tri_fvidx[iTriFace][0]],v01);
    diffVt(XYZ[tri_fvidx[iTriFace][2]],XYZ[tri_fvidx[iTriFace][0]],v02);
    crossProd(v01,v02,normal[iTriFace]);
    areaSqTriFc[iTriFace] = 0.25*dotProd(normal[iTriFace],normal[iTriFace]);
    normVt(normal[iTriFace],normal[iTriFace]);
  }

  if(paramLimits[3]>0.) {
    double rgnSkew = fabs(dotProd(normal[0],normal[1]));
    if(rgnSkew<paramLimits[3])
      return 1;
  }

  if(paramLimits[4]>0.) {
    double rgnTaper = areaSqTriFc[0]/areaSqTriFc[1];
    rgnTaper = sqrt(rgnTaper);
    if(rgnTaper>1.)
      rgnTaper = 1/rgnTaper;
    if(rgnTaper<paramLimits[4])
      return 1;
  }

  if(paramLimits[5]>0.) {
    double dotGCs, rgnTwist = 1.;
    for(int iGC=0; iGC<3; iGC++) {
      dotGCs = dotProd(gcVector[(iGC+1)%3],gcVector[iGC]);
      if(rgnTwist>dotGCs)
        rgnTwist = dotGCs;
    }
    if(rgnTwist<paramLimits[5])
      return 1;
  }

  if(paramLimits[6]>0.) {
    double dotTriGC, rgnShear = 1.;
    for(int iTri=0; iTri<2; iTri++) {
      for(int iGC=0; iGC<3; iGC++) {
        dotTriGC = fabs(dotProd(normal[iTri],gcVector[iGC]));
        if(rgnShear>dotTriGC)
          rgnShear = dotTriGC;
      }
    }
    if(rgnShear<paramLimits[6])
      return 1;
  }

  return 0;
}

