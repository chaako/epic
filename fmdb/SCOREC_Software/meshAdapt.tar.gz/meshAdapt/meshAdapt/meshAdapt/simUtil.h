#ifndef _H_SIMUTIL
#define _H_SIMUTIL

#include "modeler.h"

void GM_print(pGModel, int level=-1);
void GM_printVertices(pGModel);
void GM_printEdges(pGModel);
void GM_printFaces(pGModel);
void GM_printRegions(pGModel);

#endif //_H_SIMUTIL

