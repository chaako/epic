#ifndef _H_LayerEdgeSwapMod
#define _H_LayerEdgeSwapMod

#include <iostream>

#include "LocMeshMod.h"
#include "BLUtil.h"

using std::cout;
using std::endl;

class layerEdgeSwapMod : public locMeshMod
{
 public:
  layerEdgeSwapMod(const layerEdgeSwapMod &);
  layerEdgeSwapMod(pMesh p, pSField mf, MeanRatio *m, evalResults *r)
    : locMeshMod(p, mf, m, r),  edge(0), conf(-1), n(-1)  
    { }
/*   layerEdgeSwapMod(pMesh, pSField mf, MeanRatio *, evalResults *, pVertex v, double *t); */
  ~layerEdgeSwapMod() {}
  
  /* the common local modification interface */
  virtual int topoCheck();
  virtual int geomCheck();
  virtual int sizeCheck();
  virtual void getAffectedRgns(pPList *);
  virtual int apply();
  virtual int apply(pPList *);
  virtual modType type() { return LESWAP; }

  /* specific function for edge swap */
  void  setSwapEdge(pEdge ent) 
  { 
    pVertex Ovtx[2]; 
    Ovtx[0] = V_getOriginatingNode(E_vertex(ent,0));
    Ovtx[1] = V_getOriginatingNode(E_vertex(ent,1));
    edge=0;
    if(EN_levelInBL((pEntity)ent)==0)
      edge=ent; 
    else
      edge=E_exists(Ovtx[0],Ovtx[1]);
    if(!edge) {
      cout<<"\nError in layerEdgeSwapMod::setSwapEdge()"<<endl;
      cout<<"zero level layer edge not found"<<endl;
      exit(0);
    }
  
    edges.clear();
    BL_getHorizontalEdgesByEdge(ent, edges);
//    pPList elist = GC_layerAndTransitionEdges(V_growthCurve(Ovtx[0]),V_growthCurve(Ovtx[1]));
    listSize = edges.size();
    interfaceEdge=edges[listSize-1];
    results->reset(); conf=-1; n=-1; 
  }

  void  setSwapEdgeList(vector<pEdge> &elist) 
  { 
    edges.clear(); 
    for (vector<pEdge>::const_iterator eit = elist.begin(); eit != elist.end(); ++eit)
      edges.push_back(*eit);     

    results->reset();
    if(!edge)
      edge=edges[0];
    listSize = edges.size();
    interfaceEdge = edges[listSize-1];
    conf=-1; n=-1; }
    pEdge getSwapEdge() { return edge; }
//    pPList getSwapEdgeList() { return edges; }

  int   getCfg() { return conf; }
  int geomCheck(pVertex, pVertex);

 protected:
  /* driving data */
  /* the zero level layer edge to be swapped */
  pEdge edge;
  /* the interface edge to be swapped */
  pEdge interfaceEdge;
  /* the list of layer edges to be swapped */
  vector<pEdge> edges;  
  int listSize;

  /* internal data  */
  /* set after topoCheck() */
  int conf;            
  int n;

  int E_swpNewEdges(double *, double *);
  int geomCheck2D();

};


inline layerEdgeSwapMod::layerEdgeSwapMod(const layerEdgeSwapMod &x):
  locMeshMod(x.mesh, x.pSizeField, x.shpMeasure, x.results)
{
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;    
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;
  CB_move=x.CB_move;
  userData_CB_move=x.userData_CB_move;

  edge=x.edge;
  interfaceEdge=x.interfaceEdge;
//  edges=PList_newCopy(x.edges);
  for (vector<pEdge>::const_iterator eit = x.edges.begin(); eit != x.edges.end(); ++eit)
    edges.push_back(*eit);
  conf=x.conf;
  n=x.n;
  listSize=x.listSize;

  vertMv=x.vertMv;
  target[0]=x.target[0];
  target[1]=x.target[1];
  target[2]=x.target[2];
}


/* inline layerEdgeSwapMod::layerEdgeSwapMod(pMesh p, pSField mf, MeanRatio *m,  */
/* 				evalResults *r,  */
/* 				pVertex v, double *t) */
/*   : locMeshMod(p, mf, m, r),  edge(0), conf(-1), n(-1)  */
/* { */
/*   vertMv=v; */
/*   target[0]=t[0]; */
/*   target[1]=t[1]; */
/*   target[2]=t[2]; */
/* } */

#endif
