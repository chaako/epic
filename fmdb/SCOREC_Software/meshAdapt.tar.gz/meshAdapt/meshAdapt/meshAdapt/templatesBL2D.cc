#include "templateRefine.h"
#include "BLUtil.h"

void meshTemplate::selectDiagonalOnStack(vector<pFace>& stackOfFaces) 
{
  pFace top = stackOfFaces[stackOfFaces.size()-1];
  int value;
  // find index of the untagged edge
  int *order = new int[4];
  // int numEdges = F_numEdges(top);
  // assuming triangular face
  int iEdge;
  for(iEdge=0; iEdge<3; iEdge++) {
    if( !EN_getDataInt((pEntity)F_edge(top,iEdge),int_reff,&value) || 
	value!=1 ) {
      order[0] = iEdge;
      break;
    }
  }
  order[1] = (order[0]+1)%3;
  order[2] = (order[0]+2)%3;
  order[3] = order[0];

  void *data;  
  if(EN_getDataPtr((pEntity)top,diagonalSelectionID,(void **)&data)) {
    cout<<"\nError in selectDiagonalOnStack()..."<<endl;
    cout<<"order of edges is already attached for top face"<<endl;
    exit(0);
  }
  EN_attachDataPtr((pEntity)top,diagonalSelectionID,(void *)order);

  vector<pEdge> edgesStack;
  BL_getHorizontalEdgesByEdge(F_edge(top,order[1]), edgesStack);

  pFace face;
  for (int i = 0; i < stackOfFaces.size()-1; i++)
  {
    face = stackOfFaces[i];


    int *eorder = new int[4];

    for(iEdge=0; iEdge<3; iEdge++) {
      if( !EN_getDataInt((pEntity)F_edge(face,iEdge),int_reff,&value) || value!=1 )
      {
        eorder[0] = iEdge;
        break;
      }
    }
    if (std::find(edgesStack.begin(),edgesStack.end(),F_edge(face,(iEdge+1)%3)) != edgesStack.end())
    {
      eorder[1] = (eorder[0]+1)%3;
      eorder[2] = (eorder[0]+2)%3;
      eorder[3] = eorder[0];
    }
    else
    {
      eorder[1] = (eorder[0]+2)%3;
      eorder[2] = (eorder[0]+1)%3;
      eorder[3] = (eorder[0]+1)%3;
    }

    if(EN_getDataPtr((pEntity)face,diagonalSelectionID,(void **)&data)) {
      cout<<"\nError in selectDiagonalOnStack()..."<<endl;
      cout<<"order of edges is already attached for top face"<<endl;
      exit(0);
    }
    EN_attachDataPtr((pEntity)face,diagonalSelectionID,(void *)eorder);
  }
}

// this is replica of get_split_faces_2(pFace face)
// only that the selection of diagonal edge is made
// such that it is consistent for the whole stack of faces
pPList meshTemplate::get_split_faces_selected_2(pFace face) 
{
  void *temp_ptr;
  pPList plist;
  
  if(EN_getDataPtr((pEntity)face,ptr_reff,&temp_ptr))
    // the face is already split
    plist=(pPList)temp_ptr;
  else {
    // the face is not split yet
  
    int ne=F_numEdges(face);
    int zeroVert;           // the index of vert 0
    int zero;               // the index of unmarked edge
    int first, second;      // the 2 index of marked edge
    pEdge edges[7];         // the 7 edges to create the 3 new faces
    pEdge parent_edges[3];  // the 3 parent edges
    int e_dirs[3];          // directions the face uses its 3 edges
    pVertex verts[3];       // the 3 vertices to create the 2 interior edges
    pEdge f_edges[3];       // the 3 edges to create a new face
    int   f_dirs[3];        // the 3 directions to create a new face
    pFace faces[3];         // the 3 new faces created
    pGEntity g_entity;
    int i;

    // get the 3 parent edges of the face
    for(i=0; i<ne; i++) {
      parent_edges[i]=F_edge(face,i);
      e_dirs[i]=F_edgeDir(face,i);
    }
  
    int *order;
    if(!EN_getDataPtr((pEntity)face,diagonalSelectionID,(void **)&order)) 
    {
      cout<<"\nError in get_split_faces_selected_2()..."<<endl;
      cout<<"NO data attached to select diagonal edge"<<endl;
//      exit(0);
    }
  
    zero = order[0];
    first = order[1];
    second = order[2];
    zeroVert = order[3];

    delete [] order;
    EN_deleteData((pEntity)face,diagonalSelectionID);

    // get the first vertex
    pPList vlist=F_vertices(face,1);
    verts[0]=(pVertex)PList_item(vlist,zeroVert);

    // define the first edge to create the 3 faces
    edges[0]=parent_edges[zero];

    int offset = 0;
    if(zeroVert!=zero)
      offset=1;
    
    // get the two new edges of the first split edge
    pPList elist=get_split_edges(parent_edges[first]);
    verts[1]=(pVertex)PList_item(elist,0);
    if(e_dirs[first]) {
      edges[1]=(pEdge)PList_item(elist,1+offset);
      edges[2]=(pEdge)PList_item(elist,2-offset);
    }
    else {
      edges[1]=(pEdge)PList_item(elist,2-offset);
      edges[2]=(pEdge)PList_item(elist,1+offset);
    }

    // get the two new edges of the second split edge
    elist=get_split_edges(parent_edges[second]);
    verts[2]=(pVertex)PList_item(elist,0);
    if(e_dirs[second]) {
      edges[3]=(pEdge)PList_item(elist,1+offset);
      edges[4]=(pEdge)PList_item(elist,2-offset);
    }
    else {
      edges[3]=(pEdge)PList_item(elist,2-offset);
      edges[4]=(pEdge)PList_item(elist,1+offset);
    }

    // create the two interior edge 5 & 6
    g_entity=F_whatIn(face);
    edges[5]=M_createE(pmesh,verts[0], verts[1],g_entity);
    edges[6]=M_createE(pmesh,verts[1], verts[2],g_entity);

    // now create the three faces with orientation the same as its parent
    // always take the interior edge as the first edge
    // if there are two interior, take the edge normal to 12 as the first
    f_edges[0]=edges[5];
    f_edges[1+offset]=edges[0];
    f_edges[2-offset]=edges[1];
    f_dirs[0]=offset;
    f_dirs[1+offset]=e_dirs[zero];
    f_dirs[2-offset]=e_dirs[first];
    faces[0]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    f_edges[0+offset]=edges[5];
    f_edges[1-offset]=edges[6];
    f_edges[2]=edges[4];
    f_dirs[0+offset]=1-offset;
    f_dirs[1-offset]=1-offset;
    f_dirs[2]=e_dirs[second];
    faces[1]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    f_edges[0]=edges[6];
    f_edges[1+offset]=edges[2];
    f_edges[2-offset]=edges[3];
    f_dirs[0]=0+offset;
    f_dirs[1+offset]=e_dirs[first];
    f_dirs[2-offset]=e_dirs[second];
    faces[2]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

#ifdef DEBUG
    double par_normal[3],ch_normal[3];
    F_normalVector(face,1,par_normal);
    for(int iFace=0; iFace<3; iFace++) {
      F_normalVector(faces[iFace],1,ch_normal);
      if(dotProd(par_normal,ch_normal)<=0.)
	cout<<"Opp. normal of faces ["<<iFace<<"] of ["<<EN_id((pEntity)face)<<"]"<<endl;
    }
#endif

    PList_delete(vlist);

    // set inverse classification info - one level refinement only
    plist=PList_new();
    PList_append(plist,edges[5]);
    PList_append(plist,edges[6]);
    PList_append(plist,faces[0]);
    PList_append(plist,faces[1]);
    PList_append(plist,faces[2]);
    EN_attachDataPtr((pEntity)face,ptr_reff,plist);

    // set classification information 
    if(ChildToParent) {
      void *tmpPtr;
      if(!EN_getDataPtr((pEntity)face,ChildToParent,&tmpPtr)) 
	tmpPtr=(void *)face;
      EN_attachDataPtr((pEntity)edges[5],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)edges[6],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[0],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[1],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[2],ChildToParent,tmpPtr);
    }      

    // activate callback
    if( function_CB ) {
      pPList newFaces=PList_new();
      PList_append(newFaces,faces[0]);   // if we append new faces before edges in plist
      PList_append(newFaces,faces[1]);   // we can simply call callCallback here
      PList_append(newFaces,faces[2]); 
      pPList oldFaces=PList_new();
      PList_append(oldFaces,face);
      (function_CB)(oldFaces,newFaces,userData_CB,F_REFINE,0);
      PList_delete(oldFaces);
      PList_delete(newFaces);
    }

#ifdef MA_PARALLEL
#ifdef AOMD_ // PAOMD
    pmEntity* mCB;
    mCB = EN_getCommonBdry((pEntity)face);
    if( ! mCB )
      // we are a interior mesh entity
      return plist;

    // set common boundary information first
    EN_setCommonBdry((pEntity)edges[5], mCB);
    EN_setCommonBdry((pEntity)edges[6], mCB);
    EN_setCommonBdry((pEntity)faces[0], mCB);
    EN_setCommonBdry((pEntity)faces[1], mCB);
    EN_setCommonBdry((pEntity)faces[2], mCB);

    entities_to_update.push_back((pEntity)face);
#endif  // PAOMD
#endif  // MA_PARALLEL
  }
  
  return plist;
}

