#include <iostream>

#include "BLUtil.h"

char cornerModelEdgeID[256]; 

//extern int numBLSurfaces;
//extern int *blSurfaceTags;

extern pMeshDataId cornerONodeID;

using std::cout;
using std::endl;

void Mesh_DetectAndLabelCornerNodes(pMesh mesh, pGModel model)
{
  cornerONodeID = MD_newMeshDataId("corner onode");

  if (!model)
    return;

  pVertex pVertexVtx;
  pGVertex gvert;
  int dataTag;
  int iCornerVtxCount = 0;

  GVIter gvit = GM_vertexIter(model);
  while(gvert = GVIter_next(gvit)) {

    VIter vit = M_classifiedVertexIter(mesh, (pGEntity)gvert, 0);
    while(pVertexVtx = VIter_next(vit)) 
    {
      std::vector<pFace> VecLayerFaces;
      V_layerFaces(pVertexVtx, VecLayerFaces);

      std::set<pGEntity> VecGeomFaces; 
      for (int iFace = 0; iFace < VecLayerFaces.size(); ++iFace)
      {
        VecGeomFaces.insert(F_whatIn(VecLayerFaces[iFace]));
      }

      if(VecGeomFaces.size() >= 2)
      {
/*
        if(VecGeomFaces.size() > 2) 
        {
          cout<<"\nError in detectAndLabelCornerNodes()..."<<endl;
          cout<<"non-manifold model or num. of BL surfaces ["<<VecGeomFaces.size()<<"] around model edge NOT supported\n"<<endl;
          exit(0);
        }
*/
        /// Here we assume that the corner vertex is the one on the border of different model faces and has two or more growth edges starting from the originating vertex
        int iNumGrowthEdge = 0;
        pEdge pEdgeEdge;
        for (int iEdge = 0; iEdge < V_numEdges(pVertexVtx); ++iEdge)
        {
          pEdgeEdge = V_edge(pVertexVtx, iEdge);
          if (E_typeInBL(pEdgeEdge) == eGROWTH)
             iNumGrowthEdge++;
        }

        if (iNumGrowthEdge > 1 && !EN_getDataInt((pEntity)pVertexVtx, cornerONodeID, &dataTag))
        {
          EN_attachDataInt((pEntity)pVertexVtx, cornerONodeID, 1);
          iCornerVtxCount++;
        }
      }

    }
    VIter_delete(vit);
  }
  GVIter_delete(gvit);

/* 
  int numBLSurfacesAroundGEdge, numGEFaces, gFaceTag;
  pPList ge_faces;

  pGEdge gedge;
  pGFace gface;
  GEIter geit = GM_edgeIter(model);
  while(gedge = GEIter_next(geit)) {
    ge_faces = GE_faces(gedge);
    numGEFaces = PList_size(ge_faces);
    numBLSurfacesAroundGEdge = 0;
    for(int iGEFace=0; iGEFace<numGEFaces; iGEFace++) {
      gface = (pGFace)PList_item(ge_faces,iGEFace);
      gFaceTag = GEN_tag((pGEntity)gface);

      for(int iBLSurf=0; iBLSurf<numBLSurfaces; iBLSurf++) {
	if(blSurfaceTags[iBLSurf]==gFaceTag) {
	  numBLSurfacesAroundGEdge++;
	  break;
	}
      }
    }
    PList_delete(ge_faces);

    if(numBLSurfacesAroundGEdge>=2) {
      if(numBLSurfacesAroundGEdge>2) {
	cout<<"\nError in detectAndLabelCornerNodes()..."<<endl;
	cout<<"non-manifold model or num. of BL surfaces ["<<numBLSurfacesAroundGEdge<<"] around model edge NOT supported\n"<<endl;
	exit(0);
      }

      GEN_attachDataInt((pGEntity)gedge,cornerModelEdgeID,1);
    }
  }
  GEIter_reset(geit);

  int dataTag;
  GEIter_reset(geit);
  while(gedge = GEIter_next(geit)) {
    if(!GEN_getDataInt((pGEntity)gedge,cornerModelEdgeID,&dataTag))
      continue;

    int numFaces, fcount;
    double cos_dhd_angle;
    dArray dhd_xyz[4];
    pEdge edge;
    pFace face;
    EIter eit = M_classifiedEdgeIter(mesh,(pGEntity)gedge,0);
    while(edge = EIter_next(eit)) {      
      for(int iVert=0; iVert<2; iVert++)
	V_coord(E_vertex(edge,iVert),dhd_xyz[iVert]);

      numFaces = E_numFaces(edge);
      fcount = 0;
      for(int iFace=0; iFace<numFaces; iFace++) {
	face = E_face(edge,iFace);
	if(F_whatInType(face)==2) {
	  V_coord(F_edOpVt(face,edge),dhd_xyz[fcount+2]);

	  fcount++;
	  if(fcount>2) {
	    cout<<endl;
	    cout<<" ["<<fcount<<"] bdry. mesh faces found around mesh edge classified on model edge"<<endl;
	    exit(0);
	  }
	}
      }

      cos_dhd_angle = E_dihedral(dhd_xyz);
    }
    EIter_delete(eit);
  }
  GEIter_delete(geit);
*/

}

void Mesh_UnlabelCornerNodes(pMesh mesh, pGModel model)
{
  pVertex pVertexVtx;
  pGVertex gvert;
  int dataTag;

  GVIter gvit = GM_vertexIter(model);
  while(gvert = GVIter_next(gvit)) {

    VIter vit = M_classifiedVertexIter(mesh, (pGEntity)gvert, 0);
    while(pVertexVtx = VIter_next(vit))
    {
      if(EN_getDataInt((pEntity)pVertexVtx, cornerONodeID, &dataTag))
        EN_deleteData((pEntity)pVertexVtx, cornerONodeID);
    }
    VIter_delete(vit);
  }
  GVIter_delete(gvit);
/*
  int dataTag;
  pVertex vtx;
  pGEdge gedge;
  GEIter geit = GM_edgeIter(model);
  while(gedge = GEIter_next(geit)) {

    if(!GEN_getDataInt((pGEntity)gedge,cornerModelEdgeID,&dataTag))
      continue;

    VIter vit = M_classifiedVertexIter(mesh,(pGEntity)gedge,1);
    while(vtx = VIter_next(vit)) {
      if(EN_getDataInt((pEntity)vtx,cornerONodeID,&dataTag))
	EN_deleteData((pEntity)vtx,cornerONodeID);
    }
    VIter_delete(vit);

    GEN_deleteData((pGEntity)gedge,cornerModelEdgeID);
  }
  GEIter_delete(geit);
*/
  MD_deleteMeshDataId(cornerONodeID);

}
