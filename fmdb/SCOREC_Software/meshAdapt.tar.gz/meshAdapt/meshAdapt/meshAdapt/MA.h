#ifndef H_MA
#define H_MA

/* MA.h, Version 1.1 beta */
#include "FMDB.h"
#include "MeshAdapt.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
typedef class meshAdapt* pMAdapt;
#ifdef CURVE
typedef class curveMesh* pCrvMesh;
#endif /* CURVE */
#else
typedef struct meshAdapt* pMAdapt;
#ifdef CURVE
typedef struct curveMesh* pCrvMesh;
#endif /* CURVE */
#endif

typedef pMAdapt pMSAdapt;

/** \brief Provide adaptation routines.
 *
 *  Given a Mesh Adaptation Driver, the function provides mesh adaptation routines based on
 *  the sequential execution of mesh modification operations to achieve the desired size and quality of the mesh.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *
 */
void MA_Adapt(pMAdapt pMAdaptDrvr);


/** \brief Delete Mesh Adaptation Driver.
 *
 *  Given a Mesh Adaptation Driver, the function deallocates it.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *
 */
void MA_Del(pMAdapt pMAdaptDrvr);


/** \brief Create an object of class (struct) pMAdapt.
 *
 *  Given a mesh, the function allocates a Mesh Adaptation Driver with the default configuration.
 *
 *  \param  pMAdaptDrvr                  (In/Out)  Mesh Adaptation Driver.
 *  \param  pMeshInstance                (In)  Input mesh.
 *  \param  iSizeFldType                 (In)  Input Size Field Type
 *
 */
void MA_NewMeshAdaptDrvr(pMAdapt &pMAdaptDrvr, pMeshMdl pMeshInstance, int iSizeFldType);


/// Same as above, but with the ability to specifically provide the model type: 0 - no snapping, 1 - Not parametric, 2 - Parametric.
void MA_NewMeshAdaptDrvr_ModelType(pMAdapt &pMAdaptDrvr, pMeshMdl pMeshInstance, int iSizeFldType, int iModelType);


/** \brief Set anisotropic size for a specific vertex.
 *
 *  Given a mesh adaptation driver, a vertex and the desired anisotropic size, sets remembers the size
 *  for this specific vertex in order to achive the desired size during mesh modification operations.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  pVertexVtx                   (In)  Input vertex.
 *  \param  ddSize                       (In)  Desired anisotropic size.
 *
 */
void MA_SetAnisoVtxSize(pMAdapt pMAdaptDrvr, pVertex pVertexVtx, double ddSize[3][3]);


/** \brief Set a callback function.
 *
 *  Given a Mesh Adaptation Driver, the function remembers the callbck function and needed
 *  user (application) data in order to call the callback function while doing mesh adaptation.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  CB                           (In)  Callback function.
 *  \param  userData                     (In)  User (application) data.
 *
 */
void MA_SetCB(pMAdapt pMAdaptDrvr, CBFunction CB, void *userData);


/** \brief Set isotropic size for a specific vertex.
 *
 *  Given a mesh adaptation driver, a vertex and the desired isotropic size, sets remembers the size
 *  for this specific vertex in order to achive the desired size during mesh modification operations.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  pVertexVtx                   (In)  Input vertex.
 *  \param  dSize                        (In)  Desired isotropic size.
 *
 */
void MA_SetIsoVtxSize(pMAdapt pMAdaptDrvr, pVertex pVertexVtx, double dSize);


/** \brief Set the number of mesh modification steps (iterations).
 *
 *  Given a mesh adaptation driver, the function sets the number of mesh modification steps (iterations).
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  iNumIt                       (In)  Number of mesh modification steps (iterations).
 *
 */
void MA_SetNumIt(pMAdapt pMAdaptDrvr, int iNumIt);


/** \brief Set the option for providing predictive load balance.
 *
 *  Given a mesh adaptation driver, the function sets the option for providing predictive load balance.
 *  The options are: 0 - no predictive load balance, 1 - predictive load balance.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  iPredLoadBal                 (In)  Predictive load balance option.
 *
 */
void MA_SetPredLoadBal(pMAdapt pMAdaptDrvr, int iPredLoadBal);


/** \brief Set refinement level for an entity.
 *
 *  Given a mesh adaptation driver, the entity and the refinement level, the function remembers the refinement level
 *  for this specific entity. The levels are: 0 - no refinement needed, 1 - refinement requested.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  pEntityEnt                   (In)  Mesh entity.
 *  \param  iRefLvl                      (In)  Refinement level.
 *
 */
void MA_SetRefLvl(pMAdapt pMAdaptDrvr, pEntity pEntityEnt, int iRefLvl);


/** \brief Get refinement level for an entity.
 *
 *  Given a mesh adaptation driver, the entity and the variable for refinement level, the function assigns the refinement level
 *  for the specific entity provided. The levels are: 0 - no refinement level assigned, 1 - refinement requested.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  pEntityEnt                   (In)  Mesh entity.
 *  \param  iRefLvl                      (Out)  Refinement level.
 *
 */
void MA_GetRefLvl(pMAdapt pMAdaptDrvr, pEntity pEntityEnt, int &iRefLvl);


/** \brief Set analytical size field function.
 *
 *  Given a mesh adaptation driver, the function sets the analytical size field function which will be called
 *  to calculate the size for each mesh vertex.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  SizeFldFunc                  (In)  Pointer to the analytical size field function.
 *
 */
void MA_SetSizeFldFunc(pMAdapt pMAdaptDrvr, adaptSFunc SizeFldFunc);


/** \brief Set size field type.
 *
 *  Given a mesh adaptation driver, the function sets the size field type.
 *  The options are from SizeFldType enum:
 *  Application - the size field will be provided by the application (default).
 *  TagDriven - tag driven size field. 
 *  Analytical - analytical size field. 
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  iSizeFldType                 (In)  Size field type.
 *
 */
void MA_SetSizeFldType(pMAdapt pMAdaptDrvr, int iSizeFldType);


/** \brief Anisotropic mesh gradation control.
 *
 *  Given a mesh adaptation driver and the smoothness prescribed value, the function smoothes the size field to 
 *  control the element size and shape variation to avoid significant size jumps between the neighboring vertices.
 *
 *  \param  pMAdaptDrvr                   (In)  Mesh Adaptation Driver.
 *  \param  dBeta                         (In)  Smoothness control value.
 *
 */
int MA_AnisoSmooth(pMAdapt pMAdaptDrvr, double dBeta[3]);


/** \brief Calculate the mesh size associated with vertex.
 *
 *  Given a mesh vertex, the function calculates the mesh size associated with the vertex. 
 *  The anisotropic size is returned in the order of increasing magnitude
 *
 *  \param  pVertexVtx                   (In)  Mesh vertex.
 *  \param  dAnisoSize                   (In)  Anisotropic size.
 *
 */
int MA_Vtx_Size(pVertex pVertexVtx, double dAnisoSize[3][3]);


void MA_SetQualityThreshold(pMAdapt pMAdaptDrvr, double dQualThreshold);


/** \brief Set the flag for first layer thickness in boundary layer mesh. 
 *
 *  The function sets the flag for the first layer thickness in boundary layer adaptation.
 *  0 means that that the first nodal spacing off the wall is not going to be considered.
 *  1 stands for using the first layer thickness which is supposed to be attached to the
 *  originating nodes.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  isFirstLayerThicknessSet     (In)  First layer thickness flag.
 *
 */
void MA_SetFirstLayerThicknessFlag(pMAdapt pMAdaptDrvr, int isFirstLayerThicknessSet);


/** \brief Attach information about first nodal spacing to the vertex.
 *
 *  Given a mesh vertex, the function attaches the first layer thickness to it.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  pVertexVtx                   (In)  Mesh vertex.
 *  \param  dFirstNodalSpacing           (In)  Nodal spacing.
 *
 */
int MA_SetFirstLayerThickness(pMAdapt pMAdaptDrvr, pVertex pVertexVtx, double dFirstNodalSpacing);


/** \brief Set the flag for performing the adaptive trimming in boundary layer mesh.
 *
 *  The function sets the flag for the ability to provide adaptive trimming in boundary layer adaptation
 *  if the aspect ratio of boundary layer entities goes wrong.
 *  0 means that that the no adaptive trimming will be performed.
 *  1 stands for applying the trimming routines ones the wrong aspect ratio is identified.
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  iFlag                        (In)  Flag for trimming.
 *
 */
int MA_SetAdaptiveDecompFlag(pMAdapt pMAdaptDrvr, int iFlag);


/** \brief Set the aspect ratio square limit for adaptive trimming in boundary layer mesh.
 *
 *  The function sets the aspect ratio square limit for the ability to provide adaptive trimming in boundary layer adaptation.
 *  If the aspect ratio of boundary layer entities goes higher than the limit is set, adaptive trimming routines are performed.
 *  Note that for the trimming routines to be executed it is needed to set the flag in MA_SetAdaptiveTrimmingFlag().
 *
 *  \param  pMAdaptDrvr                  (In)  Mesh Adaptation Driver.
 *  \param  dAspectRatioLimit            (In)  Aspect ratio limit for the trimming.
 *
 */
int MA_SetAdaptiveDecomp_AspectRatioLimit(pMAdapt pMAdaptDrvr, double dAspectRatioLimit);


/// Tetrahedralize mesh
int MA_TetrahedralizeBL(pMAdapt pMAdaptDrvr);
int MA_Mesh_TetrahedralizeBLs(pMeshMdl pMeshModel);

/// Decomposition with aspect ratio, aspect ratio is a square of growth edge / layer edge
int MA_DecompositionBL_AspectRatio(pMAdapt pMAdaptDrvr, double dAspectRatioLimit);
int MA_DecompositionBL_ForQuality(pMAdapt pMAdaptDrvr);
int MA_Mesh_DecompositionBL_ForQuality(pMeshMdl pMeshModel);


#ifdef CURVE
/** C APIs for curved mesh adaptation */
  
/** \brief Create an object of class (struct) pCrvMesh.
 *
 *  Given a mesh, the function creates a curved mesh object with the default configuration.
 *
 *  \param  pCrvMeshObj               (In/Out)  Curved Mesh Object.
 *  \param  pMeshMesh                 (In)  Input mesh.
 *
 */
int CMA_NewCrvMeshObj(pCrvMesh &pCrvMeshObj, pMesh pMeshMesh);

/** \brief Delete an object of class (struct) pCrvMesh.
 *
 *  This function deletes a curved mesh object and de-allocates the memory.
 *
 *  \param  pCrvMeshObj               (In)  Curved Mesh Object.
 *
 */
int CMA_DelCrvMeshObj(pCrvMesh pCrvMeshObj);

/** \brief Set the type of geometric model.
 *
 *  This function tells the curving code what type of geometric model information is available. Currently supports: 0-- no model, 1-- mesh model with no parametric coordinates, and 2-- CAD model with parametric coordinates.
 *
 *  \param  pCrvMeshObj               (In)  Curved Mesh Object.
 *  \param  iModelType                (In)  Flag of Model type info.
 *
 */
int CMA_SetModelType(pCrvMesh pCrvMeshObj, int iModelType);

/** \brief Curve a given linear(straight-sided) mesh to be a high-order(curved) mesh.
 *
 *  This function does the mesh curving. The mesh need to be classified on a geometric model with appropriate parametric coordinates. Validity is not checked in this routine. 
 *
 *  \param  pCrvMeshObj               (In)  Curved Mesh Object.
 *
 */
int CMA_CurveLinearMesh(pCrvMesh pCrvMeshObj);

/** \brief Fix the invalid curved elements of a given high-order(curved) mesh.
 *
 *  This function does topological and geometric modifications to the cavity defined by the invalid element, and yields an all valid output mesh.
 *
 *  \param  pCrvMeshObj               (In)  Curved Mesh Object.
 *
 */
int CMA_FixInvalidCurvedElement(pCrvMesh pCrvMeshObj);

/** \brief Clear up the memory of the high-order nodes of the curved mesh.
 *
 *  This function clears up the memory of the high-order nodes of the curved mesh.
 *
 *  \param  pCrvMeshObj               (In)  Curved Mesh Object.
 *
 */
int CMA_ClearHighOrderNodes(pCrvMesh pCrvMeshObj);

/** \brief The main routine to perform the shape quality improvement capability.
 *
 *
 *  \param  pCrvMeshObj               (In)  Curved Mesh Object.
 *
 */
int CMA_ImproveMeshQualityByMeshMod(pCrvMesh pCrvMeshObj);

/** \brief Tag the edges of the surface mesh to be "fixed" from mesh mod operations.
 *
 *
 *  \param  pCrvMeshObj               (In)  Curved Mesh Object.
 *
 */
int CMA_LockSurfaceMesh(pCrvMesh pCrvMeshObj);

/** \brief Set the user-defined shape quality threshold for mesh improvement operations.
 *
 *
 *  \param  pCrvMeshObj               (In)  Curved Mesh Object.
 *  \param  dThreshold                (In)  Input Shape Threshold.
 *
 */
int CMA_SetCrvMeshQualityThreshold(pCrvMesh pCrvMeshObj, double dThreshold);

#endif


#ifdef __cplusplus
}
#endif

#endif

