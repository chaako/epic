#ifndef H_MeshSimAdapt
#define H_MeshSimAdapt

/* MeshSimAdapt.h, Version 2.3 */
#ifdef SIM
#include "MeshSim.h"
#else
#include "FMDB.h"
#include "MeshTools.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
typedef class meshAdapt* pMSAdapt;
#else
typedef struct meshAdapt* pMSAdapt;
#endif

typedef pMesh pParMesh;

void MSA_setAnisoVertexSize(pMSAdapt,pVertex,double[3][3]);

void MSA_setVertexSize(pMSAdapt,pVertex,double);

pMSAdapt MSA_new(pMeshMdl, pMesh, int);
 
void MSA_delete(pMSAdapt);

/* set refinement for mesh entity */
void MSA_setRefineLevel(pMSAdapt,pEntity,int);

/* do refinement */
void MSA_adapt(pMSAdapt);

void MSA_setCallback(pMSAdapt simAdapter, CBFunction CB, int filter, void *userData);
#ifdef __cplusplus
	   }
#endif

#endif

