#ifndef _H_TEMPLATEUTIL
#define _H_TEMPLATEUTIL

#include "MeshTools.h"
#include "sizeFieldBase.h"

namespace templatesUtil {

  void mapping_template(pRegion,pPList,pPList,int,const int[][6],const int[][4],const int[][4],
			pFace[4],pEdge[6],int[4],pVertex[4]); 
  void mapping_template_pyr(pRegion region, pPList ordered_edges, int id, pFace parent_faces[5], pEdge parent_edges[8], pVertex verts[5]);
  void mapping_template_prism(pRegion region, pPList ordered_edges, int id, pFace parent_faces[5], pEdge parent_edges[9], pVertex verts[6]);
  int shortestDiagonal(pPList, int, pSField);
  void map_vertices(pFace face,pVertex verts[3],int n[3]);

  /* compute centroid and interoplate mesh size there */
  pMSize tetCenter(pVertex[4], double[3], pSField pSizeField);
  pMSize wedgeCenter(pVertex[6], double[3], pSField pSizeField);

  int middlePoint(pEdge,double,double*, double*);
  int bisectParam1(double,double*,double[2][3],pGEdge,double[2],double*,double*,double,int);
  int bisectParam2(double,double[2][3],double[2][3],pGFace,int[2],int[2],double[2][2],int,double*,double*,double,int);
  int GV_isonSeam(pGVertex gv, pGFace gf);
  int GE_isClosed(pGEdge ge);
  int ifAddPeriod(pGFace,int[2],int[2],int,double[2][3],double[2][2]);
  int ifDegenerated(pGFace gf, double *par, double tol);

  int Edge_colaps(pMesh, pEdge, pVertex, pVertex, CBFunction, void *, pPList *);
#ifdef MATCHING
  int Edge_colaps(pMesh, pEdge, pVertex, pVertex, CBFunction, void *, pPList *,
                  pPList *, pPList *); 
#endif
  pVertex Edge_split(pMesh, pEdge, double *, double*, CBFunction, void *, pPList *);
  int Edge_swap(pMesh, pEdge, int, CBFunction, void *, pPList *); 
  pEdge Edge_swapOnGFace(pMesh, pEdge, pGEntity,CBFunction, void *, pPList *);
  int Face_swap(pMesh, pFace, double, CBFunction, void *, pPList *);

#ifdef CURVE
  int isFaceCurved(pFace);
#endif
}

#endif /* _H_TEMPLATEUTIL */
