/*
  This class maintains a piecewise linear mesh size field that 
  is attached to the vertices of the current mesh.
 
  Created  04/15/2002    -li
 */
#ifndef _H_PWLsfield
#define _H_PWLsfield

#include "AdaptTypes.h"
#include "sizeFieldBase.h"
#include <deque>
#include <list>

/*
#ifdef MA_PARALLEL
#include "pmDataExchanger.h"
#endif
*/

using namespace std;

class PWLsfield : public SFieldBase
{
 public:
  PWLsfield(pMesh);
  ~PWLsfield();

  virtual int type() { return 1; }

  // specification
  void setSize(pEntity, double[3][3], double[3]);

  // control the gradation of desired mesh size variation
  void isoSmooth(double);
  void anisoSmooth(double[3]);

  // geometric computation
  virtual double lengthSq(pEdge);
  virtual double areaSq(pFace);
  virtual double volume(pRegion);

  virtual double lengthSq(dArray, dArray, pMSize);
  virtual double areaSq(dArray[3], pMSize, dArray);
  virtual double volume(dArray[4], pMSize);
  virtual double angleSq(dArray, dArray, pMSize);

  virtual double lengthSq(dArray, dArray, pMSize, pMSize);
  virtual double lengthSq(pVertex,pVertex);

  virtual void decomposeMetricTensor(pVertex, dArray);
  virtual pMSize decomposeMetricTensor(pMSize, dArray);

  // compute location of center point and its associated size
  virtual void center(pEdge, double[3], pMSize *);
  virtual double center(pVertex,pVertex,dArray,pMSize *);

#ifdef MATCHING
  virtual void center(pVertex,pVertex, double, dArray,pMSize *); 
#endif 

  // set/delete the size at a vertex 
  virtual void setSize(pEntity, pMSize);
  virtual void setSize(pEntity, double);
  virtual void deleteSize(pEntity);

  // get the size at a point or a vertex
  virtual pMSize getSize(dArray, pEntity);
  virtual pMSize getSize(dArray, pPList);
  virtual pMSize getSize(pVertex, dArray, dArray, pRegion);
  virtual pMSize getSize(pVertex);

 protected:
  double center(dArray[2],pMSize[2],dArray,pMSize *);
  void interpolate(pMSize,pMSize,double,pMSize *);
  int spheroidType(pMSize,pMSize);
  int E_isoSmooth(pVertex, pVertex, double, std::deque<pEdge >&,pMeshDataId);
  int E_anisoSmooth(pVertex,pVertex,double[3][3],double,double[3]);
  void procAnEdge(pEdge, std::deque<pEdge> &, pMeshDataId, double[3]);
  void updateQueue(std::deque<pEdge> &, pMeshDataId, pVertex);

  pMesh backMesh;
  pMeshDataId pMSizeFieldId;
  int dim;

#ifdef MA_PARALLEL
  list<pEntity> verts_to_update;
  list<pEntity>::iterator lit;
  void syncMetric(deque<pEdge> &, pMeshDataId, list<pEntity> &);
  int intersect(pVertex, double[3][3], double[3]);
#endif

};

/*
#ifdef MA_PARALLEL
class idExchanger_metric : public pmDataExchanger
{
  PWLsfield *pwField;
  pMeshDataId id;
  std::deque<pEdge> deQueue;

public :
  idExchanger_metric(PWLsfield *pwsf, pMeshDataId i, std::deque<pEdge> &queue): pwField(pwsf), id(i), deQueue(queue) {}
  virtual int msg_size();
  virtual void fill_buffer (mEntity *e, mEntity *remoteEnt, void *&msg_send);
  virtual void receiveData (void *msg_recv, int pid_from);
};
#endif
*/

#endif
