#ifndef _H_PARAMSONGFACE
#define _H_PARAMSONGFACE

#include "MeshTools.h"

class ParamsOnGFace  
{
 public:
  ParamsOnGFace(int, pGFace, double *);
  ~ParamsOnGFace();

  int ifGParamExist(pGFace);
  void append(pGFace, double *);
  void appendUnique(pGFace, double *);
  int getParam(pGFace, double *);

 private:
  int np; 
  pGFace *gface;
  double *param;
};



#endif
