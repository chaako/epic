#ifndef _H_BLUTIL
#define _H_BLUTIL

//#include "stdio.h"

#include "FMDB.h"
#include "FMDB_EntGrp.h"
#include "FMDB_Internals.h"
#include "MeshEntTools.h"

#include <vector>
#include <set>

using namespace std;

typedef pEntityGroup pBLayer;
typedef EGIter pBLIter;
typedef EntIter pBLEntIter;

//pMeshDataId blEdgeTypeID, blFaceTypeID, blRegionTypeID;

/// Edge classification in BL.
typedef enum blVertexType 
{
  vORIGINATING=1, vREGULAR
} blVertexType;

/// Edge classification in BL.
typedef enum blEdgeType 
{
  eLAYER=1, eGROWTH, eDIAGONAL, eTRANSITION
} blEdgeType;

/// Face classification in BL.
typedef enum blFaceType 
{
  fLAYER=1, fVERTICAL_QUAD, fVERTICAL_TRI, fTRANSITION
} blFaceType;

/// Region classification in BL.
typedef enum blRegionType 
{
  rREGULAR=1, rBLEND_PRISM, rBLEND_HEX, rTRANSITION_TET, rTRANSITION_PYR
} blRegionType;


pBLIter Mesh_GetBegBLIter(pMesh pMeshMesh);

pBLIter Mesh_GetEndBLIter(pMesh pMeshMesh);

pBLEntIter BL_GetBegEntIter(pBLayer pBLayerBL);

pBLEntIter BL_GetEndEntIter(pBLayer pBLayerBL);


/** \brief Defines whether the given entity is a BL entity.
 *
 *  Given an entity, the function returns 1 if the entity belongs to a BL, and 0 otherwise.
 *
 *  \param  ent                    (In)  Entity.
 *  \return                              1 if entity is a part of BL or 0.
 */
int EN_isBLEntity(pEntity ent);


/** \brief Gives the level of an entity in BL.
 *
 *  Given an entity, the function returns its growth level in BL.
 *
 *  \param  ent                    (In)  Entity.
 *  \return                              Growth level in BL or -99.
 */
int EN_levelInBL(pEntity ent);

/// Same as above but for the remote BL entities, EN_levelInBL() of which is -99
int EN_remLevelInBL(pEntity ent);

/** \brief Gives the BL the entity belongs to.
 *
 *  Given an entity, the function returns the BL it belongs to, if it is unique to the BL.
 *  The valid input entities are regions, layer and transition faces.
 *
 *  \param  ent                    (In)  Entity.
 *  \return                              BL, if any.
 */
pBLayer EN_getBL(pEntity ent);


/** \brief Merges the BL entity information.
 *
 *  Given an entity from which the information is needed (entFrom), and the entity where it has to be migrated (entTo),
 *  the function merges it on the requested entity. If the information in any of the fields of entTo was already filled,
 *  the priority is given to the information of the entity from which it migrates.
 *
 *  \param  entTo                  (In)  Entity where the information will be migrated.
 *  \param  entFrom                (In)  Entity from which the data is migrated.
 *
 */
void EN_mergeBLInfo(pEntity entTo, pEntity entFrom);


/** \brief Label the specific entity with the level info and type in BL.
 *
 *  Given a BL entity, level in BL and type of a BL entity, the function assigns that information to the entity.
 *
 *  \param  ent                    (In)  Entity.
 *  \param  level                  (In)  Entity level in BL.
 *  \param  entTypeInBL            (In)  Entity type in BL.
 *
 */
void EN_labelBLEntity(pEntity ent, int level, int entTypeInBL);


/** \brief Unlabel entity BL level and its type in BL.
 *
 *  Given a BL entity, the function clears its BL level and type data.
 *
 *  \param  ent                    (In)  Entity.
 *
 */
void EN_unlabelBLEntity(pEntity ent);


void EN_unlabelBLEntAndDownAdjEnts(pEntity pEntityEnt);


/** \brief Clean BL level of an entity.
 *
 *  Given a BL entity, the function clears its BL level.
 *
 *  \param  ent                    (In)  Entity.
 *
 */
void Ent_ClrBLEntLvl(pEntity pEntityEnt);


/** \brief Checks for all the adjacent nodes being BL vertexes.
 *
 *  Given a BL entity, the function checks the adjacent vertexes for beng BL vertexes. If all the nodes are BL nodes, it returns 1.
 *
 *  \param  ent                    (In)  Entity.
 *  \return                              1 if all the nodes are BL nodes, 0 otherwise.
 */
int EN_allBLNodes(pEntity ent);


// do NOT use any BL info. (can be used for a general mesh)
int EN_isPointInside(pEntity entity, double *xyz);


/** \brief Gives the BL the entity belongs to.
 *
 *  Given an entity, the function returns the BL it belongs to, if it is unique to the BL.
 *  The valid input entities are regions, layer and transition faces.
 *
 *  \param  ent                    (In)  Entity.
 *  \return                              BL, if any.
 */
int V_typeInBL(pVertex vertex);


/** \brief Checks the BL vertex for being an originating one.
 *
 *  Given a BL vertex, the function returns 1 if it is an originating node, and o otherwise.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \return                              1 if originating node, 0 otherwise.
 */
int V_isOriginatingNode(pVertex vertex);


/** \brief Gets an originating node using the BL vertex provided.
 *
 *  Given a BL vertex, the function gets the originating node along the same growth curve they reside on.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \return                              Originating node.
 */
pVertex V_getOriginatingNode(pVertex vertex);


/** \brief Sets information about vertex being a corner node.
 *
 *  Given a BL vertex, the function sets it to be a corner node, such that there are more than one but no more than two
 *  model faces connected to it from which boundary layers grow.
 *
 *  \param  vertex                 (In)  BL vertex.
 */
void V_setCornerONode(pVertex vertex);


/** \brief Checks if the vertex is a corner node.
 *
 *  Given a BL vertex, the function checks if it is corner node, such that there are more than one but no more than two
 *  model faces connected to it from which boundary layers grow.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \return                              1 if corner node, 0 otherwise.
 */
int V_isCornerONode(pVertex vertex);


/** \brief Get layer edges adjacent to the BL vertex.
 *
 *  Given a BL vertex, the function gets adjacent layer edges.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \param  layerEdges             (In/Out) Vector of layer edges.
 *
 */
void V_layerEdges(pVertex vertex, vector<pEdge>& layerEdges);


/** \brief Get layer faces adjacent to the BL vertex.
 *
 *  Given a BL vertex, the function gets adjacent layer faces.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \param  lyrFcs                 (In/Out) Vector of layer faces.
 *
 */
void V_layerFaces(pVertex vertex, vector<pFace>& lyrFcs);


/** \brief Get layer and transition faces adjacent to the BL vertex.
 *
 *  Given a BL vertex, the function gets adjacent layer and transition faces.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \param  lyrFcs                 (In/Out) Vector of layer and transition faces.
 *
 */
void V_layerAndTransitionFaces(pVertex curVD, vector<pFace>& lyrFcs);


/** \brief Get layer and transition faces adjacent to the BL vertex.
 *
 *  Given a BL vertex, specific growth level, the function gets adjacent layer and transition faces of the requested level.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \param  level                  (In)  BL level of the faces.
 *  \param  lyrFcs                 (In/Out) Vector of layer and transition faces.
 *
 */
void V_layerAndTransitionFaces(pVertex vertex, int level, vector<pFace>& lyrFcs);


/** \brief Get BL regions adjacent to the BL vertex.
 *
 *  Given a BL vertex, specific growth level, the function gets adjacent BL regions of the requested level.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \param  level                  (In)  BL level of the regions.
 *  \param  BLRegs                 (In/Out) Vector of BL regions.
 *
 */
void V_BLRegions(pVertex vertex, int level, vector<pRegion>& BLRegs);


/** \brief Get BL regions adjacent to the BL vertex.
 *
 *  Given a BL vertex, the function gets its adjacent BL regions.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \param  BLRegs                 (In/Out) Vector of BL regions.
 *
 */
void V_BLRegions(pVertex vertex, vector<pRegion>& BLRegs);


/** \brief Get regular (non BL) regions adjacent to the vertex.
 *
 *  Given a vertex, the function gets adjacent regular (non BL) regions.
 *
 *  \param  vertex                   (In)  Vertex.
 *  \param  nonBLRegs                (In/Out) Vector of regular (non BL) regions.
 *
 */
void V_nonBLRegions(pVertex vertex, vector<pRegion>& nonBLRegs);


void V_excludeLevelBLRegions(pVertex vertex, vector<pRegion>& exclBLRegs);


/** \brief Get layer and transition interface edges adjacent to the BL vertex.
 *
 *  Given a BL vertex, the function gets adjacent layer and transition interface edges.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \param  edgesBLIntfc           (In/Out) Vector of layer and transition interface edges.
 *
 */
void V_edgesAtBLInterface(pVertex vertex, vector<pEdge>& edgesBLIntfc);


/** \brief Get layer and transition interface faces adjacent to the BL vertex.
 *
 *  Given a BL vertex, the function gets adjacent layer and transition interface faces.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \param  facesBLIntfc           (In/Out) Vector of layer and transition interface faces.
 *
 */
void V_facesAtBLInterface(pVertex vertex, vector<pFace>& facesBLIntfc);


// vertex is at BL interface if it bounds atleast one non-BL region
// (possible to have NO non-BL edge, i.e., all BL edges, connected to vertex)
int V_atBLInterface(pVertex vertex);


/** \brief Get growth edge connected to the vertex, using the direction wrt the wall.
 *
 *  Given a BL vertex and the direction (1 is up, -1 is down), the function gets adjacent growth edge
 *  using the specified direction, which tells whether it is the lower or upper level growth edge wrt the BL wall.
 *
 *  \param  vertex                 (In)  BL vertex.
 *  \param  dir                    (In)  Direction to specify upper or lower growth edge.
 *  \return                              Growth edge.
 */
pEdge V_growthEdge(pVertex vertex, int dir);


/// Needs to be rewised!
void V_nonBLFacesOnBLSurfaces(pVertex vertex, vector<pFace>& nonBLFacesOnBLSurfaces);


void V_getAdjacentOrigVerts(pVertex vertex, vector<pVertex>& adjOrigVerts);


// get the value of lower limit on total thickness of boundary layer
// (at this "vtx")
double V_getLowerLimitOnTotThickness(pVertex vtx);


/** \brief Defines the type of an edge in BL, if any.
 *
 *  Given an edge, its BL classification is returned, if the edge belongs to any BL.
 *  If the edge is a regular edge in the unstructured mesh, the function returns 0.
 *
 *  \param  edge                   (In)  Edge.
 *  \return                              Edge classification in BL or 0.
 */
int E_typeInBL(pEdge edge);


/** \brief Gets the common face of two edges.
 *
 *  Given two edges, the function gets their common face. 
 *  DOES NOT use any BL mesh info. (can be used for a general mesh).
 *
 *  \param  edge1                  (In)  First edge.
 *  \param  edge2                  (In)  Second edge
 *  \return                              Common face, if any.
 */
pFace E_commonFace(pEdge edge1, pEdge edge2);


/** \brief Checks if the edge is at the BL interface.
 *
 *  Given an edge, the function checks whether it is at the BL interface.
 *
 *  \param  edge                   (In)  Edge.
 *  \return                              1 if the edge is at BL interface, or 0.
 */
int E_atBLInterface(pEdge edge);


/** \brief Get BL regions adjacent to the edge.
 *
 *  Given an edge, specific growth level, the function gets adjacent BL regions of the requested level.
 *
 *  \param  edge                   (In)  Edge.
 *  \param  level                  (In)  BL level of the regions.
 *  \param  BLRegs                 (In/Out) Vector of BL regions.
 *
 */
void E_BLRegions(pEdge edge, int level, vector<pRegion>& BLRegs);


/** \brief Get BL regions adjacent to the edge.
 *
 *  Given an edge, the function gets adjacent BL regions of the requested level.
 *
 *  \param  edge                   (In)  Edge.
 *  \param  BLRegs                 (In/Out) Vector of BL regions.
 *
 */
void E_BLRegions(pEdge edge, vector<pRegion>& BLRegs);


/** \brief Get layer and transition faces adjacent to the edge. 
 *
 *  Given an edge, specific growth level, the function gets adjacent layer and transition faces of the requested level.
 *
 *  \param  edge                   (In)  Edge.
 *  \param  level                  (In)  BL level of the faces.
 *  \param  lyrFcs                 (In/Out) Vector of layer and transition faces.
 *
 */
void E_layerAndTransitionFaces(pEdge edge, int level, vector<pFace>& lyrFcs);


/** \brief Get vertical face connected to the layer or interface edge, using the direction wrt the wall.
 *
 *  Given a layer or transition edge and the direction (1 is up, -1 is down), the function gets adjacent vertical face
 *  using the specified direction, which tells whether it is the lower or upper level growth edge wrt the BL wall.
 *
 *  \param  edge                   (In)  Layer or transition edge.
 *  \param  dir                    (In)  Direction to specify upper or lower growth edge.
 *  \return                              Vertical face.
 */
pFace E_verticalFace(pEdge edge, int dir);


// sameSurface is required for layer edges at corner
/** \brief Get layer (and transition) faces adjacent to the edge.
 *
 *  Given an edge, the function gets adjacent layer (and transition) faces of the requested level.
 *
 *  \param  edge                   (In)  Edge.
 *  \param  layerFaces             (In/Out) Vector of layer faces.
 *
 */
void E_layerFaces(pEdge edge, vector<pFace> &layerFaces, int transition=1, int sameSurface=1);


/** \brief Get faces at BL interface adjacent to the edge.
 *
 *  Given an edge, the function gets adjacent faces at BL interface.
 *
 *  \param  edge                   (In)  Edge.
 *  \param  layerFaces             (In/Out) Vector of layer faces.
 *
 */
void E_facesAtBLInterface(pEdge edge, vector<pFace>& blInterfaceFaces);


/** \brief Get regular (non BL) regions adjacent to the edge.
 *
 *  Given an edge, the function gets adjacent regular (non BL) regions.
 *
 *  \param  edge                   (In)  Edge.
 *  \param  nonBLRegs              (In/Out) Vector of regular (non BL) regions.
 *
 */
void E_nonBLRegions(pEdge edge, vector<pRegion>& nonBLRegs);


/** \brief Correct BL type and level of the edge.
 *
 *  Given an edge, the function corrects its BL type and level, if necessary.
 *
 *  \param  edge                   (In)  Edge.
 *
 */
void E_correctTypeAndLevelInBL(pEdge edge);


/** \brief Defines the type of a face in BL, if any.
 *
 *  Given a face, its BL classification is returned, if the face belongs to any BL.
 *  If the face is a regular face in the unstructured mesh, the function returns 0.
 *
 *  \param  face                   (In)  Face.
 *  \return                              Face classification in BL or 0.
 */
int F_typeInBL(pFace face);


/** \brief Checks if the face is at the BL interface.
 *
 *  Given a face, the function checks whether it is at the BL interface.
 *
 *  \param  face                   (In)  Face.
 *  \return                              1 if the edge is at BL interface, or 0.
 */
int F_atBLInterface(pFace face, int *side=0);


// do NOT use any BL info. (can be used for a general mesh)
// seems there is one in adaptUtil (F_otherRgn)
pRegion F_otherRegion(pFace face, pRegion region);


/** \brief Gets the opposite face of the specified prism and its face.
 *
 *  Given a face and a prism, the function gets the opposite face.
 *  Does NOT use any BL info. (can be used for a general mesh).
 *
 *  \param  face                   (In)  Face.
 *  \param  region                 (In)  Region (must be prism)
 *  \return                              Opposite face.
 */
pFace F_otherTriFcPrism(pFace face, pRegion region);


/** \brief Gets the opposite face of the specified pyramid and its face.
 *
 *  Given a face and a pyramid, the function gets the opposite face.
 *  Does NOT use any BL info. (can be used for a general mesh).
 *
 *  \param  face                   (In)  Face.
 *  \param  region                 (In)  Region (must be pyramid)
 *  \return                              Opposite face.
 */
pFace F_otherTriFcPyramid(pFace face, pRegion region);


/** \brief Correct BL type and level of the face.
 *
 *  Given a face, the function corrects its BL type and level, if necessary.
 *
 *  \param  face                   (In)  Face.
 *
 */
void F_correctTypeAndLevelInBL(pFace face);


/** Checks whether face swap is OK or not
 *
 *  The function checks whether face swap is OK To avoid TWO2TWO case in face swap mode 
 *  for non-BL faces connected to interface edges
 *
 *  \param  face                   (In)  Face.
 *
 */
int F_checkForTwo2TwoSwap(pFace face, pEdge edge=0);


// do NOT use any BL info. (can be used for a general mesh)
int F_isPointInside(pFace face, double *xyz);


/** \brief Defines if a region belongs to any BL
 *
 *  Given an entity, the functions defines whether the region is a part of any BL.
 *
 *  \param  ent                    (In)  Entity of any dimention.
 *  \return                              1 if entity belongs to any BL, and 0 otherwise.
 */
int R_isBLEntity(pRegion ent);


/** \brief Defines the type of a region in BL, if any.
 *
 *  Given a region, its BL classification is returned, if the region belongs to any BL.
 *  If the region is a regular region in the unstructured mesh, the function returns 0.
 *
 *  \param  region                 (In)  Region.
 *  \return                              Region classification in BL or 0.
 */
int R_typeInBL(pRegion region);


/// Region level in BL
int R_levelInBL(pRegion reg);


int R_isPointInside(pRegion region, double *xyz);


/** \brief Get a boundary layer, if any, using the entity provided.
 *
 *  Given an entity, the function returns the boundary layer it belongs to, if any.
 *
 *  \param                         (In)  Entity of any dimention.
 *  \return                              Pointer to a boundary layer, or 0x0
 */
pBLayer EN_getBL(pEntity ent);


int M_getNumBLs(pMesh pmesh);


// do NOT use any BL info. (can be used for a general mesh)
// if point lies inside return :
// 1 - purely inside region
// 2 - purely inside one of the face
// 3 - purely inside one of the edge
// 4 - on one of the vertex
// this routine assumes four verts, i.e., tet. element
// (other element topologies can be broken/sub-divided into child tets.)
int XYZ_isPointInside(dArray *X_Y_Z, double *xyz);


// do NOT use any BL info. (can be used for a general mesh)
// see combination : <return value> - <where point lies >
// 1 - purely inside face
// 2-v0, 3-v1, 4-v2
// 5-e0, 6-e1, 7-e2
int XYZ_isPointInsideTriangle(double tri_xyz[3][3], double *xyz);


double XYZ_volume2(dArray *X_Y_Z, int rTopoType);


/// Calculate the nurmal unstructured height to the growth curve
double BL_GetNormalUnstrHeight(pVertex pVertexVtx, double dNormal[3]);


/// Limit the first layer thickness if needed
void BL_LimitFirstLayerThickness(double dCurFirstLayerThickness, double &dPropFirstLayerThickness, double dGrowthFactor, double dNormalUnstr, int iNumLayer);


void BL_CalcThicknessesUsingFirstThicknessAndGrowthFactor(double firstLayerThickness, double dGrowthFactor, double *thicknesses, int listSize);


void BL_geomProg(double h0, double H, int nLayers, double *height, double rmin, double rmax, int h0flag);


double BL_rtNewton(double fmx, double fmin, double dfm, int npt);


void Mesh_GetNormalVectorOfOrigVtx(pMesh pmesh);


void GC_getAvgGrowthEdgeDir(vector<pVertex> nodesOnGC, double *avgDir);


// return 1 if normal vector is defined/applicable
void GC_getNormalVector(pVertex oNode, double *normal);


void GC_setNormalVector(pVertex oNode, double *normal);


void GC_getClassification(vector<pVertex>& nodesOnGC, int &type, int &tag);


double GC_getTotalThickness(vector<pVertex>& nodesOnGC);


/** \brief Get the zero-level (bottom) face of a boundary layer
 *
 *  Given a specific boundary layer, the function gets its zero-level face.
 *
 *  \param  pbl                     (In)  Boundary layer pointer.
 *  \return                               Zero-level face.
 */
pFace BL_GetZeroLvlFace(pBLayer pbl);


/** \brief Get the top (interface) face of a boundary layer
 *
 *  Given a specific boundary layer, the function gets its interface face
 *  which is the upper one on the top region in the stack.
 *
 *  \param  pbl                     (In)  Boundary layer pointer.
 *  \return                               Interface face.
 */
pFace BL_GetTopFace(pBLayer pbl);


void BL_GetLayerFaces(pFace pFaceBotFace, vector<pFace>& facesStack);


void BL_GetStackRgns(pFace pFaceBotFace, vector<pRegion>& rgnStack);


/** \brief Get the stack of triangular horizontal (layer) faces
 *
 *  Given a specific boundary layer, the function gets horizontal (layer) faces
 *  of the entities within the BL. It returns faces in the order from the botom most 
 *  to the top one.
 *
 *  \param  pbl                     (In)  Boundary layer pointer.
 *  \param  facesStack              (In/Out)  Vector of a stack of faces.
 */
void BL_getHorizontalFaces(pBLayer pbl, vector<pFace>& facesStack);


/// Get the stack of quad vertical faces based on the zero level edge provided, assuming BL consists of PRISMs, not developed completely.
void BL_getVerticalFacesByZeroLevelEdge(pBLayer pbl, pEdge edge, vector<pFace>& facesStack);


/** \brief Get vertical faces in an arbitrary order based on the edge provided.
 *
 *  Given an edge, the function gets a stack of vertical faces. The input edge can be either
 *  layer (eLAYER) or transition (eTRANSITION) one, and belong to at least one BL. 
 *  The vertical faces in the stack are not sorted in any specific order. The order depends
 *  on the location of the input edge in the BL.
 *
 *  \param  edge                    (In)  Input edge.
 *  \param  facesStack              (In/Out)  Vector of a stack of faces.
 */
void BL_getVerticalFacesByEdge(pEdge edge, vector<pFace>& facesStack);


/** \brief Get a set of horizontal edges in an arbitrary order based on the edge provided.
 *
 *  Given an edge, the function gets a stack of horizontal (layer) edges. The input edge can be either
 *  layer (eLAYER) or transition (eTRANSITION) one, and belong to at least one BL.
 *  The horizontal edges in the stack are not sorted in any specific order. The order depends
 *  on the location of the input edge in the BL.
 *
 *  \param  edge                    (In)  Input edge.
 *  \param  edgesStack              (In/Out)  Vector of a stack of edges.
 */
void BL_getHorizontalEdgesByEdge(pEdge edge, vector<pEdge>& edgesStack);


/** \brief Get growth curve edges.
 *
 *  Given a BL vertex, the function gets a stack of growth edges of the growth curve. The input vertex can be 
 *  any BL vertex on the growth curve. The originating node is then identified,
 *  and the growth edges are given in the order the growth curve grows from the wall.
 *
 *  \param  vertex                  (In)  Input vertex.
 *  \param  edgesStack              (In/Out)  Vector of a stack of growth edges.
 */
void BL_getGrowthCurveEdges(pVertex vertex, vector<pEdge>& edgesStack);


/** \brief Get growth curve nodes.
 *
 *  Given a BL vertex, the function gets a stack of growth curve nodes. The input vertex can be
 *  any BL vertex on the growth curve. The originating node is then identified,
 *  and the growth curve nodes are given in the order the growth curve grows from the wall.
 *
 *  \param  vertex                  (In)  Input vertex.
 *  \param  vtxStack                (In/Out)  Vector of a stack of growth curve nodes.
 */
void BL_getGrowthCurveNodes(pVertex vertex, vector<pVertex>& vtxStack);


/** \brief Get growth curve nodes from the stack of growth edges.
 *
 *  Given a stack of growth edges, the function gets a stack of growth curve nodes.
 *  The growth edges must be given in the order the growth curve grows from the wall.
 *
 *  \param  edgesStack              (In)  Vector of a stack of growth edges.
 *  \param  vtxStack                (In/Out)  Vector of a stack of growth curve nodes.
 */
void BL_getGCNodesFromGCEdges(vector<pEdge>& edgesStack, vector<pVertex>& vtxStack);


/** \brief Categorization of BL entities of a single BL.
 *
 *  Given a BL, the function categorizes its entities based on the classification of
 *  regions, faces and edges (see blEdgeType, etc.).
 *
 *  \param  pbl                      (In)  Input BL.
 */
void BL_CategorizeBLEntities(pBLayer pbl);


/** \brief Categorization of BL entities for the whole mesh.
 *
 *  Given a mesh, the function categorizes boundary layer entities based on the classification of
 *  regions, faces and edges (see blEdgeType, etc.). 
 *
 *  \param  pmesh                    (In)  Input mesh.
 */
void Mesh_CategorizeBLEntities(pMesh pmesh);


/** \brief Detection and labeling of corner nodes.
 *
 *  Given a mesh and a model, the function detects and labels corner nodes - two model faces on which BLs grow adjacent to the model vertex. 
 *
 *  \param  pmesh                    (In)  Input mesh.
 *  \param  model                    (In)  Input model.
 */
void Mesh_DetectAndLabelCornerNodes(pMesh pmesh, pGModel model);


/** \brief Unlabling of corner nodes.
 *
 *  Given a mesh and a model, the function unlables corner nodes. 
 *
 *  \param  pmesh                    (In)  Input mesh.
 *  \param  model                    (In)  Input model.
 */
void Mesh_UnlabelCornerNodes(pMesh mesh, pGModel model);


#ifdef MA_PARALLEL
/** \brief Collect and update BL entities on the boundary. 
 *
 *  Given a mesh, the function updates the information about boundary layer entities (vertexes, edges, faces)
 *  on a partition boundary. This information is useful in parallel since interface region can be 
 *  on a separate part from its boundary layer, and even though it shares entities
 *  with the top-most layer surface of a stack, as a part of interface element it does not belong 
 *  to any of the stack elements.
 *
 *  \param  pmesh                    (In)  Input mesh.
 */
void Mesh_UnifyBLInterfaceOnCB(pMesh pmesh);
#endif


/** \brief Construction of entity sets for BLs based on the entity set implementation.
 *
 *  Construction of entity sets for BLs based on the following steps:
 *    -  Loop over all growth curves and recover BLs from them.
 *    -  Based on adjacency, construct the initial entity set EG_{k} from the prism elements on top of the surface face M_{i}^{2}.
 *
 *  \param  mesh                     (In)  Input mesh.
 */
int Mesh_ConstructBLs_EntSet(pMesh mesh);


/** \brief Assign a level in a stack to all the boundary layer entities inside.
 * 
 *  Given a boundary layer, the function assigns the stack level (if none is assigned) to all the
 *  boundary layer entities whithin the stack of the boundary layer.
 *
 *  \param  pbl                      (In)  Boundary layer.
 */
void BL_AssignBLLevelsToEnts(pBLayer pbl);


/// Same as above but applied to all BLs in the mesh.
void Mesh_AssignBLLevelsToAllBLEnts(pMesh mesh);


/** @brief Initialization of boundary layers.
 *
 *  @remark Given an input mesh and a model, the function provides initial important routines needed to correctly
 *  construct and work with boundary layers. This includes: construction of boundary layers, their categorization, 
 *  assigning levels, unification of BL entities on the boundary.
 *
 *  @param  pMeshMesh                (In)  Input mesh.
 */
void Mesh_InitBLs(pMesh pMeshMesh, pGModel model, int iFromTopo=0);


#ifdef MA_PARALLEL
/** \brief Get the set of top-most nodes of growth curves connected to hanging BL vertices.
 *
 *  Given a mesh, the function gets the set of top-most nodes of growth curves connected to 
 *  hanging BL vertices across the boundary.
 *
 *  \param  pMeshMesh                 (In)  Input mesh.
 *  \param  SetTopVerts               (In)  Set of top-most GC nodes.
 */
void Mesh_GetBLTopVertConnToBLHangingVert(pMesh pMeshMesh, std::set<pVertex> &SetTopVerts);
#endif


/** \brief Clear BL levels of hanging on the partition boundary entities.
 *
 *  Given a mesh, the function clears BL levels of hanging on the partition boundary entities.
 *
 *  \param  pMeshMesh                 (In)  Input mesh.
 */
void Mesh_ClrHangingBLEntLvl(pMesh pMeshMesh);


/// For debugging: check several consistencies between remote copies of entities in BLs

/** \brief Check all the edges in the mesh and their vertexes for being consistent if they are part of any BL.
 * 
 *  Given a mesh, the function loops over its edges and if the edge is a BL edge, it is checked for the 
 *  vertexes to be BL vertexes as well. If any inconsistency is found, the function prints out a message
 *  and terminates the program.
 *
 *  \param  mesh                     (In)  Input mesh.
 */
void M_checkBLEdgesAndVerts(pMesh mesh);


/** \brief Check the BL faces for having more than 2 adjacent regions and whether the adjacent regions are BL ones.
 * 
 *  Given a mesh, the function checks the BL faces for having more than 2 adjacent regions. It also checks for the adjacent
 *  regions to be the BL regions. If any inconsistency is found, the function prints out a message and terminates the program.
 *
 *  \param  mesh                     (In)  Input mesh.
 */
void M_checkBLFacesAndAdjRegions(pMesh mesh);


/** \brief Check the boundary layer entities in the stack for the consistent labeling.
 * 
 *  Given a boundary layer, the function checks for its entities in the stack to have a consistent labeling, i.e.
 *  if there is an entity of the BL which is either not a BL entity or does not have any BL level,
 *  the function prints out a message and terminates the program.
 *
 *  \param  pbl                      (In)  Boundary layer.
 */
void BL_checkBLStructure(pBLayer pbl);


/// Same as above but applied to all BLs in the mesh.
void M_checkBLStructure(pMesh mesh);


/** \brief Check the prism regions to be part of a BL if one of their faces is on the surface.
 *
 *  Given a mesh, the function loops over its faces on the model boundary, and when encounteres the prismatic region,
 *  checks it for being a part of any BL. If it is not, the function prints out a message and terminates the program.
 *
 *  \param  mesh                     (In)  Input mesh.
 */
void M_checkBLPresence(pMesh mesh);


/** \brief Check splitted BL faces and regions for their consistency.
 *
 *  Given a mesh, the function loops over its boundary layers and checks whether each of its layer or transition
 *  face which is not on the doundary has no less than two regions adjacent to it.
 *
 *  \param  mesh                     (In)  Input mesh.
 */
void M_checkBLSplitFaces(pMesh pmesh);


void checkEGRemCps(pMesh mesh, pMeshDataId ptr_reff, pMeshDataId int_reff);

int Mesh_CheckVtxCoordsOnPB(pMesh pmesh);

#endif

