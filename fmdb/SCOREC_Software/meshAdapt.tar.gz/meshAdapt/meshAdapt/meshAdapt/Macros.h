#ifndef __Macros
#define __Macros

#define MAX(x,y) ((x)<(y) ? (y) : (x))
#define MIN(x,y) ((x)>(y) ? (y) : (x))
#define ABS(x) ((x) < 0 ? -(x) : (x))

/* define NULL */
#ifndef NULL
#define NULL 0
#endif

#endif


#ifndef __Defines
#define __Defines

/* tolerance indicating m/c precision */
#ifndef TOLRENCE
#define TOLRENCE 1.0e-14
#endif

#ifndef DTOLRENCE
#define DTOLRENCE 1.0e-50
#endif

#ifndef MTBIG
#define MTBIG 1.0e20
#endif

#endif



#ifndef __meshAdaptDefines
#define __meshAdaptDefines

/* acceptable thresholds by local modification and meshAdapt*/
#define ACPT_MEANRATIO 0.001              //0.01
#define MAX_PERIODIC_SPAN 0.3333            // should <= 1/3
#define IMPROVE_RATIO 1.3

/* #define PI 3.141596 */
#define Dh_179 -0.99984769516
#define Dh_175 -0.99619469809
#define Dh_170 -0.98480775301
#define Dh_160 -0.93969262079
#define Dh_150 -0.86602540378
#define Dh_140 -0.76604444312
#define Dh_130 -0.64278760969
#define Dh_120 -0.5
#define Dh_110 -0.34202014333
#define Dh_100 -0.17364817767
#define Dh_90 0.0
#define Dh_80 0.17364817767
#define Dh_70 0.34202014333
#define Dh_60 0.5

#endif


