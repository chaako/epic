#include "VertMotionMod.h"
#include "AdaptUtil.h"
#include "fromMeshTools.h"
#include <iostream>
#include <stdio.h>

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif

using std::cout;
using std::endl;
using std::cerr;

vertMotionsMod::vertMotionsMod(const vertMotionsMod &x)
  : locMeshMod(x.mesh,x.pSizeField,0,0)
{
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;    
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;

  s=x.s;

  for(int i=0; i<s; i++) {
    vert[i]=x.vert[i];
    target[i][0]=x.target[i][0];
    target[i][1]=x.target[i][1];
    target[i][2]=x.target[i][2];
  }
}



vertMotionsMod::vertMotionsMod(pMesh p, pSField mf, int n, pVertex *v, double t[][3])
  : locMeshMod(p,mf,0,0)
{
  s=n;

  for(int i=0; i<s; i++) {
    vert[i]=v[i];
    target[i][0]=t[i][0];
    target[i][1]=t[i][1];
    target[i][2]=t[i][2];
  }
}

vertMotionsMod::vertMotionsMod(pMesh p, pSField mf, pVertex v0, pVertex v1, 
			       double t0[3],double t1[3])
  : locMeshMod(p,mf,0,0)
{
  s=2;

  vert[0]=v0;
  vert[1]=v1;
  target[0][0]=t0[0];
  target[0][1]=t0[1];
  target[0][2]=t0[2];
  target[1][0]=t1[0];
  target[1][1]=t1[1];
  target[1][2]=t1[2];
}


/*
  note: for a vertex on model region, "target" hold the coordinates in world space
        for a vertex on model face, "target" hold the coordinates in parametric space
*/
int vertMotionsMod::apply()
{
  int i;
  pPoint point;

  for(i=0; i<s; ++i) {
    if (!EN_okTo(MOVE,(pEntity)vert[i]))
      continue;
#ifdef MA_PARALLEL
    if( EN_onCB((pEntity)vert[i]) ) {
      printf("Info: Not considered yet vertMotionsMod::apply()\n");
      return 0;
    }
#endif
    switch (V_whatInType(vert[i])) {
    case Tregion:
      adaptUtil::move_vertex(vert[i], target[i],CB_move,userData_CB_move);
      break;
    case Tface:
      point= V_point(vert[i]);
      P_setParam2(point,target[i][0],target[i][1],(int)target[i][2]);
      printf("WARNING: need activate callback function!!!\n");
      // make sure in meshSim that above function automatically move the coordinates
      // in world space
      break;
    default:
      cerr << "moving vertex classified on model vertex and model edge is not permitted" << endl;
    }
  }

  return 1;
}

void vertMotionsMod::insert(pVertex vt, double t[3])
{
  if(s > 5)
    cerr<<"vertMotionMod::insert - number of vertices to be moved exceeds 4"<<endl;

  vert[s]=vt;
  target[s][0]=t[0];
  target[s][1]=t[1];
  target[s][2]=t[2];

  ++s;
}

int vertMotionsMod::inList(pVertex vt)
{
  int i;

  for(i=0; i<s; i++)
    if(vert[i] == vt) return 1;

  return 0;
}
