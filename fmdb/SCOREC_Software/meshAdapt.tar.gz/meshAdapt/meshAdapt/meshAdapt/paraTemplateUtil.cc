/*<i> ****************************************************************************
 *
 *  templateUtil/paraTemplateUtil.cc
 *  Created by Seegyoung Seol, on Tue May 11 2004, 10:26:37 EDT
 *
 *  Copyright (c) 2004, Scientific Computation Research Center
 *
 *  <a href="http://www.scorec.rpi.edu" CLASS="nav">www.scorec.rpi.edu</a>
 *
 *  File Content: parallel size field helper operators
 *
 *************************************************************************** </i>*/
#include "paraTemplateUtil.h"
#include "fromMeshTools.h"
#include "MeshSize.h"
#include <stdio.h>
#include <iostream>
#include <math.h>

#ifdef AOMD_
#include <assert.h>
#include "FMDB_cint.h"
#include "FMDB_Internals.h"
#include "ParUtil.h"
#ifdef MA_PARALLEL
using std::vector;
#include "paraAdapt.h"
#include "pmDataExchanger.h"
#include "pmMigrationCallbacks.h"
#endif
#endif

using std::cout;
using std::endl;
using std::cerr;

void printSize(pEntity ent, pMSize pS)
{
#ifdef AOMD_
  double h[3];
  double dirs[3][3];
  double* e;
  int i,j;

  for( i=0; i<3; i++ ) {
    h[i]=pS->size(i);
    e=pS->eigenvector(i);
    for( j=0; j<3; j++ )
      dirs[i][j]=e[j];
  }  
  cout<<"("<<P_pid()<<") V"<<EN_id(ent)
      <<"["<<h[0]<<","<<h[1]<<","<<h[2]<<"]["
      <<dirs[0][0]<<","<<dirs[0][1]<<","<<dirs[0][2]<<"/"
      <<dirs[1][0]<<","<<dirs[1][1]<<","<<dirs[1][2]<<"/"
      <<dirs[2][0]<<","<<dirs[2][1]<<","<<dirs[2][2]<<"]\n";
#endif
}

#ifdef AOMD_
int identicalSizeField;

#ifdef MA_PARALLEL

int sfExchanger::msg_size()
{
  return sizeof(smoothPack);
}

void sfExchanger:: fill_buffer(pEntity ent, int src, int dest, pEntity remoteEnt, void *&msg_send)
{
  pMSize metric = pSizeField->getSize((pVertex)ent);
  double sizes[3];
  double dirs[3][3];
  double* e;
  int i,j;

//  cout<<"("<<P_pid()<<") SEND: "; printSize(ent, metric);
  for( i=0; i<3; i++ ) {
    sizes[i]=metric->size(i);
    e=metric->eigenvector(i);
    for( j=0; j<3; j++ )
      dirs[i][j]=e[j];
  }

  smoothPack *castbuf=(smoothPack *)msg_send;
  castbuf->vertex=remoteEnt;
  for( i=0; i<3; i++ ) {
    castbuf->h[i]=sizes[i];
    for( j=0; j<3; j++ )
       castbuf->e[i][j]=dirs[i][j];
  }
}

void sfExchanger::receiveData (void *msg_recv, int pid_from)
{
  smoothPack* castbuf = (smoothPack*)msg_recv;

  pMSize metric = pSizeField->getSize((pVertex)castbuf->vertex);
  double sizes[3];
  double dirs[3][3];
  double* e;
  int i,j;
  double v1, v2;
   
  int oppositeSign;
  for( i=0; i<3; i++ ) {
    sizes[i]=metric->size(i);
    e=metric->eigenvector(i);
    for( j=0; j<3; j++ )
      dirs[i][j]=e[j];
  }

  for( i=0; i<3; i++ ) {
    sizes[i]=metric->size(i);
    if (sizes[i]!=castbuf->h[i])
    {
      cout<<"("<<P_pid()<<") TR FATAL ERROR: metric mismatch of V"
            <<EN_id(castbuf->vertex)
            <<" h["<<i<<"] on P"<<P_pid()<<" = "<<sizes[i]
            <<", P"<<pid_from<<" = "<<castbuf->h[i]<<endl;
       identicalSizeField = 0;	    
    }
  }
}
#endif

//
// added by seole 04/30/04
//
// size field exchanger
//  - check the consistency of size field of common boundary entitiws
//

// Result: return true if all vertices have size field and consistent in terms
//         of partition boundary


bool M_checkSizeField(pMesh mesh, pSField pSizeField)
{
#ifdef DEBUG
  if (!SCUTIL_CommRank())
  {
    cout<<"\n****************************\n";
    cout<<"    M_checkSizeField - ";
  }
  double t1 = ParUtil::Instance()->wTime();
#endif
  int ret=0;
  VIter iter=M_vertexIter(mesh);
  pVertex v;
  pMSize metric;
  identicalSizeField = 1;
#ifdef MA_PARALLEL
  vector<pEntity> verticesOnCB;
#endif
  while( (v=VIter_next(iter)) )
  {
    metric = pSizeField->getSize(v);
    if (!metric)
    {
      cout <<"("<<P_pid()<<") FATAL ERROR: Size Field is not defined with V"
           <<EN_id((pEntity)v)<<endl;
    }
    assert(metric);
#ifdef MA_PARALLEL
    if (EN_duplicate((pEntity)v));
    {
      verticesOnCB.push_back(v);
    }
#endif
  }
  VIter_delete(iter);
#ifdef MA_PARALLEL
  sfExchanger deCallback(pSizeField);
  genericDataExchanger(verticesOnCB.begin(), verticesOnCB.end(), deCallback);
#endif
#ifdef DEBUG
  double t2 = ParUtil::Instance()->wTime();
#endif
  int global = P_getMinInt(identicalSizeField);
#ifdef DEBUG
  if (!SCUTIL_CommRank())
  {
    if (global==0)
      cout<<"  FALSE \n";
    else
      cout<<"  TRUE \n";
    cout<<"   (t = "<<t2-t1<<" sec)\n";
    cout<<"****************************\n";
  }
#endif
  if (global==0) return false;
  return true;
}
#ifdef MA_PARALLEL

int numLocalSFCorrection;

int sfUnifier::msg_size()
{
  return sizeof(smoothPack);
}

void sfUnifier::fill_buffer(pEntity ent, int src, int dest, pEntity remoteEnt, void *&msg_send)
{
  pMSize metric = pSizeField->getSize((pVertex)ent);
  double sizes[3];
  double dirs[3][3];
  double* e;
  int i,j;

//  cout<<"("<<P_pid()<<") SEND: "; printSize(ent, metric);
  for( i=0; i<3; i++ ) {
    sizes[i]=metric->size(i);
    e=metric->eigenvector(i);
    for( j=0; j<3; j++ )
      dirs[i][j]=e[j];
  }

  smoothPack *castbuf=(smoothPack *)msg_send;
  castbuf->vertex=remoteEnt;
  for( i=0; i<3; i++ ) {
    castbuf->h[i]=sizes[i];
    for( j=0; j<3; j++ )
       castbuf->e[i][j]=dirs[i][j];
  }
}

void sfUnifier::receiveData (void *msg_recv, int pid_from)
{
  smoothPack* castbuf = (smoothPack*)msg_recv;

  double rmtH[3];
  double rmtDir[3][3];
  int i,j;
  pEntity vt = (pEntity) castbuf->vertex;
  int oppositeSign;
  for( i=0; i<3; i++ ) {
    rmtH[i]=castbuf->h[i];
    for( j=0; j<3; j++ )
      rmtDir[i][j]=castbuf->e[i][j];
  }
  pMSize rmtM=new MeshSize(castbuf->e,castbuf->h);
  pSizeField->setSize(vt,rmtM);
  ++numLocalSFCorrection;
}

// this is called in PWLsfield::anisosmooth
int M_unifySizeField(pMesh mesh, pSField pSizeField)
{
   // local number of size field correction
  int numGSFCorrection=0; // global number of size field correction
#ifdef DEBUG  
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_unifySizeField - ");
#endif
  int ret=0;
  VIter iter=M_vertexIter(mesh);
  pVertex vt;
  pMSize metric;

  vector<pEntity> verticesOnCB;
  while( (vt=VIter_next(iter)) )
  {
    if (EN_duplicate((pEntity)vt) && EN_owner((pEntity)vt)==P_pid())
      verticesOnCB.push_back(vt);
  }
  VIter_delete(iter);
  numLocalSFCorrection=0;

  sfUnifier deCallback(pSizeField);
  genericDataExchanger(verticesOnCB.begin(), verticesOnCB.end(), deCallback);

#ifdef DEBUG
  int numGlobalSFCorrection = P_getSumInt(numLocalSFCorrection);
  ParUtil::Instance()->Msg(ParUtil::INFO," %d metrics corrected \n",
  numGlobalSFCorrection);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n");
#endif
  return true;
}

#endif /* MA_PARALLEL */
#endif /* AOMD */
