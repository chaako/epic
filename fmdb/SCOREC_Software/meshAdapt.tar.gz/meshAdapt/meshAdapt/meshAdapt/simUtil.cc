#include "simUtil.h"
#include <iostream>

#include "PList.h"
#include "modeler.h"

using std::cout;
using std::endl;

void GM_print(pGModel model, int level)
{
  switch(level)
  {
    case 0: GM_printVertices(model); break;
    case 1: GM_printEdges(model); break;
    case 2: GM_printFaces(model); break;
    case 3: GM_printRegions(model); break;
    default: GM_printVertices(model);
            GM_printEdges(model);
	    GM_printFaces(model);
	    GM_printRegions(model);
	    break;
  }
}

void GM_printVertices(pGModel model)
{
  cout<<"\n********** GVertices ***********\n";
  cout<<"# model vertices: "<<GM_numVertices(model)<<endl;
  pGVertex gvertex;
  double xyz[3];
  // write out gvertices     
  GVIter gvit = GM_vertexIter(model);
  while (gvertex = GVIter_next(gvit))
  {
    GV_point(gvertex, xyz);
    cout<<"gtype: "<< GEN_type((pGEntity)gvertex)<<", "
//         <<"gid: "<<GEN_id((pGEntity)gvertex)<<", "
	 <<"gtag: "<<GEN_tag((pGEntity)gvertex)<<", "
         <<"coord: ["<<xyz[0]<<","<<xyz[1]<<","<<xyz[2]<<"]\n";
  }
  GVIter_delete(gvit);
  cout<<endl;  
  cout<<"********************************\n";
}
  
void GM_printEdges(pGModel model)
{
  cout<<"\n********** GEdges ***********\n";
  cout<<"# model edges: "<<GM_numEdges(model)<<endl;
  pGEdge gedge;
  pGVertex gvertex;
    
  double u, v;
  // write out gvertices     
  GEIter geit = GM_edgeIter(model);
  while (gedge = GEIter_next(geit))
  {
    cout<<"GE "<<GEN_tag((pGEntity)gedge)<<": ";
    cout<<" (gtype: "<<GEN_type((pGEntity)gedge)<<")\n ";
    pPList gevertices = GE_vertices(gedge);
    void* iter=0;
    cout<<"\tadj GV: (";
    while (gvertex=(pGVertex)PList_next(gevertices,&iter))
    {
      cout<<"GV "<<GEN_tag((pGEntity)gvertex)<<",";
    }
    cout<<") \n";

    GE_parRange((pGEdge)gedge,&u,&v);
    cout<<"\tparRange ["<<u<<","<<v<<"]\n";
    
  }
  GEIter_delete(geit);
  cout<<endl;  
  cout<<"********************************\n";
}

void GM_printFaces(pGModel model)
{
  cout<<"\n********** GFaces ***********\n";
  cout<<"# model faces: "<<GM_numFaces(model)<<endl;
  pGFace gface;
  pGVertex gvertex;
  
  double frange[2][2];
  // write out gvertices     
  GFIter gfit = GM_faceIter(model);
  while (gface = GFIter_next(gfit))
  {
    cout<<"GF "<<GEN_tag((pGEntity)gface)<<": ";
    cout<<" (gtype: "<<GEN_type((pGEntity)gface)<<")\n ";
    pPList gfvertices = GF_vertices(gface);
    void* iter=0;
    cout<<"\tadj GV: (";
    while (gvertex=(pGVertex)PList_next(gfvertices,&iter))
    {
      cout<<"GV "<<GEN_tag((pGEntity)gvertex)<<",";
    }
    cout<<") \n";

    GF_parRange(gface,0,&frange[0][0],&frange[0][1]);
    GF_parRange(gface,1,&frange[1][0],&frange[1][1]);
    
    cout<<" GF_parRange = ["<<frange[0][0]<<", "<<frange[0][1]    
	    <<"] ["<<frange[1][0]<<", "<<frange[1][1]<<"]\n";
    
  }
  GFIter_delete(gfit);
  cout<<endl;  
  cout<<"********************************\n";
}

void GM_printRegions(pGModel model)
{
  cout<<"Not implemented yet\n";
}
