#include "analyticalSField.h"
#include "MeshTools.h"
#include "MeshSize.h"
#include <math.h>
#include <stdio.h>

// Length Square computation

double analyticalSField::lengthSq(pEdge e) 
{ 
  dArray exyz[2];
  V_coord(E_vertex(e,0),exyz[0]);
  V_coord(E_vertex(e,1),exyz[1]);
  return lengthSq(exyz[0],exyz[1],0);
}

double analyticalSField::lengthSq(pVertex v0,pVertex v1)
{
  dArray exyz[2];
  V_coord(v0,exyz[0]);
  V_coord(v1,exyz[1]);
  return lengthSq(exyz[0],exyz[1],0);  
}


double analyticalSField::lengthSq(dArray loc1, dArray loc2, pMSize, pMSize)
{ return lengthSq(loc1,loc2,0); }


double analyticalSField::lengthSq(dArray loc1, dArray loc2, pMSize pS)
{
  double vec[3],tvec[3];
  diffVt(loc1,loc2,vec);
  if( !pS ) 
    {
      dArray c;
      int i;
      // this is one point rule 
      for(i=0;i<3;i++)
	c[i]=0.5*(loc1[i]+loc2[i]);
      pS=(*sfunc)(c);
      pS->transform(vec,tvec);
      delete pS;
    }
  else
    pS->transform(vec,tvec);

  return dotProd(tvec,tvec);
}


// Area Square computation

double analyticalSField::areaSq(pFace f)
{ 
  dArray fxyz[3];
  F_coord(f,fxyz);
  return areaSq(fxyz,0,0);
}


double analyticalSField::areaSq(dArray fxyz[3], pMSize pS, dArray posDir)
{
  double v01[3],v02[3],nor[3];
  double areaS, detSq;
  double dcos[3], h[3];
  int j, flag=0;

  diffVt(fxyz[1],fxyz[0],v01) ;
  diffVt(fxyz[2],fxyz[0],v02) ;
  // compute normal
  crossProd(v01,v02,nor);
  // compute area square in physical space
  if( posDir && dotProd(posDir,nor) < mtol )
    return 0;
  else      
    areaS = 0.25*dotProd(nor,nor) ;

  if( areaS < mtol )
    return 0;

  // get the mesh size at center of fxyz in case not given
  if( !pS ) {
    for(j=0;j<3;j++)
      v01[j]=(fxyz[0][j]+fxyz[1][j]+fxyz[2][j])/3.0;
    pS=(*sfunc)(v01);
    flag=1;
  }

  // normalize the norm
  normVt(nor,nor);  // can save a dotProd by making use of area

  // compute the determinant of Jacobi
  for( j=0; j<3; j++ ) {
    dcos[j]=dotProd(nor,pS->eigenvector(j));
    h[j]=pS->size(j);
  }
  dcos[0] /= (h[1]*h[2]);
  dcos[1] /= (h[0]*h[2]);
  dcos[2] /= (h[1]*h[0]);
  detSq = dotProd(dcos,dcos);
  
  if( flag )
    delete pS;

  // return the area in transformed space
  return detSq*areaS;

}


// volume compuation 

double analyticalSField::volume(pRegion r)
{ 
  dArray rxyz[4];
  R_coord(r,rxyz);
  return volume(rxyz,0);
}

double analyticalSField::volume(dArray rxyz[4], pMSize pS)
{   
  double invDet,c[3];
  double vol=XYZ_volume(rxyz);
  if( vol<mtol )
    return 0;

  if(!pS) 
    { 
      for(int j=0;j<3;j++)
	c[j]=(rxyz[0][j]+rxyz[1][j]+rxyz[2][j]+rxyz[3][j])/4.0;
      pS=(*sfunc)(c);
      invDet=pS->size(0)*pS->size(1)*pS->size(2);
      delete pS;
    } 
  else
    invDet=pS->size(0)*pS->size(1)*pS->size(2);

  return (vol/invDet);

}



// compute middle point in the transformed space

void analyticalSField::center(pEdge e, double c[3], pMSize *)
{
  dArray exyz[2];
  for(int i=0;i<2;i++) 
    V_coord(E_vertex(e,i),exyz[i]);
  center(exyz,c);
  return;
}

double analyticalSField::center(pVertex v0, pVertex v1, double c[3], pMSize *)
{
  dArray exyz[2];
  V_coord(v0,exyz[0]);
  V_coord(v1,exyz[1]);
  return center(exyz,c);
}


double analyticalSField::center(dArray exyz[2], double c[3])
{
  dArray vec;
  pMSize pS;
  double r, d[2];
  int i;

  diffVt(exyz[0],exyz[1],vec);
  for(i=0;i<2;i++) {
    pS=(*sfunc)(exyz[i]);
    d[i]=pS->dirLengthSq(vec);
    delete pS;
  }

  r=1./(1.+pow(d[1]/d[0],0.25));
  for(i=0; i<3; i++)
    c[i]=r*exyz[1][i]+(1-r)*exyz[0][i];
  return r;
}

#ifdef MATCHING
void analyticalSField::center(pVertex v0,pVertex v1, double r, dArray c,pMSize *newS)
{
    dArray exyz[2];
    V_coord(v0,exyz[0]);
    V_coord(v1,exyz[1]);
  
    for(int i=0; i<3; i++)
       c[i]=r*exyz[1][i]+(1-r)*exyz[0][i];	 
}
#endif 


// current version of meshAdapt does not call this routine 
double analyticalSField::angleSq(dArray, dArray, pMSize)
{ 
  printf("Not implemented (analyticalSField::angleSq)\n");
  return 0.0;
}


// note this function allocate memory, do not forget to delete
pMSize analyticalSField::getSize(dArray xyz, pEntity)
{
  return (*sfunc)(xyz);
}
