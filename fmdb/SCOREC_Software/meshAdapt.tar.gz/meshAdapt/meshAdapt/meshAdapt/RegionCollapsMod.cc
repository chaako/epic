#include "RegionCollapsMod.h"
#include "DSplitClpsMod.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "snap.h"
#include "EdgeCollapsMod.h"
#include "meanRatio.h"
#include "fromMeshTools.h"
#include "PList.h"
#include <stdio.h>
#include <iostream>

#ifdef CURVE
#include "curveMesh.h"
#include "curveUtil.h"
using namespace curveUtil;
#endif /*CURVE*/

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif

using std::cout;
using std::endl;

/*
  Modification to collapse a boundary tetrahedron by deletion and re-classifications  
 
  This modification has three possible configurations:
  - n=1: a boundary face and three interior faces
  - n=2: two boundary faces and two interior faces
  - n=3: three boundary faces and one interior faces

  For n=1, an interior vertex will be re-classified on boundary that needs snapping, which
  is returned. As an option, a special member function "snapVertex(pVertex)" is provided
  to take care of this vertex  
  For n=3, the boundary vertex to be removed will be returned. It's your responsibility to delete it

  Two functions are provided to check validity and acceptability w.r.t flatAngle.
  You must call these functions in the order given as below:
  (1) TopoCheck() - check topological validity
  (2) GeomCheck() - check acceptability w.r.t flatAngle
  (3) apply() or apply(pPList) -  perform the modification.
 
  return 1: TRUE or SUCCESS
         0: FALSE or FAIL

    ======> ignore the pre-repositioning of a mesh vertex <=======

  Created      02/06/2000   Xiangrong Li
  Modification history:
               01/08/2001   take care of GeoSimilarity 
	       08/16/2001   make it derived from LocMeshMod
               11/07/2001   make use of "twoSplits+collapse" operation
	       01/08/2004   account for parallelization
*/

int regionCollapsMod::topoCheck()
{
  pGFace gface;
  pFace face;
  pEdge edge;
  pVertex vert;
  int i;
  pGFace  UniqueGface=0;
  int m=0;                       // # of faces classified on model region.  n+m=4

  if (!EN_okTo(DELETE,(pEntity)region))
    return 0;

  // count the # of faces classified on the same model face
  n=0;
  for(i=0; i<4; ++i) {
    face=R_face(region,i);

    // sort the faces of this mesh region
    if(F_whatInType(face)!=Tface) {
      faces[3-m]=face;
      ++m;
      continue;
    }
    // on a non-manifold model face
    if(F_region(face,0) && F_region(face,1)) {
      faces[3-m]=face;
      ++m;
      continue;
    }
    faces[n]=face;
    ++n;

    // check if faces are classified on different model faces
    gface=(pGFace)F_whatIn(face);
    if(UniqueGface)
      if(UniqueGface!=gface)
        return 0;
    else
      UniqueGface=gface;
  }

#ifdef MA_PARALLEL
  for(i=0; i<n; ++i) 
    if( EN_onCB((pEntity)faces[i]) )
      return 0;
#endif

  pEdge oppEdge;
  switch (n) {

    // all faces are classified on model region,  no R_collapse is allowed
  case 0:  return 0;

  case 1:
    // the vertex opposite to the deleted face should be classified on model region
    vert=R_fcOpVt(region,faces[0]);
    if(V_whatInType(R_fcOpVt(region,faces[0])) != Tregion) 
      return 0;
    break;

  case 2:
    // determine the edge opposite to one to be deleted
    for(i=0; i<3; i++) {
      edge=F_edge(faces[2],i);
      if(F_inClosure(faces[3],(pEntity)edge)) break;
    }
    // the edge opposite to the deleted one should be classified on model region
    if(E_whatInType(edge) != Tregion) return 0;
    ReclssifyEdge=edge;

    oppEdge=R_gtOppEdg(region,ReclssifyEdge);

    if(!EN_okTo(DELETE,(pEntity)oppEdge))
      return 0;
    if(!EN_okTo(DELETE,(pEntity)faces[0]))
      return 0;
    if(!EN_okTo(DELETE,(pEntity)faces[1]))
      return 0;

#ifdef MA_PARALLEL
    // the mesh edge to be deleted can not be classified on a model edge 
    for(i=0; i<3; i++) {
      edge=F_edge(faces[0],i);
      if(F_inClosure(faces[1],(pEntity)edge)) break;
    }
     if( E_whatInType(edge)==Gedge )
       return 0;
#endif

    break;

  case 3:
    // check the faces to be deleted
    for(int j=0; j<3; ++j)
      if(!EN_okTo(DELETE,(pEntity)faces[j]))
        return 0;

    // the edges to be deleted must be classified on model face
    for(i=0; i<2; ++i)
      for(int j=0; j<3; ++j) {
        edge=F_edge(faces[i],j);
        if(F_inClosure(faces[3],(pEntity)edge)) continue;
        if(E_whatInType(edge)!=Tface) {
	  cout<<"INFO: a bdry mesh region can be deleted by Fsplit+collapse operations"<<endl;
	  return 0;
	}
        if(!EN_okTo(DELETE,(pEntity)edge))
          return 0;
      }

    // the vertex to be deleted must be classified on model face
    vert=R_fcOpVt(region,faces[3]);
    if(!EN_okTo(DELETE,(pEntity)vert))
      return 0;
    if(V_whatInType(vert) != Tface)
      return 0;
    if(V_numEdges(vert)!=3)
      return 0;
    break;

    // all faces are classified on model face, R_collapse fails
  default:
    return 0;
  }

  return 1;
}

// return the face normal NOT pointing to the given region
// (point out of mesh domain if region==0)
void regionCollapsMod::F_normal(pFace face, pRegion rgn, double nor[3])
{
  // get the region if it is NULL
  if( !rgn ) {
    pRegion rgn1;
    rgn=F_region(face,0);
    rgn1=F_region(face,1);
    if( (rgn && rgn1) || (!rgn && !rgn1) )
      printf("WARNING: we have a problem (regionCollapsMod::F_normal)\n");
    if( !rgn )
      rgn=rgn1;
  }

  double xyz[4][3];
  double v01[3], v02[3], v03[3];
  pPList fverts=F_vertices(face,1);
  pVertex vertex;
  void *iter=0;
  int i=0;
  while( vertex=(pVertex)PList_next(fverts,&iter) )
    V_coord(vertex,xyz[i++]);

  vertex=R_fcOpVt(rgn,face);
  V_coord(vertex,xyz[3]);

  diffVt(xyz[1],xyz[0],v01);
  diffVt(xyz[2],xyz[0],v02);
  diffVt(xyz[3],xyz[0],v03);
  crossProd(v01,v02,nor);
  if( dotProd(nor,v03) > 0 ) {
    nor[0]=-1.*nor[0];
    nor[1]=-1.*nor[1];
    nor[2]=-1.*nor[2];
  }

  PList_delete(fverts);
}


int regionCollapsMod::geomCheck()
{
  pEdge edge;
  double normal1[3], normal2[3];
  int i;
  pGFace  UniqueGface=0;

  switch (n) {
  case 1:
    // check normal
    //    F_normalVector(faces[0],1,normal1);
    F_normal(faces[0], 0, normal1);
    for(i=1; i<4; ++i) {
      //      F_normalVector(faces[i],1,normal2);
      F_normal(faces[i], region, normal2);
      //      edge=adaptUtil::CommonEdge(faces[i],faces[0]);
      if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != -1)
	return 0;
//        if(F_dirUsingEdge(faces[i],edge)==F_dirUsingEdge(faces[0],edge)) {
//          if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != 1)
//            return 0;
//        }
//        else {
//          if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != -1)
//            return 0;
//        }
    }
    break;

  case 2: {
    int flag=0;
    if( model_type==PARAM ) {
      if( adaptUtil::F_checkGeoSim(faces[0])!=1 ) flag++;
      if( adaptUtil::F_checkGeoSim(faces[1])!=1 ) flag++; 
// #ifdef DEBUG
//       if (flag==2)
// 	printf("Info: two invalid boundary faces (regionCollapsMod::geomCheck)\n"); 
// #endif
    }

    edge=adaptUtil::CommonEdge(faces[0],faces[1]);
#ifdef DEBUG
    if( R_gtOppEdg(region,ReclssifyEdge)!= edge )
      printf("Error: invalid mesh (regionCollapsMod::geomCheck)\n"); 
#endif

    if( !flag ) {    
      // check normals of the two boundary faces
//        F_normalVector(faces[0],1,normal1);
//        F_normalVector(faces[1],1,normal2);
//        if(F_dirUsingEdge(faces[0],edge)==F_dirUsingEdge(faces[1],edge)) {
//          if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != -1)
//  	  return 0;
//        }
//        else {
//          if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != 1)
//  	  return 0;
//        }

//        F_normalVector(faces[2],1,normal1);
//        F_normalVector(faces[3],1,normal2);
//      edge=adaptUtil::CommonEdge(faces[2],faces[3]);
//        if(F_dirUsingEdge(faces[2],edge)==F_dirUsingEdge(faces[3],edge)) {
//          if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != -1)
//  	  return 0;
//        }
//        else {
//          if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != 1)
//  	  return 0;
//        }

      F_normal(faces[0], 0, normal1);
      F_normal(faces[1], 0, normal2);
      if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != 1)
	return 0;    

      F_normal(faces[2], region, normal1);
      F_normal(faces[3], region, normal2);
      if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != 1)
	return 0;   
    }

    // the two vertices of the common edge must be snapped, otherwise,
    // we do not know how to compute the parametric location of new vertex
    if( E_whatInType(edge)==Gedge && model_type==PARAM ) {
      if( adaptUtil::V_checkPar(E_vertex(edge,0),0)==0 )
	return 0;
      if( adaptUtil::V_checkPar(E_vertex(edge,1),0)==0 )
	return 0;
    }
    break;
  }
  case 3:
    // check normal
    F_normalVector(faces[3],1,normal1);
    for(i=0; i<3; ++i) {
      F_normalVector(faces[i],1,normal2);
      if(!adaptUtil::RelativeDirection(normal1,normal2,flatAngle))
        return 0;
    }
    break;
  }
  
  return 1;
}

#ifdef CURVE

void regionCollapsMod::getAffectedRgns(pPList *rlist)
{
  switch (n) {
    case 1: {
      pVertex vert = R_fcOpVt(region,faces[0]);
      *rlist = V_regions(vert);
      break;
    }
    case 2: {
      *rlist = F_regions(faces[2]);
      pPList tmplist = F_regions(faces[3]);
      PList_appPListUnique(*rlist, tmplist);
      PList_delete(tmplist);
      break;
    }
    case 3: {
      cout<<"N=3, NOT IMPLEMENTED"<<endl;
      *rlist = PList_new();
      break;
    }
  }

  return;
}

int regionCollapsMod::apply(pPList *newRlist)
{
  pGEntity gent;
  pEdge edge, oppEdge;
  pVertex vert;
  int i, j;
  int chDir=0;

  gent=F_whatIn(faces[0]);

  switch (n) {

  case 1:
    // reclassify faces
    for(i=1; i<4; ++i) {
      F_setWhatIn(faces[i],gent);
      edge=adaptUtil::CommonEdge(faces[i],faces[0]);
      chDir=0;
      if(F_dirUsingEdge(faces[i],edge)!=F_dirUsingEdge(faces[0],edge)) {
        F_chDir(faces[i]);
	chDir=1;
	}
#ifdef MA_PARALLEL
      fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)faces[i], chDir);
#endif
    }

    // reclassify edges
    for(i=0; i<3; ++i) {
      edge=F_edge(faces[1],i);
      if(F_inClosure(faces[0],(pEntity)edge)) continue;
      E_setWhatIn(edge,gent);
#ifdef MA_PARALLEL
      fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)edge, 0);
#endif      
    }
    for(i=0; i<3; ++i) {
      edge=F_edge(faces[2],i);
      if(E_whatInType(edge)==Tregion) {
        E_setWhatIn(edge,gent);
#ifdef MA_PARALLEL
        fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)edge, 0);
#endif   	
      }
    }

    // reclassify vertex
    vert = R_fcOpVt(region,faces[0]);
    V_setWhatIn(vert,gent);
    adaptUtil::ProcessNewBdryVertex(mesh,vert);
#ifdef MA_PARALLEL
    fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)vert, 0);
#endif   
/*
    if(quadratic == true) {
      double vxyz[3], fxyz[3][3], exyz[3];
      pVertex newv;
      pEdge newe;
      pPoint pt;
      F_bezierXYZ(faces[0], fxyz);
      F_bezierEval(fxyz, 1./3., 1./3., vxyz);
      
      adaptUtil::move_vertex(vert, vxyz);
      
      pPList fvlist = F_vertices(faces[0], 1);
      
      for(i=0; i<3; i++) {
	newv = (pVertex)PList_item(fvlist, i);
	pEdge newe = E_exists(vert, newv);
	if(E_numPoints(newe)) 
	  pt = E_point(newe, 0); 
	else
	  pt = P_new();
	if(!i)
	  F_bezierEval(fxyz, 1./6., 1./6., exyz);
	else if(i==1)
	  F_bezierEval(fxyz, 2./3., 1./6., exyz);
	else
	  F_bezierEval(fxyz, 1./6., 2./3., exyz);
	P_setPos(pt, exyz[0], exyz[1], exyz[2]);
      }
      
      PList_delete(fvlist);
    }
*/
    M_removeRegion(mesh,region);
    M_removeFace(mesh,faces[0]);

    *newRlist = V_regions(vert);

    keepVertex = vert;
    return 2;
//    return *(int*)(vert);

  case 2:
    // determine the mesh edge to be deleted 
    for(i=0; i<3; i++) {
      edge=F_edge(faces[0],i);
      if(F_inClosure(faces[1],(pEntity)edge)) break;
    }

    // reclassify faces
    for(i=2; i<4; ++i) 
    {
      F_setWhatIn(faces[i],gent);
      edge=adaptUtil::CommonEdge(faces[i],faces[0]);
      chDir=0;
      if(F_dirUsingEdge(faces[i],edge)!=F_dirUsingEdge(faces[0],edge)) {
	F_chDir(faces[i]);
	chDir=1;
	}
#ifdef MA_PARALLEL
      fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)faces[i], chDir);
#endif
    }
    
    // reclassify edge
//      for(i=0; i<3; ++i) {
//        edge=F_edge(faces[2],i);
//        if(E_whatInType(edge)==Tregion)
//  	{ E_setWhatIn(edge,gent); break; }
//      }
    E_setWhatIn(ReclssifyEdge,gent);
#ifdef MA_PARALLEL
    fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)ReclssifyEdge, 0);
#endif
    
    oppEdge=R_gtOppEdg(region,ReclssifyEdge);

/*
    double xyz[3];
    if(quadratic == true)
      computePtForOppEdge(oppEdge, faces, xyz);
    
    if(E_numPoints(ReclssifyEdge)) {
      pPoint pt = E_point(ReclssifyEdge, 0);
      P_setPos(pt, xyz[0], xyz[1], xyz[2]);
    }
    else{
      pPoint pt = P_new();
      P_setPos(pt, xyz[0], xyz[1], xyz[2]);
      E_setPoint(ReclssifyEdge, pt);
    }
*/    
    // collapse the region
    M_removeRegion(mesh,region);
    M_removeFace(mesh,faces[0]);
    M_removeFace(mesh,faces[1]);
    M_removeEdge(mesh,oppEdge);

    edge = adaptUtil::CommonEdge(faces[2],faces[3]); 
    *newRlist = E_regions(edge);
    break;

  case 3:
    // reclassify face
    F_setWhatIn(faces[3],gent);
    edge=adaptUtil::CommonEdge(faces[3],faces[0]);
    if(F_dirUsingEdge(faces[3],edge)!=F_dirUsingEdge(faces[0],edge)) {
      F_chDir(faces[3]);
      chDir=1;
    }
#ifdef MA_PARALLEL
    fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)faces[3], chDir);
#endif
    
    // collapse region
    pEdge edges[3];
    vert=R_fcOpVt(region,faces[3]);
    int m=V_numEdges(vert);
    if(m!=3)
      { cout << "Error: adaptUtil::R_colaps!!!" << endl; return 0; }
    for(i=0; i<m; ++i)
      edges[i]=V_edge(vert,i);
   
    M_removeRegion(mesh,region);
    M_removeFace(mesh,faces[0]);
    M_removeFace(mesh,faces[1]);
    M_removeFace(mesh,faces[2]);
    M_removeEdge(mesh,edges[0]);
    M_removeEdge(mesh,edges[1]);
    M_removeEdge(mesh,edges[2]);

    cout<<"RegionCollapse: n=3 apply is not implemented for curved mesh"<<endl;
    // return *(int*)vert;
    keepVertex = vert;
    return 2;
  }

  return 1;
}

#else /*NOCURVE*/

int regionCollapsMod::apply()
{
  pGEntity gent;
  pEdge edge, oppEdge;
  pVertex vert;
  int i;
  int chDir=0;

  gent=F_whatIn(faces[0]);

  switch (n) {

  case 1:
    // reclassify faces
    for(i=1; i<4; ++i) {
      F_setWhatIn(faces[i],gent);
      edge=adaptUtil::CommonEdge(faces[i],faces[0]);
      chDir=0;
      if(F_dirUsingEdge(faces[i],edge)!=F_dirUsingEdge(faces[0],edge)) {
        F_chDir(faces[i]);
	chDir=1;
	}
#ifdef MA_PARALLEL
      fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)faces[i], chDir);
#endif
    }

    // reclassify edges
    for(i=0; i<3; ++i) {
      edge=F_edge(faces[1],i);
      if(F_inClosure(faces[0],(pEntity)edge)) continue;
      E_setWhatIn(edge,gent);
#ifdef MA_PARALLEL
      fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)edge, 0);
#endif      
    }
    for(i=0; i<3; ++i) {
      edge=F_edge(faces[2],i);
      if(E_whatInType(edge)==Tregion) {
        E_setWhatIn(edge,gent);
#ifdef MA_PARALLEL
        fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)edge, 0);
#endif   	
      }
    }

    // reclassify vertex
    vert = R_fcOpVt(region,faces[0]);
    V_setWhatIn(vert,gent);
    adaptUtil::ProcessNewBdryVertex(mesh,vert);
#ifdef MA_PARALLEL
    fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)vert, 0);
#endif   

    M_removeRegion(mesh,region);
    M_removeFace(mesh,faces[0]);

    // return (int)vert; // not good for 64-bit mode
    keepVertex = vert;
    return 2;

  case 2:
    // determine the mesh edge to be deleted 
    for(i=0; i<3; i++) {
      edge=F_edge(faces[0],i);
      if(F_inClosure(faces[1],(pEntity)edge)) break;
    }

    // reclassify faces
    for(i=2; i<4; ++i) 
    {
      F_setWhatIn(faces[i],gent);
      edge=adaptUtil::CommonEdge(faces[i],faces[0]);
      chDir=0;
      if(F_dirUsingEdge(faces[i],edge)!=F_dirUsingEdge(faces[0],edge)) {
	F_chDir(faces[i]);
	chDir=1;
	}
#ifdef MA_PARALLEL
      fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)faces[i], chDir);
#endif
    }
    
    // reclassify edge
//      for(i=0; i<3; ++i) {
//        edge=F_edge(faces[2],i);
//        if(E_whatInType(edge)==Tregion)
//  	{ E_setWhatIn(edge,gent); break; }
//      }
    E_setWhatIn(ReclssifyEdge,gent);
#ifdef MA_PARALLEL
    fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)ReclssifyEdge, 0);
#endif
   
    // collapse the region
    oppEdge=R_gtOppEdg(region,ReclssifyEdge);
    M_removeRegion(mesh,region);
    M_removeFace(mesh,faces[0]);
    M_removeFace(mesh,faces[1]);
    M_removeEdge(mesh,oppEdge);
    break;

  case 3:
    // reclassify face
    F_setWhatIn(faces[3],gent);
    edge=adaptUtil::CommonEdge(faces[3],faces[0]);
    if(F_dirUsingEdge(faces[3],edge)!=F_dirUsingEdge(faces[0],edge)) {
      F_chDir(faces[3]);
      chDir=1;
    }
#ifdef MA_PARALLEL
    fromMeshTools::sendReclassifiedEntity(mesh, (pEntity)faces[3], chDir);
#endif
    
    // collapse region
    pEdge edges[3];
    vert=R_fcOpVt(region,faces[3]);
    int m=V_numEdges(vert);
    if(m!=3)
      { cout << "Error: adaptUtil::R_colaps!!!" << endl; return 0; }
    for(i=0; i<m; ++i)
      edges[i]=V_edge(vert,i);
    
    M_removeRegion(mesh,region);
    M_removeFace(mesh,faces[0]);
    M_removeFace(mesh,faces[1]);
    M_removeFace(mesh,faces[2]);
    M_removeEdge(mesh,edges[0]);
    M_removeEdge(mesh,edges[1]);
    M_removeEdge(mesh,edges[2]);
    // return (int)vert; // not good for 64-bit mode
    keepVertex = vert;
    return 2;
  }

  return 1;
}

#endif/*CURVE*/

pVertex regionCollapsMod::getKeepVertex() {
  return keepVertex;
}

#ifndef MA_PARALLEL 
/*   8/16/01   -li  */
int regionCollapsMod::snapVertex(pVertex vd, pPList *updatedRgns)
{
  if( n != 1 ) 
    return 0;

  printf("WARNING: need compute the target in a better way (regionCollapsMod)\n");

  pEdge edge, bestEdgeDel;
  pVertex vr, bestVr, bestVd;
  double maxWorstShape=0.0;
  int i;

  shpMeasure=new MeanRatio(pSizeField);
  results=new evalResults();
  edgeCollapsMod clps = edgeCollapsMod(mesh,pSizeField,shpMeasure,results);

  clps.setAcptControl(1);
  clps.setModelType(model_type);

  for( i=0; i<V_numEdges(vd); i++ ) {
    edge=V_edge(vd,i);
    if( E_whatInType(edge) == Gregion ) continue;

    vr=E_otherVertex(edge,vd);
    clps.setCollaps(edge,vd,vr);
    if( !clps.topoCheck() )  continue;
    if( !clps.geomCheck() )  continue;

    if( maxWorstShape < results->getWorstShape() ) {
      maxWorstShape=results->getWorstShape();
      bestEdgeDel=edge;
      bestVr=vr;
      bestVd=vd;
    }
  }

  delete shpMeasure;
  delete results;

  if( maxWorstShape!=0.0 ) {
    clps.setCollaps(bestEdgeDel,bestVd,bestVr);
    clps.apply(updatedRgns);
  } else {

    // calculate the projection onto the boundary 
    double pxyz[3];
    double *proxyz=new double[3];
    V_coord(vd,pxyz);

    if( model_type==NOPARAM ) {
      double fxyz[3][3];
      double normal[3];
      double v01[3],v02[3],v0P[3],ratio;
      double magCP,magN;
      int k=0;

      for( i=0; i<V_numEdges(vd); i++ ) {
	edge=V_edge(vd,i);
	if( E_whatInType(edge) == Gregion ) continue;
	V_coord(E_otherVertex(edge,vd),fxyz[k++]);
      }
      
      diffVt(fxyz[1],fxyz[0],v01);
      diffVt(fxyz[2],fxyz[0],v02); 
      crossProd(v01,v02,normal);
      
      magN=dotProd(normal,normal);
      
      diffVt(pxyz,fxyz[0],v0P);
      magCP=dotProd(v0P,normal);
      ratio=magCP/magN;
      
      for(i=0;i<3;++i)
	proxyz[i]=pxyz[i]-ratio*normal[i];
    }
    else {
      pGEntity gent = V_whatIn(vd);
      int gtype = GEN_type(gent);
      double par[]={0.0,0.0,0.0};
      
      // C_closestPoint() is no longer used, please use GF_closestPoint and GE_closestPoint instead. 
      //  if( !C_closestPoint(gtype,gent,pxyz,0,0,0,proxyz,par) ) 
      // 	{ delete proxyz; return 0; } 
      
      if(gtype==0 && gtype==3){
	delete proxyz; 
	return 0; 
      }

      if(gtype==2)
	GF_closestPoint((pGFace)gent, pxyz, proxyz, par);
      if(gtype==1)
	GE_closestPoint((pGEdge)gent, pxyz, proxyz, par);
                 
      pPoint pt=M_createP(mesh,proxyz[0],proxyz[1],proxyz[2],par,0,gent);
      pPoint point=V_point(vd);
      V_setPoint(vd,pt);
      P_delete(point);
      P_setPos(pt,pxyz[0],pxyz[1],pxyz[2]);
    }

    meshSnap vsnap(mesh,pSizeField);
    vsnap.setModelType(model_type);
    vsnap.append(vd, proxyz);
    if( vsnap.run()!=0 ) return 0;
    *updatedRgns=PList_new();      // we can not return new regions in snapping
  }

  return 1;
}
#endif //Not MA_PARALLEL


/*
  evaluate if a region can be collapsed with geometric similarity not guaranteed
  return 1 if it can
         0 if region collapse fails

  Created      02/06/2000   Xiangrong Li
  Last Mod.    01/08/2001   take care of GeoSimilarity
*/
#if 0
int regionCollapsMod::evaluate(pMeshDataId int_geoSim, pMeshDataId ptr_geoSim)
{
  pGFace gface;
  pFace face;
  pEdge edge;
  double normal1[3], normal2[3];
  double vxyz[3];
  pVertex vert;
  int i;
  pGFace  UniqueGface=0;
  int value;
  int m=0;                       // # of faces classified on model region.  n+m=4

  // count the # of faces classified on the same model face
  n=0;
  for(i=0; i<4; ++i) {
    face=R_face(region,i);

    // sort the faces of this mesh region
    if(F_whatInType(face)!=Tface) {
      faces[3-m]=face;
      ++m;
      continue;
    }
    if(F_region(face,0) && F_region(face,1)) {
      faces[3-m]=face;
      ++m;
      continue;
    }
    faces[n]=face;
    ++n;

    // check if faces are classified on different model faces
    gface=(pGFace)F_whatIn(face);
    if(UniqueGface)
      if(UniqueGface!=gface)
        return 0;
    else
      UniqueGface=gface;
  }

  switch (n) {

    // all faces are classified on model region,  R_collapse fails
  case 0:  return 0;

  case 1:
    // check normal
    //    F_normalVector(faces[0],1,normal1);
    F_normal(faces[0], 0, normal1);
    for(i=1; i<4; ++i) {
      //      F_normalVector(faces[i],1,normal2);
      F_normal(faces[i], region, normal2);
      if(adaptUtil::RelativeDirection(normal1,normal2,flatAngle) != -1)
	return 0;
//        edge=adaptUtil::CommonEdge(faces[i],faces[0]);
//        if(F_dirUsingEdge(faces[i],edge)==F_dirUsingEdge(faces[0],edge)) {
//          if(adaptUtil::RelativeDirection(normal1,normal2) != 1)
//            return 0;
//        }
//        else {
//          if(adaptUtil::RelativeDirection(normal1,normal2) != -1)
//            return 0;
//        }
    }
    
    // the vertex opposite to the deleted face should be classified on model region
    vert=R_fcOpVt(region,faces[0]);
    if(V_whatInType(R_fcOpVt(region,faces[0])) != Tregion) return 0;

    V_coord(vert,vxyz);
    if(XYZ_onBoundary(vxyz,(pEntity)faces[0],M_getTolerance()) != (pEntity)faces[0])
      return 0;

    break;

  case 2:
    // if one of the faces not geometrically similar, checking normal is not necessary
    value=1;
    for( i=0; i<2; i++ ) {
      if( EN_getDataInt((pEntity)faces[i],int_geoSim,&value) && value!=1 )
	break;
      else {
	value=adaptUtil::F_checkGeoSim(faces[i],ptr_geoSim);
        if( value!=1)  break;
      }
    }
    if( value==-2 ) {
      cout<<"...Error: can not reparameterize (RegionCollpase::evaulate())"<<endl;
      return 0;
    }
    if( value==1 ) {
      // check normal
//        F_normalVector(faces[0],1,normal1);
//        F_normalVector(faces[1],1,normal2);
//        if(!adaptUtil::RelativeDirection(normal1,normal2))
//          return 0;
//        normal1[0] += normal2[0];
//        normal1[1] += normal2[1];
//        normal1[2] += normal2[2];
//        for(i=2; i<4; ++i) {
//  	F_normalVector(faces[i],1,normal2);
//  	edge=adaptUtil::CommonEdge(faces[i],faces[0]);
//  	if(F_dirUsingEdge(faces[i],edge)==F_dirUsingEdge(faces[0],edge)) {
//  	  if(adaptUtil::RelativeDirection(normal1,normal2) != 1)
//  	    return 0;
//  	}
//  	else {
//  	  if(adaptUtil::RelativeDirection(normal1,normal2) != -1)
//  	    return 0;
//  	}
//        }
      F_normal(faces[0], 0, normal1);
      F_normal(faces[1], 0, normal2);
      if(!adaptUtil::RelativeDirection(normal1,normal2))
	return 0;
      normal1[0] += normal2[0];
      normal1[1] += normal2[1];
      normal1[2] += normal2[2];
      for(i=2; i<4; ++i) {
	F_normal(faces[i], region, normal2);
	if(adaptUtil::RelativeDirection(normal1,normal2) != -1)
	  return 0;
      }
    }

    // check if the edge to be deleted is classified on model face
    for(i=0; i<3; i++) {
      edge=F_edge(faces[0],i);
      if(F_inClosure(faces[1],(pEntity)edge)) break;
    }
    if(E_whatInType(edge)!=Tface) return 0;

    // the edge opposite to the deleted one should be classified on model region
    if(E_whatInType(R_gtOppEdg(region,edge)) != Tregion) return 0;

    break;

  case 3:
    // if one of the three faces not geometrically similar, checking normal is not necessary
    value=1;
    for( i=0; i<3; i++ ) 
      if( EN_getDataInt((pEntity)faces[i],int_geoSim,&value) && value!=1 )
	break;
      else {
	value=adaptUtil::F_checkGeoSim(faces[i],ptr_geoSim);
        if( value!=1)  break;
      }

    if( value==-2 ) {
      cout<<"...Error: can not reparameterize (RegionCollpase::evaulate(3))"<<endl;
      return 0;
    }
    if( value==1 ) {
      // check normal
      F_normalVector(faces[3],1,normal1);
      for(i=0; i<3; ++i) {
	F_normalVector(faces[i],1,normal2);
	if(!adaptUtil::RelativeDirection(normal1,normal2))
	  return 0;
      }
    }

    // check if the edges to be deleted are classified on model face
    for(i=0; i<2; ++i)
      for(int j=0; j<3; ++j) {
        edge=F_edge(faces[i],j);
        if(F_inClosure(faces[3],(pEntity)edge)) continue;
        if(E_whatInType(edge)!=Tface) return 0;
      }

    // check if the vertex to be deleted is classified on model face
    vert=R_fcOpVt(region,faces[3]);
    if(V_whatInType(vert) != Tface)
      return 0;
    break;

    // all faces are classified on model face, R_collapse fails
  default:
    return 0;
  }

  return 1;
}



/*
  collapse a boundary region
  created by Xiangrong Li    02/08/2000
*/
pEntity regionCollapsMod::apply(pMeshDataId int_geoSim)
{
  pGEntity gent;
  pEdge edge, oppEdge;
  pVertex vert;
  int value;
  int i;

  gent=F_whatIn(faces[0]);

  switch (n) {

  case 1:
    // reclassify faces
    for(i=1; i<4; ++i) {
      F_setWhatIn(faces[i],gent);
      edge=adaptUtil::CommonEdge(faces[i],faces[0]);
      if(F_dirUsingEdge(faces[i],edge)!=F_dirUsingEdge(faces[0],edge))
        F_chDir(faces[i]);
    }

    // reclassify edges
    for(i=0; i<3; ++i) {
      edge=F_edge(faces[1],i);
      if(F_inClosure(faces[0],(pEntity)edge)) continue;
      E_setWhatIn(edge,gent);
    }
    for(i=0; i<3; ++i) {
      edge=F_edge(faces[2],i);
      if(E_whatInType(edge)==Tregion)
        E_setWhatIn(edge,gent);
    }

    // reclassify vertex
    vert = R_fcOpVt(region,faces[0]);
    V_setWhatIn(vert,gent);

    if( EN_getDataInt((pEntity)faces[0],int_geoSim,&value) )
      EN_deleteData((pEntity)faces[0],int_geoSim);

    M_removeRegion(mesh,region);
    M_removeFace(mesh,faces[0]);
    return (pEntity)vert;

  case 2:
    // reclassify faces
    for(i=2; i<4; ++i) {
      F_setWhatIn(faces[i],gent);
      edge=adaptUtil::CommonEdge(faces[i],faces[0]);
      if(F_dirUsingEdge(faces[i],edge)!=F_dirUsingEdge(faces[0],edge))
        F_chDir(faces[i]);
    }

    // reclassify edge
    for(i=0; i<3; ++i) {
      edge=F_edge(faces[2],i);
      if(E_whatInType(edge)==Tregion)
        { E_setWhatIn(edge,gent); break; }
    }

    // collapse the region
    oppEdge=R_gtOppEdg(region,edge);
    M_removeRegion(mesh,region);
    if( EN_getDataInt((pEntity)faces[0],int_geoSim,&value) )
      EN_deleteData((pEntity)faces[0],int_geoSim);
    if( EN_getDataInt((pEntity)faces[1],int_geoSim,&value) )
      EN_deleteData((pEntity)faces[1],int_geoSim);
    M_removeFace(mesh,faces[0]);
    M_removeFace(mesh,faces[1]);
    M_removeEdge(mesh,oppEdge);
    break;

  case 3:
    // reclassify face
    F_setWhatIn(faces[3],gent);
    edge=adaptUtil::CommonEdge(faces[3],faces[0]);
    if(F_dirUsingEdge(faces[3],edge)!=F_dirUsingEdge(faces[0],edge))
      F_chDir(faces[3]);

    // collapse region
    pEdge edges[3];
    vert=R_fcOpVt(region,faces[3]);
    for(i=0; i<V_numEdges(vert); ++i)
      edges[i]=V_edge(vert,i);

    if( EN_getDataInt((pEntity)faces[0],int_geoSim,&value) )
      EN_deleteData((pEntity)faces[0],int_geoSim);
    if( EN_getDataInt((pEntity)faces[1],int_geoSim,&value) )
      EN_deleteData((pEntity)faces[1],int_geoSim);
    if( EN_getDataInt((pEntity)faces[2],int_geoSim,&value) )
      EN_deleteData((pEntity)faces[2],int_geoSim);

    M_removeRegion(mesh,region);
    M_removeFace(mesh,faces[0]);
    M_removeFace(mesh,faces[1]);
    M_removeFace(mesh,faces[2]);
    M_removeEdge(mesh,edges[0]);
    M_removeEdge(mesh,edges[1]);
    M_removeEdge(mesh,edges[2]);
    return (pEntity)vert;
  }

  return (pEntity)1;
}


#endif
