#ifndef _H_LayerEdgeCollapsMod
#define _H_LayerEdgeCollapsMod

#include <iostream>

#include "EdgeCollapsMod.h"
#include "BLUtil.h"

using namespace std;

class layerEdgeCollapsMod: public edgeCollapsMod
{
 public:
  layerEdgeCollapsMod(const layerEdgeCollapsMod &);
  layerEdgeCollapsMod(pMesh,pSField,MeanRatio *,evalResults *);
  ~layerEdgeCollapsMod() { }

  /* the common local modification interface */
  virtual int topoCheck();
  virtual int geomCheck();
  virtual int sizeCheck();
  virtual void getAffectedRgns(pPList *);
  virtual int apply();
  virtual int apply(pPList *);

  virtual modType type() { return LECOLAPS; }

  void setCollaps(pEdge e, pVertex d, pVertex r);
  void setCollapsList(vector<pEdge> &elist, pVertex d, pVertex r);

  pEdge edgeD() { return edgeDel; }
//  pPList getCollapsEdgeList() { return edges; }
  pVertex vertD(int top=0) { 
    if(top) {
/*
      pVertex topVd;
      pPList nodes = (V_growthCurve(vd))->getNodesOnGC();
      topVd = (pVertex)PList_item(nodes,PList_size(nodes)-1);
      PList_delete(nodes);

      return topVd;
*/
    }
    else
      return vd; }
  pVertex vertR() { return vr; }
  void bdryCheck() { flag=1; }

 private:
  /* the zero level layer edge to be collapsed */
  pEdge edgeDel;
  /* the interface edge to be collapsed */
  pEdge interfaceEdge;
  /* the list of layer edges to be collapsed */
  vector<pEdge> edges;
  vector<pVertex> vd_GC, vr_GC;
  int listSize;

  pVertex vd;
  pVertex vr;
  pVertex topVd;
  int flag;    

 protected:
  /* functions to check parametric span on periodic model face/edge */
  int GF_checkPeriodicSpan(pGFace);
  int GE_checkPeriodicSpan(pGEdge);

};

inline layerEdgeCollapsMod::layerEdgeCollapsMod(const layerEdgeCollapsMod &x)
  : edgeCollapsMod(x.mesh, x.pSizeField, x.shpMeasure, x.results) 
{
  interfaceEdge=x.interfaceEdge;
  for (vector<pEdge>::const_iterator eit = x.edges.begin(); eit != x.edges.end(); ++eit)
    edges.push_back(*eit);
  listSize=x.listSize;
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;
  CB_move=x.CB_move;
  userData_CB_move=x.userData_CB_move;

  edgeDel=x.edgeDel;
  vd=x.vd;
  vr=x.vr;
  topVd = x.topVd;
  flag=x.flag;

  vertMv=x.vertMv;
  target[0]=x.target[0];
  target[1]=x.target[1];
  target[2]=x.target[2];
}

inline layerEdgeCollapsMod::layerEdgeCollapsMod(pMesh p, pSField mf, MeanRatio *m,
				       evalResults *r)
  : edgeCollapsMod(p,mf,m,r)
{
 interfaceEdge=0;
 listSize=0;
 edgeDel=0;
 vd=0;
 vr=0;
 topVd = 0;
 flag=0;
}

/* inline layerEdgeCollapsMod::layerEdgeCollapsMod(pMesh p, pSField mf, MeanRatio *m, */
/* 				      evalResults *r,  */
/* 				      pVertex v, double *t) */
/*   : locMeshMod(p,mf,m,r), edgeDel(0), vd(0), vr(0), flag(0) */
/* {  */
/*   vertMv=v; */
/*   target[0]=t[0]; */
/*   target[1]=t[1]; */
/*   target[2]=t[2]; */
/* } */

#endif

