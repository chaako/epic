/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project  : Mesh Tools
  Author(s): Rao Garimella
  Creation : Feb., 95
  Modifi.  : 
  Function :
    mesh optimization: Check if a particular mesh modification operation
    is not allowed by checking the appropriate bit field of integer
    data on entity and the model entity it is classified on.
-------------------------------------------------------------------------*/
#include <stdio.h>
#include "FMDB.h"
#include "fromMeshTools.h"

extern int globalCst ;
extern MarkID MT_cnst;

void EN_unconstrain(opType i,pEntity e) {
  unsigned int d = 0;

  if (!e)
    /* apply global constraint here. */
    globalCst &= ~(1<<i);
  else {
    d = EN_mark(e,MT_cnst);
    d &= ~(1<<i);
    EN_setMark(e,MT_cnst,d);
  }
}

void EN_unconstrainAll(pEntity e) {
  unsigned int d = 0;

  if (!e)
    globalCst = 0;
  else {
    d = EN_mark(e,MT_cnst);
    d = 0;
    EN_setMark(e,MT_cnst,d);
  }
}

void GEN_unconstrain(opType i, pGEntity e) {
  int d = 0;

  if (!e)
    /* apply global constraint here. */
    globalCst &= ~(1<<i);
  else {
    if(!GEN_dataI(e,"cnst",&d))
      d = 0;
    if (d)
      if (d & ~(1<<i))
	GEN_modifyDataI(e,"cnst",(d & ~(1<<i)));
      else
	GEN_removeData(e,"cnst");
  }
}

void GEN_unconstrainAll(pGEntity e) {
  int d = 0;

  if (!e)
    /* apply global constraint here. */
    globalCst = 0;
  else {
    if (GEN_dataI(e,"cnst", &d))
      GEN_removeData(e,"cnst");
  }
}

