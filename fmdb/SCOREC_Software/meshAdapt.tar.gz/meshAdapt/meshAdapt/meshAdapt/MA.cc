#include "MA.h"
#include "PWLinearSField.h"
#include "AdaptUtil.h"
#include <cmath>


/* do refinement */
extern "C"
void MA_Adapt(pMAdapt pMAdaptDrvr)
{
  int iNumIt = pMAdaptDrvr->GetNumIt();
  int iSizeFldFlag;
  adaptSFunc SizeFldFunc = pMAdaptDrvr->GetSizeFldFunc(); 
  if (SizeFldFunc)
  {
    iSizeFldFlag = 1;
  }
  else
  {
    iSizeFldFlag = 0;
  }
  pMAdaptDrvr->run(iNumIt, iSizeFldFlag, SizeFldFunc);
}


extern "C"
void MA_NewMeshAdaptDrvr(pMAdapt &pMAdaptDrvr, pMeshMdl pMeshInstance, int iSizeFldType)
{
#ifndef MESHMODEL
  pMAdaptDrvr = new meshAdapt(pMeshInstance, iSizeFldType, 2);
#else
  pMAdaptDrvr = new meshAdapt(pMeshInstance, iSizeFldType, 0);
#endif
}


extern "C"
void MA_Del(pMAdapt pMAdaptDrvr)
{
  delete pMAdaptDrvr;
}


extern "C"
void MA_NewMeshAdaptDrvr_ModelType(pMAdapt &pMAdaptDrvr, pMeshMdl pMeshInstance, int iSizeFldType, int iModelType)
{
  pMAdaptDrvr = new meshAdapt(pMeshInstance, iSizeFldType, iModelType);
}


extern "C"
void MA_SetAnisoVtxSize(pMAdapt pMAdaptDrvr, pVertex pVertexVtx, double ddSize[3][3])
{
  double h[3] = {0.,0.,0.};
  double dirs[3][3];

  for(int i=0; i<3; i++) {
    for (int j=0 ;j<3; j++) {
      h[i] += ddSize[i][j]*ddSize[i][j]; 
    }

    h[i] = sqrt(h[i]);

    for(int j=0; j<3; j++)
      dirs[i][j] = ddSize[i][j]/h[i];
  }

  pSField SizeFld = pMAdaptDrvr->getSizeField();

  ((PWLsfield *)SizeFld)->setSize((pEntity)pVertexVtx, dirs, h);
}


extern "C"
void MA_SetCB(pMAdapt pMAdaptDrvr, CBFunction CB, void *userData)
{ 
  pMAdaptDrvr->setCallback(CB,userData);
}


extern "C"
void MA_SetIsoVtxSize(pMAdapt pMAdaptDrvr, pVertex pVertexVtx, double dSize)
{
  pSField SizeFld = pMAdaptDrvr->getSizeField();

  ((PWLsfield *)SizeFld)->setSize((pEntity)pVertexVtx, dSize);
}


extern "C"
void MA_SetNumIt(pMAdapt pMAdaptDrvr, int iNumIt)
{
  pMAdaptDrvr->SetNumIt(iNumIt);  
}


extern "C"
void MA_SetPredLoadBal(pMAdapt pMAdaptDrvr, int iPredLoadBal)
{
  pMAdaptDrvr->SetPreLBFlag(iPredLoadBal);
}


extern "C"
void MA_SetRefLvl(pMAdapt pMAdaptDrvr, pEntity pEntityEnt, int iRefLvl)
{ 
  pMAdaptDrvr->setAdaptLevel(pEntityEnt, iRefLvl); 
}


extern "C"
void MA_GetRefLvl(pMAdapt pMAdaptDrvr, pEntity pEntityEnt, int &iRefLvl)
{
  iRefLvl = pMAdaptDrvr->getAdaptLevel(pEntityEnt);
}


extern "C"
void MA_SetSizeFldFunc(pMAdapt pMAdaptDrvr, adaptSFunc SizeFldFunc)
{
  pMAdaptDrvr->SetSizeFldFunc(SizeFldFunc);
}


extern "C"
void MA_SetSizeFldType(pMAdapt pMAdaptDrvr, int iSizeFldType)
{
  pMAdaptDrvr->SetSizeFldType(iSizeFldType);
}


extern "C"
int MA_AnisoSmooth(pMAdapt pMAdaptDrvr, double dBeta[3])
{
  pSField SizeFld = pMAdaptDrvr->getSizeField();
  
  ((PWLsfield *)SizeFld)->anisoSmooth(dBeta);

  return 0;
}


extern "C"
int MA_Vtx_Size(pVertex pVertexVtx, double dAnisoSize[3][3])
{
  return adaptUtil::Vtx_Size(pVertexVtx, dAnisoSize);
}


extern "C"
void MA_SetQualityThreshold(meshAdapt *pMAdaptDrvr, double dQualThreshold)
{
  pMAdaptDrvr->setQualityCheckThreshold(dQualThreshold);
}


extern "C"
void MA_SetFirstLayerThicknessFlag(meshAdapt *pMAdaptDrvr, int isFirstLayerThicknessSet) 
{
  pMAdaptDrvr->SetFirstLayerThicknessFlag(isFirstLayerThicknessSet);
}


extern "C"
int MA_SetFirstLayerThickness(pMAdapt pMAdaptDrvr, pVertex pVertexVtx, double dFirstNodalSpacing)
{
  pMAdaptDrvr->SetFirstLayerThickness(pVertexVtx, dFirstNodalSpacing);
}


extern "C"
int MA_SetAdaptiveDecompFlag(pMAdapt pMAdaptDrvr, int iFlag)
{
  pMAdaptDrvr->SetBLTetrahedronization(iFlag);
  return 0;
}


extern "C"
int MA_SetAdaptiveDecomp_AspectRatioLimit(pMAdapt pMAdaptDrvr, double dBLAspectRatioLimit)
{
  pMAdaptDrvr->SetTetrahedronization_AspectRatioLimit(dBLAspectRatioLimit);
  return 0;
}


extern "C"
int MA_TetrahedralizeBL(pMAdapt pMAdaptDrvr)
{
  pMAdaptDrvr->getRefObj()->tetrahedronizeBL();
  return 0;
}


extern "C"
int MA_Mesh_TetrahedralizeBLs(pMeshMdl pMeshInstance)
{
  pMAdapt pMAdaptDrvr;
  MA_NewMeshAdaptDrvr(pMAdaptDrvr, pMeshInstance, Application);

  MA_TetrahedralizeBL(pMAdaptDrvr);

  MA_Del(pMAdaptDrvr);
  return 0;
}


extern "C"
int MA_DecompositionBL_AspectRatio(pMAdapt pMAdaptDrvr, double dAspectRatioLimit)
{
  pMAdaptDrvr->getRefObj()->Mesh_AdaptiveDecompBL(dAspectRatioLimit);
  return 0;
}


extern "C"
int MA_DecompositionBL_ForQuality(pMAdapt pMAdaptDrvr)
{
  pMAdaptDrvr->getRefObj()->Mesh_TetrahedralizePyramids();
  pMAdaptDrvr->getRefObj()->Mesh_AdaptiveDecompBL();
  return 0;
}


extern "C"
int MA_Mesh_DecompositionBL_ForQuality(pMeshMdl pMeshModel)
{
  pMAdapt pMAdaptDrvr;
  MA_NewMeshAdaptDrvr(pMAdaptDrvr, pMeshModel, Application);

  MA_DecompositionBL_ForQuality(pMAdaptDrvr);

  MA_Del(pMAdaptDrvr);
  return 0;
}
