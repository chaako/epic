#include "MeshSize.h"
#include "MeshEntTools.h"
#include <stdio.h>

MeshSize::MeshSize(double dirs[3][3], double hs[3])
{
  int i, min;
  double mag, vec[3];

  if( hs[0]<=0 || hs[1]<=0 || hs[2]<=0 ) {
    printf("Error: Negative desired size detected (MeshSize)\n");
    throw 1;
  }

  // sort the array such that smallest length being the first
  min=0;
  if( hs[0] > hs[1] )
    min=1;
  if( hs[min] > hs[2] )
    min=2;
  h[0]=hs[min];
  normVt(dirs[min],e[0]);

  ++min;
  if( hs[(min+1)%3] > hs[(min)%3] )
    {
      h[1]=hs[min%3];
      h[2]=hs[(min+1)%3];
      min=min%3;
    }
  else
    {
      h[1]=hs[(min+1)%3];
      h[2]=hs[min%3];
      min=(min+1)%3;
    }

  // project e[1] so that it is perpendicular to e[0]
  mag=dotProd(e[0],dirs[min]);
  for( i=0; i<3; i++ )
    vec[i]=dirs[min][i]-mag*e[0][i];
  normVt(vec,e[1]);

  crossProd(e[0],e[1],vec);
  normVt(vec,e[2]);
}


MeshSize::MeshSize(double hs)
{
  e[0][0]=1.0;
  e[0][1]=0.0;
  e[0][2]=0.0;
  e[1][0]=0.0;
  e[1][1]=1.0;
  e[1][2]=0.0;
  e[2][0]=0.0;
  e[2][1]=0.0;
  e[2][2]=1.0;
  h[0]=hs;
  h[1]=hs;
  h[2]=hs;
}

MeshSize::MeshSize(MeshSize *pm)
{
  e[0][0]=pm->e[0][0];
  e[0][1]=pm->e[0][1];
  e[0][2]=pm->e[0][2];
  e[1][0]=pm->e[1][0];
  e[1][1]=pm->e[1][1];
  e[1][2]=pm->e[1][2];
  e[2][0]=pm->e[2][0];
  e[2][1]=pm->e[2][1];
  e[2][2]=pm->e[2][2];
  h[0]=pm->h[0];
  h[1]=pm->h[1];
  h[2]=pm->h[2];
}


void MeshSize::scale(int dir, double factor)
{
  h[dir] *= factor;
}

void MeshSize::scale(double factor)
{
  h[0] *= factor;
  h[1] *= factor;
  h[2] *= factor;
}

// get the square of desired edge length along 'vec'
double MeshSize::dirLengthSq(double vec[3])
{
  double tvec[3];
  transform(vec,tvec);
  return dotProd(vec,vec)/dotProd(tvec,tvec);
}


void MeshSize::transform(double vec[3], double tvec[3])
{
  tvec[0]=dotProd(vec,e[0])/h[0];
  tvec[1]=dotProd(vec,e[1])/h[1];
  tvec[2]=dotProd(vec,e[2])/h[2];
}

// get maximum aspect ratio of the transformation >=1
double MeshSize::aspectRatio(int dim)
{
  if( dim==3 )
    return h[2]/h[0];
  else
    return h[1]/h[0];
}

double MeshSize::aspectRatio2(int i)
{
  switch ( i ) {
    case 0: return h[1]/h[0];
    case 1: return h[2]/h[1];
    default:
       printf("Error: i must be 1 or 1 (aspectRatio2)");
  }
  return 0;    
}
