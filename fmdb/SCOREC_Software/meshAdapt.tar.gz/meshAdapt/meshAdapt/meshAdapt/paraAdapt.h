#ifndef _H_PARAADAPT
#define _H_PARAADAPT


#ifdef MA_PARALLEL
#ifdef AOMD_
#include "mpi.h"
#include "FMDB_Internals.h"
#endif
#ifdef SIM
#endif

typedef std::pair<pEntity,int>  RemotePointer;

struct smoothPack {
  pVertex vertex;
  double e[3][3]; 
  double h[3];
};

struct classificationPack {
  pEntity ent;
  int chDir;      
  int tag;        // tag of geometry model entity the mesh entity is classified 
  int type;       // type of the geometry model entity
  double par[2];  // bookkeep the parameters in case of a boundary vertex
};

struct snapPack {
  pVertex vertex;
  int valid; 
};

struct remoteCopyPack {
  pEntity localInSend;
  int Uid;
  int type;
  int pid;

  pEntity remoteInSend;
};

class Edge_template {
 public:

  pEdge sender;         // the parent edge on sender
  pEdge receiver;       // the parent edge on receiver

  pVertex matchVert;    // the owner of vertex bounded by the 1st attached edge

  RemotePointer midVertPtr;   // the new middle vertex
  RemotePointer edgesPtr[2];  // the two new edges
};


class Face_template1 {
 public:

  pFace sender;          // parent face on sender
  pFace receiver;        // parent face on receiver

  pEdge matchEdge;       // the owner of edge bounded by the 1st attached face, but not by the 2nd

  RemotePointer   edgePtr;
  RemotePointer   facesPtr[2];
};


class Face_template2 {
 public:

  pFace sender;          // parent face on sender
  pFace receiver;        // parent face on receiver

  RemotePointer   edgesPtr[2];
  RemotePointer   facesPtr[3];
};



class Face_template3 {
 public:

  pFace sender;
  pFace receiver;

  pVertex vertices[3]; 

  RemotePointer   edgesPtr[3];
  RemotePointer   facesPtr[4];
};


#endif

#endif
