#ifndef _H_Fswap
#define _H_Fswap
 
#include "FMDB.h"

enum TRANSFORMATION { EMPTY,TWO2TWO, TRI2TWO, TWO2TRI } ;

typedef struct {
  enum TRANSFORMATION swapType; 
  pRegion oppRegs[2]; /* opposite regions of the face to be swapped */
  pVertex oppVrts[2]; /* opposite vertices of the face to be swapped */
  pFace   face;       /* face to be swapped */
  pRegion thirdReg;   /* in case of TRI2TWO this is the third region */
  pEdge edge;         /* in case of TWO2TWO this the edge to be swapped */
  int   cfg;          /* TWO2TWO edge swap configuration index */
} F_SwapConfig ;   


#endif
