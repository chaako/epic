#include "templateRefine.h"
#include "templateUtil.h"
#include <iostream>
#include <string.h>
#include "FMDB_cint.h"
#include <stdio.h>
using std::cout;
using std::endl;
using std::cerr;

#include "AdaptUtil.h"

#ifdef AOMD_
#include "PList.h"
#include "SGModel.h"
#include "MeshModel.h"
#include "FMDB_Internals.h"
#endif

#include "BLUtil.h"

#ifdef CURVE
#include "curveUtil.h"
#include "curveMesh.h"
using namespace curveUtil;
#endif





// if both ends of zero level layer (BL) edge are tagged with gcThicknessID
// then tag the new vertex (ONode) created due to split of zero level layer edge
// (not a good way but just a fix for now)
extern pMeshDataId gcThicknessID, remLayerNumberID;

/*
 * 2D refinement template with one marked edge
 *
 * Functionalities:
 *   retrieve the attached entities (one edge and two faces)
 *   if no data are attached, create the entities and attach them to the face
 *
 * The new faces are defined such that orientaion is the same as its parent
 * The new edges are always defined from middle edge vertex

   created:   05/08/99   X. Li
   Modified:  03/16/2000 add refining quadratic element stuff  X. Li
              03/08/2002 collect classification info to parent mesh  X. Li 
          
*/
pPList meshTemplate::get_split_faces_1(pFace face)
{
   void *temp_ptr;
   pPList plist;

   if(EN_getDataPtr((pEntity)face,ptr_reff,&temp_ptr)) {
    // the face is already split
     plist=(pPList)temp_ptr;
     return plist; 
   }
   else {
     // the face is not split yet
     int ne=F_numEdges(face);
     int split_edge;         // the index of the edge that will be split
     pEdge edges[5];         // the 5 edges to create the 2 new faces
     pVertex pvert;          // the middle vertex of the split edge
     pEdge parent_edges[3];  // the 3 parent edges
     int e_dirs[3];          // directions the face uses its 3 edges
     pVertex parent_verts[3];// the 3 parent vertices
     pEdge f_edges[3];       // the 3 edges to create a new face
     int   f_dirs[3];        // the 3 directions to create a new face
     pFace faces[2];         // the two new faces created
     pGEntity g_entity;
     int value;
     int i;
     int matchFlag=1;        // match flag 
    
     list<std::pair<int, pEntity> > mlist;       // the matched face list
     list<std::pair<int, pEntity> >::iterator mlistIter;


     // check if the face has matched faces
     if(!EN_isMatchEnt(face))  { 
       mlist.push_back(make_pair(0,face));
       matchFlag=0; 
     }
     else 
       EN_getMatchEnts(face, 0, mlist);
     
     void* it=0;
     pFace srcFace = face;                     // the given face 
     pEdge srcEdge;                            // the split edge of the given face  
     list<std::pair<int, pEntity> > srcEList;  // the matched edge list of the split edge: srcEdge
     list<pEntity> newEds, newFaces[2];        // the new matched edge list, the 2 new matched face lists
     pPList srcList;                           // the return list of the given face 

/*     
     // allocate the plists for the new match entity lists 
     if(matchFlag) {                
       newEds = PList_new(); 
       newFaces[0]=PList_new(); 
       newFaces[1]=PList_new(); 
     }
*/
     
     // get the split edge of the given face
     for(i=0; i<ne; i++) {
       parent_edges[i]=F_edge(face,i); 
       e_dirs[i]=F_edgeDir(face,i);
       if(EN_getDataInt((pEntity)parent_edges[i],int_reff,&value) && value==1) {
	 split_edge=i; 
	 break; 
       }
     }
     
     // get the matched edge list of one new edge derived from the split edge: srcEdge  
     // if no matched edges, the list contains the new edge itself  
     int eflag=0; 
     if(matchFlag){ 
       pPList elist=get_split_edges(parent_edges[split_edge]);
       if(e_dirs[split_edge]) 
	 srcEdge=(pEdge)PList_item(elist,1);
       else
	 srcEdge=(pEdge)PList_item(elist,2); 
       
       if(EN_isMatchEnt(srcEdge))
	 EN_getMatchEnts(srcEdge, 0, srcEList);
       else{
	 srcEList.push_back(make_pair(0,srcEdge));
	 eflag=1; 
       }
     }
     
     for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
     {
       face = mlistIter->second;
       
       // get the 3 parent vertices of the face
       pPList vlist=F_vertices(face,1); 
       void *temp=0;
       for(i=0; i<ne; i++)
	 parent_verts[i]=(pVertex)PList_next(vlist,&temp);
       PList_delete(vlist);
       
       // get the 3 parent edges of the face
       for(i=0; i<ne; i++) {
	 parent_edges[i]=F_edge(face,i);
	 e_dirs[i]=F_edgeDir(face,i);
       }
       
       // find the split edge index
       for(i=0; i<ne; i++)
	 if(EN_getDataInt((pEntity)parent_edges[i],int_reff,&value) && value==1) 
	   { split_edge=i; break; }
       
       // define the 5 edges to create the 2 faces
       edges[0]=F_edge(face,(split_edge+1)%3); 
       edges[1]=F_edge(face,(split_edge+2)%3);
       
       // get the two new edges of the split edge
       pPList elist=get_split_edges(parent_edges[split_edge]);
       pvert=(pVertex)PList_item(elist,0);
       if(e_dirs[split_edge]) {
	 edges[2]=(pEdge)PList_item(elist,1);
	 edges[3]=(pEdge)PList_item(elist,2);
       }
       else {
	 edges[2]=(pEdge)PList_item(elist,2);
	 edges[3]=(pEdge)PList_item(elist,1);
       }
       
       // create the interior edge 4
       int opposite=(split_edge+2)%3;
       g_entity=F_whatIn(face);
       edges[4]=M_createE(pmesh,pvert,parent_verts[opposite],g_entity);
       
       // put the new edge into the matched edge list 
       if(matchFlag) 
	 newEds.push_back(edges[4]); 
       
#ifdef CURVE
    // check if the edge needs curving
       if(templatesUtil::isFaceCurved(face)) {
           
           pPoint pt;
	   double ParamU, ParamV;

	   switch(split_edge)
           {
	     case 0:
	       ParamU = 0.25;
	       ParamV = 0.25;
	       break;

	     case 1:
	       ParamU = 0.5;
	       ParamV = 0.25;
	       break;
           
             case 2: 
	       ParamU = 0.25;
	       ParamV = 0.5;
	       break;
       	   
             default:
               break;
	   }
	   
	   if(E_whatInType(edges[4])!=3 && model_type==2){
	     double coords[3];
	     double params[3];
	     templatesUtil::middlePoint(edges[4], 0.5, coords, params);
	     pt = P_new();
	     P_setPos(pt, coords[0], coords[1], coords[2]);
	     E_setPoint(edges[4], pt);
	     FMDB_P_setParametricPos(pt, params[0], params[1], params[2]);
	   }
	   else{
	     pt = curveUtil::extractPt(pmesh, face, edges[4], ParamU, ParamV); 
	     E_setPoint(edges[4], pt);
             if(E_whatInType(edges[4])!=3)
	       FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0); 
	   }
	 
	   // try to reduce P-order here           <= please implement it
	   // }
	   // else
	   // 	   PList_append(curlist,edges[4]);
       }
#endif

    // now create the two faces with oriientation the same as its parent
    // always take the interior edge as the first edge
    f_edges[0]=edges[4];
    f_edges[1]=edges[1];
    f_edges[2]=edges[2];
    f_dirs[0]=1;
    f_dirs[1]=e_dirs[opposite];
    f_dirs[2]=e_dirs[split_edge];
    faces[0]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    f_edges[0]=edges[4];
    f_edges[1]=edges[3];
    f_edges[2]=edges[0];
    f_dirs[0]=0;
    f_dirs[1]=e_dirs[split_edge];
    f_dirs[2]=e_dirs[(split_edge+1)%3];
    faces[1]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);
    
    // put new faces into matched face lists based on the matching order 
    if(matchFlag) {
      if(find(srcEList.begin(), srcEList.end(), make_pair(0,edges[2])) != srcEList.end()) {
	newFaces[0].push_back(faces[0]);
	newFaces[1].push_back(faces[1]);
      }
      else {
        newFaces[0].push_back(faces[1]);
        newFaces[1].push_back(faces[0]);
      }
    }

    // set inverse classification info for one level 
    plist=PList_new();
    PList_append(plist,edges[4]);
    PList_append(plist,faces[0]);
    PList_append(plist,faces[1]);
    EN_attachDataPtr((pEntity)face,ptr_reff,plist);
    
    if(face==srcFace)
      srcList=plist; 
    
    // set classification info
    if(ChildToParent) {
      void *tmpPtr;
      if(!EN_getDataPtr((pEntity)face,ChildToParent,&tmpPtr)) 
	tmpPtr=(void *)face;
      EN_attachDataPtr((pEntity)edges[4],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[0],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[1],ChildToParent,tmpPtr);
    }      

    // activate callback
    if( function_CB ) {
      pPList newFaces=PList_new();
      pPList oldFaces=PList_new();
      PList_append(newFaces,faces[0]);   // if we append new faces before edges in plist
      PList_append(newFaces,faces[1]);   // we can simply call callCallback here
      PList_append(oldFaces,face);
      (function_CB)(oldFaces,newFaces,userData_CB,F_REFINE,0);
      PList_delete(oldFaces);
      PList_delete(newFaces);
    } 


#ifdef MA_PARALLEL
#ifdef AOMD_    // PAOMD
    pmEntity* mCB;
    mCB = EN_getCommonBdry((pEntity)face);
   //  if( ! mCB ) 
//       // we are a interior mesh entity
//       return plist;

    if(mCB) 
    {
    
      // set common boundary information first
      EN_setCommonBdry((pEntity)edges[4], mCB);
      EN_setCommonBdry((pEntity)faces[0], mCB);
      EN_setCommonBdry((pEntity)faces[1], mCB);

/// The matching functionality is not implemented in this communication pattern, thus only a pointer to the childs is used. See lines below
/// if need to append matching info along with children
      entities_to_update.push_back((pEntity)face);

/*
/// This lines should be merged with the already attached list of children, if possible, not to attach same data again
    list<pEntity> *ch_list;
    ch_list = new list<pEntity>;
    ch_list->push_back((pEntity)edges[4]);
    ch_list->push_back((pEntity)faces[0]);
    ch_list->push_back((pEntity)faces[1]);     
//    ch_list->push_back((pEntity)EN_getRemoteCopy(pmesh,(pEntity)edges[1],rpid));
    ch_list->push_back((pEntity)edges[1]);
    EN_attachDataPtr((pEntity)face, ptr_update, ch_list);     

    
    // we are on processor boundaries
    // set and send out the messages
    RemotePointer remotePtr;
    int pid;
    
    // we need looping over all our remote copies
    std::vector<RemotePointer > remoteCopies;
    EN_getRemoteCopies(pmesh, face, remoteCopies);
    std::vector<RemotePointer>::iterator rcIter = remoteCopies.begin();
    for (; rcIter!=remoteCopies.end(); ++rcIter)
      {
	pEntity remoteEnt = (*rcIter).first;
	int rpid = (*rcIter).second;    
	
	// rpid is the remote pid to send, 2 is the tag
	void *buf=AP_alloc(rpid,2,sizeof(Face_template1));
	Face_template1 *castbuf=(Face_template1 *)buf;
	
	// set the parent face and its remote copy
	castbuf->sender=face;
	castbuf->receiver=(pFace)remoteEnt; 
	
	// set the new mesh entities
	pid=M_Pid();
	castbuf->edgePtr.first  = edges[4];
	castbuf->edgePtr.second = pid;
	castbuf->facesPtr[0].first  = faces[0];
	castbuf->facesPtr[0].second = pid;
	castbuf->facesPtr[1].first  = faces[1];
	castbuf->facesPtr[1].second = pid;
	
	// set the edge bounded by the 1st attached face for matching
	castbuf->matchEdge = EN_getRemoteCopy(pmesh,(pEntity)edges[1],rpid);

	AP_send(buf);  
      }
*/
    }
#endif  // PAOMD
#endif  // MA_PARALLEL
     }

/*
     if(matchFlag==0)
       PList_delete(mlist);
     else{
       if(eflag)
	 PList_delete(srcEList);
     }
*/
     
     // build matched entity info
     if( matchFlag && newEds.size()>1) {
       EN_addLocalMatchEnts(newEds);               
       EN_addLocalMatchEnts(newFaces[0]);
       EN_addLocalMatchEnts(newFaces[1]);
     }
     
     // return plist; 
     return srcList;
   }
}

/*
 * 2D refinement template with two marked edges
 *
 * Functionalities:
 *   retrieve the attached entities (two edge and three faces)
 *   if no data are attached, create the entities and attach them to the face
 *
 * The new faces are defined such that orientaion is the same as its parent
 * The new edges are always defined such that the new middle face uses them positively

   The order of attaching and retrieving:
   (0)  interior edge normal to edge 12
   (1)  interior edge connecting the two new middle vertices
   (2)  face bouned by the unmarked edge
   (3)  the middle face
   (4)  face bounded by vertex 2

   There are two possiblities about how to splitting the face. We does not select the
   optimal diagonal yet
*/
pPList meshTemplate::get_split_faces_2(pFace face)
{
  void *temp_ptr;
  pPList plist;

  if(EN_getDataPtr((pEntity)face,ptr_reff,&temp_ptr))
    // the face is already split
    plist=(pPList)temp_ptr;

  else {
    // the face is not split yet
    int ne=F_numEdges(face);
    int zero;               // the index of unmarked edge
    int first, second;      // the 2 index of marked edge
    pEdge edges[7];         // the 7 edges to create the 3 new faces
    pEdge parent_edges[3];  // the 3 parent edges
    int e_dirs[3];          // directions the face uses its 3 edges
    pVertex verts[3];       // the 3 vertices and to create the 2 interior edges
    pEdge f_edges[3];       // the 3 edges to create a new face
    int   f_dirs[3];        // the 3 directions to create a new face
    pFace faces[3];         // the 3 new faces created
    pGEntity g_entity;
    int value;
    int i;

    // get the 3 parent edges of the face
    for(i=0; i<ne; i++) {
      parent_edges[i]=F_edge(face,i);
      e_dirs[i]=F_edgeDir(face,i);
    }

    // find index of the un-refined edge
    for(i=0; i<ne; i++)
      if(!EN_getDataInt((pEntity)parent_edges[i],int_reff,&value) || value!=1) {
        zero=i;
        break;
      }
    first = (zero+1)%3;
    second= (zero+2)%3;

    // get the first vertex
    pPList vlist=F_vertices(face,1);
    verts[0]=(pVertex)PList_item(vlist,zero);

    // define the first edge to create the 3 faces
    edges[0]=F_edge(face,zero);
//    }

    // get the two new edges of the first split edge
    pPList elist=get_split_edges(parent_edges[first]);
    verts[1]=(pVertex)PList_item(elist,0);
    if(e_dirs[first]) {
      edges[1]=(pEdge)PList_item(elist,1);
      edges[2]=(pEdge)PList_item(elist,2);
    }
    else {
      edges[1]=(pEdge)PList_item(elist,2);
      edges[2]=(pEdge)PList_item(elist,1);
    }

    // get the two new edges of the second split edge
    elist=get_split_edges(parent_edges[second]);
    verts[2]=(pVertex)PList_item(elist,0);
    if(e_dirs[second]) {
      edges[3]=(pEdge)PList_item(elist,1);
      edges[4]=(pEdge)PList_item(elist,2);
    }
    else {
      edges[3]=(pEdge)PList_item(elist,2);
      edges[4]=(pEdge)PList_item(elist,1);
    }

    // create the two interior edge 5 & 6
    g_entity=F_whatIn(face);
    edges[5]=M_createE(pmesh,verts[0], verts[1],g_entity);
    edges[6]=M_createE(pmesh,verts[1], verts[2],g_entity);

#ifdef CURVE
    // check if the edge needs curving
    if(templatesUtil::isFaceCurved(face)) {
      //if(GEN_type(g_entity)==Tregion) {
      pPoint pt;
      double ParamU[2];
      double ParamV[2];
      switch(zero) {
      case 0:
	ParamU[0] = 0.5;
	ParamV[0] = 0.25;
	ParamU[1] = 0.25;
	ParamV[1] = 0.25;

	break;

      case 1:
	ParamU[0] = 0.25;
	ParamV[0] = 0.5;
	ParamU[1] = 0.5;
	ParamV[1] = 0.25;

	break;
	 
      case 2:
	ParamU[0] = 0.25;
	ParamV[0] = 0.25;
	ParamU[1] = 0.25;
	ParamV[1] = 0.5;
	
	break;
        // try to reduce P-order here           <= please implement it
      } // end of switch
      if(E_whatInType(edges[5])!=3 && model_type==2){
	double coords[3];
	double params[3];
	templatesUtil::middlePoint(edges[5], 0.5, coords, params);
	pt = P_new();
	P_setPos(pt, coords[0], coords[1], coords[2]);
	E_setPoint(edges[5], pt);
	FMDB_P_setParametricPos(pt, params[0], params[1], params[2]);
      }
      else{
	pt = curveUtil::extractPt(pmesh, face, edges[5], ParamU[0], ParamV[0]); 
	E_setPoint(edges[5], pt); 
        if(E_whatInType(edges[5])!=3)
          FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0);
      }
      
      if(E_whatInType(edges[6])!=3 && model_type==2){
	double coords[3];
	double params[3];
	templatesUtil::middlePoint(edges[6], 0.5, coords, params);
	pt = P_new();
	P_setPos(pt, coords[0], coords[1], coords[2]);
	E_setPoint(edges[6], pt);
	FMDB_P_setParametricPos(pt, params[0], params[1], params[2]);
      }
      else{
	pt = curveUtil::extractPt(pmesh, face, edges[6], ParamU[1], ParamV[1]); 
	E_setPoint(edges[6], pt);
        if(E_whatInType(edges[6])!=3)
          FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0);
      }
      
      
    }
#endif
    
    // now create the three faces with oriientation the same as its parent
    // always take the interior edge as the first edge
    // if there are two interior, take the edge normal to 12 as the first
    f_edges[0]=edges[5];
    f_edges[1]=edges[0];
    f_edges[2]=edges[1];
    f_dirs[0]=0;
    f_dirs[1]=e_dirs[zero];
    f_dirs[2]=e_dirs[first];
    faces[0]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    f_edges[0]=edges[5];
    f_edges[1]=edges[6];
    f_edges[2]=edges[4];
    f_dirs[0]=1;
    f_dirs[1]=1;
    f_dirs[2]=e_dirs[second];
    faces[1]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    f_edges[0]=edges[6];
    f_edges[1]=edges[2];
    f_edges[2]=edges[3];
    f_dirs[0]=0;
    f_dirs[1]=e_dirs[first];
    f_dirs[2]=e_dirs[second];
    faces[2]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

//    if (!EN_isBLEntity(face))
//    if(!(E_typeInBL(parent_edges[0]) || E_typeInBL(parent_edges[1]) || E_typeInBL(parent_edges[2])))
//    {
      // check if this is the shorter diagonal edge
      double d0, d1;
      d0=pSizeField->lengthSq(verts[0], verts[1]);
      d1=pSizeField->lengthSq(verts[2], 
  			    (pVertex)PList_item(vlist,first));
      if( d1 < 0.97*d0 ) {
        PList_append(ambigEdges,edges[5]);
        PList_append(ambigEdges,verts[2]);
        PList_append(ambigEdges,E_otherVertex(edges[0],verts[0]));
      }
//    }
    PList_delete(vlist);

    // set inverse classification info - one level refinement only
    plist=PList_new();
    PList_append(plist,edges[5]);
    PList_append(plist,edges[6]);
    PList_append(plist,faces[0]);
    PList_append(plist,faces[1]);
    PList_append(plist,faces[2]);
    EN_attachDataPtr((pEntity)face,ptr_reff,plist);

    // set classification information 
    if(ChildToParent) {
      void *tmpPtr;
      if(!EN_getDataPtr((pEntity)face,ChildToParent,&tmpPtr)) 
	tmpPtr=(void *)face;
      EN_attachDataPtr((pEntity)edges[5],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)edges[6],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[0],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[1],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[2],ChildToParent,tmpPtr);
    }      

    // activate callback
    if( function_CB ) {
      pPList newFaces=PList_new();
      PList_append(newFaces,faces[0]);   // if we append new faces before edges in plist
      PList_append(newFaces,faces[1]);   // we can simply call callCallback here
      PList_append(newFaces,faces[2]); 
      pPList oldFaces=PList_new();
      PList_append(oldFaces,face);
      (function_CB)(oldFaces,newFaces,userData_CB,F_REFINE,0);
      PList_delete(oldFaces);
      PList_delete(newFaces);
    } 

#ifdef MA_PARALLEL
#ifdef AOMD_ // PAOMD
    pmEntity* mCB;
    mCB = EN_getCommonBdry((pEntity)face);
    if( ! mCB )
      // we are a interior mesh entity
      return plist;

    // set common boundary information first
    EN_setCommonBdry((pEntity)edges[5], mCB);
    EN_setCommonBdry((pEntity)edges[6], mCB);
    EN_setCommonBdry((pEntity)faces[0], mCB);
    EN_setCommonBdry((pEntity)faces[1], mCB);
    EN_setCommonBdry((pEntity)faces[2], mCB);
    
    entities_to_update.push_back((pEntity)face);

/*
    // we are on processor boundaries
    // set and send out the messages
    RemotePointer remotePtr;
    int pid;
    
    // we need looping over all our remote copies
    std::vector<RemotePointer > remoteCopies;
    EN_getRemoteCopies(pmesh, face, remoteCopies);
    std::vector<RemotePointer>::iterator rcIter = remoteCopies.begin();
    for (; rcIter!=remoteCopies.end(); ++rcIter)
      {
	pEntity remoteEnt = (*rcIter).first;
	pid = (*rcIter).second;    

	// rpid is the remote pid to send, 2 is the tag
	void *buf=AP_alloc(pid,3,sizeof(Face_template2));
	Face_template2 *castbuf=(Face_template2 *)buf;
	
	// set the parent face and its remote copy
	castbuf->sender=face;
	castbuf->receiver=(pFace)remoteEnt; 
	
	// set the new mesh entities
	pid=M_Pid();
	for( i=0;i<2;i++ ) {
	  castbuf->edgesPtr[i].first = edges[i+5];
	  castbuf->edgesPtr[i].second = pid;
	}
	for( i=0;i<3;i++ ) {
	  castbuf->facesPtr[i].first = faces[i];
	  castbuf->facesPtr[i].second = pid;
	}
	
	AP_send(buf);  
      }
*/
#endif  // PAOMD
#endif  // MA_PARALLEL
  }
  return plist;
}

/*
 * 2D refinement template with all edges marked (uniform refinement)
 *
 * The new faces are defined such that orientaion is the same as its parent
 * The new interior edges are defined such that: e3 3->4; e4 4->5; e5 5->3
 * the middle face use the 3 interior edges positively
 * the 3 corner faces select the interior edge as first edge
 *
 * Rules to attach entities:
 *  1. the order of attachment is only based on the order of the face
 *  2. attach the 3 interior edges first 0->2.
 *     First, the edge opposite to parent vertex 0
 *     then, the edge opposite to parent vertex 1
 *     finally, the edge opposite to parent vertex 2
 *  3. attach the 4 interior faces
 *     First, the face containing parent vertex 0
 *     then , the face containing parent vertex 1
 *     then , the face containing parent vertex 2
 *     finally,  the middle face
 */
pPList meshTemplate::get_split_faces_3(pFace face)
{
  void *temp_ptr;
  pPList elist;

  if(EN_getDataPtr((pEntity)face,ptr_reff,&temp_ptr)) {
    // the face is already split
    elist=(pPList)temp_ptr;
    return elist; 
  }
  else {

    // define entities' matching order (parent edges, new edges, new first 3 faces),
    // int fme[6][3]= {{0,1,2}, {2,0,1}, {1,2,0}, {2,1,0}, {1,0,2}, {0,2,1}}
    int nme[6][3]= {{6,7,8}, {8,6,7}, {7,8,6}, {7,6,8}, {6,8,7}, {8,7,6}}; 
    int nmf[6][3]= {{0,1,2}, {2,0,1}, {1,2,0}, {0,2,1}, {2,1,0}, {1,0,2}}; 

    // define the double matching order
    int dmf[3][3]= {{0,1,2}, {1,2,0}, {2,0,1}}; 
    int dme[3][3]= {{2,0,1}, {0,1,2}, {1,2,0}}; 
    
    pEdge edges[9];         // the 9 edges to create the 4 faces
    int e_dirs[3];          // the directions face uses its three edges
    pVertex verts[3];       // the 3 middle edge vertices
    pEdge f_edges[3];       // the 3 edges to create a face
    int   f_dirs[3];        // the 3 directions the face will use its edges
    pFace faces[4];         // the 4 new faces that will be created
    pEdge parent_edges[3];
    int ne=F_numEdges(face);
    pPList plist;
    int i;
  
    pFace srcFace = face; 
    list<std::pair<int, pEntity> > srcVList[3];    // the 3 matched vertex lists
    list<std::pair<int, pEntity> > srcEList[2];    // the 2 matched edge lists, in double match condition (2 edges in one face match each other) 
    void* it=0; 
    pPList srcList;        
    list<pEntity> newEdges[3];    // the 3 new matched edge lists
    list<pEntity> newFaces[4];    // the 4 new matched face lists    
    int matchFlag=1;       // matched mesh flag 
    int dblMatchFlag=0;    // matched mesh with double match condition flag  
    int nonDblMatchEd;     // the edge without double match condition 
    int vflags[3];         // flags to delete 3 matched vertex lists      
    int eflags[2];         // flags to delete 2 matched edge lists
   
    list<std::pair<int, pEntity> > mlist;       // the matched face list
    list<std::pair<int, pEntity> >::iterator mlistIter;
 
    // check if the face has matched faces
    if(!EN_isMatchEnt(face)) {
       mlist.push_back(make_pair(0,face));
      matchFlag=0; 
    }
    else
      EN_getMatchEnts(face, 0, mlist);
    
    // get the matched vertex lists of the new vertices
    // if no matched vertices, the lists contain the vertices themselves
    if(matchFlag) {
      for(i=0; i<ne; i++) {
	vflags[i]=0; 
	parent_edges[i]=F_edge(srcFace,i);
	plist=get_split_edges(parent_edges[i]);
	verts[i]=(pVertex)PList_item(plist,0); 
	if(EN_isMatchEnt(verts[i])) 
	  EN_getMatchEnts(verts[i], 0, srcVList[i]);  
	else { 
	  srcVList[i].push_back(make_pair(0,verts[i]));
	  vflags[i]=1; 
	}
      }
      
      // check the double match condition
      for(int i=0; i<3; i++) {
	if( find(srcVList[i].begin(), srcVList[i].end(), make_pair(0,verts[(i+1)%3])) != srcVList[i].end()) {
	  nonDblMatchEd=(i+2)%3; 
       	  dblMatchFlag=1; 
	  break; 
	}
        if( find(srcVList[i].begin(), srcVList[i].end(), make_pair(0,verts[(i+2)%3])) != srcVList[i].end()) {
	  nonDblMatchEd=(i+1)%3; 
       	  dblMatchFlag=1; 
	  break; 
	}
      }
      
      // get the matched edge lists of the new edges derived from the edge without double match condition
      // if no matched edges, the lists contain the edges themselves
      if(dblMatchFlag==1) {
	int e_dir=F_edgeDir(srcFace,nonDblMatchEd);
	plist=get_split_edges(parent_edges[nonDblMatchEd]); 
	pEdge e; 
	if (e_dir) 
	  for(int i=0; i<2; i++) {
	    eflags[i]=0; 
	    e=(pEdge)PList_item(plist,i+1); 
	    if(EN_isMatchEnt(e)) 
	      EN_getMatchEnts(e, 0, srcEList[i]);   
	    else {
	      srcEList[i].push_back(make_pair(0, e));
	      eflags[i]=1; 
	    }
	  }
	else 
	  for(int i=0; i<2; i++) {
	    eflags[i]=0; 
	    if(i==0)
	      e=(pEdge)PList_item(plist,2);
	    else
	      e=(pEdge)PList_item(plist,1);
	    if(EN_isMatchEnt(e)) 
	      EN_getMatchEnts(e, 0, srcEList[i]);   
	    else {
	      srcEList[i].push_back(make_pair(0, e));
	      eflags[i]=1; 
	    }
	  }
      }
/* 
      // allocate the new pLists 
      for(int i=0; i<3; i++)
	newEdges[i]=PList_new(); 
      for(int i=0; i<4; i++)
	newFaces[i]=PList_new(); 
*/
    } // if(matchFlag)
    
     for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
     {
       face = mlistIter->second;

      // get the 3 parent edges of the face
      for(i=0; i<ne; i++) {
	parent_edges[i]=F_edge(face,i);
	e_dirs[i]=F_edgeDir(face,i);
      }
     
    // get the 6 boundary edges to create new faces
    // edge 0
    plist=get_split_edges(parent_edges[0]);
    verts[0]=(pVertex)PList_item(plist,0);
    if(e_dirs[0]) {
      edges[0]=(pEdge)PList_item(plist,1);
      edges[1]=(pEdge)PList_item(plist,2);
    } else {
      edges[0]=(pEdge)PList_item(plist,2);
      edges[1]=(pEdge)PList_item(plist,1);
    }
    
    // edge 1
    plist=get_split_edges(parent_edges[1]);
    verts[1]=(pVertex)PList_item(plist,0);
    if(e_dirs[1]) {
      edges[2]=(pEdge)PList_item(plist,1);
      edges[3]=(pEdge)PList_item(plist,2);
    } else {
      edges[2]=(pEdge)PList_item(plist,2);
      edges[3]=(pEdge)PList_item(plist,1);
    }

    // edge 2
    plist=get_split_edges(parent_edges[2]);
    verts[2]=(pVertex)PList_item(plist,0);
    if(e_dirs[2]) {
      edges[4]=(pEdge)PList_item(plist,1);
      edges[5]=(pEdge)PList_item(plist,2);
    } else {
      edges[4]=(pEdge)PList_item(plist,2);
      edges[5]=(pEdge)PList_item(plist,1);
    }

  
    // get the matching order in non-double match condition  
    int morder=0; 
    if(matchFlag) {
      if(srcFace==face)
	morder=0; 
      else {
	if(!dblMatchFlag) {
          if( find(srcVList[0].begin(), srcVList[0].end(), make_pair(0,verts[0])) != srcVList[i].end()) {
            if( find(srcVList[1].begin(), srcVList[1].end(), make_pair(0,verts[1])) != srcVList[i].end())
	      morder=0;                     
	    else
	      morder=5; 
	  }
	  else  
            if( find(srcVList[0].begin(), srcVList[0].end(), make_pair(0,verts[1])) != srcVList[i].end()) {
              if( find(srcVList[1].begin(), srcVList[1].end(), make_pair(0,verts[2])) != srcVList[i].end()) 
		morder=2; 
	      else
		morder=4; 
	    }
	    else {
              if( find(srcVList[1].begin(), srcVList[1].end(), make_pair(0,verts[0])) != srcVList[i].end())
		morder=1; 
	      else
		morder=3; 
	    }
	}
      }
    }
    
    // create the 3 interior edges
    // edge[6]: v0->v1; edge[7]: v1->v2; edge[8]: v2->v0
    pGEntity g_entity=F_whatIn(face);
    for(i=0; i<ne; i++) {
      edges[i+6]=M_createE(pmesh,verts[i],verts[(i+1)%3],g_entity);
    }

#ifdef CURVE
    // check if the edge needs curving
    if(templatesUtil::isFaceCurved(face)) {
      //if(GEN_type(g_entity)==Tregion) {

      pPoint pt;

      if(E_whatInType(edges[6])!=3 && model_type==2){
	double coords[3];
	double params[3];
	templatesUtil::middlePoint(edges[6], 0.5, coords, params);
	pt = P_new();
	P_setPos(pt, coords[0], coords[1], coords[2]);
	E_setPoint(edges[6], pt);
	FMDB_P_setParametricPos(pt, params[0], params[1], params[2]);
      }
      else{
	pt = curveUtil::extractPt(pmesh, face, edges[6], 0.25, 0.5); 
	E_setPoint(edges[6], pt); 
        if(E_whatInType(edges[6])!=3)
	  FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0);
      }

      if(E_whatInType(edges[7])!=3 && model_type==2){
	double coords[3];
	double params[3];
	templatesUtil::middlePoint(edges[7], 0.5, coords, params);
	pt = P_new();
	P_setPos(pt, coords[0], coords[1], coords[2]);
	E_setPoint(edges[7], pt);
	FMDB_P_setParametricPos(pt, params[0], params[1], params[2]);
      }
      else{
	pt = curveUtil::extractPt(pmesh, face, edges[7], 0.25, 0.25); 
	E_setPoint(edges[7], pt); 
        if(E_whatInType(edges[7])!=3)
	  FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0);
      }

      if(E_whatInType(edges[8])!=3 && model_type==2){
	double coords[3];
	double params[3];
	templatesUtil::middlePoint(edges[8], 0.5, coords, params);
	pt = P_new();
	P_setPos(pt, coords[0], coords[1], coords[2]);
	E_setPoint(edges[8], pt);
	FMDB_P_setParametricPos(pt, params[0], params[1], params[2]);
      }
      else{
	pt = curveUtil::extractPt(pmesh, face, edges[8], 0.5, 0.25); 
	E_setPoint(edges[8], pt); 
        if(E_whatInType(edges[8])!=3)
	  FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0);
      }
     
   
        // try to reduce P-order here           <= please implement it
    } 

#endif

    // create the 4 interior faces
    // here we always select the interior edge as the first edge
    f_edges[0]=edges[8];
    f_edges[1]=edges[5];
    f_edges[2]=edges[0];
    f_dirs[0]=0;
    f_dirs[1]=e_dirs[2];
    f_dirs[2]=e_dirs[0];
    faces[0]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    f_edges[0]=edges[6];
    f_edges[1]=edges[1];
    f_edges[2]=edges[2];
    f_dirs[0]=0;
    f_dirs[1]=e_dirs[0];
    f_dirs[2]=e_dirs[1];
    faces[1]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    f_edges[0]=edges[7];
    f_edges[1]=edges[3];
    f_edges[2]=edges[4];
    f_dirs[0]=0;
    f_dirs[1]=e_dirs[1];
    f_dirs[2]=e_dirs[2];
    faces[2]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);
    
    // use the interior edge opposite to parent_vertex[0] as the first edge
    f_edges[0]=edges[8];
    f_edges[1]=edges[6];
    f_edges[2]=edges[7];
    f_dirs[0]=1;
    f_dirs[1]=1;
    f_dirs[2]=1;
    faces[3]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    // make the correct matching order 
    if(matchFlag) {
      if(!dblMatchFlag) 
	for(int i=0; i<3; i++) {
	  newEdges[i].push_back(edges[nme[morder][i]]);
	  newFaces[i].push_back(faces[nmf[morder][i]]);
	}
      else 	
	if(srcFace==face) 
	  for(int i=0; i<3; i++) {
	    newEdges[i].push_back(edges[nme[0][i]]);
	    newFaces[i].push_back(faces[nmf[0][i]]);
	  }
	else {
	  int fe[4]; 
	  int x[2]; 
	  
	  // edges[x[0]]/edges[x[1]] matches the new edge, derived from the edge without double match condition
	  for(int i=0; i<3; i++) {
	    if( find(srcEList[0].begin(), srcEList[0].end(), make_pair(0,edges[i*2])) != srcEList[0].end()) 
              fe[0] = 1;
            else
              fe[0] = 0;
            if( find(srcEList[1].begin(), srcEList[1].end(), make_pair(0,edges[i*2+1])) != srcEList[1].end())
              fe[1] = 1;
            else
              fe[1] = 0;
            if( find(srcEList[0].begin(), srcEList[0].end(), make_pair(0,edges[i*2+1])) != srcEList[0].end())
              fe[2] = 1;
            else
              fe[2] = 0;
            if( find(srcEList[1].begin(), srcEList[1].end(), make_pair(0,edges[i*2])) != srcEList[1].end())
              fe[3] = 1;
            else
              fe[3] = 0;
	    
	    if(fe[0]&&fe[1]) {
	      x[0]=i*2; 
	      x[1]=i*2+1; 
	      break; 
	    }
	    if(fe[2]&&fe[3]) {
	      x[0]=i*2+1; 
	      x[1]=i*2; 
	      break; 
	    }
	  }
	  
	  int fids[2] = {-1,-1}; 
	  int eids[2] = { 0, 0};  
	  
	  for(int i=0; i<2; i++) {
	    
	    // get the new face 'f' adjacent to edges[x[i]]
	    pPList flist=E_faces(edges[x[i]]);
	    void* it=0; 
	    pFace f;  
	    while(f=(pFace)PList_next(flist, &it)) {
	      for(int j=0; j<3; j++)
		if(f==faces[j]) {
		  fids[i]=j; 
		  break; 
		}
	      if(fids[i]>0)
		break; 
	    }
	    PList_delete(flist);
	    newFaces[dmf[nonDblMatchEd][i]].push_back(faces[fids[i]]);
	    
	    // get the new edge adjacent to the new face 'f' 
	    pPList elist=F_edges(faces[fids[i]],0,(pVertex) 0);
	    for(int j=0; j<3; j++) 
	      if(PList_inList(elist, (void*)edges[j+6])){
		eids[i]=j+6; 
		newEdges[dme[nonDblMatchEd][i]].push_back(edges[j+6]);
		break; 
	      }
	    PList_delete(elist);
	  }
	  
	  // find the new face and new edge not adjacent to the edge without double match condition
	  for(int i=0; i<3; i++) {
	    if(i!=fids[0] && i!=fids[1]) 
	      newFaces[dmf[nonDblMatchEd][2]].push_back(faces[i]); 
	    if((i+6)!=eids[0] && (i+6)!=eids[1])
	      newEdges[dme[nonDblMatchEd][2]].push_back(edges[i+6]); 
	  }
	} // if(srcFace==face)

      // the middle face
      newFaces[3].push_back(faces[3]);
    }
    
    // set inverse classification info - one level only
    elist=PList_new();
    PList_append(elist,edges[8]);
    PList_append(elist,edges[6]);
    PList_append(elist,edges[7]);
    PList_append(elist,faces[0]);
    PList_append(elist,faces[1]);
    PList_append(elist,faces[2]);
    PList_append(elist,faces[3]);
    EN_attachDataPtr((pEntity)face,ptr_reff,elist);

    if(face==srcFace)
      srcList=elist; 
    
    // set classification info
    if(ChildToParent) {
      void *tmpPtr;
      if(!EN_getDataPtr((pEntity)face,ChildToParent,&tmpPtr)) 
	tmpPtr=(void *)face;
      EN_attachDataPtr((pEntity)edges[6],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)edges[7],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)edges[8],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[0],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[1],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[2],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)faces[3],ChildToParent,tmpPtr);
    }      

    // activate callback
    if( function_CB ) {
      pPList newFaces=PList_new();
      PList_append(newFaces,faces[0]);   // if we append new faces before edges in plist
      PList_append(newFaces,faces[1]);   // we can simply call callCallback here
      PList_append(newFaces,faces[2]);
      PList_append(newFaces,faces[3]);
      pPList oldFaces=PList_new();
      PList_append(oldFaces,face);
      (function_CB)(oldFaces,newFaces,userData_CB,F_REFINE,0);
      PList_delete(oldFaces);
      PList_delete(newFaces);
    } 


#ifdef MA_PARALLEL
#ifdef AOMD_  // PAOMD
    
    pmEntity* mCB;
    mCB = EN_getCommonBdry((pEntity)face);
 //    if( ! mCB )
//       // we are a interior mesh entity
//       return elist;

    if(mCB) {

    // set common boundary information first
    EN_setCommonBdry((pEntity)edges[6], mCB);
    EN_setCommonBdry((pEntity)edges[7], mCB);
    EN_setCommonBdry((pEntity)edges[8], mCB);
    EN_setCommonBdry((pEntity)faces[0], mCB);
    EN_setCommonBdry((pEntity)faces[1], mCB);
    EN_setCommonBdry((pEntity)faces[2], mCB);
    EN_setCommonBdry((pEntity)faces[3], mCB);

    entities_to_update.push_back((pEntity)face);

/*
    // we are on processor boundaries
    // set and send out the messages
    RemotePointer remotePtr;
    int pid;
    
    // get the three bounding vertices of parent face
    pPList fverts = F_vertices(face,1);
    pVertex vertex;
    void *iter;

    // we need looping over all our remote copies
    std::vector<RemotePointer > remoteCopies;
    EN_getRemoteCopies(pmesh, face, remoteCopies);
    std::vector<RemotePointer>::iterator rcIter = remoteCopies.begin();
    for (; rcIter!=remoteCopies.end(); ++rcIter)
      {
	pEntity remoteEnt = (*rcIter).first;
	int rpid = (*rcIter).second;   

	void *buf=AP_alloc(rpid,4,sizeof(Face_template3));
	Face_template3 *castbuf=(Face_template3 *)buf;
	
	// set the parent face and its remote copy
	castbuf->sender=face;
	castbuf->receiver=(pFace)remoteEnt;
	
	// set the three vertices of parent face for matching
	iter=0; i=0;
	while( vertex=(pVertex)PList_next(fverts,&iter) ) {
	  castbuf->vertices[i] = EN_getRemoteCopy(pmesh,(pEntity)vertex,rpid);
	  i++;
	}

	//	printf("%d: send out match vertex %p %p %p\n",M_Pid(), castbuf->vertices[0],
	//	       castbuf->vertices[1],castbuf->vertices[2]);

	// set the new mesh entities
	pid=M_Pid();
	castbuf->edgesPtr[0].second = pid;
	castbuf->edgesPtr[1].second = pid;
	castbuf->edgesPtr[2].second = pid;
	castbuf->edgesPtr[0].first = edges[8];
	castbuf->edgesPtr[1].first = edges[6];
	castbuf->edgesPtr[2].first = edges[7];
	
	for( i=0; i<4; i++ ) {
	  castbuf->facesPtr[i].first = faces[i];
	  castbuf->facesPtr[i].second = pid;
	}
	
	AP_send(buf);  
      }
    PList_delete(fverts); 
*/
    }
#endif // PAOMD
#endif  // MA_PARALLEL
    }
/*    
    if(matchFlag==0) 
      PList_delete(mlist);
    else {
      for(int i=0; i<ne; i++) 
	if(vflags[i])
	  PList_delete(srcVList[i]);
      
      if(dblMatchFlag) {
	for(int i=0; i<2; i++)
	  if(eflags[i])
	    PList_delete(srcEList[i]);
      }
    }
*/    
    // build matched entity info
    if( matchFlag && newEdges[0].size()>1) {
      for(int i=0; i<3; i++) {
	EN_addLocalMatchEnts(newEdges[i]);                  
	EN_addLocalMatchEnts(newFaces[i]);
      }
      EN_addLocalMatchEnts(newFaces[3]);
    }
    
    // return elist;
    return srcList; 
  }
}


pPList meshTemplate::get_bisected_faces(pFace face) {
  void *temp_ptr;
  pPList plist;

  if(EN_getDataPtr((pEntity)face,ptr_reff,&temp_ptr))
    // the face is already bisected
    plist=(pPList)temp_ptr;
  else {
    // the face is not bisected yet
    int ne = F_numEdges(face);

    if(ne==3) {
      plist = bisect_tri(face);
    }
    else if(ne==4){
      plist = bisect_quad(face);
    }
    else {
      cout<<"\nError in get_bisected_faces()..."<<endl;
      cout<<"face is NOT triangular/quadilateral"<<endl;
      exit(0);
    }
  }

  return plist;
}

/*
 * 2D refinement (bisection) template with two opp. edges or one edge of tri. face marked
 *
 * Functionalities:
 *   retrieve the attached entities (one edge and two faces)
 *   if no data are attached, create the entities and attach them to the face
 *
 * The new faces are defined such that orientation is the same as its parent
 * The new edge is defined from marked edge next to first unmarked edge to other marked edge (Case A) or from marked edge to opp. vertex (Case B)

   The order of attaching and retrieving:
   Case A - two edges marked
     (0)  interior edge
     (1)  face bounded by unmarked edge, i.e., quad face
     (2)  face not bounded by unmarked edge, i.e., tri face
   Case B - one edge marked
          see get_split_faces_1()
*/

pPList meshTemplate::bisect_tri(pFace face) {

  int ne=F_numEdges(face);
  int order[3];
  pEdge edges[6];         // the 6 (or 5) edges to create the 2 new faces
  pEdge parent_edges[3];  // the 3 parent edges
  int e_dirs[3];          // directions the face uses its 3 edges
  pVertex verts[2];       // the 2 vertices to create a new edge
  pEdge f_edges[4];       // the 4 (or 3) edges to create new face
  int   f_dirs[4];        // the 4 (or 3) directions to create new face
  pFace faces[2];         // the 2 new faces created
  pGEntity g_entity;
  int value, numTaggedEdges = 0;

  // get the 3 parent edges of the face
  for(int iEdge=0; iEdge<ne; iEdge++) {
    parent_edges[iEdge]=F_edge(face,iEdge);
    e_dirs[iEdge]=F_edgeDir(face,iEdge);
    if( EN_getDataInt((pEntity)parent_edges[iEdge],int_reff,&value) &&
        value==1 )
      numTaggedEdges++;
  }

  pPList plist;
  if(numTaggedEdges==1) {
    plist=get_split_faces_1(face);
  }
  else {
    // find index of the first un-refined/un-marked edge
    for(int iEdge=0; iEdge<ne; iEdge++) {
      if( !EN_getDataInt((pEntity)parent_edges[iEdge],int_reff,&value) ||
          value!=1 ) {
        order[0]=iEdge;
        break;
      }
    }

    order[1]=(order[0]+1)%3;
    order[2]=(order[0]+2)%3;

    // get the first unmarked edge
    edges[0]=parent_edges[order[0]];

    // get the two new edges of the first split edge
    pPList elist=get_split_edges(parent_edges[order[1]]);

    verts[0]=(pVertex)PList_item(elist,0);
    if(e_dirs[order[1]]) {
      edges[1]=(pEdge)PList_item(elist,1);
      edges[2]=(pEdge)PList_item(elist,2);
    }
    else {
      edges[1]=(pEdge)PList_item(elist,2);
      edges[2]=(pEdge)PList_item(elist,1);
    }

    // get the two new edges of the first split edge
    pPList elist1=get_split_edges(parent_edges[order[2]]);

    verts[1]=(pVertex)PList_item(elist1,0);
    if(e_dirs[order[2]]) {
      edges[3]=(pEdge)PList_item(elist1,1);
      edges[4]=(pEdge)PList_item(elist1,2);
    }
    else {
      edges[3]=(pEdge)PList_item(elist1,2);
      edges[4]=(pEdge)PList_item(elist1,1);
    }

    g_entity=F_whatIn(face);
    edges[5]=M_createE(pmesh,verts[0],verts[1],g_entity);

    // now create the two new faces with same orientation as parent
    // new edge is first edge for the new faces
    f_edges[0]=edges[5];
    f_edges[1]=edges[4];
    f_edges[2]=edges[0];
    f_edges[3]=edges[1];
    f_dirs[0]=1;
    f_dirs[1]=e_dirs[order[2]];
    f_dirs[2]=e_dirs[order[0]];
    f_dirs[3]=e_dirs[order[1]];

    faces[0]=M_createF(pmesh,4,f_edges,f_dirs,g_entity);

    f_edges[0]=edges[5];
    f_edges[1]=edges[2];
    f_edges[2]=edges[3];
    f_dirs[0]=0;
    f_dirs[1]=e_dirs[order[1]];
    f_dirs[2]=e_dirs[order[2]];
    faces[1]=M_createF(pmesh,3,f_edges,f_dirs,g_entity);

    plist = PList_new();
    PList_append(plist,edges[5]);
    PList_append(plist,faces[0]);
    PList_append(plist,faces[1]);
    EN_attachDataPtr((pEntity)face,ptr_reff,plist);

    // activate callback
    if( function_CB ) {
      pPList newFaces=PList_new();
      PList_append(newFaces,faces[0]);
      PList_append(newFaces,faces[1]);
      pPList oldFaces=PList_new();
      PList_append(oldFaces,face);
      (function_CB)(oldFaces,newFaces,userData_CB,F_REFINE,0);
      PList_delete(oldFaces);
      PList_delete(newFaces);
    }

#ifdef MA_PARALLEL
#ifdef AOMD_  // PAOMD

    pmEntity* mCB;
    mCB = EN_getCommonBdry((pEntity)face);
 //    if( ! mCB )
//       // we are a interior mesh entity
//       return elist;

    if(mCB) {

      // set common boundary information first
      EN_setCommonBdry((pEntity)edges[5], mCB);
      EN_setCommonBdry((pEntity)faces[0], mCB);
      EN_setCommonBdry((pEntity)faces[1], mCB);

      entities_to_update.push_back((pEntity)face);
    }

#endif // PAOMD
#endif // MA_PARALLEL

  }

  return plist;
}

/*
 * 2D refinement (bisection) template with two opp. edges of quad. face marked
 *
 * Functionalities:
 *   retrieve the attached entities (one edge and two faces)
 *   if no data are attached, create the entities and attach them to the face
 *
 * The new faces are defined such that orientation is the same as its parent
 * -- ?? The new edge is defined with orientation opposite to the first unmarked edge
 * The new edge is defined from marked edge next to first unmarked edge to other marked edge

   The order of attaching and retrieving:
   (0)  interior edge
   (1)  face bounded by the first unmarked edge
   (2)  face bounded by the second unmarked edge
*/

pPList meshTemplate::bisect_quad(pFace face) 
{
  void *temp_ptr;
  pPList plist;

  if(EN_getDataPtr((pEntity)face,ptr_reff,&temp_ptr)) 
  {
    // the face is already split
    plist=(pPList)temp_ptr;
    return plist;
  }

  int ne=F_numEdges(face);
  int order[4];
  pEdge edges[7];         // the 7 edges to create the 2 new faces
  pEdge parent_edges[4];  // the 4 parent edges
  int e_dirs[4];          // directions the face uses its 4 edges
  pVertex verts[2];       // the 2 vertices to create a new edge
  pEdge f_edges[4];       // the 4 edges to create new face
  int   f_dirs[4];        // the 4 directions to create new face
  pFace faces[2];         // the 2 new faces created
  pGEntity g_entity;
  int value;

  // get the 4 parent edges of the face
  for(int iEdge=0; iEdge<ne; iEdge++) {
    parent_edges[iEdge]=F_edge(face,iEdge);
    e_dirs[iEdge]=F_edgeDir(face,iEdge);
  }

  // find index of the first un-refined edge
  for(int iEdge=0; iEdge<ne; iEdge++) {
    if( !EN_getDataInt((pEntity)parent_edges[iEdge],int_reff,&value) ||
        value!=1 ) {
      order[0]=iEdge;
      break;
    }
  }
//  order[0] = (order[0]+2)%4;
  order[1] = (order[0]+1)%4;
  order[2] = (order[0]+2)%4;
  order[3] = (order[0]+3)%4;

  // get the first unmarked edge
  edges[0]=parent_edges[order[0]];

  // get the two new edges of the first split edge
  pPList elist=get_split_edges(parent_edges[order[1]]);

  verts[0]=(pVertex)PList_item(elist,0);
  if(e_dirs[order[1]]) {
    edges[1]=(pEdge)PList_item(elist,1);
    edges[2]=(pEdge)PList_item(elist,2);
  }
  else {
    edges[1]=(pEdge)PList_item(elist,2);
    edges[2]=(pEdge)PList_item(elist,1);
  }

  edges[3] = parent_edges[order[2]];

  // get the two new edges of the first split edge
  pPList elist1=get_split_edges(parent_edges[order[3]]);

  verts[1]=(pVertex)PList_item(elist1,0);
  if(e_dirs[order[3]]) {
    edges[4]=(pEdge)PList_item(elist1,1);
    edges[5]=(pEdge)PList_item(elist1,2);
  }
  else {
    edges[4]=(pEdge)PList_item(elist1,2);
    edges[5]=(pEdge)PList_item(elist1,1);
  }

  g_entity=F_whatIn(face);

  edges[6]=M_createE(pmesh,verts[0],verts[1],g_entity);

//   // create new edge with opp. orientation as first unmarked edge
//   if(e_dirs[order[0]])
//     edges[6]=M_createE(pmesh,verts[0],verts[1],g_entity);
//   else
//     edges[6]=M_createE(pmesh,verts[1],verts[0],g_entity);

  // now create the two new faces with same orientation as parent
  // ?? first unmarked edge is first edge for the first new face
  // ?? new edge is first edge for the second new face
  // --- osahni : actually first edge of the faces depend upon "order[]"
  // changed : new edge is the first edge for both the new faces
  f_edges[0]=edges[6];
  f_edges[1]=edges[5];
  f_edges[2]=edges[0];
  f_edges[3]=edges[1];
  f_dirs[0]=1;
  f_dirs[1]=e_dirs[order[3]];
  f_dirs[2]=e_dirs[order[0]];
  f_dirs[3]=e_dirs[order[1]];
  faces[0]=M_createF(pmesh,4,f_edges,f_dirs,g_entity);

  f_edges[0]=edges[6];
  f_edges[1]=edges[2];
  f_edges[2]=edges[3];
  f_edges[3]=edges[4];
  f_dirs[0]=0;
  f_dirs[1]=e_dirs[order[1]];
  f_dirs[2]=e_dirs[order[2]];
  f_dirs[3]=e_dirs[order[3]];
  faces[1]=M_createF(pmesh,4,f_edges,f_dirs,g_entity);

  /// Attach the remote level number, if the face split is the part of a region detached from the BL stack
  if (EN_remLevelInBL(face) > -1)
  {
    int iRemLevelBL = EN_remLevelInBL(face);
    EN_attachDataInt(edges[6], remLayerNumberID, iRemLevelBL);
    EN_attachDataInt(faces[0], remLayerNumberID, iRemLevelBL);
    EN_attachDataInt(faces[1], remLayerNumberID, iRemLevelBL);
  }

  plist = PList_new();
  PList_append(plist,edges[6]);
  PList_append(plist,faces[0]);
  PList_append(plist,faces[1]);
  EN_attachDataPtr((pEntity)face,ptr_reff,plist);

  // set classification info
  if(ChildToParent) {
    void *tmpPtr;
    if(!EN_getDataPtr((pEntity)face,ChildToParent,&tmpPtr))
      tmpPtr=(void *)face;
    EN_attachDataPtr((pEntity)edges[6],ChildToParent,tmpPtr);
    EN_attachDataPtr((pEntity)faces[0],ChildToParent,tmpPtr);
    EN_attachDataPtr((pEntity)faces[1],ChildToParent,tmpPtr);
  }

  // activate callback
  if( function_CB ) {
    pPList newFaces=PList_new();
    PList_append(newFaces,faces[0]);
    PList_append(newFaces,faces[1]);
    pPList oldFaces=PList_new();
    PList_append(oldFaces,face);
    (function_CB)(oldFaces,newFaces,userData_CB,F_REFINE,0);
    PList_delete(oldFaces);
    PList_delete(newFaces);
  }

#ifdef MA_PARALLEL
#ifdef AOMD_  // PAOMD

    pmEntity* mCB;
    mCB = EN_getCommonBdry((pEntity)face);
 //    if( ! mCB )
//       // we are a interior mesh entity
//       return elist;

    if(mCB) {

      // set common boundary information first
      EN_setCommonBdry((pEntity)edges[6], mCB);
      EN_setCommonBdry((pEntity)faces[0], mCB);
      EN_setCommonBdry((pEntity)faces[1], mCB);

      entities_to_update.push_back((pEntity)face);
    }

#endif // PAOMD
#endif // MA_PARALLEL

  return plist;
}

/*
  split an edge

  1.The two new edges will be in the same direction as their parent_edge
  2.The order of attaching:
   (1). the middle vertex;
   (2). the edge connecting v0->v2;
   (3). the edge connecting v2->v1;
  3.The middle vertex will be created on the straight edge approximation
  4.If snapping algorithm is applied, the target location will be calculated
    and attached for the new vertices classified on Gface or Gedge

  Created: Mesh Adapt V1.0   10/1/99

  Modification History:
     split Quadratic edge   03/11/2000   by Xiangrong Li
     interpolate the desired size value at new vertices 6/26/2001  Xiangrong Li
*/
pPList meshTemplate::get_split_edges(pEdge edge)
{
  void *temp_ptr;
  pPList elist;

  // just retrieve the data if the edge has been split
  if(EN_getDataPtr((pEntity)edge,ptr_reff,&temp_ptr))
    elist=(pPList)temp_ptr;

  // split the edge
  else {
#ifdef CURVE
    switch (E_numPoints(edge)) {
    case 0:
      elist=splitLinearEdge(edge);
      break;
    case 1:
      elist=splitQuadraticEdge(edge);
      break;
    default:
      cerr<<"Unimplemented function: split cubic or higher order edge"<<endl;
      return 0;
    }
#else
    elist=splitLinearEdge(edge);
#endif
  }

  return elist;
}

pPList meshTemplate::splitLinearEdge(pEdge edge)
{
  //cout<<"SPLIT LINEAR EDGE !!!"<<endl;
  pVertex verts[3];
  double  xyz[2][3];
  pEdge edges[2];
  pGEntity g_entity;
  double xyz1[3];
  double t;
  double par[]={0.0,0.0,0.0};
  int type;
  int i;

  list<std::pair<int, pEntity> > mlist;       // the matched face list
  list<std::pair<int, pEntity> >::iterator mlistIter;

  pEdge srcEd=edge;                         // store the original edge 
  pVertex srcVtx[2]; 
  pPList srcList; 
  list<std::pair<int, pEntity> > srcVList;
  list<pEntity> newEds[2], vertices; 
  int matchFlag=1; 
  int dblMatchFlag=0; 

  // check if the edge has matched edges 
  if(!EN_isMatchEnt(edge)) {
    mlist.push_back(make_pair(0,edge));
    matchFlag=0; 
  }
  else {
    EN_getMatchEnts(edge, 0, mlist);
/*
    vertices = PList_new();
    for(int i=0; i<2; i++)
      newEds[i]=PList_new();
*/
  }
  
  // get the vertices of the given face 
  for(i = 0; i<2; i++) {
    verts[i]= E_vertex(srcEd,i);
    srcVtx[i]=verts[i];
  }
  
  int vflag=0; 
  if(matchFlag) {
    if(EN_isMatchEnt(verts[0])){
      EN_getMatchEnts(verts[0],0,srcVList);
      if(find(srcVList.begin(), srcVList.end(), make_pair(0,verts[1])) != srcVList.end()) 
	dblMatchFlag=1; 
    }
    else {
      srcVList.push_back(make_pair(0,verts[0]));
      vflag=1; 
    }
  }
 
  double ratio=-1;  
  pVertex tmpVtx; 
  for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
  {
    edge = mlistIter->second;  
    // get the two parent vertex
    for (i= 0; i< 2; i++) {
      verts[i]= E_vertex(edge,i);
      V_coord(verts[i],xyz[i]);
    }

    // computer straight edge approximation and interpolate tensor field
    // NOTE: Need consider the new location is in the middle of transformed space
    pMSize mTmiddle;
    if (E_typeInBL(edge))
    {
      t=0.5;
      for (i= 0; i<3; i++)        // this should be deleted later
        xyz1[i]=t*(xyz[0][i]+xyz[1][i]);

      pSizeField->interpolate(pSizeField->getSize(verts[0]),
                              pSizeField->getSize(verts[1]),t,&mTmiddle);
    }
    else
//    t = pSizeField->center(verts[0],verts[1],xyz1,&mTmiddle); 

#ifdef MATCHING
    if(ratio<0) {
#endif
      t = pSizeField->center(verts[0],verts[1],xyz1,&mTmiddle);                 
#ifdef MATCHING
      ratio = t;                                                 // define the ratio from the first edge
    }
    else 
      if(matchFlag) {
	 
	 if(PList_inList(srcVList,(void*)verts[0]) )             // use the ratio for other matched edges
	    t=ratio; 
	 else
	    t=1.0-ratio;  
	 pSizeField->center(verts[0],verts[1],t,xyz1,&mTmiddle);
         
//	 cout<<" "<<EN_getUid(edge)<<" with size t="<<t<<", ratio="<<ratio<<endl; 
    }  
#endif

    // find the snapping target if on model boundary
    g_entity= E_whatIn(edge);
    type= GEN_type(g_entity);
    if(model_type && (type==Gedge || (type==Gface && curved2DSurface))) 
      {
	double *coords=new double[3];
	double tol=GEN_tolerance(g_entity);
	switch ( model_type )
        {
	case 2: {
	  // solid model with parametric space
	  if (!templatesUtil::middlePoint(edge,t,coords,par)) {
	    if(type != Gface && type != Gedge)
	      cerr<<"get_split_edges: pb! Could not get target location"<<endl;
	    if(type == Gface)
	      GF_closestPoint((pGFace)g_entity, xyz1, coords, par);
	    else if(type == Gedge)
	      GE_closestPoint((pGEdge)g_entity, xyz1, coords, par);
	  }
	  break;
	}
#ifdef AOMD_
	case 1: {
	  // mesh model providing target computation
          pGModel model = M_model(pmesh);
          if ((E_whatInType(edge) == 1) && (!strcmp(model->name(), "analytic")))
            Analytic_middlePoint(pmesh, edge, par, coords);
          else
            MeshModel_middlePoint(pmesh,edge,coords);  

//            MeshModel_subdivision_middlePoint(pmesh, edge, coords);
         
	  break;
        }
#endif
	default:
	  printf("WARNING: unsupported model type \n");
	}
/*	
#ifdef MA_PARALLEL
	if (P_size()>1)
	  {
	    EN_getDataInt((pEntity)edge,vtIdTag,&i);
            verts[2]=M_createVP2(pmesh, xyz1, par, i, g_entity);
	    EN_deleteData((pEntity)edge,vtIdTag);
	  }
	else
#endif
*/
	  verts[2]=M_createVP2(pmesh, xyz1, par, 0, g_entity);
	
	if(matchFlag) 
	  vertices.push_back(verts[2]); 
	
      // check if target location coincident with straight edge approximation
	if( XYZ_distance2(coords,xyz1) > tol*tol ) {
	  pSnap->push_back(std::make_pair(verts[2],coords));
        }
	else			 
	  delete[] coords;      
      } 
    else 
      {
/*
#ifdef MA_PARALLEL
	if (P_size()>1)
	  {
	    EN_getDataInt((pEntity)edge,vtIdTag,&i);
	    verts[2]=M_createVP2(pmesh, xyz1, par, i, g_entity);
	    EN_deleteData((pEntity)edge,vtIdTag);
	  }
	else
#endif
*/
	  verts[2]=M_createVP2(pmesh, xyz1, par, 0, g_entity);

	if(matchFlag)
	  vertices.push_back(verts[2]);
      }
    
  // interpolate the metric tensor
    pSizeField->setSize((pEntity)verts[2],mTmiddle); 
 
  // tag the new ONode for zero level layer edge
  // if two ends of the edge are tagged with gcThicknessID

  if(E_typeInBL(edge) &&
     EN_levelInBL((pEntity)edge)==0) {
    int gcThicknessTag;
    if(EN_getDataInt((pEntity)verts[0],gcThicknessID,&gcThicknessTag) &&
       EN_getDataInt((pEntity)verts[1],gcThicknessID,&gcThicknessTag))
      EN_attachDataInt((pEntity)verts[2],gcThicknessID,1);
  }

 
  // create the two edges
    edges[0]=M_createE(pmesh,verts[0],verts[2],g_entity);
    edges[1]=M_createE(pmesh,verts[2],verts[1],g_entity);
    
  // put the new edges into list in matching order
    if(matchFlag) {
      if(dblMatchFlag) {

        // check if two model entities on which the vertices classified are adjacent to one matched model face 
	pGEntity ge[2]; 
	ge[0]= V_whatIn(srcVtx[0]); 
	ge[1]= V_whatIn(verts[0]);
	
	pPList gflist[2]; 
	for(int i=0; i<2; i++) {
	  if(GEN_type(ge[i])==0)
	    gflist[i]= GV_faces((pGVertex)ge[i]);
	  else
	    if(GEN_type(ge[i])==1)
	      gflist[i]=GE_faces((pGEdge)ge[i]);
	    else
	      cout<<"Invalid match condition."<<endl; 
	}
	
	void* it=0; 
	pGEntity gent; 
	int flag=0; 
	while(gent=(pGEntity)PList_next(gflist[1], &it)) {
	  if(PBC_isPbcOnGEntity(gent) && PList_inList(gflist[0], (void*)gent)) {
	    flag=1; 
	    break; 
	  }
	}
	for(int i=0; i<2; i++)
	  PList_delete(gflist[i]); 
	
	if(flag==1){
          newEds[0].push_back(edges[0]);
          newEds[1].push_back(edges[1]);
        }
        else{
          newEds[0].push_back(edges[1]);
          newEds[1].push_back(edges[0]);
        }
      }
      else
      if(find(srcVList.begin(), srcVList.end(), make_pair(0,verts[0])) != srcVList.end()){
	  newEds[0].push_back(edges[0]);
	  newEds[1].push_back(edges[1]);
	}
	else{
	  newEds[0].push_back(edges[1]);
	  newEds[1].push_back(edges[0]);
	}
    }
    
  // activate callback 
    if( function_CB ) {
      pPList newEdges=PList_new();
      PList_append(newEdges,edges[0]);
      PList_append(newEdges,edges[1]);
      pPList oldEdges=PList_new();
      PList_append(oldEdges,edge);
      (function_CB)(oldEdges,newEdges,userData_CB,E_REFINE,(pEntity)verts[2]);
      PList_delete(oldEdges);
      PList_delete(newEdges);
    } 
    
  // set inverse classification info
    pPList elist=PList_new();
    PList_append(elist,verts[2]);
    PList_append(elist,edges[0]);
    PList_append(elist,edges[1]);
    if(edge==srcEd)
      srcList=elist; 

    EN_attachDataPtr((pEntity)edge,ptr_reff,elist);
    
  // set classification info
    if(ChildToParent) {
      void *tmpPtr;
      if(!EN_getDataPtr((pEntity)edge,ChildToParent,&tmpPtr)) 
	tmpPtr=(void *)edge;
      EN_attachDataPtr((pEntity)verts[2],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)edges[0],ChildToParent,tmpPtr);
      EN_attachDataPtr((pEntity)edges[1],ChildToParent,tmpPtr);
    }     


#ifdef MA_PARALLEL
#ifdef AOMD_ // PAOMD
  pmEntity* mCB;
  mCB = EN_getCommonBdry((pEntity)edge);
//   if( ! mCB ) 
//     // we are a interior mesh entity
//     return elist; 

  if(mCB) {

  // set common boundary information first
  EN_setCommonBdry((pEntity)verts[2], mCB);
  EN_setCommonBdry((pEntity)edges[0], mCB);
  EN_setCommonBdry((pEntity)edges[1], mCB);

  entities_to_update.push_back((pEntity)edge);

/*
  // we are on processor boundary
  RemotePointer remotePtr;
  int pid;

  // we need looping over all our remote copies
  std::vector<RemotePointer > remoteCopies;
  EN_getRemoteCopies(pmesh, edge, remoteCopies);
  std::vector<RemotePointer>::iterator rcIter = remoteCopies.begin();
  for (; rcIter!=remoteCopies.end(); ++rcIter)
  {
    int rpid = (*rcIter).second;  
    void *buf=AP_alloc(rpid,1,sizeof(Edge_template));
    Edge_template *castbuf=(Edge_template *)buf;

    castbuf->sender=edge;
    castbuf->receiver=(pEdge)((*rcIter).first);

    castbuf->midVertPtr.first = verts[2];
    castbuf->edgesPtr[0].first = edges[0];
    castbuf->edgesPtr[1].first = edges[1];
    pid=M_Pid();
    castbuf->midVertPtr.second = pid;
    castbuf->edgesPtr[0].second = pid;
    castbuf->edgesPtr[1].second = pid;

    castbuf->matchVert=EN_getRemoteCopy(pmesh,(pEntity)verts[0],rpid);
    AP_send(buf);
  }
*/
  }
#endif // PAOMD
#endif // MA_PARALLEL
  }
/* 
  if(matchFlag==0)
    PList_delete(mlist); 
  else {
    if(vflag)
      PList_delete(srcVList);
  }
*/  
  // build matched entity info
  if( matchFlag && vertices.size()>1) {
    EN_addLocalMatchEnts(vertices);                   
    EN_addLocalMatchEnts(newEds[0]);
    EN_addLocalMatchEnts(newEds[1]);
  } 

  // return elist; 
  return srcList;                                     
}

#ifdef CURVE
// input 'edge' has middle point
pPList meshTemplate::splitQuadraticEdge(pEdge edge)
{
  //cout<<"SPLIT QUADRATIC EDGE !!!"<<endl;
  pVertex verts[3];
  pEdge edges[2];
  pGEntity g_entity;
  double coords[3][3];
  double par[3][3];
  pPoint pt[2];

  // get the two parent vertex
  verts[0]= E_vertex(edge,0);
  verts[1]= E_vertex(edge,1);

  // create the middle vertex
  g_entity= E_whatIn(edge);
  pPoint ept=E_point(edge,0); 
/*
  if( (E_whatInType(edge)!=3)&&!ept->getData(AOMD_Util::Instance()->getParametric())){
    cout<<"this point has no parametric value !"<<endl; 
    cout<<"And the edge is on Geom Ent Dim: "<<E_whatInType(edge)<<endl;
    //ept->print();
    cout<<"XYZ Coords: "<<P_x(ept)<<","<<P_y(ept)<<","<<P_z(ept)<<endl;
    if( !verts[0]->getData(AOMD_Util::Instance()->getParametric())){
      cout<<"vert 0 has no param value also"<<endl;
      verts[0]->print();
    }
    if( !verts[1]->getData(AOMD_Util::Instance()->getParametric())){
      cout<<"vert 1 has no param value also"<<endl;
      verts[1]->print();
    }
  }
*/
  //double param=P_param1(ept); // commented by Kai, Apr 4 2010
  /////////////////////////////////// Added by Kai, from templates2D.cc of curving branch
/*  double param[3] = {0.0, 0., 0.};
  if(E_whatInType (edge) == 1) 
   param[0]=P_param1(ept);
  else if (E_whatInType(edge) == 2)
   P_param2(ept, param, param+1, (int*)param+2); */
  ////////////////////////////////////////////////////////////////

  int type= GEN_type(g_entity);
  double t = 0.5;
  double xyz1[3];
  double param[]={0.0,0.0,0.0};
  if(model_type && (type==Gface || type==Gedge))
  {
    double *mid_coords=new double[3];
    double tol=GEN_tolerance(g_entity);
    switch ( model_type )
    {
      case 2: {
          // solid model with parametric space
        if (!templatesUtil::middlePoint(edge,t,mid_coords,param)) {
          if(type != Gface && type != Gedge)
            cerr<<"get_split_edges: pb! Could not get target location"<<endl;
          if(type == Gface)
            GF_closestPoint((pGFace)g_entity, xyz1, mid_coords, param);
          else if(type == Gedge)
            GE_closestPoint((pGEdge)g_entity, xyz1, mid_coords, param);
        }
        break;
      }
      default:
          printf("WARNING: unsupported model type \n");
    }
    verts[2]=M_createVP2(pmesh,mid_coords,param,0,g_entity);
    delete [] mid_coords;
  }
  else{

    verts[2]=M_createVP(pmesh,P_x(ept), P_y(ept), P_z(ept),param,0,g_entity);
  }


  // interpolate the size field to the center of the two vertices
  // NOTE: currently using LINEAR INTERPOLATION
  if(pSizeField){
    double t;
    double xyz1[3];
    pMSize mTmiddle;
    t = pSizeField->center(verts[0],verts[1],xyz1,&mTmiddle);
    pSizeField->setSize((pEntity)verts[2], mTmiddle);
  }

  // create the two edges
  edges[0]=M_createE(pmesh,verts[0],verts[2],g_entity);
  edges[1]=M_createE(pmesh,verts[2],verts[1],g_entity);

  // curve the two new edges
  //if(GEN_type(g_entity)==Tregion) {   commented by Kai, Apr 4 2010
  if(model_type!=2){    // geometric model is not available

    // extractPt allocates memory for pPoint
    pt[0]=curveUtil::extractPt(pmesh,edge,0.25);
    pt[1]=curveUtil::extractPt(pmesh,edge,0.75);
   
    E_setPoint(edges[0],pt[0]);
    if(E_whatInType(edges[0])!=3)
      FMDB_P_setParametricPos(pt[0], 0.0, 0.0, 0.0);
    E_setPoint(edges[1],pt[1]);
    if(E_whatInType(edges[1])!=3)
      FMDB_P_setParametricPos(pt[1], 0.0, 0.0, 0.0);
  }
  else{  // geometric model is available
    if(E_whatInType(edge)!=3){
      templatesUtil::middlePoint(edges[0],0.5,coords[0],par[0]);
      templatesUtil::middlePoint(edges[1],0.5,coords[1],par[1]);
      pt[0]=P_new();
      pt[1]=P_new();
  
      P_setPos(pt[0], coords[0][0], coords[0][1], coords[0][2]);
      P_setPos(pt[1], coords[1][0], coords[1][1], coords[1][2]);

      E_setPoint(edges[0], pt[0]);
      FMDB_P_setParametricPos(pt[0], par[0][0], par[0][1], par[0][2]);
      
      E_setPoint(edges[1], pt[1]);
      FMDB_P_setParametricPos(pt[1], par[1][0], par[1][1], par[1][2]);

    }
    else{
      pt[0]=P_new();
      pt[1]=P_new();
      pt[0]=curveUtil::extractPt(pmesh,edge,0.25);
      pt[1]=curveUtil::extractPt(pmesh,edge,0.75);
      
      E_setPoint(edges[0],pt[0]);
      if(E_whatInType(edges[0])!=3)
	FMDB_P_setParametricPos(pt[0], 0.0, 0.0, 0.0);
      E_setPoint(edges[1],pt[1]);
      if(E_whatInType(edges[1])!=3)
	FMDB_P_setParametricPos(pt[1], 0.0, 0.0, 0.0);
    }

  }
   //}              //commented by Kai, Apr 4 2010
    //else {            // commented by Kai, Apr 4 2010
    //   PList_append(curlist,edges[0]);     //   commented by Kai, Apr 4 2010
    //   PList_append(curlist,edges[1]);    // commented by Kai, Apr 4 2010    
    //}                                     //  commented by Kai, Apr 4 2010   


  // back push new entities into pPList
  pPList elist=PList_new();
  PList_append(elist,verts[2]);
  PList_append(elist,edges[0]);
  PList_append(elist,edges[1]);

#ifdef MA_PARALLEL
  pmEntity* mCB;
  mCB = EN_getCommonBdry((pEntity)edge);
//   if( ! mCB ) 
//     // we are a interior mesh entity
//     return elist; 

  if(mCB) {

  // set common boundary information first
  EN_setCommonBdry((pEntity)verts[2], mCB);
  EN_setCommonBdry((pEntity)edges[0], mCB);
  EN_setCommonBdry((pEntity)edges[1], mCB);

  entities_to_update.push_back((pEntity)edge);

  //cout<<"[CURVE_INFO]: Setup Common Bdry and push back entities"<<endl;
  }
#endif
  //attach the pList to the edge
  EN_attachDataPtr((pEntity)edge,ptr_reff,elist);

  return elist;
}
#endif




