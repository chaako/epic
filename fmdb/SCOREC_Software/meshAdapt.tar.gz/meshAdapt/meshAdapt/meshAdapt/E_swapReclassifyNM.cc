/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Optimization
  Author(s) : Rao Garimella
  Creation  : Apr 96
  Modifi.   : 
  Function  : 

  Given a a set of regions (regs) resulting from swapping an edge
  on a non-manifold model face (nmGFace) and the direction in which the mesh
  faces classified on the model face use that face (fGFaceDir), figure out 
  the right model regions on which to classify the mesh regions and the 
  boundary entities completely enclosed by this set regions. It is assumed
  that the appropriate 2 faces in the interior of the polyhedron are 
  classified  correctly on the non-manifold model face and that their 
  orientations are consistent with the original triangulation
-------------------------------------------------------------------------*/
#include "FMDB.h"
#include "Macros.h"
#include "fromMeshTools.h"
#include "Eswap.h"
#include "modeler.h"

extern SwapConfig sc;

int E_swapReclassifyNM(pPList regs, pGEntity nmGFace, int fGFaceDir) {
  pPList nuregs, faces = PList_new(), efaces, edges = PList_new();
  pGRegion gregions[2], greg;
  pRegion region, oregion;
  pFace face;
  pEdge iedge;
  int i, j, k, allTagged, count, done, totcount=0, MKID = MT_getMarkID();
  void *temp, *temp2;

  gregions[0] = GF_region((pGFace)nmGFace,0);
  gregions[1] = GF_region((pGFace)nmGFace,1);

  nuregs = PList_newCopy(regs);

  /* First tag all entities interior to the retriangulated polyhedron */
  temp = 0;
  while (region = (pRegion)PList_next(nuregs,&temp)) {
    EN_attachDataI(region,"intr",1);
    for (i = 0; i < 4; i++)
      PList_append(faces,R_face(region,i));
  }

  temp = 0;
  while (face = (pFace)PList_next(faces,&temp)) {
    if (EN_dataI(face,"intr")) continue;
    if (F_whatInType(face) == Gface) continue;

    if ((region = F_region(face,0)) && EN_dataI(region,"intr"))
      if ((region = F_region(face,1)) && EN_dataI(region,"intr")) {
	EN_attachDataI(face,"intr",1);
	for (i = 0; i < 3; i++)
	  PList_append(edges, F_edge(face,i));
      }
  }

  temp = 0;
  while (iedge = (pEdge)PList_next(edges,&temp)) {
    if (EN_dataI(iedge,"intr")) continue; /* edge already tagged */

    efaces = E_faces(iedge);
    allTagged = 1;
    temp2 = 0;
    while (allTagged && (face = (pFace)PList_next(efaces,&temp2)))
      allTagged = EN_dataI(face,"intr");
    PList_delete(efaces);
    
    if (allTagged && (E_whatInType(iedge) == Gregion))
      EN_attachDataI(iedge,"intr",1);
    else {
      /* Tag differently to avoid rechecking next time for this edge */
      EN_attachDataI(iedge,"intr",-1);
    }
  }

  /* Now loop through the list of regions, until all the regions and their */
  /* boundaries (whenever necessary) have been assigned the right classfn. */

  done = 0; totcount = 0;
  while (!done) {

    count = 0; /* Will count how many regions reclassified on each pass */
    temp = 0; 
    while (region = (pRegion)PList_next(nuregs, &temp)) {
      if (MT_isMarked(region,MKID)) continue;

      for (i = 0, greg = 0; !greg && (i < 4); i++) {
	face = R_face(region,i);
	
	if (F_whatIn(face) == nmGFace) {
	  if (R_faceDir(region,i))
	    greg = (fGFaceDir) ? gregions[0] : gregions[1];
	  else
	    greg = (fGFaceDir) ? gregions[1] : gregions[0];
	}
	else if (EN_dataI(face,"intr")) {
	  oregion = R_faceDir(region,i) ? F_region(face,1): F_region(face,0);
	  if (MT_isMarked(oregion,MKID))
	    greg = R_whatIn(oregion);
	}
      }
      
      if (!greg) 
	continue;

      /* Classify region and its appropriate boundary entities on greg */
      count++;
      totcount++;
      R_setWhatIn(region,(pGEntity)greg);
      MT_setMark(region,MKID);
	
      for (i = 0; i < 4; i++) {
	face = R_face(region,i);

	if (EN_dataI(face,"intr") && !MT_isMarked(face,MKID)) {
	  F_setWhatIn(face,(pGEntity)greg);
	  MT_setMark(face,MKID);
	    
	  for (j = 0; j < 3; j++) {
	    iedge = F_edge(face,j);
	    if (EN_dataI(iedge,"intr") == 1)
	      E_setWhatIn(iedge,(pGEntity)greg);
	  }
	}
      }

    }
    if (!count) done = 1;
  }

  if (totcount != PList_size(nuregs))
    MT_ErrorHandler("Reclassification error after swap on non-manifold face","E_swapReclassifyNM",FATAL);
  
  temp = 0;
  while (region = (pRegion)PList_next(nuregs, &temp)) {
    EN_removeData(region,"intr");
    MT_unMark(region,MKID);
  }
  PList_delete(nuregs);

  temp = 0;
  while (face = (pFace)PList_next(faces,&temp)) {
    EN_removeData(face,"intr");
    MT_unMark(face,MKID);
  }
  PList_delete(faces);

  temp = 0;
  while (iedge = (pEdge)PList_next(edges,&temp))
    EN_removeData(iedge,"intr");
  PList_delete(edges);

  MT_freeMarkID(MKID);

  return 1;
}

