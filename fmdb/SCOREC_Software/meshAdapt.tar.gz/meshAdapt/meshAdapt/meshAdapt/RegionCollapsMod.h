#ifndef _H_RegionCollapsMod
#define _H_RegionCollapsMod

#include "LocMeshMod.h"

class regionCollapsMod: public locMeshMod
{
 public:
  regionCollapsMod(const regionCollapsMod &);
#ifdef CURVE
  regionCollapsMod(pMesh m,pSField mf,pRegion r)
    : locMeshMod(m,mf,0,0), region(r), flatAngle(175) {quadratic=false;}
  regionCollapsMod(pMesh m,pSField mf,pRegion r, double a, evalResults *rs):
    locMeshMod(m,mf,0,rs), region(r), flatAngle(a) {quadratic=false;}
#else
  regionCollapsMod(pMesh m,pSField mf,pRegion r)
    : locMeshMod(m,mf,0,0), region(r), flatAngle(175) {}
  regionCollapsMod(pMesh m,pSField mf,pRegion r, double a):
    locMeshMod(m,mf,0,0), region(r), flatAngle(a) {}
#endif
  ~regionCollapsMod() { }

  /* the common local modification interface */
  virtual int topoCheck();
  virtual int geomCheck();
  virtual int sizeCheck() { return 0; }
#ifdef CURVE
  virtual void getAffectedRgns(pPList *);
  virtual int apply() {return 0;}
  virtual int apply(pPList *);
#else /* NO CURVE */
  virtual void getAffectedRgns(pPList *) { return; }
  virtual int apply();
  virtual int apply(pPList *) { return 0; }
#endif
  virtual modType type() { return RCOLAPS; }

  pVertex getKeepVertex();

  /* set the dihedral angle in degree above which the tetrahedron will be considered as flat */
  void setFlagAngle(double degree) {  flatAngle=degree; }
  /* set the region to be collapsed */
  void setRegion(pRegion r) { region=r; }
  /* return the # of faces classified on Gface, n=1, 2 or 3 */
  int getCfg() { return n; }
  /* return the i-th boundary face, i=0,1,...,n-1 */
  pFace getBdryFace(int i) { return faces[i]; }
  /* get the edge to be reclassified if n==2 */
  pEdge getEdgeToReclassify() { 
    if( n==2 ) return ReclssifyEdge;
    return 0;
  }
  /* snap the new boundary vertex in case n=1 */
  int snapVertex(pVertex, pPList *);

  /* to be consistent with snap procedure, this two functions are here */
  /* they will be removed after we update the snap code */
/*    int evaluate(pMeshDataId , pMeshDataId ); */
/*    pEntity apply(pMeshDataId); */

 private:
  double flatAngle;     // flatAngle used to determine if tetrahedron can be collapsed in gepmCheck()
  pRegion region;       // region to be collapsed
  int n;                // # of faces classified on model face
  pFace faces[4];       // bounding mesh faces of the region with those classified on model boundary first
  pEdge ReclssifyEdge;  // the edge to be reclassified onto boundary in case of n==2 
  pVertex keepVertex;
#ifdef CURVE
  pVertex fv[3];
#endif
  void F_normal(pFace face, pRegion region, double nor[3]);
};

inline regionCollapsMod::regionCollapsMod(const regionCollapsMod &x): 
  locMeshMod(x.mesh,x.pSizeField,0,0) 
{
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;    
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;
  CB_move=x.CB_move;
  userData_CB_move=x.userData_CB_move;

  flatAngle=x.flatAngle;
  region=x.region;
  n=x.n;
  faces[0]=x.faces[0];
  faces[1]=x.faces[1];
  faces[2]=x.faces[2];
  faces[3]=x.faces[3];
#ifdef CURVE
  quadratic=x.quadratic;
#endif
}


#endif
