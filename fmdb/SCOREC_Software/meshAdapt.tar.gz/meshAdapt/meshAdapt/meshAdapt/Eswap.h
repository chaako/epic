#ifndef _H_Eswap
#define _H_Eswap
 
#include "FMDB.h"
//#include "FMDB_Internals.h"

#define MAX_POLVERTS   29
#define MAX_TRIANGLES  35
#define MAX_TRIANGULS  42

typedef struct {
  pEdge edge;                   /* edge for which cfg computed         */
  int nbr_triangles ;           /* number of different triangles       */
  int (*triangles)[3] ;         /* triangles array                     */
  int nbr_trianguls ;           /* number of different triangulations  */
  int nbr_triangles_2 ;         /* number of triangles / triangulation */
  int (*trianguls)[5] ;         /* retriangulations array              */
  short valid[MAX_TRIANGLES];   /* bit pattern to say which triangles form */
                                /* valid regions with top and bot verts    */
  short topoValidCfg[MAX_TRIANGULS]; /* Which triangulations r topologically */
                                     /* valid; needed for swap on model faces*/
 
  pVertex pverts[MAX_POLVERTS] ;
  pVertex top_vert ;
  pVertex bot_vert ;
} SwapConfig ;


/* prototypes for swapping operations */
/* int E_swp2Fac(pMesh ,pEdge) ; */
void E_swp3_3(SwapConfig *) ;
void E_swp3_4(SwapConfig *) ;
void E_swp3_5(SwapConfig *) ;
void E_swp3_6(SwapConfig *) ;
void E_swp3_7(SwapConfig *) ;
int E_swapReclassifyNM(pPList regs, pGEntity nmGFace, int fGFaceDir);

#endif
