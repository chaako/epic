#include "NullSField.h"
#include "AdaptUtil.h"

double NullSField::lengthSq(pEdge e) 
{ return adaptUtil::E_lengthSq(e); }

double NullSField::areaSq(pFace f)
{ 
  dArray fxyz[3];
  F_coord(f,fxyz);
  return areaSq(fxyz,0,0);
 }

double NullSField::volume(pRegion r)
{ return R_volume(r); }

double NullSField::lengthSq(dArray loc1, dArray loc2, pMSize, pMSize)
{ return lengthSq(loc1,loc2,0); }

double NullSField::lengthSq(dArray loc1, dArray loc2, pMSize)
{
  dArray vec;
  diffVt(loc1,loc2,vec);
  return dotProd(vec,vec); 
}

double NullSField::lengthSq(pVertex v0,pVertex v1)
{
  double vec[3],xyz[2][3];
  V_coord(v0,xyz[0]);
  V_coord(v1,xyz[1]);
  diffVt(xyz[0],xyz[1],vec);
  return dotProd(vec,vec);
}

double NullSField::areaSq(dArray fxyz[3], pMSize, dArray posDir)
{
  dArray v01, v02, nor;
  diffVt(fxyz[1],fxyz[0],v01) ;
  diffVt(fxyz[2],fxyz[0],v02) ;
  crossProd(v01,v02,nor);
  if( posDir && dotProd(posDir,nor) < 0. )
    return -0.25*dotProd(nor,nor);
  return 0.25*dotProd(nor,nor);
}


double NullSField::volume(dArray xyz[4], pMSize)
{ return XYZ_volume(xyz); }

double NullSField::angleSq(dArray v1, dArray v2, pMSize)
{ 
  double tmp=dotProd(v1,v2);
  double cosSq=tmp*tmp/(dotProd(v1,v1)*dotProd(v2,v2));
  if(tmp<0)
    return -cosSq;
  return cosSq;
}

void NullSField::center(pEdge e, double c[3], pMSize *)
{
  dArray exyz[2];
  V_coord(E_vertex(e,0),exyz[0]);
  V_coord(E_vertex(e,1),exyz[1]);
  for(int i=0; i<3; i++)
    c[i]=0.5*(exyz[0][i]+exyz[1][i]);
  return;
}

double NullSField::center(pVertex v0, pVertex v1, double c[3], pMSize *)
{
  dArray exyz[2];
  V_coord(v0,exyz[0]);
  V_coord(v1,exyz[1]);
  for(int i=0; i<3; i++)
    c[i]=0.5*(exyz[0][i]+exyz[1][i]);
  return 0.5;
}

#ifdef MATCHING
void NullSField::center(pVertex v0,pVertex v1, double r, double c[3],pMSize *newS) 
{
   center(v0, v1, c, newS); 
}
#endif
  


