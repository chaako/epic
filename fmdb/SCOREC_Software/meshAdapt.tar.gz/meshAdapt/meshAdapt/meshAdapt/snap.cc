/*
  codes for vertex snapping
                   12/20/2003 last modification -li
                   12/19/2003 added palallel vertex snapping in terms of mesh modifications
                   12/10/2003 fix a bug related to respecting constraints  
                   11/30/2003 (1). split an edge of BPM00 and snap the new vertex if hitting a bdry 
		              face in cavity expansion. (2) if there are snapped vertices on cavity
			      boundary, snap it first (limitation: if the snapping need use cavity
			      retriangulation again, something wrong).   
                   11/19/2003 fixed several bugs related to non-manifold models to pass the two 
		              examples from CCR.  
            V2.2   11/4/2001  snapping vertices by modifications is made smarter and efficient  
            V2.0   06/21/2001 use modified mean ratio as shape measure, and assume a desired size field 
            V1.9   03/01/2001 vertex snapping has its own interface
            V1.7   01/10/2001 overall procedure is modified and geometric similarity issue incorporated 
            V1.5   9/12/2000  cavity retriangulation is included 
            V1.4   8/20/2000  support both meshsim and MEGA; collect statistic data  
            V1.2   06/23/2000
  MeshAdapt V1.0   06/09/99   Xiangrong Li
*/

#include "snap.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "FaceSwapMod.h"
#include "EdgeSwapMod.h"
#include "EdgeCollapsMod.h"
#include "EdgeSplitMod.h"
#include "RegionCollapsMod.h"
#include "DSplitClpsMod.h"
#include "SplitCollapsMod.h"
#include "VertMotionMod.h"
#include "Fswap.h"
#include "ParamsOnGFace.h"
#include "Macros.h"
#include "fromMeshTools.h"
#include "meanRatio.h"
#include "NullSField.h"
#include "MeshSize.h"
#include "visUtil.h"
#include "PList.h"

#include "BLUtil.h"
#include "LayerEdgeCollapsMod.h"

extern pMeshMdl pMeshMdlInst;

#include <math.h>
#include <stdio.h>
#include <iostream>
using std::cout;
using std::endl;
using std::cerr;

#ifdef AOMD_
#ifdef MA_PARALLEL
#include "paraAdapt.h"
#include "ParUtil.h"
#endif
#include "FMDB_cint.h"
#endif

#ifdef MVTK
#include "visUtil.h"
#include "mvtk.h"
#endif

meshSnap::meshSnap(pMesh m, pSField mf, std::list<pVertex> *p)
  : pmesh(m), pSizeField(mf), pSnaplist(p), model_type(PARAM),
    function_CB(0), CB_move(0), GeoSimCheck(1), upperLenSqBound(SNAP_UPPERLENSQBOUND),lowerLenSqBound(SNAP_LOWERLENSQBOUND)
{
  ptr_GFparams=MD_newMeshDataId("pVertex_GFparams");
  int_geoSim=MD_newMeshDataId("pFace_geoChecked");

  ptr_xyz=MD_newMeshDataId("pVertex_target");  
  int_snap=MD_newMeshDataId("integer_in_snap");
  ptr_remesh=MD_newMeshDataId("pointer_in_remesh");

  shpMeasure=new MeanRatio(mf);
  result=new evalResults();

  counterMax = 1;

  mtol=M_getTolerance();

//  pRemovedVerts=new std::set<pVertex> ;
  pb_regions=new SCOREC::Util::scorecSSList<pRegion> ;
  comEdges=PList_new();
  pb_faces=PList_new();

  if( !pSizeField )
    { pSizeField=new NullSField(); nullFieldFlag=1; }
  else
    nullFieldFlag=0;
}


meshSnap::meshSnap(pMesh m, pSField mf)
  : pmesh(m), pSizeField(mf), model_type(PARAM), function_CB(0), 
  CB_move(0), upperLenSqBound(1.96), lowerLenSqBound(0.5), GeoSimCheck(1)
{
  ptr_GFparams=MD_newMeshDataId("pVertex_GFparams");
  int_geoSim=MD_newMeshDataId("pFace_geoChecked");

  ptr_xyz=MD_newMeshDataId("pVertex_target");  
  int_snap=MD_newMeshDataId("integer_in_snap");
  ptr_remesh=MD_newMeshDataId("pointer_in_remesh");

  shpMeasure=new MeanRatio(mf);
  result=new evalResults();

  counterMax = 1;

  mtol=M_getTolerance();

  pSnaplist=new std::list<pVertex> ;
//  pRemovedVerts=new std::set<pVertex>;
  pb_regions=new SCOREC::Util::scorecSSList<pRegion> ;
  comEdges=PList_new();
  pb_faces=PList_new();

  if( !pSizeField )
    { pSizeField=new NullSField(); nullFieldFlag=1; }
  else
    nullFieldFlag=0;
}

meshSnap::~meshSnap()
{
//    adaptUtil::ifMeshDataIdCleaned(pmesh,ptr_GFparams);
//    adaptUtil::ifMeshDataIdCleaned(pmesh,int_geoSim);
//    adaptUtil::ifMeshDataIdCleaned(pmesh,ptr_xyz);
//    adaptUtil::ifMeshDataIdCleaned(pmesh,int_snap);
//    adaptUtil::ifMeshDataIdCleaned(pmesh,ptr_remesh);

  MD_deleteMeshDataId(ptr_GFparams);
  MD_deleteMeshDataId(int_geoSim);

  MD_deleteMeshDataId(ptr_xyz);
  MD_deleteMeshDataId(int_snap);
  
  MD_deleteMeshDataId(ptr_remesh);

  if( nullFieldFlag )
    delete (NullSField *)pSizeField;

  delete shpMeasure;
  delete result;
  delete pSnaplist;
//  delete pRemovedVerts;
  delete pb_regions;
  PList_delete(comEdges);
  PList_delete(pb_faces);
}

void meshSnap::setCallback(CBFunction CB, void * userData)
{ 
  function_CB=CB;
  userData_CB=userData;
}

void meshSnap::setCallback(CBFunc_move CB, void * userData)
{ 
  CB_move=CB;
  userData_CB_move=userData;
}

/*
  it is other routine's duty to allocate the space for *p;
  it is this routinue's duty to free all spaces pointed by *p;
*/ 
void meshSnap::append(pVertex v, double *p)
{
  void *vChechTarget;
  if(!EN_getDataPtr((pEntity)v, ptr_xyz, &vChechTarget))
  {
    EN_attachDataPtr((pEntity)v,ptr_xyz,p);
    pSnaplist->push_back(v);
  }
}

void meshSnap::remove(pVertex v)
{
//  freeTarget(v);
  pSnaplist->remove(v);
//    cout <<" WARNING: removed duplicated vertex in the snapping list\n";
//  while ( pSnaplist->inList(v)) 
//    pSnaplist->remove(v);

}

void meshSnap::computeTarget(pVertex vertex)
{
   pGEntity gent;
   pPoint pt;
   void *temp_ptr;
   
   if( !EN_getDataPtr((pEntity)vertex,ptr_xyz,&temp_ptr) )
   {
     gent=V_whatIn(vertex);
     pt=V_point(vertex);

     target=new double[3];
     switch( V_whatInType(vertex) )
     {
       case Gedge: 
         GE_point((pGEdge)gent,P_param1(pt),target);
         break;
       case Gface:
       {
         double par[2];
         P_param2(pt,&par[0],&par[1],0);
         GF_point((pGFace)gent, par, target);
         break;
       }
       default:
       {
         double xyz[3];
         V_coord(vertex, xyz);
         cerr<<"Error: (meshSnap::run)"<<endl;
         exit(0);
       }
     }
     EN_attachDataPtr((pEntity)vertex,ptr_xyz,(void*)target);
   }
   return;
}


void meshSnap::GetSetRemovedVtx(std::set<pVertex> &pSetRemovedVtx)
{
  for (std::set<pVertex>::iterator SetIt = pRemovedVerts.begin(); SetIt!= pRemovedVerts.end(); ++SetIt) 
    pSetRemovedVtx.insert(*SetIt);
}


/* 
   Functionality: snap all vertices in the given list

   return: >=0 - the number of snapped vertices 
            -1 - unexpected error
*/  
#ifdef MA_PARALLEL
int meshSnap::run(pmMigrationCallbacks& userLB)
#else
int meshSnap::run()
#endif
{
  pVertex vertex;
  void *iter, *temp_ptr;
  std::list<pVertex>::iterator snapIter;

  
  /* calculate a target location for each vertex in the list */
  snapIter = pSnaplist->begin();
  while(snapIter != pSnaplist->end())
  {
    vertex = *snapIter;
    computeTarget(vertex);
    snapIter++;
  }
  
  /* snapping vertices on curved boundaries*/
  pPList newV=PList_new();
  int num;
  int counter=0;
  while( num=P_getMaxInt(pSnaplist->size()) ) {

    if(counter>=counterMax) 
    {
      snapIter = pSnaplist->begin();
      while(snapIter != pSnaplist->end())
      {
        vertex = *snapIter;
        freeTarget(vertex);
        snapIter++;
      }
      pSnaplist->clear();       // remove all items from the list
      if (!BLAdapt)
        pRemovedVerts.clear();
      return num;
      break;
    }

#ifdef MA_PARALLEL
    if (BLAdapt)
      unifySnapListBL();
    else
      unifySnapList();

    if( ! run_2(newV,userLB) ) 
#else
    if( ! run_2(newV) ) 
#endif
      {
        snapIter = pSnaplist->begin();
        while(snapIter != pSnaplist->end())
        {
          vertex = *snapIter;
          freeTarget(vertex);
          snapIter++;
        }
        pSnaplist->clear();       // remove all items from the list
        if (!BLAdapt)
          pRemovedVerts.clear();
        return -1;
      }

    // insert the new boundary vertex introduced in re-triangulation
    if( PList_size(newV) ) {
      iter=0;
      while( vertex=(pVertex)PList_next(newV,&iter) ) 
      {
	computeTarget(vertex);
	pSnaplist->push_back(vertex);
      }
      PList_clear(newV);
    }
    
    counter++;

#ifdef AOMD_
    int newn=P_getMaxInt(pSnaplist->size());
    if( num<=newn ){ 
      num=newn; 
      if( counter==2 ) {
	printf("num=%d newn=%d (meshSnap::run()\n",num,newn); 
	break; 
      }
    }
#endif
  }
  PList_delete(newV);
  
  if( GeoSimCheck != 1 || model_type==NOPARAM ) 
  {
    snapIter = pSnaplist->begin();
    while(snapIter != pSnaplist->end())
    {
      vertex = *snapIter;
      freeTarget(vertex);
      snapIter++;
    }
    pSnaplist->clear();       // remove all items from the list
    if (!BLAdapt)
      pRemovedVerts.clear();
    return num;
  }
/*
#ifdef MA_PARALLEL
  M_removeDissimFaces(userLB);
#else
  M_removeDissimFaces();
#endif
*/
//  return  P_getMaxInt(pSnaplist->size());
// we must clear this list because the remaining vertices could be delete after
//  INSTEAD OF THIS: return  P_getMaxInt(pSnaplist->size());
//---
  int unSnapVertices = P_getMaxInt(pSnaplist->size());
  snapIter = pSnaplist->begin();
  while(snapIter != pSnaplist->end())
  {
    vertex = *snapIter;
    freeTarget(vertex);
    snapIter++;
  }
  pSnaplist->clear();       // remove all items from the list
  if (!BLAdapt)
    pRemovedVerts.clear();
  return unSnapVertices;
//---
}


/* return 1 - success
          0 - failure  */
int meshSnap::run_2(pPList &newV
#ifdef MA_PARALLEL     
		    , pmMigrationCallbacks& userLB  
#endif
		    )
{
  double ori[3];      // current coordinates
  int isPerformed=0;
  pMeshMod pBestMod;
  pPList rlist;
  pRegion region;
  double shape_1;
  double worstShp;

  std::list<pVertex>::iterator snapIter, snapIterDel;
  void *temp_ptr;
  void *iter;
  
  int _numMod=0;
  int _LoopId=0;
  int _numByMove=0;
  int _numByModAndMove = 0;
  int _numAlreadyTarget=0;
  int _numRemesh=0;

  nToFPP=0;
  nEclps=0;
  nLEclps=0;
  nRclps=0;
  nEswap=0;
  nFswap=0;
  nVmove=0;
  nSpltClps=0;
  nTwoSpltClps=0;
  nEsplt=0;
  nByMod=0;
  nNewVerts=0;

  myTimer tt;
  tt.reset();

#ifdef MA_PARALLEL
  std::list<pair<pEntity,pEntity> > nextCBList;
  std::list<pEntity> CBVertsList;
  int _numsnapV;      // number of snapped vertices on partition boundary


  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  int msg_size = sizeof(snapPack);
  CM->set_fixed_msg_size(msg_size);
  snapPack *msg_send = (snapPack*)CM->alloc_msg(msg_size);
  int num_sent = 0, num_recvd = 0;


#endif

  // vertex snapping process begins
  while( P_getMaxInt(pSnaplist->size())  && _LoopId < 500000) {
    if(_LoopId == 499999)
	printf("Too many iterations in snap.cc.  Exiting out of loop next time through.\n");
    _LoopId++;

#ifdef DEBUG_
    adaptUtil::Info("Nbr of vertices to be snapped: ", pSnaplist->size());
#endif

    // if no modfication was performed in last pass, come out
#ifdef MA_PARALLEL
    if( P_getMinInt(isPerformed) ) break;
    numReceive=MD_newMeshDataId("numReceivedRemoteCopies");  
    P_barrier();
#else
    if(isPerformed) break;
#endif

    // reset and loop over the vertex list
    isPerformed = 1;

    snapIter = pSnaplist->begin();
    while(snapIter != pSnaplist->end()) 
    {
      vert = *snapIter;

      // see if the vertex has been removed
      if( pRemovedVerts.count(vert) )
      { 
        snapIterDel = snapIter;
        snapIter++;
        pSnaplist->erase(snapIterDel);
        pRemovedVerts.erase(vert); 
        continue; 
      }

      // retrieve target and check if the vertex is already snapped 
      if( checkSnapTarget(vert) ) 
      {
        _numAlreadyTarget++;
        snapIterDel = snapIter;
        snapIter++;
        pSnaplist->erase(snapIterDel);
	freeTarget(vert);
	continue;
      }

//      adaptUtil::Info("snapping vertex ",EN_id((pEntity)vert));
//      printf("(%d) snapping vertex %d==%p \n",M_Pid(),EN_id((pEntity)vert),vert);

      /* snapping vertex by a repositioning starts */
      rlist=V_regions(vert);
#ifndef MA_PARALLEL
      if( !PList_size(rlist) ) {  
	PList_delete(rlist);
	// surface mesh is handled here
	if( _LoopId==1 )
	  _numByMove++;
        snapIterDel = snapIter;
        snapIter++;
        pSnaplist->erase(snapIterDel);
	snapSurfaceMesh();
	freeTarget(vert);
	continue;
      }
#endif

      // take care of volume mesh
      V_coord(vert,ori);

      adaptUtil::move_vertex(vert, target);
      pb_regions->clear();
      iter=0;
      worstShp=1.0;
      while( region=(pRegion)PList_next(rlist,&iter) ) {

        if(EN_isBLEntity((pEntity)region) || region->getType() != TET)
          continue;

	shpMeasure->R_shape(region,&shape_1);
	if( worstShp>shape_1 )
	  worstShp=shape_1;
	if( shape_1 < SNAP_QUALITYFRACTION*QUALITYTHRESHOLD )
	  pb_regions->append(region);
      }
      if( worstShp>mtol )
	valid=1;
      else
	valid=0;
      PList_delete(rlist);
      
#ifdef MA_PARALLEL
      // send snap information to partners if on partition boundaries
      if( EN_duplicate((pEntity)vert) ) {
	adaptUtil::move_vertex(vert, ori);
//	sendSnapInfo(vert,pb_regions->size()); 

        std::vector<RemotePointer > remoteCopies;
        EN_getRemoteCopies(pmesh, vert, remoteCopies);
        std::vector<RemotePointer>::iterator rcIter = remoteCopies.begin();
        for (; rcIter!=remoteCopies.end(); ++rcIter)
        {
          pVertex remoteVt = (*rcIter).first;
          int rpid = (*rcIter).second;

          // set the remote vertex and the validity of its local neighboring regions
          msg_send->vertex = remoteVt;
          msg_send->valid = pb_regions->size();

          CM->send(rpid, (void*)msg_send);
          num_sent++;
        }
        if(pb_regions->size())
          EN_attachDataInt((pEntity)vert,numReceive,remoteCopies.size()+1);
        else
          EN_attachDataInt((pEntity)vert,numReceive,remoteCopies.size());

        snapIterDel = snapIter;
        snapIter++;
        pSnaplist->erase(snapIterDel);
	continue;
      }
#endif

      if( !pb_regions->size() ) 
      {
	adaptUtil::move_vertex(vert, ori);
	adaptUtil::move_vertex(vert, target, CB_move, userData_CB_move);
	isPerformed = 0;
        snapIterDel = snapIter;
        snapIter++;
        pSnaplist->erase(snapIterDel);
	delete[] target;
	EN_deleteData((pEntity)vert,ptr_xyz);

	if( _LoopId==1 ) _numByMove++;
        else _numByModAndMove++;
      }
      /* end of snapping by a reposition */
      
      else 
      {
	/* snapping vertex by a local mesh modification starts */
	adaptUtil::move_vertex(vert, ori);
	FirstPbPlane(ori); 

//  #ifdef MVTK
//  	pVisSimRep pL=mvtkAddLine(ori,target);
//  	visUtil::mvtkShowCavity(vert,0);
//  	mvtkDelete(pL);
//  #endif

	// collapsing to an existing vertex on FPP
	clpsToFPP(&pBestMod);
	if( pBestMod ) nToFPP++;

	// move vertex ahead by a mesh modification
	if( !pBestMod ) 
        {
	  if( getLocMod(&pBestMod) ) 
          {
	    // region collapse(s) or vertex motion(s) have been performed 
	    _numMod++;
	    isPerformed = 0;
            snapIter++;
	    continue;
	  }
	}

	// although no modification available, the motion is valid 
	if( !pBestMod ) {
	  if(valid) {
	    adaptUtil::move_vertex(vert, target, CB_move, userData_CB_move);

            if(_LoopId==1) _numByMove++;
            else _numByModAndMove++;

            snapIterDel = snapIter;
            snapIter++;
            pSnaplist->erase(snapIterDel);
            delete [] target;
            EN_deleteData((pEntity)vert,ptr_xyz);
	    continue;
	  }
	}

	if( !pBestMod ) {
	  // several things can still be tried before activating cavity-meshing
	  //    -li   03/16/2003
	  // 1. change the target location to one of boundary points of FPP
	  // 2. compute a new target location using closetPoint()
	  // 3. apply a local optimization procedure  ??????
//  	  if( pb_regions->size() > 1 )
//  	    isPerformed = localOpt();
#ifdef MA_PARALLEL
	  pEntity ee=F_inClosureCBEnt(pb_face);
	  if( ee && ! V_inPairList(nextCBList,vert) ) 
          {
            snapIterDel = snapIter;
            snapIter++;
            pSnaplist->erase(snapIterDel);
	    nextCBList.push_back(std::make_pair(vert,ee));
#ifdef DEBUG
	    printf("(%d) push vertex %d into nextCBList\n",P_pid(),EN_id((pEntity)vert));
#endif
	  }
          else
#endif
            snapIter++;
	  continue;
	}
	
	apply(snapIter, pBestMod);
	
	delete pBestMod;
	isPerformed = 0;
	_numMod++;
	
      } // end of determining a local mesh modification

    } // end of looping over snap list once


#ifdef MA_PARALLEL
//    CM->free_msg(msg_send);
    CM->finalize_send();

//    receiveSnapInfo(CBVertsList,&_numsnapV);

    // receive phase begins
    void *msg_recv;
    int pid_from;
    pPList cbverts=PList_new();
    _numsnapV = 0;
    int value;
    pVertex vt;
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      num_recvd++;
      snapPack* castbuf=(snapPack *)msg_recv;
      vt = castbuf->vertex;
      PList_appUnique(cbverts,vt);
      if( ! castbuf->valid ) {
        if(!EN_getDataInt((pEntity)vt,numReceive, &value)) {
#ifdef DEBUG
            adaptUtil::Info("received a vertex not in local snaplist yet (meshSnap::receiveSnapInfo)");
#endif
          value=9999;
        }
        if( value<1 )
          adaptUtil::Error(" 2 meshSnap::receiveSnapInfo()\n");
        if( value==1 ) {
          // snap the vertex which is already removed from snaplist
          void *temp_ptr;
          if( EN_getDataPtr((pEntity)vt,ptr_xyz,&temp_ptr) ) {
            if( checkSnapTarget(vt) ) {
              adaptUtil::Warning("already snapped!!\n");
            }
            adaptUtil::move_vertex(vt, target, CB_move, userData_CB_move);
            delete[] target;
            EN_deleteData((pEntity)vt,ptr_xyz);
            _numsnapV++;
          }
        }
        else
          EN_modifyDataInt((pEntity)vt,numReceive,value-1);
      } // end if( !castbuf->valid )
    }
    void *iter=0;
    void *temp_ptr;
    while( vt=(pVertex)PList_next(cbverts,&iter) ) {
      if(EN_getDataInt((pEntity)vt,numReceive, &value))
        EN_deleteData((pEntity)vt,numReceive);
      if(EN_getDataPtr((pEntity)vt,ptr_xyz,&temp_ptr))
        CBVertsList.push_back(vt);
    }
    PList_delete(cbverts);

    _numByMove += _numsnapV;
    MD_deleteMeshDataId(numReceive);

//      pVertex vvvv;
//      VIter vit=M_vertexIter(pmesh);
//      while( vvvv=VIter_next(vit) ) {
//        if(  V_whatInType(vvvv)==2 ) {
//  	double par[3];
//  	adaptUtil::Info("1 process vertex ",EN_id((pEntity)vvvv));
//  	P_param2(V_point(vvvv),par,(par+1),(int *)(par+2));
//  	adaptUtil::Info("2 process vertex ",EN_id((pEntity)vvvv));
//        }
//      }
//      VIter_delete(vit);
#endif
  }
  /* end of snapping by local mesh modification */

#ifdef DEBUG_
  cout<<"INFO: Time by Local mesh modifications -- "<<tt.elapsedCPU()<<endl;
  cout<<"      nToFPP (subset of nEclps)="<<nToFPP<<endl;
  cout<<"      nEclps="<<nEclps<<endl;
  cout<<"      nLEclps="<<nLEclps<<endl;
  cout<<"      nRclps="<<nRclps<<endl;
  cout<<"      nEswap="<<nEswap<<endl;
  cout<<"      nFswap="<<nFswap<<endl;
  cout<<"      nVmove="<<nVmove<<endl;
  cout<<"      nSpltClps="<<nSpltClps<<endl;
  cout<<"      nTwoSpltClps="<<nTwoSpltClps<<endl;
  cout<<"      nEsplt="<<nEsplt<<endl;
  cout<<"      nNewVerts="<<nNewVerts<<endl;
  cout<<"      "<<pSnaplist->size()<<" vertices are not snapped by modifications"<<endl;
  cout<<"      "<< _numByMove <<" vertices snapped by a move"<<endl;
  cout<<"      "<< _numByModAndMove <<" vertices snapped by mod. and move"<<endl;
  cout<<"      "<< nByMod <<" vertices snapped by mod."<<endl;
  cout<<"      "<< _numAlreadyTarget <<" vertices already at target"<<endl;
  cout<<"      "<< _numMod<<" local modifications performed"<<endl;
  tt.reset();
#endif

#ifdef MA_PARALLEL
  
  _numsnapV=nextCBList.size()+CBVertsList.size();
#ifdef DEBUG
  adaptUtil::Info( _numsnapV,"vertex on/next to partition boundary is not snapped");
#endif
  deleteDimReduction(nextCBList,CBVertsList, userLB);

  if (BLAdapt)
    migrateMeshForSnapBL(nextCBList,CBVertsList,userLB);
  else
    migrateMesh(nextCBList,CBVertsList,userLB);

  return 1;
#endif

  return 1;
}



void meshSnap::apply(std::list<pVertex>::iterator &snapIter, pMeshMod pBestMod)
{
  pVertex vertex, vertex_2;
  void *temp_ptr;
  int snapping=0;

  std::list<pVertex>::iterator snapIterDel;
  int iVtxDel = 0;

  switch( pBestMod->type() ) {

    // need special consideration for the vertex to be deleted 
  case ECOLAPS: { 
    vertex=((edgeCollapsMod *)pBestMod)->vertD();
    if( vertex==vert )
    {
      snapIterDel = snapIter;
      snapIter++;
      pSnaplist->erase(snapIterDel);
      iVtxDel++;
    }
//    else if(EN_getDataPtr((pEntity)vertex,ptr_xyz,&temp_ptr)) 
    else if (V_whatInType(vertex) < 3)
      pRemovedVerts.insert(vertex);

    freeTarget(vertex);  
    freeReparam(vertex);

    pBestMod->apply();

    if(vertex!=vert) 
    {
      if( checkSnapTarget(vert) ) 
      {
        nByMod++;
        snapIterDel = snapIter;
        snapIter++;
        pSnaplist->erase(snapIterDel);
        freeTarget(vert);
        iVtxDel++;
      }
    }

    if (!iVtxDel)
      snapIter++;

    nEclps++;
    break;
  }
  case LECOLAPS: {
    int top = 1;
    vertex=((layerEdgeCollapsMod *)pBestMod)->vertD(top);
    if( vertex==vert )
    {
      snapIterDel = snapIter;
      snapIter++;
      pSnaplist->erase(snapIterDel);
      iVtxDel++;
    }
//    else if(EN_getDataPtr((pEntity)vertex,ptr_xyz,&temp_ptr))
    else if (V_whatInType(vertex) < 3)
      pRemovedVerts.insert(vertex);

    freeTarget(vertex);
    freeReparam(vertex);

    pBestMod->apply();

    if(vertex!=vert) 
    {
      if( checkSnapTarget(vert) ) 
      {
        nByMod++;
        snapIterDel = snapIter;
        snapIter++;
        pSnaplist->erase(snapIterDel);
        freeTarget(vert);
        iVtxDel++;
      }
    }

    if (!iVtxDel)
      snapIter++;

    nLEclps++;
    break;
  }
    
  case ESPLIT:
    pBestMod->apply(); 
    vertex=((edgeSplitMod *)pBestMod)->getNewVertex();
    if( V_whatInType(vertex)!=Gregion ) 
    { 
      nNewVerts++;
      computeTarget(vertex);
      pSnaplist->push_back(vertex); 
    }

    if( checkSnapTarget(vert) ) 
    {
      nByMod++;
      snapIterDel = snapIter;
      snapIter++;
      pSnaplist->erase(snapIterDel);
      freeTarget(vert);
      iVtxDel++;
    }

    if (!iVtxDel)
      snapIter++;

    nEsplt++;
    break;
    
    // may introduce a new vertex and delete an old one
  case SPLTCLPS: 
    vertex=((EsplitClpsMod *)pBestMod)->getVertex();
    freeReparam(vertex);
    if(EN_getDataPtr((pEntity)vertex,ptr_xyz,&temp_ptr)) 
    {
      EN_deleteData((pEntity)vertex,ptr_xyz);
      snapping=1;
    }
    
    pBestMod->apply(); 

    vertex_2=((EsplitClpsMod *)pBestMod)->getVertex();
    if( vertex==vertex_2 ) 
    {
      if( snapping ) 
	EN_attachDataPtr((pEntity)vertex,ptr_xyz,temp_ptr);

      if( checkSnapTarget(vert) ) 
      {
        nByMod++;
        snapIterDel = snapIter;
        snapIter++;
        pSnaplist->erase(snapIterDel);
        freeTarget(vert);
        iVtxDel++;
      }
    }
    else 
    {
      if(vertex!=vert) 
      {
        if( checkSnapTarget(vert) ) 
        {
          nByMod++;
          snapIterDel = snapIter;
          snapIter++;
          pSnaplist->erase(snapIterDel);
          freeTarget(vert);
          iVtxDel++;
        }
      }

      // process the deleted vertex
      if( snapping ) 
      {
	delete[] (double *)temp_ptr;
	if( vertex==vert )
        {
          snapIterDel = snapIter;
          snapIter++;
          pSnaplist->erase(snapIterDel);
          iVtxDel++;
        }
	else
	  pRemovedVerts.insert(vertex);
      }
      
      // process the new vertex
      if( V_whatInType(vertex_2)!=Gregion ) 
      {
        nNewVerts++;
	computeTarget(vertex_2);
	pSnaplist->push_back(vertex_2);
      }
    }

    if (!iVtxDel)
      snapIter++;

    nSpltClps++;
    break;
 
  case FSWAP: 
    pBestMod->apply(); 

    if( checkSnapTarget(vert) ) 
    {
      nByMod++;
      snapIterDel = snapIter;
      snapIter++;
      pSnaplist->erase(snapIterDel);
      freeTarget(vert);
    }
    else
      snapIter++;

    nFswap++;
    break;

  case ESWAP:
    pBestMod->apply(); 

    if( checkSnapTarget(vert) ) 
    {
      nByMod++;
      snapIterDel = snapIter;
      snapIter++;
      pSnaplist->erase(snapIterDel);
      freeTarget(vert);
    }
    else
      snapIter++;

    nEswap++;
    break;
  }

  return;
}


/*
  Given a mesh vertex, this routine does two things:
  - retrieve the target location. (returned by member data "double *target")
  - check if the target is already coincident with current position
    return 1 if yes
           0 if no
*/
int meshSnap::checkSnapTarget(pVertex vt)
{
  double xyz[3], vec[3];

  pGEntity gent=V_whatIn(vt);
  double tol=GEN_tolerance(gent);
  V_coord(vt,xyz);

  // get the target
  void *temp_ptr;
  if(!EN_getDataPtr((pEntity)vt,ptr_xyz,&temp_ptr)) 
  {
#ifdef DEBUG
    cerr<<"Error: a vertex without attached target location"<<endl;
#endif
    return 1;
//    exit(0);
  }
  target=(double*)temp_ptr;      

  // check if the target is very close 
  diffVt(target,xyz,vec);

  if(dotProd(vec,vec) > tol*tol)  
    return 0;

  return 1;
}


void meshSnap::GetTarget(pVertex pVertexVtx, double *&pdTarget)
{
  // get the target
  void *pvDataPtr;
  if(EN_getDataPtr((pEntity)pVertexVtx, ptr_xyz, &pvDataPtr))
    pdTarget = (double*)pvDataPtr;
  else
    pdTarget = 0;
}


/*
  for a vertex not attched to any vertices, check if it is valid to snap it
  return 1 if valid
         0  otherwise
*/
int meshSnap::V_snapValid2D()
{ 
  // solid model with parametric space
  if( model_type==PARAM )
    return V_checkGeoSim();
  
  // mesh model
  pFace face;
  pEdge edge;
  pPList vfaces=V_faces(vert);
  double ori[3], xyz0[3], xyz1[3];
  double v0[3], v1[3], v2[3], nor1[3], nor2[3];
  V_coord(vert,ori);
  void *iter=0;
  while( face=(pFace)PList_next(vfaces,&iter) )
    {
      edge=F_vtOpEd(face,vert);
      V_coord( E_vertex(edge,0), xyz0 );
      V_coord( E_vertex(edge,1), xyz1 );
      diffVt(xyz1,xyz0,v0);
      diffVt(ori,xyz0,v1);
      diffVt(target,xyz0,v2);

      crossProd(v0,v1,nor1);
      crossProd(v0,v2,nor2);

      if( dotProd(nor1,nor2) < mtol ) 
	{ PList_delete(vfaces); return 0; }
    }
  
  PList_delete(vfaces);
  return 1;
}

/*
  we always place the vertex onto a boundary location. 
  If return 1, the vertex is snapped, 
            0, although snapped, the local mesh is not valid
               (in case happened, need more work to address)
  Note that the attached target location is not cleaned.    
                    5/16/2003  
 */
int meshSnap::snapSurfaceMesh()
{
  if( V_snapValid2D() ) {
    adaptUtil::move_vertex(vert, target, CB_move, userData_CB_move);
    return 1;
  }

#ifdef DEBUG
  printf("Info: initial target is not valid\n");
#endif

  if( model_type!=PARAM )
    return 0;

  // since ProcessNewBdryVertex assume no target is attached
  // and it always attaches a new target to the vertex 
  freeTarget(vert); 

  // use another way to the target and check
  adaptUtil::ProcessNewBdryVertex(pmesh,vert);
  computeTarget(vert);
  if( checkSnapTarget(vert) ) 
    return 1;
  // always move the vertex no matter valid or not
  adaptUtil::move_vertex(vert, target, CB_move, userData_CB_move);
  if( V_snapValid2D() )
    return 1;

  printf("Error: snapping vertex %d leads to invalid surface mesh (snapSurfaceMesh)\n",
	 EN_id((pEntity)vert));
  return 0;
}



/* solve bdry mesh faces not similar to model boundary */
#ifdef MA_PARALLEL
int meshSnap::M_removeDissimFaces(pmMigrationCallbacks& userLB)  
#else
int meshSnap::M_removeDissimFaces() 
#endif
{
  // collect mesh faces not similar to the model
  std::list<pFace> DisSimfaces;
  pFace face;
  pVertex vertex;
  int value;
  int CB_Flag;

  FIter fit=M_faceIter(pmesh);
  while( face=FIter_next(fit) ) {
    if(EN_okTo(DELETE,(pEntity)face)) {
      if( F_whatInType(face)==Gregion ) 
        continue;
#ifdef MA_PARALLEL
      if( EN_duplicate((pEntity)face) ) {
        adaptUtil::Info("detected a face on model face and on partition boundary",
  		      F_numRegions(face)); 
        continue;
      }
#endif

      if (face->getType() == QUAD)
        continue;

      if( EN_getDataInt((pEntity)face,int_geoSim,&value) ) 
        EN_deleteData((pEntity)face,int_geoSim);
      else 
        value= adaptUtil::F_checkGeoSim(face, ptr_GFparams);

      if( value!=1 ) 
        DisSimfaces.push_back(face);
    }    
  }
  FIter_delete(fit);

#ifdef DEBUG
  value=DisSimfaces.size();
  if( value ) 
    adaptUtil::Info(value," mesh faces are not similar");
#endif


  std::list<pFace>::iterator ffiter;
#ifdef MA_PARALLEL
  if( P_size()==1 ) {
#endif
    ffiter=DisSimfaces.begin();
    for(; ffiter!=DisSimfaces.end(); ) {
      fixGeoSim(*ffiter, &DisSimfaces,0,0,CB_Flag);
      DisSimfaces.erase(ffiter++);
    }
#ifdef MA_PARALLEL
  }
#endif

#ifdef MA_PARALLEL   
  while( P_size()>1 && P_getMaxInt(DisSimfaces.size()) ) {
    
    std::list<pVertex> vtsOnCB;
    pPList fverts;
    void *iter;
    int applied=0;
    IPComMan *CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int msg_size = sizeof(classificationPack);
    CM->set_fixed_msg_size(msg_size);
//    classificationPack *msg_send = (classificationPack*)CM->alloc_msg(msg_size);
//    int num_sent = 0, num_recvd = 0;

    // delete dissimilarity by swap and collapse 
    // as well as upddate the face list
    ffiter=DisSimfaces.begin();
    for(; ffiter!=DisSimfaces.end(); ) {
      if( fixGeoSim(*ffiter, &DisSimfaces,0,0,CB_Flag)==0 && CB_Flag ) 
	// no mesh modification applied but next to partition boundary
	ffiter++;
      else {
	// the face is removed or not next to partition boundary
	DisSimfaces.erase(ffiter++);
	applied++;
      }
    }

    CM->finalize_send();
//    CM->free_msg(msg_send);

    fromMeshTools::syncClassification(pmesh);
    deleteDimReduction(DisSimfaces,userLB);

    if( ! P_getMaxInt(applied) )
      break;

    // collect data to drive mesh migration
    ffiter=DisSimfaces.begin();
    for(; ffiter!=DisSimfaces.end(); ffiter++) {
      fverts=F_vertices(*ffiter,1);
      iter=0;
      while( vertex=(pVertex)PList_next(fverts,&iter) ) 
	if( EN_duplicate((pEntity)vertex) ) 
	   vtsOnCB.push_back(vertex);
    }    
    vtsOnCB.sort();
    vtsOnCB.unique();

    // migrate
    migrateMesh_2(vtsOnCB,DisSimfaces,userLB);
    vtsOnCB.clear();
  }
#endif

  // eliminate the data attached on vertices
  void *temp_ptr;
  VIter vit=M_vertexIter(pmesh);
  while( vertex=VIter_next(vit) ) {
    if( V_whatInType(vertex)==Gregion ) continue;
    if( EN_getDataPtr((pEntity)vertex,ptr_GFparams,&temp_ptr) ) {
      EN_deleteData((pEntity)vertex,ptr_GFparams);
      delete (ParamsOnGFace *)temp_ptr;
    }
  }
  VIter_delete(vit);

  return 1;
}

/*
  check geometric similarity of faces adjacent to the vertex to be snapped

  Input: a vertex to be snapped
  Output: (i)  The dissimilar faces are inserted into vs.pb_faces
          (ii) vs.Indicator=-1

  return 1: all adjacent faces are geometrically similar 
        -1: if there is dissimilar face(s)

  Created      1/7/01      X-R Li
*/
int meshSnap::V_checkGeoSim()
{
  pFace face;
  int value;
  void *iter=0;
  pPList vflist=V_faces(vert);

  PList_clear(pb_faces);

  while(face=(pFace)PList_next(vflist,&iter)) {
    if( F_whatInType(face)==Gregion ) continue;

    if( EN_getDataInt((pEntity)face,int_geoSim,&value) ) {
      if( value==-1 )
	PList_append(pb_faces,(pEntity)face);
      continue;;
    }

    switch( adaptUtil::F_checkGeoSim(face,ptr_GFparams) ) {
    case 1:  EN_attachDataInt((pEntity)face,int_geoSim,1); break;
    case -1:
      EN_attachDataInt((pEntity)face,int_geoSim,-1);
      PList_append(pb_faces,(pEntity)face);
      break;
    default:
//        cout<<"Info: nearly zero parametric normal (MeshAdapt::checkGeoSim)"<<endl;
      EN_attachDataInt((pEntity)face,int_geoSim,0);
      PList_append(pb_faces,(pEntity)face);
    }
  }
  PList_delete(vflist);

  return PList_size(pb_faces) ? -1 : 1 ;
}


/*
  return 0: no local mesh modification has been applied
         1: applied

  if type==1, there is no mesh regions attached to the faces being considered
  
  CB_Flag is used for parallel purpose. Return 1 if any modification is denied 
  since it is next to partition boundary, 0 otherwise. Always return 0 in case
  of serial.

  Note: this routine may eliminate item(s) from a list being traversing, which is
        an undefined behavior. Therefore, it is necessary to reset the iterator and 
	re-start traversing to avaoid unfedined behavior  
*/
int meshSnap::fixGeoSim(
  pFace face,                  // a mesh face in list "disFaces" 
  std::list<pFace> *disFaces,  // a list of mesh faces not similar to model boundary
  int type,                    // type==1 will update the following face list
  SCOREC::Util::scorecSSList<pFace> *BPM00,        // the face list to be updated
  int &CB_Flag)          
{
  pVertex vertDel, vertR, vertex;
  pFace face_2, fc;
  pEdge edge;
  pRegion region;
  void *iter, *temp_ptr;
  int num, ok, value;
  int applied;
  int i,j,k;
  pPList newRegs, F_verts, tmplist;

#ifdef MA_PARALLEL
  CB_Flag = 0;
#endif

  edgeCollapsMod clps(pmesh,pSizeField,shpMeasure,result);
  clps.setModelType(model_type);
  clps.setCallback(function_CB,userData_CB);

  // try collapsing one edge of the face that is not similar
  for(i=0;i<3;i++ ) {
    edge=F_edge(face,i);

    applied=0;
    for(i=0; i<2; i++) {
      vertDel=E_vertex(edge,i);
      vertR=E_vertex(edge,(i+1)%2);
      clps.setCollaps(edge, vertDel, vertR);
#ifdef MA_PARALLEL
      if( EN_duplicate((pEntity)vertDel) )
	CB_Flag = 1;
#endif     
      if( !clps.topoCheck() )  
	continue; 
      if(clps.geomCheck()) {

#ifdef DEBUG
	printf("Info: collapsed vertex %d (meshSnap::fixGeoSim)\n",EN_id((pEntity)vertDel));
#endif
        pRemovedVerts.insert(vertDel);
	// take care of dis-similar face list
	pPList vfaces=V_faces(vertDel);
	iter=0;
	while( fc=(pFace)PList_next(vfaces,&iter) ) {
	  if( F_whatInType(fc)==Gregion )  continue;
	  if( fc!=face )
	    disFaces->remove(fc);  
	}
	PList_delete(vfaces);


	// take care of the vertex to be deleted
	if( EN_getDataPtr((pEntity)vertDel,ptr_GFparams,&temp_ptr) ) {
	  EN_deleteData((pEntity)vertDel,ptr_GFparams);
	  delete (ParamsOnGFace *)temp_ptr;
	}
	freeTarget(vertDel);
	if( std::find(pSnaplist->begin(), pSnaplist->end(), vertDel) != pSnaplist->end() )
	  pSnaplist->remove(vertDel);

	// apply collapse
	clps.apply();
	if( type==1 ) {
	  BPM00->remove(face);
	  BPM00->remove(face_2);
	} 

	// update dis-similar face list
	vfaces=V_faces(vertR);
	iter=0;
	while( fc=(pFace)PList_next(vfaces,&iter) ) {
	  if( F_whatInType(fc)==Gregion )  
	    continue;
	  if( adaptUtil::F_checkGeoSim(fc, ptr_GFparams) == 1 )
	    disFaces->remove(fc);
	}
	PList_delete(vfaces);

	return 1;
      }
    }
  }  // end of if(ok)


  // try edge swap
  iter=0;
  applied=0;
  for(i=0;i<3;i++ ) {
    edge=F_edge(face,i);
    if( E_whatInType(edge)==Gedge ) 
      continue;
    if (!EN_okTo(SWAP,(pEntity)edge))
      continue;
#ifdef MA_PARALLEL
    if( EN_duplicate((pEntity)edge) )
      { CB_Flag=1; continue; }
#endif
    face_2=adaptUtil::E_otherBdryFace(edge, face);
    if( EN_getDataInt((pEntity)face_2,int_geoSim,&value) && value!=1 ) 
      continue;
    if( adaptUtil::F_checkGeoSim(face_2,ptr_GFparams)!=1 ) continue;

    // make sure the two new boundary faces are both geometrically similar
    vertex=F_edOpVt(face_2,edge);
    pGFace gface=(pGFace)F_whatIn(face);
    F_verts=PList_new();
    tmplist=F_vertices(face,1);
    ok=0;
    for( k=0; k<2; k++ ) {
      iter=0; 
      while( vertR=(pVertex)PList_next(tmplist,&iter) ) 
	if( vertR==E_vertex(edge,k) )
	  PList_append(F_verts,(pEntity)vertex);
	else
	  PList_append(F_verts,(pEntity)vertR);
      if( adaptUtil::F_checkGeoSim(&F_verts,gface)!=1 ) 
	{ ok=1; break; }
      PList_clear(F_verts);
    }
    
    PList_delete(tmplist);
    PList_delete(F_verts);
    if( ok==1 ) continue;

    // apply swapping
    if( type==1 ) {
      templatesUtil::Edge_swapOnGFace(pmesh, edge, F_whatIn(face), 0, 0, &newRegs);
      BPM00->remove(face);
      BPM00->remove(face_2);
      iter=0;
      while( fc=(pFace)PList_next(newRegs,&iter) )
	BPM00->append(fc);
      PList_delete(newRegs);
      applied=1;
    }

    else {
      num =E_numSwpCfg (edge); 
      for (j=0; j<num; j++) 
	if(E_evalSwpCfg (edge, j)) {
	  templatesUtil::Edge_swap(pmesh,edge,j,function_CB,userData_CB,&newRegs);
	  PList_delete(newRegs);
	  applied=1;
	  break;
	}
    }

    if( applied ) {
      // update dis-similar face list
      disFaces->remove(face_2);
      return 1;
    }
  }

  if( type==1 )
    return 0;

  return 0;
}


// free the target location attached data on a bdry mesh vertex
void meshSnap::freeTarget(pVertex v)
{
  void *temp_ptr;

  if(EN_getDataPtr((pEntity)v,ptr_xyz,&temp_ptr)) {
    EN_deleteData((pEntity)v,ptr_xyz);
    delete[] (double *)temp_ptr;
  }

  return;
}

// free the re-parameterized par onto gface attached to mesh vertex on gvertex/gedge
void meshSnap::freeReparam(pVertex v)
{
  void *temp_ptr;

  if(EN_getDataPtr((pEntity)v,ptr_GFparams,&temp_ptr)) {
    EN_deleteData((pEntity)v,ptr_GFparams);
    delete (ParamsOnGFace *)temp_ptr;
  }

  return;
}


void meshSnap::delete_vertex(pVertex v)
{
  void *temp_ptr;

  if(!V_numEdges(v)) {

    if(EN_getDataPtr((pEntity)v,ptr_xyz,&temp_ptr)) {
      EN_deleteData((pEntity)v,ptr_xyz);
      delete[] (double *)temp_ptr;
      pRemovedVerts.insert(v);
    }
    
    pSizeField->deleteSize((pEntity)v);
    freeReparam(v);
    M_removeVertex(pmesh,v);
  }

  return;
}


/*
  Determine 1.the first problem plane (FPP);
            2.common mesh edges among coplannar problem faces on FPP;  comEdges
	    3.pb_region, pb_face
            4.the target to move.              int_xyz[3]

  12/21/00   modified X-R Li
  10/30/01
*/
void meshSnap::FirstPbPlane(double *origin)
{
  int pbNum=pb_regions->size();
  double *dist=new double[pbNum];

  pRegion region;
  pFace   face;
  int     i, infinite;
  double  dir[3],dir1[3];
  double  xyz_face[3][3], tmp_xyz[3];
  double  minDist=99999999.0;

  SCOREC::Util::scorecSSListIter<pRegion> rIter(*pb_regions);

  // reset data
  int_xyz[0]=0.0;
  int_xyz[1]=0.0;
  int_xyz[2]=0.0;
  pb_face=0;
  pb_region=0;
  PList_clear(comEdges);

  // determine the ray
  diffVt(target, origin, dir);

  // determine distances to all possible problem faces, the shortest
  // distance and its intersection on first problem plane (FPP)
  i=0;
  while( rIter(region) ) {
    face = R_vtOpFc(region, vert);      
    F_coord(face,xyz_face);
    
    if(M_intersectRay3XYZ(origin, dir, xyz_face, tmp_xyz, &infinite)) {
      if(infinite)
	cout << "Error: invalid mesh ( FirstPbPlane() ) " << endl;
      
      diffVt(tmp_xyz, origin, dir1);
      dist[i] = dotProd (dir1, dir1);
      
      // determine the shortest distance and its intersection on FPP 
      if( dist[i] < minDist ) {
	minDist = dist[i];
	pb_face = face;
	pb_region = region;
	if( !valid ) {      // the move to target is not valid
	  int_xyz[0] = tmp_xyz[0];
	  int_xyz[1] = tmp_xyz[1];
	  int_xyz[2] = tmp_xyz[2];
	}
      } 
    }
    else
      dist[i] = minDist+mtol+1;
    ++i;
  }

  if( valid ) {
    int_xyz[0] = target[0];
    int_xyz[1] = target[1];
    int_xyz[2] = target[2];
  }

  pPList coplaneRgns=PList_new();
  rIter.reset();
  if( !pb_region ) {
    // no FPP
    pb_region = pb_regions->nth(0);
    pb_face = R_vtOpFc(pb_region, vert); 
    while( rIter(region) ) 
      PList_append(coplaneRgns,region);
  } else {
    // determine co-plannar problem regions w.r.t. FPP
    i=0;
    minDist += mtol;
    while( rIter(region) ) {
      if( dist[i] < minDist )
	PList_append(coplaneRgns,region);
      i++;
    }
  }
  delete[] dist;

  // determine pb_face, pb_face and comEdges
  commonEdges(coplaneRgns);

  PList_delete(coplaneRgns);
  
  return;
}


/*
  (1) find the common mesh edges of coplannar problem region
      adjacent to the snapping vertex
  (2) initialize private data pb_face, pb_region

  10/31/01
*/
void meshSnap::commonEdges(pPList coplaneRgns)
{
  pEdge edge;
  pPList rEdges;
  void *iter, *iter_2;

  // if one problem region
  if( PList_size(coplaneRgns) == 1 ) {
    rEdges=R_edges(pb_region,1);
    iter=0;
    while( edge=(pEdge)PList_next(rEdges,&iter) ) 
      if( E_inClosure(edge,(pEntity)vert) )
	PList_append(comEdges,edge);
    PList_delete(rEdges);
    return;
  }
  
  // determine the problem face closest to the intersection on FPP
  pRegion region, regionBuf;
  pFace face;
  double cen[3];
  double minDistSquare, distSquare;
  int flag;

  adaptUtil::centroidOfMFace(pb_face, cen);
  minDistSquare=XYZ_distance2(cen,int_xyz);
  regionBuf=pb_region;
  
  iter=0;
  while( region=(pRegion)PList_next(coplaneRgns,&iter) ) {
    if( region==regionBuf ) continue;
    face = R_vtOpFc(region, vert);   
    adaptUtil::centroidOfMFace(face, cen);
    distSquare=XYZ_distance2(cen,int_xyz);
    if( distSquare<minDistSquare ) {
      minDistSquare=distSquare;
      pb_face=face;
      pb_region=region;
    }
  }
  
  // find the common mesh edge(s) among problem regions
  rEdges=R_edges(pb_region,1);
  iter=0;
  while( edge=(pEdge)PList_next(rEdges,&iter) ) {
    if( E_inClosure(edge,(pEntity)vert) ) { 
      // check if this edge is common
      iter_2=0;
      flag=1;
      while( region=(pRegion)PList_next(coplaneRgns,&iter_2) ) {
	if( region==pb_region ) 
	  continue;
	if( !R_inClosure(region,(pEntity)edge) ) 
	  { flag=0; break; }
      }
      if( flag )
	PList_append(comEdges,edge);
    }
  }
  PList_delete(rEdges);
  
  return;
}


// collapse from the snapping vertex to a vertex on FPP
// To prevent undoing refinement, collapsing to a vertex classified on 
// the same or lower level model entity should be denied if no mesh size
// field available
void meshSnap::clpsToFPP(pMeshMod *ppBestMod)
{
  pEdge edge;
  pVertex vd;
  double xyz[3];
  void *iter;

  double maxR = SNAP_QUALITYFRACTION*QUALITYTHRESHOLD;
  *ppBestMod=0;

  edgeCollapsMod clps(pmesh,pSizeField,shpMeasure,result);
  clps.setModelType(model_type);
  clps.setCallback(function_CB,userData_CB);
  clps.setCallback(CB_move,userData_CB_move);
  if( nullFieldFlag ) 
    clps.bdryCheck();

  // deny collapsings that move away from current target
  double distOriTarget, ori[3];
  V_coord(vert,ori);
  distOriTarget = XYZ_distance2(ori, target);

  iter=0;
  while( edge=(pEdge)PList_next(comEdges,&iter) ) {
    vd=E_otherVertex(edge, vert);
    V_coord(vd,xyz);

    if(EN_isBLEntity((pEntity)vert)) {
      // double mtol = M_getTolerance();
      double vec[3], v1[3];
      diffVt(target,ori,vec);
      normVt(vec,vec);
      // --- osahni
      // P_distToLine() gives perpendicular dist. of point to line
      // double distSq = P_distToLine(xyz,ori,target,0);
      // if(distSq<0.0)
      // continue;
      // if(distSq>mtol*mtol) {
      // for(int iComp=0; iComp<3; iComp++)
      //  xyz[iComp] = ori[iComp] + sqrt(distSq)*vec[iComp];
      // }
      diffVt(xyz,ori,v1);
      double dist = dotProd(vec,v1);
      // if(dist<0.0)
      if(dist<mtol)
        continue;
      // if(dist>mtol) {
      for(int iComp=0; iComp<3; iComp++)
        xyz[iComp] = ori[iComp] + dist*vec[iComp];
        // }
      // check if xyz is on the other side of the target wrt original
      diffVt(target,xyz,v1);
      if(dotProd(vec,v1)<0.) {
        for(int iComp=0; iComp<3; iComp++)
          xyz[iComp] = target[iComp];
      }
    }

    // check if the collapse will bring it towards the target.
    if( XYZ_distance2(xyz,target) > distOriTarget ) 
      continue;

    clps.setVertMotion(vert,xyz);
    clps.setCollaps(edge, vd, vert);

    if( !clps.topoCheck() ) { continue; }
    if( !nullFieldFlag )
      {
	if( !clps.sizeCheck() ) 
	  continue;
	if( result->getMaxSize()>upperLenSqBound && 
	    result->getRatioSquareAtMaxSize() > 1.)
	  continue;
      }
    if(clps.geomCheck()) {
      //          #ifdef DEBUG
      //  	cout<<"  collapsing to an existing vertex on FPP valid   ---"<<edge;
      //  	cout<<"       worstShape="<<clps.getResultHolder()->getWorstShape()<<endl;
      //          #endif
      if( clps.getResultHolder()->getWorstShape() > maxR) 
	{
	  maxR = clps.getResultHolder()->getWorstShape();
	  if(*ppBestMod) 
	    delete *ppBestMod;
	  *ppBestMod = new edgeCollapsMod(clps);
	}
    }

  }
  return;
}



/* 
   This is the second effort to snap vertices by local mesh modifications
   return 1 if a modification has been performed, otherwise 0 
*/
int meshSnap::getLocMod(pMeshMod *ppBestMod)
{
  // if possible, collapse one of three shortest edges
  if ( clpsTetEdges(ppBestMod) ) return 0;

  // eliminate problem region by region collapse if possible
//  if ( clpsBdryPbTet(viter) ) return 1;

  // eliminate problem by swap or face-split
  if ( swapOrsplitPbTet(ppBestMod) ) return 0;

/*
  // vertex motions.
  vertMotionsMod *VmMod = VertexMotion();
  if(VmMod) {
    nVmove++;
    delete VmMod;  return 1; 
  }
*/
  return 0;
}


int meshSnap::clpsTetEdges(pMeshMod *ppBestMod)
{
  pVertex vd, vr;
  pEdge edge;
  double maxRank = SNAP_QUALITYFRACTION*QUALITYTHRESHOLD;
  int i,j;

  edgeCollapsMod clps=edgeCollapsMod(pmesh,pSizeField,shpMeasure,result,vert,int_xyz);
  clps.setCallback(function_CB,userData_CB);
  clps.setCallback(CB_move,userData_CB_move);
  clps.setModelType(model_type);
  //  clps.bdryCheck();

  // collapse common edges on FPP (not adjacent to the snapping vertex)
  switch( PList_size(comEdges) ) {
  case 2:
    edge=(pEdge)PList_item(comEdges,0);
    vd=E_otherVertex(edge,vert);
    edge=(pEdge)PList_item(comEdges,1);
    vr=E_otherVertex(edge,vert);
    for( i=0; i<3; i++ ) {
      edge=F_edge(pb_face,i);
      if( E_vertex(edge,0)==vd && E_vertex(edge,1)==vr ) 
	break;
      if( E_vertex(edge,1)==vd && E_vertex(edge,0)==vr ) 
	break;
    }
    clps.setCollaps(edge,vd,vr);
    adaptUtil::evalEclps(pSizeField,&clps,ppBestMod,&maxRank,upperLenSqBound);
    clps.setCollaps(edge,vr,vd);
    adaptUtil::evalEclps(pSizeField,&clps,ppBestMod,&maxRank,upperLenSqBound);
    break;

  case 3:
    for( i=0; i<3; i++ ) {
      edge=F_edge(pb_face,i);
      for( j=0; j<2; j++ ) {
         vd=E_vertex(edge,j);
         vr=E_vertex(edge,(j+1)%2);
         clps.setCollaps(edge,vd,vr);
         adaptUtil::evalEclps(pSizeField,&clps,ppBestMod,&maxRank,upperLenSqBound);
      }
    }
    break;
  }    

  if( *ppBestMod ) 
    return 1;

  void *iter=0;
  while( edge=(pEdge)PList_next(comEdges,&iter) ) 
    eliminateCommonEdge(edge,&clps,ppBestMod,&maxRank);

  return (*ppBestMod) ? 1 : 0;
}

void meshSnap::eliminateCommonEdge(pEdge edge, edgeCollapsMod *pClps, 
				   pMeshMod *ppBestMod, double *maxR)
{
  pVertex vd, vr;
  pEdge edgeDel;
  double vr_xyz[3];
  int i;

  // first check collapsing the edge
  for( i=0; i<2; i++ ) {
    vd=E_vertex(edge,i);
    vr=E_vertex(edge,(i+1)%2);
    pClps->setCollaps(edge,vd,vr);
    adaptUtil::evalEclps(pSizeField,pClps,ppBestMod,maxR,upperLenSqBound);
  }   

  // then check moving the vertex on FPP away
  vd=E_otherVertex(edge,vert);
  for( i=0; i<V_numEdges(vd); i++ ) {
    edgeDel=V_edge(vd,i);
    if( edgeDel==edge ) 
      continue;
    if( F_inClosure(pb_face,(pEntity)edgeDel) )  
      continue;
    vr=E_otherVertex(edgeDel,vd);

    V_coord(vr,vr_xyz);
    if( adaptUtil::V_wrtFace(vr_xyz,vert,pb_face)==1 ) 
      continue;
    
    pClps->setCollaps(edgeDel,vd,vr);
    adaptUtil::evalEclps(pSizeField,pClps,ppBestMod,maxR,upperLenSqBound);
  }
  
  return;
}

/* collapse tets next to model boundary */
int meshSnap::clpsBdryPbTet(SCOREC::Util::scorecSSListIter<pVertex> *viter)
{
  
  return 0;
  
  pRegion region;
  pVertex vertex;
  double ori[3];
  int removed=0;
  int applied=0;
  int ok;
  void *iter, *temp_ptr;

  V_coord(vert,ori);
  adaptUtil::move_vertex(vert, int_xyz);
  pPList newV=PList_new();

  SCOREC::Util::scorecSSListIter<pRegion> rIter(*pb_regions);
  while( rIter(region) ) {
    regionCollapsMod rclps(pmesh,pSizeField,region);
//---
  rclps.setCallback(function_CB,userData_CB);
//---
    rclps.setModelType(model_type);
    if( !rclps.topoCheck() )  
      continue;
    if( !rclps.geomCheck() ) 
      continue;
    // more considerations are needed in case of  double splitting and collapse
    // since it changes regions other than the region being considering
    // all other regions connected to the interior edge being split
    // should have positive volume when the vert is moved back
    if( rclps.getCfg()==2 ) {
      pEdge reclassifyEdge, deleteEdge;
      reclassifyEdge=rclps.getEdgeToReclassify();
      deleteEdge=R_gtOppEdg(region,reclassifyEdge);
      if(E_whatInType(deleteEdge)==Gedge) {
	// double edge splitting and collapse will be applied
	// all entities connected to vert should be valid when vert moving back
	double midxyz[3], rxyz[4][3];
	pPList eRgns=E_regions(reclassifyEdge);
	pVertex otherVt=E_otherVertex(reclassifyEdge,vert);
	pPList verts;
	pRegion rgn;
	int i;
	adaptUtil::centroidOfMEdge(reclassifyEdge,midxyz);
	iter=0;
	while( rgn=(pRegion)PList_next(eRgns,&iter) ) {
	  if( rgn==region )
	    continue;
	  verts=R_vertices(rgn,1);
	  temp_ptr=0;
	  ok=1;
	  i=0;
	  while( vertex=(pVertex)PList_next(verts,&temp_ptr) ) {
	    if( vertex==otherVt )
	      { rxyz[i][0]=midxyz[0]; rxyz[i][1]=midxyz[1]; rxyz[i][2]=midxyz[2]; }
	    if( vertex==vert )
	      { rxyz[i][0]=ori[0]; rxyz[i][1]=ori[1]; rxyz[i][2]=ori[2]; }
	    else
	      V_coord(vertex, rxyz[i]);
	    i++;
	  }
	  PList_delete(verts);
	  if( XYZ_volume(rxyz) < M_getTolerance() )
	    { ok=0; break; }
	}
	PList_delete(eRgns);
	if( ok==0 || pb_regions->size() > 1) 
	  continue;
	// we need to update *pb_regions in case pb_regions->size()>1
      }
    }
    
    nRclps++;
    applied=1;
    ok=rclps.apply();
    rIter.remove();
    if( ok==1 ) 
      continue;
    vertex = rclps.getKeepVertex();
//    vertex=(pVertex)ok;
    if(rclps.getCfg() == 3) {
      if( vertex==vert ) {
	removed=1;
	(*viter).remove();
	delete_vertex(vertex);
      } else if( !EN_getDataPtr((pEntity)vertex,ptr_xyz,&temp_ptr) ) 
	delete_vertex(vertex);
      else {
	delete_vertex(vertex);
	if( PList_inList(newV,(pEntity)vertex) ) 
	  PList_remItem(newV,vertex);
	else 
	  pRemovedVerts.insert(vertex);
      } 
    } // end of getCfg() == 3
    else {
      computeTarget(vertex);
      PList_append(newV,vertex); 
    }
  }

  iter=0;
  while( vertex=(pVertex)PList_next(newV,&iter) ) {
    adaptUtil::Info("insert vertex into snaplist: ", EN_id((pEntity)vertex));
    (*viter).insert(vertex);
  }
  PList_delete(newV);

  // we always move it back to avoid activating callback of moving a vertex
  if( !removed ) 
    adaptUtil::move_vertex(vert,ori);  
  return applied;
}


/*
  Evaluate local mesh modification to get rid of the first problem face

  The following modifications of consideration are:
  1. Edge/Face swap
  2. Edge split + snap new vertex
  3. Two edge splits + a edge collapse
  4. One edge split + a edge collapse

  return 0 if no local modification available
         1 determined a local modification

  History:
    11/10/99  created     Xiangrong Li
    12/10/00  modified 
    11/02/01  take edge collapse out, add split and compound
*/
int meshSnap::swapOrsplitPbTet(pMeshMod *ppBestMod)
{
  pEntity ents[4];
  pEdge edge;
  void *temp_ptr;
  double min, xyz[3], area[4], intXYZ[3];
  double par[]={0.0,0.0,0.0};
  double maxRank = SNAP_QUALITYFRACTION*QUALITYTHRESHOLD;
  int ind, i;

  // if common edge is less than 2, this routine does no good
  if( PList_size(comEdges)<2 ) 
    return 0;

  *ppBestMod=0;

  edgeSwapMod eswp(pmesh,pSizeField,shpMeasure,result);
  eswp.setCallback(function_CB,userData_CB);
  eswp.setCallback(CB_move,userData_CB_move);
  eswp.setModelType(model_type);
  EsplitClpsMod comp(pmesh,pSizeField,shpMeasure,result);
  comp.setCallback(function_CB,userData_CB);
  comp.setCallback(CB_move,userData_CB_move);
  comp.setSnap();

  // further consideration is needed if moving "vert" to "int_xyz"
  V_coord(vert,xyz);
  adaptUtil::move_vertex(vert,int_xyz);
  ind=adaptUtil::getTetInfo(pb_region,pb_face,vert,valid,ents,area,intXYZ);    
  adaptUtil::move_vertex(vert,xyz);
//    if( !ind ) {
//      printf("target: (%f,%f,%f)\n",target[0],target[1],target[2]);
//      V_info(vert);
//      F_info(pb_face);
//      R_info(pb_region);
//      pPList tmprgns=V_regions(vert);
//      PList_printx(tmprgns);
//      //    visUtil::writeRegions(tmprgns, 2);
//      PList_delete(tmprgns);
//    }
  if( !ind ) 
    return 0;

  // check if area of base triangle is much smaller than others
  min=BIG_NUMBER;
  for(i=1;i<4;i++) 
    if( area[i]<min ) min=area[i]; 
  if( area[0]==min ) {
    // try to eliminate the sliver base
    pEdge longest;
    double ratio;
    adaptUtil::F_longestEdge(pSizeField,pb_face,&longest,&ratio);

    eswp.setSwapEdge(longest);
    if( adaptUtil::evalEswp(&eswp,ppBestMod,&maxRank,lowerLenSqBound) ) 
      return 1;
    comp.reset(longest,pb_face);
    if( adaptUtil::evalSpltClps(&comp,ppBestMod,&maxRank,upperLenSqBound) )  
      return 1; 

//      if( ratio >= 4.0 ) {
//        *ppBestMod=new EdgeSplitMod(pmesh,shpMeasure,sizMeasure,result);
//        (pEdgeSplitMod(*ppBestMod))->setSplitEdge(longest);
//        adaptUtil::centroidOfMEdge(longest,xyz);
//        (pEdgeSplitMod(*ppBestMod))->setSplitPos(xyz);
//        return 1;
//      }
  }
  // end of check base triangle

  eswp.setVertMotion(vert,int_xyz);
  comp.setVertMotion(vert,int_xyz);

  // two large dihedral angles -> key problem: two mesh edges
  if( ind==3 || ind==5 || ind==6 ) {

    // check edge swapping
    for( i=0; i<2; i++ ) {
      eswp.setSwapEdge((pEdge)ents[i]);
      adaptUtil::evalEswp(&eswp,ppBestMod,&maxRank,lowerLenSqBound);
    }
    if( *ppBestMod ) return 1;

    // check split+collapse
    for( i=0; i<2; i++ ) {
      comp.reset((pEdge)ents[i],(pFace)ents[i+2]);
      adaptUtil::evalSpltClps(&comp,ppBestMod,&maxRank,upperLenSqBound);
    }
    if( *ppBestMod ) return 1;

    // split the mesh edge not moving + motion
    if( E_whatInType((pEdge)ents[0])!=Gregion ) {
      edge=(pEdge)ents[0];
      if(!EN_getDataPtr((pEntity)E_vertex(edge,0),ptr_xyz,&temp_ptr) &&
         !EN_getDataPtr((pEntity)E_vertex(edge,1),ptr_xyz,&temp_ptr)) {
	edgeSplitMod esplt(pmesh,pSizeField,shpMeasure,result);
	esplt.setSplitEdge(edge);
        if( esplt.topoCheck() && templatesUtil::middlePoint(edge,0.5,xyz,par) ) {
	  esplt.setCallback(function_CB,userData_CB);
	  esplt.setCallback(CB_move,userData_CB_move);
          esplt.setSplitPos(xyz,par);
	  esplt.setVertMotion(vert,int_xyz);
          if( esplt.geomCheck() ) {
 	    *ppBestMod = new edgeSplitMod(esplt);
	    return 1;
          }
        }
      }
    }
  }
  // end of two large dihedral angle cases

  // three large dihedral angles -> key entity: a mesh face 
  else {

    // check edge swaps
    for( i=0; i<3; i++ ) {
      edge=F_edge((pFace)ents[0],i);
      eswp.setSwapEdge(edge);    
      adaptUtil::evalEswp(&eswp,ppBestMod,&maxRank,lowerLenSqBound);
    }

    // check face swap
    faceSwapMod fswp(pmesh,pSizeField,shpMeasure,result,vert,int_xyz);
    fswp.setCallback(function_CB,userData_CB);
    fswp.setCallback(CB_move,userData_CB_move);
    fswp.setModelType(model_type);
    fswp.setSwapFace((pFace)ents[0]);

    // avoid TWO2TWO case in face swap mode
    // for non-BL faces connected to interface edges
    // note : we constrain such faces but it could be
    // created in the process of removing slivers
    int fSwpTwo2TwoOk = 1;
    if(!EN_isBLEntity(ents[0])) {
      for(i=0; i<3; i++) {
        edge = F_edge((pFace)ents[0],i);
        if( EN_isBLEntity((pEntity)edge) &&
            E_atBLInterface(edge) ) {
          fSwpTwo2TwoOk = 0;
          // fSwpTwo2TwoOk = F_checkForTwo2TwoSwap((pFace)ents[0],edge);
        if(!fSwpTwo2TwoOk)
          break;
        }
      }
    }

    if( fSwpTwo2TwoOk && fswp.topoCheck() && fswp.geomCheck()) {
      if( fswp.getResultHolder()->getWorstShape() > maxRank) {
	if(*ppBestMod) delete *ppBestMod;
	*ppBestMod = new faceSwapMod(fswp);
      }
    }
    if( *ppBestMod ) 
      return 1;

    // check split+collapse
    comp.reset((pEdge)ents[1],(pFace)ents[2]);
    if( adaptUtil::evalSpltClps(&comp,ppBestMod,&maxRank,upperLenSqBound) ) 
      return 1;

    // check split
    if( E_whatInType((pEdge)ents[1])!=Gregion ) {
      edge=(pEdge)ents[1];
      if(!EN_getDataPtr((pEntity)E_vertex(edge,0),ptr_xyz,&temp_ptr) &&
         !EN_getDataPtr((pEntity)E_vertex(edge,1),ptr_xyz,&temp_ptr)) {
	edgeSplitMod esplt(pmesh,pSizeField,shpMeasure,result);
	esplt.setSplitEdge(edge);
        if( esplt.topoCheck() && templatesUtil::middlePoint(edge,0.5,xyz,par) ) {
	  esplt.setCallback(function_CB,userData_CB);
	  esplt.setCallback(CB_move,userData_CB_move);
          esplt.setSplitPos(xyz,par);
	  esplt.setVertMotion(vert,int_xyz);
          if( esplt.geomCheck() ) {
	    *ppBestMod = new edgeSplitMod(esplt);
	    return 1;
          }
        }
      }
    }
  }
  // end of three large dihedral angles
  
  // consider two close model faces and edges
  // split the face/edge opposite to the vertex to be snapped
  // and place the new vertex on model boundary if possible

/*
  if( ind==7 ) {
    splitEntOnCloseGEnt(ents, ppBestMod); 
    if( *ppBestMod ) 
      return 1;
  }
*/
  return 0;
}

/*
   given the only problem region, its problem face, the vertex to be snapped
   and the index to eliminate the problem region, see if the region connects
   two boundary model entities that are not adjacent each other:
   1. two model edges
   2. two model faces
   3. a model face and a model edge with edge not in the closure of the face
   
   The solution should be enriched when we know more about these possibilities
   Now, we only consider: the vertex to be snapped on model edge, only one edge
   of the problem face is on another model edge, and the vertex and its target
   location on different side of the edge on another model face
*/
void meshSnap::splitEntOnCloseGEnt(pEntity ents[4], pMeshMod *ppBestMod)
{
   int flag=0;
   pEdge edge, spltEdge=0;
   double xyz[3];
   double par[]={0.0,0.0};
     
   switch( V_whatInType(vert) ) {
   case Gface: {
     if( F_whatInType(pb_face)==Gface ) {
        pGFace gf1=(pGFace)V_whatIn(vert);
        pGFace gf2=(pGFace)F_whatIn(pb_face);
	if( gf1==gf2 )
	  { flag=4; printf("Info: two close model faces\n"); }
    }
    break;    
  }
  case Gedge: {
     pGEdge ge1 = (pGEdge)V_whatIn(vert);  
     int i, num=0;
     for( i=0; i<3; i++ ) {
       edge=F_edge(pb_face,i);  
       if( E_whatInType(edge)==Gedge && ((pGEdge)E_whatIn(edge)!=ge1) )
          { num++; spltEdge=edge; }
     }
     if( num>0 ) 
       { flag=num; printf("Info: two close model edges\n"); }
   break;
 }
 default:
    printf("incorrect classification\n");
 }

 if( flag==1 && (spltEdge==(pEdge)ents[1]) ) {
    edge=(pEdge)ents[1];
    void *tmpPtr;
    if(!EN_getDataPtr((pEntity)E_vertex(edge,0),ptr_xyz,&tmpPtr) &&
       !EN_getDataPtr((pEntity)E_vertex(edge,1),ptr_xyz,&tmpPtr)) {

	edgeSplitMod esplt(pmesh,pSizeField,shpMeasure,result);
	esplt.setSplitEdge(edge);
        if( esplt.topoCheck() && templatesUtil::middlePoint(edge,0.5,xyz,par) ) {
          esplt.setSplitPos(xyz,par);
          if( esplt.geomCheck() ) {
            esplt.setCallback(function_CB,userData_CB);
            esplt.setCallback(CB_move,userData_CB_move);
	    *ppBestMod = new edgeSplitMod(esplt);
            printf("Info: split can be applied (splitEntOnCloseGEnt)\n"); 
	    return;
          }
      }
    }
 }

  return;
}

/*
  return 1 if no swap is applied
         0 if any swap is applied
 */
int meshSnap::localOpt()
{
  pPList edges=PList_new();
  pPList tmpList;
  pEdge edge;
  pRegion region;
  double ori[3], shape, worstShp=1;

  SCOREC::Util::scorecSSListIter<pRegion> rIter(*pb_regions);
  while( rIter(region) ) {
    shpMeasure->R_shape(region,&shape);
    if (worstShp > shape)
      worstShp=shape;
    tmpList=R_edges(region,1);
    PList_appUnique(edges, PList_item(tmpList,0));
    PList_appUnique(edges, PList_item(tmpList,1));
    PList_appUnique(edges, PList_item(tmpList,2));
    PList_appUnique(edges, PList_item(tmpList,3));
    PList_delete(tmpList);
  }

  edgeSwapMod eswp(pmesh,pSizeField,shpMeasure,result);
  eswp.setCallback(function_CB,userData_CB);
  eswp.setCallback(CB_move,userData_CB_move);
  eswp.setModelType(model_type);

  void *iter=0;
  V_coord(vert,ori);
  adaptUtil::move_vertex(vert, int_xyz);
  while( edge=(pEdge)PList_next(edges,&iter) ) {
    eswp.setSwapEdge(edge);
    if( !eswp.topoCheck() ) 
      continue;  
    if( !eswp.geomCheck() )
      continue;    
    result=eswp.getResultHolder();
    if( result->getWorstShape() > IMPROVE_RATIO*worstShp ) {
      printf("swap applied, shape %f -> %f\n",worstShp,result->getWorstShape());
      adaptUtil::move_vertex(vert, ori);
      if( eswp.geomCheck() ) {
	eswp.apply();
        return 0;
      }
      adaptUtil::move_vertex(vert, int_xyz);
    }
  }
  PList_delete(edges);
  adaptUtil::move_vertex(vert, ori);

  return 1;
}


/*
  Find the proper vertex repositions to make snapping acceptable
  based on visible region calculations

  12/21/00  re-write so that copying local mesh is not required   X-R Li
*/
vertMotionsMod *meshSnap::VertexMotion()
{
  SCOREC::Util::scorecSSList<double *> ptList;
  double *pt;

  pRegion region;
  pVertex vt, tmpvert;
  pVertex verts[6];
  double xyz[6][3];
  pPList vertices;
  pPList rlist;
  pPList pb_vertices=PList_new();
  double origin[3], center[3], vec[3];
  double PreWorst=10.0, shape_1, AftWorst;
  int value,i,n,k,success;
  void *iter;

  SCOREC::Util::scorecSSListIter<pRegion> rIter(*pb_regions);

  // move the snapping vertex
  V_coord(vert,origin);
  adaptUtil::move_vertex(vert, int_xyz);

  // determine the vertices to be moved and their weights
  while( rIter(region) ) {
    vertices=R_vertices(region,1);
    iter=0;  k=0;
    while( vt=(pVertex)PList_next(vertices,&iter) ) {
      if( vt==vert ) continue;
      if( V_whatInType(vt) < Gregion) continue;
      if( PList_inList(pb_vertices,vt) ) continue;
      ++k;
      PList_append(pb_vertices,vt);
      if( EN_getDataInt((pEntity)vt,int_snap,&value) ) {
	value++;
	EN_modifyDataInt((pEntity)vt,int_snap,value);
      } else 
	EN_attachDataInt((pEntity)vt,int_snap,1);
    }
    PList_delete(vertices);
    if( !k ) { //if this happens, we know vertex motion can not eliminate this poor region
      adaptUtil::move_vertex(vert,origin);
      iter=0;
      while( tmpvert=(pVertex)PList_next(pb_vertices,&iter) ) 
	EN_deleteData( (pEntity)tmpvert, int_snap );
      PList_delete(pb_vertices);
      return 0;
    }
  }

  // estimate the possible mesh regions that might be affected
  tmpvert=(pVertex)PList_item(pb_vertices,0);
  pPList regions=V_regions(vert);
  iter=0;
  while( vt=(pVertex)PList_next(pb_vertices,&iter) ) {
    rlist=V_regions(vt);
    PList_appPListUnique(regions,rlist);
    PList_delete(rlist);
  }


  // determine the vertices and their motions
  vertMotionsMod *VertMod = new vertMotionsMod(pmesh,pSizeField);
  k=0;
  success=0;
  while( PList_size(pb_vertices) ) {

    // determine a vertex to be moved
    value=0;
    iter=0;
    while( tmpvert=(pVertex)PList_next(pb_vertices,&iter) ) {
      EN_getDataInt((pEntity)tmpvert,int_snap,&i);
      if( i > value ) {
	value=i;
	vt=tmpvert;
      }
    }
    EN_deleteData( (pEntity)vt, int_snap );
    PList_remItem(pb_vertices, vt);

    // if no visible region exists, this vertex can not be moved
    if(! adaptUtil::VisibleRegion(vt, ptList) )    continue;

    // calculate centroid of visible region
    center[0]=0.0;      center[1]=0.0;      center[2]=0.0;
    SCOREC::Util::scorecSSListIter<double *> PtIter(ptList);
    while(PtIter(pt)) {
      center[0] += pt[0];
      center[1] += pt[1];
      center[2] += pt[2];
    }
    n=ptList.size();
    adaptUtil::DeleteVisibleRegion(ptList);
    center[0] /= n;  center[1] /= n;  center[2] /= n;

    // remember the vertex moved and its original location, then move it
    verts[k]=vt;
    V_coord(vt, xyz[k]);
    diffVt(xyz[k],center,vec);
    if( dotProd(vec,vec)<mtol )   continue;
    adaptUtil::move_vertex(vt,center);
    k++;

    // calculate the worst shape of affected mesh regions after this motion
    iter=0;
    int acptFlag=1;
    AftWorst=1000;
    while(region=(pRegion)PList_next(regions,&iter)) {
      if( !shpMeasure->R_shape(region,&shape_1) )
	acptFlag=0;
      if(shape_1 < AftWorst)
        AftWorst = shape_1;
    }

    if( acptFlag ) { 
      // done
      VertMod->insert(vt,center);
      success=1;
      break;
    } else if( k==0 || AftWorst >= PreWorst ) {  // first time or become better
      // see if this motion is valuable
      VertMod->insert(vt,center);
      PreWorst=AftWorst;
    } else
      // move the vertex back
      { --k; adaptUtil::move_vertex(vt,xyz[k]); }
  }

  // clean the attached data on pb_vertices
  iter=0;
  while( tmpvert=(pVertex)PList_next(pb_vertices,&iter) ) 
    EN_deleteData( (pEntity)tmpvert, int_snap );
  PList_delete(pb_vertices);
  PList_delete(regions);

  if( success )  return VertMod;

  // failed, move the vertcies back
  adaptUtil::move_vertex(vert,origin);
  for( i=0; i<k; i++ ) 
    adaptUtil::move_vertex(verts[i],xyz[i]);

  delete VertMod;
  return 0;
}



#ifndef MA_PARALLEL
/*
   this routine determines the cavity,
   retriangualtes the cavity, 
   and process the new vertices 

   return:  1 - sucessful
            0 - failed

   9/10/00    created by Xiangrong Li 
   9/22/00    code to expand P(M00) is added
  11/19/00    expended to non-manifold models     X-R. Li
  12/08/01    T(P(M00)) does not need to have a common vertex any more
              expand the cavity further in case there is close cavity entities
*/
int meshSnap::cavity_retriangulation(pVertex M00, double tg[3], pPList &newVerts)
{
  int nf;            // # of model faces using M00
  pPList gfaces;     // model faces using M00
  pPList gregs;      // model regions using M00

  pEdge edges[2];    // new edges in T(P(M00)) that are classified on model edge  
  pVertex vertex;    // new interior vertex of T(P(M00)) to replace M00

  int i,j=0;
  void *iter=0;
  void *iter_2;

  int gtype;
  pGRegion gr;
  pGFace gf;
  pGEdge ge;

  // get model faces/regions using M00
  // create a new internal vertex to replace M00
  // create two new edges if in classified a model edge
  // use Id "ptr_remesh" to attach these new entities
  gtype=V_whatInType(M00);
  switch( gtype ) {
  case Gface: {
    gf=(pGFace)V_whatIn(M00);
    gfaces=PList_new();
    PList_append(gfaces,gf);
    gregs=PList_new();
    for( i=0; i<2; i++ ) 
      {
	gr=GF_region(gf,i);
	if( gr )
	  PList_appUnique(gregs,gr);
      }
    //    gregs=GF_regions(gf);

    double param[2];
    P_param2(V_point(M00),&param[0],&param[1],&i);
    vertex=M_createVP2(pmesh,tg,param,0,(pGEntity)gf);
    EN_attachDataPtr((pEntity)M00,ptr_remesh,vertex);

    break;
  }
  case Gedge: {
    ge=(pGEdge)V_whatIn(M00);
    gfaces=GE_faces(ge);
    gregs=GE_regions(ge);  
    // Note, here, we assume no dupricated model regions in above two lists
    // True for MeshSim

    pVertex verts[2];
    pEdge edge;
    double param=P_param1(V_point(M00));
    vertex=M_createVP2(pmesh,tg,&param,0,(pGEntity)ge);
    EN_attachDataPtr((pEntity)M00,ptr_remesh,vertex);

    for( i=0; i<V_numEdges(M00); i++ ) {
      edge=V_edge(M00,i);
      if( E_whatIn(edge) != (pGEntity)ge ) continue;
      verts[0]=E_vertex(edge,0);
      verts[1]=E_vertex(edge,1);
      if( verts[0] == M00 ) verts[0]=vertex;
      if( verts[1] == M00 ) verts[1]=vertex;
      edges[j]=edge;
      edge=M_createE(pmesh,verts[0],verts[1],(pGEntity)ge);
      EN_attachDataPtr((pEntity)edges[j++],ptr_remesh,edge);
    }

    break;
  }
  default:
    cout<< "Error - Vertex not classified on model face/edge (cavity_retriangulation)"<<endl;
    return 0;
  } 

  // attach the desired size value
  if( pSizeField->getSize(M00) ) {
    pMSize cpSize=new MeshSize(pSizeField->getSize(M00));
    pSizeField->setSize((pEntity)vertex,cpSize);
  }

  // create a new triangulation for each model face 
  // determine the perimeter of the new triangulation
  // determine original triangulation of this piece of surface mesh
  nf=PList_size(gfaces);
  pPList* BPM00_gf=new pPList[nf];    // original triangulation
  pPList* TPM00_gf=new pPList[nf];    // new triangulation
  pPList* PM00_gf=new pPList[nf];     // the junction edges of the two pieces
  pPList allTPM00=PList_new();        // all pieces of new triangulation together

  i=0;
  while( gf=(pGFace)PList_next(gfaces,&iter) ) {
    BPM00_gf[i]=PList_new();
    TPM00_gf[i]=PList_new();
    PM00_gf[i]=PList_new();
    adaptUtil::V_bdryfacesOngface(M00,(pGEntity)gf,&BPM00_gf[i]);
//  #ifdef MVTK
//     double ogn[3];
//     V_coord(M00,ogn);
//     visUtil::mvtkAddPList(BPM00_gf[i],0.5,4,1,Tface);
//     pVisSimRep pL=mvtkAddLine(ogn,tg);
//     //   mvtkActivate();
//     //   mvtkDelete(pL);
//     //   mvtkRemoveAllMEnts();
//  #endif
    newsurfTrigulation(pmesh,&BPM00_gf[i],M00,tg,&TPM00_gf[i],&PM00_gf[i]);
    PList_app2Lst(&allTPM00,TPM00_gf[i],0);
    improveNewSurfMesh(gf,TPM00_gf[i],allTPM00,vertex);
#ifdef MVTK
   visUtil::mvtkAddPList(TPM00_gf[i],0.7,3,1,Tface);
   mvtkActivate();
   mvtkRemoveAllMEnts();
#endif
    if( !ensureSimilarity(TPM00_gf[i],PM00_gf[i],vertex) )
       return 0;
     ++i;
  }
  PList_delete(allTPM00);

  if( gtype==Gedge ) {
    EN_deleteData( (pEntity)edges[0], ptr_remesh );
    EN_deleteData( (pEntity)edges[1], ptr_remesh );
  }
  EN_deleteData( (pEntity)M00, ptr_remesh );

  // determine the piece of cavity for each model region
  SCOREC::Util::scorecSSList<pFace> cavity;
  pPList TPM00=PList_new();
  pPList PM00=PList_new();
  iter=0;
  while( gr=(pGRegion)PList_next(gregs,&iter) ) {

    // get PM00, TPM00 and initial BPM00 for current model region
    SCOREC::Util::scorecSSList<pFace> BPM00;
    iter_2=0;  i=0;
    while( gf=(pGFace)PList_next(gfaces,&iter_2) ) {
      if( GR_inClosure(gr,(pGEntity)gf) ) {
	PList_app2Lst(&TPM00,TPM00_gf[i],0);
	PList_app2Lst(&PM00,PM00_gf[i],0);
	adaptUtil::SSList_appPList(&BPM00,&BPM00_gf[i],0);
      }
      ++i;
    }

    // initialize the original mesh boundary to be replaced by TPM00
    traceReplacedBdry(BPM00,PM00);
    // determine and delete intersecting mesh regions, thus update BPM00
    if( !removeIntersections(PM00,TPM00,BPM00,gr,cavity) )  
      return 0;
    // determine and remove disconnected mesh regions and update BPM00
    removeDiscEntities(gr,PM00,BPM00);
    // further expand cavity to eliminate entities in proximity
    //    removeCloseEntities(PM00,TPM00,BPM00);
    // re-classify entities covered by TPM00 in case they are not removed
    reclassifyReplacedBdry(gr,BPM00);

    // put the the remaining boundary together
    adaptUtil::SSList_appSSList(&cavity,&BPM00,0);

    PList_clear(TPM00);
    PList_clear(PM00);
  }

  pPList cavityPList=PList_new();
  adaptUtil::PList_appSSList(&cavityPList,&cavity,0);
  
  for( i=0; i<nf; i++ ) 
    PList_app2Lst(&TPM00, TPM00_gf[i], 0);
  

 #ifdef MVTK
  visUtil::mvtkAddPList(cavityPList,0.5,4,1,Tface);
  visUtil::mvtkAddPList(TPM00,0.8,3,1,Tface);
  mvtkActivate();
  mvtkRemoveAllMEnts();
 #endif

  // put the two piece of mesh faces together
  PList_app2Lst(&cavityPList,TPM00,0);
  PList_delete(TPM00);
  PList_delete(PM00);

  // retriangulate the cavity and try collapsing new vertices
  pPList tmplist=PList_new();
  pPList finalF = 0;
#ifdef DEBUG
  checkCavity(cavityPList);
#endif
//  if( triangulatecavity(pmesh, cavityPList, &gr, 0, finalF, tmplist) ) 
  if (0)
  {

    // this is bad, but it is all we can do now
    VIter vvit=M_vertexIter(pmesh);
    while( vertex=VIter_next(vvit) ) {
      if( ! pSizeField->getSize(vertex) ) {
	//	printf("WARNING: a new vertex not returned (cavityMeshing)\n");
	interpMSizeAtVertex(vertex,cavityPList);
	//	PList_appUnique(tmplist,vertex);
      }
    }  // end of the bad stuff
    VIter_delete(vvit);
    
    // collapse as much new unsnapped vertices as possible
    iter_2=0;
    while( vertex=(pVertex)PList_next(tmplist,&iter_2) ) {
      //  interpMSizeAtVertex(vertex,cavity);
      gtype=V_whatInType(vertex);
      if( adaptUtil::RemoveAVertex(pmesh,pSizeField,vertex,3,0,0,
				   function_CB,userData_CB) ) 
	continue;
      if( gtype==Gvertex || gtype==Gregion ) 
	continue;
      adaptUtil::ProcessNewBdryVertex(pmesh,vertex);
      PList_append(newVerts,vertex);
    }
  
  }

  PList_delete(tmplist);
  PList_delete(cavityPList);

  for( i=0;i<nf;i++ ) {
    PList_delete(BPM00_gf[i]);
    PList_delete(TPM00_gf[i]);
    PList_delete(PM00_gf[i]);
  }
  delete[] BPM00_gf;
  delete[] TPM00_gf;
  delete[] PM00_gf;

  return 1;
}



/*
 Functionality: check if the new triangulation can be created just by copying

 return 1 need expansion using newSurfTriangulation
        0 copying local surface mesh is enough

 surfT  - a portion of surface mesh before moving M00 (not self-intersected)
 vt     - a vertex on surfT to be moved. it can be on the perimeter of surfT or interior 
 target - the current destination to move vt 

 10/31/2000    created
 12/30/2000    add geometric similarity check
 01/17/2001    make consistent with newSurfTriangulation
*/
int meshSnap::isTriangulationValid(pPList *surfT, pVertex vt, double *tg)
{
  pFace face, face_2;
  pEdge edge;
  void *iter;
  int value, i;
  double xyz[3];

  // see if any face in surfT will become degenerated after motion  
  V_coord(vt,xyz);
  adaptUtil::move_vertex(vt,tg);
  iter=0;
  while( face=(pFace)PList_next(*surfT,&iter) ) 
    if( F_checkFlat(face,0) ) 
      { adaptUtil::move_vertex(vt, xyz); return 1; }
  adaptUtil::move_vertex(vt, xyz);


  // check rotation in real space and geometric similarity 
  iter=0;
  while( face=(pFace)PList_next(*surfT,&iter) ) {

    // rotation of each face should be less than 90 degrees
    edge=F_vtOpEd(face,vt);
    if( adaptUtil::ifNeedExpand(face,edge,tg) ) 
      return 1;

    // check geometric similarity
    if( E_whatInType(edge)==Gedge )
      continue;
    for( i=0; i<2; i++ ) {
      face_2 = (i) ? (adaptUtil::E_otherBdryFace(edge,face)) : face;
      value=adaptUtil::F_checkGeoSim(face_2, ptr_GFparams);
      if( value!=1 )  
	return 1;
    }
  }

  return 0;
}


/* in this routine, tag "int_snap" is used to attach a pointer to a mesh edge */
//  void meshSnap::copyLocalSurfMesh(pMesh mesh, pPList *oldT, pVertex M00, 
//  				  pPList *newT, pPList *periEdges)  
//  {
//    pGEntity gent;
//    pVertex copiedVt, verts[2];
//    void *temp_ptr;
//    int i;

//    void *iter=0;
//    pFace face;
//    pEdge edge,edges[3];
//    int dirs[3];

//    // create the only new vertex of the triangulation
//    if( EN_getDataPtr((pEntity)M00,ptr_remesh,&temp_ptr) ) 
//      copiedVt=(pVertex)temp_ptr;
//    else 
//      cout<<"...Error - new vertex not yet created (copyLocalSurfMesh)"<<endl;

//    // create the edges/faces of the new triangulation
//    while( face=(pFace)PList_next(*oldT,&iter) ) {

//      edge=F_vtOpEd(face,M00);
//      PList_append(*periEdges,edge);

//      for( i=0; i<3; i++ ) {
//        dirs[i]=F_edgeDir(face,i);
//        edge=F_edge(face,i);
//        if( EN_getDataPtr((pEntity)edge,ptr_remesh,&temp_ptr) )
//  	edges[i]=(pEdge)temp_ptr; 
//        else if ( EN_getDataPtr((pEntity)edge,int_snap,&temp_ptr) )
//  	edges[i]=(pEdge)temp_ptr; 
//        else {
//  	verts[0]=E_vertex(edge,0);
//  	verts[1]=E_vertex(edge,1);
//  	if( verts[0]!=M00 && verts[1]!=M00 )
//  	  edges[i]=edge; 
//  	else {
//  	  gent=E_whatIn(edge);
//  	  if( verts[0] == M00 ) verts[0]=copiedVt;
//  	  if( verts[1] == M00 ) verts[1]=copiedVt;
//  	  edges[i]=M_createE(mesh,verts[0],verts[1],gent);
//  	  EN_attachDataPtr((pEntity)edge,int_snap,edges[i]);
//  	}
//        }
//      }
//      gent=F_whatIn(face);
//      PList_append(*newT, M_createF(mesh,3,edges,dirs,gent) );
//    }
  
//    // delete the data attached on mesh edges
//    iter=0;
//    while( face=(pFace)PList_next(*oldT,&iter) ) 
//      for( i=0; i<3; i++ ) {
//        edge=F_edge(face,i);
//        if( EN_getDataPtr((pEntity)edge,int_snap,&temp_ptr) )
//  	EN_deleteData( (pEntity)edge, int_snap );
//      }
  
//    return;
//  }

/* 
   determine P(M00) and generate T(P(M00))
*/
int meshSnap::newsurfTrigulation(pMesh mesh,
				 pPList *oldT,   // old surface triangulation
				 pVertex M00,    // the vertex to be snapped
				 double tg[3],   // where to move M00
				 pPList *newT,   // new surface triangulation - T(P(M00))
				 pPList *periEdges) // P(M00)
{
  pGEntity gent;
  pFace face, faces[2];
  pEdge edge, edge_2, edges[3];
  pVertex copiedVt, OpVert, vertex, verts[2];
  void *temp_ptr;
  void *iter;
  int dirs[3];
  int expandFlag; 
  int i;

  pPList fverts=PList_new();

  // get the interior vertex of the new surface triangulation
  EN_getDataPtr((pEntity)M00,ptr_remesh,&temp_ptr);
  copiedVt=(pVertex)temp_ptr;

  // initialize 
  SCOREC::Util::scorecSSList<pEdge> PerimeterEdges;
  iter=0;
  while( face=(pFace)PList_next(*oldT,&iter) ) 
    {
      edge=F_vtOpEd(face,M00);
      EN_attachDataPtr((pEntity)edge,int_snap,face);
      PerimeterEdges.append(edge);
    }

  // expand
  SCOREC::Util::scorecSSListIter<pEdge> EdgeIter(PerimeterEdges);
  while( EdgeIter(edge) ) {

    if( !EN_getDataPtr((pEntity)edge,int_snap,&temp_ptr) ) 
      continue;

    // two boundary faces the edge bounds
    faces[0]=(pFace)temp_ptr;                      // the face in perimeter
    faces[1]=adaptUtil::E_otherBdryFace(edge,faces[0]); // out of perimeter

    // if the neigboring face outside 2D cavity is not geometrically 
    // similer, always expand 
    if( faces[1] )
      expandFlag=adaptUtil::F_checkGeoSim(faces[1], ptr_GFparams);
    else
      expandFlag=1;

    if( expandFlag==1 )
      // the out face is similar, further check point convexity
      {
	if( F_dirUsingEdge(faces[0],edge)==1 )
	  // direction: counterclockwise around the normal
	  {
	    PList_append(fverts,(pEntity)E_vertex(edge,0));
	    PList_append(fverts,(pEntity)E_vertex(edge,1));
	  }
	else
	  {
	    PList_append(fverts,(pEntity)E_vertex(edge,1));
	    PList_append(fverts,(pEntity)E_vertex(edge,0));
	  }
	PList_append(fverts,(pEntity)copiedVt);

	expandFlag=adaptUtil::F_checkGeoSim(&fverts, (pGFace)F_whatIn(faces[0]));
	PList_clear(fverts);
      }

    if( expandFlag != 1 ) 
      // should expand 2D cavity at current edge
      {
	// expansion is invalid in case classified on a model edge
	if( E_whatInType(edge) == Gedge ) {

	  double tpar, segment[2][3];
	  V_coord(E_vertex(edge,0),segment[0]);
	  V_coord(E_vertex(edge,1),segment[1]);
	  tpar=adaptUtil::ParOnLinearEdge(segment, tg);
	  printf("Info: tpar=%f \n",tpar);
	  
	  if( tpar>mtol && tpar<1-mtol ) { 
	    // the motion penetrate an edge on model edge
	    double xyz[3],par[3];
	    pVertex vts[2];
	    if( templatesUtil::middlePoint(edge,0.5,xyz,par) ) {
	      edgeSplitMod esplt(pmesh,pSizeField,shpMeasure,result);
	      esplt.setCallback(function_CB,userData_CB);
	      esplt.setCallback(CB_move,userData_CB_move);
	      esplt.setSplitEdge(edge);
	      esplt.setSplitPos(xyz,par);
	      if( esplt.topoCheck() && esplt.geomCheck() ) {
		pVertex newv, optv;
		EN_deleteData( (pEntity)edge, int_snap );
		EdgeIter.remove();
		
		if( !EN_getDataPtr((pEntity)edge,int_snap,&temp_ptr) )
		  printf("Fatal Error: expand an edge not on P(M00)\n");
		face=(pFace)temp_ptr;   
		PList_remItem(*oldT,face);
		optv=F_edOpVt(face,edge);
		
		vts[0]=E_vertex(edge,0);
		vts[1]=E_vertex(edge,1);
		
		esplt.apply();
		
		newv=esplt.getNewVertex();
		for( i=0; i<2; i++ ) {
		  edge_2=E_exists(newv,vts[i]);
		  face=F_exists(Tvertex,(pEntity)optv,(pEntity)newv,(pEntity)vts[i],0);
		  PList_append(*oldT,face);
		  EN_attachDataPtr((pEntity)edge_2,int_snap,face);
		  EdgeIter.insert(edge_2);
		}
	      }
	      else
		printf("WARNING: not implementated. (snap::newsurfTrigulation)\n");
	    }
	    else 
	      printf("WARNING: can not find middle point 2 (snap::newsurfTrigulation)\n");
	  }
	  continue;  // no expansion is required if not on the edge
	}
	
	// expansion is always possible in case on model face 
	EN_deleteData( (pEntity)edge, int_snap );
	EdgeIter.remove();
      
	PList_append(*oldT,faces[1]);
	for( i=0; i<3; i++ ) 
	  {
	    edge_2=F_edge(faces[1],i);
	    if( edge_2==edge ) 
	      continue;
	    if( PerimeterEdges.inList(edge_2) ) 
	      EN_deleteData( (pEntity)edge_2, int_snap );
	    else {
	      EN_attachDataPtr((pEntity)edge_2,int_snap,faces[1]);
	      EdgeIter.insert(edge_2);  
	    }
	  }
      }
  }
  PList_delete(fverts);

  // any edge without attachment should be removed from the list
  EdgeIter.reset();
  while( EdgeIter(edge) ) 
    if( ! EN_getDataPtr((pEntity)edge,int_snap,&temp_ptr) )
      EdgeIter.remove();



  // create mesh faces in T and their bounding mesh edges
  EdgeIter.reset();
  while( EdgeIter(edge) ) {
    EN_getDataPtr((pEntity)edge,int_snap,&temp_ptr);
    face=(pFace)temp_ptr;
    OpVert=F_edOpVt(face,edge);

    gent=F_whatIn(face);
    for( i=0; i<3; i++ ) {
      edge_2=F_edge(face,i);
      if( edge_2==edge ) {
	edges[i]=edge;
	dirs[i]=F_edgeDir(face,i);
      } else {
	vertex=E_vertex(edge_2,0);
	if( vertex==OpVert )
	  vertex=E_vertex(edge_2,1);
	edges[i]=E_exists(copiedVt,vertex);
	if( edges[i] ) {
	  if( E_vertex(edges[i],0)==E_vertex(edge_2,0) || 
	      E_vertex(edges[i],1)==E_vertex(edge_2,1) )
	    dirs[i]=F_edgeDir(face,i);
	  else {
	    if( F_edgeDir(face,i) ) dirs[i]=0;
	    else dirs[i]=1;
	  }
	} else {
	  verts[0]=E_vertex(edge_2,0);
	  verts[1]=E_vertex(edge_2,1);
	  if( verts[0] == OpVert ) verts[0]=copiedVt;
	  if( verts[1] == OpVert ) verts[1]=copiedVt;
	  edges[i]=M_createE(mesh,verts[0],verts[1],gent);
	  dirs[i]=F_edgeDir(face,i);
	}
      }
    }
    PList_append(*newT, M_createF(mesh,3,edges,dirs,gent) );
  }

  // delete the attached data on each perimeter edge
  // and keep them in a list
  EdgeIter.reset();
  while( EdgeIter(edge) ) {
    EN_deleteData( (pEntity)edge, int_snap );
    PList_append(*periEdges,edge);
  }
  return 1;
}


/*
  given a new triangulation on a model face and the only internal vertex
  improve its quality by swap operations     12/03/01  -li

  Modified:  11/19/03   -li  (take care of non-manifold case)
*/
void meshSnap::improveNewSurfMesh(pGFace gf, pPList &TPM00, pPList allTPM00, pVertex TM00)
{
  //  double normal[3];
  double newMinAng, oriMinAng; //the signed cosine 
  double newMaxAngToNormal, oriMaxAngToNormal; //the signed cosine square
  pFace face;
  pEdge swpedge;
  pVertex vts[2];
  pPList newF,vedges,buff;
  void *iter, *iter_2;
  int j, swapFlag;

  buff=PList_new();

  // keep traversing until no more swap can be performed
  swapFlag=1;
  while( swapFlag ) {
    swapFlag=0;

    // collect edges to check swapping
    vedges=PList_new();
//     for( j=0; j<V_numEdges(TM00); j++ ) 
//       PList_append(vedges,(pEntity)V_edge(TM00,j));
    iter_2=0;
    while( face=(pFace)PList_next(TPM00,&iter_2) ) {
      for( j=0; j<3; j++ ) {
	swpedge = F_edge(face,j);
	if( ! PList_inList(vedges,swpedge) ) {
	  if( E_vertex(swpedge,0)==TM00 || E_vertex(swpedge,1)==TM00 )
	    PList_append(vedges,swpedge);
	}
      }
    }
    iter_2=0;
    while( swpedge=(pEdge)PList_next(buff,&iter_2) ) 
      PList_appUnique(vedges,(pEntity)swpedge);
    PList_clear(buff);

    // swap edges if improving quality
    iter_2=0;
    while( swpedge=(pEdge)PList_next(vedges,&iter_2) ) { 
      
      // check the validity of swap the edge
      // and get the angles after swapping
      if( fromMeshTools::E_evalSwpOnGFace(swpedge,(pGEntity)gf,allTPM00,&newMinAng,&newMaxAngToNormal) ) {
	
	// get the angles before swapping 
	adaptUtil::E_swpGetOriAngles(swpedge,&oriMinAng,&oriMaxAngToNormal);
      
	// angle to model normal should decrease or less than 60 degree
	// 0.25=(cos60)^2
	if( newMaxAngToNormal<oriMaxAngToNormal && newMaxAngToNormal<0.25 ) 
	  continue; 
	
	// we want to minimize the maximum angle between mesh face normal and model normal
	if( newMinAng < oriMinAng ) {
	  swapFlag=1;
	  for( j=0; j<2; j++ ) {
	    face=E_face(swpedge,j);
	    vts[j]=F_edOpVt(face,swpedge);
	    PList_remItem(TPM00,face);
	    PList_remItem(allTPM00,face);
	  }
	  templatesUtil::Edge_swapOnGFace(pmesh,swpedge,(pGEntity)gf,0, 0, &newF);
	  iter=0;
	  while( face=(pFace)PList_next(newF,&iter) ) {
	    PList_append(TPM00,face);
	    PList_append(allTPM00,face);
	  }
	  PList_delete(newF);
	  swpedge=E_exists(vts[0],vts[1]);
	  if( swpedge )
	    PList_appUnique(buff,swpedge);
	}
      }
    }
    
    PList_delete(vedges);
  }

  PList_delete(buff);
  return;
}

// in case not silimar, apply the valid collapse operation to eliminate the edge as short as
// possible. 
// The following should be done later:   -li 6/6/2002
// SHOULD avoid return back to the original surface triangulation AND split the 
// longest interior to at least have one interior vertex.
int meshSnap::ensureSimilarity(pPList &TPM00,pPList &PM00,pVertex TM00)
{
  pFace face;
  pEdge edge;
  int ok;

  void *iter=0;
  while( edge=(pEdge)PList_next(PM00,&iter) )
    {
      if( E_whatInType(edge)!=Tedge )
	continue;
      face=adaptUtil::F_getFmFaces(TPM00,edge);
      if( !face )
	{ printf("Error: ensureSimilarity\n"); return 0; }
      ok=adaptUtil::F_checkGeoSim(face, ptr_GFparams);
      if( ok==-2 )
        printf("Error: can not get parameter of a vertex");
      if( ok==0 || ok==-1 )
	if( !adaptUtil::RemoveAVertex(pmesh,pSizeField,TM00,Gface,1,TPM00, 
				      function_CB, userData_CB) )
	  { 
	    printf("Error: can not create a valid new triangulation\n"); 
	    return 0;
	  } 
    }
  return 1;
}


void meshSnap::traceReplacedBdry(SCOREC::Util::scorecSSList<pFace> &BPM00, pPList &PM00)
{
  pFace face;
  pEdge edge;
  pVertex vt;
  int i,j,value;
  void *iter;

  coveredEds=PList_new();
  coveredVts=PList_new();

  iter=0;
  while( edge=(pEdge)PList_next(PM00,&iter) ) {
    EN_attachDataInt((pEntity)edge,int_snap,1);
    EN_attachDataInt((pEntity)E_vertex(edge,0),int_snap,1);
    EN_attachDataInt((pEntity)E_vertex(edge,1),int_snap,1);
  }

  // tag mesh entities originally at boundary
  SCOREC::Util::scorecSSListIter<pFace> fcIter(BPM00);
  while( fcIter(face) ) {
    EN_attachDataInt((pEntity)face,int_snap,1);

    for( i=0; i<3; i++ ) {
      edge=F_edge(face,i);
      if( EN_getDataInt((pEntity)edge,int_snap,&value) )
        continue;
      PList_appUnique(coveredEds,(pEntity)edge);
      for(j=0; j<2; j++) {
        vt=E_vertex(edge,j);
        if( EN_getDataInt((pEntity)vt,int_snap,&value) )
          continue;
        PList_appUnique(coveredVts,(pEntity)vt);
      }
    }
  }
  
  // cleanup
  iter=0;
  while( edge=(pEdge)PList_next(PM00,&iter) ) {
    EN_deleteData((pEntity)edge,int_snap);
    EN_deleteData((pEntity)E_vertex(edge,0),int_snap);
    EN_deleteData((pEntity)E_vertex(edge,1),int_snap);
  }

  return;
}


/*
  solve the self-intersections between the two pieces of surface mesh
  12/03/01   - X.Li
*/
int meshSnap::removeIntersections(
  pPList &PM00,         // the list of edges at the junction of the two pieces  
  pPList &TPM00,        // the list of faces representing the new trangulation
  SCOREC::Util::scorecSSList<pFace> &BPM00, // the list of faces representing the remaining mesh bdry
  pGRegion gr,          // the model region being processing
  SCOREC::Util::scorecSSList<pFace> &cavity)
{
  if( !processIntersection_1(gr,PM00,TPM00,BPM00) )
    return 0;
  int ok=processIntersection_2(gr,PM00,TPM00,BPM00,0);
  if( ok != 2 )
    return ok;

  // Interior vertex of TPM00 is moved, need re-checking intersection
  while( ok == 2 ) {
    ok=processIntersection_2(gr,PM00,TPM00,BPM00,0);
    printf("Info: reshaping TPM00 (meshSnap::removeIntersections)\n");
  }
  if( ok==0 )
    return ok;
  if( processIntersection_2(0,PM00,TPM00,cavity,1)==1 ) 
    return 1;
  
  printf("Error:   (meshSnap::removeIntersections)\n");
  return 0;
}


/*
  process the possible intersections between faces of the two pieces of surface
  mesh with a common egde 

  Note that a shell defined by faces in "TPM00" and "BPM00" is maintained
  in the deletion and expansion process
  12/04/01 - X.li
*/
int meshSnap::processIntersection_1(pGRegion gr, pPList &PM00,
			       pPList &TPM00, SCOREC::Util::scorecSSList<pFace> &BPM00)
{
  pRegion region;
  pFace face_B, face_T, face;
  pFace faces[2];
  pEdge edge;
  pVertex vt, vert_T, verts[2];
  pPList tmpList, rverts;
  pPList interactRgns;  // list to hold regions interacted with an edge on PM00
  pPList pmRgns;        // list to hold regions interacted with all edges on PM00
  double xyz[4][3];
  double volume;
  void *iter, *iter_2, *iter_3;
  int i,j,flag;

  interactRgns=PList_new();
  pmRgns=PList_new();

  // loop over edges on PM00 to determine all interacted mesh regions
  iter=0;
  while( edge=(pEdge)PList_next(PM00,&iter) ) {
    face_B=adaptUtil::F_getFmFaces(BPM00,edge);
    face_T=adaptUtil::F_getFmFaces(TPM00,edge);
    vert_T=F_edOpVt(face_T,edge);
    
    // loop over regions hooked on current edge
    tmpList=E_regions(edge);
    iter_2=0;
    while( region=(pRegion)PList_next(tmpList,&iter_2) ) {
      if( R_whatIn(region)!=gr ) continue;
      
      // get the two faces of current region bounded by the edge
      j=0;
      for( i=0; i<4; i++ ) {
	face=R_face(region,i);
	if( F_inClosure(face,(pEntity)edge) ) {
           faces[j]=face;
           verts[j]=F_edOpVt(faces[j],edge);   
           j++;
        } 
      }

      // determine if intersected
      // flag=0             ==> Intersect a region
      // flag=1 && volume=0 ==> Intersect two regions at their common face
      // flag=1 && volume<0 ==> Not intersected
      rverts=R_vertices(region,1);
      flag=0;
      for( i=0; i<2; i++ ) {
	iter_3=0; j=0;
        while( vt=(pVertex)PList_next(rverts,&iter_3) ) {
	  if( vt==verts[i] ) 
	    V_coord(vert_T,xyz[j++]);
	  else
	    V_coord(vt,xyz[j++]);
        }
        volume=XYZ_volume(xyz);
        if( volume<mtol )
 	  { flag=1; break; }
      }
      PList_delete(rverts);
     
      if( !flag ) { PList_append(interactRgns,region); break; }
      if( ABS(volume)<mtol ) {
        for( j=0; j<2; j++ ) {
          region=F_region(faces[(i+1)%2],j);
          if( region && R_whatIn(region)==gr )
	    PList_append(interactRgns,region);
        }
        break;
      }
    }
    PList_clear(tmpList);
    // --- loop of regions ends ---
    
    // "face_T" does not intersect the local mesh, continue for next edge
    if( PList_size(interactRgns)==0 )  
      continue;


    // "face_T" does intersect
    // determine other interact regions to be deleted
    flag=0;
    for( i=0; i<2; i++ ) {
      region=F_region(face_B,i);
      if( !region || R_whatIn(region)!=gr ) 
	continue;

      for( ; ; ) {
	if( PList_inList(interactRgns,(pEntity)region) ) 
	  { flag=1; break; }
	for( j=0; j<4; j++ ) {
	  face=R_face(region,j);
	  if( face==face_B ) continue;
	  if( F_inClosure(face,(pEntity)edge) )
	    break;
	}
	if( F_whatInType(face)==Gface && 
	    !EN_getDataInt((pEntity)face,int_snap,&j) ) {
	  F_info(face);
	  break;
	}
	face_B=face;
	PList_append(tmpList,region);
	region=adaptUtil::F_otherRgn(face_B,region);
      }

      if( flag ) {
	PList_app2Lst(&interactRgns,tmpList,0);
	break;
      } 
      else 
	PList_clear(tmpList);
    }
    if( flag==0 ) {
      //      PList_printx(interactRgns);
      cerr<<"Error: interacted region between TPM00 and intersecting region";
      cerr<<" can not be determined (processIntersection_1)"<<endl;
      return 0;
    }
    PList_delete(tmpList);

    PList_appPListUnique(pmRgns,interactRgns);
    PList_clear(interactRgns);
  }
  PList_delete(interactRgns); 
  // --- loop of edges ends ---

  // delete interacted regions and expand cavity
  iter=0;
  while( region=(pRegion)PList_next(pmRgns,&iter) ) 
    expandCavity(region,BPM00,0,-1);
  PList_delete(pmRgns);    

  return 1;
}



/*
  process intersections between faces of the two pieces of surface mesh
  without a common edge

  loop over faces in "BPM00" and intersect each current face with "TPM00"
  
  return 1: succeed;
         0: failed;
         2: TPM00 reshaped, need recheck intersections of BPM00 and TPM00

*/
int meshSnap::processIntersection_2(pGRegion gr, pPList &PM00, 
				    pPList &TPM00, SCOREC::Util::scorecSSList<pFace> &BPM00, int second)
{
  pRegion region;
  pFace face_1, face_2;
  void *iter;
  int value;
  int recheck=1;
  int ok=1;

  IntersectionData idata;
  pPList removedEnts=PList_new();
  SCOREC::Util::scorecSSListIter<pFace> fcIter(BPM00);

  // recheck intersection is required in case a mesh face at boundary is expanded
  while( recheck ) {
    recheck=0;

    fcIter.reset();
    while( fcIter(face_1) ) {
      if( PList_inList(removedEnts,(pEntity)face_1) ) {
	fcIter.remove();
	PList_remItem(removedEnts,(pEntity)face_1);
	continue;
      }
      
      iter=0;
      while( face_2=(pFace)PList_next(TPM00,&iter) ) {
	if( adaptUtil::CommonEdge(face_1,face_2) ) 
	  continue;
	
	idata=M_intersectionData_new();
	// inclosure intersects inclosure
	if( ! M_intersectFaces(face_1,1,face_2,1,&idata) ) {
	  // does not intersect
	  M_intersectionData_delete(idata);
	  continue;
	}
	
	// if the two faces have a common vertex, it must be on PM00
	// and it should be considered as " not intersected"
	if( idata.dim==0 ) 
	  if( EN_type(idata.Description->IntEnt1)==Tvertex &&
	      idata.Description->IntEnt1==idata.Description->IntEnt2 ) {
	    M_intersectionData_delete(idata);
	    continue;
	  }
// 	printf("Highest intersection dimension: %d\n",idata.dim);
// 	printf("IntEnt1: %p %d   IntEnt2: %p %d \n",idata.Description->IntEnt1, 
// 	                                            EN_type(idata.Description->IntEnt1),
// 	                                            idata.Description->IntEnt2,
// 	                                            EN_type(idata.Description->IntEnt2));
	M_intersectionData_delete(idata);
	
	// now the two faces are intersected
	if( F_whatInType(face_1)==Gregion || 
	    EN_getDataInt((pEntity)face_1,int_snap,&value) ) {
	  region=F_region(face_1,0);
	  if( second ) {
	    if( F_region(face_1,1) && region )
	      { cout<<"Error - not implemented (processIntersection_2)"<<endl; throw; }
	    if( !region )
	      region=F_region(face_1,1);
	    if( !region )
	      { cout<<"Error - invalid mesh (processIntersection_2)"<<endl; throw; }
	  } 
	  else {	    
	    if( !region || R_whatIn(region)!=gr )
	      region=F_region(face_1,1);
	    if( !region || R_whatIn(region)!=gr ) { 
	      F_info(face_1);
	      cout<<"Error - an interior face bounding two model regions (processIntersection_2)"<<endl; 
	      throw; 
	    }
	  }
	  expandCavity(region,BPM00,&removedEnts,Tface);
	}
	
	// classified on a model face not initially in B(P(M00))
	else {
	  cout<<"INFO - want to expand a face classified on model face"<<endl;

	  SCOREC::Util::scorecSSListIter<pFace> fIter(BPM00);
	  pFace face;
	  while( fIter(face) ) {
	    if( PList_inList(removedEnts,(pEntity)face) ) {
	      fIter.remove();
	      PList_remItem(removedEnts,(pEntity)face);
	      continue;
	    }
	  }

	  switch ( expandCavityAtBdry(face_1,face_2,PM00,BPM00,&removedEnts,Tface) ) {
	  case 0: 
	    {ok=0; break;}
	  case 3:
	    { cerr<<"       NOT IMPLEMENTED"<<endl; ok=0; break; }
	  case 4:
	    {ok=2; break;}
	  default:
	    { recheck=1; ok=1;}
	  }  //end of switch
	}  // end of if else

	break;
      }  // end traversing faces in T(P(M00))

      if( recheck || ok==2 || ok==0 )
	break;
    }  // end traversing faces in B(P(M00))

    if( ok==2 || ok==0 )
      break;
  }  // while loop of recheck

  iter=0;
  while( face_1=(pFace)PList_next(removedEnts,&iter) )
    BPM00.remove(face_1);
  PList_delete(removedEnts);

  return ok;
}

/* return 1 if face_B is modified by vertex motion, 
          2 in case modified by swap or collapse
          3 in case of a NOT IMPLEMENTED situation
	  4 in case a vertex of face_T not on PM00 is moved
	  5 in case an edge of face_B not on PM00 is split and snapped
          0 otherwise 0 */
int meshSnap::expandCavityAtBdry(pFace face_B, pFace face_T, pPList &PM00,
	       SCOREC::Util::scorecSSList<pFace> &BPM00, pPList *pRemoved, int type)
{
  pRegion rgn;
  pFace face;
  pEdge ed;
  pVertex vt;
  std::list<pFace> tmpList;
  double shape_1;
  int i, applied, Flag;
  void *iter;
  void *tmp_ptr;

  // snap first in case there are unsnapped bounding vertices
  pPList vertices=F_vertices(face_B,1);
  iter=0;
  applied=0;
  while( vt=(pVertex)PList_next(vertices,&iter) ) {
    if(!EN_getDataPtr((pEntity)vt,ptr_xyz,&tmp_ptr)) 
      continue;
    printf("Found an unsnapped vertex %d on BPM00 (expandCavityAtBdry)\n",EN_id((pEntity)vt));
    applied=1;
    pSnaplist->push_back(vt);
  }
  PList_delete(vertices);

  if( pSnaplist->size() > 0 ) {
    i=GeoSimCheck;
    this->setGeoSimCheck(0);
    if( this->run() )
      printf("Fatal Error: expandCavityAtBdry()\n");
    this->setGeoSimCheck(i);
    pRemovedVerts.insert(vt);

    if( type==Tface ) 
      return updateBPM00(PM00,BPM00);
  }

  if( applied )
    return 1;
  
  
  // check geometry similarity nearby "face_B"
  if( !EN_getDataInt((pEntity)face_B,int_geoSim,&Flag) ) 
    Flag = adaptUtil::F_checkGeoSim(face_B, ptr_GFparams);
  if( Flag!=1 )
    tmpList.push_back(face_B);

  for( i=0; i<3; i++ ) {
    ed=F_edge(face_B,i);
    face=adaptUtil::E_otherBdryFace(ed,face_B);
    if( !face ) continue;
    if( !EN_getDataInt((pEntity)face,int_geoSim,&Flag) ) 
      Flag = adaptUtil::F_checkGeoSim(face, ptr_GFparams);
    if( Flag!=1 )
      tmpList.push_back(face);
  }

  // apply swap or collapse to eliminate dis-similarity if there is
  if( tmpList.size() ) {
    while( tmpList.size() ) {
      std::list<pFace>::iterator fcit=tmpList.begin();
      for( ; fcit!=tmpList.end(); ) {
	if( !fixGeoSim(*fcit, &tmpList, 1, &BPM00, Flag) ) {
	  tmpList.erase(fcit++);
	  cerr<<"Error: a face not similar to boundary is not eliminated (expandCavityAtBdry)"<<endl;
	  return 0;
	}
	
      }
    }
    return 2;
  }

  // refine an edge of face_B that improves geometry approximation most
  if( splitSnapBPM00(face_B,PM00,BPM00,pRemoved,type) ) {
    printf("Info: split and snapped a vertex on BPM00\n");
    return 5;
  }

  // move the interior vertex of TPM00, then recheck
  if( reshapeTPM00(face_T,face_B,PM00) ) {
    printf("Info: moved an interior vertex of TPM00\n");
    return 4;
  }

  // To be investigated in case it really occurs
  cout<<"INFO:  need refinement or bad T(P(M00)) (expandCavityAtBdry)"<<endl;
  return 3;
}


/*
  improve geometry approximation of BPM00

  return 1: if splitting an edge and snap the new vertex
         0: otherwise

  11/26/03 -xli
 */
int meshSnap::splitSnapBPM00(pFace face_B, pPList &PM00, SCOREC::Util::scorecSSList<pFace> &BPM00, 
			     pPList *pRemoved, int type)
{
  pFace face, faces[4];
  pEdge edge,splitedge;
  pEdge newEdges[4];
  pVertex vts[2];
  double xyz[3],tmppar[3], par[3];
  double *dest=new double[3];
  double dOverH, worstDoverH=0;
  int i, j, count;

  if( F_whatInType(face_B) != Tface )
    return 0;

  // determine the edge to be split
  for( i=0; i<3; i++ ) {
    edge=F_edge(face_B,i);
    if( PList_inList(PM00,edge) )
      continue;
    templatesUtil::middlePoint(edge,0.5,xyz,tmppar);
    // dOverH=adaptUtil::E_dOverH(edge,xyz);
    dOverH=adaptUtil::E_lengthSq(edge);
    if( dOverH > worstDoverH ) {
      worstDoverH=dOverH;
      dest[0]=xyz[0]; dest[1]=xyz[1]; dest[2]=xyz[2];
      par[0]=tmppar[0]; par[1]=tmppar[1]; par[2]=tmppar[2];
      splitedge=edge;
    }
  }

  if( !worstDoverH )
    return 0;

  if( type==Tface ) {
    // update BPM00
    count=0;
    for( i=0; i<E_numFaces(splitedge); i++) {
      face=E_face(splitedge,i);
      if( BPM00.inList(face) ) {
	BPM00.remove(face);
	count++;
      }
    }
    if( count!=2 )
      printf("Error: 1 splitSnapBPM00()\n");
  }
  
  vts[0]=E_vertex(splitedge,0);
  vts[1]=E_vertex(splitedge,1);

  // split the edge 
  edgeSplitMod esplt(pmesh,pSizeField,shpMeasure,result);
  esplt.setCallback(function_CB,userData_CB);
  esplt.setCallback(CB_move,userData_CB_move);
  esplt.setSplitEdge(splitedge);
  adaptUtil::centroidOfMEdge(splitedge,xyz);
  esplt.setSplitPos(xyz,par);
  esplt.apply();

  // update BPM00
  pVertex newv = esplt.getNewVertex();
  for( i=0; i<2; i++ ) {
    newEdges[i]=E_exists(newv,vts[i]);
    if( !newEdges[i] )
      printf("Error: meshSnap::splitSnapBPM00\n");
    EN_constrain( COLAPS,(pEntity)newEdges[i] );
  }
  EN_constrain( COLAPS,(pEntity)newv );

  // snap the new vertex
  this->append(newv,dest);
  i=GeoSimCheck;
  this->setGeoSimCheck(0);
  if( this->run() )
    printf("Fatal Error: 3 splitSnapBPM00()\n");
  this->setGeoSimCheck(i);
  EN_unconstrain( COLAPS,(pEntity)newv );
  for( i=0; i<2; i++ ) 
    EN_unconstrain( COLAPS,(pEntity)newEdges[i] );

  if( type==Tface ) {
    return updateBPM00(PM00,BPM00);
  }
//     {
//     if( EN_id((pEntity)newv) < 0 ) {
//       printf("Error: the new vertex of BPM00 was deleted (splitSnapBPM00)\n");
//       return 0;
//     }
//     for( i=0; i<4; i++ ) {
//       if( EN_id((pEntity)oppEdges[i]) < 0 ) {
// 	printf("Error: unable to update BPM00 (splitSnapBPM00)\n");
// 	return 0;
//       }
//       faces[i]=F_exists(Tvertex,(pEntity)newv,(pEntity)E_vertex(oppEdges[i],0),
// 			(pEntity)E_vertex(oppEdges[i],1),0);
//       //      faces[i]=adaptUtil::F_exists_2(oppEdges[i],newv);
//       if( !faces[i] )
// 	printf("Error: 2 splitSnapBPM00()\n");
//       BPM00.append(faces[i]);
//     }
//     }

  return 1;
}


/* 
   find the missing faces of B(P(M00)) isolated by P(M00)
   return 1: successful
          0: otherwise, e.g. P(M00) is touched
   created: 11/30/03  -li
*/

int meshSnap::updateBPM00(pPList &PM00, SCOREC::Util::scorecSSList<pFace> &BPM00)
{
  SCOREC::Util::scorecSSListIter<pFace> fIter(BPM00);
  pFace face,face_2;
  pEdge edge;
  int i,j,num, count;

  while( fIter(face) ) {
    if( EN_id((pEntity)face)<0 ) 
      fIter.remove();
  }

  fIter.reset();
  while( fIter(face) ) {
    for( i=0; i<3; i++ ) {
      edge=F_edge(face,i);
      if( PList_inList(PM00,edge) )
	continue;
      num=E_numSSListFace(BPM00,edge);
      if( num==2 )
	continue;
      if( num !=1 ) {
	printf("Error: num=%d (updateBPM00)\n",num);
	return 0;
      }
      
      count=0;
      num=E_numFaces(edge);
      for(j=0; j<num; j++) {
	face_2=E_face(edge,j);
	if( face_2==face )
	  continue;

	if( F_region(face_2,0) && F_region(face_2,1) )
	  continue;

	BPM00.append(face_2);
	count++;
      }
      if( count!=1 ) 
	throw;
    }
  }

  return 1;
}

int meshSnap::E_numSSListFace(SCOREC::Util::scorecSSList<pFace> &BPM00,pEdge edge)
{
  SCOREC::Util::scorecSSListIter<pFace> fIter(BPM00);
  pFace face;
  int i, count;

  count=0;
  while( fIter(face) ) {
    for( i=0; i<3; i++ ) 
      if( F_edge(face,i)==edge )
	count++;
  }
  return count;
}



/*
  relocate the interior vertex of TPM00

  return 1: if relocation occurs
         0: other wise

  created: 11/19/03 -xli
 */
int meshSnap::reshapeTPM00(pFace face_T, pFace face_B, pPList &PM00)
{
  pEdge edge, tmpEdge;
  pVertex vert_T, vert_B, vertex;
  int i;

  // find interior vertex to move
  int count=0;
  for( i=0; i<3; i++ ) {
    edge=F_edge(face_T,i);
    if( PList_inList(PM00,edge) ) {
      tmpEdge=edge;
      count++;
    }
  }

  switch ( count ) {
  case 0: {
    printf("Info: an interior face of TPM00 (meshSnap::reshapeTPM00)\n");
    vert_T=E_vertex(edge,0);
    break;
  }
  case 1: {
    vert_T=F_edOpVt(face_T,tmpEdge);
    if( V_whatInType(vert_T)==Tedge ) {
      printf("Info: an interior vertex of TPM00 on Gedge(meshSnap::reshapeTPM00)\n");
      return 0;
    }
    break;
  }
  default:
    return 0;
  }

  // find the closest vertex of face_B to vert_T
  pPList tmpList=F_vertices(face_B,1);
  void *iter=0;
  double xyz[3], coords[3], par[3];
  double tmpd, dd=1e14;
  V_coord(vert_T,xyz);
  while( vertex=(pVertex)PList_next(tmpList,&iter) ) {
    V_coord(vertex,coords);
    tmpd = XYZ_distance2(xyz,coords);
    if( tmpd < dd ) {
      dd = tmpd;
      vert_B = vertex;
    }
  }
  PList_delete(tmpList);

  // find the new location for vert_T
  int type=F_whatInType(face_T);
  pGEntity gent=F_whatIn(face_T);
  V_coord(vert_B,xyz);

  // C_closestPoint() is no longer used, please use GF_closestPoint and GE_closestPoint instead. 
  // C_closestPoint(type,gent,xyz,0,0,0,coords,par); 
  if(type==2)
    GF_closestPoint((pGFace)gent, xyz, coords, par);
  if(type==1)
    GE_closestPoint((pGEdge)gent, xyz, coords, par);
  
  if( XYZ_distance2(xyz,coords) < 0.0001*dd ) {
    // the new location is close to the current one
    return 0;
  }
  
  pPList surfT = V_faces(vert_T);
  if( isTriangulationValid(&surfT, vert_T, coords) ) {
    PList_delete(surfT);
    return 0;
  }
  PList_delete(surfT);

  // set parameter and coordinate of vert_T to the new location
  pPoint pt=M_createP(pmesh,coords[0],coords[1],coords[2],par,0,gent);
  pPoint point=V_point(vert_T);
  V_setPoint(vert_T,pt);
  P_delete(point);

  return 1;    
}


/*
  check if faces in "BPM00" are a piece of face mesh.
  if not, identify those not connected to the local mesh, delete them, 
  thus again expand the cavity
*/
void meshSnap::removeDiscEntities(pGRegion gr,pPList &PM00,
				  SCOREC::Util::scorecSSList<pFace> &BPM00)
{
  void *Buff;
  pPList tmpList;
  pPList edList=PList_new();
  pRegion region;
  pFace face_B, face_1;
  pEdge edge;
  void *iter;
  int i, value;

  SCOREC::Util::scorecSSListIter<pFace> fiter(BPM00);

  // determine the two cavity faces for each cavity edge
  while( fiter(face_B) ) {
    for( i=0; i<3; i++ ) {
      edge=F_edge(face_B,i);
      if(EN_getDataPtr((pEntity)edge,ptr_remesh,&Buff)) 
	PList_append((pPList)Buff,face_B);
      else {
	PList_append(edList,edge);
	tmpList=PList_new();
	PList_append(tmpList,face_B);
	EN_attachDataPtr((pEntity)edge,ptr_remesh,tmpList);
      }
    }
  }

  // get the face in BPM00 connected to an edge of PM00
  edge=(pEdge)PList_item(PM00,0);
  EN_getDataPtr((pEntity)edge,ptr_remesh,&Buff);
  iter=0;
  pPQueue pQ=PQueue_new();
  while( face_B=(pFace)PList_next((pPList)Buff,&iter) ) {
    PQueue_push(pQ,(pEntity)face_B);
  }

  // color faces in the piece connected to PM00
  pMeshDataId color=MD_newMeshDataId("color_as_connected");
  while( face_B=(pFace)PQueue_pop(pQ) ) {
    if( EN_getDataInt((pEntity)face_B,color,&value) )
      continue;
    EN_attachDataInt((pEntity)face_B,color,1);
    for( i=0; i<3; i++ ) {
      edge=F_edge(face_B,i);
      if(EN_getDataPtr((pEntity)edge,ptr_remesh,&Buff)) {
	tmpList=(pPList)Buff;
	PList_remItem(tmpList,face_B);
	iter=0;
	while( face_1=(pFace)PList_next(tmpList,&iter) ) 
	  PQueue_push(pQ, (pEntity)face_1);

	EN_deleteData( (pEntity)edge, ptr_remesh );
	PList_delete(tmpList);
      }
    }
  }
  PQueue_delete(pQ);

  // clean the attached pPList
  iter=0;
  while( edge=(pEdge)PList_next(edList,&iter) ) 
    if(EN_getDataPtr((pEntity)edge,ptr_remesh,&Buff)) {
      PList_delete((pPList)Buff);
      EN_deleteData( (pEntity)edge, ptr_remesh );
    }
  PList_delete(edList);

  // process initial faces in BPM00 in case non-manifold
  fiter.reset();
  while( fiter(face_B) ) {
    if( !EN_getDataInt((pEntity)face_B,int_snap,&value) )
      continue;
    region=F_region(face_B,0);
    if( !region || R_whatIn(region)!= gr )
      continue;
    region=F_region(face_B,1);
    if( !region || R_whatIn(region)!= gr )
      continue;   

    fiter.remove();
    F_setWhatIn(face_B,(pGEntity)gr);
    EN_deleteData((pEntity)face_B,int_snap);
    if( EN_getDataInt((pEntity)face_B,color,&value) )
      EN_deleteData((pEntity)face_B,color);
  }

  // delete the pieces not colored
  pPList removedEnts=PList_new();
  fiter.reset();
  while( fiter(face_B) ) {
    if( PList_inList(removedEnts,(pEntity)face_B) ) { 
      fiter.remove();
      PList_remItem(removedEnts,(pEntity)face_B);
      continue;
    }

    if( EN_getDataInt((pEntity)face_B,color,&value) )
      continue;
    // found a disconnected face in BPM00
    region=F_region(face_B,0);
    if( !region || R_whatIn(region)!=gr ) 
      region=F_region(face_B,1);
    if( region && R_whatIn(region)==gr ) {
//       #ifdef DEBUG
//       cout<<" delete a disconnected region "<<region<<endl;
//       #endif
      expandCavity(region,BPM00,&removedEnts,Tface);   
    }
  }

  iter=0;
  while( face_B=(pFace)PList_next(removedEnts,&iter) )
    BPM00.remove(face_B);
  PList_delete(removedEnts);

  // delete the attached color
  fiter.reset();
  while( fiter(face_B) ) 
    EN_deleteData((pEntity)face_B,color);
  MD_deleteMeshDataId(color);

  return;
}


/*
  re-classify a mesh mesh entities on original boundary onto Gregion
  Created:            01/16/2001  
*/
void meshSnap::reclassifyReplacedBdry(pGRegion gr, SCOREC::Util::scorecSSList<pFace> &BPM00)
{
  pFace face;
  pEdge edge;
  pVertex vertex;
  void *iter;
  int value;

  // re-classify faces 
  SCOREC::Util::scorecSSListIter<pFace> fiter(BPM00);
  while( fiter(face) ) 
    if( EN_getDataInt((pEntity)face,int_snap,&value) ) {
      // reclassify the face
      F_setWhatIn(face,(pGEntity)gr);
      EN_deleteData((pEntity)face,int_snap);
    }

  // re-classify edges
  iter=0;
  while( edge=(pEdge)PList_next(coveredEds,&iter) ) 
    E_setWhatIn(edge,(pGEntity)gr);

  // reclassify vertices
  iter=0;
  while( vertex=(pVertex)PList_next(coveredVts,&iter) ) {
    void *temp_ptr;
    if( EN_getDataPtr((pEntity)vertex,ptr_GFparams,&temp_ptr) ) {
      EN_deleteData((pEntity)vertex,ptr_GFparams);
      delete (ParamsOnGFace *)temp_ptr;
    }
    V_setWhatIn(vertex,(pGEntity)gr);
  }

  PList_delete(coveredEds);
  PList_delete(coveredVts);
  return;
}



/* 
   remove the given mesh region, update faces in list "BPM00" by the four
   bounding faces of the region

   if type==Tvertex, any removed vertex will be put into list "removed"
   if type==Tedge,  any removed edge will be put into list "removed"
   if type==Tface,  any removed face will be put into list "removed"
   if u do not want to collect the entities being removed, set type==-1
      and leave the list "nil"
*/
void meshSnap::expandCavity(pRegion region,SCOREC::Util::scorecSSList<pFace> &BPM00, 
				pPList *removed, int type)
{
  pGRegion gr=R_whatIn(region);
  pRegion region_2;
  pFace r_faces[4];
  int i, value;

  for ( i= 0; i<4; i++ ) 
    r_faces[i]= R_face(region,i);
  M_removeRegion(pmesh,region);
      
  for ( i= 0; i< 4; i++ ) {
    // if it is a boundary face in initial BPM00
    if( EN_getDataInt((pEntity)r_faces[i],int_snap,&value) ) {
      region_2=F_region(r_faces[i],0);
      if( !region_2 ) region_2=F_region(r_faces[i],1);
      if( region_2 && R_whatIn(region_2)==gr ) 
	continue;

      if( type==Tface ) 
	PList_append(*removed,r_faces[i]);
      else {
	BPM00.remove(r_faces[i]);
	//	printf("1. remove face %p\n",r_faces[i]);
      }
      EN_deleteData( (pEntity)r_faces[i], int_snap );
      deleteFace(r_faces[i],removed,type);
    }
    
    // if a mesh face on model face not in initial BPM00
    else if( F_whatInType(r_faces[i])==Gface ) {
      BPM00.appendUnique(r_faces[i]);
      //      printf("1. add face %p\n",r_faces[i]);
    }

    // a mesh face on model region
    else {
      if( F_region(r_faces[i],0)==0 && F_region(r_faces[i],1)==0 ) {
	if( BPM00.inList(r_faces[i]) ) {
	  if( type==Tface ) {
	    PList_append(*removed,r_faces[i]);	 
	  }
	  else {
	    BPM00.remove(r_faces[i]);
	    //  printf("2. remove face %p\n",r_faces[i]);
	  }
	}
	deleteFace(r_faces[i],removed,type);
      } else {
	BPM00.appendUnique(r_faces[i]);
	//	printf("3. add face %p\n",r_faces[i]);
      }
    }
  }

  return;
}


/*
  delete a mesh face and its bounding mesh entities if could, update the two given list
  created  01/16/01
*/
void meshSnap::deleteFace(pFace face,pPList *removed,int type)
{
  if (F_region(face,0)==0 && F_region(face,1)==0) {
    
    pEdge F_edges[3];
    pVertex vt[2];
    int i,j;
    
    for(i=0;i<3;i++)
      F_edges[i]=F_edge(face,i);

    if( EN_getDataInt((pEntity)face,int_geoSim,&j) )
      EN_deleteData((pEntity)face,int_geoSim);
    M_removeFace(pmesh, face);
    
    // process edges hereafter
    for(i=0;i<3;i++) {
      if (E_numFaces(F_edges[i])==0) {
	
	for(j=0;j<2;j++)
	  vt[j]=E_vertex(F_edges[i],j);

	if( type==Tedge )
	  PList_append(*removed,F_edges[i]);
        PList_remItem(coveredEds,(pEntity)F_edges[i]); 
	M_removeEdge(pmesh, F_edges[i]);
	
	// processor vertex hereafter
	for(j=0;j<2;j++) {
	  if( type==Tvertex && !V_numEdges(vt[j]) )
	    PList_append(*removed,vt[j]);
          if( !V_numEdges(vt[j]) )
            PList_remItem(coveredVts,(pEntity)vt[j]);
	  delete_vertex(vt[j]);
	}
      }
    }
  }

  return;
}


/*
  determine if there are close entities between "TPM00" and "BPM00"
  In case there is, expand cavity by deleting region(s) attached to 
     the entity from "BPM00"

  Three steps:
  (1) check small diheral angle at any edge on "PM00";
  (2) check short distance from any interior vertex of "BPM00" to faces in "TPM00"
  (3) check short distance between interior edges of "BPM00" and "TPM00"

  Currently, angle less than 10 degree is considered as "small"
             distance less than 0.1 of the desired size is considered as "small"

  created 12/06/01  -li
*/
void meshSnap::removeCloseEntities(pPList &PM00,pPList &TPM00,SCOREC::Util::scorecSSList<pFace> &BPM00)
{
  pRegion region, rgn0, rgn1;
  pFace face_B, face_T;
  pEdge edge, edge_2, edge_T;
  pVertex vertex, otherV;
  pPList tmpList;
  double xyz[4][3];
  void *iter, *iter_2;
  int i,j,value;
  double dSqr, SizeSqr;

  // detect small dihedral angles at junction edges    xli 9/12/01
  pPQueue pQ=PQueue_new();
  iter=0;
  while( edge=(pEdge)PList_next(PM00,&iter) ) 
    PQueue_push(pQ,(pEntity)edge);

  while( edge=(pEdge)PQueue_pop(pQ) ) {
    face_B=adaptUtil::F_getFmFaces(BPM00,edge);
    if( !face_B ) continue;      // note this is possible  12/13/01 
    if( F_whatInType(face_B)==Gface &&
       !EN_getDataInt((pEntity)face_B,int_snap,&value) ) 
      continue;
    face_T=adaptUtil::F_getFmFaces(TPM00,edge);

    V_coord( E_vertex(edge,0), xyz[0] );
    V_coord( E_vertex(edge,1), xyz[1] );
    V_coord(F_edOpVt(face_T,edge),xyz[2]);
    V_coord(F_edOpVt(face_B,edge),xyz[3]);
    
//  #ifdef MVTK
//    mvtkAddMEnt((pEntity)face_B);
//    mvtkAddMEnt((pEntity)face_T);
//    mvtkActivate();
//    mvtkRemoveAllMEnts();
//  #endif

    // if the angle less than 10 degree
    //if( E_dihedral(xyz) < 0.9848 ) continue;
    //if( E_dihedral(xyz) < 0.9659 ) continue;    // less than 15 degree
    if( E_dihedral(xyz) < 0.9397 ) continue;    // less than 20 degree
    
    region=F_region(face_B,0);
    if( !region ) region=F_region(face_B,1);
    if( !region ) continue;
    
    // expand the cavity
    // Need to fix: can not remove the face if in TPM00_gf[i]
    expandCavity(region,BPM00,0,-1);
    PQueue_push(pQ,(pEntity)edge);
  }   

  pPList removedEnts=PList_new();

  // mark entities in the closure of PM00
  // estimate the threshold value for small distance
  iter=0;
  SizeSqr=-1.0;
  while( edge=(pEdge)PList_next(PM00,&iter) ) {
    EN_attachDataInt((pEntity)edge,int_snap,1);
    EN_attachDataInt((pEntity)E_vertex(edge,0),int_snap,1);
    EN_attachDataInt((pEntity)E_vertex(edge,1),int_snap,1);

    for( i=0; i<2; i++ ) {
      dSqr=adaptUtil::V_shortestLength( E_vertex(edge,i) );
      if( SizeSqr==-1.0 )
	SizeSqr=dSqr;
      else if( dSqr < SizeSqr )
	  SizeSqr=dSqr;
      }
  }
  SizeSqr *= 0.111111;

  // detect small distance from interior point of BPM00 to faces in TPM00

  // determine the interior vertex of BPM00
  SCOREC::Util::scorecSSListIter<pFace> fiter(BPM00);
  while( fiter(face_B) ) {
    tmpList=F_vertices(face_B,1);
    iter=0;
    while( vertex=(pVertex)PList_next(tmpList,&iter) ) {
      if( EN_getDataInt((pEntity)vertex,int_snap,&value) )
        continue;
      if( V_whatInType(vertex)!=Gregion && 
          ! EN_getDataInt((pEntity)face_B,int_snap,&value) ) 
        continue;
      PQueue_pushUnique(pQ,(pEntity)vertex);
    }
    PList_delete(tmpList);
  }

  // calculate point-triangle distance, and expand in case small
  while( vertex=(pVertex)PQueue_pop(pQ) ) {
    if( PList_inList(removedEnts,(pEntity)vertex) ) {
      PList_remItem(removedEnts,vertex);
      continue;
    }
    iter=0;
    while( face_T=(pFace)PList_next(TPM00,&iter) ) 
      {
	dSqr=adaptUtil::V_sqrDistToFace(vertex,face_T);
	if( dSqr<SizeSqr ) {
	  //        cout<<dSqr<<"  vertex:"<<EN_id((pEntity)vertex)<<endl;
	  // append new interior vertices into the queue
	  for( i=0; i<V_numEdges(vertex); i++ ) 
	    {
	      edge=V_edge(vertex,i);
	      otherV=E_otherVertex(edge,vertex);
	      if( EN_getDataInt((pEntity)otherV,int_snap,&value) )
		continue;
	      if( V_whatInType(otherV)!=Gregion )
		continue;
	      PQueue_pushUnique(pQ,(pEntity)otherV);
	    }
	  
	  tmpList=V_regions(vertex);
	  iter_2=0;
	  while( region=(pRegion)PList_next(tmpList,&iter_2) ) 
	    expandCavity(region,BPM00,&removedEnts,Tvertex);
	  PList_delete(tmpList);
	  break;
	}
      }
  }
  PList_clear(removedEnts);

  // detect small distance between interior edges of TPM00 and BPM00

  // determine interior edges in TPM00
  pPList Tedges=PList_new();
  iter=0;
  while( face_T=(pFace)PList_next(TPM00,&iter) ) 
    for( i=0; i<3; i++ ) {
      edge=F_edge(face_T,i);
      if( EN_getDataInt((pEntity)edge,int_snap,&value) )
	continue;
      PList_appUnique(Tedges,(pEntity)edge);
    }

  // determine interior edges in BPM00
  fiter.reset();
  while( fiter(face_B) ) 
    for( i=0; i<3; i++ ) {
      edge=F_edge(face_B,i);
      if( EN_getDataInt((pEntity)edge,int_snap,&value) )
	continue;
      if( E_whatInType(edge) != Gregion &&
         !EN_getDataInt((pEntity)face_B,int_snap,&value) ) 
	continue;
      PQueue_pushUnique(pQ,(pEntity)edge);
    }

  // calculate segment-to-segment distance between interior edges of
  // BPM00 and TPM00, expand in case the distance is small
  pVertex Evts[2];
  while( edge=(pEdge)PQueue_pop(pQ) ) {
    if( PList_inList(removedEnts,(pEntity)edge) ) {
      PList_remItem(removedEnts,edge);
      continue;
    }
    Evts[0]=E_vertex(edge,0);
    Evts[1]=E_vertex(edge,1);

    iter=0;
    while( edge_T=(pEdge)PList_next(Tedges,&iter) ) {
      
      if( Evts[0]==E_vertex(edge_T,0) || Evts[0]==E_vertex(edge_T,1) )
	continue;
      if( Evts[1]==E_vertex(edge_T,0) || Evts[1]==E_vertex(edge_T,1) )
	continue;
      dSqr=adaptUtil::M_sqrDistEdges(edge,edge_T);
      if( dSqr<SizeSqr ) {
	//	cout<<dSqr<<"  edges: "<<EN_id((pEntity)edge_T)<<"  "<<EN_id((pEntity)edge)<<endl;
	// append new interior vertex of BPM00 into the queue
	for( i=0; i<E_numFaces(edge); i++ ) {
	  face_B=E_face(edge,i);
	  for( j=0; j<3; j++ ) {
	    edge_2=F_edge(face_B,j);
	    if( edge==edge_2 ) continue;
	    if( EN_getDataInt((pEntity)edge_2,int_snap,&value) )
	      continue;
            if( E_whatInType(edge_2) ==Gregion )
	      PQueue_pushUnique(pQ,(pEntity)edge_2);
	  }
	}
	tmpList=E_regions(edge);
	iter_2=0;
	while( region=(pRegion)PList_next(tmpList,&iter_2) )
	  expandCavity(region,BPM00,&removedEnts,Tedge);
	PList_delete(tmpList);
	break;
      }
    }
  }
  PQueue_delete(pQ);
  PList_delete(removedEnts);
  PList_delete(Tedges);

  // expand BPM00 if three faces of a tet are in BPM00
  fiter.reset();
  while( fiter(face_B) ) 
    {
      rgn0=F_region(face_B,0);
      rgn1=F_region(face_B,1);
      if( !rgn0 && !rgn1 )
	continue;
      if( rgn0 && rgn1 )
	continue;
      if( !rgn0 )
	rgn0=rgn1;
      value=0;
      for( i=0; i<4; i++ ) {
	face_T=R_face(rgn0,i);
	if( face_T==face_B || BPM00.inList(face_T) )
	  value++; 
      }
      if( value==3 )
	PList_appUnique(tmpList,rgn0);
    }
  iter=0;
  while( region=(pRegion)PList_next(tmpList,&iter) )
    expandCavity(region,BPM00,0,-1);

  // cleanup
  iter=0;
  while( edge=(pEdge)PList_next(PM00,&iter) ) {
    EN_deleteData((pEntity)edge,int_snap);
    EN_deleteData((pEntity)E_vertex(edge,0),int_snap);
    EN_deleteData((pEntity)E_vertex(edge,1),int_snap);
  }

//   #ifdef MVTK
//     pPList tmpcavity=PList_new();
//     visUtil::mvtkAddPList(TPM00,0.8,5,1,Tface);
//     mvtkActivate();
//     adaptUtil::PList_appSSList(&tmpcavity,&FM00,0);
//     visUtil::mvtkAddPList(tmpcavity,0.3,4,1,Tface);
//     mvtkActivate();
//     mvtkRemoveAllMEnts();
//   #endif

  return;
}

void meshSnap::interpMSizeAtVertex(pVertex vertex,pPList cavity)
{
  if ( !nullFieldFlag ) {
    pVertex vv,closeVt=0;
    double xyz[3], closeXYZ[3];
    double min_dSq=1e14, dSq;
//     pFace face;
//     void *iter=0, *iter_2;
//     pPList vts;
//     V_coord(vertex,xyz);
//     while( face=(pFace)PList_next(cavity,&iter) )
//       {
// 	vts=F_vertices(face,1);
// 	iter_2=0;
// 	while( vv=(pVertex)PList_next(vts,&iter_2) ) {
// 	  if( ! pSizeField->getSize(vv) )
// 	    continue;
// 	  V_coord(vv,closeXYZ);
// 	  dSq=XYZ_distance2(xyz,closeXYZ);
// 	  if( dSq<min_dSq ) 
// 	    { min_dSq=dSq; closeVt=vv; }
// 	}
// 	PList_delete(vts);
//       }

    pEdge edge;
    V_coord(vertex,xyz);
    for( int i=0; i<V_numEdges(vertex); i++ ) {
      edge = V_edge(vertex,i);
      vv = E_otherVertex(edge,vertex);
      if( ! pSizeField->getSize(vv) )
	 continue;
      V_coord(vv,closeXYZ);
      dSq=XYZ_distance2(xyz,closeXYZ);
      if( dSq<min_dSq ) 
	{ min_dSq=dSq; closeVt=vv; }
    }

    if( ! closeVt ) {
      printf("WARNING: a vertex without mesh size field created (meshSnap)\n");
      return;
    }
    pMSize pS=new MeshSize(pSizeField->getSize(closeVt));
    pSizeField->setSize((pEntity)vertex,pS);
    //    printf("vertex: %d (%p) set size=%f\n",EN_id((pEntity)vertex),vertex,pS->size(0));
  }
  return;
}

#ifdef DEBUG
void meshSnap::checkCavity(pPList cavityFaces)
{
  pFace face, face_2;
  void *iter, *iter_2;

  // check geometric similarity
  iter=0;
  while( face=(pFace)PList_next(cavityFaces,&iter) ) 
    {
      if( F_whatInType(face)==Gregion ) 
	continue;
      switch( adaptUtil::F_checkGeoSim(face,ptr_GFparams) ) 
	{
	case -1: 
	  printf("WARNING: face %d is not similar to geometry (checkCavity)\n",
		 EN_id((pEntity)face));
	  break;
	case 0:  
	  printf("WARNING: face %d has ZERO normal in parameter space (checkCavity)\n",
		 EN_id((pEntity)face));
	  break;
	case -2:
	  printf("WARNING: parameter not available (checkCavity)\n");
	  break;
	}
    }
  
  // check if cavity is open
  if( !adaptUtil::isCavityClosed(&cavityFaces) )
    { printf("Error: Open cavity (checkCavity)"); exit(0); }

  // check if the cavity intersects itself
  IntersectionData idata;
  iter=0;
  while( face=(pFace)PList_next(cavityFaces,&iter) ) 
    {
      iter_2=0;
      while( face_2=(pFace)PList_next(cavityFaces,&iter_2) ) 
	{
	  if( face_2==face )
	    continue;
	  idata=M_intersectionData_new();
	  if( M_intersectFaces(face,0,face_2,0,&idata) )
	    {
	      printf("Error: face %d intersects face %d (checkCavity)\n",
		     EN_id((pEntity)face),EN_id((pEntity)face_2));
	    }
	  M_intersectionData_delete(idata);
	}
    }

  return;
}

#endif //EDBUG

#endif //MA_PARALLEL






