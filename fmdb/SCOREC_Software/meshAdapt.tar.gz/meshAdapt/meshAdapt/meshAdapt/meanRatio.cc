#include "meanRatio.h"
#include "sizeFieldBase.h"
#include "MeshTools.h"
#include "Macros.h"
#include "MeshSize.h"
#include "NullSField.h"
#include "PList.h"
#include <stdio.h>
#include <math.h>


/*
  General Description:

  return 0 if any resulting shape is not acceptable w.r.t the given threshold
         1 if all resulting shape are acceptable

  the shape value is returned by reference in the last argument in case acceptable
  which is not defined in case not acceptable
*/


MeanRatio::MeanRatio(pSField f)
{
  mtol=M_getTolerance();
  setDefaultAcptValue();
  if( !f )
    { pSF=new NullSField(); flag=1; }
  else
    { pSF=f; flag=0; }
}


MeanRatio::~MeanRatio()
{
  if( flag )
    delete (NullSField *)pSF;
}


/* Given 3 points, compute the modified mean ratio of a triangle */
int MeanRatio::XYZ_shape(dArray xyz[3],pMSize pS[3],
		      dArray nor,double *shape)
{
  if( flag ) {
    // null size field
    if( ! XYZ_shape(xyz,pS[0],nor,shape) )
      { *shape=0; return 0; }
  }
  
  else 
  {
    double shp[3];
    int i;
    for(i=0;i<3;i++)
      if( ! XYZ_shape(xyz,pS[i],nor, &shp[i]) )
	{ *shape=0; return 0; }
    *shape = MIN(MIN(shp[0],shp[1]),shp[2]);
  }
  return 1;
}

int MeanRatio::XYZ_shape(dArray xyz[3],pMSize pS,
		      dArray nor,double *shape)
{
  double aSq,sumSq;
  
  /* get signed area square */
  aSq=pSF->areaSq(xyz,pS,nor);
  
  /* check if element is flipped */
  if( aSq<=mtol ) 
    { *shape=0; return(0); } 
    
  /* summation of edge length square wrt mesh size field*/
  sumSq=pSF->lengthSq(xyz[1],xyz[0],pS);
  sumSq += pSF->lengthSq(xyz[2],xyz[0],pS);
  sumSq += pSF->lengthSq(xyz[1],xyz[2],pS);
    
  /* computer modified mean ratio wrt mesh size field */
  *shape=48.*aSq/(sumSq*sumSq);
  
  /* check if element is acceptable */
  if( *shape<acptValue ) 
    return (0);
  return(1) ;
}


/* Given 4 points, compute the modified mean ratio of a tetrahedron */
int MeanRatio::XYZ_shape(dArray xyz[4],pMSize pS[4],double *shape)
{
  if( flag ) {
    // null size field
    if( ! XYZ_shape(xyz,pS[0],shape) )
      { *shape=0; return 0; } 
  }
  
  else{
    int i;
    double hmin=1e14;
    pMSize pSZ;

#if 0
    /* use average */
    double tmp;
    *shape=0;
    for(i=0;i<4;i++) {
      if( pS[i] ) {
	XYZ_shape(xyz,pS[i],&tmp);
	*shape += tmp;
      } 
      else {
	printf("mesh size field not defined at vertices\n");
	hmin=-1e14;
      }
    }
    if( hmin == 1e14 ) {
      *shape = *shape/4.0;
      return 1;
    }
#endif

    double sqrtDetMinv, MaxofSqrtDetMinv = 0.;

    /* use worst */
    for(i=0;i<4;i++) {
      if( pS[i] ) {
        /* sqrtDetMinv = 1/sqrt(det(M)) */
        sqrtDetMinv = pS[i]->size(0)*pS[i]->size(1)*pS[i]->size(2);
//      if( pS[i]->size(0) <  hmin )
//        { hmin=pS[i]->size(0); pSZ=pS[i]; }
        if(sqrtDetMinv > MaxofSqrtDetMinv)
          { MaxofSqrtDetMinv=sqrtDetMinv; pSZ=pS[i]; }
      }
    }
//     if( hmin != 1e14 ) {
    if( MaxofSqrtDetMinv != 0. ) {
      if( ! XYZ_shape(xyz,pSZ,shape) )
        return 0;
      return 1;
    }
    
    // could be analytical size field
    
    // compute the center
    double cent[3]={0.0, 0.0, 0.0};
    for(i=0; i<4; i++)
      { cent[0]+=xyz[i][0]; cent[1]+=xyz[i][1]; cent[2]+=xyz[i][2]; }
    cent[0]/=4.0; cent[1]/=4.0; cent[2]/=4.0;
    
    pSZ=pSF->getSize(cent, (pEntity)0);
    if( pSZ ) {
      if( ! XYZ_shape(xyz,pSZ,shape) )
	{ delete pSZ; return 0;} 
      delete pSZ;
      return 1;
    }
    
//    printf("WARNING: an element without size field (MeanRatio::XYZ_shape)\n");
    *shape=0;
    return 0;
  }
  return 1;
}

int MeanRatio::XYZ_shape(dArray xyz[4],pMSize pS,double *shape)
{
  double vol,sumSq;
/*  
  // added by dinesh - 06/07/05
  if( !XYZ_shapeMeasure( xyz, shape ) ) { 
    *shape = 0.0 ;
    return 0 ;
  }  
*/
  /* compute the volume in Euclidean space  =Jacob/6 */
  vol=pSF->volume(xyz,pS);

  /* check if element is valid */
  if ( vol < mtol ) 
    { *shape=0; return(0) ;}
  
  /* compute the summation of edge length square */
  sumSq=pSF->lengthSq(xyz[1],xyz[0],pS);
  sumSq += pSF->lengthSq(xyz[2],xyz[0],pS);
  sumSq += pSF->lengthSq(xyz[3],xyz[0],pS);
  sumSq += pSF->lengthSq(xyz[3],xyz[1],pS);
  sumSq += pSF->lengthSq(xyz[3],xyz[2],pS);
  sumSq += pSF->lengthSq(xyz[1],xyz[2],pS);

  /* compute modified mean ratio */
  *shape=15552.*vol*vol/(sumSq*sumSq*sumSq);

  /* check if element is acceptable */
  if( *shape<acptValue ) 
    { return (0);}
  return(1) ;
}


int MeanRatio::R_shape(pRegion rgn, double *shape)
{
  dArray rxyz[4];
  pMSize pS[4];
  pVertex vt;
  
  void *iter=0;
  int i=0;
  pPList verts=R_vertices(rgn,1);
  while( (vt=(pVertex)PList_next(verts,&iter)) ) {
    pS[i]=pSF->getSize(vt);
    V_coord(vt,rxyz[i++]);
  }  
  PList_delete(verts);

  return XYZ_shape(rxyz,pS,shape);  
}


int MeanRatio::F_shape(pFace face,dArray normal,double *shape)
{
  pVertex vt;
  dArray fxyz[3];
  pMSize pS[3];
  void *iter=0;
  int i=0;

  pPList fvts=F_vertices(face,1);
  while( vt=(pVertex)PList_next(fvts,&iter) ) {
    pS[i]=pSF->getSize(vt);
    V_coord(vt,fxyz[i++]);  
  }
  PList_delete(fvts);

  return XYZ_shape(fxyz,pS,normal,shape);  
}



