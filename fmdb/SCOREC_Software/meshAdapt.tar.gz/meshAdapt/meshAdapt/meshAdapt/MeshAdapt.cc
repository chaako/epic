/*
  codes for anisotropic mesh adaptation

                   12/10/03   last modification   -li
  MeshAdapt V1.0   06/09/99   Xiangrong Li
*/
#include "MeshAdapt.h"
#include "paraAdapt.h"
#include "templateUtil.h"
#include "EdgeCollapsMod.h"
#include "EdgeSwapMod.h"
#include "SplitCollapsMod.h"
#include "RegionCollapsMod.h"
#include "DSplitClpsMod.h"
#include "EdgeSplitMod.h"
#include "FaceSwapMod.h"
#include "AdaptUtil.h"
#include "meanRatio.h"
#include "Macros.h"
#include "fromMeshTools.h"
#include "NullSField.h"
#include "PWLinearSField.h"
#include "visUtil.h"
#include "PList.h"
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <math.h>
#include <vector>
#include "predLB.h"
#include "ParUtil.h"
#include <list>
#include <set>

#include "modeler.h"
#include "pbcOnGFace.h"
#include "pbcOnGEdge.h"
#include "FMDB.h"

#include "pmModel.h"

#include "BLUtil.h"

#include "MA_writeVTUFile.h"

using std::cout;
using std::cerr;
using std::endl;
using std::list; 
using std::set; 

#ifdef MVTK
#include "mvtk.h"
#endif

#ifdef AOMD_
#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#include "pbcOnGEdge.h"
#ifdef MA_PARALLEL
#include "SF_MigrationCallbacks.h"
#endif /* MA_PARALLEL */
#endif /* AOMD_ */

  extern "C" void trace_start(void);
  extern "C" void trace_stop(void);
  extern "C" void summary_start(void);
  extern "C" void summary_stop(void);

// extern pMeshDataId blEdgeTypeID, blFaceTypeID, blRegionTypeID;
extern pMeshDataId gcNormalTag;
int IsLowerLimitOnTotalThickness = 0;
pMeshDataId gcThicknessID;

pMeshMdl pMeshMdlInst;

meshAdapt::meshAdapt(pMeshMdl pMeshInstance, int iSizeFld, int iModelType)
  : pMeshInst(pMeshInstance), iSizeFldType(iSizeFld), model_type(iModelType), function_CB(0),
    SolutionID(NULL), nVar(0),
    CB_move(0), checkVolume(0),
//    upperLenSqBound(1.96), lowerLenSqBound(0.16), qualityThreshold(0.008),
//    upperLenSqBound(1.44), lowerLenSqBound(0.36), qualityThreshold(0.027),
    upperLenSqBound(UPPERLENSQBOUND), lowerLenSqBound(LOWERLENSQBOUND), qualityThreshold(QUALITYTHRESHOLD),
    iPreLBFlag(0), alphaFactor(0.64), BLAdaptFlag(0), 
    thicknessGradeFactorOnGC(THICKNESSGRADEFACTORONGC), thicknessGradeFactorAroundGC(THICKNESSGRADEFACTORAROUNDGC)
{
  FMDB_Mesh_GetPart(pMeshInst, 0, pmesh);

#ifndef CURVE
  M_setTolerance(pmesh);
#endif

  smoothed = MD_newMeshDataId("V_smoothed");

#ifdef CURVE
  _SplitEdge = MD_newMeshDataId("_Edge2Split");
  _SwapEdge = MD_newMeshDataId("_Edge2Swap");
  _ClpsEdge = MD_newMeshDataId("_Edge2Clps");

  _pCrvMesh = new curveMesh(pmesh, model_type, 0);

#endif


//  coarsenTested = MD_newMeshDataId("test_deref");

  isLowerLimitOnTotalThickness = 0;
  isFirstLayerThicknessSet = 0;
  isHmaxAlongThickness = 0;
//  applyThicknessAdaptationInBL = 0;
//  isAdjustGrowthDirectionForGCs = 0;
  firstLayerThicknessID = 0;
  thicknessAdaptExecuted = 0;

  /// Set a default number of iterations
  iNumIt = 10;

  /// By default there is no analytical function
  SizeFldFunc = 0;

  if (iSizeFldType == TagDriven)
  {
    pSizeField = 0;
    nullFieldFlag=1;
    iTagDrvnRef = 1;
  }
  else
  {
    pSizeField = new PWLsfield(pmesh);
    nullFieldFlag=0;
    if (iSizeFldType == SF_TagDriven)
      iTagDrvnRef = 1;
    else
      iTagDrvnRef = 0;
  }

  if( model_type ) {
    pSnapList=new std::vector< std::pair<pVertex,double *> > ;
    pRef=new meshTemplate(pmesh, pSizeField, model_type, pSnapList);

    pSnap=new meshSnap(pmesh, pSizeField);
    switch(model_type) {
    case 1:
      pSnap->setModelType(NOPARAM);
      break;
    case 2:
      pSnap->setModelType(PARAM);
      break;
    default:
      adaptUtil::Error("incorrect model type");
    }
  } 
  else 
    pRef=new meshTemplate(pmesh, pSizeField, 0, 0); 

  // declare measures
  shpMeasure=new MeanRatio(pSizeField);
  result=new evalResults();

  if( !pSizeField )
    pSizeField=new NullSField(); 


  pGModel model = M_model(pmesh);
  // the pbc tag
  if(model) {    //  in case that no geom model was loaded.  QLU, Sep 21, 2010
    if( GM_pbc(model) ) {
      pbcId = MD_newMeshDataId("pbc");
    }
  }
 
  /// TRY TO FIND SOMETHING ELSE EXCEPT FOR COLLECTIVE CALL!
  int numBL = M_getMaxNum(M_getNumBLs(pmesh));
  if (numBL)
  {
    BLAdaptFlag = 1;
    BLTetrahedronization = 0;
    dBLAspectRatioLimit = 0.64;
  }

  /// Identify if the mesh has pyramids
  iMeshWithPyr = 0;
  pRegion pRegionRgn;
  RIter rit = M_regionIter(pmesh);
  while(pRegionRgn = RIter_next(rit))
  {
    if (pRegionRgn->getType() == PYRAMID)
    {
      iMeshWithPyr = 1;
      break;
    }
  }
  RIter_delete(rit);
  iMeshWithPyr = M_getMaxNum(iMeshWithPyr);
}


meshAdapt::meshAdapt(pMesh m, pSField mf, int s, int t)
  : pmesh(m), pSizeField(mf), model_type(s), iTagDrvnRef(t), function_CB(0),
    SolutionID(NULL), nVar(0),
    CB_move(0), checkVolume(0),
//    upperLenSqBound(1.96), lowerLenSqBound(0.16), qualityThreshold(0.008),
//    upperLenSqBound(1.44), lowerLenSqBound(0.36), qualityThreshold(0.027),
    upperLenSqBound(UPPERLENSQBOUND), lowerLenSqBound(LOWERLENSQBOUND), qualityThreshold(QUALITYTHRESHOLD),
    iPreLBFlag(0), alphaFactor(0.64), BLAdaptFlag(0),
    thicknessGradeFactorOnGC(THICKNESSGRADEFACTORONGC), thicknessGradeFactorAroundGC(THICKNESSGRADEFACTORAROUNDGC)
{   
#ifndef CURVE
  M_setTolerance(pmesh);
#endif

  smoothed = MD_newMeshDataId("V_smoothed");
  
#ifdef CURVE
  _SplitEdge = MD_newMeshDataId("_Edge2Split");
  _SwapEdge = MD_newMeshDataId("_Edge2Swap");
  _ClpsEdge = MD_newMeshDataId("_Edge2Clps");
  
  _pCrvMesh = new curveMesh(pmesh, model_type, 0);
  
#endif


//  coarsenTested = MD_newMeshDataId("test_deref");

  isLowerLimitOnTotalThickness = 0;
  isFirstLayerThicknessSet = 0;
  isHmaxAlongThickness = 0;
//  applyThicknessAdaptationInBL = 0;
//  isAdjustGrowthDirectionForGCs = 0;
  firstLayerThicknessID = 0;
  thicknessAdaptExecuted = 0;

  /// Set a default number of iterations
  iNumIt = 10;

  /// By default there is no analytical function
  SizeFldFunc = 0;

  if( model_type ) {
    pSnapList=new std::vector< std::pair<pVertex,double *> > ;
    pRef=new meshTemplate(pmesh,mf,model_type,pSnapList);

    pSnap=new meshSnap(pmesh,mf);
    switch(model_type) {
    case 1:
      pSnap->setModelType(NOPARAM);
      break;
    case 2:
      pSnap->setModelType(PARAM);
      break;
    default:
      adaptUtil::Error("incorrect model type");
    }
  }
  else
    pRef=new meshTemplate(pmesh,mf,0,0);

  if( !pSizeField )
    { pSizeField=new NullSField(); nullFieldFlag=1; }
  else
    nullFieldFlag=0;

  // declare measures
  shpMeasure=new MeanRatio(pSizeField);
  result=new evalResults();

  pGModel model = M_model(pmesh);
  // the pbc tag
  if(model) {    //  in case that no geom model was loaded.  QLU, Sep 21, 2010
    if( GM_pbc(model) ) {
      pbcId = MD_newMeshDataId("pbc");
    }
  }

  /// TRY TO FIND SOMETHING ELSE EXCEPT FOR COLLECTIVE CALL!
  int numBL = M_getMaxNum(M_getNumBLs(pmesh));
  if (numBL)
  {
    BLAdaptFlag = 1;
    BLTetrahedronization = 0;
    dBLAspectRatioLimit = 0.64;
  }

  /// Identify if the mesh has pyramids
  iMeshWithPyr = 0;
  pRegion pRegionRgn;
  RIter rit = M_regionIter(pmesh);
  while(pRegionRgn = RIter_next(rit))
  {
    if (pRegionRgn->getType() == PYRAMID)
    {
      iMeshWithPyr = 1;
      break;
    }
  }
  RIter_delete(rit);
  iMeshWithPyr = M_getMaxNum(iMeshWithPyr);
}


meshAdapt::~meshAdapt()
{
/*
  pEdge edge;
  int value;
  EIter eiter=M_edgeIter(pmesh);
  while( edge=EIter_next(eiter) ) { 
    if( EN_getDataInt((pEntity)edge,coarsenTested,&value) ) 
      EN_deleteData((pEntity)edge,coarsenTested);
  } 
  EIter_delete(eiter);
  MD_deleteMeshDataId(coarsenTested);
*/
  MD_deleteMeshDataId(smoothed);

#ifdef CURVE
  MD_deleteMeshDataId(_SwapEdge);
  MD_deleteMeshDataId(_SplitEdge);
  MD_deleteMeshDataId(_ClpsEdge);

  delete _pCrvMesh;

#endif

  delete pRef;
  delete shpMeasure;
  delete result;
  if( nullFieldFlag )
    delete (NullSField *)pSizeField;
  else
    delete (PWLsfield *)pSizeField;
  if( model_type ) {
    delete pSnap;  // this will also delete pSnapList
    delete pSnapList;
  }

}


void meshAdapt::setCallback( CBFunction CB, void * userData)
{ 
  function_CB=CB;
  userData_CB=userData;
  pRef->setCallback(CB,userData);
  if( model_type )
    pSnap->setCallback(CB,userData);
}

void meshAdapt::setCallback( CBFunc_move CB, void * userData)
{ 
  CB_move=CB;
  userData_CB_move=userData;
  if( model_type )
    pSnap->setCallback(CB,userData);
}


void meshAdapt::setAdaptLevel(pEdge ed,int level)
{
//  if( iTagDrvnRef ) 
    pRef->setRefineLevel(ed,level);
//  else
//    cerr<<"you are not allowed to tag mesh edges for size-based adaptation"<<endl;
  
  return;
}

int meshAdapt::getAdaptLevel(pEdge ed)
{
//  if( iTagDrvnRef )
    return pRef->getRefineLevel(ed);
//  else
//    cerr<<"you are not allowed to tag mesh edges for size-based adaptation"<<endl;

//  return 0;
}

/* constrain a mesh entity and its downward from all mesh modifications */
void meshAdapt::setConstraint(pEntity e)
{   
  EN_constrainAll(e);
  
  switch (EN_type(e)) {
  case Tedge:
    EN_constrainAll( (pEntity)E_vertex((pEdge)e,0) );
    EN_constrainAll( (pEntity)E_vertex((pEdge)e,1) );
    break;
  case Tface:
    setConstraint( (pEntity)F_edge((pFace)e,0) );
    setConstraint( (pEntity)F_edge((pFace)e,1) );
    setConstraint( (pEntity)F_edge((pFace)e,2) );
    break;
  case Tregion:
    setConstraint( (pEntity)R_face((pRegion)e,0) );
    setConstraint( (pEntity)R_face((pRegion)e,1) );
    setConstraint( (pEntity)R_face((pRegion)e,2) );
    setConstraint( (pEntity)R_face((pRegion)e,3) );
    break;    
  }
  return;
}

/* constrain a model entity and its downward */
void meshAdapt::setConstraint(pGEntity e) 
{
  int gtype=GEN_type(e);

  GEN_constrainAll(e);

  if( gtype!=Gvertex )
    {
      pGEntity gent;
      pPList ents;
      void *iter=0;

      switch (gtype) {
      case Gedge:
	ents=GE_vertices((pGEdge)e);
	break;
      case Gface:
	ents=GF_edges((pGFace)e);
	break;
      case Gregion:
	ents=GR_faces((pGRegion)e);
	break;    
      }
      
      while( (gent=(pGEntity)PList_next(ents,&iter)) ) 
	setConstraint(gent);
     
      PList_delete(ents);
    }

  return; 
}

void meshAdapt::setMaxLenRatioSq(double uppperSq)
{
  upperLenSqBound=uppperSq;
  lowerLenSqBound=0.16*uppperSq;
  if( model_type ) 
    pSnap->setMaxLenRatioSq(upperLenSqBound);
}


void meshAdapt::SetFirstLayerThicknessFlag(int iFirstLayerThicknessFlag) 
{
  isFirstLayerThicknessSet = iFirstLayerThicknessFlag;
  firstLayerThicknessID = MD_lookupMeshDataId("First Layer Thickness");
}

void meshAdapt::SetFirstLayerThickness(pVertex pVertexVtx, double dFirstLayerThickness) 
{
  if(!V_isOriginatingNode(pVertexVtx)) 
  {
    cout<<"\nError in meshAdapt::setFirstLayerThickness()..."<<endl;
    cout<<"vertex is NOT an originating node"<<endl;
    exit(0);
  }

  if(!isFirstLayerThicknessSet || !firstLayerThicknessID) 
  {
    cout<<"\nError in meshAdapt::setFirstLayerThickness()..."<<endl;
    cout<<"flag and/or ID for first layer thickness NOT set"<<endl;
    exit(0);
  }

  double val;
  if(EN_getDataDbl((pEntity)pVertexVtx, firstLayerThicknessID, &val)) 
  {
    cout<<"\nError in meshAdapt::setFirstLayerThickness()..."<<endl;
    cout<<"first layer thickness for vertex is already set"<<endl;
    exit(0);
  }

  EN_attachDataDbl((pEntity)pVertexVtx, firstLayerThicknessID, dFirstLayerThickness);
}


int meshAdapt::iCheckGetAdaptLvl(pEdge pEdgeEdge, double dLimit)
{
  if(getAdaptLevel(pEdgeEdge))
    return 1;
  if (E_typeInBL(pEdgeEdge))
    return 0;
 
  if (dLimit == 0.)
    return 0;

  double lSq=pSizeField->lengthSq(pEdgeEdge);
  if( lSq > dLimit )    
  {
    setAdaptLevel(pEdgeEdge, 1);
    return 1;
  }
  else
    return 0;
}


int meshAdapt::CheckAddTemplate(pEdge pEdgeInitEdge, pEdge pEdgeOppEdge, pFace pFaceFace, pFace pFaceOppFace, pRegion pRegionRgn)
{
  pVertex pVertexVtx;
  pEdge pEdgeEdge;
  for (int iEdge = 0; iEdge < 3; ++iEdge)
  {
    pEdgeEdge = F_edge(pFaceFace, iEdge);
    if(pEdgeEdge == pEdgeInitEdge)
    {
      pVertexVtx = F_vertex(pFaceFace, iEdge);
      break;
    }
  }

  pPList plist = R_edges(pRegionRgn, 1);
  int iEdgeNum;
  /// Define which edge from quad face is in closure of pFaceFace and switch to the edge following edge
  for (int iEdge = 0; iEdge < 4; ++iEdge)
  {
    pEdgeEdge = (pEdge)PList_item(plist, iEdge);
    if (F_inClosure(pFaceFace, pEdgeEdge))
    {
      iEdgeNum = (iEdge+1)%4;
      break;
    }
  }

  /// Define which edge the vertex belongs to, then if it's on either of the edges of the quad face - take the other vertex of the edge
  int iInd = 0;
  for (int iEdge = 0; iEdge < 3; iEdge+=2)
  {
    iEdgeNum = (iEdgeNum+iEdge)%4;
    pEdgeEdge = (pEdge)PList_item(plist, iEdgeNum);
    if (E_inClosure(pEdgeEdge, pVertexVtx))
    {
      iInd = 1;
      break;
    }
  }
  if (iInd)
    pVertexVtx = E_otherVertex(pEdgeEdge, pVertexVtx);

  /// Check if the vertex matches the proposed vertex. If not, swap the order of the pFaceOppFace
  for (int iEdge = 0; iEdge < 3; ++iEdge)
  {
    pEdgeEdge = F_edge(pFaceOppFace, iEdge);
    if(pEdgeEdge == pEdgeOppEdge)
    {
      if(pVertexVtx != F_vertex(pFaceOppFace, iEdge))
        return 1;
      else
        return 0;
    }
  }
}


int meshAdapt::tagAdditionalEdgesForPyrTemplates(double dLimit)
{
  int iCountAddPyr = 0;
  pEdge pEdgeEdge;
  pRegion pRegionRgn;
  int iNoTagEdgeInd[4], iNumTagEdge, iNumNoTagEdge;
  int iLocalCountAddPyr;
  std::list<pEntity> entities_to_update;
  std::list<pEdge>::iterator ListIt;

#ifdef MA_PARALLEL
  M_unifyTaggedEntities(pRef->getRefineTag(), pRef->getRefBLEdgesList());
#endif
  for (ListIt = pRef->getRefBLEdgesList()->begin(); ListIt != pRef->getRefBLEdgesList()->end(); ListIt++)
  {
    pEdgeEdge = *ListIt;
    if (EN_levelInBL(pEdgeEdge) == 0)
      pRef->tagBLEdges(pEdgeEdge);
  }


  do{
  iLocalCountAddPyr = 0;
  int iAddCount[4] = {0, 0, 0, 0};
  RIter rit = M_regionIter(pmesh);
  while(pRegionRgn = RIter_next(rit))
  {
    if (pRegionRgn->getType() != PYRAMID)
      continue;

    iNumTagEdge = 0;
    iNumNoTagEdge = 0;
    pPList plist = R_edges(pRegionRgn, 1);
    for (int iEdge = 4; iEdge < 8; ++iEdge)
    {
      pEdgeEdge = (pEdge)PList_item(plist, iEdge);
      if (iCheckGetAdaptLvl(pEdgeEdge, dLimit))
        iNumTagEdge++;
      else
      {
        iNoTagEdgeInd[iNumNoTagEdge] = iEdge;
        iNumNoTagEdge++;
      }
    }

    /// Currently can't deal with templates number 3 and 13, tag the 4th edge
    if (iNumTagEdge == 3)
    {
      pEdgeEdge = (pEdge)PList_item(plist, iNoTagEdgeInd[0]);
      if (EN_onCB(pEdgeEdge))
        entities_to_update.push_back(pEdgeEdge);
      if (E_typeInBL(pEdgeEdge))
        pRef->tagBLEdges(pEdgeEdge);
      else
        setAdaptLevel(pEdgeEdge, 1);
      iLocalCountAddPyr++;
      iAddCount[0]++;
      iNumTagEdge++;
    }

    /// Can't also deal with the case when 2 opposite non-quad-face edges are marked and 2 quad edges are tagged
    if (iNumTagEdge == 2)
    {
      for (int iEdge = 0; iEdge < 2; ++iEdge)
      {
        pEdgeEdge = (pEdge)PList_item(plist, iEdge);
        if (iCheckGetAdaptLvl(pEdgeEdge, dLimit) && (iNoTagEdgeInd[1] - iNoTagEdgeInd[0] == 2))
        {
          for (int iEdgeIt = 0; iEdgeIt < 2; ++iEdgeIt)
          {
            pEdgeEdge = (pEdge)PList_item(plist, iNoTagEdgeInd[iEdgeIt]);
            if (EN_onCB(pEdgeEdge))
              entities_to_update.push_back(pEdgeEdge);
            if (E_typeInBL(pEdgeEdge))
              pRef->tagBLEdges(pEdgeEdge);
            else            
              setAdaptLevel(pEdgeEdge, 1);
          }
//          pEdgeEdge = (pEdge)PList_item(plist, iNoTagEdgeInd[1]);
//          setAdaptLevel(pEdgeEdge, 1);
          iLocalCountAddPyr++;
          iAddCount[1]++;
          iNumTagEdge = 4;
          break;
        }
      }
    }

    /// See if we need to tag till the full configuration in order to deal with opposite faces having 2 edges tagged in a different direction
    /// Before we were ChDir of one of the face, didn't really work
    int iBLEdgeTag = 0;
    if (iNumTagEdge == 2 || iNumTagEdge == 4)
    {
      for (int iEdge = 0; iEdge < 2; ++iEdge)
      {
        pEdgeEdge = (pEdge)PList_item(plist, iEdge);
        if (iCheckGetAdaptLvl(pEdgeEdge, dLimit))
        {
          iBLEdgeTag = 1;
          break;
        }
      }
    }

    if (iNumTagEdge == 2 && iBLEdgeTag)
    {
      int iEdgeInd[4][7] = {{1, 4, 5, 6, 7, 2, 4}, {1, 6, 7, 5, 4, 2, 4}, {0, 5, 6, 4, 7, 1, 3}, {0, 7, 4, 5, 6, 1, 3}};
      for (int iIt = 0; iIt < 4; ++iIt)
      {
        int iTag = 0;
        for (int iEdge = 0; iEdge < 3; ++iEdge)
        {
          if (iCheckGetAdaptLvl((pEdge)PList_item(plist, iEdgeInd[iIt][iEdge]), dLimit))
            iTag++;
        }
        if (iTag == 3)
        {
          pEdge pEdgeEdges[2] = {(pEdge)PList_item(plist, iEdgeInd[iIt][3]), (pEdge)PList_item(plist, iEdgeInd[iIt][4])};
          pFace pFaceFaces[2] = {R_face(pRegionRgn, iEdgeInd[iIt][5]), R_face(pRegionRgn, iEdgeInd[iIt][6])};
          if (CheckAddTemplate(pEdgeEdges[0], pEdgeEdges[1], pFaceFaces[0], pFaceFaces[1], pRegionRgn))
          {
            for (int iEdge = 0; iEdge < 2; ++iEdge)
            {
              if (EN_onCB(pEdgeEdges[iEdge]))
                entities_to_update.push_back(pEdgeEdges[iEdge]);
              if (E_typeInBL(pEdgeEdges[iEdge]))
                pRef->tagBLEdges(pEdgeEdges[iEdge]);
              else
                setAdaptLevel(pEdgeEdges[iEdge], 1);
            }
//            setAdaptLevel(pEdgeEdges[1], 1);
            iLocalCountAddPyr++;
            iAddCount[2]++;
            break;
          }
        }
      }
    }
    else if (iNumTagEdge == 4 && !iBLEdgeTag)
    {
      /// Look for not tagged edges
      for (int iFace = 1; iFace < 3; ++iFace)
      {
        pFace pFaceFaces[2];
        pEdge pEdgeEdges[2];
        for (int iFaceIt = 0; iFaceIt < 2; ++iFaceIt)
        {
          pFaceFaces[iFaceIt] = R_face(pRegionRgn, iFace + 2*iFaceIt);
          for (int iEdge = 0; iEdge < 3; ++iEdge)
          {
            pEdgeEdges[iFaceIt] = F_edge(pFaceFaces[iFaceIt], iEdge);
            if (E_typeInBL(pEdgeEdges[iFaceIt]) && !getAdaptLevel(pEdgeEdges[iFaceIt]))
              break;
          }
        }
        if (CheckAddTemplate(pEdgeEdges[0], pEdgeEdges[1], pFaceFaces[0], pFaceFaces[1], pRegionRgn))
        {
          if (E_typeInBL(pEdgeEdges[0]) == eGROWTH)
          {
            pFaceFaces[0] = R_face(pRegionRgn, 0);
            for (int iEdge = 0; iEdge < 2; ++iEdge)
            {
              pEdgeEdges[0] = F_edge(pFaceFaces[0], iEdge);
              if (E_typeInBL(pEdgeEdges[0]) == eLAYER)
              {
                pEdgeEdges[1] = F_edge(pFaceFaces[0], iEdge+2);
                break;
              }
            }
          }

//          pEdge pEdgeMaxLvlEdge = pEdgeEdges[0];
//          if (EN_levelInBL(pEdgeMaxLvlEdge) < EN_levelInBL(pEdgeEdges[1]))
//            pEdgeMaxLvlEdge = pEdgeEdges[1];
          if (EN_onCB(pEdgeEdges[0]))
            entities_to_update.push_back(pEdgeEdges[0]);
          if(EN_onCB(pEdgeEdges[1]))
            entities_to_update.push_back(pEdgeEdges[1]);
          
//          pRef->tagBLEdges(pEdgeMaxLvlEdge);
          pRef->tagBLEdges(pEdgeEdges[0]);
          iLocalCountAddPyr++;
          iAddCount[3]++;
          break;
        }
      }
    }

    PList_delete(plist);
  }
  RIter_delete(rit);

//  int iListSize = entities_to_update.size();

  /// Should know exactly which entities are tagged and which are not after communication to properly manage them
  /// Communicate layer edges across part boundaries
#ifdef MA_PARALLEL
  if (SCUTIL_CommSize() > 1)
  {
    IPComMan *CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int num_sent = 0, num_recvd = 0;
    CM->set_fixed_msg_size(sizeof(pEdge));
    pEdge* msg_send = (pEdge*)CM->alloc_msg(sizeof(pEdge));

    for (ListIt = entities_to_update.begin(); ListIt != entities_to_update.end(); ++ListIt)
    {
      pEdgeEdge = *ListIt;
      std::vector<std::pair<int, pMeshEnt> > VecRemCpy;
      FMDB_Ent_GetAllRmt(pEdgeEdge, VecRemCpy);
      for (int iRC = 0; iRC < VecRemCpy.size(); ++iRC)
      {
        *msg_send = VecRemCpy[iRC].second;
        CM->send(VecRemCpy[iRC].first, (void*)msg_send);
      }
    }
    CM->free_msg(msg_send);
    CM->finalize_send();

    void* msg_recv;
    int pid_from;

    // recieve phase
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      pEdgeEdge = *(pEdge*)msg_recv;
      if (E_typeInBL(pEdgeEdge))
      {
        if (pRef->tagBLEdges(pEdgeEdge))
          iLocalCountAddPyr++;
      }
      else
      {
        if (pRef->setRefineLevel(pEdgeEdge, 1))
          iLocalCountAddPyr++;
      }
      CM->free_msg(msg_recv);
    }

    entities_to_update.clear();

    /// Some stacks might propagate more BL edges to be refined to regions which are detached from their stacks
    M_unifyTaggedEntities(pRef->getRefineTag(), pRef->getRefBLEdgesList());
    /// Some edges of the stack higher than the one communicating edges needed for refinement might not be tagged so need to check for all the stacks again
    for (ListIt = pRef->getRefBLEdgesList()->begin(); ListIt != pRef->getRefBLEdgesList()->end(); ListIt++)
    {
      pEdgeEdge = *ListIt;
      if (EN_levelInBL(pEdgeEdge) == 0)
      {
        if(pRef->tagBLEdges(pEdgeEdge))
          iLocalCountAddPyr++;
      }
    }

    /// Same about non-BL edges
    int iListSize = pRef->getRefEdgesList()->size();
    M_unifyTaggedEntities(pRef->getRefineTag(), pRef->getRefEdgesList());
    iListSize = pRef->getRefEdgesList()->size() - iListSize;
    if (iListSize > 0)
      iLocalCountAddPyr++;
  }
#endif

  iCountAddPyr += iLocalCountAddPyr;
/*
  if (iLocalCountAddPyr)
  {
    printf("Tagged %d pyramids to match the templates\n", iLocalCountAddPyr);
    for (int iIt = 0; iIt < 4; ++iIt)
      printf("Matching scenario [%d]: tag %d pyramids additionally\n", iIt, iAddCount[iIt]);
  }
*/
  }
  while (P_getMaxInt(iLocalCountAddPyr));
  
#ifdef DEBUG
  printf("[%d]: Tagged %d pyramids additionall to match the implemented templates\n", P_pid(), iCountAddPyr);  
#endif

  return iCountAddPyr;
}


int meshAdapt::tagEdgesByField(double tSq)
{
  pEdge edge;
  double lSq;
  int nref=0;

  // tag/untag mesh edges for refinement in terms of values at vertices
  EIter eit=M_edgeIter(pmesh);
  while( edge=EIter_next(eit) ) 
  {
    if (E_typeInBL(edge))
      continue;

    if (getAdaptLevel(edge))
      continue;
    lSq=pSizeField->lengthSq(edge);
    if( lSq>tSq ) 
    {
      if(pRef->setRefineLevel(edge,1) )
	nref++;
    }
//    else
//      pRef->setRefineLevel(edge,0);
  }
  EIter_delete(eit);
#ifdef DEBUG
  adaptUtil::Info(nref,"edges are tagged to be refined");
#endif
  return nref;
}


/* set up the paired edges based on periodic model boundary entities  */
void meshAdapt::setupEdgesForPBC()
{

  pGModel model = M_model(pmesh);
  pEdge edge;
  
  return;
}


int meshAdapt::tagEdgesForPBC()
{
  pGModel model = M_model(pmesh);
  int flag = GM_pbc(model);
  if (flag==0)
    return 0;
  
  pEdge srcEd, tgtEd;
  //  pVertex srcVt, tgtVt;
  int nref=0, ok1, ok2;
  int tmpflag=0; 

  list<std::pair<int, pEntity> > mlist; 
  list<std::pair<int, pEntity> >::iterator mlistIter;

  // Traverse all of the pbce
  PbcOnGEIter pbceiter = GM_pbcOnGEdgeIter(model);
  pbcOnGEdge *pbcge;
  while(pbcge = PbcOnGEIter_next(pbceiter)) {
    std::vector<pGEdge> ge;
    pbcge->get_pbcEdges(ge);
   
    std::vector<pGEdge>::iterator geiter = ge.begin(), geitend = ge.end();
    while(geiter != geitend) {
      EIter eiter = M_classifiedEdgeIter(pmesh, *geiter, 0);
      while (srcEd = EIter_next(eiter)){
	EN_getMatchEnts(srcEd, 0, mlist);
        for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
        {
          tgtEd = mlistIter->second;
	  ok1 = pRef->getRefineLevel(tgtEd);
	  if(ok1) {
	    tmpflag=1; 
	    break; 
	  }
	}
	 
	if(tmpflag==1){
          for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
          {
            tgtEd = mlistIter->second;
            if( !pRef->getRefineLevel(tgtEd) ){
              pRef->setRefineLevel(tgtEd, 1);
              nref ++;
            }
	  }
	}
	tmpflag=0;              // remember to init tmpflag=0
      }
      EIter_delete(eiter);
      geiter ++;
    }
  }
  PbcOnGEIter_delete(pbceiter);
  
  std::set<pFace> pbcfaces; 

  // Traverse all of the pbcf
  PbcOnGFIter pbcfiter = GM_pbcOnGFaceIter(model);
  pbcOnGFace *pbcgf;
  while(pbcgf = PbcOnGFIter_next(pbcfiter)) {
    std::vector<pGFace> gf; 
    pbcgf->get_pbcFaces(gf);
    
    std::vector<pGFace>::iterator gfiter = gf.begin(), gfitend = gf.end();

    while(gfiter != gfitend) {
      EIter eiter = M_classifiedEdgeIter(pmesh, *gfiter, 0);
      while (srcEd = EIter_next(eiter)){
        EN_getMatchEnts(srcEd, 0, mlist);
        for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
        {
          tgtEd = mlistIter->second;
	   ok1 = pRef->getRefineLevel(tgtEd);
	   if(ok1) {
	     tmpflag=1; 
	     break; 
	   }
	 }
	 
	 if(tmpflag==1){
           for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
           {
             tgtEd = mlistIter->second;
             if( !pRef->getRefineLevel(tgtEd) ){
               pRef->setRefineLevel(tgtEd, 1);
               nref ++;
             }
	   }
	 }
	 tmpflag=0;              // remember to init tmpflag=0
      }
      EIter_delete(eiter);

      FIter fiter = M_classifiedFaceIter(pmesh, *gfiter, 0);
      pFace face; 
      while(face=FIter_next(fiter)) {
	pbcfaces.insert(face); 
      }
      FIter_delete(fiter); 
      
      gfiter ++;
    }
  }
  PbcOnGFIter_delete(pbcfiter);
    
  // Traverse all of the pbcf, if #marked_edges_on_one_face==2, mark the third edge. 
  std::set<pFace>::iterator iter; 
  int stopflag=0;       // flag to stop the process of marking the third edge  
  
  while(!stopflag) {
    stopflag=1; 
    for(iter=pbcfaces.begin(); iter!=pbcfaces.end(); iter++) {
      pFace face=*iter; 
      pEdge edge; 
      int ok[4];
      int icount=0;
      int ne = F_numEdges(face); 
      for(int i=0; i<ne; i++) {
	edge = F_edge(face, i);
	ok[i]=pRef->getRefineLevel(edge); 
	if(ok[i])
	  icount++; 
      }
      
      if(icount==2) { 
	stopflag=0; 
	for(int i=0; i<ne; i++) 
	  if(!ok[i]){
	    edge = F_edge(face, i); 
	    if(EN_isMatchEnt(edge)) {
	      // If one edge is marked, mark all its matched edges if it has
              EN_getMatchEnts(srcEd, 0, mlist);
              for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
              {
                tgtEd = mlistIter->second;
                if( !pRef->getRefineLevel(tgtEd) ){
                  pRef->setRefineLevel(tgtEd, 1);
                  nref ++;
                }
	      }
	    }
	    else if( !pRef->getRefineLevel(tgtEd) ){
                pRef->setRefineLevel(tgtEd, 1);
                nref ++;
	    }
	  }	
      } 
    }
  }
  
  adaptUtil::Info(nref,"edges on pbc are tagged to be refined");
  return nref;
}

void meshAdapt::printoutPBC()
{
  pVertex srcVt, tgtVt;
  double xyz[2][3];
  std::vector<pVertex>::iterator viter = srcVts.begin(), viend = srcVts.end();
  
  for( ; viter != viend; ) {
    srcVt = *viter;
    EN_getDataPtr((pEntity)srcVt, pbcId, (void**)&tgtVt);

    V_coord(srcVt, xyz[0]);
    V_coord(tgtVt, xyz[1]);

    printf("%.9lf %.9lf %.9lf \n", xyz[0][0], xyz[0][1], xyz[0][2]);
    printf("%.9lf %.9lf %.9lf \n\n", xyz[1][0], xyz[1][1], xyz[1][2]);
    
    viter++;
   }
  
  return;
}


void meshAdapt::setSnap(void)
{
  std::vector< std::pair<pVertex,double* > >::iterator pairIt;
  for(pairIt=pSnapList->begin();pairIt!=pSnapList->end();++pairIt) 
    pSnap->append((*pairIt).first,(*pairIt).second );

  pSnapList->clear();
}


void meshAdapt::clearSnap(void)
{
  std::vector< std::pair<pVertex,double* > >::iterator pairIt;
  for(pairIt=pSnapList->begin();pairIt!=pSnapList->end();++pairIt)
    delete [] pairIt->second;

  pSnapList->clear();
}


void Mesh_CheckRgnVol(pMesh pmesh)
{
  pRegion pRegionRgn;
  RIter rit=M_regionIter(pmesh);
  while(pRegionRgn = RIter_next(rit))
  {
    if ( R_Volume2(pRegionRgn) <= 1e-15)
      printf("ERROR! The region volume is <= 0\n");
  }
  RIter_delete(rit);
}


void writeVTUSizes(pPart pmesh, pSField pSizeField)
{
  pMeshDataId nodalSizeID, nodalDirectionID;
  pVertex vtx;
  pMSize pS;
  double *e;
  VIter vit = M_vertexIter(pmesh);
  while(vtx = VIter_next(vit)) 
  {
    pS = pSizeField->getSize((pVertex)vtx);

    double *h = new double[3];
    double *dir = new double[9];
    for(int i=0; i<3; i++) 
    {
      e = pS->eigenvector(i);
      h[i] = pS->size(i);
      for(int j=0; j<3; j++)
        dir[i*3+j] = e[j];
    }

    EN_attachDataPtr( (pEntity)vtx, nodalSizeID, (void *)h);
    EN_getDataPtr((pEntity)vtx, nodalDirectionID, (void**)&dir);
  }

  VIter_delete(vit);  

  MA_writeVTUFile(pmesh, "nodalSize", nodalSizeID, 3);
  MA_writeVTUFile(pmesh, "nodalDir", nodalDirectionID, 9);
}


#ifdef MA_PARALLEL
void meshAdapt::run(int niter,        // specify the maximum number of iterations 
		    int flag,         // indicate if a size field function call is available
		    adaptSFunc sizefd)  // the size field function call
{
  
//  SF_MigrationCallbacks sfLB(pSizeField);
  
  /// This is the callback for BLAdapt unless automatic movement of attachable data is implemented
  BL_MigrationCallbacks sfLB(pSizeField);
  if(nVar){
      sfLB.SF_setSolutionID(SolutionID);
      sfLB.SF_setnVar(nVar);
  }

  iNumIt = niter;
  run(iNumIt, flag, sizefd, sfLB);  // the size field function call
}
#endif

void meshAdapt::run(int niter,        // specify the maximum number of iterations 
		    int flag,         // indicate if a size field function call is available
		    adaptSFunc sizefd // the size field function call
#ifdef MA_PARALLEL     
		    , pmMigrationCallbacks& userLB  
#endif
                    ) 
{
  if (BLAdaptFlag)
  {
    gcThicknessID = MD_newMeshDataId("gc thickness adjusted");
    layerFaceNormalChangeID = MD_newMeshDataId("layer face normal change ID");
    metricDecompositionID = MD_newMeshDataId("metric decomposed");
    gcNormalTag = MD_lookupMeshDataId("Vector Normal");

    /// This is needed for snapping. Tags are allocated in BL_MigrationCallbacks.
    notBLSnapID = MD_lookupMeshDataId("bl not snapped");
    topNodeMoveID = MD_lookupMeshDataId("top node move ID");
    moveDirID = MD_lookupMeshDataId("move dir ID");
    moveVectorID = MD_lookupMeshDataId("move vector ID");
    updateGCOnModelBdryID = MD_lookupMeshDataId("update GC on model bdry. after snap");
  }

  pMeshMdlInst = pMeshInst;

  if( flag ) 
    sizefd(pmesh,pSizeField,0);

  if (BLAdaptFlag)
  {
    /// Tetrahedralize initial pyramids sitting in the unstructured portion of the domain
    pRef->Mesh_TetrahedralizePyramids();
     
    // this will snap the nodes (or tag the nodes, if snap not possible)
    // of the initial/input mesh (that may be a previously adapted mesh with unsnapped nodes)
    // decompose mesh metric field after initial snapping
    // (initial/input mesh may be a previously adapted mesh with unsnapped nodes)
    if(model_type && iSizeFldType != TagDriven)
    {
//      initSnapBLNodes(userLB);
      decomposeMetricField();
    }
  }

#ifdef MA_PARALLEL
  if (iPreLBFlag)
  {
    double t1=ParUtil::Instance()->wTime();

    PredLB(pMeshInst, pSizeField, SolutionID, nVar);

    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    double t2=ParUtil::Instance()->wTime();

    if (P_pid()==0)
    {
      std::cout<<"\n# pred_load_balance = "<<P_size()<<"\n";
      std::cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
    }
  }
#endif

  if (iPreLBFlag)
  {
//    trace_start();
//    summary_start();
  }

  int num, numBL=0;
  double accumulateT_ref, accumulateT_snap, accumulateT_others;
  double accumulateT_BLref, accumulateT_BLsnap, accumulateT_BLothers;
  myTimer tt;
  tt.reset();

  std::vector< std::pair<pVertex,double *> > VecSnapListNonBLNodes;
  std::vector< std::pair<pVertex,double *> >::iterator ItVecSnapList;

  /* the tag-driven template refinement/snapping procedure */
  if( iTagDrvnRef ) 
  {
    if (BLAdaptFlag)
    {
      if (iMeshWithPyr)
        tagAdditionalEdgesForPyrTemplates(0.);

      pRef->runBL();
    }

   /* tag the additional edges for periodic model boundary entities */
    tagEdgesForPBC();

    pRef->run();

#ifdef DEBUG
//M_writeVTKFile(pmesh, "mesh_out_ref");
//int isValid=0;
//FMDB_Mesh_Verify(pMeshInst, &isValid);
//printf("The mesh is valid: %d\n", isValid);
#endif

      if (BLAdaptFlag)
      { 
        if(model_type) 
        {
          // setSnap();
          tt.reset();

          /// Nodes added within refBL() routine must be excluded from pSnapList to be processed later
          pVertex pVertexVtx;
          for (int iIt = 0; iIt < pSnapList->size();)
          {
            pVertexVtx = pSnapList->at(iIt).first;
            if (!V_typeInBL(pVertexVtx))
            {
              VecSnapListNonBLNodes.push_back(pSnapList->at(iIt));
              pSnapList->erase(pSnapList->begin() + iIt);
            }
            else
              iIt++;
          }

          // the normal vector for the new growth curve
          // is set in buildAndUpdateBLDataStructures()
          constrainBL();
#ifdef MA_PARALLEL
          numBL = snapBLNodes(userLB);
#else
          numBL = snapBLNodes();
#endif
          unconstrainBL();

          /// Get the pointer to the list of removed vertices to make sure none of non-BL vertices are affected
          std::set<pVertex> pSetRemovedVtx;
          pSnap->GetSetRemovedVtx(pSetRemovedVtx);

          /// Snap Non-BL vertices
          for (int iIt = 0; iIt < VecSnapListNonBLNodes.size(); ++iIt)
          {
            pVertexVtx = VecSnapListNonBLNodes[iIt].first;
            if (pSetRemovedVtx.count(pVertexVtx))
              delete []  VecSnapListNonBLNodes[iIt].second;
            else
              pSnapList->push_back(VecSnapListNonBLNodes[iIt]);
          }
          VecSnapListNonBLNodes.clear();
          pSetRemovedVtx.clear();

          accumulateT_BLsnap += tt.elapsedCPU();
          if( numBL==-1 )
            { adaptUtil::Info("Error: snapping return -1 for BL mesh\n"); exit(0); }
#ifdef DEBUG
          if( numBL )
            adaptUtil::Info(numBL,"vertices are not snapped for BL mesh");
#endif

        }
      }

    if(BLAdaptFlag)
    {
      unconstrainThicknessAdapt();
      constrainBL();
    }

    if( model_type ) 
    {
      setSnap();
#ifdef MA_PARALLEL
      num=pSnap->run(userLB);
#else
      num=pSnap->run();
#endif
      if( num==-1 ) 
	exit(0);
#ifdef DEBUG
      if( num ) 
	adaptUtil::Info(num,"vertices are not snapped");
#endif
    }

    if (BLAdaptFlag)
    {
      unconstrainBL();

      if (BLTetrahedronization)
          pRef->Mesh_AdaptiveDecompBL(dBLAspectRatioLimit);
    }

    adaptUtil::Info(tt.elapsedCPU(),"seconds for refinement");
    tt.reset();
//    return;
  }

  else
  {
  /* the size-driven adaptaion procedure begins  */
  double alpha_maxSq = 0.5625;
  double alpha_threshdSq = 0.25;
  double maxSq, minSq, threshdSq=1.0e14;
  int numsplit, numsplitBL;
  int loop=0;

  double maxSqBL, minSqBL, threshdSqBL=1.0e14;

  thicknessAdaptExecuted = 0;

  /*     STAGE ONE       */
#ifdef MA_PARALLEL
  if (P_pid()==0)
#endif
{
    cout<<"\n/*************************/\n";
    cout<<"/*     STAGE ONE         */\n";
    cout<<"/*************************/\n";
  }
//      writeVTUSizes(pmesh, pSizeField);
//      exit(0);
#ifdef DEBUG
//M_writeVTKFile(pmesh,"mesh_init");
//Mesh_CheckRgnVol(pmesh);
#endif
#ifdef MA_PARALLEL 
  double t1= ParUtil::Instance()->wTime();
#endif

#if 1
#ifndef MA_PARALLEL
  coarsen(upperLenSqBound);
#else
  if (BLAdaptFlag)
  {
    coarsenSurfaceInBL(upperLenSqBound, userLB);
//    optimizeSurfaceInBL(upperLenSqBound, userLB);

    constrainBL();

    if (isFirstLayerThicknessSet)    
    {
      thicknessAdaptationInBL(userLB);
//      decomposeMetricField();
    }


#ifdef DEBUG
//M_writeVTKFile(pmesh,"mesh_stage1_thickness");
#endif

//**    removeSliverRegions(qualityThreshold, upperLenSqBound, userLB);

  }

//  coarsen(maxSq,userLB);
  coarsen(upperLenSqBound, userLB);
#endif
#endif
/// Comment from the top of stage one till here if you don't want stage one

  adaptUtil::M_checkSize(pmesh,pSizeField,maxSq,minSq);

  if(BLAdaptFlag)
  {
    unconstrainBL();
//    unconstrainBL();
    adaptUtil::M_checkSizeBL(pmesh,pSizeField,maxSqBL,minSqBL);
//    unconstrainThicknessAdapt();
//    constrainBL();
  }

#ifdef MA_PARALLEL
  double t2= ParUtil::Instance()->wTime();
  if (P_pid()==0)
  {
    cout<<"\n# Stage One = "<<P_size()<<"\n";
    cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
  }
#endif
  adaptUtil::Info(tt.elapsedCPU(),"seconds for coarsening");
  tt.reset();

#ifdef DEBUG
//M_writeVTKFile(pmesh,"mesh_stage1");
//M_verify(pmesh);
#endif

  /*     STAGE TWO       */
#ifdef MA_PARALLEL
  if (P_pid()==0)
#endif
  {
    cout<<"\n/*************************/\n";
    cout<<"/*     STAGE TWO         */\n";
    cout<<"/*************************/\n";
  }

  accumulateT_ref = accumulateT_BLref = 0;
  accumulateT_snap = accumulateT_BLsnap = 0;
  accumulateT_others = accumulateT_BLothers = 0;
  double accumulateT_pre=0; 
  double accumulateT_CSize=0; 
  double accumulateT_sizefd=0; 
#ifdef MA_PARALLEL
  t1= ParUtil::Instance()->wTime();
#endif 
  do {

      ++loop;

#ifdef DEBUG
char cNumIter[4];
char file_name[128];
sprintf(cNumIter,"%d",loop);
#endif

#ifdef MA_PARALLEL
if (P_pid()==0)
#endif
{      
      printf("\n\n");
      printf("****************************\n");
      printf("    START iteration %d\n",loop);
      printf("****************************\n\n");
      printf(" * edge length range w.r.t size field: (%f ~ %f)\n",
	     sqrt(maxSq),sqrt(minSq));

      printf(" * BL layer edge length range w.r.t size field: (%f ~ %f)\n",
             sqrt(maxSqBL), sqrt(minSqBL));

      printf(" * threshold reduced from %f -> ",sqrt(threshdSq));
      printf(" * BL threshold reduced from %f -> ",sqrt(threshdSqBL));
}      
//        threshdSq = 0.5625*maxSq;
//        threshdSq = MAX(threshdSq,upperLenSqBound);
      tt.reset();
//      threshdSq = MIN(0.9*threshdSq,0.64*maxSq);
      threshdSq = MIN(alpha_threshdSq*threshdSq, alphaFactor*maxSq);
      threshdSq = MAX(threshdSq,upperLenSqBound);

//      threshdSqBL = MIN(alpha_threshdSq*threshdSqBL, alpha_maxSq*maxSqBL);
      threshdSqBL = MIN(alpha_threshdSq*threshdSqBL, alphaFactor*maxSqBL);
      threshdSqBL = MAX(threshdSqBL, upperLenSqBound);

#ifdef MA_PARALLEL
if (P_pid()==0)
#endif
      printf("%f \n ",sqrt(threshdSq));

      int global_numsplit, global_numsplitBL;

      if (BLAdaptFlag)
      {
        tt.reset();
//        numsplitBL = tagLayerEdgesInBLBySizeField(threshdSq);

//        unconstrainBL();

        numsplitBL = tagLayerEdgesInBLBySizeField(upperLenSqBound);

        if (iMeshWithPyr)
          tagAdditionalEdgesForPyrTemplates(upperLenSqBound);

        accumulateT_pre += tt.elapsedCPU();

#ifndef MA_PARALLEL
        if( numsplitBL )
#else
        global_numsplitBL = M_getMaxNum(numsplitBL);
        accumulateT_pre += tt.elapsedCPU();

        if (global_numsplitBL)
#endif
        {
          tt.reset();
          pRef->runBL();
          accumulateT_BLref += tt.elapsedCPU();
        }
      }

#ifdef DEBUG
//M_writeVTKFile(pmesh,"mesh_out_refBL");
//Mesh_CheckVtxCoordsOnPB(pmesh);
#endif

/// INTR. VOL Mesh refinement
      tt.reset();
//      numsplit = tagEdgesByField(threshdSq);
      numsplit = tagEdgesByField(upperLenSqBound);

      /// tag the additional edges for periodic model boundary entities 
//      setupEdgesForPBC();
      numsplit += tagEdgesForPBC();

#ifndef MA_PARALLEL
      if( numsplit )
#else
      global_numsplit = M_getMaxNum(numsplit);
      accumulateT_pre += tt.elapsedCPU();

      if (global_numsplit || global_numsplitBL)
#endif
      {
        tt.reset();
        pRef->run();
        accumulateT_ref += tt.elapsedCPU();
      }
/*
#ifdef MA_PARALLEL
  if (BLAdaptFlag)
    Mesh_UnifyBLInterfaceOnCB(pmesh);
#endif
*/
//          decomposeMetricField();

#ifdef DEBUG
strcpy(file_name, "mesh_out_ref");
strcat(file_name, cNumIter);
//int isValid=0;
//FMDB_Mesh_Verify(pMeshInst, &isValid);
//Mesh_CheckVtxCoordsOnPB(pmesh);
#endif

      if (BLAdaptFlag && global_numsplitBL)
      {
        if(model_type) 
        {
          // setSnap();
          tt.reset();

          /// Nodes added within refBL() routine must be excluded from pSnapList to be processed later
          pVertex pVertexVtx;
          for (int iIt = 0; iIt < pSnapList->size();)
          {
            pVertexVtx = pSnapList->at(iIt).first;
            if (!V_typeInBL(pVertexVtx))
            {
              VecSnapListNonBLNodes.push_back(pSnapList->at(iIt));
              pSnapList->erase(pSnapList->begin() + iIt);
            }
            else
              iIt++;
          }

          // the normal vector for the new growth curve
          // is set in buildAndUpdateBLDataStructures()
          constrainBL();
#ifdef MA_PARALLEL
          numBL = snapBLNodes(userLB);
#else
          numBL = snapBLNodes();
#endif
          unconstrainBL();

          /// Get the pointer to the list of removed vertices to make sure none of non-BL vertices are affected
          std::set<pVertex> pSetRemovedVtx;
          pSnap->GetSetRemovedVtx(pSetRemovedVtx);

          /// Snap Non-BL vertices
          for (int iIt = 0; iIt < VecSnapListNonBLNodes.size(); ++iIt)
          {
            pVertexVtx = VecSnapListNonBLNodes[iIt].first;
            if (pSetRemovedVtx.count(pVertexVtx))
              delete []  VecSnapListNonBLNodes[iIt].second;
            else
              pSnapList->push_back(VecSnapListNonBLNodes[iIt]);
          }
          VecSnapListNonBLNodes.clear();
          pSetRemovedVtx.clear();

          accumulateT_BLsnap += tt.elapsedCPU();
          if( numBL==-1 )
            { adaptUtil::Info("Error: snapping return -1 for BL mesh\n"); exit(0); }
#ifdef DEBUG
          if( numBL )
            adaptUtil::Info(numBL,"vertices are not snapped for BL mesh");
#endif

        }
//          else
//            clearSnap();
#ifdef DEBUG
//int isValid=0;
//FMDB_Mesh_Verify(pMeshInst, &isValid);
#endif
      }
      if(BLAdaptFlag)
      {
//        unconstrainThicknessAdapt();
        constrainBL();
      }

      if(global_numsplit &&  model_type )
      {
        setSnap();
        tt.reset();
#ifdef MA_PARALLEL
//          M_sync();
        num=pSnap->run(userLB);
#else
        num=pSnap->run();
#endif
        accumulateT_snap += tt.elapsedCPU();
        if( num==-1 )
          { adaptUtil::Info("Error: snapping return -1\n"); exit(0); }
        if( num )
          adaptUtil::Info(num,"vertices are not snapped");
      }
//      else
//        clearSnap();

      if( flag )
      {
        tt.reset();
        sizefd(pmesh,pSizeField,0);
        accumulateT_sizefd += tt.elapsedCPU();
      }

#ifdef DEBUG
strcpy(file_name, "mesh_out_snap");
strcat(file_name, cNumIter);
//int isValid=0;
//FMDB_Mesh_Verify(pMeshInst, &isValid);
#endif

      if (BLAdaptFlag && model_type)
        decomposeMetricField();

      tt.reset();
#ifdef MA_PARALLEL
      if(BLAdaptFlag)
      {
        unconstrainBL();

        coarsenSurfaceInBL(MAX(alpha_threshdSq*threshdSqBL, upperLenSqBound), userLB);

#ifdef DEBUG
strcpy(file_name, "mesh_out_coarseBL");
strcat(file_name, cNumIter);
#endif

//        optimizeSurfaceInBL(MAX(alpha_threshdSq*threshdSqBL, upperLenSqBound), userLB);

        /// Adaptive unstructuring
        if (BLTetrahedronization)
          pRef->Mesh_AdaptiveDecompBL(dBLAspectRatioLimit);

#ifdef DEBUG
//int isValid=0;
//FMDB_Mesh_Verify(pMeshInst, &isValid);
//M_checkBLStructure(pmesh);
//M_checkBLEdgesAndVerts(pmesh);
//M_checkBLFacesAndAdjRegions(pmesh);
//M_checkBLSplitFaces(pmesh);
strcpy(file_name, "mesh_out_adaptTrim");
strcat(file_name, cNumIter);
//Mesh_CheckRgnVol(pmesh);
#endif

        constrainBL();
      }

//**      removeSliverRegions(qualityThreshold, 0., userLB);
      accumulateT_BLothers += tt.elapsedCPU();
#else
      if(BLAdaptFlag)
      {
        unconstrainBL();
        if (BLTetrahedronization)
          pRef->Mesh_AdaptiveDecompBL(dBLAspectRatioLimit);
        coarsenSurfaceInBL(MAX(alpha_threshdSq*threshdSqBL,upperLenSqBound));
//        optimizeSurfaceInBL(MAX(alpha_threshdSq*threshdSqBL, upperLenSqBound));
        constrainBL();
      }
#endif


/// INTR. VOL. ADAPTATION
      int optimize2D = 0;

      tt.reset();

      if (BLAdaptFlag)
        constrainBL();
#ifdef MA_PARALLEL
      coarsen(MAX(alpha_threshdSq*threshdSq,upperLenSqBound),userLB); 
//      if( M_getMaxNum(M_numRegions(pmesh))==0 )
      if (M_maxMeshDim() < 3)
	optimize2D = 1;
#else
      coarsen(MAX(alpha_threshdSq*threshdSq,upperLenSqBound));
      if( M_numRegions(pmesh)==0 )
	optimize2D = 1;
#endif 

      if(optimize2D)
	optimize(MAX(alpha_threshdSq*threshdSq,upperLenSqBound));

      accumulateT_others += tt.elapsedCPU();
	
      tt.reset();       

      if(BLAdaptFlag)
      {
        constrainBL();
//        constrainThicknessAdapt();
      }

      adaptUtil::M_checkSize(pmesh,pSizeField,maxSq,minSq);
  
      if(BLAdaptFlag)
      {
//        unconstrainThicknessAdapt();
        unconstrainBL();
//        constrainThicknessAdapt();
        adaptUtil::M_checkSizeBL(pmesh,pSizeField,maxSqBL,minSqBL);
//        unconstrainThicknessAdapt();
//        constrainBL();
      }

      accumulateT_CSize += tt.elapsedCPU();

#ifdef DEBUG
strcpy(file_name, "mesh_out_intermediate");
strcat(file_name, cNumIter);
//int isValid=0;
//FMDB_Mesh_Verify(pMeshInst, &isValid);
/*
if (loop == 1)
{
FMDB_Mesh_WriteToFile (pMeshInst, "inter/geom.sms", 1);
visUtil::writeSizeField(pMeshInst, pSizeField, "inter/", 1);
MPI_Barrier(MPI_COMM_WORLD);
}
*/
//Mesh_CheckRgnVol(pmesh);
#endif

   } while( MAX(maxSq, maxSqBL) > 1.06*upperLenSqBound && loop<niter );

#ifdef MA_PARALLEL
  t2= ParUtil::Instance()->wTime(); 
  if (P_pid()==0)
  {
    std::cout<<"\n# Stage Two = "<<P_size()<<"\n";
    std::cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
  }
#endif 

adaptUtil::Info("Total time on refinement:",accumulateT_ref);
adaptUtil::Info("Total time on BL refinement:",accumulateT_BLref);
adaptUtil::Info("Total time on coarsening:",accumulateT_others);
adaptUtil::Info("Total time on BL coarsening:",accumulateT_BLothers);
adaptUtil::Info("Total time on snapping:",accumulateT_snap);
adaptUtil::Info("Total time on BL snapping:",accumulateT_BLsnap);
adaptUtil::Info("Total time on preprocessing:",accumulateT_pre);
adaptUtil::Info("Total time on checking size:",accumulateT_CSize);
adaptUtil::Info("Total time on attaching sizefd:",accumulateT_sizefd);

  /*     STAGE THREE     */
#ifdef MA_PARALLEL
  if (P_pid()==0)
#endif
  {
    cout<<"\n/*************************/\n";
    cout<<"/*     STAGE THREE         */\n";
    cout<<"/*************************/\n";
  }
 
//return;

  if(BLAdaptFlag)
  {
/*
    constrainBL();

    // pSnapList might be empty but some nodes (o-nodes or nodes of GC on model bdry.)
    // might be tagged with notBLSnapID
    if( model_type)
#ifdef MA_PARALLEL
      numBL = snapBLNodes(userLB);
#else
      numBL = snapBLNodes();
#endif
//    else
//      clearSnap();
    if( numBL==-1 )
      { adaptUtil::Info("Error: snapping return -1 for BL mesh\n"); exit(0); }
    if( numBL )
      adaptUtil::Info(numBL,"vertices are not snapped for BL mesh");

//    constrainBL();
//    removeSliverRegions(qualityThreshold, 0., userLB);
*/
//    unconstrainBL();

#ifdef MA_PARALLEL
    optimizeSurfaceInBL(upperLenSqBound, userLB);
#else
    optimizeSurfaceInBL(upperLenSqBound);
#endif
  }

#ifdef DEBUG
//M_verify(pmesh);
#endif
 
  tt.reset();
#ifdef MA_PARALLEL
if (P_pid()==0)
#endif
  printf("\n\n");
  adaptUtil::Info("start correcting element shape");

  if (BLAdaptFlag)
    constrainBL();
#ifdef MA_PARALLEL
   t1= ParUtil::Instance()->wTime();
//  if( M_getMaxNum(M_numRegions(pmesh))!=0 ) 
   if (M_maxMeshDim() == 3)
     removeSliverRegions(qualityThreshold, 0., userLB);
#else
  if( M_numRegions(pmesh)!=0 ) 
    removeSliverRegions(qualityThreshold, 0.);
#endif
  else
    optimize(upperLenSqBound);

  if (BLAdaptFlag)
    unconstrainBL();
 
#ifdef MA_PARALLEL  
  t2= ParUtil::Instance()->wTime();
  if (P_pid()==0)
  {
    std::cout<<"\n# Stage Three = "<<P_size()<<"\n";
    std::cout<<"TIME = "<<t2-t1<<" (sec)\n\n";
  }
#endif 

#ifdef DEBUG
//M_verify(pmesh);
#endif

  adaptUtil::Info(tt.elapsedCPU(),"seconds for shape correction");
  }

  if(BLAdaptFlag) 
  {
    int gcThicknessTag, layerFaceNormalChangeTag, notBLSnapTag, metricDecomposedTag;
    double firstLayerThicknessTag;
    pVertex onode;
    VIter oviter = M_vertexIter(pmesh);
    while(onode = VIter_next(oviter)) {
      if(EN_getDataInt((pEntity)onode,gcThicknessID,&gcThicknessTag))
        EN_deleteData((pEntity)onode,gcThicknessID);
      if(EN_getDataInt((pEntity)onode,notBLSnapID,&notBLSnapTag))
        EN_deleteData((pEntity)onode,notBLSnapID);
      if(EN_getDataInt((pEntity)onode,metricDecompositionID,&metricDecomposedTag))
        EN_deleteData((pEntity)onode,metricDecompositionID);
      if(isFirstLayerThicknessSet)
        if(EN_getDataDbl((pEntity)onode,firstLayerThicknessID,&firstLayerThicknessTag))
          EN_deleteData((pEntity)onode,firstLayerThicknessID);
    }
    VIter_delete(oviter);

    pFace lyrFc;
    FIter lfit = M_faceIter(pmesh);
    while(lyrFc = FIter_next(lfit)) {
      if(EN_getDataInt((pEntity)lyrFc,layerFaceNormalChangeID,&layerFaceNormalChangeTag))
        EN_deleteData((pEntity)lyrFc,layerFaceNormalChangeID);
    }
    FIter_delete(lfit);

    MD_deleteMeshDataId(gcThicknessID);
    if(isFirstLayerThicknessSet)
      MD_deleteMeshDataId(firstLayerThicknessID);
    MD_deleteMeshDataId(layerFaceNormalChangeID);
    MD_deleteMeshDataId(metricDecompositionID);
    MD_deleteMeshDataId(gcNormalTag);

    /// Snapping stuff
    MD_deleteMeshDataId(updateGCOnModelBdryID);
    MD_deleteMeshDataId(topNodeMoveID);
    MD_deleteMeshDataId(moveDirID);
    MD_deleteMeshDataId(moveVectorID);
    MD_deleteMeshDataId(notBLSnapID);
  }

#ifdef VTMOVE
  cleanSmoothFlag();
#endif

#ifdef DEBUG
//M_writeVTKFile(pmesh,"mesh_out_final");
//int isValid=0;
//FMDB_Mesh_Verify(pMeshInst, &isValid);
//printf("The mesh is valid: %d\n", isValid);
#endif

  return;  
}

/*
  the main routines for mesh coarsening

  Given a prescribed mesh size field, this procedure eliminates
  short mesh edges using edge collapses applied every one another
  return the number of applied edge collapses 

  Created: 03/06/01   X.R. Li
  Modified: 7/15/01   -li
            8/30/01   -li
	    2/26/03   -li  test vertex motion in case collapsing creats long edges
*/
#ifdef MA_PARALLEL  // at page 10 of printout
int meshAdapt::coarsen(double upperBoundSq, pmMigrationCallbacks& userLB)
#else
int meshAdapt::coarsen(double upperBoundSq)
#endif
{
  pEdge edge, edgeDel, pbc_edgeDel;
  pVertex vd, vr, pbc_vd /*,vts[2]*/;
  int i,/* j,*/ value;
  double sqel;
  double maxWorstShape;
  int nclps=0, nmove=0;
  double mtol=M_getTolerance();

  std::set<pVertex> removedEnts;       

  // the tag and the two lists controlling the coarsening routine 
  pMeshDataId deref=MD_newMeshDataId("Id_Deref_Control");
  std::list<pVertex> drVertices;

  // declare the edge collapse object 
  edgeCollapsMod *clps = new edgeCollapsMod(pmesh,pSizeField,shpMeasure,result);
  clps->setCallback(function_CB,userData_CB);
  clps->setAcptControl(1);
  if( checkVolume ) 
    clps->setCheckVolume(dV_limit,dA_limit);
  if( model_type != 2 )
    clps->setModelType(NOPARAM);

#ifdef CURVE
  clps->setCurved();
#ifdef DEBUG
  cout<<"[CURVE Info]: Setting edgeCollapsMod in meshAdapt::coarsen to enable curving "<<endl;
#endif//DEBUG  
#endif//CURVE

  // determine mesh edges and their end vertices to be processed
  EIter eit = M_edgeIter(pmesh);
  while (edge=EIter_next(eit))
  {
    if (!EN_okTo(DELETE,(pEntity)edge))
      continue;

    /// This check is needed to exclude from considering BL edges end vertexes from processing. These edges and vertexes 
    /// are unaware of being BL vertexes on the interface regions on the partition boundary. 
    /// The function constrain_BL() checks only for BL stacks and is not aware of interface regions
    /// having part of the elements on the partition boundary with the correspondent BL. At the same time, there is no need to check all the edges
    /// additionaly in constrainBL() since during migration there can be interface regions migrated with the not constrained edges and vertexes.
    if (E_typeInBL(edge))
      continue;
    sqel = pSizeField->lengthSq(edge);
    if(sqel < lowerLenSqBound) 
    {
      EN_attachDataInt((pEntity)edge,deref,-1);
      for( i=0; i<2; i++ ) {
	vr=E_vertex(edge,i);
        if(!EN_okTo(DELETE,(pEntity)vr))
          continue;
        if (V_typeInBL(vr))
          continue;
	if( !EN_getDataInt((pEntity)vr,deref,&value) )  {
	  EN_attachDataInt((pEntity)vr,deref,-1);
	  drVertices.push_back(vr);
	}
      }
    }
  }
  EIter_delete(eit);

  // repeat traversing of the vertex list to eliminate edges to be coarsened
  int loopId = 0;
  int flag;
  std::list<pVertex>::iterator drIter, tmp_drIter;

#ifndef MA_PARALLEL
  while( drVertices.size() ) {

#else 		/* MA_PARALLEL */

  int globalDrVertices_size = M_getMaxNum(drVertices.size());  
  std::list<pVertex>  vtOnCB;
  int Comm_start_FLAG=1;
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  while(globalDrVertices_size) {

    if( Comm_start_FLAG && P_size()>1) { 
      CM->set_tag(0);
      int msg_size = sizeof(classificationPack);
      CM->set_fixed_msg_size(msg_size);

      Comm_start_FLAG=0;
    }
#endif
//    setupEdgesForPBC();  
    loopId++;    
    drIter = drVertices.begin();   

    while(drIter != drVertices.end()) {
      
      // see if the vertex has been removed
      vd = *drIter;
      tmp_drIter = drIter;
      if( removedEnts.find(vd) != removedEnts.end() ){
         drIter++;
	 drVertices.erase(tmp_drIter); 
	 removedEnts.erase(vd); 
	 continue;
      }
      
      // this is to ensure that edge collapsed is applied every other vertex
      if( !EN_getDataInt((pEntity)vd,deref,&value) ) {
        drIter++;
	drVertices.erase(tmp_drIter);
	continue; 
      }
      if( value>loopId )
      {
        drIter++;
        continue; 
      }

      // always eliminate this vertex in case it is processed
      drIter++;
      drVertices.erase(tmp_drIter);

      // set shape threshold
      shpMeasure->setDefaultAcptValue();
      maxWorstShape=0.1*adaptUtil::V_worstShp(shpMeasure,vd);
      shpMeasure->setAcptValue(maxWorstShape);
      
      // try edge collapse or vertex motion
      std::vector< std::pair<double,pEdge> > Evector;
      std::vector< std::pair<double,pEdge> >::iterator pairIt;
      for( i=0; i<V_numEdges(vd); i++ ) {
	edgeDel=V_edge(vd,i);
	if( !EN_getDataInt((pEntity)edgeDel,deref,&value) ) 
	  continue;
        sqel = pSizeField->lengthSq(edgeDel);
	Evector.push_back(std::make_pair(sqel,edgeDel));
      }
      std::sort(Evector.begin(),Evector.end());

      // situation 1: no connected mesh edge requires coarsening
      if( Evector.size()==0 ) { 
	EN_deleteData((pEntity)vd,deref);
	  continue; 
      }

      for(pairIt=Evector.begin();pairIt!=Evector.end();++pairIt) {
	edgeDel=(*pairIt).second;
	flag=coarsenVertex(edgeDel,vd,upperBoundSq,maxWorstShape,clps,loopId,
			   deref,drVertices,removedEnts);
	if ( flag )
        {
	  break;
        }
      }
	 
      if( flag==2 ) {
	nmove++;
	continue;
      }
      if( flag==1 ) {
	nclps++;
	continue;
      }

#ifdef MA_PARALLEL
      if( EN_onCB(vd) ) 
      {
/*
/// Later update on this whole commented fragment of code. The migration involving entity groups migration still happens. 
/// Do we really need to restrict entity groups from migration, or there are some inevitable situations where there is no way
/// but migrate entity groups alog with the region requesting migration. Right now, entity groups can be migrated
/// along with the regular regions.

        /// This check is needed to prevent from migrating BLs at this step. Some vertexes are BL vertexes on the interface
        /// regions on the partition boundary. The function constrain_BL() checks only for BL stacks and is not aware of interface regions
        /// having part of the elements on the partition boundary with the correspondent BL.
        /// Probably not a good idea to check this here after we've done all the topological checks already. Need revision for efficiency.
        if (BLAdaptFlag)
        {
          int iAllowToMigrate = 1;
          for (int iEdge = 0; iEdge < V_numEdges(vd); ++iEdge)
          {
            if (E_typeInBL(V_edge(vd, iEdge)))
            {
              iAllowToMigrate = 0;
              break;  
            }
          }

          if (iAllowToMigrate)
          {
            vtOnCB.push_back(vd);
          }
        }
        else
        {
          vtOnCB.push_back(vd);
        }
*/
        vtOnCB.push_back(vd);

	continue;
      }
#endif

      // situation 2: no valid edge collapse is available
      EN_deleteData((pEntity)vd,deref);
    } // end  of traversing drVertices once

#ifdef MA_PARALLEL
    // do mesh migration only if all vertices in drVertices on CB
    globalDrVertices_size=M_getMaxNum(drVertices.size());

//    This checkup for the changed max dim of the mesh in global sence is not needed so far, it is set during the mesh load
//    int mDim = M_globalMaxDim(pmesh);
//    M_set_maxMeshDim(mDim);

    if(globalDrVertices_size==0 && P_size()>1) {
      // initialize removedEnts
      removedEnts.clear();
      CM->finalize_send();

      fromMeshTools::syncClassification(pmesh);

      Comm_start_FLAG=1;
      // update partition boundary to remove all mesh faces not locally 
      // connected to a mesh region and update list "vtOnCB"
      deleteDimReduction(vtOnCB, userLB);
      globalDrVertices_size = mMigrateForCoarsen(vtOnCB,	// a list of vertices on CB
						 drVertices,	// a list of vertices to be coarsened
						 userLB,	// customized load balancer
						 deref,	        // tag 
						 lowerLenSqBound); // threshould
      vtOnCB.clear();		
    }
#endif

  } // end of the loop to enforce "every other vertices"
#ifdef DEBUG
  adaptUtil::Info(nclps,"edge collapse(s) were performed (coarsened)");
  adaptUtil::Info(nmove,"vertex motion(s) were performed (coarsened)");
#endif

  EIter eiter=M_edgeIter(pmesh);
  while( edge=EIter_next(eiter) ) { 
    if( EN_getDataInt((pEntity)edge,deref,&value) ) 
      EN_deleteData((pEntity)edge,deref);
  } 
  EIter_delete(eiter);
  VIter viter= M_vertexIter(pmesh);
  pVertex vert;
  while(vert = VIter_next(viter)) {
    if( EN_getDataInt((pEntity)vert,deref,&value) ) 
      EN_deleteData((pEntity)vert,deref);
  }
  VIter_delete(viter);

  MD_deleteMeshDataId(deref);
  delete clps;

  return nclps;
}


  /*
    Eliminate a given edge by edge collapsing or relocation

    return 1 if a vertex of the edge is collapsed
           2 if a vertex of the edge is moved
           0 no mesh modification happened
  */
  int meshAdapt::coarsenVertex(pEdge edgeDel,   // the edge
			       pVertex vd,
			       double upperBoundSq, 
			       double maxWorstShape,
			       edgeCollapsMod *clps,
			       int loopId,
			       pMeshDataId deref,
			       std::list<pVertex>& drVertices,
			       std::set<pVertex>& removedEnts)        
{  
  pVertex bestVr, bestVd, vr;
  pEdge edge, bestEdgeDel;

  double tmpshp;
  double tmpXYZ[3], target[3];
  double mtol=M_getTolerance();
  pVertex vts[2];
  int i, j, value;

 // consider the pbc condition
  int match_flag=0;  // Note: QLU
                     // Indicate the edge has matched edges or not. 
                     // Default: match_flag=0: no matched edges
                     // Aug 15, 2010
  list<std::pair<int, pEntity> > mlist, vlist[2];
  list<std::pair<int, pEntity> >::iterator mlistIter;
  pEdge match_edgeDel;
  pVertex match_vts[2], match_vd, match_vr;
  std::vector<edgeCollapsMod*> match_clps;
  std::vector<double> match_maxWorstShapes;
  std::vector<pVertex> match_vds, match_vrs;
  int count;                          // the vector array subscript
  int del_plist_flag[2];

  // get matched edges of edgeDel if it has
  if( GM_pbc(M_model(pmesh)) && EN_isMatchEnt(edgeDel) )  {
     EN_getMatchEnts(edgeDel, 0, mlist);
     match_flag=1;   // Note QLU
                     // Set match_flag = 1 to account matching entities
                     // Aug 15, 2010
     //   cout<<"mlist size: "<<PList_size(mlist)<<endl;
  }

  int Flag=0;
  int opt=2;
  for( i=0; i<2; i++ ) {
    vts[i]=E_vertex(edgeDel,i);
#ifdef MA_PARALLEL
    if( EN_onCB((pEntity)vts[i]) )
      Flag++;
#endif
    if( match_flag ){  // matching case 
      if( EN_isMatchEnt(vts[i]) )
        EN_getMatchEnts(vts[i], 0, vlist[i]);
    }                  // end of matching case
  }


#ifdef MA_PARALLEL
  if (Flag==2)
    return 0;
  pVertex tmpVt;
  if (Flag==1) {
    opt=1;
    if (EN_onCB(vts[0]))
    {
      if (!EN_isBLEntity(vts[1])) 
      {
        tmpVt=vts[0];
        vts[0]=vts[1];
        vts[1]=tmpVt;
      }
      else
       return 0;
    }
  }
#endif

  if (match_flag) // matching case
  {
    for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
    {
      match_edgeDel = mlistIter->second;
      // get match_vd for match_edgeDel
      if( match_edgeDel!=edgeDel ) {
        for(int i=0; i<2; i++) {
          match_vts[i]=E_vertex(match_edgeDel, i);
          if( EN_isMatchEnt(vd) ) {
            list<std::pair<int, pEntity> > vlist;
            EN_getMatchEnts(vd, 0, vlist);
            if (find(vlist.begin(), vlist.end(), make_pair(0,match_vts[i])) != vlist.end())
            {
              match_vd=match_vts[i];
              break;
            }
          }
          else
            if( vd==match_vts[i] ) {
              match_vd=match_vts[i];
              break;
            }
        }
      }
      else        //  if( match_edgeDel!=edgeDel )
        match_vd=vd;
      match_vr = E_otherVertex(match_edgeDel, match_vd);
      match_vds.push_back(match_vd);                              // match_vds indicates vds now
      match_vrs.push_back(match_vr);

      if( match_edgeDel!=edgeDel ) {
        double tmp_maxWorstShape = 0.1*adaptUtil::V_worstShp(shpMeasure,match_vd);
        edgeCollapsMod* tmp_clps = new edgeCollapsMod(pmesh,pSizeField,shpMeasure,result);
        tmp_clps->setCallback(function_CB, userData_CB);
        if( model_type != 2 )
          tmp_clps->setModelType(NOPARAM);
        match_clps.push_back(tmp_clps);
        match_maxWorstShapes.push_back(tmp_maxWorstShape);
      }
      else {
        match_clps.push_back(clps);
        match_maxWorstShapes.push_back(maxWorstShape);
      }
    }  // while( match_edgeDel = (pEdge)PList_next(mlist, &it) )
  }  // End of matching case

  Flag = 0;
  if (!match_flag) // No matching case
  {
    for( i=0; i<opt; i++ ) 
    {
      clps->setCollaps(edgeDel,vts[i],vts[(i+1)%2]);    

    if( !clps->topoCheck() )
      continue;
    
    clps->sizeCheck(); 
    
    if( result->getMaxSize()>upperBoundSq+mtol ) {
      // check vertex motion
#ifdef VTMOVE
      if( moveVertex(vts[i], upperBoundSq, tmpXYZ, &tmpshp) ) 
	if( maxWorstShape+mtol < tmpshp ) {
	  maxWorstShape=tmpshp;
	  bestVd=vts[i];
	  target[0]=tmpXYZ[0];
	  target[1]=tmpXYZ[1];
	  target[2]=tmpXYZ[2];
	  Flag=2;
	}
#endif
      continue; 
    }
	    
    if( ! clps->geomCheck() )  // geomCheck in coarsenVertex
     continue;
    if( result->getWorstShape() < mtol )
      continue; 
    if( maxWorstShape+mtol < result->getWorstShape() ) 
      {
	maxWorstShape=result->getWorstShape();
	bestEdgeDel=edgeDel;
	bestVr=vts[(i+1)%2];
	bestVd=vts[i];
	Flag=1;
      }
    }
  }    // End of No matching case
  else {          // if (match_flag)
    for( i=0; i<opt; i++ ) {
      int iflag=0;                   // iflag indicating break or not in the while loop

      count=0;
      for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
      {
        match_edgeDel = mlistIter->second;
        if( vts[i]==vd ) {
          match_vts[i]=match_vds[count];
          match_vts[(i+1)%2]=match_vrs[count];
        }
        else {
          match_vts[i]=match_vrs[count];
          match_vts[(i+1)%2]=match_vds[count];
        }
        match_clps[count]->setCollaps(match_edgeDel, match_vts[i], match_vts[(i+1)%2]);

        if( !match_clps[count]->topoCheck() ) {
          iflag=1;
          break;
        }

        match_clps[count]->sizeCheck();

        if( result->getMaxSize()>upperBoundSq+mtol ) {
        // check vertex motion
#ifdef VTMOVE
          if( edgeDel==match_edgeDel )
            if( moveVertex(vts[i], upperBoundSq, tmpXYZ, &tmpshp) )
              if( maxWorstShape+mtol < tmpshp ) {
                maxWorstShape=tmpshp;
                bestVd=vts[i];
                target[0]=tmpXYZ[0];
                target[1]=tmpXYZ[1];
                target[2]=tmpXYZ[2];
                Flag=2;
              }
#endif
          iflag=1;
          break;
        }

        if( !match_clps[count]->geomCheck() ) {  // geomCheck in coarsenVertex
         iflag=1;
         break;
        }
        if( result->getWorstShape() < mtol ) {
          iflag=1;
          break;
        }
        maxWorstShape = min(maxWorstShape, match_maxWorstShapes[count]);
        count++;
      }

      if( iflag==0 )
        if( maxWorstShape+mtol < result->getWorstShape() )
          {
            maxWorstShape=result->getWorstShape();
            bestEdgeDel=edgeDel;
            bestVr=vts[(i+1)%2];
            bestVd=vts[i];
            Flag=1;
          }
    }
  }  // End of matching case

  if (Flag == 0) {
    if( match_flag )  // matching
      for(int i=0; i< (int)match_clps.size(); i++)
        if( match_clps[i]!= clps)
          delete match_clps[i];  // end of matching
    return 0;
  }
      
  // situation 3: a vertex repositioning is available
  if( Flag==2 ) {
    // Not deal vertex reposition at this moment
    if(match_flag)
      printf("The vertex reposition for pbc is not implemented yet!\n");

    if( vd==bestVd )
      EN_deleteData((pEntity)bestVd,deref);
    for( j=0; j<V_numEdges(bestVd); j++ ) {
      edge=V_edge(bestVd,j);
      if( pSizeField->lengthSq(edge) < lowerLenSqBound ) {
	if( !EN_getDataInt((pEntity)edge,deref,&value) )
	  EN_attachDataInt((pEntity)edge,deref,-1);
      } 
      else if( EN_getDataInt((pEntity)edge,deref,&value) )
	EN_deleteData((pEntity)edge,deref);  
    }
    adaptUtil::move_vertex(bestVd,target,CB_move,userData_CB_move);
    if( match_flag )
      for(int i=0; i< match_clps.size(); i++)
        if( match_clps[i]!= clps)
          delete match_clps[i];
    return 2;
  }

  // situation 4: an edge collapse is available

  // check if interactive check for collapse is needed
  if(match_flag) //matching
  {

    set<pVertex> vertices;
    vector<pEntity> match_ents;
    vector<pEntity> match_ent_copies;
    set<pVertex>::iterator setit;
    pEdge vedge;
    pVertex vtx, other_vtx;
    int dbl_check_flag=0;

    count=0;
    for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
    {
      match_edgeDel = mlistIter->second;
      if( match_edgeDel==edgeDel ) {
        match_vd=bestVd;
        match_vr=bestVr;
      }
      else {
        if( bestVd==vd) {
          match_vd=match_vds[count];
          match_vr=match_vrs[count];
        }
        else {
          match_vr=match_vds[count];
          match_vd=match_vrs[count];
        }
      }

      if( bestVd!=vd ) {
        match_vds[count]=match_vd;                        // match_vds indicates bestVds from now on
        match_vrs[count]=match_vr;
      }


      if(dbl_check_flag==0) {
        setit = vertices.find(match_vd);
        if(setit==vertices.end())
          vertices.insert(match_vd);                      // put match_vd into vertices
        else {
          dbl_check_flag=1;
        }

        if(dbl_check_flag==0) {
          for(int iedge=0; iedge<V_numEdges(match_vd); iedge++) {      // get adjacent edges of match_vd
            vedge=V_edge(match_vd, iedge);
            if(vedge!=match_edgeDel)
              other_vtx = E_otherVertex(vedge, match_vd);
            else
              other_vtx = match_vr;

            setit = vertices.find(other_vtx);
            if(setit==vertices.end())
              vertices.insert(other_vtx);
            else {
              dbl_check_flag=1;                 // matched vertices connect to common vertex
              break;
            }
          }
        } // if(dbl_check_flag==0)
      }

      match_ents.push_back(match_edgeDel);
      match_ents.push_back(match_vd);
      count++;
    }
    vertices.clear();

    // double check is needed
    if(dbl_check_flag) {

      pPList reglist = PList_new();
      pPList tmplist;
      for(int i=0; i<(int)match_vds.size(); i++) {
        tmplist = V_regions(match_vds[i]);
        PList_appPListUnique(reglist, tmplist);
        PList_delete(tmplist);
      }

      // create a copied mesh from regions around all match_vds
      pMesh copyMesh=adaptUtil::copyRegions(reglist, match_ents, match_ent_copies, pSizeField);
      PList_delete(reglist);

      count=0;
      void* it=0;
      int size = (int)match_ent_copies.size()/2;

      edgeCollapsMod* tmp_clps = new edgeCollapsMod(copyMesh,pSizeField,shpMeasure,result);
      tmp_clps->setCallback(function_CB, userData_CB);
      if( model_type != 2 )
        tmp_clps->setModelType(NOPARAM);

      match_edgeDel=match_ent_copies[0];
      match_vd = match_ent_copies[1];
      match_vr = E_otherVertex(match_edgeDel, match_vd);

      for(int i=1; i<size; i++) {

        // collapse the first edge
        if(match_edgeDel && match_vd && match_vr) {
          tmp_clps->setCollaps(match_edgeDel, match_vd, match_vr);
          tmp_clps->apply();  // apply() in coarsenVertex // seems not this one
        }
        else {
          Flag=0;
          break;
        }


        // check the second edge for collapse
        match_edgeDel=match_ent_copies[i*2];
        match_vd = match_ent_copies[i*2+1];

        // check if current vd was collapsed in previous operation
        for(int j=0; j<i; j++)
          if( match_ent_copies[j*2+1]==match_vd ) {
            Flag=0;
            break;
          }
        if(Flag==0)
          break;

        match_vr = E_otherVertex(match_edgeDel, match_vd);

        if(match_edgeDel && match_vd && match_vr)
          tmp_clps->setCollaps(match_edgeDel, match_vd, match_vr);
        else {
          Flag=0;
          break;
        }


        if( !tmp_clps->topoCheck() ) {
          Flag=0;
          break;
        }

        tmp_clps->sizeCheck();

        if( result->getMaxSize()>upperBoundSq+mtol ) {
          Flag=0;
          break;
        }

        if( result->getWorstShape() < mtol ) {
          Flag=0;
          break;
        }

        if( ! tmp_clps->geomCheck() ) { //geomCheck in coarsenVertex
          Flag=0;
          break;
        }
      }

      // delete the mesh size
      VIter viter = M_vertexIter(copyMesh);
      while( vtx=VIter_next(viter) ) {
        pSizeField->deleteSize(vtx);
      }
      VIter_delete(viter);
      delete tmp_clps;
      M_delete(copyMesh);

      if (Flag == 0) {
        for(int i=0; i< (int)match_clps.size(); i++)
          if( match_clps[i]!= clps)
            delete match_clps[i];
        return 0;
      }
    }   //  if(dbl_check_flag)
  }  // End of matching
     // if(match_flag)


  // not process the neighboring vertices in this traversing
  if(!match_flag) {  // No matching case
    for( j=0; j<V_numEdges(bestVd); j++ ) {
      edge=V_edge(bestVd,j);
      EN_deleteData((pEntity)edge,deref);
      vr=E_otherVertex(edge,bestVd);
      if( EN_getDataInt((pEntity)vr,deref,&value) )
        EN_modifyDataInt((pEntity)vr,deref,loopId+1);
    }
  }
  else {     // Matching case
    list<std::pair<int, pEntity> > vlist;
    if( EN_isMatchEnt(bestVd) ) {
      EN_getMatchEnts(bestVd, 0, vlist);
    }

    for (mlistIter = vlist.begin(); mlistIter != vlist.end(); mlistIter++)
    {
      match_vd = mlistIter->second;
      for( j=0; j<V_numEdges(match_vd); j++ ) {
        edge=V_edge(match_vd, j);
        EN_deleteData((pEntity)edge,deref);
        match_vr=E_otherVertex(edge, match_vd);
        if( EN_getDataInt((pEntity)match_vr,deref,&value) )
          EN_modifyDataInt((pEntity)match_vr,deref,loopId+1);
      }
    }
  }

  // apply edge collapse
  if(!match_flag) {  // No Matching
    clps->setCollaps(bestEdgeDel,bestVd,bestVr);
    EN_deleteData((pEntity)bestVd,deref);
    if( bestVd!=vd ) {
      removedEnts.insert(bestVd);
      EN_deleteData((pEntity)vd,deref);
    }

    if( model_type ) pSnap->remove(vd);
  }      
  else {  // Matching
    count=0;
    for (mlistIter = mlist.begin(); mlistIter != mlist.end(); mlistIter++)
    {
      match_edgeDel = mlistIter->second;
      match_vd=match_vds[count];
      match_vr=match_vrs[count];

      match_clps[count]->setCollaps(match_edgeDel, match_vd, match_vr);
      EN_deleteData((pEntity)match_vd,deref);

      if(edgeDel!=match_edgeDel) {
        removedEnts.insert(match_vd);
        //      cout<<" add to removedEnt ("<<match_vd<<")"<<EN_getUid(match_vd)<<endl;
      }
      else
        if( bestVd!=vd ) {
          removedEnts.insert(match_vd);
          //      cout<<" add to removedEnt ("<<match_vd<<")"<<EN_getUid(match_vd)<<endl;
          EN_deleteData((pEntity)match_vr,deref);
      }

      if( model_type ) pSnap->remove(match_vds[count]);

//       if( bestVd!=vd ) {
//      match_vds[count]=match_vd;                        // match_vds indicates bestVds from now on
//      match_vrs[count]=match_vr;
//       }

      count++;
    }
  }

  if(!match_flag) {   // No matching,  push clps to match_clps
    match_clps.clear();
    match_clps.push_back(clps);
    match_vrs.clear();
    match_vrs.push_back(bestVr);
  }

  std::set<pFace> newFaces;
  std::set<pEdge> newEdges;
  std::set<pEdge>::iterator eiter;
  std::set<pFace>::iterator fiter;
  pFace face;

  for(int icount=0; icount<match_clps.size(); icount++) {

    int iflag=0;
    if(icount>0) {

      // check if current bestVd was collapsed in previous operation
      for(int i=0; i<=icount-1; i++)
        if( match_vds[icount]==match_vds[i] ) {
          iflag=1;
          break;
        }

      // check if any new edge will be removed in the coming operation
      pPList vlist;
      std::set<pEdge> tmpEdges;
      for(eiter=newEdges.begin(); eiter!=newEdges.end(); eiter++){
        vlist = E_vertices(*eiter);
        if( PList_inList(vlist, (void*)match_vds[icount]) )
          tmpEdges.insert(*eiter);
        PList_delete(vlist);
      }

      for(eiter=tmpEdges.begin(); eiter!=tmpEdges.end(); eiter++){
        newEdges.erase(*eiter);
      }

      // check if any new face will be removed in the coming operation
      std::set<pFace> tmpFaces;
      for(fiter=newFaces.begin(); fiter!=newFaces.end(); fiter++){
        vlist = F_vertices(*fiter, 1);
        if( PList_inList(vlist, (void*)match_vds[icount]) )
          tmpFaces.insert(*fiter);
        PList_delete(vlist);
      }

      for(fiter=tmpFaces.begin(); fiter!=tmpFaces.end(); fiter++){
        newFaces.erase(*fiter);
      }
    }

    if(iflag)
      continue;
#ifndef MATCHING
    match_clps[icount]->apply(); // apply() in coarsenVertex // yes, it's this guy
#else
      pPList newEds;
      pPList newFcs;
      pPList newRegs;
      match_clps[icount]->apply(&newEds, &newFcs, &newRegs);       // In 2D mesh, newRegs is empty.
      PList_delete(newRegs);

      if( GM_pbc(M_model(pmesh)) ) {
      void *it=0;
      while( edge=(pEdge)PList_next(newEds, &it) )
        newEdges.insert(edge);

      void* it2=0;
      while( face=(pFace)PList_next(newFcs, &it2) )
        newFaces.insert(face);

      }
      PList_delete(newEds);
      PList_delete(newFcs);
#endif

      // allow the remaining vertex to be moved
      EN_deleteData((pEntity)match_vrs[icount],smoothed);
  }  // for(int icount=0; )

  // set up connections between matched new mesh faces/edges based on matched vertices
  if( GM_pbc(M_model(pmesh)) ){

      list<std::pair<int, pEntity> > vlist[2];
      list<std::pair<int, pEntity> >::iterator mlistIter, mlistIter2, mlistIter3;
      list<pEntity> new_elist;
      for( eiter= newEdges.begin(); eiter!=newEdges.end(); eiter++ ){

        int iflag[2];

        if( !EN_isMatchEnt(*eiter) ){
          int gtype = GEN_type(E_whatIn(*eiter));
          for( int i=0; i<2; i ++) {
            iflag[i]=0;
            match_vts[i] = E_vertex(*eiter, i);

            if( EN_isMatchEnt(match_vts[i]) )
              EN_getMatchEnts(match_vts[i], 0, vlist[i]);
            else {
              iflag[i]=1;
  
              /// The first argument in pair is 0 for now, since it works only in serial
              vlist[i].push_back(make_pair(0,match_vts[i]));   
            }
          }

          pVertex v1, v2;
          for (mlistIter = vlist[0].begin(); mlistIter != vlist[0].end(); mlistIter++)
          {
            v1 = mlistIter->second;
            for (mlistIter2 = vlist[1].begin(); mlistIter2 != vlist[1].end(); mlistIter2++)
            {
              v2 = mlistIter2->second;
              edge = E_exist(v1, v2);
              if(edge) {
                pGEntity gent = E_whatIn(edge);
                if( GEN_type(gent)==gtype  && PBC_isPbcOnGEntity(gent) )
                  /// Have to be unique!!! Previous line was: PList_appUnique( new_elist, (void*)edge );
                  new_elist.push_back(edge);
              }
            }
          }

          for(int i=0; i<2; i++)
            if(iflag[i]==1)
              vlist[i].clear();
 
          new_elist.sort();
          new_elist.unique(); 
          /// Not sure exactly which function to use here
          EN_addLocalMatchEnts(new_elist);
        }
      }

    list<std::pair<int, pEntity> > elist[4];
    list<pEntity> flist;          // consider triangle face only
    for( fiter = newFaces.begin(); fiter!=newFaces.end(); fiter++) {

      if( !EN_isMatchEnt(*fiter) ){
        int gtype = GEN_type(F_whatIn(*fiter));
        int iflag[4];

        for(i=0; i<F_numEdges(*fiter); i++) {
          iflag[i]=0;
          edge = F_edge( *fiter, i);
          if( EN_isMatchEnt(edge) )
              EN_getMatchEnts(edge, 0, elist[i]);
          else{
            elist[i].push_back(make_pair(0,edge));
            iflag[i]=1;
            }
          }

          pEdge edges[4];
          for (mlistIter = elist[0].begin(); mlistIter != elist[0].end(); mlistIter++)
          {
            edges[0] = mlistIter->second;
            for (mlistIter2 = elist[1].begin(); mlistIter2 != elist[1].end(); mlistIter2++)
            {
              edges[1] = mlistIter2->second;
              for (mlistIter3 = elist[2].begin(); mlistIter3 != elist[2].end(); mlistIter3++)
              {
                edges[2] = mlistIter3->second;
                face = F_exist(1, edges[0], edges[1], edges[2], 0);
                if(face){
                  pGEntity gent = F_whatIn(face);
                  if( GEN_type(gent)==gtype && PBC_isPbcOnGEntity(gent))
                    ///PList_appUnique( flist, (void*)face );
                    flist.push_back(face);
                }
              }
            }
          }

          for(int i=0; i<F_numEdges(*fiter); i++)
            if(iflag[i]==1)
              elist[i].clear();

          flist.sort();
          flist.unique();

        // assert( PList_size(flist)>1 );
          EN_addLocalMatchEnts(flist);
        }
      }
  }

  // check new mesh edges
  if(!match_flag ) {   // No matching
    for( j=0; j<V_numEdges(bestVr); j++ ) {
      edge=V_edge(bestVr,j);
      if(!EN_okTo(DELETE,(pEntity)edge))
        continue;
      if (E_typeInBL(edge))
        continue;
      if( pSizeField->lengthSq(edge) < lowerLenSqBound ) {
        // need coarsening
        if( !EN_getDataInt((pEntity)edge,deref,&value) ) {
          EN_attachDataInt((pEntity)edge,deref,-1);
          // --- osahni
          // if an old edge is tagged but end vertices have been removed
          // from drVertices then append the vertices and tag them too
          vr=E_otherVertex(edge,bestVr);
          if(!EN_okTo(DELETE,(pEntity)vr))
            continue;
          if (V_typeInBL(vr))
            continue;
          if( !EN_getDataInt((pEntity)vr,deref,&value) )  {
            EN_attachDataInt((pEntity)vr,deref,-1);
            drVertices.push_back(vr);
          }
        }
      } else {
        // do not need coarsening
        if( EN_getDataInt((pEntity)edge,deref,&value) )
          EN_deleteData((pEntity)edge,deref);
      }
    }
  }
  else {    // Matching
    for(int icount=0; icount!=match_vrs.size(); icount++  ) {    //  Here we assume that match_vrs do not overlap match_vds ??????
      match_vr = match_vrs[icount];
      for( int j=0; j<V_numEdges(match_vr); j++ ) {
        edge=V_edge(match_vr,j);
        if(!EN_okTo(DELETE,(pEntity)edge))
          continue;
        if (E_typeInBL(edge))
          continue;
        if( pSizeField->lengthSq(edge) < lowerLenSqBound ) {
          // need coarsening
          if( !EN_getDataInt((pEntity)edge,deref,&value) ) {
            EN_attachDataInt((pEntity)edge,deref,-1);
            vr=E_otherVertex(edge,match_vr);
            if(!EN_okTo(DELETE,(pEntity)vr))
              continue;
            if (V_typeInBL(vr))
              continue;
            if( !EN_getDataInt((pEntity)vr,deref,&value) )  {
              EN_attachDataInt((pEntity)vr,deref,-1);
              drVertices.push_back(vr);
            }
          }
        } else {
          // do not need coarsening
          if( EN_getDataInt((pEntity)edge,deref,&value) )
            EN_deleteData((pEntity)edge,deref);
        }
      }
    }
  }

  if(match_flag) {  // Matching
    for(int i=0; i< match_clps.size(); i++)
      if( match_clps[i]!= clps)
        delete match_clps[i];
  }

  return Flag;
}

      
// need to ensure not creating long edges

int meshAdapt::removeSliverFaces()
{
  pFace face;
  double shp;
  pMeshMod pBestMod;
  pPList tmpList;
  int nmod=0;
  void *iter;

  std::set<pEntity> removed;        
  
  shpMeasure->setDefaultAcptValue();

  std::vector< std::pair<double,pFace> > Fvec;
  //  std::list< std::pair<double,pFace> > Fvec;   

  FIter fit=M_faceIter(pmesh);
  while( face=FIter_next(fit) ) {
    shpMeasure->F_shape(face,0,&shp);
    if( shp < 0.04 )          
      Fvec.push_back(std::make_pair(shp,face));
  }
  FIter_delete(fit);
  std::sort(Fvec.begin(),Fvec.end());

  adaptUtil::Info((int)Fvec.size(),"faces have shape less than 0.04 (removeSliverFaces)\n");

  std::vector< std::pair<double,pFace> >::iterator faceIt;
  // std::list< std::pair<double,pFace> >::iterator faceIt;   
  for(faceIt=Fvec.begin();faceIt!=Fvec.end();++faceIt)  
    {
      face=(*faceIt).second;
    //   if( removed.inList((pEntity)face) ) {
// 	removed.remove((pEntity)face);
      if(removed.find((pEntity)face) != removed.end()) { 
	removed.erase((pEntity)face);
	continue;
      }
      
      if( !handleSliverFace(face,(*faceIt).first,&pBestMod,&tmpList) )
	continue;

      iter=0;
      while( (face=(pFace)PList_next(tmpList,&iter)) ) {
// 	if( !removed.inList((pEntity)face) )
// 	  removed.append((pEntity)face);
//	if(removed.find((pEntity)face) == removed.end())  
	  removed.insert((pEntity)face);
	}
      PList_delete(tmpList);
      pBestMod->apply();  // apply() in removeSliverFaces
      nmod++;
      delete pBestMod;
    }

  adaptUtil::Info(nmod," local modifications applied (removeSliverFaces)");
  return 1;
}


/*
  determine if the given region is a sliver wrt the gievn threshold
  return 1: if it is a sliver
         0: otherwise
*/
int meshAdapt::R_isSliver(pRegion region, double t, double *shp, double upperBoundSq)
{
  *shp=0.;

  if (region->getType() != TET)
    return 0;

  if( ! EN_okTo(DELETE,(pEntity)region) )
    return 0;

  // see if there is relatively short edges
//   if( adaptUtil::R_maxTominLengthSq(region,pSizeField)>10.0 )
//     return 0;

  if(upperBoundSq>0. && adaptUtil::R_countLongLengthSq(region,pSizeField,upperBoundSq)>0)
    return 0;

  // see if shape is bad
  shpMeasure->R_shape(region,shp);
  if( *shp < t )
    return 1;

  return 0;
}


/*
  main routine for parallel element shape correction
*/
#ifdef MA_PARALLEL
int meshAdapt::removeSliverRegions(double shpLowerBound, double upperBoundSq,
				   pmMigrationCallbacks& userLB)
#else
int meshAdapt::removeSliverRegions(double shpLowerBound, double upperBoundSq)
#endif
{
  pRegion region;
  pMeshMod pBestMod;
  pPList tmpList;
  int nmod;
  int cbFlag;
  double shp;
  void *iter, *iter2;

  int nRclps=0;
  int nEclps=0;
  int nEswap=0;
  int nFswap=0;
  int nSpltClps=0;
  int nDSpltClps=0;
  int nEsplt=0;

  std::set<pRegion> removed, newSlivers;
  std::set<pRegion>::iterator SetRgnIt;         
  shpMeasure->setDefaultAcptValue();
  std::vector< std::pair<double,pRegion> > Rvec;
  std::vector< std::pair<double,pRegion> >::iterator pairIt;
  // std::list< std::pair<double,pRegion> > Rvec;          
  // std::list< std::pair<double,pRegion> >::iterator pairIt;

  /* -------------------------------------------------
     first of all, detect all sliver regions
     and put them into the std::vector
     --------------------------------------------------*/

  RIter rit=M_regionIter(pmesh);
  while( region=RIter_next(rit) ) 
  {
    if ( R_isSliver(region,shpLowerBound,&shp, upperBoundSq) )
      Rvec.push_back(std::make_pair(shp,region)); 
  }
  RIter_delete(rit);


  /*----------------------------------------------
    process the sliver region list
    ----------------------------------------------*/
  int applied=1;
  int counter=0, counterMax=10;

#ifdef MA_PARALLEL
  while ( P_getMaxInt(applied) ) {
#else
  while (applied) {
#endif
    counter++;
    if(counter>counterMax)
      break;
    applied=0;
    nmod=0;

    std::sort(Rvec.begin(),Rvec.end());
    int tmp=P_getSumInt((int)Rvec.size()); 

#ifdef DEBUG
    if (P_pid()==0) 
      cout<<"\n* iter "<<counter<<": sliver regions should be processed: "
          <<tmp<<endl;
#endif

#ifdef MA_PARALLEL
    std::list<pEntity> rgNextCB;
//    AP_send_begin();
    IPComMan *CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int msg_size = sizeof(classificationPack);
    CM->set_fixed_msg_size(msg_size);
#endif

    for(pairIt=Rvec.begin();pairIt!=Rvec.end();++pairIt)
    {
      region=(*pairIt).second;

      if(removed.find((pEntity)region) != removed.end()) { 
	removed.erase((pEntity)region);
	continue;
      }

      // try boundary region collapse. apply it if possible
#ifndef MA_PARALLEL   
      if( clpsBdryTet((*pairIt).second)==1 ) { 
	nmod++; 
	nRclps++;
	continue; 
      }
#endif

      // evaluate all other possible mesh modifications
      cbFlag=swapOrsplitPbTet(pairIt->second, pairIt->first, &pBestMod);
#ifdef MA_PARALLEL
      if( cbFlag== -2 ) 
      { 
        rgNextCB.push_back(region);
      }
#endif
      if( cbFlag != 1 ) 
	continue;

      // apply the mesh modification and update three lists
      applied=1;
      pBestMod->getAffectedRgns(&tmpList);
      iter=0;
      while( (region=(pRegion)PList_next(tmpList,&iter)) )
      {
//	if(removed.find((pEntity)region) == removed.end())    
	  removed.insert((pEntity)region);
	  newSlivers.erase(region);
          
#ifdef MA_PARALLEL
	  updateRgnList(region,rgNextCB);
#endif
      }
      PList_delete(tmpList);
      pBestMod->apply(&tmpList);  // apply() in removeSliverRegions
      iter=0;
      while( (region=(pRegion)PList_next(tmpList,&iter)) ) 
      {
	if ( R_isSliver(region,shpLowerBound,&shp,upperBoundSq) )
        {
	  newSlivers.insert(region);
        }
      }

      pVertex vtx;
      std::set<pRegion> outerCavity;
      iter=0;
      while( (region=(pRegion)PList_next(tmpList,&iter)) ) 
      {
        pPList rverts = R_vertices(region,1);
        int numRVerts = PList_size(rverts);
        for(int iRVert=0; iRVert<numRVerts; iRVert++) 
        {
          vtx = (pVertex)PList_item(rverts,iRVert);
          pPList vregs = V_regions(vtx);
          iter2=0;
          while( (region=(pRegion)PList_next(vregs,&iter2)) )
          {
            outerCavity.insert(region);
          }
          PList_delete(vregs);
        }
        PList_delete(rverts);
      }

      while( (region=(pRegion)PList_next(tmpList,&iter)) )
        outerCavity.erase(region);
      PList_delete(tmpList);

      for( SetRgnIt = outerCavity.begin(); SetRgnIt != outerCavity.end(); ++SetRgnIt ) 
      {
        region = *SetRgnIt;
        if ( R_isSliver(region,shpLowerBound,&shp,upperBoundSq) )
        {
//          if (std::find(rgNextCB.begin(),rgNextCB.end(),region) == rgNextCB.end())
            newSlivers.insert(region);
        }
      }
      outerCavity.clear();

#ifdef DEBUG
      switch( pBestMod->type() ) {
      case ECOLAPS: nEclps++; break;
      case ESPLIT: nEsplt++; break;
      case SPLTCLPS: nSpltClps++; break;
      case RCOLAPS_2: nDSpltClps++; break;
      case FSWAP:  nFswap++; break;
      case ESWAP:  nEswap++; break;
      default: 
	adaptUtil::Error("%something wrong");
      }
#endif     
      nmod++;
      delete pBestMod;
    }  // end of the for-loop

#ifdef MA_PARALLEL
    CM->finalize_send();

    fromMeshTools::syncClassification(pmesh);
    mMigrateForShapeCorrect(rgNextCB,newSlivers,userLB,shpLowerBound);
#endif

#ifdef DEBUG
  nmod=P_getSumInt(nmod);
  adaptUtil::Info(nmod,"local modifications applied");
#endif

    // update the sliver element list
    Rvec.clear();
    for( SetRgnIt = newSlivers.begin(); SetRgnIt != newSlivers.end(); ++SetRgnIt )
    {
      region = *SetRgnIt;
      if(R_isSliver(region,shpLowerBound,&shp,upperBoundSq))
      {
        Rvec.push_back(std::make_pair(shp,region));
      }
    }
    newSlivers.clear();
    removed.clear();
    
  }

#ifdef DEBUG
    adaptUtil::Info("nRclps=",nRclps);
    adaptUtil::Info("nEclps=",nEclps);
    adaptUtil::Info("nEswap=",nEswap);
    adaptUtil::Info("nFswap=",nFswap);
    adaptUtil::Info("nDSplitClps=",nDSpltClps);
    adaptUtil::Info("nSplitClps=",nSpltClps);
    adaptUtil::Info("nEsplit=",nEsplt);
#endif

  return 1;
}

int meshAdapt::clpsBdryTet(pRegion region)
{
  regionCollapsMod rclps(pmesh,pSizeField,region);
  if( model_type != 2 )  
    rclps.setModelType(NOPARAM);
  if( !rclps.topoCheck() )  
    return 0;
  if( !rclps.geomCheck() ) // geomCheck in clpsBdryTet
    return 0;

  // more considerations are needed in case of  double splitting and collapse
  // since it changes regions other than the region being considering
  // all other regions connected to the interior edge being split
  // should have positive volume when the vert is moved back
  if( rclps.getCfg()==2 ) {
    pEdge reclassifyEdge, deleteEdge;
    reclassifyEdge=rclps.getEdgeToReclassify();
    deleteEdge=R_gtOppEdg(region,reclassifyEdge);
    if(E_whatInType(deleteEdge)==Gedge) {
      // double edge splitting and collapse will be applied
      // all entities connected to vert should be valid when vert moving back
      return 0;
//  #if 0
//        double midxyz[3], rxyz[4][3];
//        pPList eRgns=E_regions(reclassifyEdge);
//        pVertex otherVt=E_otherVertex(reclassifyEdge,vert);
//        pPList verts;
//        pRegion rgn;
//        int i;
//        adaptUtil::centroidOfMEdge(reclassifyEdge,midxyz);
//        iter=0;
//        while( rgn=(pRegion)PList_next(eRgns,&iter) ) {
//  	if( rgn==region )
//  	  continue;
//  	verts=R_vertices(rgn,1);
//  	temp_ptr=0;
//  	ok=1;
//  	i=0;
//  	while( vertex=(pVertex)PList_next(verts,&temp_ptr) ) {
//  	  if( vertex==otherVt )
//  	    { rxyz[i][0]=midxyz[0]; rxyz[i][1]=midxyz[1]; rxyz[i][2]=midxyz[2]; }
//  	  if( vertex==vert )
//  	    { rxyz[i][0]=ori[0]; rxyz[i][1]=ori[1]; rxyz[i][2]=ori[2]; }
//  	  else
//  	    V_coord(vertex, rxyz[i]);
//  	  i++;
//  	}
//  	PList_delete(verts);
//  	if( XYZ_volume(rxyz) < M_getTolerance() )
//  	  { ok=0; break; }
//        }
//        PList_delete(eRgns);
//        if( ok==0 )
//  	continue;
//  #endif
    }
  }

  if(rclps.getCfg()==1 ) {
    adaptUtil::Info("region collapse (cfg=1) can be applied\n");
    return 0;
  }

  rclps.apply();  // apply in clpsBdryTet
  return 1;
}

/*
  return 1: a local mesh modification is determined
         0: error
        -1: interior and no local mesh modfication possible
        -2: next to partition boundary and no local mesh modfication possible
 */
int meshAdapt::swapOrsplitPbTet(pRegion region, double maxRank, pMeshMod *ppBestMod)
{  
  pEntity ents[4];
  double area[4], intXYZ[3], exyz[2][3], t;
  pFace face;
  pEdge edge;
  pVertex vertex;
  int i, ind;

  int cbFlag=-1;

  *ppBestMod=0;
  maxRank=IMPROVE_RATIO*maxRank;

  edgeSwapMod eswp(pmesh,pSizeField,shpMeasure,result);
  eswp.setCallback(function_CB,userData_CB);
  if( model_type != 2 )  
    eswp.setModelType(NOPARAM);
  if( checkVolume ) 
    eswp.setCheckVolume(dV_limit,dA_limit);

  EsplitClpsMod comp(pmesh,pSizeField,shpMeasure,result);
  comp.setCallback(function_CB,userData_CB);
  if( model_type != 2 )  
    comp.setModelType(NOPARAM);
  if( checkVolume ) 
    comp.setCheckVolume(dV_limit,dA_limit);

  face=R_face(region,0);
  vertex=R_fcOpVt(region,face);
  // the areas are computed in physical space, we can not use them
  ind=adaptUtil::getTetInfo(region,face,vertex,1,ents,area,intXYZ);
  if( !ind ) 
    return 0; 

  // two large dihedral angles -> key problem: two mesh edges
  if( ind==3 || ind==5 || ind==6 ) 
    {	
      // check edge swapping
      for( i=0; i<2; i++ ) {
#ifdef MA_PARALLEL
	if ( EN_onCB((pEntity)ents[i]) )
	  { cbFlag=-2; continue; }
#endif
	eswp.setSwapEdge((pEdge)ents[i]);
	adaptUtil::evalEswp(&eswp,ppBestMod,&maxRank,lowerLenSqBound);
      }
      if( *ppBestMod ) return 1;
      
      // check split+collapse
#ifndef MA_PARALLEL
      for( i=0; i<2; i++ ) {
	comp.reset((pEdge)ents[i],(pFace)ents[i+2]);
	adaptUtil::evalSpltClps(&comp,ppBestMod,&maxRank,upperLenSqBound);
      }
      if( *ppBestMod ) return 1;
#endif
      
      // check two-spliting + a collapsing
      // split 
      for( i=0; i<2; i++ ) {
	if( E_whatInType((pEdge)ents[i]) != Gregion )
	  continue;
#ifdef MA_PARALLEL
	if ( EN_onCB((pEntity)ents[i]) )
	  continue; 
#endif
	edgeSplitMod esplt(pmesh,pSizeField,shpMeasure,result);
	esplt.setCallback(function_CB,userData_CB);
	if( checkVolume ) 
	  esplt.setCheckVolume(dV_limit,dA_limit);
	if( model_type != 2 )  
	  esplt.setModelType(NOPARAM);
	adaptUtil::centroidOfCavity2((pEdge)ents[i],intXYZ);

	// need to ensure the projection of intXYZ onto ents[i]
	V_coord(E_vertex((pEdge)ents[i],0),exyz[0]);
	V_coord(E_vertex((pEdge)ents[i],1),exyz[1]);
	t = adaptUtil::ParOnLinearEdge(exyz,intXYZ);
	if( t>1 || t<0 )
	  continue;
	esplt.setSplitEdge((pEdge)ents[i]);
	esplt.setSplitPos(intXYZ,0);
	if( esplt.topoCheck() && esplt.geomCheck() ) {  //geomCheck in swapOrsplitPbTet
          if( esplt.sizeCheck() ) {
            if( result->getMinSize() > lowerLenSqBound &&
                result->getWorstShape() > IMPROVE_RATIO*maxRank) {
              maxRank = result->getWorstShape();
              if(*ppBestMod)
                delete *ppBestMod;
              *ppBestMod = new edgeSplitMod(esplt);
            }
          }
	}
      }
      if( *ppBestMod ) return 1;

    }
  // end of two large dihedral angle cases

  else 
    {
      // check edge swaps
      for( i=0; i<3; i++ ) {
	edge=F_edge((pFace)ents[0],i);
#ifdef MA_PARALLEL
	if ( EN_onCB((pEntity)edge) )
	  { cbFlag=-2; continue; }
#endif
	eswp.setSwapEdge(edge);    
	adaptUtil::evalEswp(&eswp,ppBestMod,&maxRank,lowerLenSqBound);
      }
      
#ifdef MA_PARALLEL
      if ( EN_onCB(ents[0]) )
	cbFlag=-2;
      else {
#endif      
      // check face swap
      faceSwapMod fswp(pmesh,pSizeField,shpMeasure,result);
      fswp.setCallback(function_CB,userData_CB);
      if( model_type != 2 ) 
	fswp.setModelType(NOPARAM);
      if( checkVolume ) 
	fswp.setCheckVolume(dV_limit,dA_limit);

      fswp.setSwapFace((pFace)ents[0]);

      // avoid TWO2TWO case in face swap mode
      // for non-BL faces connected to interface edges
      // note : we constrain such faces but it could be
      // created in the process of removing slivers
      int fSwpTwo2TwoOk = 1;
      if(!EN_isBLEntity(ents[0])) {
        for(i=0; i<3; i++) {
          edge = F_edge((pFace)ents[0],i);
          if( EN_isBLEntity((pEntity)edge) &&
              E_atBLInterface(edge) ) {
            fSwpTwo2TwoOk = 0;
            // fSwpTwo2TwoOk = F_checkForTwo2TwoSwap((pFace)ents[0],edge);
          if(!fSwpTwo2TwoOk)
            break;
          }
        }
      }

      if(fSwpTwo2TwoOk)
        if( fswp.topoCheck() && fswp.geomCheck()) //geomCheck in swapOrsplitPbTet
          if( fswp.getResultHolder()->getWorstShape() > IMPROVE_RATIO*maxRank)
            {
              if(*ppBestMod)
                delete *ppBestMod;
              *ppBestMod = new faceSwapMod(fswp);
            }
#ifdef MA_PARALLEL
      }
#endif
      if( *ppBestMod )
	return 1;
      
      // check split+collapse
#ifndef MA_PARALLEL
      comp.reset((pEdge)ents[1],(pFace)ents[2]);
      if( adaptUtil::evalSpltClps(&comp,ppBestMod,&maxRank,upperLenSqBound) )
	return 1;
#endif
    }
  // end of three large dihedral angles
  
  return cbFlag;
}

int meshAdapt::handleSliverFace(pFace face, double maxRank, pMeshMod *ppBestMod, 
				pPList *affectedFcs)
{
  pEdge edge, longestE;
  pVertex vd, vr;
  double ratio;
  int i, j;

  *ppBestMod=0;

  maxRank=IMPROVE_RATIO*maxRank;

  edgeSwapMod eswp(pmesh,pSizeField,shpMeasure,result);
  eswp.setCallback(function_CB,userData_CB);
  if( model_type != 2 )  
    eswp.setModelType(NOPARAM);
  if( checkVolume ) 
    eswp.setCheckVolume(dV_limit,dA_limit);

  if ( !adaptUtil::F_longestEdge(pSizeField,face,&longestE,&ratio) )
    adaptUtil::Warning("problem in finding the longest edge");
  eswp.setSwapEdge(longestE);
  adaptUtil::evalEswp(&eswp,ppBestMod,&maxRank,lowerLenSqBound); 

  edgeCollapsMod clps(pmesh,pSizeField,shpMeasure,result);
  clps.setCallback(function_CB,userData_CB);
  if( model_type != 2 ) 
    clps.setModelType(NOPARAM);
  if( checkVolume ) 
    clps.setCheckVolume(dV_limit,dA_limit);

  for( i=0; i<3; i++ ) 
    {
      edge=F_edge(face,i);
      if( edge==longestE ) 
	continue;
      for( j=0; j<2; j++ ) 
	{
	  vd=E_vertex(edge,j);
	  vr=E_vertex(edge,(j+1)%2);
	  clps.setCollaps(edge,vd,vr); 
	  adaptUtil::evalEclps(pSizeField, &clps, ppBestMod, &maxRank,upperLenSqBound);
	}
    }

  if( *ppBestMod ) 
    {
      switch( (*ppBestMod)->type() ) { 
      case ECOLAPS:
	vd=((edgeCollapsMod *)(*ppBestMod))->vertD();
	*affectedFcs=V_faces(vd);
	break;
      case ESWAP:
	*affectedFcs=E_faces(longestE);
	break;
      }
      return 1;
    }

//  #ifdef MVTK
//    adaptUtil::mvtkShowCavity(edge);
//  #endif
  //  printf("   not able to eliminate a sliver face\n");
  return 0;
}

/* 
   optimize connectivity by edge swaps 
   Created: 04/06/01   X.R. Li
*/
int meshAdapt::optimize(double upperBoundSq)
{
  // apply edge swap to improves worst shape  
  EIter eit_2=M_edgeIter(pmesh);
  int nswap=0;
  double mtol=M_getTolerance();
  double oriWorst;
  pPList rlist;
  pEdge edge;

  edgeSwapMod eswp(pmesh,pSizeField,shpMeasure,result);
  eswp.setCallback(function_CB,userData_CB);
  if( model_type != 2 ) 
    eswp.setModelType(NOPARAM);

  //  printf(" totol # of edges: %d\n",M_numEdges(pmesh));
  int ne=M_numEdges(pmesh);
  int i=0;
  shpMeasure->setDefaultAcptValue();
  while( edge=EIter_next(eit_2) ) 
  {  
    if( i>ne ) break;
    i++;
    if( !EN_okTo(DELETE,(pEntity)edge) )
      continue;
    rlist=E_regions(edge);
    if( PList_size(rlist)<6 ) {
      
      eswp.setSwapEdge(edge);
      if( eswp.topoCheck() ) { 
	if( eswp.geomCheck() ) { // geomCheck in optimize
	  
  	  eswp.sizeCheck();
  	  if( result->getMaxSize()>upperBoundSq )
  	    continue;
 
	  oriWorst=adaptUtil::E_worstShp(shpMeasure,rlist,edge);
	  if( oriWorst <mtol ) 
	    {
	      adaptUtil::Warning("flat elements (meshAdapt::optimize())");
	      if( result->getWorstShape() > (mtol + oriWorst) ) 
		{ 
		  eswp.apply();
		  nswap++;
		}
	    }
	  else if( result->getWorstShape() > 1.2*oriWorst ) //IMPROVE_RATIO*oriWorst )
	    {
	      eswp.apply();
	      nswap++;
	    }
	}
      }
    }
    PList_delete(rlist);
  }
  EIter_delete(eit_2);
  adaptUtil::Info(nswap,"edge swap are performed");

  return nswap;
}


void meshAdapt::cleanSmoothFlag()
{
  VIter vit=M_vertexIter(pmesh);
  pVertex vt;
  while( (vt=VIter_next(vit)) )
    EN_deleteData((pEntity)vt,smoothed);
  VIter_delete(vit);
}


// return 1: moved
//        0; remain the same
int meshAdapt::moveVertex(pVertex vt, double threshdSq, double tar[3], double *worstshp)
{
  double ori[3], max, min;
  int flag=0;

  if( ! getTarget819(vt,tar) )
    return 0;

  V_coord(vt,ori);
  adaptUtil::move_vertex(vt,tar);

  adaptUtil::maxminEdgeLength(pSizeField,vt,&max,&min);
  if( max < threshdSq && min > lowerLenSqBound ) {
    *worstshp = adaptUtil::V_worstShp(shpMeasure,vt);
    if( *worstshp != 0.0 )
      flag=1;
  }

  adaptUtil::move_vertex(vt,ori);
  return flag;
}


// give a vertex connected to at least one short edge
// suggest a target location
int meshAdapt::getTarget819(pVertex vt, double target[3])
{
  double Pxyz[3], Pixyz[3], vec[3];
  double ltSq, k;
  pEdge edge;
  pVertex otherVt;
  int i,j,nv;

  if(M_numRegions(pmesh)==0) {
    if( V_whatInType(vt)!=Gface )
      return 0;
  }
  else if( V_whatInType(vt)!=Gregion )
    return 0;

  for( j=0; j<3; j++ )
    target[j]=0;

  V_coord(vt,Pxyz);
  nv=0;
  for( i=0; i<V_numEdges(vt); i++) {
    edge=V_edge(vt,i);
    ltSq = pSizeField->lengthSq(edge);

    if( ltSq < lowerLenSqBound ) {
      nv++;
      otherVt=E_otherVertex(edge,vt);
      V_coord(otherVt,Pixyz);
      diffVt(Pxyz,Pixyz,vec);
      k =1./sqrt(ltSq);
      for( j=0; j<3; j++ )
        target[j] += Pixyz[j] + vec[j]*k;
    }
  }

  if( nv>0 )
    for( j=0; j<3; j++ )
      target[j] /= (double)nv;

  return nv;
}


/*
// procedure of laplace smoothing
//   threshdSq: the maximum transformed edge length square allowed to created
//              threshdSq==0 means NO threshold and NO size field 
//   flag:  1: respect smooth tag "smoothed"
int meshAdapt::Laplace(double threshdSq, int flag)
{
  pVertex vt;
  double cen[3];
  int value;
  VIter vit=M_vertexIter(pmesh);
  while( (vt=VIter_next(vit)) ) {
    if( !EN_okTo(DELETE,(pEntity)vt) )
      continue;
    if(M_numRegions(pmesh)==0) {
      if( V_whatInType(vt)!=Gface )
	continue;
    }
    else if( V_whatInType(vt)!=Gregion ) 
      continue;
    if( flag ) {
      if( EN_getDataInt((pEntity)vt,smoothed,&value) && value==1 )
	continue;
      EN_attachDataInt((pEntity)vt,smoothed,1);
    }
    adaptUtil::centroidOfCavity(vt,cen);
    toOptimal(vt,cen,threshdSq);
  }
  VIter_delete(vit);
  return 1;
}


void meshAdapt::toOptimal(pVertex vt, double opt[3], double threshdSq)
{
  double ori[3];
  int i,j,flag=1;
  std::vector<pFace> faces;
  double oriWorst=adaptUtil::V_worstVolumeRatio(vt,&faces);
  double r, maxLenSq, minLenSq;
  double mtol=M_getTolerance();

  V_coord(vt,ori);
  for(j=0;j<3;j++) {
    // if vt is already the center
    if( XYZ_distance2(opt,ori)<mtol )
      break;

    adaptUtil::move_vertex(vt,opt);
    r=adaptUtil::V_worstVolumeRatio(vt,&faces);

    // moving to optimal location will not improve volume ratio 
    // move it if increasing shape
    if( ABS(oriWorst-r) < mtol ) {
      adaptUtil::move_vertex(vt,ori);
      oriWorst=adaptUtil::V_worstShp(shpMeasure,vt);
      adaptUtil::move_vertex(vt,opt);
      if( adaptUtil::V_worstShp(shpMeasure,vt) > oriWorst )
	flag=0;
      break;
    }

    // move to improve volume ratio
    if( r+mtol<oriWorst && r!=-1 ) {
      if( threshdSq != 0 ) {
	adaptUtil::maxminEdgeLength(pSizeField,vt,&maxLenSq, &minLenSq);
	if( maxLenSq<threshdSq )
	  {flag=0;break;}
      } else
	{ flag=0;break; }
    }

    // compute a location to "loc"
    for(i=0; i<3; i++)
      opt[i] = 0.5*(opt[i]+ori[i]);
  }

  if( flag ) 
    adaptUtil::move_vertex(vt,ori);
  else if( CB_move ) {
    V_coord(vt,opt);
    adaptUtil::move_vertex(vt,ori);
    adaptUtil::move_vertex(vt,opt,CB_move,userData_CB_move);
  }

  return;
}


int meshAdapt::getTarget816(pVertex vt, double target[3])
{
  double Pixyz[3];
  double alpha, sigma;
  pEdge edge;
  pVertex otherVt;
  int i,j;

  if( V_whatInType(vt)!=Gregion )
    return 0;

  sigma=0;
  for( j=0; j<3; j++ )
    target[j]=0;

  for( i=0; i<V_numEdges(vt); i++) {
    edge=V_edge(vt,i);
    alpha = 1./(pSizeField->lengthSq(edge));
    sigma += alpha;
    otherVt=E_otherVertex(edge,vt);
    V_coord(otherVt,Pixyz);
    for( j=0; j<3; j++ )
      target[j] += Pixyz[j]*alpha;     
  }
  
  for( j=0; j<3; j++ )
    target[j] /= sigma ;

  return 1;
}
*/
