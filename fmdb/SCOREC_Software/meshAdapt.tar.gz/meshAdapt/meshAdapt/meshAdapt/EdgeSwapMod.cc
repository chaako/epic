#include "EdgeSwapMod.h"
#include "AdaptUtil.h"
#include "templateUtil.h"
#include "Eswap.h"
#include "Macros.h"
#include "fromMeshTools.h"
#include "MeshAdjTools.h"
#include "PList.h"
#include <stdio.h>
#include <iostream>
using std::cout;
using std::endl;
using std::cerr;

#ifdef CURVE
#include "curveUtil.h"
#include "curveMesh.h"
using namespace adaptUtil;
using namespace curveUtil;
#endif

#include "BLUtil.h"
#include "FMDB_cint.h"
#include "mEntity.h"

#ifdef MVTK
#include "mvtk.h"
#endif

#ifdef MA_PARALLEL
#include "FMDB_Internals.h"
#endif

/*
  Modification of a given a vertex motion followed by a given edge swap.
  The associated local mesh is one/two polyhedron(s).

  In evaluation, u must call the functions in an order as follows
    topoCheck();
    geomCheck();   -> check geometric similarity and calculate shape info
    sizeCheck();   -> calculate size info


  To perform the modification, call routine apply();  


  return 1: TRUE or SUCCESS
         0: FALSE or FAIL

  History: 10/05/99  Created. 
           03/07/01  Add valid(), worstShape(), maxminEdgeLength()  
	   06/18/01  add sizeCheck() 
	   08/14/01  add the option to control volume conservation
	   09/26/01  deny the edge swap if it creates an edge spanning more than 
                     MAX_PERIODIC_SPAN*period;    
           04/12/02  support 2D application and evaluation for AOMD 
*/

int edgeSwapMod::topoCheck() 
{    
  if (!EN_okTo(SWAP,(pEntity)edge)){
    return 0;
  }
#ifdef MA_PARALLEL
  if( EN_onCB((pEntity)edge) ){
    return 0;
    
  }
#endif

  /// Can't handle cases involving any topology other than tets
  int iValidRgn = 1;
  pVertex pVertexVtx[3] = {E_vertex(edge, 0), E_vertex(edge, 1), vertMv};
  pRegion pRegionRgn;
  int iVtxNum = 2;
  if (vertMv)
    iVtxNum = 3;
  for (int iVtx = 0; iVtx < iVtxNum; ++iVtx)
  {
    pPList vregs = V_regions(pVertexVtx[iVtx]);
    for (int iRgn = 0; iRgn < PList_size(vregs); ++iRgn)
    {
      pRegionRgn = (pRegion)PList_item(vregs, iRgn);
      if (pRegionRgn->getType() == PYRAMID)
      {
        iValidRgn = 0;
        PList_delete(vregs);
        break;
      }
    }
    if (iValidRgn)
      PList_delete(vregs);
    else
      break;
  }
  if (!iValidRgn)
    return 0;

  n=E_numSwpCfg(edge);
  if(!n) 
    return 0;
  return 1;
}

int edgeSwapMod::geomCheck()
{ 
  pMSize pmt[4];
  pRegion region;
  pVertex vt, vertex;
//  pPList verts;
  std::vector<pVertex> *verts;
  double origin[3], xyz[4][3];
  double shape_1, optimum, worst;
  int num, i, j, k, flag;
  void *temp;

  if ( n==-1 )
    std::cout<<"Error: please do topoCheck() before geomCheck()"<<endl;
  
  // check parametric span if on periodic model face
  if( model_type==PARAM ) {
    if( !adaptUtil::E_swpCheckPer(edge) )
      return 0;
  }

  results->reset();

  // this is not true if case we have surface and volume mesh together
  if( M_numRegions(mesh)==0 ) 
    return geomCheck2D();

  if( vertMv ) {
    // make the move
    V_coord(vertMv,origin);
    adaptUtil::move_vertex(vertMv,target);

    // determine the validity of tets hooked on the moving vertex but not in
    // the polyhedron associated with swap
    // Although the validity requirement is only positive volume, we calculate 
    // element shape here to avoid repeated calculation

    pPList vrlist;
    if(EN_isBLEntity((pEntity)vertMv)) {
      if(!V_atBLInterface(vertMv)) {
        cout<<"\nError in faceSwapMod::geomCheck()..."<<endl;
        cout<<"vertMv is BL entity but not at BL interface"<<endl;
        exit(0);
      }

      vector<pRegion> nonBLRegs;
      V_nonBLRegions(vertMv, nonBLRegs);

      vrlist=PList_new();
      for (int iReg = 0; iReg < nonBLRegs.size(); ++iReg)
        PList_append(vrlist,(void*)nonBLRegs[iReg]);

      double f_xyz[3][3], v01[3], v02[3], nor[3];;
      pMSize f_pmt[3];
      pFace face;
      vector<pFace> vLyrFaces;
      V_layerFaces(vertMv, vLyrFaces); 
      pPList fverts;
      int numFaces = vLyrFaces.size();
      for(int iFace=0; iFace<numFaces; iFace++) {
        face = vLyrFaces[iFace];

        fverts = F_vertices(face,1);

        // compute the original normal
        temp = 0; i = 0;
        while (vertex = (pVertex)PList_next(fverts, &temp)) {
          if(vertex==vertMv) {
            f_xyz[i][0]=origin[0]; f_xyz[i][1]=origin[1]; f_xyz[i++][2]=origin[2];
          }
          else
            V_coord(vertex,f_xyz[i++]);
        }
        diffVt(f_xyz[1],f_xyz[0],v01);
        diffVt(f_xyz[2],f_xyz[0],v02);
        crossProd(v01,v02,nor);

        temp = 0; i = 0;
        while (vertex = (pVertex)PList_next(fverts, &temp)) {
          f_pmt[i]=pSizeField->getSize(vertex);
          V_coord(vertex,f_xyz[i++]);
        }
        PList_delete(fverts);

        // check validity and calculate shape
        if(!shpMeasure->XYZ_shape(f_xyz, f_pmt, nor, &shape_1)) {
          PList_delete(vrlist);
          adaptUtil::move_vertex(vertMv,origin);
          return 0;
        }
      }
    }
    else
      vrlist=V_regions(vertMv);

    temp=0;
    while(region=(pRegion)PList_next(vrlist,&temp)) {
      if(R_inClosure(region,(pEntity)edge)) continue;

      // calculate shape and check acceptability
      if( ! shpMeasure->R_shape(region, &shape_1) ) {
	adaptUtil::move_vertex(vertMv,origin); 
	PList_delete(vrlist); 
	return 0;
      }

      if( shape_1 < results->getWorstShape() )
	results->setWorstShape(shape_1);
    }
    PList_delete(vrlist);
  }

  // calculate the volume of original polyhedron w.r.t. this edge swap
  double origVol=0, newVol;
  if( checkVolume && E_whatInType(edge)==Tface ) {
    pPList erlist = E_regions (edge);
    temp=0;
    while( region = (pRegion)PList_next(erlist, &temp) )
      origVol += R_volume (region);
    PList_delete (erlist);
  }
  
  // determine the validity of tets associated with swap


  // loop over all possible configurations, find the one of best element shape
  optimum=0.0;
#ifdef CURVE
  if(quadratic == false) {
#endif
  for(i=0;i<n;i++) {
    newVol =0;
    verts=fromMeshTools::E_swpCfgVerts(edge,i);
    if( !verts ) 
      continue;
    //num=PList_size(verts)/4;
    num=verts->size()/4;

    // this is a special case (see E_swp2Fac.c in meshTools) 
    // It is the same as 2->2 RegionCollapse operator 
    // Always can be applied     -li 8/14/01
    if( !num ) {
      delete verts;
      break;
    }

    // loop over regions that will be created for this specific configure
    // calculate the worst shape
//    temp=0; 
    flag=0;
    worst=BIG_NUMBER;
    std::vector<pVertex>::iterator vtIter=verts->begin();
    for(j=0;j<num;j++) {
      // get vertex coordintes assuming the vertex moved
      for(k=0;k<4;k++) {
 //       vt=(pVertex)PList_next(verts,&temp);
        vt=*vtIter;
        vtIter++;
	V_coord(vt,xyz[k]);
	pmt[k]=pSizeField->getSize(vt);
      }

      // compute the sum volume of the new regions
      if( checkVolume && E_whatInType(edge)==Tface ) 
	newVol += XYZ_volume (xyz);

      // calculate shape and check acceptability
      if( ! shpMeasure->XYZ_shape(xyz, pmt,&shape_1) )
	{ flag=1; break; }

      // find the worst element shape of this configuration
      if(shape_1 < worst)   
	worst=shape_1;
    }
    delete verts;

    if(flag) 
      continue;
      
    // OK, we have a valid configuration here

    // see if it will cause volume change too much
    if( checkVolume && E_whatInType(edge)==Tface ) 
      if( ABS(origVol-newVol)/origVol > dV_limit ) 
	continue;
    
    
    // if it is the one with "the worst shape" best so far, remember it
    if(worst>optimum)
      {  optimum=worst;  conf=i; }
  }

#ifdef CURVE
  }
  else if(quadratic == true) {
      // for quadratic tetrahedral meshes (10-node tet elements)
    double xyz[10][3];
    pVertex v[4];
    crShpInfo csi;

    if (EN_whatInType (edge)==Tface) {
      // for an edge classified on a model face to be swapped,
      // the only new edge node is on the model face
      pGFace gface =(pGFace)EN_whatIn (edge);
      if(n != 1)
	return 0;
      
      for(i=0;i<n;i++) {
	// there is only one configuration possible
	verts=fromMeshTools::E_swpCfgVerts(edge,i);
	if( !verts ) 
	  continue;
	num=verts->size()/4;
	
	if( !num || num !=2) {
	  delete verts;
	  break;
	}
	// loop over regions that will be created for this specific configure
	// calculate the worst shape
	flag=0;
	worst=BIG_NUMBER;
	std::vector<pVertex>::iterator vtIter=verts->begin();
	for(j=0;j<num;j++) {
	  // get the 4 vertex coordintes
	  for(k=0;k<4;k++) {
	    vt=*vtIter;
	    vtIter++;
	    V_coord(vt,xyz[k]);
	    pmt[k]=pSizeField->getSize(vt);
	    v[k] =vt;
	  }
	  
  
	  // get the six edge nodal coordinates
	  int j0, j1;
	  for (int l=0; l<6; l++) {
	    switch (l) {
	    case 0:
	      j0 =0; j1 =1;
	      break;
	    case 1:
	      j0 =1; j1 =2;
	      break;
	    case 2:
	      j0 =2; j1 =0;
	      break;
	    case 3:
	      j0 =0; j1 =3;
	      break;
	    case 4:
	      j0 =1; j1 =3;
	      break;
	    case 5:
	      j0 =2; j1 =3;
	      break;
	    }
	      pEdge e;
	    if ((e=E_exists(v[j0], v[j1]))) {
	      // for the existing edges, get their mid-side nodes
	      E_bezierCtrlPt(e, xyz[k++]);
		
	    }
	    else {
	      // for the new edge, compute its mid-side node
	      if (!mid_xyz_evaluated) {
		// compute the coordinate of the mid-side node
		mid_xyz_evaluated =true;
		
		if (model_type=PARAM) {
		  // in case of a parametric model
		  double params[2][2];

		  // compute the parametric values for the vertices
		  for (int j=0; j<2; j++) {
		    pVertex vertex =j? v[j0]:v[j1];

		    switch (EN_whatInType (vertex)) {
		    case Tvertex:
		      // the vertex is on a model vertex
		      GF_vertexReparam(gface, (pGVertex)EN_whatIn(vertex), params[j]);
		      break;
		      case Tedge:
		      // the vertex is on a model edge
		      GF_edgeReparam (gface, (pGEdge)EN_whatIn(vertex), 
				      P_param1(V_point(vertex)), 1, params[j]);
		      break;
		    
		    case Tface:
		      // the vertex is on a model face
		      P_param2 (V_point (vertex), &(params[j][0]), &(params[j][1]), 0);
		      break;
		    }
		  }

		  // evaluate the physical coordinates by parametic value
		  double mid_params[2];
		  mid_params[0] =(params[0][0]+params[1][0])/2.0;
		  mid_params[1] =(params[0][1]+params[1][1])/2.0;
		  GF_point(gface, mid_params, mid_xyz);
		  xyz[k][0] =mid_xyz[0];
		  xyz[k][1] =mid_xyz[1];
		  xyz[k++][2] =mid_xyz[2];
		}
		else {
		    // in case of a mesh model
		  mid_xyz_evaluated =true;
		  pPList eflist = E_faces(edge);
		  pFace faces[2],f;
		  int count = 0;
		  for(int ll=0; ll<PList_size(eflist); ll++){
		    f = (pFace)PList_item(eflist, ll);
		    if(F_whatInType(f) == 2)
		      faces[count++] = f;
		  }
		  PList_delete(eflist);
		  
		  computePtForOppEdge(edge, faces, mid_xyz);
		  xyz[k][0] =mid_xyz[0];
		  xyz[k][1] =mid_xyz[1];
		  xyz[k++][2] =mid_xyz[2];
		  cout<<"Error: mesh model has not been implemented"<<endl;
		}
	      } else {
		// mid_xyz has been computed
		xyz[k][0] =mid_xyz[0];
		xyz[k][1] =mid_xyz[1];
		xyz[k++][2] =mid_xyz[2];
	      }	      
	    }
	  } // for (i=0; i<6; i++)
  // calculate shape and check acceptability
	  if( ! HO_XYZ_isValid(xyz, &csi) )
	    { flag=1; break; }
	  
	  // find the worst element shape of this configuration
	  if(csi.shape < worst)   
	    worst=csi.shape;
	}
	delete verts;
	
	if(flag) 
	  // at least one element is invalid or unacceptable
	  continue;
	
	// if it is the one with "the worst shape" best so far, remember it
	if(worst>optimum)
	  {  optimum=worst;  conf=i; }
      }
    } // if (EN_whatInType (edge)==Tface)
 else {
      // for an edge classified on a model region to be swapped, 
      // all the new edge nodes are within the model region
      if(n>4)
	return 0;
      
      for(i=0;i<n;i++) {
	verts=fromMeshTools::E_swpCfgVerts(edge,i);
	if( !verts ) 
	  continue;
	num=verts->size()/4;
	
	if( !num ) {
	  delete verts;
	  break;
	}
	
	// loop over regions that will be created for this specific configure
	// calculate the worst shape
	flag=0;
	worst=BIG_NUMBER;
		std::vector<pVertex>::iterator vtIter=verts->begin();
	for(j=0;j<num;j++) {
	  // get vertex coordintes assuming the vertex moved
	  for(k=0;k<4;k++) {
	    vt=*vtIter;
	    vtIter++;
	    V_coord(vt,xyz[k]);
	    //	    pmt[k]=pSizeField->getSize(vt);
	    v[k] =vt;
	  }

	  // get the six edge nodal coordinates
	  int j0, j1;
	  for (int m=0; m<6; m++) {
	    switch (m) {
	    case 0:
	      j0 =0; j1 =1;
	      break;
	    case 1:
	      j0 =1; j1 =2;
	      break;
	    case 2:
	      j0 =2; j1 =0;
	      break;
	    case 3:
	      j0 =0; j1 =3;
	      break;
	    case 4:
	      j0 =1; j1 =3;
	      break;
	    case 5:
	      j0 =2; j1 =3;
	      break;
	    }
  //printf ("\n swap: edge m=%d, k=%d", m, k);
	    pEdge e;
	    if ((e=E_exists(v[j0], v[j1]))) {
	      // for the existing edges, use their mid-side nodes
	      E_bezierCtrlPt(e, xyz[k++]);
	    }
	    else {
	      // for the new edges, compute their mid-side nodes
	      xyz[k][0] =(xyz[j0][0]+xyz[j1][0])/2;
	      xyz[k][1] =(xyz[j0][1]+xyz[j1][1])/2;
	      xyz[k++][2] =(xyz[j0][2]+xyz[j1][2])/2;
	    }
	  } // for (m=0; m<6; m++)
	  
	  // calculate shape and check acceptability
	  if( ! HO_XYZ_isValid(xyz, &csi) )
	    { flag=1; break; }
	  
	  // find the worst element shape of this configuration
	  if(csi.shape < worst)   
	    worst=csi.shape;
	}
	delete verts;
	
	if(flag) 
	  continue;
		// if it is the one with "the worst shape" best so far, remember it
	if(worst>optimum)
	  {  optimum=worst;  conf=i; }
      }
    }
  }
  

#endif

  // undo the vertex motion
  if( vertMv )  
    adaptUtil::move_vertex(vertMv,origin);

  // if "optimum" unchanges, there is no valid swap configuration
  if( optimum<=M_getTolerance() )  
    return 0;

  // combine the two worst element shape
  if( optimum<results->getWorstShape() )
    results->setWorstShape(optimum);

  // check geometric similarity if the edge is on model face
  if( E_whatInType(edge)==Gface ) {
#ifdef CURVE
    if(quadratic == false){
#endif /* CURVE */
    if( model_type==PARAM ) {
      pFace face;
      pPList F_verts, tmplist; 
      pVertex vts[2];
      // the two vertices should be available in the swap structure
      j=0;
      for( i=0; i<E_numFaces(edge); i++ ) {
	face=E_face(edge,i);
	if( F_whatInType(face)==Gface ) 
	  vts[j++]=F_edOpVt(face,edge);
	if( j==2 ) break;
      }
      
      pGFace gface=(pGFace)F_whatIn(face);
      F_verts=PList_new();
      tmplist=adaptUtil::F_verticesOutofMesh(face);
      flag=0;
      for( i=0; i<2; i++ ) {
	temp=0; 
	while( vt=(pVertex)PList_next(tmplist,&temp) ) 
	  if( vt==E_vertex(edge,i) )
	    PList_append(F_verts,(pEntity)vts[0]);
	  else
	    PList_append(F_verts,(pEntity)vt);
	if( adaptUtil::F_checkGeoSim(&F_verts,gface)!=1 ) 
	  { flag=1; break; }
	PList_clear(F_verts);
      }
      
      PList_delete(tmplist);
      PList_delete(F_verts);
      if( flag ) return 0;
    }
#ifdef CURVE
    }
#endif
  }

  return 1;
}


int edgeSwapMod::geomCheck(pVertex v1, pVertex v2)
{ 
  pMSize pmt[4];
  pVertex vt;
  std::vector<pVertex> *verts;
  double xyz[4][3];
  double shape_1, optimum, worst;
  int num, i, j, k, flag, okCfg, flagCfg;

  if ( n==-1 )
    std::cout<<"Error: please do topoCheck() before geomCheck()"<<endl;  
  if ( vertMv )
    std::cout<<"Error: not implemented yet (edgeSwapMod::geomCheck(v1,v2)"<<endl;

  // check parametric span if on periodic model face
  if( model_type==PARAM ) {
    if( !adaptUtil::E_swpCheckPer(edge) )
      return 0;
  }
  results->reset();

  if( M_numRegions(mesh)==0 ) 
    return geomCheck2D();
  
  // determine the validity of tets associated with swap


  // loop over all possible configurations, find the one of best element shape
  optimum=0.0;
  for(i=0;i<n;i++) {
    verts=fromMeshTools::E_swpCfgVerts(edge,i);
    if( !verts ) 
      continue;
    //num=PList_size(verts)/4;
    num=verts->size()/4;

    // this is a special case (see E_swp2Fac.c in meshTools) 
    // It is the same as 2->2 RegionCollapse operator 
    // Always can be applied     -li 8/14/01
    if( !num ) {
      delete verts;
      break;
    }

    // loop over regions that will be created for this specific configure
    // calculate the worst shape
    flag=0;
    okCfg=0;
    worst=BIG_NUMBER;
    std::vector<pVertex>::iterator vtIter=verts->begin();
    for(j=0;j<num;j++) {
      flagCfg=0;
      // get vertex coordintes assuming the vertex moved
      for(k=0;k<4;k++) {
        vt=*vtIter;
        vtIter++;
	V_coord(vt,xyz[k]);
	if( vt==v1 )  ++flagCfg;
	if( vt==v2 )  ++flagCfg; 
	pmt[k]=pSizeField->getSize(vt);
      }
      if( flagCfg==2 ) okCfg=1;

      // calculate shape and check acceptability
      if( ! shpMeasure->XYZ_shape(xyz, pmt,&shape_1) )
	{ flag=1; break; }

      // find the worst element shape of this configuration
      if(shape_1 < worst)   
	worst=shape_1;
    }
    delete verts;

    if( !okCfg )
      // this configuration has the desired edge
      continue;

    if(flag) 
      continue;
      
    // OK, we have a valid configuration here

    // if it is the one with "the worst shape" best so far, remember it
    if(worst>optimum)
      {  optimum=worst;  conf=i; }
  }

  // if "optimum" unchanges, there is no valid swap configuration
  if( optimum<=M_getTolerance() )  
    return 0;

  // combine the two worst element shape
  if( optimum<results->getWorstShape() )
    results->setWorstShape(optimum);

  return 1;
}


int edgeSwapMod::geomCheck2D()
{
  pMSize pmt[3];
  pFace face;
  pVertex vts[2],vt;
  double xyz[3][3];
  double shape_1, worst=BIG_NUMBER;;
  int i,j, flag;
  void *temp;

  if( vertMv ) {
    std::cerr<<" A pre vertex motion is not supported (geomCheck2D)\n"<<endl;
    return 0;
  }

  // ensure no region attached 
#ifdef DEBUG
  pPList erlist=E_regions(edge);
  if( PList_size(erlist) != 0 ) {
    PList_delete(erlist);
    std::cerr<<" there are attached regions (geomCheck2D)\n"<<endl;
    return 0;
  }
  PList_delete(erlist);
#endif

  // find the vertices opposite to 'edge' 
  if( E_numFaces(edge) != 2 )
    {
      printf("Error: should first check topological validity (edgeSwapMod::geomCheck2D)\n");
      return 0;
    }

  for( i=0; i<E_numFaces(edge); i++ ) {
    face=E_face(edge,i);
    vts[i]=F_edOpVt(face,edge);
  }

  pPList tmplist=F_vertices(face,1);

  // in case there is parametric space
  if( model_type==PARAM ) {
    pGFace gface=(pGFace)F_whatIn(face);
    pPList F_verts=PList_new();

    flag=0;
    for( i=0; i<2; i++ ) {
      // check geometric similarity
      temp=0; 
      while( vt=(pVertex)PList_next(tmplist,&temp) ) 
	if( vt==E_vertex(edge,i) )
	  PList_append(F_verts,(pEntity)vts[0]);
	else
	  PList_append(F_verts,(pEntity)vt);
      if( adaptUtil::F_checkGeoSim(&F_verts,gface)!=1 ) 
	{ flag=1; break; }
      // calculate the worst element shape
      temp=0; j=0;
      while( vt=(pVertex)PList_next(F_verts,&temp) )
	{
	  pmt[j]=pSizeField->getSize(vt);
	  V_coord(vt,xyz[j++]);
	}
      PList_clear(F_verts);
      if( ! shpMeasure->XYZ_shape(xyz,pmt,0,&shape_1) )
	{ flag=1; break; } 
      if(shape_1 < worst)   
	worst=shape_1;
    }
    PList_delete(tmplist);
    PList_delete(F_verts);
    if( flag ) 
      return 0;
  }

  else {    // no parametric space
    double area, area1, normal[3], normal1[3];

    // determine the normal
    F_normalVector(E_face(edge,0),1,normal);
    F_normalVector(E_face(edge,1),1,normal1);
    area = dotProd(normal,normal);
    area1 = dotProd(normal1,normal1);
    if( MAX(area, area1) < M_getTolerance()*M_getTolerance() )
      { printf("Error: an edge bounded by two sliver faces\n"); return 0; }
    if( area < area1 )
      {
	normal[0]=normal1[0];
	normal[1]=normal1[1];
	normal[2]=normal1[2];
      }

    // check the validity with respect to the normal
    flag=0;
    for( i=0; i<2; i++ ) {
      temp=0; j=0;
      while( vt=(pVertex)PList_next(tmplist,&temp) ) {
	if( vt==E_vertex(edge,i) )
	  {
	    pmt[j]=pSizeField->getSize(vts[0]);
	    V_coord(vts[0],xyz[j++]);
	  }
	else
	  {
	    pmt[j]=pSizeField->getSize(vt);
	    V_coord(vt,xyz[j++]);
	  }
      }

      if( ! shpMeasure->XYZ_shape(xyz,pmt,normal,&shape_1) )
	{ flag=1; break; } 
      if(shape_1 < worst)   
	worst=shape_1;
    }
    PList_delete(tmplist);
    if( flag ) 
      return 0;
  }

  results->setWorstShape(worst);
  return 1;
}



/*
  calculate the max/min size after the modification is applied

  return 0:  size not acceptable
         1:  acceptable
*/
int edgeSwapMod::sizeCheck()
{
  double max, min;
  double maxSwap, minSwap;
  double tmp, ratio;
  int i;
  pEdge eg;
  double origin[3];
  
  // initialization
  min=BIG_NUMBER; 
  max=0.0;
  
  // make the move
  if( vertMv ) {
    V_coord(vertMv,origin);
    adaptUtil::move_vertex(vertMv,target);
    
    // consider edges connected to the moving vertex
    for(i=0;i<V_numEdges(vertMv);i++) {
      eg=V_edge(vertMv,i);
      if( eg==edge ) continue;
      tmp=pSizeField->lengthSq(eg);
      if( min>tmp ) min=tmp;
      if( max<tmp ) max=tmp;
    }
  }
  
  // consider the new edges created after swap
  if( M_numRegions(mesh)==0 ) {
    // 2D
    if( E_numFaces(edge)!=2 )
      { printf("Info: should first check topological validity \n"); return 0;}
    pVertex vv[2];
    pFace face;
    for( i=0; i<2; i++ ) {
      face=E_face(edge,i);
      vv[i]=F_edOpVt(face,edge);
    }
    maxSwap=pSizeField->lengthSq(vv[0],vv[1]);
    minSwap=maxSwap;
  }
  else {
    // 3D
    if( E_swpNewEdges(&maxSwap, &minSwap)==-1 )
    std::cout<<"Error: edgeSwapMod::maxminEdgeLength()"<<endl;
  }
  
  if( maxSwap > max ) max=maxSwap;
  if( minSwap < min ) min=minSwap;
  results->setMaxSize(max);
  results->setMinSize(min);

  // get size of the edge before swap
  tmp = pSizeField->lengthSq(edge);
  ratio=maxSwap/tmp;
  results->setMaxRatioSquare(ratio);
  
  // move back
  if( vertMv ) 
    adaptUtil::move_vertex(vertMv,origin);
  return 1;
}


void edgeSwapMod::getAffectedRgns(pPList *l)
{
  *l=E_regions(edge);

  if( vertMv ) {
    pPList vrlist=V_regions(vertMv);
    pRegion region;
    void *iter=0;
    while( region=(pRegion)PList_next(vrlist,&iter) )
      PList_appUnique(*l, region);
    PList_delete(vrlist);
  }
}


int edgeSwapMod::apply()
{
  pPList newRegs;
  apply( &newRegs );
  PList_delete(newRegs);
  return 1;
}


int edgeSwapMod::apply(pPList *newRegs)
{
#ifdef DEBUG
  pRegion region;
  void *iter;
#endif

  if( vertMv ) {
    adaptUtil::move_vertex(vertMv,target,CB_move,userData_CB_move);
#ifdef DEBUG
    pPList mvRgns=V_regions(vertMv);
    pPList edRgns=E_regions(edge);
    iter=0;
    while( region=(pRegion)PList_next(mvRgns,&iter) ) {
      if( ! PList_inList(edRgns,region) )
        if( R_Volume2(region) < 2.e-16 ) {
          printf("Error: 1. region %p: R_volume2=%12.5e [rTopoType=%d] (edgeSwapMod::apply())\n",
                 region,R_Volume2(region),region->getType());
	}
    }
    PList_delete(mvRgns);
    PList_delete(edRgns);
#endif
  }

  E_numSwpCfg(edge);
  E_evalSwpCfg(edge,conf);
#ifdef CURVE
  pVertex oldvt[2];
  int edgeType = E_whatInType(edge);
  
  if(quadratic == true && edgeType == 2) {
    cout<<"swap edge on the model edge"<<endl;
    pPList eflist = E_faces(edge);
    pFace faces[2],f;
    int count = 0;
    for(int ll=0; ll<PList_size(eflist); ll++){
      f = (pFace)PList_item(eflist, ll);
      if(F_whatInType(f) == 2)
	faces[count++] = f;
    }
    PList_delete(eflist);
    oldvt[0] = F_edOpVt(faces[0], edge);
    oldvt[1] = F_edOpVt(faces[1], edge);
  }
#endif /* CURVE */
  templatesUtil::Edge_swap(mesh, edge, conf, function_CB, userData_CB, newRegs);
#ifdef CURVE
if(quadratic == true && edgeType == 2) {
    
    pEdge newedge = E_exists(oldvt[0], oldvt[1]);
    if(!newedge) {
      cout<<"the new edge on the model face can not be founded";
    }
    double xyz[2][3];
    V_coord(oldvt[0], xyz[0]);
    V_coord(oldvt[1], xyz[1]);
    for(int ll=0; ll<3; ll++)
      mid_xyz[ll] = 0.25*(xyz[0][ll] + xyz[1][ll]) + 0.5*mid_xyz[ll];

    if(E_numPoints(newedge)) {
      pPoint pt = E_point(newedge, 0);
      P_setPos(pt, mid_xyz[0], mid_xyz[1], mid_xyz[2]);
    }
    else{
      pPoint pt = P_new();
      P_setPos(pt, mid_xyz[0], mid_xyz[1], mid_xyz[2]);
      E_setPoint(newedge, pt);
    }
    
  }
#endif /* CURVE */

#ifdef DEBUG
  if (M_numRegions(mesh))
  {
    iter=0;
    while( region=(pRegion)PList_next(*newRegs,&iter) ) {
      if(R_Volume2(region) < 2.e-16)
        printf("Error: 2. region %p: R_volume2=%12.5e [rTopoType=%d] (edgeSwapMod::apply())\n", region,R_Volume2(region),region->getType());
    }
  }
#endif

  return 1;
}

/*
  calculate max/min edge length square of new edges of the c'th swap configuration
  return the number of new edges    
*/
//extern "C" SwapConfig sc;
extern SwapConfig sc;

int edgeSwapMod::E_swpNewEdges(double *maxlen, double *minlen)
{
  pVertex rvert[8];
  int     i,j,t,c2;
  double LL;

  *maxlen=0;
  *minlen=1e14;

  /* check if swap configuration already available */
  if (sc.edge != edge)
    if (!E_numSwpCfg(edge))
      return -1;

  if (!conf && !sc.nbr_triangles)
    /* This is the special case where only configuration is valid       */
    /* unless the resulting mesh will violate topological compatibility */
    /* (this is checked during the actual swap operation)               */
    return 1;

  if (conf >= sc.nbr_trianguls)
    return -1;

  /* Have to find the c'th *topologically valid* configuration */
  for (c2 = 0, j = -1; c2 < sc.nbr_trianguls; c2++) {
    if (sc.topoValidCfg[c2]) j++;
    if (j == conf) break;
  }

  /* evaluate the triangles of the c'th configuration */
  for (j=0; j < sc.nbr_triangles_2; j++) {
    t = sc.trianguls[c2][j];

    for(i=0;i<3;i++)
      rvert[i] = sc.pverts[sc.triangles[t][i]];

    for(i=0; i<3; i++)
      if(!E_exists(rvert[i],rvert[(i+1)%3])) {
	LL = pSizeField->lengthSq(rvert[i],rvert[(i+1)%3]);
        if(LL > *maxlen)   *maxlen=LL;
	if(LL < *minlen)   *minlen=LL;
      }
  }

  /* it could return 0 if no new edge after swap */
  /* note when this happen, maxlen and minlen are initialized, but not assigned a value */
  return sc.nbr_triangles_2-1;
}
