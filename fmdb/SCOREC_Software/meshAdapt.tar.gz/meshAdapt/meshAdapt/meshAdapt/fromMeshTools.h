#ifndef _H_fromMeshTools
#define _H_fromMeshTools

#include "MeshTools.h"
#include <iostream>
#include <vector>
using namespace std;

/* Performs CPU and wall clock timing 
   from SCOREC util */
class myTimer {
public:
  myTimer();
  void reset();
  double elapsedCPU() const;
  long elapsedWallClock() const;

  friend ostream& operator<<(ostream& os, const myTimer& s);
private:
  double TimeLastResetCPU;
  double TimeLastResetWallClock;
  double computeElapsedCPU() const;
  long computeElapsedWallClock() const;
};


/* used routines from meshTools.h */
namespace fromMeshTools {

  // needed function for meshAdapt 
  void MT_intLineLine2(double[2][3], double[2][3],int *, double[3]);
  void XYZ_FAngles(dArray *xyz, double *cosangs);
  int E_evalSwpOnGFace(pEdge, pGEntity, pPList &, double *, double *);

  // evaluation of local mesh modification
  std::vector<pVertex> *E_swpCfgVerts(pEdge edge, int c);

  // Here we have assumed the ordering of mesh entities of prismatic elements
  int Layer_E_colaps(pMesh, vector<pEdge>&, pVertex, pVertex, CBFunction,void *, pPList *);
  pPList E_colapsOnBLInterface(pMesh, pVertex, pVertex, CBFunction, void *);

  // execution of local mesh modifications   added 09/25/02 -li
#ifndef MATCHING
  int E_colaps(pMesh, pEdge, pVertex, pVertex, CBFunction,void *, pPList, pPList *);
  int E_colapsOnGFace(pMesh, pEdge, pVertex, pVertex, CBFunction, void *, pPList,pPList *);
#else
  int E_colaps(pMesh, pEdge, pVertex, pVertex, CBFunction,void *, pPList, pPList*, pPList*, pPList *);
  int E_colapsOnGFace(pMesh, pEdge, pVertex, pVertex, CBFunction, void *, pPList, pPList*, pPList *);
#endif

  // Here we have assumed the ordering of mesh entities of prismatic elements
  int Layer_E_swap(pMesh,vector<pEdge>&,int,CBFunction,void *, pPList *);
  pPList E_swapOnBLInterface(pMesh mesh, pEdge edge, pPList eregs, int c, pPList oldRgns, pPList oldFaces);

  int E_swap(pMesh,pEdge,int,CBFunction,void *, pPList *);
  int E_swap2Fac(pMesh mesh, pEdge edge);
  pEdge E_swapOnGFace(pMesh, pEdge, pGEntity, CBFunction, void *, pPList *);
  pVertex E_split(pMesh, pEdge, double *, double *, CBFunction, void *, pPList *); 
  pVertex TopGrowth_E_split(pMesh, pEdge, double *, double *, CBFunction, void *, pPList *);
  pVertex R_split(pMesh mesh, pRegion region, double *xyz, pPList *newReg);
  int F_swap(pMesh, pFace, double, CBFunction, void *, pPList*, pPList*);

  int E_numSwpCfg(pEdge edge);
  // needed by the executaion of local modifications
  void E_getCavityBdry(pEdge ledge,pPList regions,pPList *faces,pPList *edges, int *modelDir);
  void E_vrtCrtFaces(pMesh mesh, pPList edgeList, pVertex vert);
  pPList E_swpCrtRegs(pMesh mesh, int tri_nbr, pVertex tri_verts[][3], 
		      pVertex e_verts[2],pGEntity rg_entity, pPList faceList,
		      int modelDir );
  void E_reorder(pEdge* elist,int* edir, int n);
  int E_defaultRegionSwpCfg (pEdge edge);
  pFace E_vrtCrtFc(pMesh mesh, pEdge edge, pVertex vert,
		   pGEntity g_entity, int dir);
  pRegion F_vrtCrtReg(pMesh mesh, pFace face,int dir,pVertex vert,pGEntity rg_entity);
  void edgesToVerts(pEdge edges[3], pVertex verts[3]);

#ifdef MA_PARALLEL
  void sendReclassifiedEntity(pMesh,pEntity,int);
  void syncClassification(pMesh);
#endif
}

/*************************************************/
/* operators to deal with constrained operations */
/*************************************************/
void EN_constrain(opType ,pEntity ) ;
void EN_constrainAll(pEntity ) ;
void EN_unconstrain(opType ,pEntity ) ;
void EN_unconstrainAll(pEntity);
int  EN_okTo(int ,pEntity ) ;
/* Check if it is ok to perform operation on model entity */
int GEN_okTo(int i,pGEntity g);

void GEN_constrain(opType ,pGEntity ) ;
void GEN_constrainAll(pGEntity ) ;
void GEN_unconstrain(opType ,pGEntity ) ;
void GEN_unconstrainAll(pGEntity);

/*************************************************/
/* Local Mesh Modification operators */
/*************************************************/
/* Edge collapsing */
int E_chkColaps(pVertex *vert0,pVertex *vert1,pEdge ledge);
int E_chkColapsFcs(pVertex vert0,pVertex vert1,pEdge ledge);
int E_chkClpTopo(pVertex vdel, pEdge ledge);
int E_evalColaps(pMesh mesh, pEdge ledge, pVertex vertd, pVertex vertr);
int E_evalColapsOnGFace(pMesh mesh, pEdge cedge, pVertex vertd, pVertex vertr, double *normal );

/* Edge swapping */
int E_numSwpCfg(pEdge);
int E_evalSwpCfg(pEdge, int);
int E_evalSwpOnGFace(pEdge swpedge, pGEntity gface, double *normal);

  /* Face Swap */
int F_evalSwap(pFace,double);

#endif

