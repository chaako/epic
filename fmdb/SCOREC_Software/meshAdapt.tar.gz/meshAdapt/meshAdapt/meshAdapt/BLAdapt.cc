#include "mEntity.h"
#include "AdaptUtil.h"
#include "Macros.h"
#include "BLUtil.h"
#include "MeshAdapt.h"
#include "MeshSize.h"
#include "FMDB_cint.h"
#include "fromMeshTools.h"
#include <vector>

#include "snap.h"
#include "paraAdapt.h"

#include "ParUtil.h"

using namespace std;

pMeshDataId currentRegionID;
extern "C" pMeshDataId gcThicknessID;

int meshAdapt::tagLayerEdgesInBLBySizeField(double tSq)
{
  pEdge edge;
  pFace face;
  pRegion reg;
  double lSq;
  int nref = 0;
  pMeshDataId procTag = MD_lookupMeshDataId("ProcessedBLEdgeTag"); 
  deque<pEdge> procEdges;
  int value;

  /// Loop over entity groups
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    /// Find the zero-level face, i.e. the face on the surface
    face = BL_GetZeroLvlFace((pBLayer)(*egIt));
    int n_edges = F_numEdges(face);
    for (int iEdge = 0; iEdge < n_edges; ++iEdge)
    {
      edge = F_edge(face,iEdge);

      ///If the edge (and its stack of edges) is already marked for refinement or the edge (and its stack of edges) is not supposed to be refined
      if (pRef->getRefineLevel(edge) || EN_getDataInt(edge,procTag,&value))
        continue;

      vector<pEdge> edgesStack;
      BL_getHorizontalEdgesByEdge(edge, edgesStack);
      int e_ref = 0;

      /// Check if there is an edge in the stack which has to be refined
      for (int i = 0; i < edgesStack.size(); i++)
      {
        edge = edgesStack[i];
        lSq=pSizeField->lengthSq(edge);
        if( lSq>tSq )
        {
          e_ref = 1;
          break;
        }
      }

      /// If the edges to be refined was found, mark for refinement all the edges in the stack
      if (e_ref)
      {
        for (int i = 0; i < edgesStack.size(); i++)
        {
          edge = edgesStack[i];
          if (pRef->setRefineLevel(edge,1))
            nref++;
        }      
      }

      /// Otherwise mark the zero-level edge that it is not supposed to be refined, so if encountered again there is no need to check the whole stack
      else
      {
        edge = F_edge(face,iEdge);
        EN_attachDataInt(edge,procTag,1);
        procEdges.push_back(edge);
      }
    }
  }

  for (deque<pEdge>::iterator eIt = procEdges.begin(); eIt != procEdges.end(); ++eIt)
    EN_deleteData(*eIt,procTag);

  MD_deleteMeshDataId(procTag); 

#ifdef DEBUG
  printf("%d BL edges are tagged to be refined\n", nref);
#endif
  return nref;
}

// the code structure is similar to general coarsen routine
#ifdef MA_PARALLEL
int meshAdapt::coarsenSurfaceInBL(double upperBoundSq, pmMigrationCallbacks& userLB)
#else
int meshAdapt::coarsenSurfaceInBL(double upperBoundSq) 
#endif
{

  // the tag and the two lists controlling the coarsening routine
  pMeshDataId deref=MD_newMeshDataId("Id_Deref_Control");
  list<pVertex> drVertices;

  // declare the layer edge collapse object
  layerEdgeCollapsMod *LEclps = new layerEdgeCollapsMod(pmesh,pSizeField,shpMeasure,result);
  LEclps->setCallback(function_CB,userData_CB);
  // LEclps->setAcptControl(1);
  if( checkVolume )
    LEclps->setCheckVolume(dV_limit,dA_limit);
  if( model_type != 2 )
    LEclps->setModelType(NOPARAM);

  // determine layer edges and their end vertices to be processed
  // loop over zero level layer edges
  // check on the above stack of layer
  // edges to determine growth curves
  // that need to be collapsed
  int numEdges, nClpsInStack, isClpNeeded, value;
//  pVertex v[2], vtx;
  pVertex vtx;
  pEdge edge;
  pFace face;
  pRegion reg;
  vector<pEdge> elist;
  pMeshDataId procTag = MD_lookupMeshDataId("ProcessedBLEdgeTag");

  /// Loop over entity groups
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    /// Find the zero-level face, i.e. the face on the surface
    face = BL_GetZeroLvlFace((pBLayer)(*egIt));

    int n_edges = F_numEdges(face);
    for (int iEdge = 0; iEdge < n_edges; ++iEdge)
    {
      edge = F_edge(face,iEdge);

      ///If the edge (and its stack of edges) is already marked for refinement or the edge (and its stack of edges) is not supposed to be refined
      if (EN_getDataInt(edge,procTag,&value))
        continue;

      EN_attachDataInt(edge,procTag,1);

      BL_getHorizontalEdgesByEdge(edge, elist);

      isClpNeeded = 0;
      nClpsInStack = 0;
      numEdges = elist.size();
      for(int iEdge=0; iEdge<numEdges; iEdge++) {
        edge = elist[iEdge];

        // if any layer edge from the stack is
        // constrained or tested for coarsening
        // then NO layer edge from the stack
        // is allowed to be collapsed
        if( !EN_okTo(DELETE,(pEntity)edge))// || EN_getDataInt((pEntity)edge,coarsenTested,&value) ) 
        {
          nClpsInStack = 0;
          break;
        }

        // collapse is performed ONLY if all layer edges
        // from the stack need to be coarsened
        // conservative approach and avoids oscillation between
        // refinement and coarsening
        // in case of refinement we split all layer
        // edges in stack if any needs split
        // in any case this would probably happen only for a small
        // portion of the domain (e.g., shock and boundary layer interaction)
        if( pSizeField->lengthSq(edge) < lowerLenSqBound ) 
          nClpsInStack++;
        else
          break;
      }

      if(nClpsInStack==numEdges)
        isClpNeeded=1;

      if(isClpNeeded) {
        EN_attachDataInt((pEntity)elist[0],deref,-1);
        for(int iVert=0; iVert<2; iVert++ ) {
          vtx=E_vertex(elist[0],iVert);
          if(!EN_okTo(DELETE,(pEntity)vtx))
            continue;
          if( !EN_getDataInt((pEntity)vtx,deref,&value) )  {
            EN_attachDataInt((pEntity)vtx,deref,-1);
            drVertices.push_back(vtx);
          }
        } // loop over end vertices
      } // if clp is needed
    } // check for zero level layer edges
  } // loop over mesh edges
//  EIter_delete(eit);

  // repeat traversing of the vertex list to eliminate
  // stack of layer edges to be coarsened
  int loopId = 0, flag, nLEclps = 0;
  double sizeSq, maxWorstShape = 0.;
  pVertex vd;
  list<pVertex>::iterator drIter, rem_drIter;
  // SCOREC::Util::scorecSSList<pVertex> removedEnts;
  std::set<pVertex> removedEnts;
  std::vector< std::pair<double,pEdge> > Evector;
  std::vector< std::pair<double,pEdge> >::iterator pairIt;
  pEdge edgeDel;
  vector<pEdge> vLyrEdges;

#ifndef MA_PARALLEL
  while( drVertices.size() ) {

#else           /* MA_PARALLEL */

  int globalDrVertices_size = M_getMaxNum(drVertices.size());
  list<pVertex>  vtOnCB;

//  int Comm_start_FLAG=1;
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);


  while(globalDrVertices_size) {

//    if( Comm_start_FLAG && P_size()>1)
    if(P_size()>1) 
    {
      CM->set_tag(0);
      int msg_size = sizeof(classificationPack);
      CM->set_fixed_msg_size(msg_size);

//      Comm_start_FLAG=0;
    }

#endif

    loopId++;
    drIter = drVertices.begin();;
    while(drIter != drVertices.end()) {

      // see if the vertex has been removed
      // if( removedEnts.inList(vd) )
      //   { drIter.remove(); removedEnts.remove(vd); continue; }
      vd = *drIter;
      rem_drIter = drIter;
      if( removedEnts.find(vd) != removedEnts.end() ){
         drIter++;
         drVertices.erase(rem_drIter);
         removedEnts.erase(vd);
         continue;
      }


      // this is to ensure that edge collapsed is applied every other vertex
      if( !EN_getDataInt((pEntity)vd,deref,&value) )
      {
        drIter++;
        drVertices.erase(rem_drIter);
        continue;
      }
      if( value>loopId )
      {
        drIter++;
        continue;
      }

      // always eliminate this vertex in case it is processed
      drIter++;
      drVertices.erase(rem_drIter);

      // HOW TO USE "WORST SHAPE" IS STILL NOT CLEAR
      // (MOREOVER WE MAY HAVE TO CONSIDER LAYER TRIANGLES ON EACH LAYER SURFACE)
      // set shape threshold
      shpMeasure->setDefaultAcptValue();
      // maxWorstShape=0.1*adaptUtil::V_worstShp(shpMeasure,vd);
      // shpMeasure->setAcptValue(maxWorstShape);

      // try edge collapse
      // COLLAPSING SHORTEST LAYER EDGE (AT ZERO LEVEL)
      Evector.clear();
      V_layerEdges(vd, vLyrEdges);
      numEdges = vLyrEdges.size();
      for(int iEdge=0; iEdge<numEdges; iEdge++ ) {
        edgeDel=vLyrEdges[iEdge];
        if( !EN_getDataInt((pEntity)edgeDel,deref,&value) )
          continue;
        sizeSq=pSizeField->lengthSq(edgeDel);
        Evector.push_back(std::make_pair(sizeSq,edgeDel));
      }

      std::sort(Evector.begin(),Evector.end());

      // no connected layer edge requires coarsening
      if( Evector.size()==0 ) {
        EN_deleteData((pEntity)vd,deref);
        continue;
      }

      for(pairIt=Evector.begin();pairIt!=Evector.end();++pairIt) {
        edgeDel=(*pairIt).second;
        flag=coarsenVertexInBL(edgeDel,vd,upperBoundSq,maxWorstShape,LEclps,loopId,
                               deref,drVertices,removedEnts);
        if ( flag )
          break;
      }

      if( flag==1 ) {
        nLEclps++;
        continue;
      }

#ifdef MA_PARALLEL
      vector<pVertex> GC;
      BL_getGrowthCurveNodes(vd, GC);
      pVertex topVD = GC[GC.size()-1];
      if( EN_onCB(topVD) ) {
        vtOnCB.push_back(topVD);
        continue;
      }
#endif

      // no valid layer edge collapse is available
      // WE MAY NEED TO CLEAN DATA ATTACHED WITH "coarsenTested" WITHIN LOOP
      // AS MESH CONFIGURATION MIGHT CHANGE LOCALLY NEAR THIS EDGE
      // (--- AT THE END OF MESHADAPT IT IS DELETED IN DESTRUCTOR ---)
      EN_deleteData((pEntity)vd,deref);
//       for(pairIt=Evector.begin();pairIt!=Evector.end();++pairIt) {
//      edgeDel=(*pairIt).second;
//      cout<<"\n\n coarsenTested reached in coarsenSurfaceInBL() \n\n"<<endl;
//      if(!EN_getDataInt((pEntity)edgeDel,coarsenTested,&value))
//        EN_attachDataInt((pEntity)edgeDel,coarsenTested,1);
//       }
    } // end of traversing drVertices once


#ifdef MA_PARALLEL
    // do mesh migration only if all vertices in drVertices on CB
    globalDrVertices_size=M_getMaxNum(drVertices.size());

//    This checkup for the changed max dim of the mesh in global sence is not needed so far, it is set during the mesh load
//    int mDim = M_globalMaxDim(pmesh);
//    M_set_maxMeshDim(mDim);

    if(globalDrVertices_size==0 && P_size()>1) {
      // initialize removedEnts
      removedEnts.clear();
      CM->finalize_send();

      fromMeshTools::syncClassification(pmesh);

//      Comm_start_FLAG=1;
      // update partition boundary to remove all mesh faces not locally
      // connected to a mesh region and update list "vtOnCB"
      deleteDimReduction(vtOnCB, userLB);
      globalDrVertices_size = mMigrateForCoarsenBL(vtOnCB,        // a list of vertices on CB
                                                 drVertices,    // a list of vertices to be coarsened
                                                 userLB,        // customized load balancer
                                                 deref,         // tag
                                                 lowerLenSqBound); // threshould
      vtOnCB.clear();
    }
#endif

  } // end of the loop to enforce "every other vertices" with loopId

//  adaptUtil::Info(nLEclps,"zero level layer edge collapse(s) were performed (coarsened)");
#ifdef DEBUG
  printf("%d zero level layer edge collapse(s) were performed (coarsened)\n", nLEclps);
#endif

  // probably there shouldn't be any vertex left that is tagged with deref
  VIter viter=M_vertexIter(pmesh);
  while( vtx=VIter_next(viter) ) {
    if( EN_getDataInt((pEntity)vtx,deref,&value) )
      EN_deleteData((pEntity)vtx,deref);
  }
  VIter_delete(viter);

  EIter eiter=M_edgeIter(pmesh);
  while( edge=EIter_next(eiter) ) {
    if( EN_getDataInt((pEntity)edge,deref,&value) )
      EN_deleteData((pEntity)edge,deref);
    if (EN_getDataInt((pEntity)edge,procTag,&value))
      EN_deleteData((pEntity)edge,procTag);
  }
  EIter_delete(eiter);

  MD_deleteMeshDataId(procTag);
  MD_deleteMeshDataId(deref);
  delete LEclps;

//   pFace fc;
//   FIter fit = M_faceIter(pmesh);
//   while(fc = FIter_next(fit)) {
//     if(fc == (pFace)(0x2ed51f8)) {
//       cout<<"\n\n\n\nstop\n\n\n\n\n\n\n"<<endl;
//       for(int iEdge=0; iEdge<3; iEdge++) {
//      mvtkAddMEnt(F_edge(fc,iEdge));
//      mvtkSetMEntColorI(F_edge(fc,iEdge),iEdge);
//       }
//       mvtkAddMEnt(fc);
//       mvtkSetMEntColorI(fc,3);
//       mvtkActivate();
//       mvtkRemoveAllMEnts();
//     }
//   }
//   FIter_delete(fit);

  return nLEclps;
}


/*
  Eliminate stack of layer edges above "edgeDel" by collapsing

  return 1 collapse was applied
  0 no mesh modification happened
*/
int meshAdapt::coarsenVertexInBL(pEdge edgeDel,   // the edge
                                 pVertex vd,
                                 double upperBoundSq,
                                 double maxWorstShape,
                                 layerEdgeCollapsMod *LEclps,
                                 int loopId,
                                 pMeshDataId deref,
                                 list<pVertex>& drVertices,
//                               SCOREC::Util::scorecSSList<pVertex>& removedEnts)
                                 std::set<pVertex>& removedEnts)
{

  double mtol=M_getTolerance();

  int Flag = 0, opt=2;
  pVertex vts[2];

#ifdef MA_PARALLEL
  vector<pVertex> GC;
  pVertex topV[2];
  int GC_size;
#endif

  for(int iVert=0; iVert<2; iVert++ )
  {
    vts[iVert]=E_vertex(edgeDel,iVert);
#ifdef MA_PARALLEL
    BL_getGrowthCurveNodes(vts[iVert], GC);
    GC_size = GC.size();
    topV[iVert] = GC[GC_size-1];
    if( EN_onCB((pEntity)topV[iVert]) )
      Flag++;
#endif
  }


#ifdef MA_PARALLEL
  if (Flag==2)
    return 0;
  pVertex tmpVt;
  if (Flag==1) {
    opt=1;
    if (EN_onCB((pEntity)topV[0])) {
      tmpVt=vts[0];
      vts[0]=vts[1];
      vts[1]=tmpVt;
    }
  }
#endif

  Flag = 0;
  int value;
  pVertex bestVr, bestVd;
  for(int i=0; i<opt; i++ ) {
    // this is to ensure that edge collapsed is applied every other vertex
    if( EN_getDataInt((pEntity)vts[i],deref,&value) )
      if( value>loopId )
        continue;

    LEclps->setCollaps(edgeDel,vts[i],vts[(i+1)%2]);
    if( !LEclps->topoCheck() )
      continue;

    LEclps->sizeCheck();
    if( result->getMaxSize()>upperBoundSq+mtol &&
        result->getRatioSquareAtMaxSize()>1. )
      continue;
    if( !LEclps->geomCheck() )
      continue;
    if( result->getWorstShape() < mtol )
      continue;
    if( maxWorstShape+mtol < result->getWorstShape() ) {
      maxWorstShape=result->getWorstShape();
      bestVr=vts[(i+1)%2];
      bestVd=vts[i];
      Flag=1;
    }
  }

  if (Flag == 0)
    return 0;

  // an layer edge collapse (on stack) is available
  // not process the neighboring vertices in this traversing
  pVertex vtx;
  pEdge edge;
  vector<pEdge> vLyrEdges;
  V_layerEdges(bestVd, vLyrEdges);
  int numEdges = vLyrEdges.size();
  for(int iEdge=0; iEdge<numEdges; iEdge++ ) {
    edge=vLyrEdges[iEdge];
    EN_deleteData((pEntity)edge,deref);
    vtx=E_otherVertex(edge,bestVd);
    if( EN_getDataInt((pEntity)vtx,deref,&value) )
      EN_modifyDataInt((pEntity)vtx,deref,loopId+1);
  }

  // apply layer edge collapse (on stack)
  LEclps->setCollaps(edgeDel,bestVd,bestVr);
  EN_deleteData((pEntity)bestVd,deref);
  if( bestVd!=vd ) {
    // removedEnts.append(bestVd);
    removedEnts.insert(bestVd);
    EN_deleteData((pEntity)vd,deref);
  }

  if( model_type ) pSnap->remove(bestVd); //  pSnap->remove(vd)

  LEclps->apply();

  // check mesh edges around bestVr
  // also check that other vertex for any short edges is in list and tagged
  V_layerEdges(bestVr, vLyrEdges);
  numEdges = vLyrEdges.size();
  for(int iEdge=0; iEdge<numEdges; iEdge++ ) {
    edge=vLyrEdges[iEdge];
    if( pSizeField->lengthSq(edge) < lowerLenSqBound ) {
      // need coarsening
      if( !EN_getDataInt((pEntity)edge,deref,&value) )
        EN_attachDataInt((pEntity)edge,deref,-1);
      // --- osahni
      // if an old edge is tagged but end vertices have been removed
      // from drVertices then append the vertices and tag them too
      vtx=E_otherVertex(edge,bestVr);
      if( !EN_getDataInt((pEntity)vtx,deref,&value) )  {
        EN_attachDataInt((pEntity)vtx,deref,-1);
        drVertices.push_back(vtx);
      }
    } else {
      // do not need coarsening
      if( EN_getDataInt((pEntity)edge,deref,&value) )
        EN_deleteData((pEntity)edge,deref);
    }
  }

  return Flag;
}


#ifdef MA_PARALLEL
int meshAdapt::optimizeSurfaceInBL(double upperBoundSq, pmMigrationCallbacks &userLB) 
#else
int meshAdapt::optimizeSurfaceInBL(double upperBoundSq)
#endif
{
  locMeshMod *bestMod = NULL;

  layerEdgeCollapsMod LEclps(pmesh,pSizeField,shpMeasure,result);
  LEclps.setCallback(function_CB,userData_CB);
  if( checkVolume )
    LEclps.setCheckVolume(dV_limit,dA_limit);
  if( model_type != 2 )
    LEclps.setModelType(NOPARAM);

  layerEdgeSwapMod LEswp(pmesh,pSizeField,shpMeasure,result);
  LEswp.setCallback(function_CB,userData_CB);
  if( model_type != 2 )
    LEswp.setModelType(NOPARAM);
  if( checkVolume )
    LEswp.setCheckVolume(dV_limit,dA_limit);
  shpMeasure->setDefaultAcptValue();

  pVertex vtx[2];
  pEdge edge;

  double fcShpLowerBound = FACE_QUALITYTHRESHOLD;
  double fcShp;
  int numFaces;
  std::vector< std::pair<double,pFace> > Fvec;
  vector<pFace> stackOfFaces;
  pFace face, lyrFc;

  /// This loop has to be wrapped into a separate function, it appears in this function at least 3 times!
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    BL_getHorizontalFaces((pBLayer)(*egIt), stackOfFaces);
    face = stackOfFaces[0];
    numFaces = stackOfFaces.size();
    for(int iFace=0; iFace<numFaces; iFace++) {
      lyrFc = stackOfFaces[iFace];
      if (F_typeInBL(lyrFc) == fTRANSITION)
        continue;
      shpMeasure->F_shape(lyrFc,0,&fcShp);
      if(fcShp < fcShpLowerBound) {
        Fvec.push_back(std::make_pair(fcShp,face));
        break;
      }
    }
  }

#ifdef DEBUG
  cout<<Fvec.size()<<" BL stacks have faces with shape less than "<<sqrt(FACE_QUALITYTHRESHOLD)<<endl;
#endif

  int applied = 1;
  int counter=0, counterMax=5;
  int nLEclps =0, nLEswap = 0, corrected = 0;
  double edgeLenSq, maxEdgeLenSq, bestEffect = 0.;
  pEdge edgeDel, edgeToSwap, iInterfaceEdge;
  pBLayer pBLayerBLayer;
#ifdef MA_PARALLEL
  while ( P_getMaxInt(applied) ) {
#else
  while (applied) {
#endif
    counter++;
    if(counter>counterMax)
      break;
    applied=0;

    std::sort(Fvec.begin(),Fvec.end());

#ifdef MA_PARALLEL
    IPComMan *CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int msg_size = sizeof(classificationPack);
    CM->set_fixed_msg_size(msg_size);
#endif

    applied = 0;
    vector<pFace> affectedLyrFcs, newLyrFcs;
    std::set<pBLayer> newAndNotRemSlivers, FacesNextToPB;
    std::set<pBLayer>::iterator SetIt;
    int nLEclps_withinLoop = 0, nLEswap_withinLoop = 0, corrected_withinLoop = 0;
    // SCOREC::Util::scorecSSList<pFace> removedFaces;
    std::set<pFace> removedFaces;
    std::vector< std::pair<double,pFace> >::iterator faceIt;

    for(faceIt=Fvec.begin(); faceIt!=Fvec.end(); faceIt++) 
    {
      face = (*faceIt).second;

      // if( removedFaces.inList(face) )
      if(removedFaces.find(face)!=removedFaces.end())
      {
        corrected++;
        corrected_withinLoop++;
        // removedFaces.remove(face);
        continue;
      }

      bestMod = NULL;
      bestEffect = IMPROVE_RATIO*((*faceIt).first);

      maxEdgeLenSq = 0.;
      // assuming triangular layer faces
      // swap the longest edge
      for(int iEdge=0; iEdge<3; iEdge++) 
      {
        edge = F_edge(face,iEdge);
        edgeLenSq = pSizeField->lengthSq(edge);
        if( edgeLenSq > maxEdgeLenSq) 
        {
          maxEdgeLenSq = edgeLenSq;
          edgeToSwap = edge;
        }
      }

#ifdef MA_PARALLEL
      vector<pEdge> GC;
      BL_getHorizontalEdgesByEdge(edgeToSwap, GC);
      iInterfaceEdge = GC[GC.size()-1];
      if (EN_onCB(iInterfaceEdge))
      {
        pBLayerBLayer = EN_getBL(face);
        FacesNextToPB.insert(pBLayerBLayer);
        continue;
      }
#endif

      // swap longest edge
      LEswp.setSwapEdge(edgeToSwap);
      if(LEswp.topoCheck()) {
        if(LEswp.geomCheck()) {

          LEswp.sizeCheck();
          if( result->getMaxSize() < maxEdgeLenSq)
          {
            if( result->getWorstShape() > bestEffect )
            {
              bestEffect = result->getWorstShape();
              if(bestMod)
              {
                delete bestMod;
                affectedLyrFcs.clear();
              }
              bestMod = new layerEdgeSwapMod(LEswp);
              E_layerFaces(edgeToSwap, affectedLyrFcs);
            }
          }
        }
      }


      // collapse two short edges
      // (assuming triangular layer face)
      for(int iEdge=0; iEdge<3; iEdge++) {
        edge = F_edge(face,iEdge);

        if(edge==edgeToSwap)
            continue;

        edgeDel = edge;
        for(int iVert=0; iVert<2; iVert++)
          vtx[iVert] = E_vertex(edgeDel,iVert);

        for(int iVert=0; iVert<2; iVert++) {
          LEclps.setCollaps(edgeDel,vtx[iVert],vtx[(iVert+1)%2]);
          if( !LEclps.topoCheck() )
            continue;

          if( !LEclps.geomCheck() )
            continue;

          if( !LEclps.sizeCheck() )
            continue;

          if( result->getMaxSize()>upperBoundSq &&
              result->getRatioSquareAtMaxSize()>1. )
              continue;

          if(result->getWorstShape() > bestEffect) {
            bestEffect = result->getWorstShape();
            if(bestMod) {
              delete bestMod;
              affectedLyrFcs.clear();
            }
            bestMod = new layerEdgeCollapsMod(LEclps);
            V_layerFaces(vtx[iVert], affectedLyrFcs);
          }
        }
      }

      if(bestMod) 
      {
        applied = 1;

        for(int iFace=0; iFace<affectedLyrFcs.size(); iFace++) 
        {
          face = affectedLyrFcs[iFace];
          // removedFaces.append(face);
          removedFaces.insert(face);
          pBLayerBLayer = EN_getBL(face);
          newAndNotRemSlivers.erase(pBLayerBLayer);
          FacesNextToPB.erase(pBLayerBLayer);
        }
        affectedLyrFcs.clear();

        switch(bestMod->type()) 
        {
        case LECOLAPS :

          nLEclps_withinLoop++;
          bestMod->apply();

          V_layerFaces(((layerEdgeCollapsMod*)bestMod)->vertR(), newLyrFcs);
          for(int iNewFace=0; iNewFace < newLyrFcs.size(); iNewFace++) {
            face = newLyrFcs[iNewFace];
            stackOfFaces.clear();
            pBLayerBLayer = EN_getBL(face);
            BL_getHorizontalFaces(pBLayerBLayer, stackOfFaces);
//            stackOfFaces = F_getStackOfFaces(face,0);
            numFaces = stackOfFaces.size();
            for(int iFace=0; iFace<numFaces; iFace++) {
              lyrFc = stackOfFaces[iFace];
              if (F_typeInBL(lyrFc) == fTRANSITION)
                continue;
              shpMeasure->F_shape(lyrFc,0,&fcShp);
              if(fcShp < fcShpLowerBound) 
              {
                newAndNotRemSlivers.insert(pBLayerBLayer);
                break;
              }
            }
          }
          newLyrFcs.clear();

          break;
        case LESWAP :

          nLEswap_withinLoop++;

          bestMod->apply();

          break;
        default :
          cout<<"\nError in meshAdapt::optimizeSurfaceInBL()..."<<endl;
          cout<<"incorrect mesh modification detected"<<endl;
          exit(0);
        }

        delete bestMod;
      }
    }

    nLEclps += nLEclps_withinLoop;
    nLEswap += nLEswap_withinLoop;
#ifdef DEBUG
    adaptUtil::Info(nLEclps_withinLoop," zero level layer edge collapses are performed to remove sliver layer faces");
    adaptUtil::Info(nLEswap_withinLoop," zero level layer edge swaps are performed to remove sliver layer faces");
    adaptUtil::Info(corrected_withinLoop," consequently corrected sliver layer faces");
#endif

#ifdef MA_PARALLEL
      if (P_size() > 1)
      {
        CM->finalize_send();

        fromMeshTools::syncClassification(pmesh);
 
        int iMigr = mMigrateForShapeCorrectBL(FacesNextToPB, newAndNotRemSlivers, userLB);
      }
#endif  /// VERIFY THE CODE FO THE SERIAL RUN

      Fvec.clear();

      /// Ideally for the efficiency here we should traverse leftovers from newAndNotRemSlivers and the newly migrated BLs!!!
      /// Traversing all the BLs again because of the newly migrated BLs are not available.
      for (SetIt = newAndNotRemSlivers.begin(); SetIt != newAndNotRemSlivers.end(); ++SetIt)
      {
        BL_getHorizontalFaces(*SetIt, stackOfFaces);
        face = stackOfFaces[0];

        numFaces = stackOfFaces.size();
        for(int iFace=0; iFace<numFaces; iFace++)
        {
          lyrFc = stackOfFaces[iFace];
          if (F_typeInBL(lyrFc) == fTRANSITION)
            continue;
          shpMeasure->F_shape(lyrFc,0,&fcShp);
          if(fcShp < fcShpLowerBound)
          {
            Fvec.push_back(std::make_pair(fcShp,face));
            break;
          }
        }
      }      
      
      removedFaces.clear();
  }
  
  // apply edge swap to improves worst shape
  int nLEswapOpt=0, listSize;
  double mtol=M_getTolerance();
  double oriWorst;
  vector<pRegion> rlist;
  vector<pEdge> elist;
  pEdge interfaceEdge;

  int countImprFcShp, numLyrFaces;
  double faceShp, origFcShpWorst, finalFcShpWorst, allOrigFcShpWorst, allFinalFcShpWorst;
  double fcNormal[3], fxyz[3][3];
  vector<pVertex> GCs[4];
  pVertex vt;
  pEdge edg;
  pFace fc;
  pMSize pmt[3];
  pPList fverts;
  vector<pFace> lyrFaces;

//   SCOREC::Util::scorecSSList<pEdge> edgesToImprLayerFaceShp;

  int ne=M_numEdges(pmesh), i=0;
  EIter eit=M_edgeIter(pmesh);
  // --- osahni
  // should work with a dynamic list
  // moreover improve the loop above
  // while(0)
  while( edge=EIter_next(eit) )
  {
    if( i>ne ) break;
    i++;

    if( EN_isBLEntity((pEntity)edge) &&
        EN_levelInBL((pEntity)edge)==0 &&
        E_typeInBL(edge)==eLAYER ) {

      if( !EN_okTo(DELETE,(pEntity)edge) )
        continue;

      LEswp.setSwapEdge(edge);
      if( LEswp.topoCheck() ) {
        if( LEswp.geomCheck() ) {

          if(!LEswp.sizeCheck())
            continue;

          if( result->getMaxSize()>upperBoundSq )
            continue;

          for(int iVert=0; iVert<2; iVert++)
            vtx[iVert] = E_vertex(edge,iVert);

//          GCs[0] = V_growthCurve(vtx[0]);
//          GCs[1] = V_growthCurve(vtx[1]);
          BL_getGrowthCurveNodes(vtx[0], GCs[0]);
          BL_getGrowthCurveNodes(vtx[1], GCs[1]);

          BL_getHorizontalEdgesByEdge(edge, elist);
          listSize = elist.size();
          interfaceEdge = elist[listSize-1];

          // WE MUST INCORPORATE QUALITY OF LAYER FACES ON LAYER
          // SURFACES (i.e., ON STACK) TO PERFORM LAYER EDGE SWAP
          E_layerFaces(edge, lyrFaces);
          // must be 2 (cannot swap an edge classified on model edge)
          // can be 1 due to partial BL mesh on a surface
          numLyrFaces = lyrFaces.size();
          for(int iFace=0; iFace<numLyrFaces; iFace++) {
            fc = lyrFaces[iFace];

            int iGC=2;
            if(F_dirUsingEdge(fc,edge))
              iGC=3;
            BL_getGrowthCurveNodes(F_edOpVt(fc,edge),GCs[iGC]);
          }

          // count number of layers where edge swap improves face shape
          countImprFcShp = 0;
          allOrigFcShpWorst = 1., allFinalFcShpWorst = 1.;
          for(int iList=0; iList<listSize; iList++) {
            edg = elist[iList];

            int orderOfGCs[3] = {0,2,3};
            origFcShpWorst = 1., finalFcShpWorst = 1.;
            E_layerFaces(edg, lyrFaces);
            // must be 2 (cannot swap an edge classified on model edge)
            // can be 1 due to partial BL mesh on a surface
            numLyrFaces = lyrFaces.size();
            for(int iFace=0; iFace<numLyrFaces; iFace++) {
              fc = lyrFaces[iFace];

              if(1) // (iFace==0)
              {
                double mag = 0.;
                F_normalVector(fc,1,fcNormal);
                for(int iComp=0; iComp<3; iComp++)
                  mag += fcNormal[iComp]*fcNormal[iComp];
                mag = sqrt(mag);
                for(int iComp=0; iComp<3; iComp++)
                  fcNormal[iComp] = fcNormal[iComp]/mag;
              }

              fverts = F_vertices(fc,1);
              // assuming triangular layer faces
              for(int iVert=0; iVert<3; iVert++) {
                vt = (pVertex)PList_item(fverts,iVert);
                V_coord(vt,fxyz[iVert]);
                pmt[iVert]=pSizeField->getSize(vt);
              }
              PList_delete(fverts);

              shpMeasure->XYZ_shape(fxyz,pmt,fcNormal,&faceShp);
              if(origFcShpWorst>faceShp)
                origFcShpWorst = faceShp;

              if(iFace)
                { orderOfGCs[0]=3; orderOfGCs[1]=2; orderOfGCs[2]=1; }
              // assuming triangular layer faces
              for(int iVert=0; iVert<3; iVert++) {
                vt = GCs[orderOfGCs[iVert]][iList];

                V_coord(vt,fxyz[iVert]);
                pmt[iVert]=pSizeField->getSize(vt);
              }

              shpMeasure->XYZ_shape(fxyz,pmt,fcNormal,&faceShp);
              if(finalFcShpWorst>faceShp)
                finalFcShpWorst = faceShp;
            }

            if(allFinalFcShpWorst>finalFcShpWorst)
              allFinalFcShpWorst = finalFcShpWorst;

            if(allOrigFcShpWorst>origFcShpWorst)
              allOrigFcShpWorst = origFcShpWorst;

            if(finalFcShpWorst>origFcShpWorst)
              countImprFcShp++;
          }

          E_nonBLRegions(interfaceEdge, rlist);
          pPList p_rlist = PList_new();
          for (int iReg = 0; iReg < rlist.size(); ++iReg)
            PList_append(p_rlist, (void*)rlist[iReg]);
          oriWorst=adaptUtil::E_worstShp(shpMeasure,p_rlist,interfaceEdge);
          PList_delete(p_rlist);

          if( oriWorst <mtol ) {
            adaptUtil::Warning("flat elements at BL interface (meshAdapt::optimizeSurfaceInBL())");
            if( result->getWorstShape() > (mtol + oriWorst) ) {

//            edgesToImprLayerFaceShp.append(edge);

//            if( edgesToImprLayerFaceShp.inList(edge) )
//              edgesToImprLayerFaceShp.remove(edge);

              LEswp.apply();
              nLEswapOpt++;
              continue;
            }
          }

          // if for all layer faces shape is improved
          // along with the final worst shape for all layer faces
          // is higher than original one
          // then consider the original worst shape as minimum of
          // interface elements and layer faces
          if( countImprFcShp==listSize &&
              allFinalFcShpWorst > IMPROVE_RATIO*allOrigFcShpWorst ) {
            if(oriWorst*oriWorst > allOrigFcShpWorst*allOrigFcShpWorst*allOrigFcShpWorst)
              oriWorst = allOrigFcShpWorst*sqrt(allOrigFcShpWorst);
          }
          else {
            continue;
          }

          if( result->getWorstShape() > IMPROVE_RATIO*oriWorst + mtol ) {

//          edgesToImprLayerFaceShp.append(edge);

//          if( edgesToImprLayerFaceShp.inList(edge) )
//            edgesToImprLayerFaceShp.remove(edge);

            LEswp.apply();
            nLEswapOpt++;
          }
//        else if(countImprFcShp==listSize) {

// //       edgesToImprLayerFaceShp.append(edge);

//          LEswp.apply();
//          nLEswapOpt++;
//        }
        }
      }
    }
  }
  EIter_delete(eit);
#ifdef DEBUG
  adaptUtil::Info(nLEswapOpt," zero level layer edge swaps are performed to remove sliver interface regions/layer faces");
#endif
  return nLEswapOpt;
}


// opOrStage : operation or stage
// opOrStage = 0 - default
// opOrStage = 1 - split
void meshAdapt::constrainBL(int opOrStage) 
{

  int iNumLayers;
  pRegion pRegionRgn;
  pBLayer pBLayerBL;

/*
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    pBLayerBL = *egIt;
    iNumLayers = pBLayerBL->size();
    pRegionRgn = pBLayerBL->getEntity(iNumLayers - 1);
    setConstraintBL((pEntity)pRegionRgn);
  }
*/

  /// Probably it will be enough to just constrain top-most regions of each boundary layer stack and also faces, edges, vertices on the interface
  /// and on the part boundary, but that will require additional entity traversal
  pMeshEnt FMDB_Ent;
  pPartEntIter pEntIter;

  /// Constrain regions first
  FMDB_PartEntIter_Init (pmesh, FMDB_REGION, FMDB_ALLTOPO, pEntIter);
  int iEnd = 0;
  while (!iEnd)
  {
    FMDB_PartEntIter_GetNext(pEntIter, FMDB_Ent);
    if (EN_isBLEntity(FMDB_Ent))
      EN_constrainAll((pEntity)FMDB_Ent);
    else if (FMDB_Ent->getType() == PYRAMID)
      setConstraintBL((pEntity)FMDB_Ent);
    FMDB_PartEntIter_IsEnd(pEntIter, &iEnd);
  }
  FMDB_PartEntIter_Del(pEntIter);

  /// All other BL entities
  for (int iType = 0; iType < 4; ++iType)
  {
    FMDB_PartEntIter_Init (pmesh, iType, FMDB_ALLTOPO, pEntIter);
    iEnd = 0;
    while (!iEnd)
    {
      FMDB_PartEntIter_GetNext(pEntIter, FMDB_Ent);
      if (EN_isBLEntity(FMDB_Ent))
        EN_constrainAll((pEntity)FMDB_Ent);
      FMDB_PartEntIter_IsEnd(pEntIter, &iEnd);
    }
    FMDB_PartEntIter_Del(pEntIter);
  }

/*
  pRegion region;
  RIter rit = M_regionIter(pmesh);
  while(region = RIter_next(rit)) 
  {
    if(EN_isBLEntity((pEntity)region) || region->getType() != TET) 
    {
      setConstraintBL((pEntity)region);
    }
  }
  RIter_delete(rit);
*/

  pFace face;
  FIter fit = M_faceIter(pmesh);

/// Don't think the case below exists anymore
/*
  // constrain zero level layer faces both at BL surface and interface
  while(face = FIter_next(fit)) {
    if(EN_isBLEntity((pEntity)face) && EN_levelInBL((pEntity)face)==0) {
#ifdef DEBUG
      if(F_typeInBL(face)!=fLAYER) {
        cout<<"\nError in meshAdapt::constrainBL()..."<<endl;
        cout<<"zero level BL face is NOT a layer face"<<endl;
        exit(0);
      }
#endif
      if(F_atBLInterface(face))
        setConstraintBL((pEntity)face);
    }
  }
  FIter_reset(fit);
*/
  // --- osahni
  // constrain face for TWO2TWO swap in case of operations other than split
  // (no need to constrain face with all BL nodes)
  if(opOrStage!=1) {
//    FIter_reset(fit);

    while(face = FIter_next(fit)) 
    {
      if(!EN_isBLEntity((pEntity)face)) 
      {
        if (face->getType() == QUAD)
          continue;

        int iFound = 0;
        for (int iEdge = 0; iEdge < 3; ++iEdge)
        {
          if (E_typeInBL(F_edge(face, iEdge)) == eGROWTH)
          { 
            iFound = 1;
            break;
          }
        }
        if (iFound)
          continue;

        if(!F_checkForTwo2TwoSwap(face)) 
        {
          // setConstraintBL((pEntity)face);
          // use EN_constrainAll() to constrain just the face
          // if this is changed change the unconstrain parts
          // (i.e., in unconstrainBL() thickessAdaptationInBL() etc.)
          EN_constrainAll((pEntity)face);
        }

        // if(EN_allBLNodes((pEntity)face)) {
          // setConstraintBL((pEntity)face);
          // EN_constrainAll((pEntity)face);
        // }
      }
    }
  }
  FIter_delete(fit);
}

void meshAdapt::unconstrainBL(int opOrStage) {

  int iNumLayers;
  pRegion pRegionRgn;
  pBLayer pBLayerBL;
/*
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    pBLayerBL = *egIt;
    iNumLayers = pBLayerBL->size();
    pRegionRgn = pBLayerBL->getEntity(iNumLayers - 1);
    setUnconstraintBL((pEntity)pRegionRgn);
  }
*/

  /// Probably it will be enough to just constrain top-most regions of each boundary layer stack and also faces, edges, vertices on the interface
  /// and on the part boundary, but that will require additional entity traversal
  pMeshEnt FMDB_Ent;
  pPartEntIter pEntIter;

  /// Unconstrain regions first
  FMDB_PartEntIter_Init (pmesh, FMDB_REGION, FMDB_ALLTOPO, pEntIter);
  int iEnd = 0;
  while (!iEnd)
  {
    FMDB_PartEntIter_GetNext(pEntIter, FMDB_Ent);
    if (EN_isBLEntity(FMDB_Ent))
      EN_unconstrainAll((pEntity)FMDB_Ent);
    else if (FMDB_Ent->getType() == PYRAMID)
      setUnconstraintBL((pEntity)FMDB_Ent);
    FMDB_PartEntIter_IsEnd(pEntIter, &iEnd);
  }
  FMDB_PartEntIter_Del(pEntIter);

  /// All other BL entities
  for (int iType = 0; iType < 3; ++iType)
  {
    FMDB_PartEntIter_Init (pmesh, iType, FMDB_ALLTOPO, pEntIter);
    iEnd = 0;
    while (!iEnd)
    {
      FMDB_PartEntIter_GetNext(pEntIter, FMDB_Ent);
      if (EN_isBLEntity(FMDB_Ent))
        EN_unconstrainAll((pEntity)FMDB_Ent);
      FMDB_PartEntIter_IsEnd(pEntIter, &iEnd);
    }
    FMDB_PartEntIter_Del(pEntIter);
  }


/*
  pRegion region;
  RIter rit = M_regionIter(pmesh);
  while(region = RIter_next(rit)) 
  {
    if(EN_isBLEntity((pEntity)region) || region->getType() != TET)  
    {
      setUnconstraintBL((pEntity)region);
    }
  }
  RIter_delete(rit);
*/

  pFace face;
  FIter fit = M_faceIter(pmesh);
/*
  while(face = FIter_next(fit)) {
    if(EN_isBLEntity((pEntity)face) && EN_levelInBL((pEntity)face)==0) {
#ifdef DEBUG
      if(F_typeInBL(face)!=fLAYER) {
        cout<<"\nError in meshAdapt::unconstrainBL()..."<<endl;
        cout<<"zero level BL face is NOT a layer face"<<endl;
        exit(0);
      }
#endif
      if(F_atBLInterface(face))
        setUnconstraintBL((pEntity)face);
    }
  }
  FIter_reset(fit);
*/

  if(opOrStage!=1) {
//    FIter_reset(fit);
    while(face = FIter_next(fit)) 
    {
      if(!EN_isBLEntity((pEntity)face)) 
      {
        if (face->getType() == QUAD)
          continue;

        int iFound = 0;
        for (int iEdge = 0; iEdge < 3; ++iEdge)
        {
          if (E_typeInBL(F_edge(face, iEdge)) == eGROWTH)
          {
            iFound = 1;
            break;
          }
        }
        if (iFound)
        {
//          EN_unconstrainAll((pEntity)face);
          continue;
        }

        if(!F_checkForTwo2TwoSwap(face)) 
        {
          // keep this consistent with constrainBL()
          // either use EN_unconstrainAll() or setUnconstraintBL()
          // EN_constrainAll seems more appropriate - just constrains face
          // setUnconstraintBL((pEntity)face);
          EN_unconstrainAll((pEntity)face);
        }
        // if(EN_allBLNodes((pEntity)face)) {
          // setUnconstraintBL((pEntity)face);
          // EN_unconstrainAll((pEntity)face);
        // }
      }
    }
  }
  FIter_delete(fit);

/*
  pEdge edge;
//   pRegion nonBLRgn[2];
//   int foundCtrFace;
//   pPList layerFcs;
  EIter eit = M_edgeIter(pmesh);
  while(0) { //edge = EIter_next(eit)) {
    if(opOrStage!=1 && EN_allBLNodes((pEntity)edge)) {
      // setUnconstraintBL((pEntity)edge);
    }

//     if( EN_isBLEntity((pEntity)edge) &&
//      E_atBLInterface(edge) ) {

//       layerFcs = E_layerFaces(edge);
//       // cannot swap an edge classified on model edge
//       if(PList_size(layerFcs)==2) {
//      for(int iFace=0; iFace<2; iFace++) {
//        face = (pFace)PList_item(layerFcs,iFace);

//        nonBLRgn[iFace] = F_region(face,0);
//        if( nonBLRgn[iFace] &&
//            EN_isBLEntity((pEntity)nonBLRgn[iFace])) {
//          if(!EN_isBLEntity((pEntity)F_region(face,1)))
//            nonBLRgn[iFace] = F_region(face,1);
//        }
//      }

//      if(nonBLRgn[0] && nonBLRgn[1]) {
//        foundCtrFace = 0;
//        // assuming non-BL regions to be tets
//        for(int iFace=0; iFace<4; iFace++) {
//          face = R_face(nonBLRgn[0],iFace);
//          if(R_inClosure(nonBLRgn[1],(pEntity)face)) {
//            EN_unconstrainAll((pEntity)face);
//            break;
//          }
//        }
//      }
//       }
//       PList_delete(layerFcs);
//     }
  }
  EIter_delete(eit);
*/
}

/* constrain a BL mesh entity and its downward entities from all mesh modifications */
void meshAdapt::setConstraintBL(pEntity e)
{
  EN_constrainAll(e);

  switch (EN_type(e)) {
  case Tedge:
    {
      EN_constrainAll( (pEntity)E_vertex((pEdge)e,0) );
      EN_constrainAll( (pEntity)E_vertex((pEdge)e,1) );
    }
    break;
  case Tface:
    {
      int numEdges = F_numEdges((pFace)e);
      for(int iEdge=0; iEdge<numEdges; iEdge++)
        setConstraintBL( (pEntity)F_edge((pFace)e,iEdge) );
    }
    break;
  case Tregion:
    {
      int numFaces = R_numFaces((pRegion)e);
      for(int iFace=0; iFace<numFaces; iFace++)
        setConstraintBL( (pEntity)R_face((pRegion)e,iFace) );
    }
    break;
  }
  return;
}

/* unconstrain a BL mesh entity and its downward entities from all mesh modifications */
void meshAdapt::setUnconstraintBL(pEntity e)
{
  EN_unconstrainAll(e);

  switch (EN_type(e)) {
  case Tedge:
    {
      EN_unconstrainAll( (pEntity)E_vertex((pEdge)e,0) );
      EN_unconstrainAll( (pEntity)E_vertex((pEdge)e,1) );
    }
    break;
  case Tface:
    {
      int numEdges = F_numEdges((pFace)e);
      for(int iEdge=0; iEdge<numEdges; iEdge++)
        setUnconstraintBL( (pEntity)F_edge((pFace)e,iEdge) );
    }
    break;
  case Tregion:
    {
      int numFaces = R_numFaces((pRegion)e);
      for(int iFace=0; iFace<numFaces; iFace++)
        setUnconstraintBL( (pEntity)R_face((pRegion)e,iFace) );
    }
    break;
  }
  return;
}


void meshAdapt::constrainThicknessAdapt() 
{
  int count = 0;
  pVertex vtx, oVtx;
  int gcThicknessTag, notBLSnapTag;
  pEdge edge;
  EIter eit = M_edgeIter(pmesh);
  if(thicknessAdaptExecuted) {
    while (edge = EIter_next(eit)) {
      for(int iVert=0; iVert<2; iVert++) {
        vtx = E_vertex(edge,iVert);
        if(!EN_isBLEntity((pEntity)vtx))
          continue;

        oVtx = V_getOriginatingNode(vtx);

        if(!EN_getDataInt((pEntity)oVtx,gcThicknessID,
                          &gcThicknessTag)) {
          setConstraintBL((pEntity)edge );
          count++;
          break;
        }
      }
    }
  }
  EIter_delete(eit);
}


void meshAdapt::unconstrainThicknessAdapt() 
{
  pVertex vtx, oVtx;
  int gcThicknessTag, notBLSnapTag;
  pEdge edge;
  EIter eit = M_edgeIter(pmesh);
  if(thicknessAdaptExecuted) {
    while (edge = EIter_next(eit)) {
      for(int iVert=0; iVert<2; iVert++) {
        vtx = E_vertex(edge,iVert);
        if(!EN_isBLEntity((pEntity)vtx))
          continue;

        oVtx = V_getOriginatingNode(vtx);

        if(!EN_getDataInt((pEntity)oVtx,gcThicknessID,
                          &gcThicknessTag)) {
          setUnconstraintBL((pEntity)edge );
          break;
        }
      }
    }
  }
  EIter_delete(eit);
}


/*
int meshAdapt::testCollapseInBL(double upperBoundSq) {

  // declare the layer edge collapse object
  layerEdgeCollapsMod *LEclps = new layerEdgeCollapsMod(pmesh,pSizeField,shpMeasure,result);
  LEclps->setCallback(function_CB,userData_CB);
  // LEclps->setAcptControl(1);
  if( checkVolume )
    LEclps->setCheckVolume(dV_limit,dA_limit);
  if( model_type != 2 )
    LEclps->setModelType(NOPARAM);

  double mtol=M_getTolerance();

  pVertex vtx, oVtx;
  VIter vit = M_vertexIter(pmesh);
  while(vtx = VIter_next(vit)) {

    if(EN_levelInBL((pEntity)vtx)!=0)
      continue;

    if(!V_numTransitionEdges(vtx))
      continue;

    pVertex oVtx;
    pEdge edgeDel;
    pPList vLyrEdges = V_layerEdges(vtx);
    int numLyrEdges = PList_size(vLyrEdges);
    for(int iEdge=0; iEdge<numLyrEdges; iEdge++) {
      edgeDel = (pEdge)PList_item(vLyrEdges,iEdge);
      oVtx = E_otherVertex(edgeDel,vtx);
      if(V_totNumLayers(oVtx))
        break;
    }
    PList_delete(vLyrEdges);

    LEclps->setCollaps(edgeDel,vtx,oVtx);
    if( !LEclps->topoCheck() )
      continue;

    LEclps->sizeCheck();
    if( result->getMaxSize()>upperBoundSq+mtol &&
        result->getRatioSquareAtMaxSize()>1. )
      int tt; // continue;
    if( !LEclps->geomCheck() )
      continue;
    if( result->getWorstShape() < mtol )
      continue;

    if( model_type ) pSnap->remove(vtx);

    LEclps->apply();

    // just apply it on one edge
    break;
  }
  VIter_delete(vit);

  return 1;
}
*/

#ifdef MA_PARALLEL
int meshAdapt::adjustGrowthDirectionForGCs(pmMigrationCallbacks& userLB) 
#else
int meshAdapt::adjustGrowthDirectionForGCs()
#endif
{

  // acos(0.9848) is close to 10 degress
  // acos(0.9659) is close to 15 degress
  // acos(0.9500) is close to 18.2 degress
  // acos(0.8000) is close to 36.87 degress
  double cosAngleTol = 0.9848;
  double cosAngleTolSmooth = 0.9848;

  int numLayerFaces, foundUntaggedLayerFace, listSize, validGC, layerFaceNormalChangeTag;
  double dotP, tol = M_getTolerance();
  double growthDir[3], avgGrowthEdgeDir[3], fnormal[3], fxyz[3][3], fvec[2][3], xyz[2][3], vec[3];
  double *initialLocation;
  dArray *currentLocations, *targetLocations, *locPtr;

  pMeshDataId initialLocationID = MD_newMeshDataId("initial location ID");
  pMeshDataId currentLocationsID = MD_newMeshDataId("current locations ID");
  pMeshDataId targetLocationsID = MD_newMeshDataId("target locations ID");

  pFace layerFace, face;
  pRegion rgn;
  pGEntity gent;
  pPList vregs, vRegs;
  vector<pVertex> gcNodes;
  vector<pEdge> gcEdges;
  vector<pFace> vLayerFaces;

  int numAdjust = 0;
  pVertex vtx, node, onode, topNode;

  pMeshDataId procTag = MD_lookupMeshDataId("ProcessedONodeTag");
  deque<pVertex> procVerts;
  int value;

  /// Loop over entity groups
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    /// Find the zero-level face, i.e. the face on the surface
    face = BL_GetZeroLvlFace((pBLayer)(*egIt));

    for (int iVert = 0; iVert < 3; ++iVert)
    {
      vtx = F_vertex(face, iVert);
      if (!V_isOriginatingNode(vtx) || EN_getDataInt(vtx,procTag,&value))
        continue;

      EN_attachDataInt(vtx,procTag,1);
      procVerts.push_back(vtx);

    BL_getGrowthCurveNodes(vtx, gcNodes); 
    // at this point the normal/growth vector already set for GC may NOT be useful
    // (as that is what needs to be computed in this routine)
    // hence normalized/unit average of growth edge vectors is used at this stage
    GC_getAvgGrowthEdgeDir(gcNodes, avgGrowthEdgeDir);

    GC_getNormalVector(vtx, growthDir);
    dotP = dotProd(avgGrowthEdgeDir,growthDir);
    // acos(0.9848) is close to 10 degress
    // acos(0.9659) is close to 15 degress
    // acos(0.9500) is close to 18.2 degress
    // acos(0.8000) is close to 36.87 degress
    // if all layer faces are not on same model surface then take avgGrowthEdgeDir as normal vector
    if(dotP<cosAngleTol) {
#ifdef DEBUG
//       cout<<"\n WARNING in meshAdapt::adjustGrowthDirectionForGCs()"<<endl;
//       cout<<" angle change in growth dir. too high [dotP="<<dotP<<",cosAngleTol="<<cosAngleTol<<"]\n"<<endl;
#endif
      // set the normal vector (growth direction) for GC as average of growth edge vectors
      GC_setNormalVector(vtx, avgGrowthEdgeDir);

      // assuming high angle change is a consequence of limitations due to geometric model etc.
      // high angle change can result in long (or short) layer edges on higher levels
    }
    else {
      // set the normal vector (growth direction) for GC as average of face normals
      GC_setNormalVector(vtx, growthDir);
    }
    }
  }

  int smoothGrowthDirs = 1, numAdjGCs, gcClassificationType, gcClassificationTag;
  double adjGCGrowthDir[3], curGrowthDir[3];
  vector<pVertex> adjGCs;

  for (deque<pEdge>::iterator eIt = procVerts.begin(); eIt != procVerts.end(); ++eIt)
  {
    vtx = *eIt;
    V_layerFaces(vtx, vLayerFaces);
    numLayerFaces = vLayerFaces.size();
    // if all layer faces are not on same model surface then take avgGrowthEdgeDir as normal vector
    int fTagSame = 1, keepTag = -1;
    for(int iLayerFace=0; iLayerFace<numLayerFaces; iLayerFace++) {
      layerFace = vLayerFaces[iLayerFace];
      if(keepTag<0)
        keepTag = GEN_tag(F_whatIn(layerFace));
      if(keepTag!=GEN_tag(F_whatIn(layerFace))) {
        fTagSame = 0;
        break;
      }
    }
    if(!fTagSame) {
      continue;
    }

    foundUntaggedLayerFace = 0;
    for(int iLayerFace=0; iLayerFace<numLayerFaces; iLayerFace++) {
      layerFace = vLayerFaces[iLayerFace];

      // if there is a layer face that is untagged (with layerFaceNormalChangeID)
      // then adjust the growth direction of the GC at this originating node
      // this can happen due to split and/or collapse, snap is not really considered seprarately 
      // as this routine is supposed to be called after split, snap and collapse sequence of operations 
      // (example, in each loop/iteration of stage two)
      // all the layer faces will be untagged in the first call of this routine 
      // (which can be before stage two or in first loop/iteration of stage two)
      if(!EN_getDataInt((pEntity)layerFace,layerFaceNormalChangeID,&layerFaceNormalChangeTag)) {
	foundUntaggedLayerFace = 1;
	break;
      }
    }

    if(!foundUntaggedLayerFace)
      continue;
/*
    if(V_isCornerONode(vtx)) {
      cout<<"\nError in meshAdapt::adjustGrowthDirectionForGCs()..."<<endl;
      cout<<"corner vertex NOT supported as of now"<<endl;
      exit(0);
    }
*/
    BL_getGrowthCurveNodes(vtx, gcNodes);
    GC_getNormalVector(vtx, growthDir);

    // at this point the normal/growth vector already set for GC may NOT be useful
    // (as that is what needs to be computed in this routine)
    // hence normalized/unit average of growth edge vectors is used at this stage
    GC_getAvgGrowthEdgeDir(gcNodes, avgGrowthEdgeDir);
    GC_getClassification(gcNodes, gcClassificationType, gcClassificationTag);//gc->getClassificationType();

    if(smoothGrowthDirs) {
      for(int iComp=0; iComp<3; iComp++)
	curGrowthDir[iComp] = growthDir[iComp];


      V_getAdjacentOrigVerts(vtx, adjGCs);
      numAdjGCs = adjGCs.size();
      pVertex adjGC;
      for(int iAdjGC=0; iAdjGC<numAdjGCs; iAdjGC++) {
	adjGC = adjGCs[iAdjGC];

        vector<pVertex> adjGCNodes;
        BL_getGrowthCurveNodes(adjGC, adjGCNodes);

        int adjGC_Type, adjGC_Tag;
        GC_getClassification(gcNodes, adjGC_Type, adjGC_Tag);
	if(adjGC_Type > gcClassificationType || adjGCNodes.size()<2)
	  continue;

	GC_getNormalVector(adjGC, adjGCGrowthDir);

	for(int iComp=0; iComp<3; iComp++)
	  growthDir[iComp] += adjGCGrowthDir[iComp];
      }

      // normalization would be enough
//       // take the normalized average
//       for(int iComp=0; iComp<3; iComp++)
// 	growthDir[iComp] /= (numAdjGCs+1);
      normVt(growthDir,growthDir);

      // --- osahni : curGrowthCurve may NOT be useful and already rotated
      // dotP = dotProd(curGrowthDir,growthDir);
      dotP = dotProd(avgGrowthEdgeDir,growthDir);
      // acos(0.9848) is close to 10 degress
      // acos(0.9659) is close to 15 degress
      // acos(0.9500) is close to 18.2 degress
      // acos(0.8000) is close to 36.87 degress
      if(dotP<cosAngleTolSmooth) {
#ifdef DEBUG
//       cout<<"\n WARNING in meshAdapt::adjustGrowthDirectionForGCs()"<<endl;
//       cout<<" angle change in growth dir. too high while smoothing [dotP="<<dotP<<",cosAngleTolSmooth="<<cosAngleTolSmooth<<"]\n"<<endl;
#endif
	// limit angle change after smoothing
	// reset to curGrowthDir
	for(int iComp=0; iComp<3; iComp++)
	  growthDir[iComp] = curGrowthDir[iComp];
      }
    }

    dotP = dotProd(avgGrowthEdgeDir,growthDir);
    if(dotP>=0.99 && dotP<=1.0)
      continue;

    listSize = gcNodes.size();
    topNode = gcNodes[listSize-1];

    if(listSize==1) {
      cout<<"\n WARNING in meshAdapt::adjustGrowthDirectionForGCs()"<<endl;
      cout<<"only one node on GC which seems to be a corner node\n"<<endl;
      exit(0);
    }

    // exclude the originating node
    currentLocations = new dArray[listSize-1];
    targetLocations = new dArray[listSize-1];

    V_coord(vtx,xyz[0]);
    if(gcClassificationType==3) {
      // exclude the originating node
      for(int iNode=0; iNode<listSize-1; iNode++) {
	node = gcNodes[iNode+1];

	V_coord(node,xyz[1]);
	for(int iComp=0; iComp<3; iComp++)
	  currentLocations[iNode][iComp] = xyz[1][iComp];

	diffVt(xyz[1],xyz[0],vec);
	// at this point the normal/growth vector set for GC may NOT be useful
	// (as that is what needs to be computed in this routine)
	// hence normalized/unit average of growth edge vectors is used at this stage
	dotP = dotProd(avgGrowthEdgeDir,vec);
	for(int iComp=0; iComp<3; iComp++)
	  targetLocations[iNode][iComp] = xyz[0][iComp] + dotP*growthDir[iComp];
      }
    }
    else {
      // exclude the originating node
      for(int iNode=0; iNode<listSize-1; iNode++) {
	node = gcNodes[iNode+1];

	V_coord(node,xyz[1]);
	for(int iComp=0; iComp<3; iComp++)
	  currentLocations[iNode][iComp] = xyz[1][iComp];

	diffVt(xyz[1],xyz[0],vec);
	// at this point the normal/growth vector set for GC may NOT be useful
	// (as that is what needs to be computed in this routine)
	// hence normalized/unit average of growth edge vectors is used at this stage
	dotP = dotProd(avgGrowthEdgeDir,vec);
	for(int iComp=0; iComp<3; iComp++)
	  targetLocations[iNode][iComp] = xyz[0][iComp] + dotP*growthDir[iComp];
      }

       // 2nd arg. : "0" implies other than originating node
       updateTargetLocationsOfUpperNodesOnGCOnModelBdry(gcNodes,0,targetLocations);

// 	double clsLoc[3], par[3];
// 	// clsLoc is current location of node by default
// 	V_coord(node,clsLoc);
// 	gent = V_whatIn(node);
// 	switch(GEN_type(gent)) {
// 	case 0 :
// 	  cout<<"\nError in meshAdapt::adjustGrowthDirectionForGCs()..."<<endl;
// 	  cout<<"non-originating node is classified on model vertex"<<endl;
// 	  exit(0);
// 	  break;
// 	case 1 :
// 	  GE_closestPoint((pGEdge)gent,targetLocations[iNode],clsLoc,par);
// 	  break;
// 	case 2 :
// 	  GF_closestPoint((pGFace)gent,targetLocations[iNode],clsLoc,par);
// 	  break;
// 	case 3 :
// 	  // this should not happen (i.e., partial GC on model bdry.)
// 	  cout<<"\nError in meshAdapt::adjustGrowthDirectionForGCs()..."<<endl;
// 	  cout<<"partial growth curve on model bdry."<<endl;
// 	  exit(0);
// 	}

// 	// parametric coordinates for GC on model bdry. are 
// 	// taken care later with updateGCOnModelBdry()
// 	for(int iComp=0; iComp<3; iComp++)
// 	  targetLocations[iNode][iComp] = clsLoc[iComp];
    }

    if(EN_getDataPtr((pEntity)vtx,currentLocationsID,(void **)&locPtr)) {
      cout<<"\nError in meshAdapt::adjustGrowthDirectionForGCs()..."<<endl;
      cout<<"current locations already attached to vertex"<<endl;
      exit(0);
    }
    EN_attachDataPtr((pEntity)vtx,currentLocationsID,currentLocations);

    if(EN_getDataPtr((pEntity)vtx,targetLocationsID,(void **)&locPtr)) {
      cout<<"\nError in meshAdapt::adjustGrowthDirectionForGCs()..."<<endl;
      cout<<"target locations already attached to vertex"<<endl;
      exit(0);
    }
    EN_attachDataPtr((pEntity)vtx,targetLocationsID,targetLocations);
  }

  VIter viter = M_vertexIter(pmesh);
  while(vtx = VIter_next(viter)) {
    if(EN_getDataPtr((pEntity)vtx,targetLocationsID,(void **)&targetLocations)) {
      BL_getGrowthCurveNodes(vtx, gcNodes);
      listSize = gcNodes.size();
      // exclude the originating node
      for(int iNode=0; iNode<listSize-1; iNode++) {
        node = gcNodes[iNode+1];
        adaptUtil::move_vertex(node,targetLocations[iNode]);
      }
    }
  }
  VIter_reset(viter);

  VIter_reset(viter);
  while(vtx = VIter_next(viter)) {
    if(!EN_getDataPtr((pEntity)vtx,targetLocationsID,(void **)&targetLocations))
      continue;

    BL_getGrowthCurveNodes(vtx, gcNodes);
    listSize = gcNodes.size();

    // excluding top most node
    // check the validity of BL regions due to node movement
    vRegs = PList_new();
    for(int iNode=0; iNode<listSize-1; iNode++) {
      node = gcNodes[iNode];
      vregs = V_regions(node);
      PList_appPListUnique(vRegs,vregs);
      PList_delete(vregs);
    }

    validGC = 1;
    void *iter = 0;
    while(rgn = (pRegion)PList_next(vRegs,&iter)) {
      if(R_Volume2(rgn)<tol) {
	validGC = 0;
	break;
      }
    }
    PList_delete(vRegs);

    if(!validGC) {
      // if NOT valid leave them at target and move to current later
      // also clean target locations data
      EN_deleteData((pEntity)vtx,targetLocationsID);
      delete [] targetLocations;
    }
  }
  VIter_reset(viter);

  VIter_reset(viter);
  while(vtx = VIter_next(viter)) {
    if(!EN_getDataPtr((pEntity)vtx,currentLocationsID,(void **)&currentLocations))
      continue;

    BL_getGrowthCurveNodes(vtx, gcNodes);
    listSize = gcNodes.size();
    topNode = gcNodes[listSize-1];

    // move back the nodes
    // exclude the originating node
    // all the lower level nodes will be moved to target locations after the top most node has been moved
    // (or intermediate locations based on movement of top most node)
    for(int iNode=0; iNode<listSize-1; iNode++) {
      node = gcNodes[iNode+1];
      adaptUtil::move_vertex(node,currentLocations[iNode]);
    }

    EN_deleteData((pEntity)vtx,currentLocationsID);
    delete [] currentLocations;

    // if NO target locations data on vtx/onode then NOT valid GC in previous loop
    if(!EN_getDataPtr((pEntity)vtx,targetLocationsID,(void **)&targetLocations))
      continue;

    // clean target locations data from vtx/onode
    EN_deleteData((pEntity)vtx,targetLocationsID);

    initialLocation = new double[3];
    V_coord(topNode,initialLocation);
    EN_attachDataPtr((pEntity)topNode,initialLocationID,(void *)initialLocation);
    EN_attachDataPtr((pEntity)topNode,targetLocationsID,(void *)targetLocations);

    // this is deleted in snap
    double *target = new double[3];
    for(int iComp=0; iComp<3; iComp++)
      target[iComp] = targetLocations[listSize-2][iComp];

    numAdjust++;
    pSnapList->push_back(std::make_pair(topNode,target));
  }
  VIter_delete(viter);

  // tag all the zero level layer faces
  FIter fit = M_faceIter(pmesh);
  while(face = FIter_next(fit)) {
    if(!EN_isBLEntity((pEntity)face))
      continue;

    if(F_typeInBL(face)==fLAYER &&
       EN_levelInBL((pEntity)face)==0) {
      if(!EN_getDataInt((pEntity)face,layerFaceNormalChangeID,&layerFaceNormalChangeTag))
	EN_attachDataInt((pEntity)face,layerFaceNormalChangeID,1);
    }
  }
  FIter_delete(fit);

  if(pSnapList->size()!=numAdjust) {
    cout<<"\n WARNING in meshAdapt::adjustGrowthDirectionForGCs()"<<endl;
    cout<<" number of vertices in snap list do NOT match the number of growth directions to be adjusted using snapping procedure\n"<<endl;
  }

#ifdef DEBUG
  cout<<"\n entering snapping procedure for growth direction adjustment..."<<endl;
#endif

  pSnap->setCounterMax(1);
  setSnap();

#ifdef MA_PARALLEL
  int numBL = pSnap->run(userLB);
#else
  int numBL = pSnap->run();
#endif

#ifdef DEBUG
  cout<<"\n leaving snapping procedure for growth direction adjustment..."<<endl;
#endif

  int updateGCOnModelBdryTag;
  pMeshDataId updateGCOnModelBdryID = MD_newMeshDataId("update GC on model bdry");

  double gtol, orig_xyz[3], curxyz[3];
  VIter vit = M_vertexIter(pmesh);
  while(vtx = VIter_next(vit)) {
    if(EN_getDataPtr((pEntity)vtx,initialLocationID,(void **)&initialLocation)) {

      EN_getDataPtr((pEntity)vtx,targetLocationsID,(void **)&targetLocations);

      topNode = vtx;
      V_coord(topNode,curxyz);

      onode = V_getOriginatingNode(topNode);
      BL_getGrowthCurveNodes(onode, gcNodes);
      listSize = gcNodes.size();

      GC_getClassification(gcNodes, gcClassificationType, gcClassificationTag);
      if(gcClassificationType<3)
	EN_attachDataInt((pEntity)onode,updateGCOnModelBdryID,1);

      gent = V_whatIn(topNode);
      gtol = GEN_tolerance(gent);
      diffVt(targetLocations[listSize-2],curxyz,vec);
      if(dotProd(vec,vec) < gtol*gtol) {

	// check the validity of BL regions due to node movement for each level
	// this was done before (re-check as things might moved in the neighborhood)
	// excluding originating and top most node
	for(int iNode=0; iNode<listSize-2; iNode++) {
	  node = gcNodes[iNode+1];
	  vregs = V_regions(node);
	  V_coord(node,orig_xyz);
	  adaptUtil::move_vertex(node,targetLocations[iNode]);

	  validGC = 1;
	  void *iter = 0;
	  int rgnCount = 0;
	  while(rgn = (pRegion)PList_next(vregs,&iter)) {
	    // check for regions below this (current "iNode+1"th) node (i.e., region level "iNode+1")
	    if(EN_levelInBL((pEntity)rgn)!=iNode+1)
	      continue;
	    if(R_Volume2(rgn)<tol) {
	      validGC = 0;
	      adaptUtil::move_vertex(node,orig_xyz);

	      cout<<"\n WARNING in meshAdapt::adjustGrowthDirectionForGCs()..."<<endl;
	      cout<<" validity checked before [iNode="<<iNode<<",rgnCount="<<rgnCount<<"]\n"<<endl;

	      break;
	    }
	    rgnCount++;
	  }
	  PList_delete(vregs);

	  if(validGC) {
	    adaptUtil::move_vertex(node,orig_xyz);
	    adaptUtil::move_vertex(node,targetLocations[iNode],CB_move,userData_CB_move);
	  }
	}
      }
      else {

	double fullVector[3], tar_xyz[3];
	// in the opp. direction of the movement
	diffVt(initialLocation,targetLocations[listSize-2],fullVector);

	double partialMoveFactor = sqrt(dotProd(vec,vec)/dotProd(fullVector,fullVector));

	// check the validity of BL regions due to partial node movement for each level
	// this was done before (re-check as things might moved in the neighborhood)
	// excluding originating and top most node
	for(int iNode=0; iNode<listSize-2; iNode++) {
	  node = gcNodes[iNode+1];
	  vregs = V_regions(node);
	  V_coord(node,orig_xyz);

	  // in the opp. direction of the movement
	  diffVt(orig_xyz,targetLocations[iNode],fullVector);
	  for(int iComp=0; iComp<3; iComp++)
	    tar_xyz[iComp] = targetLocations[iNode][iComp] + partialMoveFactor*fullVector[iComp];

	  adaptUtil::move_vertex(node,tar_xyz);

	  validGC = 1;
	  void *iter = 0;
	  int rgnCount = 0;
	  while(rgn = (pRegion)PList_next(vregs,&iter)) {
	    // check for regions below this (current "iNode+1"th) node (i.e., region level "iNode+1")
	    if(EN_levelInBL((pEntity)rgn)!=iNode+1)
	      continue;
	    if(R_Volume2(rgn)<tol) {
	      validGC = 0;
	      adaptUtil::move_vertex(node,orig_xyz);

	      cout<<"\n WARNING in meshAdapt::adjustGrowthDirectionForGCs()..."<<endl;
	      cout<<" validity checked before (for partial movement) [iNode="<<iNode<<",rgnCount="<<rgnCount<<"]\n"<<endl;

	      break;
	    }
	    rgnCount++;
	  }
	  PList_delete(vregs);

	  if(validGC) {
	    adaptUtil::move_vertex(node,orig_xyz);
	    adaptUtil::move_vertex(node,tar_xyz,CB_move,userData_CB_move);
	  }
	}
      }

      if(smoothGrowthDirs) {
        // now set the normal vector (growth direction) for GC based on the movement of all levels
        // average of growth edge vectors seems a reasonable choice (even for partial movement)
        GC_getAvgGrowthEdgeDir(gcNodes, avgGrowthEdgeDir);
        GC_setNormalVector(onode, avgGrowthEdgeDir);
      }

      delete [] targetLocations;
      EN_deleteData((pEntity)topNode,targetLocationsID);
      delete [] initialLocation;
      EN_deleteData((pEntity)topNode,initialLocationID);
    }
  }
  VIter_reset(vit);

  VIter_reset(vit);
  while(vtx = VIter_next(vit)) {
    if(EN_getDataInt((pEntity)vtx,updateGCOnModelBdryID,&updateGCOnModelBdryTag)) {
      EN_deleteData((pEntity)vtx,updateGCOnModelBdryID);
/*
      gc = V_growthCurve(vtx);
      
      if(updateGCOnModelBdry(gc)) {
	cout<<"\n WARNING in meshAdapt::adjustGrowthDirectionForGCs()..."<<endl;
	cout<<" GC on model bdry. not completely updated\n"<<endl;
      }
*/
    }
  }

  MD_deleteMeshDataId(initialLocationID);
  MD_deleteMeshDataId(currentLocationsID);
  MD_deleteMeshDataId(targetLocationsID);
  MD_deleteMeshDataId(updateGCOnModelBdryID);

  for (deque<pEdge>::iterator eIt = procVerts.begin(); eIt != procVerts.end(); ++eIt)
    EN_deleteData(*eIt,procTag);

  MD_deleteMeshDataId(procTag);

  if( numBL==-1 ) 
    { adaptUtil::Info("Error: adjusting growth directions for GC return -1 for BL mesh\n"); exit(0); }

  if( numBL )
    adaptUtil::Info(numBL,"growth curves direction not adjusted for BL mesh");

  return numBL;
}

void meshAdapt::gradeLayerThicknessAlongGC(pMeshDataId targetLocationsID, pMeshDataId meshSizesID) {

  int listSize, gcThicknessTag, isModified, curNode;
  double vec[3], normal[3], mtol = M_getTolerance();
  dArray *targetLocations;

  std::deque<int> queue;

  pVertex vtx;
  pFace face;
  pRegion rgn;

  vector<pVertex> gcNodes;

  int gcClassificationType, gcClassificationTag;

  pMeshDataId procTag = MD_lookupMeshDataId("ProcessedONodeTag");
  deque<pVertex> procVerts;
  int value;

  /// Loop over entity groups
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    /// Find the zero-level face, i.e. the face on the surface
    face = BL_GetZeroLvlFace((pBLayer)(*egIt));

    for (int iVert = 0; iVert < 3; ++iVert)
    {
      vtx = F_vertex(face, iVert);
      if (!V_isOriginatingNode(vtx) || EN_getDataInt(vtx,procTag,&value))
        continue;

      EN_attachDataInt(vtx,procTag,1);
      procVerts.push_back(vtx);

      EN_getDataPtr((pEntity)vtx,targetLocationsID,(void **)&targetLocations);

      BL_getGrowthCurveNodes(vtx, gcNodes);
      listSize = gcNodes.size();
      GC_getNormalVector(vtx, normal);

      dArray *targetLocationsOrg = new dArray[listSize-1];
      for(int iNode=0; iNode<listSize-1; iNode++)
	for(int iComp=0; iComp<3; iComp++)
	  targetLocationsOrg[iNode][iComp] = targetLocations[iNode][iComp];

      // exclude first and top most layer
      // check ratio of current layer thickness and one below
      for(int iNode=0; iNode<listSize-2; iNode++)
	isModified += procAnNodeOnGCToGradeLayerThickness(gcNodes,iNode,targetLocations,queue);
      
      while( !queue.empty() ) {
	curNode = queue.front();
	queue.pop_front();
	isModified += procAnNodeOnGCToGradeLayerThickness(gcNodes,curNode,targetLocations,queue);
      }

      if(isModified) {
        GC_getClassification(gcNodes, gcClassificationType, gcClassificationTag);
	if(gcClassificationType<3)
	  updateTargetLocationsOfUpperNodesOnGCOnModelBdry(gcNodes,0,targetLocations);

	pPList meshSizes;
	EN_getDataPtr((pEntity)vtx,meshSizesID,(void **)&meshSizes);

	// update the sizefield for all nodes (in one go) due to scaling (caused by grading layer thickness)
	// use original target locations and sizes to update the sizes for all nodes at once
	updateSizesOfUpperNodesOnGC(gcNodes,-99,targetLocationsOrg,targetLocations,meshSizes);

	// check for validity of elements based on node distribution on growth curve
	// (this may not be stringent)
	for(int iNode=0; iNode<listSize-2; iNode++) {
	  diffVt(targetLocations[iNode+1],targetLocations[iNode],vec);
	  if(dotProd(vec,normal)<mtol) {
	    cout<<"\nError in meshAdapt::gradeLayerThicknessAlongGC()..."<<endl;
	    cout<<"target locations would result in negative volume (after scaling due to grading of layer thickness)"<<endl;
	    exit(0);
	  }
	}
      }

      delete [] targetLocationsOrg;
    }
  }
  for (deque<pEdge>::iterator eIt = procVerts.begin(); eIt != procVerts.end(); ++eIt)
    EN_deleteData(*eIt,procTag);

  MD_deleteMeshDataId(procTag);
  
}

int meshAdapt::procAnNodeOnGCToGradeLayerThickness(vector<pVertex>& gcNodes, int curNode, dArray *targetLocations, std::deque<int> &queue) {

  int listSize, isModified = 0;
  int lowerEdge, modNode, index;
  double vec[3], edgeVector[2][3], normal[3], xyz[3], lower_xyz[3], xyzKeep[3], layerThickness[2], ratio, newThickness, mtol = M_getTolerance();

  listSize = gcNodes.size();
  pVertex onode = gcNodes[0];
  GC_getNormalVector(onode, normal);
  V_coord(onode,xyz);

  diffVt(targetLocations[curNode+1],targetLocations[curNode],edgeVector[1]);
  layerThickness[1] = dotProd(edgeVector[1],normal);

  if(!curNode) {
    for(int iComp=0; iComp<3; iComp++)
      lower_xyz[iComp] = xyz[iComp];
  }
  else {
    for(int iComp=0; iComp<3; iComp++)
      lower_xyz[iComp] = targetLocations[curNode-1][iComp];
  }

  diffVt(targetLocations[curNode],lower_xyz,edgeVector[0]);
  layerThickness[0] = dotProd(edgeVector[0],normal);

  lowerEdge = 0;
  ratio = layerThickness[1]/layerThickness[0];
  if(ratio<1.) {
    lowerEdge = 1;
    ratio = 1/ratio;
  }

  if(ratio>thicknessGradeFactorOnGC+mtol) {
    isModified = 1;
    newThickness = thicknessGradeFactorOnGC*layerThickness[lowerEdge];
    
    modNode = curNode+1-lowerEdge;
    if(!lowerEdge) {
      // "curNode = modNode-1" for "lowerEdge = 0"
      for(int iComp=0; iComp<3; iComp++)
	lower_xyz[iComp] = targetLocations[curNode][iComp];
    }

    // preserve the side vector
    index = 1-lowerEdge;
    for(int iComp=0; iComp<3; iComp++) {
      xyzKeep[iComp] = targetLocations[modNode][iComp];
      vec[iComp] = edgeVector[index][iComp] - layerThickness[index]*normal[iComp];
      targetLocations[modNode][iComp] = lower_xyz[iComp] + newThickness*normal[iComp] + vec[iComp];
    }

    // move the upper nodes by constant amount
    // vector contains this constant amount see line below
    diffVt(targetLocations[modNode],xyzKeep,vec);
    for(int iNode2=modNode+1; iNode2<listSize-1; iNode2++) {
      for(int iComp=0; iComp<3; iComp++)
	targetLocations[iNode2][iComp] = targetLocations[iNode2][iComp] + vec[iComp];
    }

    // append the lower node if lower layer thickness is modified
    if(lowerEdge && modNode>0)
      queue.push_back(modNode-1);
  }

  return isModified;
}

void meshAdapt::gradeLayerThicknessAroundGC(pMeshDataId targetLocationsID, pMeshDataId meshSizesID) {

  std::deque<pEdge> queue;

  pMeshDataId inQueueID = MD_newMeshDataId("edge in queue ID");

  int foundVtx, gcThicknessTag;
  pVertex vtx;
  pEdge edge;
  EIter eit = M_edgeIter(pmesh);
  while(edge = EIter_next(eit)) {
    if(!EN_isBLEntity((pEntity)edge))
      continue;

    if( E_typeInBL(edge)!=eLAYER ||
	EN_levelInBL((pEntity)edge)!=0 )
      continue;

    foundVtx = 0;
    for(int iEVert=0; iEVert<2; iEVert++) {
      vtx = E_vertex(edge,iEVert);
      if(!EN_getDataInt((pEntity)vtx,gcThicknessID,&gcThicknessTag)) {
	foundVtx = 1;
	break;
      }
    }

    // if any node of the edge is tagged for thickness adjustment
    // in case only one node is tagged for thickness adjustment grade the target locations 
    // on its GC only if target locations leads to decrease in layer thicknesses
    // (otherwise may result in oscillations) 
    // probably consider the untagged node for thickness adjustment with new target locations
    if(!foundVtx)
      continue;

    procGCsOnNodesOfEdgeToGradeLayerThickness(edge,targetLocationsID,meshSizesID,queue,inQueueID);
  }
  EIter_delete(eit);

  while(!queue.empty()) {
    edge = queue.front();
    queue.pop_front();

    if( !EN_isBLEntity((pEntity)edge) || 
	E_typeInBL(edge)!=eLAYER || 
	EN_levelInBL((pEntity)edge)!=0 ) {
      cout<<"\nError in meshAdapt::gradeLayerThicknessAroundGC()..."<<endl;
      cout<<"edge in the queue is NOT valid to be processed to grade layer thickness\n"<<endl;
      exit(0);
    }

    procGCsOnNodesOfEdgeToGradeLayerThickness(edge,targetLocationsID,meshSizesID,queue,inQueueID);

    // untag the edge from the queue after it has been processed
    // i.e., do it after procGCsOnNodesOfEdgeToGradeLayerThickness()
    // as the tag is used in the routine to determine new zero level layer edges
    EN_deleteData((pEntity)edge,inQueueID);
  }

  MD_deleteMeshDataId(inQueueID);

}

void meshAdapt::procGCsOnNodesOfEdgeToGradeLayerThickness(pEdge edge,
							  pMeshDataId targetLocationsID,
							  pMeshDataId meshSizesID,
							  std::deque<pEdge> &queue,
							  pMeshDataId inQueueID) {

  int listSize[2], minListSize = 100000000, gcThicknessTag, isTag[2], isNode[2] = {0,0}, oneNodeMessagePrint = 0;
  double layerEdgeLength, layerThickness[2], normal[2][3], vec[3], growthVector[2][3], xyzAtEnds[2][3], xyzKeep[3], mtol = M_getTolerance();
  dArray *targetLocations[2], *targetLocationsOrg[2];
  // if only one node is tagged for thickness adjustment 
  // then grade target locations of GC on this node only if
  // it leads to decrease in layer thicknesses  
  pVertex onode[2], otherNode[2];
  vector<pVertex> gcNodes[2];
  vector<pEdge> gcEdges[2]; 

  int gcClassificationType, gcClassificationTag;

  for(int iEVert=0; iEVert<2; iEVert++) {
    onode[iEVert] = E_vertex(edge,iEVert);
    BL_getGrowthCurveNodes(onode[iEVert], gcNodes[iEVert]); 
    GC_getNormalVector(onode[iEVert], normal[iEVert]);

    listSize[iEVert] = gcNodes[iEVert].size();
    if(minListSize>listSize[iEVert])
      minListSize = listSize[iEVert];

    if(!EN_getDataInt((pEntity)onode[iEVert],gcThicknessID,&gcThicknessTag)) {
      isTag[iEVert] = 1;
      EN_getDataPtr((pEntity)onode[iEVert],targetLocationsID,(void **)&targetLocations[iEVert]);

      targetLocationsOrg[iEVert] = new dArray[listSize[iEVert]-1];
      for(int iLevel=0; iLevel<listSize[iEVert]-1; iLevel++)
	for(int iComp=0; iComp<3; iComp++)
	  targetLocationsOrg[iEVert][iLevel][iComp] = targetLocations[iEVert][iLevel][iComp];
    }
    else {
      isTag[iEVert] = 0;
      // initialize otherNode to onode
      otherNode[iEVert] = onode[iEVert];
      BL_getGrowthCurveEdges(onode[iEVert], gcEdges[iEVert]);
    }
  }

  int whichOne, isModified;
  double diff, ratio, newThickness, newThicknessTmp;
  pEdge layerEdge, growthEdge;
  vector<pEdge> elist;
  BL_getHorizontalEdgesByEdge(edge, elist); 
  for(int iLayer=0; iLayer<minListSize-2; iLayer++) {
    layerEdge = elist[iLayer];
    layerEdgeLength = sqrt(adaptUtil::E_lengthSq(layerEdge));
    layerEdge = elist[iLayer+1];
    layerEdgeLength += sqrt(adaptUtil::E_lengthSq(layerEdge));
    layerEdgeLength /= 2;

    for(int iEVert=0; iEVert<2; iEVert++) {

      for(int iLayerEnd=0; iLayerEnd<2; iLayerEnd++) {
	if(!(iLayer+iLayerEnd)) {
	  V_coord(onode[iEVert],xyzAtEnds[0]);
	}
	else {
	  if(isTag[iEVert]) {
	    for(int iComp=0; iComp<3; iComp++)
	      xyzAtEnds[iLayerEnd][iComp] = targetLocations[iEVert][iLayer-1+iLayerEnd][iComp];
	  }
	  else {
	    if(iLayerEnd) {
	      growthEdge = gcEdges[iEVert][iLayer];
	      otherNode[iEVert] = E_otherVertex(growthEdge,otherNode[iEVert]);
	    }
	    V_coord(otherNode[iEVert],xyzAtEnds[iLayerEnd]);
	  }
	}
      }

      diffVt(xyzAtEnds[1],xyzAtEnds[0],growthVector[iEVert]);
      layerThickness[iEVert] = dotProd(growthVector[iEVert],normal[iEVert]);
    }

    whichOne = 0;
    if(layerThickness[0]<layerThickness[1])
      whichOne = 1;

    isModified = 0;
    diff = layerThickness[whichOne]-layerThickness[1-whichOne];
    ratio = diff/layerEdgeLength;
    if(ratio>thicknessGradeFactorAroundGC+mtol) {
      newThicknessTmp = layerThickness[1-whichOne] + thicknessGradeFactorAroundGC*layerEdgeLength;

      if( (isModified && newThicknessTmp<newThickness) ||
	  !isModified )
	newThickness = newThicknessTmp ;

      isModified = 1;
    }

    ratio = layerThickness[whichOne]/layerThickness[1-whichOne];

    if(ratio>thicknessGradeFactorOnGC+mtol) {
      newThicknessTmp = thicknessGradeFactorOnGC*layerThickness[1-whichOne];
      
      if( (isModified && newThicknessTmp<newThickness) ||
	  !isModified )
	newThickness = newThicknessTmp ;

      isModified = 1;
    }

    if(isModified) {
      if(isTag[whichOne]) {

	for(int iComp=0; iComp<3; iComp++) {
	  xyzKeep[iComp] = targetLocations[whichOne][iLayer][iComp];
	  vec[iComp] = growthVector[whichOne][iComp] - layerThickness[whichOne]*normal[whichOne][iComp];
	  xyzAtEnds[0][iComp] = targetLocations[whichOne][iLayer][iComp] - growthVector[whichOne][iComp];
	  targetLocations[whichOne][iLayer][iComp] = xyzAtEnds[0][iComp] + newThickness*normal[whichOne][iComp] + vec[iComp];
	}

	// move the upper nodes by constant amount
	// vector contains this constant amount see line below
	diffVt(targetLocations[whichOne][iLayer],xyzKeep,vec);
        if(dotProd(vec,vec)>mtol) {
  	  for(int iLayer2=iLayer+1; iLayer2<listSize[whichOne]-1; iLayer2++) {
	    for(int iComp=0; iComp<3; iComp++)
	      targetLocations[whichOne][iLayer2][iComp] = targetLocations[whichOne][iLayer2][iComp] + vec[iComp];
	  }
        }
        else // if movement vector is less than mtol no need to modify
          isModified = 0;
      }
      else {
	if(!oneNodeMessagePrint) {
	  oneNodeMessagePrint = 1;
#ifdef DEBUG
	  cout<<"\n WARNING in meshAdapt::procGCsOnNodesOfEdgeToGradeLayerThickness()..."<<endl;
	  cout<<" node NOT tagged for thickness adjustment requires gradation\n"<<endl;
#endif
	}
      }
    }

    if(isModified) {
      isNode[whichOne] += isTag[whichOne];
      // isNode[1-whichOne] += 1-isTag[whichOne];
    }
  }

  int numLayerEdges, inQueueTag;
  vector<pEdge> vLayerEdges;
  for(int iEVert=0; iEVert<2; iEVert++) {
    if(isNode[iEVert]) {
      V_layerEdges(onode[iEVert], vLayerEdges);
      numLayerEdges = vLayerEdges.size();
      for(int iLayerEdge=0; iLayerEdge<numLayerEdges; iLayerEdge++) {
	// edge being processed currently is tagged to be in the queue
	layerEdge = vLayerEdges[iLayerEdge];
	if(!EN_getDataInt((pEntity)layerEdge,inQueueID,&inQueueTag)) {
	  EN_attachDataInt((pEntity)layerEdge,inQueueID,1);
	  queue.push_back(layerEdge);
	}
      }

      GC_getClassification(gcNodes[iEVert], gcClassificationType, gcClassificationTag);
      if(gcClassificationType<3)
	updateTargetLocationsOfUpperNodesOnGCOnModelBdry(gcNodes[iEVert],0,targetLocations[iEVert]);

      pPList meshSizes;
      EN_getDataPtr((pEntity)onode[iEVert],meshSizesID,(void **)&meshSizes);

      // update the sizefield for all nodes (in one go) due to scaling (caused by grading layer thickness)
      // use original target locations and sizes to update the sizes for all nodes at once
      updateSizesOfUpperNodesOnGC(gcNodes[iEVert],-99,targetLocationsOrg[iEVert],targetLocations[iEVert],meshSizes);

      // check for validity of elements based on node distribution on growth curve
      // (this may not be stringent)
      for(int iNode=0; iNode<listSize[iEVert]-2; iNode++) {
	diffVt(targetLocations[iEVert][iNode+1],targetLocations[iEVert][iNode],vec);
	if(dotProd(vec,normal[iEVert])<mtol) {
	  cout<<"\nError in meshAdapt::procGCsOnNodesOfEdgeToGradeLayerThickness()..."<<endl;
	  cout<<"target locations would result in negative volume (after scaling due to grading of layer thickness)"<<endl;
	  exit(0);
	}
      }
    }

    // if(!EN_getDataInt((pEntity)onode[iEVert],gcThicknessID,&gcThicknessTag))
    if(isTag[iEVert])
      delete [] targetLocationsOrg[iEVert];
  }

}


void meshAdapt::updateTargetLocationsOfUpperNodesOnGCOnModelBdry(vector<pVertex>& nodesOnGC,
                                                                 int curNode,
                                                                 dArray* targetLocations) {

  int listSize = nodesOnGC.size();

  pVertex node;
  for(int iNode=curNode; iNode<listSize-1; iNode++) {
    node = nodesOnGC[iNode+1];

double xyz[3];
V_coord(node, xyz);

    double clsLoc[3], par[3];
    pGEntity gent = V_whatIn(node);
    //double gtol=GEN_tolerance(gent);
    switch(GEN_type(gent)) {
    case 0 :
      cout<<"\nError in meshAdapt::thicknessAdaptationInBL()..."<<endl;
      cout<<"node (other than ONode) is classified on model vertex"<<endl;
      exit(0);
      break;
    case 1 :
      GE_closestPoint((pGEdge)gent,targetLocations[iNode],clsLoc,par);
      break;
    case 2 :
      GF_closestPoint((pGFace)gent,targetLocations[iNode],clsLoc,par);
      break;
    case 3 :
      // this should not happen (i.e., partial GC on model bdry.)
      cout<<"\nError in meshAdapt::thicknessAdaptationInBL()..."<<endl;
      cout<<"partial GC on model bdry."<<endl;
      exit(0);
    }

    // parametric coordinates for GC on model bdry. must be taken care outside this routine
    // for example with updateGCOnModelBdry()
    for(int iComp=0; iComp<3; iComp++)
      targetLocations[iNode][iComp] = clsLoc[iComp];
  }
}

void meshAdapt::updateSizesOfUpperNodesOnGC(vector<pVertex>& nodesOnGC,
                                            int curNode,
                                            dArray* currentLocations,
                                            dArray* targetLocations,
                                            pPList meshSizes) {

  if(!meshSizes)
    return;
  if(!PList_size(meshSizes))
    return;

  int scaleOption = 0;
  if(curNode == -99) {
    curNode = 0;
    scaleOption = 0;
  }

  pVertex ONode = nodesOnGC[0];
  double normal[3];
  GC_getNormalVector(ONode, normal);

  int listSize = nodesOnGC.size();
  pVertex topNode = nodesOnGC[listSize-1];

  double xyz[3];
  if(!curNode)
    V_coord(ONode,xyz);
  else {
    for(int iComp=0; iComp<3; iComp++)
      xyz[iComp] = currentLocations[curNode-1][iComp];
  }

  int currentPatch = curNode;
  int crossed = 0;
  double mtol = M_getTolerance();
  int infinite, numRegs;
  double curVector[3], targetVector[3], vec[3];
  double curS, targetS;
  double tmp_xyz[3], fxyz[3][3], tmp_xyz1[3];
  pPList nonBLRegs;
  pPList newMeshSizes = PList_new();
  pMSize mt0, mt1;
  pVertex node, vertex;
  pEdge edge, opEdge;
  pFace face, opFace, fc;
  pRegion region, currentReg = 0, rgn;
  for(int iNode=curNode; iNode<listSize-1; iNode++) {

    if(currentPatch>=listSize-1)
      crossed = 1;

    if(!crossed) {
      diffVt(currentLocations[currentPatch],xyz,curVector);
      diffVt(targetLocations[iNode],xyz,targetVector);

      curS = dotProd(curVector,normal);
      targetS = dotProd(targetVector,normal);

      while(targetS > curS) {
        currentPatch++;

        if(currentPatch>=listSize-1) {
          crossed = 1;
          break;
        }

        for(int iComp=0; iComp<3; iComp++)
          xyz[iComp] = currentLocations[currentPatch-1][iComp];

        diffVt(currentLocations[currentPatch],xyz,curVector);
        diffVt(targetLocations[iNode],xyz,targetVector);

        curS = dotProd(curVector,normal);
        targetS = dotProd(targetVector,normal);
      }
    }

    if(!crossed) {
      if(targetS <= curS) {

        if(!currentPatch)
          mt0 = pSizeField->getSize(ONode);
        else
          mt0 = (pMSize)PList_item(meshSizes,currentPatch-1);
        mt1 = (pMSize)PList_item(meshSizes,currentPatch);

        pMSize pSNew;
        pSizeField->interpolate(mt0,mt1,targetS/curS,&pSNew);
        PList_append(newMeshSizes,pSNew);

        continue;
      }
      else {
        cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
        cout<<"could NOT find appropriate patch to interpolate sizefield"<<endl;
        exit(0);
      }
    }
    else {

      int foundRegion = 0, ptOnFace;
      V_coord(topNode,xyz);

      diffVt(targetLocations[iNode],xyz,vec);

      // special patch
      if(dotProd(vec,normal)<mtol) {

        double exyz[2][3];
        for(int iComp=0; iComp<3; iComp++) {
          exyz[0][iComp] = currentLocations[iNode][iComp];
          exyz[1][iComp] = xyz[iComp];
        }
        double t = adaptUtil::ParOnLinearEdge(exyz,targetLocations[iNode]);

        mt0 = (pMSize)PList_item(meshSizes,iNode);
        mt1 = pSizeField->getSize(topNode);

        pMSize pSNew;
        pSizeField->interpolate(mt0,mt1,t,&pSNew);
        PList_append(newMeshSizes,pSNew);

        continue;
      }

      node = nodesOnGC[iNode+1];
      // check if current region is available from previous step
      if( EN_getDataPtr((pEntity)node,currentRegionID,(void **)&region) &&
          R_isPointInside(region,currentLocations[iNode]) ) {

        if(R_isPointInside(region,targetLocations[iNode])) {
          currentReg = region;
        }
        else {

          for(int iComp=0; iComp<3; iComp++)
            xyz[iComp] = currentLocations[iNode][iComp];

          diffVt(targetLocations[iNode],xyz,vec);

          opFace = 0;
          int numRFaces = R_numFaces(region);
          for(int iFace=0; iFace<numRFaces; iFace++) {
            face = R_face(region,iFace);
            if(F_numEdges(face)!=3)
              continue;
            F_coord(face,fxyz);

            if(M_intersectRay3XYZ(xyz,vec,fxyz,tmp_xyz,&infinite)) {
              if(infinite)
                continue;

              ptOnFace = F_isPointInside(face,tmp_xyz);

              if(ptOnFace==1) {
                opFace = face;
                foundRegion = 0;
                break;
              }

              switch(ptOnFace) {
              case 0 :
                continue;
                break;
//            case 1 :
//              opFace = face;
//              break;
              case 2 :
              case 3 :
              case 4 :
                {
                  pPList fverts =  F_vertices(face,1);
                  vertex = (pVertex)PList_item(fverts,ptOnFace-2);
                  PList_delete(fverts);

                  vector<pRegion> vregs;
                  V_nonBLRegions(vertex, vregs);
                  numRegs = vregs.size();
                  for(int iRgn=0; iRgn<numRegs; iRgn++) {
                    rgn = vregs[iRgn];

                    if(R_isPointInside(rgn,targetLocations[iNode])) {
                      currentReg = rgn;
                      break;
                    }

                    face = R_vtOpFc(rgn,vertex);

                    F_coord(face,fxyz);

                    if(M_intersectRay3XYZ(xyz,vec,fxyz,tmp_xyz1,&infinite)) {
                      if(infinite)
                        continue;

                      if( XYZ_distance2(tmp_xyz1,targetLocations[iNode]) <
                          XYZ_distance2(tmp_xyz,targetLocations[iNode]) ) {
                        if(F_isPointInside(face,tmp_xyz1)) {
                          region = rgn;
                          opFace = face;
                          foundRegion = 1;
                          break;
                        }
                      }
                    }
                  }

                  if(!foundRegion && V_whatInType(vertex)!=3) {
                    foundRegion = 1;
                    opFace = face;
                  }
                }
                break;
              case 5 :
              case 6 :
              case 7 :
                {
                  edge = F_edge(face,ptOnFace-5);

                  vector<pRegion> eregs;
                  E_nonBLRegions(edge, eregs);
                  numRegs = eregs.size();
                  for(int iRgn=0; iRgn<numRegs; iRgn++) {
                    rgn = eregs[iRgn];

                    if(R_isPointInside(rgn,targetLocations[iNode])) {
                      currentReg = rgn;
                      break;
                    }

                    for(int iFc=0; iFc<4; iFc++) {
                      fc = R_face(rgn,iFc);
                      if(F_inClosure(fc,(pEntity)edge))
                        continue;

                      F_coord(fc,fxyz);

                      if(M_intersectRay3XYZ(xyz,vec,fxyz,tmp_xyz1,&infinite)) {
                        if(infinite)
                          continue;

                        if( XYZ_distance2(tmp_xyz1,targetLocations[iNode]) <
                            XYZ_distance2(tmp_xyz,targetLocations[iNode]) ) {
                          if(F_isPointInside(fc,tmp_xyz1)) {
                            region = rgn;
                            opFace = fc;
                            foundRegion = 1;
                            break;
                          }
                        }
                      }
                    }

                  }

                  if(!foundRegion && E_whatInType(edge)!=3) {
                    foundRegion = 1;
                    opFace = face;
                  }
                }
                break;
              }

//            if(F_isPointInside(face,tmp_xyz)) {
//              opFace = face;
//              break;
//            }
            }

            if(foundRegion || currentReg)
              break;
          }
        }
      }
      else {
        opFace = 0;
        // exclude lower BL regions (top node might have transition elements)
        vector<pRegion> excludeLevelBLRegs;
        V_excludeLevelBLRegions(topNode, excludeLevelBLRegs); // V_nonBLRegions(topNode);
        numRegs = excludeLevelBLRegs.size();
        for(int iRgn=0; iRgn<numRegs; iRgn++) {
          region = excludeLevelBLRegs[iRgn];
          foundRegion = 0;

          if(R_isPointInside(region,targetLocations[iNode])) {
            currentReg = region;
            break;
          }

          int rTopoType = region->getType();
          if(rTopoType==TET) {
            face = R_vtOpFc(region,topNode);
          }
          else if(rTopoType==PRISM) {
            face = R_face(region,4);
            // take top tri. face
            if(EN_levelInBL((pEntity)face)!=EN_levelInBL((pEntity)region))
              face = F_otherTriFcPrism(face,region);
          }
          else if(rTopoType==PYRAMID) {
             face = R_face(region,1);
             if( !(F_typeInBL(face)==fLAYER ||
                   F_typeInBL(face)==fTRANSITION) )
                face = R_face(region,2);
             // take top tri. face
             if(EN_levelInBL((pEntity)face)!=EN_levelInBL((pEntity)region))
               face = F_otherTriFcPyramid(face,region);
          }
          else {
            cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
            cout<<"region topology ["<<rTopoType<<"] NOT supported"<<endl;
            exit(0);

          }

          F_coord(face,fxyz);
          if(M_intersectRay3XYZ(xyz,vec,fxyz,tmp_xyz,&infinite)) {
            if(infinite) {
              cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
              cout<<"INFINITE intersections with face found"<<endl;
              exit(0);
            }

            ptOnFace = F_isPointInside(face,tmp_xyz);

            if(ptOnFace==1) {
              opFace = face;
              foundRegion = 0;
              break;
            }

            switch(ptOnFace) {
            case 0 :
              continue;
              break;
//          case 1 :
//            opFace = face;
//            break;
            case 2 :
            case 3 :
            case 4 :
              {
                pPList fverts =  F_vertices(face,1);
                vertex = (pVertex)PList_item(fverts,ptOnFace-2);
                PList_delete(fverts);

                // exclude lower BL regions (might have transition elements)
                vector<pRegion> vregs;
                V_excludeLevelBLRegions(vertex, vregs); // V_nonBLRegions(vertex);
                numRegs = vregs.size();
                for(int iReg=0; iReg<numRegs; iReg++) {
                  rgn = vregs[iReg];

                  if(R_isPointInside(rgn,targetLocations[iNode])) {
                    currentReg = rgn;
                    break;
                  }

                  int rTopoType = rgn->getType();
                  if(rTopoType==TET) {
                    face = R_vtOpFc(rgn,topNode);
                  }
                  else if(rTopoType==PRISM) {
                    face = R_face(rgn,4);
                    // take top tri. face
                    if(EN_levelInBL((pEntity)face)!=EN_levelInBL((pEntity)rgn))
                      face = F_otherTriFcPrism(face,rgn);
                  }
                  else if(rTopoType==PYRAMID) {
                    face = R_face(rgn,1);
                    if( !(F_typeInBL(face)==fLAYER ||
                          F_typeInBL(face)==fTRANSITION) )
                      face = R_face(rgn,2);
                    // take top tri. face
                    if(EN_levelInBL((pEntity)face)!=EN_levelInBL((pEntity)rgn))
                      face = F_otherTriFcPyramid(face,rgn);
                  }
                  else {
                    cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
                    cout<<"rgn topology ["<<rTopoType<<"] NOT supported"<<endl;
                    exit(0);
                  }

                  F_coord(face,fxyz);
                  if(M_intersectRay3XYZ(xyz,vec,fxyz,tmp_xyz1,&infinite)) {
                    if(infinite)
                      continue;

                    if( XYZ_distance2(tmp_xyz1,targetLocations[iNode]) <
                        XYZ_distance2(tmp_xyz,targetLocations[iNode]) ) {
                      if(F_isPointInside(face,tmp_xyz1)) {
                        region = rgn;
                        opFace = face;
                        foundRegion = 1;
                        break;
                      }
                    }
                  }
                }

                if(!foundRegion && V_whatInType(vertex)!=3) {
                  foundRegion = 1;
                  opFace = face;
                }
              }
              break;
            case 5 :
            case 6 :
            case 7 :
              {
                edge = F_edge(face,ptOnFace-5);

                // might want to introduce E_excludeLevelBLRegions(edge);
                // i.e., exclude lower BL regions (transition elements might be present)
                pPList eregs = E_regions(edge); // E_nonBLRegions(edge);
                numRegs = PList_size(eregs);
                for(int iReg=0; iReg<numRegs; iReg++) {
                  rgn = (pRegion)PList_item(eregs,iReg);

                  if(R_isPointInside(rgn,targetLocations[iNode])) {
                    currentReg = rgn;
                    break;
                  }
                  int numRFaces = R_numFaces(rgn);
                  for(int iFc=0; iFc<numRFaces; iFc++) {
                    fc = R_face(rgn,iFc);
                    if(F_numEdges(fc)!=3 || F_inClosure(fc,(pEntity)edge))
                      continue;

                    F_coord(fc,fxyz);
                    if(M_intersectRay3XYZ(xyz,vec,fxyz,tmp_xyz1,&infinite)) {
                      if(infinite)
                        continue;

                      if( XYZ_distance2(tmp_xyz1,targetLocations[iNode]) <
                          XYZ_distance2(tmp_xyz,targetLocations[iNode]) ) {
                        if(F_isPointInside(fc,tmp_xyz1)) {
                          region  = rgn;
                          opFace = fc;
                          foundRegion = 1;
                          break;
                        }
                      }
                    }
                  }

//                opEdge = R_gtOppEdg(rgn,edge);

//                double e_xyz[2][3], e_vec[2][3], e_crossVec[2][3];

//                for(int iVert=0; iVert<2; iVert++) {
//                  V_coord(E_vertex(opEdge,iVert),e_xyz[iVert]);
//                  diffVt(e_xyz[iVert],tmp_xyz,e_vec[iVert]);
//                  crossProd(vector,e_vec[iVert],e_crossVec[iVert]);
//                }

//                if(!(dotProd(e_crossVec[0],e_crossVec[1])>0.0)) {
//                  region = rgn;
//                  opFace = face;
//                  foundRegion = 1;
//                  break;
//                }
                }
                PList_delete(eregs);

                if(!foundRegion && E_whatInType(edge)!=3) {
                  foundRegion = 1;
                  opFace = face;
                }
              }
              break;
            }

//          if(F_isPointInside(face,tmp_xyz)) {
//            opFace = face;
//            break;
//          }
          }

          if(foundRegion || currentReg)
            break;
        }
      }

      if(!currentReg && !opFace) {
        cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
        cout<<"could NOT find opp. face that contains point of intersection"<<endl;

        double growthDir[3], avgGrowthEdgeDir[3];
        GC_getNormalVector(ONode, growthDir);
        GC_getAvgGrowthEdgeDir(nodesOnGC, avgGrowthEdgeDir);
        cout<<"\n growth dir.    : ";
        for(int iComp=0; iComp<3; iComp++)
          cout<<growthDir[iComp]<<" ";
        cout<<endl;
        cout<<"\n avg. edge dir. : ";
        for(int iComp=0; iComp<3; iComp++)
          cout<<avgGrowthEdgeDir[iComp]<<" ";
        cout<<endl;

//        dumpBLStack(ONode,1,1,"OpFaceBLStack",targetLocations[iNode]);

        exit(0);
      }

      int maxCounter = 100;
      int counter = 0;
      int termination = 0;
      while(!currentReg) {
        counter++;

        if(counter>=maxCounter) {
          cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
          cout<<"could NOT find current region (counter exceeded limit)"<<endl;

//          dumpBLStack(ONode,1,1,"CounterExceededBLStack",targetLocations[iNode]);

          exit(0);
        }

        // if(!foundRegion)
        region = F_otherRegion(opFace,region);
        foundRegion = 0;

        if(F_whatInType(opFace)==2) {
          cout<<"\n WARNING : meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
          cout<<" model bdry. ["<<GEN_tag(F_whatIn(opFace))<<"] encountered in adjusting BL thickness"<<endl;
          cout<<" changing targetLocations to currentLocations\n"<<endl;

          termination = 1;
          for(int iNode2=iNode; iNode2<listSize-1; iNode2++) {
            for(int iComp=0; iComp<3; iComp++)
              targetLocations[iNode2][iComp] = currentLocations[iNode2][iComp];
            pMSize pSNew = new MeshSize((pMSize)PList_item(meshSizes,iNode2));
            PList_append(newMeshSizes,pSNew);
          }
          break;
        }
        else if(!region) {
          cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
          cout<<"could NOT find other region for opp. face"<<endl;

//          dumpBLStack(ONode,1,1,"NoRegionForOpFaceBLStack",targetLocations[iNode]);

          exit(0);
        }

        if(EN_isBLEntity((pRegion)region)) {
          cout<<"\n WARNING : meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
          cout<<" boundary layer region encountered in adjusting BL thickness"<<endl;
          cout<<" changing targetLocations to currentLocations\n"<<endl;

          termination = 2;
          for(int iNode2=iNode; iNode2<listSize-1; iNode2++) {
            for(int iComp=0; iComp<3; iComp++)
              targetLocations[iNode2][iComp] = currentLocations[iNode2][iComp];
            pMSize pSNew = new MeshSize((pMSize)PList_item(meshSizes,iNode2));
            PList_append(newMeshSizes,pSNew);
          }

          break;
        }

        if(R_isPointInside(region,targetLocations[iNode])) {
          currentReg = region;
          break;
        }

        int foundFace = 0, numRFaces = R_numFaces(region);
        pFace copyOpFace = opFace;
        for(int iFace=0; iFace<numRFaces; iFace++) {
          face = R_face(region,iFace);
          if(face==opFace || F_numEdges(face)!=3)
            continue;

          F_coord(face,fxyz);

          if(M_intersectRay3XYZ(xyz,vec,fxyz,tmp_xyz,&infinite)) {
            if(infinite)
              continue;

            ptOnFace = F_isPointInside(face,tmp_xyz);

            if(ptOnFace==1) {
              opFace = face;
              foundRegion = 0;
              break;
            }

            switch(ptOnFace) {
            case 0 :
              continue;
              break;
//          case 1 :
//            opFace = face;
//            foundFace = 1;
//            break;
            case 2 :
            case 3 :
            case 4 :
              {
                pPList fverts =  F_vertices(face,1);
                vertex = (pVertex)PList_item(fverts,ptOnFace-2);
                PList_delete(fverts);

                vector<pVertex> vregs;
                V_nonBLRegions(vertex, vregs);
                numRegs = vregs.size();
                for(int iRgn=0; iRgn<numRegs; iRgn++) {
                  rgn = vregs[iRgn];

                  if(R_isPointInside(rgn,targetLocations[iNode])) {
                    currentReg = rgn;
                    break;
                  }

                  face = R_vtOpFc(rgn,vertex);

                  F_coord(face,fxyz);

                  if(M_intersectRay3XYZ(xyz,vec,fxyz,tmp_xyz1,&infinite)) {
                    if(infinite)
                      continue;

                    if( XYZ_distance2(tmp_xyz1,targetLocations[iNode]) <
                        XYZ_distance2(tmp_xyz,targetLocations[iNode]) ) {
                      if(F_isPointInside(face,tmp_xyz1)) {
                        region = rgn;
                        opFace = face;
                        foundRegion = 1;
                        break;
                      }
                    }
                  }
                }

                if(!foundRegion && V_whatInType(vertex)!=3) {
                  foundRegion = 1;
                  opFace = face;
                }
              }
              break;
            case 5 :
            case 6 :
            case 7 :
              {
                edge = F_edge(face,ptOnFace-5);

                vector<pRegion> eregs;
                E_nonBLRegions(edge, eregs);
                numRegs = eregs.size();
                for(int iRgn=0; iRgn<numRegs; iRgn++) {
                  rgn = eregs[iRgn];

                  if(R_isPointInside(rgn,targetLocations[iNode])) {
                    currentReg = rgn;
                    break;
                  }

                  for(int iFc=0; iFc<4; iFc++) {
                    fc = R_face(rgn,iFc);
                    if(F_inClosure(fc,(pEntity)edge))
                      continue;

                    F_coord(fc,fxyz);

                    if(M_intersectRay3XYZ(xyz,vec,fxyz,tmp_xyz1,&infinite)) {
                      if(infinite)
                        continue;

                      if( XYZ_distance2(tmp_xyz1,targetLocations[iNode]) <
                          XYZ_distance2(tmp_xyz,targetLocations[iNode]) ) {
                        if(F_isPointInside(fc,tmp_xyz1)) {
                          region = rgn;
                          opFace = fc;
                          foundRegion = 1;
                          break;
                        }
                      }
                    }
                  }

//                opEdge = R_gtOppEdg(rgn,edge);

//                double e_xyz[2][3], e_vec[2][3], e_crossVec[2][3];

//                for(int iVert=0; iVert<2; iVert++) {
//                  V_coord(E_vertex(opEdge,iVert),e_xyz[iVert]);
//                  diffVt(e_xyz[iVert],tmp_xyz,e_vec[iVert]);
//                  crossProd(vector,e_vec[iVert],e_crossVec[iVert]);
//                }

//                if(!(dotProd(e_crossVec[0],e_crossVec[1])>0.0)) {
//                  region = rgn;
//                  // this can create trouble as same as copyFace
//                  opFace = face;
//                  foundRegion = 1;
//                  break;
//                }
                }

                if(!foundRegion && E_whatInType(edge)!=3) {
                  foundRegion = 1;
                  opFace = face;
                }
              }
              break;
            }

//          if(F_isPointInside(face,tmp_xyz)) {
//            opFace = face;
//            break;
//          }
          }

          if(foundRegion || currentReg)
            break;
        }

        if(!currentReg && opFace==copyOpFace) {
          cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
          cout<<"could NOT find opposite face [counter="<<counter<<"]"<<endl;

//          dumpBLStack(ONode,1,1,"NoOpFaceBLStack",targetLocations[iNode]);

          exit(0);

        }
      }

      if(!termination && !currentReg) {
        cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
        cout<<"could NOT find appropriate region"<<endl;

//        dumpBLStack(ONode,1,1,"NoRegionBLStack",targetLocations[iNode]);

        exit(0);
      }

      if(termination)
        break;

      if(EN_getDataPtr((pEntity)node,currentRegionID,(void **)&region)) {
        if(region!=currentReg)
          EN_modifyDataPtr((pEntity)node,currentRegionID,currentReg);
      }
      else
        EN_attachDataPtr((pEntity)node,currentRegionID,currentReg);

      pMSize pSNew;
      // pPList vlist = R_vertices(currentReg,1);
//      pSNew = pSizeField->getSize(targetLocations[iNode], currentReg);
      pSNew = pSizeField->getSize(node, targetLocations[iNode], normal, currentReg);
      // PList_delete(vlist);

      PList_append(newMeshSizes,pSNew);
      continue;
    }
  }

  if(PList_size(newMeshSizes)!=listSize-1-curNode) {
    cout<<"\nError in meshAdapt::updateSizesOfUpperNodesOnGC()..."<<endl;
    cout<<"new mesh sizes are NOT appropriate in number"<<endl;
    exit(0);
  }

  pMSize pSOld;
  pPList oldMeshSizes = PList_new();
  for(int iNode=curNode; iNode<listSize-1; iNode++) {
    pSOld = (pMSize)PList_item(meshSizes,iNode);
    PList_append(oldMeshSizes,pSOld);
  }
  for(int iNode=0; iNode<listSize-1-curNode; iNode++) {
    pSOld = (pMSize)PList_item(oldMeshSizes,iNode);
    PList_remItem(meshSizes,(void *)pSOld);
    delete pSOld;
  }
  PList_delete(oldMeshSizes);

  double *eigenVec;
  double dir[3][3], h[3];
  int aligned = -1;
  pMSize pS;

  if(scaleOption) {

    // curNode is zero when scaleOption is true
    for(int iNode=curNode; iNode<listSize; iNode++) {

      // also scale the originating node
      node = nodesOnGC[iNode];

      if(!iNode)
        pS = pSizeField->getSize(node);
      else
        pS = (pMSize)PList_item(newMeshSizes,iNode-1);

      // probably should use info. on type of ellipsoid represented by mesh metric tensor
      // like truely ellipsoid, prolate spheroid (with h[0] close to h[1])
      // oblate spheroid (with h[1] close to h[2]) or sphere (with h[0], h[1] and h[2] close to each other)
      double maxAligned = 0., dotAligned;
      for(int iComp=0; iComp<3; iComp++) {
        eigenVec = pS->eigenvector(iComp);
        h[iComp] = pS->size(iComp);
        for(int j=0; j<3; j++)
          dir[iComp][j] = eigenVec[j];
        dotAligned = fabs(dotProd(normal,dir[iComp]));
//      if(fabs(dotAligned-1.)<0.01)
//        aligned = iComp;
        if(dotAligned>maxAligned) {
          maxAligned = dotAligned;
          aligned = iComp;
        }
      }

      // atleast one must be aligned with the normal
      if(aligned==-1) {
        cout<<"\nError in updateSizesOfUpperNodesOnGC()..."<<endl;
        cout<<"could NOT find any dir. aligned with normal during scaling\n"<<endl;
        exit(0);
      }

      double patch[3];
      double xyzNode[3];
      // modify the corresponding size as per the scaling
      if(iNode==0) {
        // originating node
        V_coord(node,xyzNode);
        diffVt(targetLocations[0],xyzNode,patch);
        h[aligned] = dotProd(patch,normal);
      }
      else if(iNode==listSize-1) {
        // top most node
        if(iNode==1) {
          V_coord(ONode,xyzNode);
          diffVt(targetLocations[iNode-1],xyzNode,patch);
        }
        else
          diffVt(targetLocations[iNode-1],targetLocations[iNode-2],patch);
        h[aligned] = dotProd(patch,normal);
      }
      else {
        // other than originating and top most node

        // average of lower and upper patch

        // first lower patch
        if(iNode==1) {
          V_coord(ONode,xyzNode);
          diffVt(targetLocations[iNode-1],xyzNode,patch);
        }
        else
          diffVt(targetLocations[iNode-1],targetLocations[iNode-2],patch);

        h[aligned] = dotProd(patch,normal);

        // then upper patch
        diffVt(targetLocations[iNode],targetLocations[iNode-1],patch);
        h[aligned] += dotProd(patch,normal);

        // average
        h[aligned] /= 2;
      }

      if(iNode)
        delete pS;
      pSizeField->deleteSize((pEntity)node);
      pSizeField->setSize((pEntity)node,dir,h);

      if(iNode) {
        pMSize pSNew = new MeshSize(pSizeField->getSize(node));
        PList_append(meshSizes,pSNew);
      }
    }
  }
  else {
    //   for(int iNode=curNode; iNode<listSize-1; iNode++)
    //     PList_append(meshSizes,PList_item(newMeshSizes,iNode-curNode));
    PList_appPList(meshSizes,newMeshSizes);
  }

  PList_delete(newMeshSizes);
}

int M_checkForEdgeInMesh(pMesh mesh);
void M_checkPointforMesh1(pMesh mesh);
void M_checkForMesh(pMesh mesh);

extern pMeshDataId gcThicknessID;

#ifdef MA_PARALLEL
void meshAdapt::thicknessAdaptationInBL(pmMigrationCallbacks& userLB) 
#else
void meshAdapt::thicknessAdaptationInBL()
#endif
{
  int gcThicknessTag, listSize;
  double normal[3], vec[3], curLength, desiredThickness, totalThickness, mtol = M_getTolerance();
  double dGrowthFactor, dSecondGrowthEdge, dFirstGrowthEdge, dNormalUnstr;
  vector<pVertex> nodesOnGC;
  pVertex vtx, node, topNode;
  pRegion currentReg;
  double xyzAtEnds[2][3], hAtEnds[2];
  pVertex vtxAtEnds[2];
  pMSize pSAtEnds[2];

  double *eigenVec, *target;
  double dir[3][3], h[3];
  pMSize pS;

  int h0flag = 0;
  double rmin = 1., rmax = 1.9999999999999999;
  // everytime assign this flag to true
  thicknessAdaptExecuted = 1;

  int gc_Type, gc_Tag;

  int thicknessChangeTag;
  pMeshDataId thicknessID = MD_newMeshDataId("increasing thickness");
  int updateGCOnModelBdryTag;
  pMeshDataId updateGCOnModelBdryID = MD_newMeshDataId("update GC on model bdry. after thickness adjustment");
  double *initialLoc;
  pMeshDataId initialLocID = MD_newMeshDataId("initial location");
  dArray *currentLocations;
  pMeshDataId targetLocationsID = MD_newMeshDataId("target locations");
  dArray *targetLocations;
  pMeshDataId meshSizesID = MD_newMeshDataId("new mesh sizes");
  pPList meshSizes;

  currentRegionID = MD_newMeshDataId("current region");

  pMeshDataId procTag = MD_lookupMeshDataId("ProcessedONodeTag");
  deque<pVertex> procVerts;
  int value;

  pFace face;
  pRegion rgn;

#ifdef DEBUG
int count_orig_nodes = 0;
#endif

  /// Loop over entity groups
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    /// Find the zero-level face, i.e. the face on the surface
    face = BL_GetZeroLvlFace((pBLayer)(*egIt));

    for (int iVert = 0; iVert < 3; ++iVert)
    {
      vtx = F_vertex(face, iVert);
      if (!V_isOriginatingNode(vtx) || EN_getDataInt(vtx,procTag,&value))
        continue;

      EN_attachDataInt(vtx,procTag,1);
      procVerts.push_back(vtx);

      BL_getGrowthCurveNodes(vtx, nodesOnGC);
      GC_getNormalVector(vtx, normal);

      listSize = nodesOnGC.size();

      if(listSize==1) {
	EN_attachDataInt((pEntity)vtx,gcThicknessID,1);
	continue;
      }

      topNode = nodesOnGC[listSize-1];

      // exclude the originating node
      currentLocations = new dArray[listSize-1];
      targetLocations = new dArray[listSize-1];
      meshSizes = PList_new();
      for(int iNode=0; iNode<listSize-1; iNode++) 
      {
	vtxAtEnds[1] = nodesOnGC[iNode+1];
	V_coord(vtxAtEnds[1],currentLocations[iNode]);
        if(!nullFieldFlag) 
        {
  	  pSAtEnds[1] = new MeshSize(pSizeField->getSize(vtxAtEnds[1]));
	  PList_append(meshSizes,pSAtEnds[1]);
        }
      }

      // use these values in the below loop for iNode=0
      vtxAtEnds[1] = nodesOnGC[0];
      V_coord(vtxAtEnds[1],xyzAtEnds[1]);
      if(!nullFieldFlag) 
        pSAtEnds[1] = pSizeField->getSize(vtxAtEnds[1]);

      if(isFirstLayerThicknessSet) 
      {
        double firstLayerThickness;
        if(!EN_getDataDbl((pEntity)vtx, firstLayerThicknessID, &firstLayerThickness)) {
	  cout<<"\nError in meshAdapt::thicknessAdaptationInBL()"<<endl;
	  cout<<"first layer thickness NOT attached to originating node"<<endl;
	  exit(0);
        }

        // Calculate growth factor for the current growth curve
        V_coord(nodesOnGC[1], xyzAtEnds[0]);
        V_coord(nodesOnGC[2], xyzAtEnds[1]);
        diffVt(xyzAtEnds[1], xyzAtEnds[0], vec);
        dSecondGrowthEdge = dotProd(vec,normal);

        V_coord(nodesOnGC[0], xyzAtEnds[0]);
        V_coord(nodesOnGC[1], xyzAtEnds[1]);
        diffVt(xyzAtEnds[1], xyzAtEnds[0], vec);
        dFirstGrowthEdge = dotProd(vec,normal);
        dGrowthFactor = dSecondGrowthEdge / dFirstGrowthEdge;

        /// Calculate initial total thickness
        V_coord(topNode,xyzAtEnds[1]);
        diffVt(xyzAtEnds[1],xyzAtEnds[0],vec);
        totalThickness = dotProd(vec,normal);

        double *thicknesses = new double[listSize-1];

        dNormalUnstr = BL_GetNormalUnstrHeight(topNode, normal); 

        /// Limit the first layer thickness if it's too high / low
//        BL_LimitFirstLayerThickness(dFirstGrowthEdge, firstLayerThickness, dGrowthFactor, dNormalUnstr, listSize-1);

        BL_CalcThicknessesUsingFirstThicknessAndGrowthFactor(firstLayerThickness, dGrowthFactor, thicknesses, listSize);

//        BL_geomProg(firstLayerThickness,totalThickness,listSize,thicknesses,rmin,rmax,h0flag);

        V_coord(vtx,xyzAtEnds[0]);
        double accumThickness = 0.;
        // loop over nodes on GC
        for(int iNode=0; iNode<listSize-1; iNode++) {
          accumThickness += thicknesses[iNode];

          // move the nodes based on desired thickness computed
          diffVt(currentLocations[iNode],xyzAtEnds[0],vec);
          double dot = dotProd(vec,normal);
          // find the vector orthogonal to normal (side vector that will be preserved)
          for(int iComp=0; iComp<3; iComp++)
            vec[iComp] = vec[iComp] - dot*normal[iComp];

          for(int iComp=0; iComp<3; iComp++)
            targetLocations[iNode][iComp] = xyzAtEnds[0][iComp] + accumThickness*normal[iComp] + vec[iComp];
        }
	delete [] thicknesses;

        GC_getClassification(nodesOnGC, gc_Type, gc_Tag);
	if(gc_Type<3)
	  updateTargetLocationsOfUpperNodesOnGCOnModelBdry(nodesOnGC,0,targetLocations);

	// update the sizefield for this node and all nodes on upper levels
        updateSizesOfUpperNodesOnGC(nodesOnGC,-99,currentLocations,targetLocations,meshSizes);
      }

      else
      {
        printf ("Error: At least first layer thickness should be provided to accomplish the thickness adjustment\n");
        exit(-1);
      }
      
      // check for validity of elements based on node distribution on growth curve
      // (this may not be stringent)
      // Sometimes it can occur when 2 or more nodes from the growth curve try to be moved outside of the domain boundary, and they are corrected
      // using the closest point functions. There is no additional check or patch for that, it is assumed the mesh is big enough comparing to
      // the size of the boundary level, so its thickness can be adjusted correctly without going outside of the domain.
      for(int iNode=0; iNode<listSize-2; iNode++) {
	diffVt(targetLocations[iNode+1],targetLocations[iNode],vec);
	if(dotProd(vec,normal)<mtol) {
	  cout<<"\nError in meshAdapt::thicknessAdaptationInBL()"<<endl;
	  cout<<"target locations would result in negative volume"<<endl;
	  exit(0);
	}
      }

      delete [] currentLocations;
      EN_attachDataPtr((pEntity)vtx,targetLocationsID,targetLocations);
      EN_attachDataPtr((pEntity)vtx,meshSizesID,meshSizes);

      node = nodesOnGC[listSize-1];

      initialLoc = new double[3];
      V_coord(node,initialLoc);
      // attach to ONode
      EN_attachDataPtr((pEntity)vtx,initialLocID,initialLoc);

      for(int iNode=0; iNode<listSize-1; iNode++) {
	node = nodesOnGC[iNode+1];
	if(EN_getDataPtr((pEntity)node,currentRegionID,(void **)&currentReg))
	  EN_deleteData((pEntity)node,currentRegionID);
      }
    }

#ifdef DEBUG
count_orig_nodes++;
#endif

  }

  gradeLayerThicknessAroundGC(targetLocationsID,meshSizesID);

  for (deque<pEdge>::iterator eIt = procVerts.begin(); eIt != procVerts.end(); ++eIt)
  {
      vtx = *eIt;
      BL_getGrowthCurveNodes(vtx, nodesOnGC);
      listSize = nodesOnGC.size();
      GC_getNormalVector(vtx, normal);

      EN_getDataPtr((pEntity)vtx,targetLocationsID,(void **)&targetLocations);
      EN_getDataPtr((pEntity)vtx,meshSizesID,(void **)&meshSizes);

      // check for validity of elements based on node distribution on growth curve
      // (this may not be stringent)
      for(int iNode=0; iNode<listSize-2; iNode++) {
	diffVt(targetLocations[iNode+1],targetLocations[iNode],vec);
	if(dotProd(vec,normal)<mtol) {
	  cout<<"\nError in meshAdapt::thicknessAdaptationInBL()"<<endl;
	  cout<<"target locations would result in negative volume (after grading layer thickness)"<<endl;
	  exit(0);
	}
      }

      V_coord(vtx,xyzAtEnds[0]);
      topNode = nodesOnGC[listSize-1];
      V_coord(topNode,xyzAtEnds[1]);

      diffVt(xyzAtEnds[1],xyzAtEnds[0],vec);
      curLength = dotProd(vec,normal);
      diffVt(targetLocations[listSize-2],xyzAtEnds[0],vec);
      totalThickness = dotProd(vec,normal);

      // move the lower level nodes if the total thickness is decreasing
      if(curLength*(1-1.e-4)>=totalThickness) {

	// do not let total thickness fall below certain level
	if(isLowerLimitOnTotalThickness) {
	  double lowerLimitOnTotThickness = V_getLowerLimitOnTotThickness(vtx);
	  double scaleFactor;
	  if(lowerLimitOnTotThickness==0.)
	    scaleFactor=0.9;
	  else
	    scaleFactor = lowerLimitOnTotThickness/totalThickness;

	  if(scaleFactor>1.) {
	    dArray *currentLocationsOrg = new dArray[listSize-1];
	    dArray *targetLocationsModified = new dArray[listSize-1];
	    pPList meshSizesOrg = PList_new();

	    for(int iNode=0; iNode<listSize-1; iNode++) {
	      vtxAtEnds[1] = nodesOnGC[iNode+1];
	      pSAtEnds[1] = new MeshSize(pSizeField->getSize(vtxAtEnds[1]));
	      PList_append(meshSizesOrg,pSAtEnds[1]);
	      V_coord(vtxAtEnds[1],currentLocationsOrg[iNode]);

	      if(!iNode) {
		// collect xyzAtEnds[0] for the first iter. in the loop
		V_coord(vtx,xyzAtEnds[0]);
		// copy the targetLocations into targetLocationsModified in the first iter. of the loop
		for(int iNode2=0; iNode2<listSize-1; iNode2++)
		  for(int iComp=0; iComp<3; iComp++)
		    targetLocationsModified[iNode2][iComp] = targetLocations[iNode2][iComp];
	      }

	      // scale each thickness linearly
	      double targetLocationsKeep[3];
	      diffVt(targetLocationsModified[iNode],xyzAtEnds[0],vec);
	      double dot = dotProd(vec,normal);
	      for(int iComp=0; iComp<3; iComp++) {
		targetLocationsKeep[iComp] = targetLocationsModified[iNode][iComp];
		// find the vector orthogonal to normal (side vector that will ve preserved)
		vec[iComp] = vec[iComp] - dot*normal[iComp];
		targetLocationsModified[iNode][iComp] = xyzAtEnds[0][iComp] + scaleFactor*dot*normal[iComp] + vec[iComp];
		// collect xyzAtEnds[0] for next loop
		xyzAtEnds[0][iComp] = targetLocationsModified[iNode][iComp];
	      }

	      // move the upper nodes by constant amount
	      // vector contains this constant amount see line below
	      diffVt(targetLocationsModified[iNode],targetLocationsKeep,vec);
	      for(int iNode2=iNode+1; iNode2<listSize-1; iNode2++)
		for(int iComp=0; iComp<3; iComp++)
		  targetLocationsModified[iNode2][iComp] = targetLocationsModified[iNode2][iComp] + vec[iComp];

	    }

            GC_getClassification(nodesOnGC, gc_Type, gc_Tag);
	    if(gc_Type<3)
	      updateTargetLocationsOfUpperNodesOnGCOnModelBdry(nodesOnGC,0,targetLocationsModified);

	    // update the sizefield for all nodes (in one go) due to scaling (caused by lower limit on tot. thickness)
	    // use original locations and sizes to update the sizes for all nodes at once
	    updateSizesOfUpperNodesOnGC(nodesOnGC,-99,currentLocationsOrg,targetLocationsModified,meshSizesOrg);

	    V_coord(vtx,xyzAtEnds[0]);
	    diffVt(targetLocationsModified[listSize-2],xyzAtEnds[0],vec);
	    totalThickness = dotProd(vec,normal);
	    if(!(fabs(totalThickness-lowerLimitOnTotThickness)<=
		 0.1*lowerLimitOnTotThickness)) {
	      cout<<"\nError in meshAdapt::thicknessAdaptationInBL()"<<endl;
	      cout<<"lower limit on total thickness NOT reached"<<endl;
	      exit(0);
	    }

	    for(int iNode=0; iNode<listSize-1; iNode++) {
	      pS = (pMSize)PList_item(meshSizes,iNode);
	      delete pS;
	    }
	    PList_clear(meshSizes);

	    for(int iNode=0; iNode<listSize-1; iNode++) {
	      PList_append(meshSizes,PList_item(meshSizesOrg,iNode));
	      for(int iComp=0; iComp<3; iComp++)
		targetLocations[iNode][iComp] = targetLocationsModified[iNode][iComp];
	    }

	    // check for validity of elements based on node distribution on growth curve
	    // (this may not be stringent)
	    for(int iNode=0; iNode<listSize-2; iNode++) {
	      diffVt(targetLocations[iNode+1],targetLocations[iNode],vec);
	      if(dotProd(vec,normal)<mtol) {
		cout<<"\nError in meshAdapt::thicknessAdaptationInBL()"<<endl;
		cout<<"target locations would result in negative volume (after scaling due to lower limit on total thickness)"<<endl;
		exit(0);
	      }
	    }

	    delete [] currentLocationsOrg;
	    delete [] targetLocationsModified;
	    PList_delete(meshSizesOrg);
	  }
	}

	for(int iNode=0; iNode<listSize-2; iNode++) {
	  // PROBABLY SHOULD INTRODUCE VALIDITY CHECKS 
	  // (based on volume of elements)
	  // (one which is done before to check distribution of nodes along growth curve is not stringent)
	  node = nodesOnGC[iNode+1];
	  adaptUtil::move_vertex(node,targetLocations[iNode],CB_move,userData_CB_move);
 	}

        if(PList_size(meshSizes)) {
	  for(int iNode=0; iNode<listSize-2; iNode++) {
  	    pS = (pMSize)PList_item(meshSizes,iNode);
	    for(int iComp=0; iComp<3; iComp++) {
	      eigenVec = pS->eigenvector(iComp);
	      h[iComp] = pS->size(iComp);
	      for(int j=0; j<3; j++)
	        dir[iComp][j] = eigenVec[j];
	    }

	    delete pS;
	    pSizeField->deleteSize((pEntity)node);
	    pSizeField->setSize((pEntity)node,dir,h);
          }
 	}

      }
      else {
	// node = (pVertex)PList_item(nodesOnGC,0);
	EN_attachDataInt((pEntity)vtx,thicknessID,1);
      }

      // this is deleted in snap
      target = new double[3];
      for(int iComp=0; iComp<3; iComp++)
	target[iComp] = targetLocations[listSize-2][iComp];

      pSnapList->push_back(std::make_pair(topNode,target));
  }

  for (deque<pEdge>::iterator eIt = procVerts.begin(); eIt != procVerts.end(); ++eIt)
    EN_deleteData(*eIt,procTag);


  pSnap->setBLAdapt(1);
  pSnap->setCounterMax(1);
  pSnap->setDefaultMaxLenSq();
  // pSnap->setMaxLenSq(9.0);
  setSnap();

  cout<<"\n entering snapping procedure for thickness adjustment..."<<endl;

#ifdef MA_PARALLEL
  int numBL = pSnap->run(userLB);
#else
  int numBL = pSnap->run();
#endif

  cout<<"\n leaving snapping procedure for thickness adjustment..."<<endl;

  pSnap->setBLAdapt(0);
  pSnap->setDefaultCounterMax();
  pSnap->setDefaultMaxLenSq();

  double tol = M_getTolerance(), gtol;
  double xyz[3];
  // pPList vregs;
  // pRegion region;

  /// Loop over entity groups
  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    /// Find the zero-level face, i.e. the face on the surface
    face = BL_GetZeroLvlFace((pBLayer)(*egIt));

    for (int iVert = 0; iVert < 3; ++iVert)
    {
      vtx = F_vertex(face, iVert);
      if (!V_isOriginatingNode(vtx) || EN_getDataInt(vtx,procTag,&value))
        continue;

      EN_attachDataInt(vtx,procTag,1);
      procVerts.push_back(vtx);

      BL_getGrowthCurveNodes(vtx, nodesOnGC);
      GC_getNormalVector(vtx, normal);

      // need this to update GC modified on model bdry.
      // (i.e., whose thickness was adjusted)
      GC_getClassification(nodesOnGC, gc_Type, gc_Tag);
      if(gc_Type<3)
	EN_attachDataInt((pEntity)vtx,updateGCOnModelBdryID,1);

      listSize = nodesOnGC.size();
      
      EN_getDataPtr((pEntity)vtx,targetLocationsID,(void **)&targetLocations);
      EN_deleteData((pEntity)vtx,targetLocationsID);
      EN_getDataPtr((pEntity)vtx,meshSizesID,(void **)&meshSizes);
      EN_deleteData((pEntity)vtx,meshSizesID);
      
      node = nodesOnGC[listSize-1];
      V_coord(node,xyz);  

      pGEntity gent = V_whatIn(node);
      gtol = GEN_tolerance(gent);

      diffVt(targetLocations[listSize-2],xyz,vec);
//      if(dotProd(vec,vec)<=gtol*gtol) {
      EN_attachDataInt((pEntity)vtx,gcThicknessID,1);
      if(EN_getDataPtr((pEntity)vtx,initialLocID,(void **)&initialLoc))
      {
        EN_deleteData((pEntity)vtx,initialLocID);
        delete [] initialLoc;
      }

      // the movement of the top most node to the target location
      // is successful through the snapping procedure 
      // node =  (pVertex)PList_item(nodesOnGC,0);
      if(EN_getDataInt((pEntity)vtx,thicknessID,&thicknessChangeTag)) {
	EN_deleteData((pEntity)vtx,thicknessID);
	// excluding originating and top most/interface node
	for(int iNode=0; iNode<listSize-2; iNode++) {
	  // PROBABLY SHOULD INTRODUCE VALIDITY CHECKS 
	  // (based on volume of elements)
	  // (one which is done before to check distribution of nodes along growth curve is not stringent)
	  node = nodesOnGC[iNode+1];
	  adaptUtil::move_vertex(node,targetLocations[iNode],CB_move,userData_CB_move);
        }

        if(PList_size(meshSizes)) {
	  for(int iNode=0; iNode<listSize-2; iNode++) {
	    pS = (pMSize)PList_item(meshSizes,iNode);
	    for(int iComp=0; iComp<3; iComp++) {
	      eigenVec = pS->eigenvector(iComp);
	      h[iComp] = pS->size(iComp);
	      for(int j=0; j<3; j++)
	        dir[iComp][j] = eigenVec[j];
	    }
	  
	    delete pS;
	    pSizeField->deleteSize((pEntity)node);
	    pSizeField->setSize((pEntity)node,dir,h);
	  }
        }

      }

      if(PList_size(meshSizes)) {
        node = nodesOnGC[listSize-1];
        pS = (pMSize)PList_item(meshSizes,listSize-2);
        for(int iComp=0; iComp<3; iComp++) {
  	  eigenVec = pS->eigenvector(iComp);
	  h[iComp] = pS->size(iComp);
	  for(int j=0; j<3; j++)
	    dir[iComp][j] = eigenVec[j];
        }

        delete pS;
        pSizeField->deleteSize((pEntity)node);
        pSizeField->setSize((pEntity)node,dir,h);
      }

      delete [] targetLocations;
      PList_delete(meshSizes);
    }
  }

  VIter vit = M_vertexIter(pmesh);
  while(vtx = VIter_next(vit)) {
    if( V_isOriginatingNode(vtx) &&
	EN_getDataInt((pEntity)vtx,updateGCOnModelBdryID,&updateGCOnModelBdryTag) ) {

      EN_deleteData((pEntity)vtx,updateGCOnModelBdryID);

      BL_getGrowthCurveNodes(vtx, nodesOnGC);
      // if tagged with updateGCOnModelBdryID then it is likely 
      // that GC is classified on model bdry.
      GC_getClassification(nodesOnGC, gc_Type, gc_Tag);
      if(gc_Type<3)
      {
	if(updateGCOnModelBdry(nodesOnGC)) {
#ifdef DEBUG
	  cout<<"\n WARNING in meshAdapt::thicknessAdaptationInBL()..."<<endl;
	  cout<<" GC on model bdry. not completely updated\n"<<endl;
#endif
	}
      }
    }
  }
  VIter_delete(vit);

  for (deque<pEdge>::iterator eIt = procVerts.begin(); eIt != procVerts.end(); ++eIt)
    EN_deleteData(*eIt,procTag);


  MD_deleteMeshDataId(thicknessID);
  MD_deleteMeshDataId(updateGCOnModelBdryID);
  MD_deleteMeshDataId(initialLocID);
  MD_deleteMeshDataId(targetLocationsID);
  MD_deleteMeshDataId(meshSizesID);
  MD_deleteMeshDataId(currentRegionID);
  
  if( numBL==-1 ) 
    { adaptUtil::Info("Error: thickness adaptation return -1 for BL mesh\n"); exit(0); }

  if( numBL )
    adaptUtil::Info(numBL,"growth curves thickness are not adjusted for BL mesh");
}

// find the "best" possible total thickness of current GC
// (note : total thickness of adjacent GCs is assumed)
// a) find if the target locations for current node is inside any lower BL regions
//    if so limit target locations of the current node (and upper nodes) to the "best" possible extent
// b) find if the total thickness vector for current GC cross any plane [in 2D]
//    formed by "best possible" or "current other" (greater one of the two) total thickness vector of the adjacent GCs
//    if so limit target locations of the current node (and upper nodes) to the "best" possible extent
void meshAdapt::limitTargetLocationsBasedOnAdjGCs(vector<pVertex>& nodesOnGC,
						  int curNode,
						  dArray* currentLocations,
						  dArray* targetLocations) {
  double factor, totalThickness, vec[3], moveVector[3], normal[3], otherNormal[2][3], xyz[3], all_xyz[4][3], triXYZ[3][3], tmp_xyz[3], tmp_vector[3], tmp_dist;
  int listSize = nodesOnGC.size();
  int triVertMap[2][3] = {0,1,3, 0,3,2};

  pVertex onode = nodesOnGC[0];
  GC_getNormalVector(onode, normal);
  V_coord(onode,xyz);

  int foundIntersection = 0, foundInside = 0, infinite, index;
  double otherTotalThickness[2], length;
  pVertex vtx;
  pEdge opEdge;
  pFace layerFace;
  pRegion blRegion;
  vector<pVertex> otherGC;

  // allocate for each upper node (actually do not need ones below "curNode")
  dArray *targetLocationsSafe = new dArray[listSize-1];
  for(int iNode=curNode; iNode<listSize-1; iNode++)
    for(int iComp=0; iComp<3; iComp++)
      targetLocationsSafe[iNode][iComp] = currentLocations[iNode][iComp];   

  int numPasses = 2;

  // here "moveVector" is the full vector with respect to current locations
  diffVt(targetLocations[curNode],targetLocationsSafe[curNode],moveVector);
  factor = 1.0;

  vector<pFace> vLayerFaces;
  V_layerFaces(onode, vLayerFaces);
  int numLayerFaces = vLayerFaces.size();

  int offset = 1;
  pVertex currentNode = nodesOnGC[curNode+offset];
  pPList vRegs = V_regions(currentNode);
  int numVRegs = PList_size(vRegs);

  int minLayerFace = -1, intersectionLayerFace = 0, intersectionLayerFaceFound = 0, modelBdryTermination = 0;
  double minDist = 1.e10;
  int insideBLRegion = 0, insideBLRegionFound = 0;

  for(int iPass=0; iPass<numPasses; iPass++) {

    foundIntersection = 0;
    foundInside = 0;

    diffVt(targetLocations[listSize-2],xyz,vec);
    totalThickness = dotProd(vec,normal);
    for(int iLayerFace=intersectionLayerFace; !foundInside && iLayerFace<numLayerFaces; iLayerFace++) {

      layerFace = vLayerFaces[iLayerFace];
      opEdge = F_vtOpEd(layerFace,onode);
      if(E_whatInType(opEdge)==1)
	modelBdryTermination = 1;

      // split each adjacent plane [in 2D], i.e., quad. into two triangles
      for(int iEVert=0; iEVert<2; iEVert++) {
	vtx = E_vertex(opEdge,iEVert);
	V_coord(vtx,all_xyz[iEVert]);
        BL_getGrowthCurveNodes(vtx, otherGC);
	GC_getNormalVector(otherGC[0],otherNormal[iEVert]);
	otherTotalThickness[iEVert] = GC_getTotalThickness(otherGC);
      }

      for(int iEVert=0; iEVert<2; iEVert++) {
	length = totalThickness;
	if(otherTotalThickness[iEVert]>length)
	  length = otherTotalThickness[iEVert];
	for(int iComp=0; iComp<3; iComp++)
	  all_xyz[iEVert+2][iComp] = all_xyz[iEVert][iComp] + length*otherNormal[iEVert][iComp];
      }

      // split each adjacent plane [in 2D], i.e., quad. into two triangles
      for(int iTri=0; iTri<2; iTri++) {
	for(int iTriVert=0; iTriVert<3; iTriVert++) {
	  index = triVertMap[iTri][iTriVert];
	  for(int iComp=0; iComp<3; iComp++)
	    triXYZ[iTriVert][iComp] = all_xyz[index][iComp];
	}

	if(M_intersectRay3XYZ(xyz,vec,triXYZ,tmp_xyz,&infinite)) {
	  // may be throw exception in case of infinite intersection
	  if(infinite)
	    continue;

// 	  if(XYZ_distance2(targetLocations[listSize-2],xyz)<XYZ_distance2(tmp_xyz,xyz))
// 	    continue;

	  diffVt(tmp_xyz,xyz,tmp_vector);
	  tmp_dist = dotProd(tmp_vector,normal);
	  if(tmp_dist<0.)
	    continue;

	  if(totalThickness<tmp_dist)
	    continue;
	  else {
	    // a cross over of the plane is considered such that 
	    // component of vector from origination node to point of intersection 
	    // is smaller than the total thickness vector along normal
	    foundIntersection = 1;
	    if(minDist>tmp_dist) {
	      minDist = tmp_dist;
	      minLayerFace = iLayerFace;
	    }
	    break;
	  }

// 	  if(modelBdryTermination || XYZ_isPointInsideTriangle(triXYZ,tmp_xyz)) {
// 	    foundIntersection = 1;
// 	    break;
// 	  }
	}
      }

      if(foundIntersection) {
	if(!iPass && intersectionLayerFaceFound) {
	  if(intersectionLayerFace!=iLayerFace) {
	    cout<<"\nError in meshAdapt::limitTargetLocationsBasedOnAdjGCs()..."<<endl;
	    cout<<"conflict in intersection layer face [iPass="<<iPass<<"] [intersectionLayerFace="<<intersectionLayerFace<<",iLayerFace="<<iLayerFace<<"]\n"<<endl;
	    exit(0);
	  }
	}
	else {
	  // intersectionLayerFace will be updated in the loop as minLayerFace is updated
	  intersectionLayerFace = minLayerFace;
	  intersectionLayerFaceFound = 1;
	}
	// for first pass find the layer face with minimum "tmp_dist"
	if(!iPass)
	  break;
      }
    }

    for(int iVReg=insideBLRegion; !foundIntersection && iVReg<numVRegs; iVReg++) {
      blRegion = (pRegion)PList_item(vRegs,iVReg);

      if(!EN_isBLEntity((pEntity)blRegion))
	continue;
      
      if(EN_levelInBL((pEntity)blRegion)!=curNode+offset)
	continue;

      if(EN_isPointInside((pEntity)blRegion,targetLocations[curNode])) {
	foundInside = 1;
	break;
      }

      if(foundInside) {
	if(insideBLRegionFound) {
	  if(insideBLRegion!=iVReg) {
	    cout<<"\nError in meshAdapt::limitTargetLocationsBasedOnAdjGCs()..."<<endl;
	    cout<<"conflict in inside BL region [iPass="<<iPass<<"] [insideBLRegion="<<insideBLRegion<<",iVReg="<<iVReg<<"]\n"<<endl;
	    exit(0);
	  }
	}
	else {
	  insideBLRegion = iVReg;
	  insideBLRegionFound = 1;
	}
	break;
      }
    }

    // full movement is possible
    if(!iPass && !(foundIntersection+foundInside))
      break;
    else {
      if(foundIntersection || foundInside)
	factor = -fabs(factor)*2.;
      else {
	// for no intersection with adj. GCs or inside lower BL regions around current node
	// keep a safe copy (this is within "iPass!=0")
	for(int iNode=curNode; iNode<listSize-1; iNode++)
	  for(int iComp=0; iComp<3; iComp++)
	    targetLocationsSafe[iNode][iComp] = targetLocations[iNode][iComp]; 

	factor = fabs(factor)*2.;
      }

      for(int iComp=0; iComp<3; iComp++)
	vec[iComp] = moveVector[iComp]/factor;
      // modify the target locations as per the intersection or inside info.
      for(int iNode=curNode; iNode<listSize-1; iNode++)
	for(int iComp=0; iComp<3; iComp++)
	  targetLocations[iNode][iComp] = targetLocations[iNode][iComp]+vec[iComp];
    }
  }
  PList_size(vRegs);

  if(foundInside || foundIntersection) {
    for(int iNode=curNode; iNode<listSize-1; iNode++)
      for(int iComp=0; iComp<3; iComp++)
	targetLocations[iNode][iComp] = targetLocationsSafe[iNode][iComp];
  }

  delete [] targetLocationsSafe;

}


pVertex meshAdapt::updateGCOnModelBdry(vector<pVertex>& nodesOnGC) {

  pVertex oNode = nodesOnGC[0];
  int gc_Type, gc_Tag;
  // assuming updateGCOnModelBdry() is called for GCs on model bdry.
  GC_getClassification(nodesOnGC, gc_Type, gc_Tag);
  if(gc_Type==3)
    return 0;

  double gtol;
  double mtol = M_getTolerance();
  double par[]={0.0,0.0,0.0};
  double ori[3], coords[3];

  int valid = 1;
  pVertex node;
  int listSize = nodesOnGC.size();
  for(int iNode=0; iNode<listSize; iNode++) {
    node = nodesOnGC[iNode];
    V_coord(node,ori);
    pGEntity gent = V_whatIn(node);
    gtol=GEN_tolerance(gent);
    switch(GEN_type(gent)) {
    case 0 :
      if(V_isOriginatingNode(node)) {
	// check for distance between current location and model vertex location
	GV_point((pGVertex)gent,coords);
	if( XYZ_distance2(coords,ori) > gtol*gtol ) {
	  cout<<"\n WARNING in meshAdapt::updateGCOnModelBdry()..."<<endl;
	  cout<<" originating node classified on model vertex is not on model vertex\n"<<endl;
	}
      }
      else {
	cout<<"\nError in meshAdapt::updateGCOnModelBdry()..."<<endl;
	cout<<"node (other than ONode) is classified on model vertex"<<endl;
	exit(0);
      }
      break;
    case 1 :
      GE_closestPoint((pGEdge)gent,ori,coords,par);
      break;
    case 2 :
      GF_closestPoint((pGFace)gent,ori,coords,par);
      break;
    case 3 :
      // this should not happen (i.e., partial GC on model bdry.)
      cout<<"\nError in meshAdapt::updateGCOnModelBdry()..."<<endl;
      cout<<"partial GC on model bdry."<<endl;
      exit(0);
      break;
    }

    if(GEN_type(gent)<3) {
      if( XYZ_distance2(coords,ori) <= gtol*gtol ) {
        /// Take care of the parametric coordinates and the real ones
        pPoint pt = V_point(node);
        FMDB_P_setParametricPos (pt , par[0], par[1], par[2]);
        P_setPos(pt, coords[0],coords[1],coords[2]);
/*
	// do not use P_setParam1() or P_setParam2() as it also changes the real coords.
	pPoint pt=M_createP(pmesh,coords[0],coords[1],coords[2],par,0,gent);
	pPoint point=V_point(node);
	V_setPoint(node,pt);
	P_delete(point);
*/
      }
      else {
	valid = 1;
	adaptUtil::move_vertex(node,coords);
	pPList vRegs = V_regions(node);
	int numRegs = PList_size(vRegs);
	pPoint pt, point;
	pRegion rgn;
	for(int iRgn=0; iRgn<numRegs; iRgn++) {
	  rgn = (pRegion)PList_item(vRegs,iRgn);
	  if(R_Volume2(rgn)<mtol) {
	    valid = 0;

            pPoint pt = V_point(node);
            FMDB_P_setParametricPos (pt , par[0], par[1], par[2]);
            P_setPos(pt, ori[0],ori[1],ori[2]);
/*
	    // do not use P_setParam1() or P_setParam2() as it also changes the real coords.
	    pt=M_createP(pmesh,ori[0],ori[1],ori[2],par,0,gent);
	    point=V_point(node);
	    V_setPoint(node,pt);
	    P_delete(point);
*/

// 	    cout<<"\nWARNING in meshAdapt::updateGCOnModelBdry()..."<<endl;
// 	    cout<<"could NOT move node to model bdry... "<<endl;
// 	    V_info(node);

	    break;
	  }
	}
	PList_delete(vRegs);

	if(valid) {
	  adaptUtil::move_vertex(node,ori);
	  adaptUtil::move_vertex(node,coords,CB_move,userData_CB_move);
  
          pPoint pt = V_point(node);
          FMDB_P_setParametricPos (pt , par[0], par[1], par[2]);
          P_setPos(pt, coords[0],coords[1],coords[2]);
/*
	  // do not use P_setParam1() or P_setParam2() as it also changes the real coords.
	  pt=M_createP(pmesh,coords[0],coords[1],coords[2],par,0,gent);
	  point=V_point(node);
	  V_setPoint(node,pt);
	  P_delete(point);
*/
	}
	else {

	  return node;
	}
      }
    }
  }

  return 0;
}


void meshAdapt::decomposeMetricField()
{
#ifdef MA_PARALLEL
  pVertex vertex, node;
  pFace face;
  pRegion rgn;
  double normal[3];
  vector<pVertex> nodesOnGC;
  int listSize, metricDecomposedTag;

  Mesh_GetNormalVectorOfOrigVtx(pmesh);

  /// Deal with boundary layer vertices on the part boundary, communicate sizes to the vertices which are detached from their BLs
  /// and don't have normals to decompose sie fields
  IPComMan *CM;
  pVertex* vtxSend;
  void* msg_send;
  double* dSend;
  if (SCUTIL_CommSize() > 1)
  {
    /// Initialize IPComMan
    CM = ParUtil::Instance()->ComMan();
    CM->set_comm_validation(IPComMan::Neighbors);
    CM->set_tag(0);
    int num_sent = 0, num_recvd = 0;
    int iSize = sizeof(pVertex) + 12*sizeof(double);
    CM->set_fixed_msg_size(iSize);
    msg_send = CM->alloc_msg(iSize);
    vtxSend = (pVertex*)msg_send;
    dSend = (double*)((char*)msg_send + sizeof(pVertex));
  }

  for (pBLIter egIt = Mesh_GetBegBLIter(pmesh); egIt != Mesh_GetEndBLIter(pmesh); ++egIt)
  {
    /// Find the zero-level face, i.e. the face on the surface
    face = BL_GetZeroLvlFace((pBLayer)(*egIt));

    for (int iVert = 0; iVert < 3; ++iVert)
    {
      vertex = F_vertex(face, iVert);

      if(EN_getDataInt((pEntity)vertex,metricDecompositionID,&metricDecomposedTag))
        continue;

      BL_getGrowthCurveNodes(vertex, nodesOnGC);

      GC_getNormalVector(vertex, normal);

      listSize = nodesOnGC.size();
      for(int iNode=0; iNode<listSize; iNode++) 
      {
        node = nodesOnGC[iNode];
        pSizeField->decomposeMetricTensor(node,normal);

        if (!EN_onCB(node))
          continue;

        std::vector<std::pair<int, pMeshEnt> > VtxRemCpy;
        FMDB_Ent_GetAllRmt(node, VtxRemCpy);

        /// Get the rem copy of the vertex and send its sizes
        int pos=0;
        pMSize pS = pSizeField->getSize(node);
        for (int i=0;i<3;++i)
          dSend[pos++]=pS->size(i);
        for (int i=0;i<3;++i)
        {
          double* ebuf=pS->eigenvector(i);
          for (int j=0;j<3;++j)
            dSend[pos++]=ebuf[j];
        }
        for (int iRC = 0; iRC < VtxRemCpy.size(); ++iRC)
        {
          *vtxSend = VtxRemCpy[iRC].second;
          CM->send(VtxRemCpy[iRC].first, msg_send);
        }        
      }

      EN_attachDataInt((pEntity)vertex,metricDecompositionID,1);
    }
  }

  if (SCUTIL_CommSize() > 1)
  {
    CM->free_msg(msg_send);
    CM->finalize_send();

    void* msg_recv;
    int pid_from;
    // recieve phase
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      vtxSend = (pVertex*)msg_recv;
      node = *vtxSend;
      if (EN_levelInBL(node) < 0)
      {
        dSend = (double*)((char*)msg_recv + sizeof(pVertex));
        double e[3][3], h[3];
        int k = 0;
        for (;k<3;k++)
          h[k]=dSend[k];
        for (int i=0;i<3;++i)
          for (int j=0;j<3;++j)
            e[i][j]=dSend[k++];

        pSizeField->deleteSize((pEntity)node);
        pMSize pS = new MeshSize(e,h);
        pSizeField->setSize((pEntity)node, pS);
      }
      CM->free_msg(msg_recv);
    }
  }
#endif
}


#ifdef MA_PARALLEL
int meshAdapt::initSnapBLNodes(pmMigrationCallbacks &userLB) 
#else
int meshAdapt::initSnapBLNodes()
#endif
{
  // ASSUMING THAT INITIAL PARAMETRIC COORDINATES CAN BE USED

  int ptch = 0;
  double tol = M_getTolerance(), gtol;
  double orig_xyz[3], clsLoc[3], par[3];

//  MigrateRegAdjToHangingBLVtx(userLB);

  pVertex vtx;
  pPoint pt, point;
  VIter viter = M_vertexIter(pmesh);
  while(vtx = VIter_next(viter))
  {
    if(EN_isBLEntity((pEntity)vtx))
    {
//      if (EN_levelInBL(vtx) < 0)
//        continue;

      V_coord(vtx,orig_xyz);
      pGEntity gent = V_whatIn(vtx);
      int genType = GEN_type(gent);
      gtol = GEN_tolerance(gent);
      switch(genType) {
      case 0 :
	if(V_isOriginatingNode(vtx)) {
	  // check for distance between current location and model vertex location
	  GV_point((pGVertex)gent,clsLoc);
	  if( XYZ_distance2(clsLoc,orig_xyz) > gtol*gtol ) {
	    cout<<"\n WARNING in meshAdapt::initSnapBLNodes()..."<<endl;
	    cout<<" originating node classified on model vertex needs to be snapped\n"<<endl;
	  }
	}
	else {
	  cout<<"\nError : in meshAdapt::initSnapBLNodes()"<<endl;
	  cout<<"node (other than ONode) classified on model vertex "<<endl;
	  exit(0);
	}
	break;
      case 1 :
	pt = V_point(vtx);
	par[0]=P_param1(pt);
	GE_point((pGEdge)gent,par[0],clsLoc);
	// GE_closestPoint((pGEdge)gent,orig_xyz,clsLoc,par);
	break;
      case 2 :
	pt = V_point(vtx);
	P_param2(pt,&par[0],&par[1],&ptch);	
	GF_point((pGFace)gent,par,clsLoc);
	// GF_closestPoint((pGFace)gent,orig_xyz,clsLoc,par);
	break;
      case 3 :
	continue;

// 	// no snapping needed
// 	// things are handled such that this condition would not arise
// 	cout<<"\nError : in meshAdapt::initSnapBLNodes()"<<endl;
// 	cout<<"interior node tagged for snapping (with notBLSnapID)"<<endl;
// 	exit(0);
      }

      if(XYZ_distance2(orig_xyz,clsLoc)>gtol*gtol) 
      {
	double *target = new double[3];
	for(int iComp=0; iComp<3; iComp++)
	  target[iComp] = clsLoc[iComp];
	pSnapList->push_back(std::make_pair(vtx,target));
      }
    }
  }
  VIter_delete(viter);

  int numBL = pSnapList->size();
  if(numBL)
    adaptUtil::Info(numBL,"vertices need to be snapped for BL (initial) mesh");

#ifdef MA_PARALLEL
  numBL = snapBLNodes(userLB);
#else
  numBL = snapBLNodes();
#endif

  if( numBL==-1 ) 
    { adaptUtil::Info("Error: snapping return -1 for BL (initial) mesh\n"); exit(0); }
#ifdef DEBUG
  if( numBL )
    adaptUtil::Info(numBL,"vertices are not snapped for BL (initial) mesh");
#endif

  return numBL;
}

#ifdef MA_PARALLEL
int meshAdapt::snapBLNodes(pmMigrationCallbacks &userLB)
#else
int meshAdapt::snapBLNodes()
#endif
{
  int listSize, numBL = 0;
  double tol = M_getTolerance(), gtol;
  double dotP, tar_xyz[3], orig_xyz[3], xyzAtEnds[2][3];
  // normalVector of GC was set in buildAndUpdateBLDataStructures()
  // moveVector is the vector that defines the movement from the current node to target location
  // (kept constant for each node on GC as of now)
  // growthEdgeVector is the vector along the first growth edge from the originating node 
  // (used to determine whether movement is along the growth curve or not)
  // (basically see if dot product with growth direction is pos. or nega.)
  // (normalVector is NOT used as it may be defined using normal vector to model)
  double normalVector[3], moveVector[3], growthEdgeVector[3];
  // target was allocated in meshTemplate::splitLinearEdge() (thats the way it is implemented)
  // and will be used again to supply the target location for the top most node
  // this will be deallocated in snap::freeTarget()
  // targetKeep will be allocated here and will be used to check 
  // if the top most node movement was completely successful or not
  double *target, *targetKeep;

  int updateGCOnModelBdryTag;

  int numRegs, validGC;
  int gcClassificationType, gcClassificationTag;
  pVertex vtx, onode, topNode;
  pRegion rgn;
  pPList vregs;
  vector<pVertex> nodesOnGC;

  // this ID will be used to attach targetKeep
  // this will be also used to check if node was set to move
  pMeshDataId topNodeMoveID = MD_lookupMeshDataId("top node move ID");
  pMeshDataId moveDirID = MD_lookupMeshDataId("move dir ID");
  pMeshDataId moveVectorID = MD_lookupMeshDataId("move vector ID");
  pMeshDataId updateGCOnModelBdryID = MD_lookupMeshDataId("update GC on model bdry. after snap");
/*
#ifdef DEBUG
Mesh_CheckVtxCoordsOnPB(pmesh);
int isValid;
FMDB_Mesh_Verify(pMeshInst, &isValid);
#endif
*/
  int notBLSnapTag;
  VIter viter = M_vertexIter(pmesh);
  while(vtx = VIter_next(viter)) {
    // if( V_isOriginatingNode(vtx) &&
    // other nodes can also have this tag 
    // (like ones created due to layer edge split and not snapped)
    if( EN_getDataInt((pEntity)vtx,notBLSnapID,&notBLSnapTag) ) {

      double clsLoc[3], par[3];
      V_coord(vtx,orig_xyz);
      pGEntity gent = V_whatIn(vtx);
      int genType = GEN_type(gent);
      switch(genType) {
      case 0 :
	// --- osahni
	// do something better
	if(V_isOriginatingNode(vtx)) {
	  // why will this ever happen
	  // why we need to snap nodes of GC on this ONode
	  cout<<"\nError : in meshAdapt::snapBLNodes()"<<endl;
	  cout<<"originating node classified on model vertex is tagged for snapping"<<endl;
	  exit(0);
	}
	else {
	  cout<<"\nError : in meshAdapt::snapBLNodes()"<<endl;
	  cout<<"node (other than ONode) classified on model vertex is tagged for snapping"<<endl;
	  exit(0);
	}
      case 1 :
	GE_closestPoint((pGEdge)gent,orig_xyz,clsLoc,par);
	break;
      case 2 :
	GF_closestPoint((pGFace)gent,orig_xyz,clsLoc,par);
	break;
      case 3 :
	// no snapping needed
	// things are handled such that this condition would not arise
	cout<<"\nError : in meshAdapt::snapBLNodes()"<<endl;
	cout<<"interior node tagged for snapping (with notBLSnapID)"<<endl;
	exit(0);
      }

      gtol = GEN_tolerance(gent);
      if(XYZ_distance2(orig_xyz,clsLoc)>gtol*gtol) {
	switch(genType) {
	case 1 :
	case 2 :
	  pPoint pt = V_point(vtx);
          FMDB_P_setParametricPos (pt , par[0], par[1], par[2]);
          P_setPos(pt, orig_xyz[0],orig_xyz[1],orig_xyz[2]);
//	  pPoint pt=M_createP(pmesh,orig_xyz[0],orig_xyz[1],orig_xyz[2],par,0,gent);
//	  V_setPoint(vtx,pt);
//	  P_delete(point);
	  break;
	}

	target = new double[3];
	for(int iComp=0; iComp<3; iComp++)
	  target[iComp] = clsLoc[iComp];
	pSnapList->push_back(std::make_pair(vtx,target));
      }

      // clear this and if node movement for nodes on GC is not successful node will be tagged again
      EN_deleteData((pEntity)vtx,notBLSnapID);
    }
  }
  VIter_delete(viter);

  std::vector< std::pair<pVertex,double* > >::iterator pairIt;
  for(pairIt=pSnapList->begin();pairIt!=pSnapList->end();++pairIt)
  {
    vtx = (*pairIt).first;
    target = (*pairIt).second;

    /// Remove target location from the detached node, it will be updated in unifySnapListBL() with the correct target location.
    if (EN_levelInBL(vtx) < 0)
    {
      pSnap->freeTarget(vtx);
      continue;
    }

    if(!EN_isBLEntity((pEntity)vtx)) {
      cout<<"\nError : in meshAdapt::snapBLNodes()"<<endl;
      cout<<"encountered a non-BL node..."<<endl;
      exit(0);
    }

    // first check if vertex is originating node or not
    // as V_totNumLayers() will fail for non-originating node
    if(!V_isOriginatingNode(vtx)) // || !V_totNumLayers(vtx) )
    {
      // could be due to split of layer edge classified on model bdry
      // just try to move it by updating nodes on GC
      onode = V_getOriginatingNode(vtx);

      BL_getGrowthCurveNodes(onode, nodesOnGC);
      listSize = nodesOnGC.size();
      topNode = nodesOnGC[listSize-1];

     if( EN_getDataPtr((pEntity)topNode,topNodeMoveID,(void **)&targetKeep) )
       continue;

      GC_getClassification(nodesOnGC, gcClassificationType, gcClassificationTag);
      if(gcClassificationType < 3) {
	// this should work out well for gc on a planar model face
	pVertex vtxOnGC = updateGCOnModelBdry(nodesOnGC);
	if(!vtxOnGC) {
	  // update GC on model bdry. is successful
	  delete [] target;
	  continue;	
	}
	else {
	  if(vtxOnGC==topNode) {

	    // top most node
	    V_coord(topNode,orig_xyz);

	    double clsLoc[3], par[3];
	    pGEntity gent = V_whatIn(topNode);
	    int genType = GEN_type(gent);
	    switch(genType) {
	    case 0 :
	      // why we need to snap a node classified on model vertex
	      cout<<"\nError in meshAdapt::snapBLNodes()"<<endl;
	      cout<<"top node classified on model vertex is tagged for snapping"<<endl;
	      exit(0);
	    case 1 :
	      GE_closestPoint((pGEdge)gent,orig_xyz,clsLoc,par);
	      break;
	    case 2 :
	      GF_closestPoint((pGFace)gent,orig_xyz,clsLoc,par);
	      break;
	    case 3 :
	      // this should not happen (i.e., partial GC on model bdry.)
	      cout<<"\nError : in meshAdapt::snapBLNodes()"<<endl;
	      cout<<"partial GC on model bdry. (top most node of GC that is on model bdry. is in interior)"<<endl;
	      exit(0);
	    }

	    switch(genType) {
	    case 1 :
	    case 2 :
	      pPoint pt = V_point(topNode);
              FMDB_P_setParametricPos (pt , par[0], par[1], par[2]);
              P_setPos(pt, orig_xyz[0],orig_xyz[1],orig_xyz[2]);
//	      pPoint pt=M_createP(pmesh,orig_xyz[0],orig_xyz[1],orig_xyz[2],par,0,gent);
//	      V_setPoint(topNode,pt);
//	      P_delete(point);
	      break;
	    }

	    targetKeep = new double[3];
	    for(int iComp=0; iComp<3; iComp++) {
	      target[iComp] = clsLoc[iComp];
	      targetKeep[iComp] = target[iComp];
	    }
	    EN_attachDataPtr((pEntity)topNode,topNodeMoveID,(void *)targetKeep);

	    pSnap->append(topNode,target);
	    continue;
	  }
	  else {
	    numBL++;
	  
	    if(V_whatInType(vtxOnGC)==3) {
	      cout<<"\nError : in meshAdapt::snapBLNodes()"<<endl;
	      cout<<"partial GC on model bdry. (mid-level node of GC that is on model bdry. is in interior)"<<endl;
	      exit(0);
	    }

	    // assuming this vtx is on model bdry. otherwise it would
	    // not be taken next time in snapBLNodes()
	    // (i.e., partial GC on model bdry. is NOT supported)
	    EN_attachDataInt((pEntity)vtxOnGC,notBLSnapID,1);

	    delete [] target;
	    continue;
	  }
	}
      }
      else {
	cout<<"\nError : in meshAdapt::snapBLNodes()"<<endl;
	cout<<"encountered a non-originating node tagged for snapping that is classified on interior GC..."<<endl;
	exit(0);
      }
    }

    onode = vtx;
//    GC_getNormalVector(onode, normalVector);

    BL_getGrowthCurveNodes(onode, nodesOnGC);

    if (nodesOnGC.size() == 1)
    {
      pSnap->append(onode, target);
      continue;
    }

    listSize = nodesOnGC.size();
    topNode = nodesOnGC[listSize-1];

    // determine the move vector
    // vtx must be originating node
    // moveVector must be determined before 
    // calling updateGCOnModelBdry() for GC on model bdry.
    V_coord(onode,xyzAtEnds[0]);
    diffVt(target,xyzAtEnds[0],moveVector);

    GC_getClassification(nodesOnGC, gcClassificationType, gcClassificationTag);
    if(gcClassificationType < 3)
      EN_attachDataInt((pEntity)onode,updateGCOnModelBdryID,1);

    V_coord(nodesOnGC[1],xyzAtEnds[1]);
    diffVt(xyzAtEnds[1],xyzAtEnds[0],growthEdgeVector);    
    dotP = dotProd(growthEdgeVector,moveVector);

    double orig_topxyz[3];
    V_coord(topNode,orig_topxyz);

    addVt(orig_topxyz,moveVector,tar_xyz);
    adaptUtil::move_vertex(topNode,tar_xyz);

    validGC = 1;
    // check if movement creates any invalid elements at all levels
    if(dotP<0.) {

      // excluding top most node
      // bottom to top -- for dotP<0.
      validGC = 1;
      int nodesMoved = listSize-1;
      for(int iNode=0; iNode<listSize-1; iNode++) {
	vtx = nodesOnGC[iNode];

	V_coord(vtx,orig_xyz);

	addVt(orig_xyz,moveVector,tar_xyz);
	adaptUtil::move_vertex(vtx,tar_xyz);

	vregs = V_regions(vtx);
	numRegs = PList_size(vregs);
	for(int iRgn=0; iRgn<numRegs; iRgn++) {
	  rgn = (pRegion)PList_item(vregs,iRgn);
	  // from bottom to top check BL regions below current node
	  if(EN_levelInBL((pRegion)rgn)!=iNode)
	    continue;

	  if(R_Volume2(rgn)<tol) {
	    validGC = 0;
	    nodesMoved = iNode;
	    adaptUtil::move_vertex(vtx,orig_xyz);
	    break;
	  }
	}
	PList_delete(vregs);

	if(!validGC)
	  break;
      }

      // if validGC is true then nodesMoved = "listSize-1"
      // else nodesMoved will be iNode (and iNode was moved back in break)
      for(int iNode=0; iNode<nodesMoved; iNode++) {
	vtx = nodesOnGC[iNode];
	V_coord(vtx,tar_xyz);
	diffVt(tar_xyz,moveVector,orig_xyz);
	adaptUtil::move_vertex(vtx,orig_xyz);
      }
    }
    else {

      // excluding top most node
      // top to bottom -- for dotP>=0.
      validGC = 1;
      int nodesMoved = -1;
      for(int iNode=listSize-2; iNode>-1; iNode--) {
	vtx = nodesOnGC[iNode];

	V_coord(vtx,orig_xyz);

	addVt(orig_xyz,moveVector,tar_xyz);
	adaptUtil::move_vertex(vtx,tar_xyz);

	vregs = V_regions(vtx);
	numRegs = PList_size(vregs);
	for(int iRgn=0; iRgn<numRegs; iRgn++) {
	  rgn = (pRegion)PList_item(vregs,iRgn);
	  // from top to bottom check BL regions above current node
	  if(EN_levelInBL((pRegion)rgn)!=iNode+1)
	    continue;

	  if(R_Volume2(rgn)<tol) {
	    validGC = 0;
	    nodesMoved = iNode;
	    adaptUtil::move_vertex(vtx,orig_xyz);
	    break;
	  }
	}
	PList_delete(vregs);

	if(!validGC)
	  break;
      }

      // if validGC is true then nodesMoved = "-1"
      // else nodesMoved will be iNode (and iNode was moved back in break)
      for(int iNode=listSize-2; iNode>nodesMoved; iNode--) {
	vtx = nodesOnGC[iNode];
	V_coord(vtx,tar_xyz);
	diffVt(tar_xyz,moveVector,orig_xyz);
	adaptUtil::move_vertex(vtx,orig_xyz);
      }

      // for this case move the lower level nodes later
      EN_attachDataInt((pEntity)onode,moveDirID,1);
    }

    // move back the top most node
    adaptUtil::move_vertex(topNode,orig_topxyz);

    // do not apply movement if it results in invalid elements on any level
    if(!validGC) {
      numBL++;
      delete [] target;

      EN_attachDataInt((pEntity)onode,notBLSnapID,1);
      continue;
    }

    // for dotP<0. move the lower level nodes now
    if(dotP<0.) {
      for(int iNode=0; iNode<listSize-1; iNode++) {
	vtx = nodesOnGC[iNode];
	V_coord(vtx,orig_xyz);
	addVt(orig_xyz,moveVector,tar_xyz);
	adaptUtil::move_vertex(vtx,tar_xyz,CB_move,userData_CB_move);
      }
    }

    // attach move vector to all originating nodes of interior GCs
    // this will be used in case node movement 
    // of the top most node is not completely successful
    double *moveVectorPtr = new double[3];
    for(int iComp=0; iComp<3; iComp++)
      moveVectorPtr[iComp] = moveVector[iComp];
    EN_attachDataPtr((pEntity)onode,moveVectorID,moveVectorPtr);

    // top most node
    V_coord(topNode,orig_xyz);
    // target was pre-allocated (from meshTemplate::splitLinearEdge())
    // update it for the top most node target location
    addVt(orig_xyz,moveVector,target);

    targetKeep = new double[3];
    for(int iComp=0; iComp<3; iComp++)
      targetKeep[iComp] = target[iComp];
    EN_attachDataPtr((pEntity)topNode,topNodeMoveID,(void *)targetKeep);

    pSnap->append(topNode,target);
  }
/*
#ifdef DEBUG
Mesh_CheckVtxCoordsOnPB(pmesh);
FMDB_Mesh_Verify(pMeshInst, &isValid);
#endif
*/
  pSnap->setBLAdapt(2);
  pSnap->setCounterMax(1);
  pSnap->setDefaultMaxLenSq();

#ifdef DEBUG
  cout<<"\n entering snapping procedure to snap BL nodes..."<<endl;
#endif

#ifdef MA_PARALLEL
  int numBLSnapRun = pSnap->run(userLB);
#else
  int numBLSnapRun = pSnap->run();
#endif

  if( numBLSnapRun==-1 ) 
    { adaptUtil::Info("Error: meshAdapt::snapBLNodes() return -1 for BL mesh\n"); exit(0); }
#ifdef DEBUG
  if( numBLSnapRun )
    adaptUtil::Info(numBLSnapRun,"nodes not snapped for BL mesh");
#endif

#ifdef DEBUG
  cout<<"\n leaving snapping procedure to snap BL nodes..."<<endl;
#endif

  pSnap->setBLAdapt(0);
  pSnap->setDefaultCounterMax();
  pSnap->setDefaultMaxLenSq();

/*
#ifdef DEBUG
Mesh_CheckVtxCoordsOnPB(pmesh);
FMDB_Mesh_Verify(pMeshInst, &isValid);
#endif
*/
  int moveDirTag;
  double *moveVectorPtr;
  double xyz[3];
  VIter vit = M_vertexIter(pmesh);

  while( vtx = VIter_next(vit))
  {
    if( EN_getDataPtr((pEntity)vtx,topNodeMoveID,(void **)&targetKeep) )
    {
      if (EN_levelInBL(vtx) < 0)
      {
        EN_deleteData((pEntity)vtx,topNodeMoveID);
        delete [] targetKeep;
        continue;
      }

      topNode = vtx;
      V_coord(topNode,xyz);

      onode = V_getOriginatingNode(topNode);

      double vec[3];
      diffVt(xyz,targetKeep,vec);
      pGEntity gent=V_whatIn(topNode);
      gtol=GEN_tolerance(gent);      
      if(dotProd(vec,vec)<=gtol*gtol) {

	if(EN_getDataInt((pEntity)onode,moveDirID,&moveDirTag)) {
	  EN_deleteData((pEntity)onode,moveDirID);

	  // this was attached to all originating nodes of interior GCs
	  EN_getDataPtr((pEntity)onode,moveVectorID,(void **)&moveVectorPtr);

	  BL_getGrowthCurveNodes(onode, nodesOnGC);
	  listSize = nodesOnGC.size();

	  // if top most node movement was completely successful

	  // excluding top most node
	  // (validity for nodes was checked before snapping)
	  // in reverse order
	  for(int iNode=listSize-2; iNode>=0; iNode--) {
	    vtx = nodesOnGC[iNode];

	    V_coord(vtx,orig_xyz);

	    addVt(orig_xyz,moveVectorPtr,tar_xyz);
	    adaptUtil::move_vertex(vtx,tar_xyz);

	    int valid = 1;
	    vregs = V_regions(vtx);
	    numRegs = PList_size(vregs);
	    for(int iRgn=0; iRgn<numRegs; iRgn++) {
	      rgn = (pRegion)PList_item(vregs,iRgn);
	      // from top to bottom check BL regions above current node
	      if(EN_levelInBL((pRegion)rgn)!=iNode+1)
		continue;

	      if(R_Volume2(rgn)<tol) {
		valid = 0;
		adaptUtil::move_vertex(vtx,orig_xyz);
#ifdef DEBUG
		cout<<"\nWARNING in meshAdapt::snapBLNodes()"<<endl;
		cout<<"validity checks were done before snapping for all level nodes [iNode="<<iNode<<",iRgn="<<iRgn<<"]"<<endl;
#endif
//		exit(0);

		break;
	      }
	    }
	    PList_delete(vregs);

	    if(valid) {
	      adaptUtil::move_vertex(vtx,orig_xyz);
	      adaptUtil::move_vertex(vtx,tar_xyz,CB_move,userData_CB_move);
	    }
	  }
	}

	// this was attached to all originating nodes of interior GCs
	if(EN_getDataPtr((pEntity)onode,moveVectorID,(void **)&moveVectorPtr)) {
	  delete [] moveVectorPtr;
	  EN_deleteData((pEntity)onode,moveVectorID);
	}
      }
      else { 
	// top most node movement was NOT completely successful
	// (numBLSnapRun is one returned from pSnap->run())
	numBL++;

	// this was attached to all originating nodes on interior GCs
	if(EN_getDataPtr((pEntity)onode,moveVectorID,(void **)&moveVectorPtr)) {
	  // --- osahni
	  // top node movement NOT completely successful
	  // move all the nodes on GC by amount top most node moved or initial location
	  // whichever is close to model bdry., i.e., snap location for originating node
	  // and tag the originating node for next time


	  // --- osahni 
	  // RIGHT NOW JUST MOVE THE LOWER LEVEL NODES OF GC BY AMOUNT
	  // TOP MOST NODE MOVED AS IT MIGHT NOT BE POSSIBLE TO MOVE THE
	  // TOP NODE BACK TO INITIAL LOCATION
	  
	  double partialMoveVector[3];
	  V_coord(topNode,xyz);

	  if(EN_getDataInt((pEntity)onode,moveDirID,&moveDirTag)) {
	    // get the orig. position of top node
	    diffVt(targetKeep,moveVectorPtr,orig_xyz);
	    // get the partial move vector
	    // move the lower level nodes by this amount
	    diffVt(xyz,orig_xyz,partialMoveVector);

	    BL_getGrowthCurveNodes(onode, nodesOnGC);
	    listSize = nodesOnGC.size();

	    // excluding top most node
	    // (validity for nodes was checked before snapping)
	    // in reverse order
	    for(int iNode=listSize-2; iNode>=0; iNode--) {
	      vtx = nodesOnGC[iNode];

	      V_coord(vtx,orig_xyz);

	      addVt(orig_xyz,partialMoveVector,tar_xyz);
	      adaptUtil::move_vertex(vtx,tar_xyz);

	      int valid = 1;
	      vregs = V_regions(vtx);
	      numRegs = PList_size(vregs);
	      for(int iRgn=0; iRgn<numRegs; iRgn++) {
		rgn = (pRegion)PList_item(vregs,iRgn);
		// from top to bottom check BL regions above current node
		if(EN_levelInBL((pRegion)rgn)!=iNode+1)
		  continue;

		if(R_Volume2(rgn)<tol) {
		  valid = 0;
		  adaptUtil::move_vertex(vtx,orig_xyz);
#ifdef DEBUG
		  cout<<"\nWARNING in meshAdapt::snapBLNodes()"<<endl;
		  cout<<"validity checks were done before snapping for all lower level nodes [iNode="<<iNode<<",iRgn="<<iRgn<<"] (partial move vector for case of movement along growth curve)"<<endl;
#endif
//		  exit(0);

		  break;
		}
	      }
	      PList_delete(vregs);

	      if(valid) {
		adaptUtil::move_vertex(vtx,orig_xyz);
		adaptUtil::move_vertex(vtx,tar_xyz,CB_move,userData_CB_move);
	      }
	    }
	  }
	  else {
	    // get the partial move vector (from targetKeep to current location)
	    // move back the lower level nodes by this amount
	    diffVt(xyz,targetKeep,partialMoveVector);

	    BL_getGrowthCurveNodes(onode, nodesOnGC);
	    listSize = nodesOnGC.size();

	    // excluding top most node
	    // (validity for nodes was checked before snapping)
	    for(int iNode=0; iNode<listSize-1; iNode++) {
	      vtx = nodesOnGC[iNode];

	      V_coord(vtx,orig_xyz);

	      addVt(orig_xyz,partialMoveVector,tar_xyz);
	      adaptUtil::move_vertex(vtx,tar_xyz);

	      int valid = 1;
	      vregs = V_regions(vtx);
	      numRegs = PList_size(vregs);
	      for(int iRgn=0; iRgn<numRegs; iRgn++) {
		rgn = (pRegion)PList_item(vregs,iRgn);
		// from bottom to top check BL regions below current node
		if(EN_levelInBL((pRegion)rgn)!=iNode)
		  continue;

		if(R_Volume2(rgn)<tol) {
		  valid = 0;
		  adaptUtil::move_vertex(vtx,orig_xyz);
#ifdef DEBUG
		  cout<<"\nWARNING in meshAdapt::snapBLNodes()"<<endl;
		  cout<<"validity checks were done before snapping for all lower level nodes [iNode="<<iNode<<",iRgn="<<iRgn<<"] (partial move vector for case of movement away from growth curve)"<<endl;
#endif
//		  exit(0);

		  break;
		}
	      }
	      PList_delete(vregs);

	      if(valid) {
		adaptUtil::move_vertex(vtx,orig_xyz);
		adaptUtil::move_vertex(vtx,tar_xyz,CB_move,userData_CB_move);
	      }
	    }
	  }

	  delete [] moveVectorPtr;
	  EN_deleteData((pEntity)onode,moveVectorID);

	  // tag the originating node for next time
	  EN_attachDataInt((pEntity)onode,
			   notBLSnapID,1);

	  V_coord(onode,orig_xyz);

	  double clsLoc[3], par[3];
	  pGEntity gent = V_whatIn(onode);
	  int genType = GEN_type(gent);
	  switch(genType) {
	  case 0 :
	    // why we need to snap a node classified on model vertex
	    cout<<"\nError in meshAdapt::snapBLNodes()"<<endl;
	    cout<<"originating node classified on model vertex is tagged for snapping"<<endl;
	    exit(0);
	  case 1 :
	    GE_closestPoint((pGEdge)gent,orig_xyz,clsLoc,par);
	    break;
	  case 2 :
	    GF_closestPoint((pGFace)gent,orig_xyz,clsLoc,par);
	    break;
	  case 3 :
	    // this should not happen (i.e., onode inside the model)
	    cout<<"\nError : in meshAdapt::snapBLNodes()"<<endl;
	    cout<<"originating node is not classified on model bdry."<<endl;
	    exit(0);
	  }

	  switch(genType) {
	  case 1 :
	  case 2 :
	    pPoint pt = V_point(onode);
            FMDB_P_setParametricPos (pt , par[0], par[1], par[2]);
            P_setPos(pt, orig_xyz[0],orig_xyz[1],orig_xyz[2]);
//	    pPoint pt=M_createP(pmesh,orig_xyz[0],orig_xyz[1],orig_xyz[2],par,0,gent);
//	    V_setPoint(onode,pt);
//	    P_delete(point);
	    break;
	  }
	}
	else {
	  // probably this would happen when just top node 
	  // of GC on model bdry. needs to be moved
	  EN_attachDataInt((pEntity)topNode,notBLSnapID,1);
	}

	// this was attached to originating nodes with dotP>=0.
	// that is node movement due to snapping is along GC
	if(EN_getDataInt((pEntity)onode,moveDirID,&moveDirTag))
	  EN_deleteData((pEntity)onode,moveDirID);
      }

      delete [] targetKeep;
      EN_deleteData((pEntity)topNode,topNodeMoveID);
    }
  }

  VIter_reset(vit);
  while(vtx = VIter_next(vit)) {
    if( V_isOriginatingNode(vtx) &&
	EN_getDataInt((pEntity)vtx,updateGCOnModelBdryID,&updateGCOnModelBdryTag) ) {

      EN_deleteData((pEntity)vtx,updateGCOnModelBdryID);

      BL_getGrowthCurveNodes(vtx, nodesOnGC);
      // if tagged with updateGCOnModelBdryID then it is likely 
      // that GC is classified on model bdry.
      GC_getClassification(nodesOnGC, gcClassificationType, gcClassificationTag);
      if(gcClassificationType < 3)
      {
	if(updateGCOnModelBdry(nodesOnGC)) {
#ifdef DEBUG
	  cout<<"\n WARNING in meshAdapt::snapBLNodes()..."<<endl;
	  cout<<" GC on model bdry. not completely updated\n"<<endl;
#endif
	}
      }
    }
  }
/*
  MD_deleteMeshDataId(updateGCOnModelBdryID);
  MD_deleteMeshDataId(topNodeMoveID);
  MD_deleteMeshDataId(moveDirID);
  MD_deleteMeshDataId(moveVectorID);
*/

  /// INEFFICIENT! Adjust parametric coordinates of hanging from their BLs nodes on a model boundary. We need this becaus the BL nodes adjusted their parametric coordinates during snapping routine and updateOnModelBdry(), but hanging nodes are not notified about that. We should know parametrics a-priory and update it different way. Now everything is adjusted through closestPoint() which is very slow. Plus, here we traverse all the vertices on the model boundary.
  VIter_reset(vit);
  while(vtx = VIter_next(vit))
  {
    int iGeomType = V_whatInType(vtx);
    if (EN_levelInBL(vtx) < 0 && iGeomType < 3)
    {
      double par[]={0.0,0.0,0.0};
      double ori[3], coords[3];
      V_coord(vtx, ori);
      pGEntity gent = V_whatIn(vtx);
      gtol = GEN_tolerance(gent);
      switch(GEN_type(gent))
      {
        case 1 :
          GE_closestPoint((pGEdge)gent,ori,coords,par);
          break;
        case 2 :
          GF_closestPoint((pGFace)gent,ori,coords,par);
          break;
      }

      if( XYZ_distance2(coords,ori) <= gtol*gtol ) 
      {
        /// Take care of the parametric coordinates and the real ones
        pPoint pt = V_point(vtx);
        FMDB_P_setParametricPos (pt , par[0], par[1], par[2]);
      }
    }
  }
  VIter_delete(vit);

  // need to clear the list
  // setSnap() is not used in this routine
  pSnapList->clear();

  return numBL;
}

void M_checkForMesh(pMesh mesh) {
  pRegion rgn;
  RIter rit = M_regionIter(mesh);
  while(rgn = RIter_next(rit)) {
    if(!R_checkFlat(rgn))  
      int tt = 1;
  }
  RIter_delete(rit);
}

int M_checkForEdgeInMesh(pMesh mesh) {
  int err = 0;
  pEdge edge;
  EIter eit = M_edgeIter(mesh);
  while(edge = EIter_next(eit)) {
    if(E_whatInType(edge)==Gregion) {
      int numFaces = E_numFaces(edge), bdryFaces = 0;
      for(int iFace=0; iFace<numFaces; iFace++) {
        if(F_whatInType(E_face(edge,iFace))==Gface)
          bdryFaces++;
      }
      if(bdryFaces>0) {
        int tt = 1;
        err = 1;
        printf("\n WARNING : edge classification incorrect\n");
      }
    }
  }
  EIter_delete(eit);
  return err;
}

void M_checkPointforMesh1(pMesh mesh) {

  pFace face;
  FIter fit = M_faceIter(mesh);
  while(face = FIter_next(fit)) {
    /* if(face==(pFace)(0x2fa2290)) {
      cout<<"\n\nSTOP - face 1 found"<<endl;
      if( !F_region(face,0) ||
	  !F_region(face,1) )
	cout<<"STOP 1 - NO 2 regions"<<endl;
    }

    if(face==(pFace)(0x302b9ec)) {
      cout<<"\n\nSTOP - face 2 found"<<endl;
      if( !F_region(face,0) || 
	  !F_region(face,1) )
	cout<<"STOP 2 - NO 2 regions"<<endl;
    } */

    /* if(F_whatInType(face)==Gface) {
      int n=0;
      for(int iFRgn=0; iFRgn<2; iFRgn++) {
        if(F_region(face,iFRgn)) {
          if(!GF_region((pGFace)F_whatIn(face),iFRgn))
            int tt = 1;
          n++;
        }
      }
    } */

  }
  FIter_delete(fit);

  int vtxCount = 0;
  double xyz_check[2][3] = {{-0.45383, 3.50633, 5.99725}, {-0.50831, 3.45182, 6.04161}}, check_xyz[3];
  pVertex vtx, verts[2] = {0,0};
  VIter vit = M_vertexIter(mesh);
  while(vtx = VIter_next(vit)) {
    V_coord(vtx,check_xyz);
    if(XYZ_distance2(xyz_check[0],check_xyz)<1.e-4 ||
       XYZ_distance2(xyz_check[1],check_xyz)<1.e-4) {
      verts[vtxCount] = vtx;
      vtxCount++;
    }
  }
  VIter_delete(vit);

  if(vtxCount>2)
    cout<<"\nOOPS : more than two verts. found\n"<<endl;

  pEdge edge = 0;
  if(vtxCount==2)
    edge = E_exists(verts[0],verts[1]);

  if(edge)
    int tt = 1;
}
