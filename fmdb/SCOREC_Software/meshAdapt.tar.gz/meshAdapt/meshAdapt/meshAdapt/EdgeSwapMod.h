/*
  a vertex motion followed by an edge swap
  (if the mesh vertex is set to NULL, the vertex motion is turned off)
*/

#ifndef _H_EdgeSwapMod
#define _H_EdgeSwapMod

#include "LocMeshMod.h"
#ifdef CURVE
#include "curveUtil.h"
#include "curveMesh.h"
#endif

class edgeSwapMod : public locMeshMod
{
 public:
  edgeSwapMod(const edgeSwapMod &);
  edgeSwapMod(pMesh p, pSField mf, MeanRatio *m, evalResults *r)
    : locMeshMod(p, mf, m, r),  edge(0), conf(-1), n(-1)  {mesh=p;}
  edgeSwapMod(pMesh, pSField mf, MeanRatio *, 
	      evalResults *, pVertex v, double *t);
  ~edgeSwapMod() {}


  /* the common local modification interface */
  virtual int topoCheck();
  virtual int geomCheck();
  virtual int sizeCheck();
  virtual void getAffectedRgns(pPList *);
  virtual int apply();
  virtual int apply(pPList *);
  virtual modType type() { return ESWAP; }


  /* specific function for edge swap */
  void  setSwapEdge(pEdge ent) { edge=ent; results->reset(); conf=-1; n=-1; }
  pEdge getSwapEdge() { return edge; }
  int   getCfg() { return conf; }
  int geomCheck(pVertex, pVertex);

#ifdef CURVE
  /* curved edge swap tests */ // Q.K.L.,  Sep 13, 2010
  void setCfg(int i) {conf=i;}
  void setMesh(pMesh m){mesh=m;}
//  int setEntities();
//  void deleteOldEntities();
//  void createNewEntities();

  void getBestMdpt(double *xyz) { xyz[0]=mid_xyz[0]; xyz[1]=mid_xyz[1]; xyz[2]=mid_xyz[2];}
  void setBestMdpt(double *xyz) { mid_xyz[0]=xyz[0]; mid_xyz[1] = xyz[1]; mid_xyz[2]=xyz[2];}
  bool isMiddlePtComputed() {return mid_xyz_evaluated;}

#endif //CURVE

  protected:

  /* driving data */
  pEdge edge;          // the edge to be swapped
  /* internal data  */
  int conf;            // set after topoCheck()
  int n;
#ifdef CURVE
  double mid_xyz[3];
  bool mid_xyz_evaluated;
#endif /* CURVE */
  int E_swpNewEdges(double *, double *);
  int geomCheck2D();

};


inline edgeSwapMod::edgeSwapMod(const edgeSwapMod &x):
  locMeshMod(x.mesh, x.pSizeField, x.shpMeasure, x.results)
{
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;    
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;
  CB_move=x.CB_move;
  userData_CB_move=x.userData_CB_move;

  edge=x.edge;
  conf=x.conf;
  n=x.n;

  vertMv=x.vertMv;
  target[0]=x.target[0];
  target[1]=x.target[1];
  target[2]=x.target[2];
#ifdef CURVE
  quadratic = x.quadratic; // May 1, 2010, QLU
#endif // CURVE
}


inline edgeSwapMod::edgeSwapMod(pMesh p, pSField mf, MeanRatio *m, 
				evalResults *r, 
				pVertex v, double *t)
  : locMeshMod(p, mf, m, r),  edge(0), conf(-1), n(-1) 
{
  vertMv=v;
  target[0]=t[0];
  target[1]=t[1];
  target[2]=t[2];
#ifdef CURVE
  quadratic = false; // May 1, 2010, QLU
#endif // CURVE
}

#endif
