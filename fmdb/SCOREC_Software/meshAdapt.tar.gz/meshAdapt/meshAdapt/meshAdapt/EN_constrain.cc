/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC

  Project  : Mesh Tools
  Author(s): Rao Garimella
  Creation : Feb., 95
  Modifi.  : Pascal J. Frey / Aug., 95
  Function :
    mesh optimization: Check if a particular mesh modification operation
    is not allowed by checking the appropriate bit field of integer
    data on entity and the model entity it is classified on.
-------------------------------------------------------------------------*/
#include <stdio.h>
#include "FMDB.h"
#include "fromMeshTools.h"

int globalCst=0;
extern MarkID MT_cnst;

void EN_constrain(opType i,pEntity e) 
{
  unsigned int d = 0;

  if (!e)
    /* apply global constraint here. */
    globalCst |= (1<<i);
  else {
    d = EN_mark(e,MT_cnst);
    d |= 1<<i;
    EN_setMark(e,MT_cnst,d);
  }
}

void EN_constrainAll(pEntity e) {
  static unsigned int all = (1<<SWAP | 1<<COLAPS | 1<<SPLIT | 1<<MOVE | 1<<DELETE);
  if (!e)
    /* apply global constrain here */
    globalCst = 1<<SWAP | 1<<COLAPS | 1<<SPLIT | 1<<MOVE | 1<<DELETE;
  else {
    EN_setMark(e,MT_cnst,all);
  }
}

void GEN_constrain(opType i,pGEntity e) {
  int d = 0;

  if (!e)
    /* apply global constraint here. */
    globalCst |= (1<<i);
  else {
    if(!GEN_dataI(e,"cnst",&d))
      d = 0;
    if (d)
      GEN_modifyDataI(e,"cnst",(d | 1<<i));
    else
      GEN_attachDataI(e,"cnst",(1<<i));
  }
}

void GEN_constrainAll(pGEntity e) {
  static int all = (1<<SWAP | 1<<COLAPS | 1<<SPLIT | 1<<MOVE | 1<<DELETE);
  if (!e)
    /* apply global constrain here */
    globalCst = 1<<SWAP | 1<<COLAPS | 1<<SPLIT | 1<<MOVE | 1<<DELETE;
  else {
    int d = 0;
    if (GEN_dataI(e,"cnst", &d))
      GEN_modifyDataI(e,"cnst",all);
    else
      GEN_attachDataI(e,"cnst",all);
  }
}

