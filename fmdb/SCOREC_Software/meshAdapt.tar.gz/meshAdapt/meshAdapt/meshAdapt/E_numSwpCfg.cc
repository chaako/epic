/*-------------------------------------------------------------------------
  Scientific Computation Research Center, RPI, Troy NY
  (C) Copyright 1995, RPI-SCOREC
 
  Project   : Mesh Tools
  Author(s) : Pascal J. Frey, Rao Garimella
  Creation  : Apr 95
  Modifi.   : de Cougny (ifdef MPI)
  Function  :
    Return number of possible swap configurations for a given edge
-------------------------------------------------------------------------*/
#include <stdio.h>
#include "FMDB.h"
#include "Macros.h"
#include "MeshTools.h"
#include "Defines.h"
#include "Eswap.h"
#include "modeler.h"
#include "fromMeshTools.h"

#define FALSE 0
#define TRUE  1

#undef MPI
#ifdef MPI
 #include "mpi.h"
 #include "pmshops.h"
 #include <stdlib.h>
#endif

SwapConfig sc;

void (*swapFct[5])(SwapConfig *) = { 
  E_swp3_3, E_swp3_4, E_swp3_5, E_swp3_6, E_swp3_7 } ; 


int E_numSwpCfg(pEdge edge) {
  pGEntity mface, greg=0;
  pRegion  region,cur_region,nxt_region;
  pFace    face, face_2,cur_face,nxt_face;
  pEdge    edge_2, edge_3, gfedge;
  pPList   eregs;
  pVertex  verts[4], gfverts[2], vtx;
  int      etype = E_whatInType(edge);
  int      i,j,k,n=0,nbr=0,numFaces, numEdges, dir, dir_2, nonManif=0, ncfg=0;
  int      found = 0, count = 0, c, t;
  void     *temp = 0;
  pVertex e_verts[2];
  int link_nbr;
  int *ngb_pids[2];
  int PInumtids;
  int PImytid;
  int link_nbrs[2];
  int ngb_pid;
  pVertex ngb_vert;
  int status;

  if (etype == Gedge)
    return(0) ;

  /* Check if the edge is on a non-manifold face - need to manage */
  /* data differently in that case                                */
  if ( etype == Gface ) {
    /* check if model face is used by less/more than one model
       region (non-manifold)                              */
    mface = E_whatIn(edge) ;
    if (GF_region((pGFace)mface,0)) n++;
    if (GF_region((pGFace)mface,1)) n++;
    if (n == 0) 
      return(-2) ;
    else if (n == 2)
      nonManif = 1;
  }

  #ifdef MPI
  /*
  Cannot do if edge on part. bdry
  */

  link_nbr= pmdb_en_num_iplinks(edge);
  if ( link_nbr > 0 ) {
     return(0);
  }
  #endif

  /* get 'face' that connects to edge. if one classified Tface, take that
     one, otherwise take any (e.g. last one) */
  
  numFaces = E_numFaces(edge) ;
  for ( i= 0 ; i < numFaces ; i++ ) {
    face = E_face(edge,i) ;
    if ( F_whatInType(face) == Gface )
      break ;
  }

  /* keep track of 0 region connected to face */
  if ( !(region = F_region(face,0)) ) {
    region = F_region(face,1) ;
    if ( !region ) {
      MT_ErrorHandler("Invalid or incomplete tet mesh?","E_numSwpCfg",WARN);
      return 0;
    }
  }

  /* determine right away which of the 2 end-vertices of 'edge' is the top
     (bottom) w/r to the orientation associated polygon */

  verts[0] = F_edOpVt(face,edge) ;
  verts[1] = R_fcOpVt(region,face) ;
  verts[2] = E_vertex(edge,0) ;
  verts[3] = E_vertex(edge,1) ;

  /* get 'edge_2' connecting verts[0], verts[1] */
  edge_2 = E_exists(verts[0],verts[1]) ;

  /* Get the face which is adjacent to the "face" along the
     vertex "verts[0]" for the region */

  numEdges = F_numEdges(face) ;

  for ( i = 0 ; i < numEdges ; i++ )
    if ( (edge_3 = F_edge(face,i)) != edge ) {
      face_2 = E_otherFace(edge_3,face,region) ;
      if ( F_edOpVt(face_2,edge_2) == verts[2] )
	break ;
    }

  if ( !face_2 ) {
    MT_ErrorHandler("missing face","E_getSwpVrt",WARN) ;
    return 0;
  }

  /* get how the region use that face */
  dir = R_dirUsingFace(region,face_2) ;

  /* get how the face use the segment verts[0]-verts[1] */
  dir_2 = F_dirUsingEdge(face_2,edge_2) ;

  if ( E_vertex(edge_2,0) != verts[0] )
        dir_2 = 1 - dir_2 ;

  /* Now we have got all the information necessary for 
     determining the top and the bottom vertex, return
     the vertices */

  sc.top_vert= verts[2] ;
  sc.bot_vert= verts[3] ;
  if ( dir_2 != dir )  {
    sc.top_vert= verts[3];
    sc.bot_vert= verts[2];
  }

  /* Start at one of the face connected to the edge being
     swapped, get the opposite vertex for the face,
     1) Include this vertex in the list of vertices for the face
     2) Get the other face and the region from the given face
     3) Break out of the loop if we hit the start region or NULL
     */

  /* Also, for the case where the edge is classified on a model face   */
  /* store the two vertices opposite to edge and classified on closure */
  /* of model face - will be useful for the non-manifold case          */

  gfverts[0] = verts[0]; /* Already have this from before */

  nbr = 0 ;
  cur_face = face ;
  cur_region = region ;
  while ( 1 ) {
    if ((cur_face != face) && (F_whatInType(cur_face) == Gface))
      gfverts[1] = F_edOpVt(cur_face,edge);

    if ( nbr > MAX_POLVERTS ) {
      MT_ErrorHandler("too many vertices","E_getSwpVrt",WARN) ;
      return(0) ;
    }
    sc.pverts[nbr] = F_edOpVt(cur_face,edge) ;
    nbr++ ;
    if ( !cur_region ) 
      break;

    nxt_face = E_otherFace(edge,cur_face,cur_region) ;
    /* get the next region */

    nxt_region = F_region(nxt_face,0) ;
    if ( !nxt_region || nxt_region == cur_region ) {
      nxt_region = F_region(nxt_face,1) ;
      if ( nxt_region == cur_region )
	nxt_region = NULL ;
    }
    
    if ( nxt_region == region )
      break;

    /* change of variables */
    cur_face = nxt_face;
    cur_region = nxt_region;
  }

  /* check if any edges exist between non-consecutive vertices of the 
     polygon, these will cause invalid mesh on swapping */
  
  if ( nbr >= 4 ) {
    for ( i=0 ; i <nbr ; i++ )
      for ( j=(i+2) ; j<nbr-1 ; j++ )
	if (E_exists(sc.pverts[i],sc.pverts[j]))
	  return(0) ;
  }
  
  sc.edge = edge; /* set the edge for which configuration is computed */

  if (nbr > 7)
    return 0;
  else if (nbr == 2) {
    sc.nbr_triangles = 0;  /* used in E_swap to identify this special case */

    #ifdef MPI
    /*
    Check if opposite edge on part. bdry
    */

    edge_2= E_exists(sc.pverts[0],sc.pverts[1]);
    if ( edge_2 == 0 ) {
       MT_ErrorHandler("pb !","E_numSwpCfg",FATAL);
    }
    link_nbr= pmdb_en_num_iplinks(edge_2);
    if ( link_nbr > 0 ) {
       return(0);
    }
    #endif

    return 1;
  }

  swapFct[nbr-3](&sc);
  for (i = 0; i < sc.nbr_triangles; i++) sc.valid[i] = 0;


  // OK 1  return 1;

  /*
  If edge classified on model face,
  cannot swap if new edge already there
  Check added by de Cougny as the code was upgraded to MPI
  */

  if ( etype == Gface ) {

     e_verts[0] = gfverts[0];
     e_verts[1] = gfverts[1];
     edge_2= E_exists(e_verts[0],e_verts[1]);
     if ( edge_2 != 0 ) {
        return(0);
     }

     #ifdef MPI
     /*
     The edge is not there on proc but could be off proc
     Be conservative:
     Do not do anything if the 2 verts are ngbing
     the same proc, since it s a necessary reason
     for the edge to exist off proc
     */

     MPI_Comm_rank(MPI_COMM_WORLD,&PImytid);
     MPI_Comm_size(MPI_COMM_WORLD,&PInumtids);

     for ( j= 0 ; j< 2 ; j++ )
      ngb_pids[j]= (int *)calloc(PInumtids,sizeof(int));
     for ( j= 0 ; j< 2 ; j++ ) {
        link_nbrs[j]= pmdb_en_num_iplinks(e_verts[j]);
        for ( k= 0 ; k< link_nbrs[j] ; k++ ) {
           pmdb_en_iplink(e_verts[j],k,&ngb_pid,&ngb_vert);
           ngb_pids[j][k]= ngb_pid;
        }
     }
     status= FALSE;
     for ( j= 0 ; j< link_nbrs[0] ; j++ ) {
        for ( k= 0 ; k< link_nbrs[1] ; k++ ) {
           if ( ngb_pids[1][k] == ngb_pids[0][j] ) {
              status= TRUE;
              break;
           }
        }
        if ( status == TRUE ) break;
     }
     for ( j= 0 ; j< 2 ; j++ )
      free(ngb_pids[j]);

     if ( status == TRUE ) {
        return(0);
     }
     #endif

  } /* End if type == FACE */


  ncfg = sc.nbr_trianguls;

  for (c = 0; c < sc.nbr_trianguls; c++) 
    sc.topoValidCfg[c] = 1;


  if (nonManif) {
    /* if the edge is classified on a non-manifold face, the only configs */
    /* that are valid are those that include a connection between the 2   */
    /* vertices of the polygon that are classified on the closure of the  */
    /* model face.                                                        */

    for (c = 0; c < sc.nbr_trianguls; c++) {

      /* Check the connections of the c'th configuration */    
      for (j = 0, found = 0; (j < sc.nbr_triangles_2) && !found; j++) {
	t = sc.trianguls[c][j];
	
	for (k = 0, count = 0; k < 3; k++) {
	  vtx = sc.pverts[sc.triangles[t][k]];
	  if (vtx == gfverts[0] || vtx == gfverts[1])
	    count++;
	}
	
	/* If both the opposite vertices were found in the polygon */
	/* then the desired edge exists in this config             */
	found = (count == 2) ? 1 : 0;	
      }

      if (!found) {
	/* Necessary connection does not exist; */
	/* flag this triangulation as invalid   */
	sc.topoValidCfg[c] = 0;
	ncfg--;
      }
    }
  }

  return ncfg;
}

