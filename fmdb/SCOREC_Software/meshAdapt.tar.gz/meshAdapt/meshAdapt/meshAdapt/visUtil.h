#ifndef _H_VISUTIL
#define _H_VISUTIL

#include "FMDB.h"
#include "AdaptTypes.h"

namespace visUtil {

#ifdef MVTK
  void mvtkAddPList(pPList &, float, int, int, int);
  void mvtkAddPList(pPList &l, int color); // for vertex list only
  void mvtkShowMeshGface(pGModel, pMesh, int);
  void mvtkShowConnectedEdges(pVertex); 
  void mvtkAddMRgn(pRegion);
  void mvtkShowCavity(pVertex, pPList);
  void mvtkShowCavity_2(pVertex, pPList);
  void mvtkShowCavity(pEdge e);
#endif

  void writeFaces(pPList faces);
  void writeAFace(pFace worstFace);
  void writeRegions(pPList regions, int);

  void readSizeField(pMeshMdl, pSField);
  void writeSizeField(pMeshMdl, pSField, const char*, int);
  void writeSizeField2(pMesh, pSField);
  void readSizeField2(pMesh, pSField);
#ifdef SIM
  void writeDX(pMesh, pSField);
  void wrtc_(int *, int *, int[],int *, float[], float[], int *);
#endif
}


#endif

