#ifndef _H_RegionCollapsMod_2
#define _H_RegionCollapsMod_2

#include "LocMeshMod.h"
#include "AdaptUtil.h"
#include <map>

/*
  Given a mesh region, a pair of its opposite edges, and the location
  of the introduced mesh vertex. This modification splits the two edges and 
  collapse the new diagonal edge.

  A new vertex is introduced in this operation

  All mesh regions connected the pair mesh edges will be affected

  07/15/01 created Xiangrong Li
*/

class DSplitClpsMod: public locMeshMod
{
 public:
  DSplitClpsMod(const DSplitClpsMod &);
  DSplitClpsMod(pMesh,pSField,MeanRatio *,evalResults *);
  ~DSplitClpsMod() {}

  /* the common local modification interface */
  virtual int topoCheck();
  virtual int geomCheck();
  virtual int sizeCheck();
  virtual void getAffectedRgns(pPList *);
  virtual int apply();
  virtual int apply(pPList *);
  virtual modType type() { return RCOLAPS_2; }

  /* specific member functions for region collapse */
  void setCollaps(pRegion, pEdge, pEdge, double *, double *);
  void setCollaps(pRegion, pEdge, pEdge);

  pVertex getNewVertex() { return vr; }
  pRegion getRegion() { return region; }
  void getSplitPos(double *);
  pEdge getSplitEdge_0() { return edgePair[0]; }
  pEdge getSplitEdge_1() { return edgePair[1]; }

 private:
  pRegion region;
  pEdge edgePair[2];
  double xyz[3];
  double par[3];
#ifdef CURVE
  // the quadratic mesh
  adaptUtil::bptxyz ptloc[10];
  std::map<pVertex, adaptUtil::bptxyz> verts_pts;
#endif
  pVertex vr;  // the new vertex created during operations
};


inline DSplitClpsMod::DSplitClpsMod(const DSplitClpsMod &x):
  locMeshMod(x.mesh, x.pSizeField, x.shpMeasure, x.results) 
{
  model_type=x.model_type;
  AcptControl=x.AcptControl;
  checkVolume=x.checkVolume;    
  dV_limit=x.dV_limit;
  dA_limit=x.dA_limit;
  function_CB=x.function_CB;
  userData_CB=x.userData_CB;
  CB_move=x.CB_move;
  userData_CB_move=x.userData_CB_move;

  vertMv=x.vertMv;
  target[0]=x.target[0];
  target[1]=x.target[1];
  target[2]=x.target[2];

  region=x.region;
  edgePair[0]=x.edgePair[0];
  edgePair[1]=x.edgePair[1];

  xyz[0]=x.xyz[0];
  xyz[1]=x.xyz[1];
  xyz[2]=x.xyz[2];
  par[0]=x.par[0];
  par[1]=x.par[1];
  par[2]=x.par[2];
#ifdef CURVE
  quadratic = x.quadratic;
#endif /* CURVE */
}

inline DSplitClpsMod::DSplitClpsMod(pMesh p, pSField mf, MeanRatio *m, 
					  evalResults *r):
  locMeshMod(p,mf,m,r), region(0), vr(0)
{
  edgePair[0]=0;
  edgePair[1]=0;

  xyz[0]=0.0;
  xyz[1]=0.0;
  xyz[2]=0.0;
  par[0]=0.0;
  par[1]=0.0;
  par[2]=0.0;
#ifdef CURVE
  quadratic=false;
#endif /* CURVE */

}

inline void DSplitClpsMod::setCollaps(pRegion r, pEdge e0,
					 pEdge e1, double *v, double *p)
{
  region=r;
  edgePair[0]=e0;
  edgePair[1]=e1;
  xyz[0]=v[0];
  xyz[1]=v[1];
  xyz[2]=v[2];
  if( p ) 
    { par[0]=p[0]; par[1]=p[1]; par[2]=0.0; }
  else
    { par[0]=0.0; par[1]=0.0; par[2]=0.0; }
}

inline void DSplitClpsMod::setCollaps(pRegion r, pEdge e0, pEdge e1)
{
  region=r;
  edgePair[0]=e0;
  edgePair[1]=e1;
}

#endif
