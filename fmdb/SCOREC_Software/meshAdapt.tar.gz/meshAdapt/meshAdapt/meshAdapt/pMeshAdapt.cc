/*<i> ****************************************************************************
 *
 *  meshAdapt/pMeshAdapt.cc
 *  Created by X. Li and Seegyoung Seol, on Mon Dec 15 2003, 10:26:37 EDT
 *
 *  Copyright (c) 2003, Scientific Computation Research Center
 *
 *  <a href="http://www.scorec.rpi.edu" CLASS="nav">www.scorec.rpi.edu</a>
 *
 *  File Content: Function Definitions which support Parallel Mesh Modification Operator
 *
 *************************************************************************** </i>*/
 
#ifdef AOMD_
#ifdef MA_PARALLEL

#include "MeshAdapt.h"
#include "paraAdapt.h"
#include "EdgeSwapMod.h"
#include "AdaptUtil.h"
#include "FMDB_Internals.h"
#include "pmMigrationCallbacks.h"
#include "SF_MigrationCallbacks.h"
#include "fromMeshTools.h"
#include "FMDB_cint.h"
#include "PList.h"
#include "ParUtil.h"
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <vector>

//#include "paraTemplateUtil.h"

using std::cout;
using std::cerr;
using std::endl;
using std::find;
using std::vector;

/*
  Given a list of mesh vertices on partition boundary (vtOnCB) and
  a empty mesh vertices container (drVertices), this routine tries
  to migrate the mesh to make as many vertices in vtOnCB interior 
  of partition boundary as possible.

  If this leads to conflicts, e.g., one vertex in vtOnCB want to 
  move mesh region A into partition 1 while another vertex in vtOnCB
  need move region A into partition 0, we only respect the first
  vertex. The second vertex remains on partion boundary as well as
  returned in list vtOnCB. 

  After mesh migration, the routine loops over all mesh edges connected
  to (i) new vertices come to current partition and (ii) survived 
  vertices in vtOnCB (both may be interior vertices or partition boundary 
  vertices), determine if any is a short edge and append two end vertices
  of short edges into vertex container "drVertices".

   - li  1/5/04
*/


int meshAdapt::mMigrateForCoarsen(
			std::list<pVertex>& vtOnCB, 
			std::list<pVertex>& drVertices, 
                        pmMigrationCallbacks& userLB,
			pMeshDataId& deref,
			double lowerLenSqBound)
{
  if (!M_getMaxNum(vtOnCB.size()))
    return 0;

  int value;
  pVertex vr; 
  pEdge edge;  
  // do mesh migration using vtOnCB
  std::vector<pEntity> newVt;
  std::vector<pEntity> rmVt;
  std::vector<pEntity>::iterator vIt;
  std::vector<pEntity> dummy;
  std::vector<mEntityGroup*> VecRmvEG;
  std::vector<mEntityGroup*> VecNewEG;

  M_migration(pmesh,0,vtOnCB,userLB,0,rmVt,newVt,-1,dummy,dummy,VecRmvEG,VecNewEG);


  if (BLAdaptFlag)
  {
    /// Some entities are now probably unaware of being layer edges (if interface region is disconnected from its BL)
    Mesh_AssignBLLevelsToAllBLEnts(pmesh);
    Mesh_UnifyBLInterfaceOnCB(pmesh);
    Mesh_ClrHangingBLEntLvl(pmesh);
  }

  // upddate the snaplist
  if( model_type ) {
    vIt=rmVt.begin();
    for ( ; vIt!=rmVt.end(); vIt++ )
      pSnap->remove(*vIt);
  }

  // connected vertices newly moved in and survived vertices in vtOnCB
  // into a temporary vector.
  std::vector<pVertex> vts_new_and_old;  
  std::list<pEntity>::iterator vtIt=vtOnCB.begin();
  for (;vtIt!=vtOnCB.end();++vtIt)
    if ( std::find(rmVt.begin(),rmVt.end(),*vtIt)==rmVt.end())
      vts_new_and_old.push_back(*vtIt);

  vIt=newVt.begin();
  for (; vIt != newVt.end(); ++vIt) 
    vts_new_and_old.push_back(*vIt);

  // push local vertices connected to short edges into drVertices. 
  // note that the snaplist need not update
  vIt = vts_new_and_old.begin();
  for (;vIt != vts_new_and_old.end();++vIt)
    {
    for(int j=0; j<V_numEdges(*vIt); j++ ) 
    {
      edge=V_edge(*vIt,j);
      if (!EN_okTo(DELETE,(pEntity)edge))
        continue;
      if (E_typeInBL(edge))
        continue;
      if( pSizeField->lengthSq(edge) < lowerLenSqBound ) 
      {
	EN_attachDataInt((pEntity)edge,deref,-1);
	for(int i=0; i<2; i++ ) 
        {
	  vr=E_vertex(edge,i);
          if (!EN_okTo(DELETE,(pEntity)vr))
            continue;
	  if (EN_onCB(vr))
	    continue;
          if (V_typeInBL(vr))
            continue;
	  if( !EN_getDataInt((pEntity)vr,deref,&value) )  
          {
	    EN_attachDataInt((pEntity)vr,deref,-1);
	    drVertices.push_back(vr);
	  }
	} // for i
      }
    }  //for j
  }  // for vIt
  return M_getMaxNum(drVertices.size());  
}


int meshAdapt::mMigrateForCoarsenBL(
                        std::list<pVertex>& vtOnCB,
                        std::list<pVertex>& drVertices,
                        pmMigrationCallbacks& userLB,
                        pMeshDataId& deref,
                        double lowerLenSqBound)
{
  if (!M_getMaxNum(vtOnCB.size()))
    return 0;

  int iValue, iBLNumBeforeMigration, iBLNumAfterMigration;
  pVertex vd, vr;
  pEdge edge;
  // do mesh migration using vtOnCB
  vector<pEntity> newVt;
  vector<pEntity> rmVt;
  vector<pEntity>::iterator vIt, rem_vIt;
  vector<pEntity> dummy;
  std::vector<mEntityGroup*> VecRmvEG;
  std::vector<mEntityGroup*> VecNewEG;

  iBLNumBeforeMigration = M_getNumBLs(pmesh);

  M_migration(pmesh,0,vtOnCB,userLB,0,rmVt,newVt,-1,dummy,dummy,VecRmvEG,VecNewEG);

  iBLNumAfterMigration = M_getNumBLs(pmesh);

  /// Categorize newly migrated BLs
  for (int iIt = 0; iIt < VecNewEG.size(); ++iIt)
  {
    BL_CategorizeBLEntities(VecNewEG[iIt]);
//    BL_AssignBLLevelsToEnts(VecNewEG[iIt]);
  }

  // upddate the snaplist
  if( model_type ) {
    vIt=rmVt.begin();
    for ( ; vIt!=rmVt.end(); vIt++ )
      pSnap->remove(*vIt);
  }

  /// Tag processed vertexes and BLs
  pMeshDataId procTag = MD_lookupMeshDataId("ProcessedEntTag");

  // connected originating vertices newly moved in and survived vertices in vtOnCB into a temporary vector.
  // There could be regions from newly migrated BLs that are adjacent to vertexes from vtOnCB, so we have to check them for its structure
  // This routine can be moved further after we explore all the new vertexes from newVt.
  std::vector<pVertex> vts_new_and_old;
  std::list<pEntity>::iterator vtIt=vtOnCB.begin();
  for (;vtIt!=vtOnCB.end();++vtIt)
  {
    if ( std::find(rmVt.begin(),rmVt.end(),*vtIt)==rmVt.end())
    {
      vd = *vtIt;

      /// If it's not originating node, skip it.
      if (V_typeInBL(vd) == vREGULAR)
        continue;

      if (!EN_getDataInt(vd, procTag, &iValue))
      {
        EN_attachDataInt((pEntity)vd, procTag, 1);
        vts_new_and_old.push_back(vd);
      }
    }
  }

  /// add new verts and build BL information assosiated with the BLs adjacent to those verts
  vIt=newVt.begin();
  for(; vIt != newVt.end(); ++vIt)
  {
    vd = *vIt;

    /// If it's not originating node, skip it.
    if (V_typeInBL(vd) == vREGULAR)
      continue;

    if (!EN_getDataInt(vd, procTag, &iValue))
    {
      EN_attachDataInt((pEntity)vd, procTag, 1);
      vts_new_and_old.push_back(vd);
    }
  }

  /// Some entities are now probably unaware of being layer edges (if interface region is disconnected from its BL)
  Mesh_AssignBLLevelsToAllBLEnts(pmesh);
  Mesh_UnifyBLInterfaceOnCB(pmesh);

  Mesh_ClrHangingBLEntLvl(pmesh);

  // push local vertices connected to short edges into drVertices.
  // note that the snaplist need not update
  vector<pEdge> edgeStack, layerEdges;
  int isClpNeeded, nClpsInStack, numEdges;
  vIt = vts_new_and_old.begin();
  for (;vIt != vts_new_and_old.end();++vIt)
  {
    vd = *vIt;
    V_layerEdges(vd, layerEdges);
    for(int j=0; j<layerEdges.size(); j++ )
    {
      edge=layerEdges[j];

      BL_getHorizontalEdgesByEdge(edge, edgeStack);

      isClpNeeded = 0;
      nClpsInStack = 0;
      numEdges = edgeStack.size();
      for(int iEdge=0; iEdge<numEdges; iEdge++) {
        edge = edgeStack[iEdge];

        // if any layer edge from the stack is
        // constrained or tested for coarsening
        // then NO layer edge from the stack
        // is allowed to be collapsed
        if( !EN_okTo(DELETE,(pEntity)edge))// || EN_getDataInt((pEntity)edge,coarsenTested,&value) )
        {
          nClpsInStack = 0;
          break;
        }

        // collapse is performed ONLY if all layer edges
        // from the stack need to be coarsened
        // conservative approach and avoids oscillation between
        // refinement and coarsening
        // in case of refinement we split all layer
        // edges in stack if any needs split
        // in any case this would probably happen only for a small
        // portion of the domain (e.g., shock and boundary layer interaction)
        if( pSizeField->lengthSq(edge) < lowerLenSqBound )
          nClpsInStack++;
      }

      if(nClpsInStack==numEdges)
        isClpNeeded=1;

      if(isClpNeeded) {
        if (!EN_getDataInt((pEntity)edge, deref,& iValue))
          EN_attachDataInt((pEntity)edgeStack[0],deref,-1);
        for(int iVert=0; iVert<2; iVert++ ) {
          vr=E_vertex(edgeStack[0],iVert);
//          topVr = E_vertex(edgeStack[numEdges-1],iVert);
          if (EN_onCB(vr))
            continue;
          if(!EN_okTo(DELETE,(pEntity)vr))
            continue;
          if( !EN_getDataInt((pEntity)vr, deref, &iValue) )  {
            EN_attachDataInt((pEntity)vr, deref, -1);
            drVertices.push_back(vr);
          }
        } // loop over end vertices
      } // if clp is needed
    }  //for j
    EN_deleteData(vd, procTag);
  }  // for vIt

  MD_deleteMeshDataId(procTag);

  return M_getMaxNum(drVertices.size());
}


/* called in carsening */
void meshAdapt::deleteDimReduction(std::list<pVertex> &vtOnCB, pmMigrationCallbacks& userLB)
{
  std::vector<pEntity> removedVts[3];
  if (M_deleteDimReduction(pmesh,userLB,removedVts)==0)
    return;

  std::vector<pEntity>::iterator vtIt=removedVts[0].begin();
  for ( ; vtIt!=removedVts[0].end(); vtIt++ ) {
    if ( std::find(vtOnCB.begin(),vtOnCB.end(),*vtIt)!=vtOnCB.end() ) {
//      adaptUtil::Info(" removed a vertex from list vtOnCB");
      vtOnCB.remove(*vtIt);
    }
    if( model_type ) 
      pSnap->remove(*vtIt);
  }

  return;
}


void meshAdapt::updateRgnList(pRegion region,
			      std::list<pEntity> &rgnOnCB)
{
  std::list<pEntity>::iterator rgnIt;
  for(rgnIt=rgnOnCB.begin(); rgnIt!=rgnOnCB.end();++rgnIt) {
    if( *rgnIt == region )
      { rgnOnCB.erase(rgnIt); return; }
  }
  return;
}


// return 0 if no migration happened
//        1 otherwise
int meshAdapt::mMigrateForShapeCorrect(
			   std::list<pEntity> &rgnOnCB,
			   std::set<pRegion> &newSlivers,
			   pmMigrationCallbacks &userLB,
			   double shpLowerBound)
{
  pFace face;
  pEdge edge;
  pVertex vertex;
  int ind, i;
  pEntity ents[4];
  double shp, area[4], intXYZ[3];
  std::list<pEntity> egOnCB;

  std::list<pEntity>::iterator rgnIt;
  rgnIt=rgnOnCB.begin();
  for( ; rgnIt!=rgnOnCB.end();++rgnIt) {
    face=R_face(*rgnIt,0);
    vertex=R_fcOpVt(*rgnIt,face);
    ind=adaptUtil::getTetInfo(*rgnIt,face,vertex,1,ents,area,intXYZ);
    if( !ind ) 
      { adaptUtil::Error("strange!!!\n"); continue; } 

    if( ind==3 || ind==5 || ind==6 )
    {	
      for( i=0; i<2; i++)
      {
	if( EN_onCB((pEntity)ents[i]) )
        {
          if (!EN_isBLEntity((pEntity)ents[i]))
            egOnCB.push_back(ents[i]);
	}
      } 
    }
    else {
      for( i=0; i<3; i++ ) {
	edge=F_edge((pFace)ents[0],i);
	if ( EN_onCB((pEntity)edge) )
        {
          if (!EN_isBLEntity((pEntity)edge))
            egOnCB.push_back(edge);
        }
      }
    }
  }

  if (!P_getMaxInt(egOnCB.size()))
    { 
#ifdef DEBUG
      adaptUtil::Info("No migration needed"); 
#endif
      return 0; }

  egOnCB.unique();


  std::vector<pEntity> rmRg;
  std::vector<pEntity> newRg;
  std::vector<pEntity> dummy;
  std::vector<mEntityGroup*> VecRmvEG;
  std::vector<mEntityGroup*> VecNewEG;

  ind=M_migration(pmesh,1,egOnCB,userLB,3,rmRg,newRg,-1,dummy,dummy,VecRmvEG,VecNewEG);

//    for(rgnIt=rgnOnCB.begin(); rgnIt!=rgnOnCB.end();++rgnIt) {
//      if( std::find(rmRg.begin(),rmRg.end(),*rgnIt)!=rmRg.end())
//        rgnOnCB.erase(rgnIt);
//    }

  /// Some entities are now probably unaware of being layer edges (if interface region is disconnected from its BL)
  Mesh_AssignBLLevelsToAllBLEnts(pmesh);
  Mesh_UnifyBLInterfaceOnCB(pmesh);

  Mesh_ClrHangingBLEntLvl(pmesh);

  std::vector<pEntity>::iterator rmIter;
  for (rmIter=rmRg.begin();rmIter!=rmRg.end();++rmIter){  
    rgnOnCB.remove(*rmIter);
    newSlivers.erase(*rmIter);
  }

  std::vector<pEntity>::iterator rIt;
  for(rIt=newRg.begin(); rIt!=newRg.end();++rIt)
  {
    if( R_isSliver(*rIt,shpLowerBound,&shp, 0.) ) 
    {
      newSlivers.insert(*rIt);
    }
  }

  for(rgnIt=rgnOnCB.begin(); rgnIt!=rgnOnCB.end();++rgnIt) 
  {
    newSlivers.insert(*rgnIt);
  }
 
  return ind;
}


int meshAdapt::mMigrateForShapeCorrectBL(std::set<pBLayer> &FacesNextToPB, std::set<pBLayer> &newAndNotRemSlivers, pmMigrationCallbacks &userLB)
{
  if (!M_getMaxNum(FacesNextToPB.size()))
    return 0;

  int iValue, iBLNumBeforeMigration, iBLNumAfterMigration;
  pVertex vert, topVD;
  pFace face;
  pEdge edge;
  vector<pEntity> newVt;
  vector<pEntity> rmVt;
  vector<pEntity>::iterator vIt, rem_vIt;
  vector<pEntity> dummy;
  list<pEntity> vtOnCB;
  std::vector<mEntityGroup*> VecRmvEG;
  std::vector<mEntityGroup*> VecNewEG;

  /// Tag processed vertexes
  pMeshDataId procTag = MD_lookupMeshDataId("ProcessedEntTag");

  std::set<pBLayer>::iterator fcIt;
  for (fcIt = FacesNextToPB.begin(); fcIt != FacesNextToPB.end(); ++fcIt)
  {
    face = BL_GetZeroLvlFace(*fcIt);
    for (int itVert = 0; itVert < 3; ++itVert)
    {
      vert = F_vertex(face, itVert);
      if (EN_getDataInt((pEntity)vert, procTag, &iValue))
        continue;
      
      EN_attachDataInt((pEntity)vert, procTag, 1);
      rmVt.push_back(vert);

      vector<pVertex> GC;
      BL_getGrowthCurveNodes(vert, GC);
      topVD = GC[GC.size()-1];

      if (EN_onCB(topVD))
        vtOnCB.push_back(topVD);
    }
  }

  for (int iVert = 0; iVert < rmVt.size(); ++iVert)
    EN_deleteData(rmVt[iVert], procTag);

  rmVt.clear();

  iBLNumBeforeMigration = M_getNumBLs(pmesh);

  M_migration(pmesh,0,vtOnCB,userLB,0,rmVt,newVt,-1,dummy,dummy,VecRmvEG,VecNewEG);

  iBLNumAfterMigration = M_getNumBLs(pmesh);

  /// Categorize newly migrated BLs
  for (int iIt = 0; iIt < VecNewEG.size(); ++iIt)
  {
    BL_CategorizeBLEntities(VecNewEG[iIt]);
//    BL_AssignBLLevelsToEnts(VecNewEG[iIt]);
  }

  // upddate the snaplist
  if( model_type ) 
  {
    vIt=rmVt.begin();
    for ( ; vIt!=rmVt.end(); vIt++ )
      pSnap->remove(*vIt);
  }

  /// Some entities are now probably unaware of being layer edges (if interface region is disconnected from its BL)
  Mesh_AssignBLLevelsToAllBLEnts(pmesh);
  Mesh_UnifyBLInterfaceOnCB(pmesh);

  Mesh_ClrHangingBLEntLvl(pmesh);

  MD_deleteMeshDataId(procTag);

  std::vector<mEntityGroup*>::iterator EGIter;
  for (EGIter = VecRmvEG.begin(); EGIter != VecRmvEG.end(); ++EGIter)
  {
    FacesNextToPB.erase(*EGIter);
    newAndNotRemSlivers.erase(*EGIter);
  }

  for (EGIter = VecNewEG.begin(); EGIter != VecNewEG.end(); ++EGIter)
  {
    newAndNotRemSlivers.insert(*EGIter);
  }

  for(fcIt = FacesNextToPB.begin(); fcIt != FacesNextToPB.end(); ++fcIt)
  {
    newAndNotRemSlivers.insert(*fcIt);
  }
 
  return 1;
}


// return an entity on partition boundary that bounds the given face.
//        NULL otherwise
pEntity meshSnap::F_inClosureCBEnt(pFace face)
{
  if( EN_onCB((pEntity)face) )
    return (pEntity)face;

  pEdge edge;
  for( int i=0; i<3; i++ ) {
    edge=F_edge(face,i);
    if( EN_onCB((pEntity)edge) )
      return (pEntity) edge;
  }

  pPList verts=F_vertices(face,1);
  pVertex vv;
  void *iter=0;
  while( vv=(pVertex)PList_next(verts,&iter) )
    if( EN_onCB((pEntity)vv) )
      { PList_delete(verts); return (pEntity)vv;}
  PList_delete(verts);
  return (pEntity)0;
}


// return 1 if the vertex is the 1st element of one of the pairs
//        0 otehrwise  
int meshSnap::V_inPairList(std::list<pair<pEntity,pEntity> >& pairList, pVertex vv)
{
  pVertex vvv;
  std::list<pair<pVertex,pFace> >::iterator pairIt=pairList.begin();
  for (;pairIt!=pairList.end();++pairIt) {
    vvv=(pVertex)pairIt->first;
    if( vvv==vv )
      return 1;
  }
  return 0;
}


void meshSnap::deleteDimReduction(std::list<pair<pEntity,pEntity> >& pairList,
			          std::list<pEntity>& vtsOnCB,
				  pmMigrationCallbacks& userLB)
{
  std::vector<pEntity> removedVts[3];
  if (M_deleteDimReduction(pmesh,userLB,removedVts)==0)
    return;

  std::list<pVertex>::iterator vtIt=vtsOnCB.begin();
  for ( ; vtIt!=vtsOnCB.end(); ) 
  {
    if (std::find(pSnaplist->begin(), pSnaplist->end(), *vtIt) != pSnaplist->end() )
      pSnaplist->erase(vtIt);
    if ( std::find(removedVts[0].begin(),removedVts[0].end(),*vtIt)!=removedVts[0].end() ) 
    {
#ifdef DEBUG
      adaptUtil::Info(" removed a vertex from list vtOnCB");
#endif
      vtsOnCB.erase(vtIt++);
    }
    else
      vtIt++;
  }
  
  std::list<pair<pEntity,pEntity> >::iterator prIt=pairList.begin();
  for ( ; prIt!=pairList.end(); ) {
    if ( std::find(removedVts[0].begin(),removedVts[0].end(),prIt->first)!=removedVts[0].end() ) 
    {
#ifdef DEBUG
      adaptUtil::Info(" removed a vertex from list vtOnCB");
#endif      
      pairList.erase(prIt++);
    }
    else
      prIt++;
  }

  std::list<pVertex>::iterator vIt = pSnaplist->begin(), vItDel;
  pVertex vertex;
  while (vIt != pSnaplist->end())
  {
    vertex = *vIt;
    if ( std::find(removedVts[0].begin(),removedVts[0].end(),vertex)!=removedVts[0].end() ) 
    {
      vItDel = vIt;
      vIt++;
      pSnaplist->erase(vItDel);
    }
    else
      vIt++;
  }
  
  return;
}


void meshSnap::deleteDimReduction(std::list<pFace> &DisSimfaces,pmMigrationCallbacks& userLB)
{
  std::vector<pEntity> removedEnts[3];
  if (M_deleteDimReduction(pmesh,userLB,removedEnts)==0)
    return;

  // update the list of not similar faces
    std::list<pFace>::iterator fcIt=DisSimfaces.begin(), fcItRem;
    for ( ; fcIt!=DisSimfaces.end(); ) {
      if ( std::find(removedEnts[2].begin(),removedEnts[2].end(),*fcIt)!=removedEnts[2].end() ) 
      {
#ifdef DEBUG
        adaptUtil::Info(" removed a face from DisSimfaces");
#endif
        fcItRem = fcIt;
        fcIt++;
        DisSimfaces.erase(fcItRem);
      }
      else
        fcIt++;
    }

  // update the vertex list to be snapped
  std::list<pVertex>::iterator vIt = pSnaplist->begin(), vItDel;
  pVertex vertex;
  while (vIt != pSnaplist->end())
  {
    vertex = *vIt;
    if ( std::find(removedEnts[0].begin(),removedEnts[0].end(),vertex)!=removedEnts[0].end() )
    {
      vItDel = vIt;
      vIt++;
      pSnaplist->erase(vItDel);
    }
    else
      vIt++;
  }

  return;
}

// Dec 02, 2004 corrected by E.S. Seol
// some vertex in pairList was deleted by E_colap before migrateMesh is called
// and this caused crash post-process of migration
// it returns 0 if migration performed, 1 otherwise
int meshSnap::migrateMesh(std::list<pair<pEntity,pEntity> >& pairList,
			  std::list<pEntity>& vtsOnCB,
			  pmMigrationCallbacks& userLB) 
{
  if (P_getSumInt(pairList.size()+vtsOnCB.size())==0) return 0;

  std::list<pair<pVertex,pFace> >::iterator pairIt = pairList.begin();
  bool eraseFlag=false;
  for (;pairIt!=pairList.end();++pairIt) 
  {
    if (eraseFlag)
    {
      --pairIt; eraseFlag=false;
    }
    
    if (M_findE(pmesh, pairIt->first, 0)==0)
    {
//      cout<<"("<<P_pid()<<") erase from pairList\n";
      pairList.erase(pairIt++);
      eraseFlag=true;      
    }  
//    else
//      cout<<"("<<P_pid()<<") "<<EN_getUid(pIt->first)<<" stays in pairList\n";
  }

  std::vector<pEntity> newVt;
  std::vector<pEntity> rmVt;
  std::vector<mEntityGroup*> VecRmvEG;
  std::vector<mEntityGroup*> VecNewEG;
  M_migrationForSnap(pmesh,userLB,vtsOnCB,pairList,0,rmVt,newVt,VecRmvEG,VecNewEG);

  for (int iIt = 0; iIt < VecNewEG.size(); ++iIt)
  {
    BL_CategorizeBLEntities(VecNewEG[iIt]);
//    BL_AssignBLLevelsToEnts(VecNewEG[iIt]);
  }

  /// Some entities are now probably unaware of being layer edges (if interface region is disconnected from its BL)
  Mesh_AssignBLLevelsToAllBLEnts(pmesh);
  Mesh_UnifyBLInterfaceOnCB(pmesh);

  Mesh_ClrHangingBLEntLvl(pmesh);

#ifdef DEBUG
  M_checkBLStructure(pmesh);
  M_checkBLFacesAndAdjRegions(pmesh);
  M_checkBLPresence(pmesh);
#endif
/// BL STUFF TILL THIS POINT

  // update the vertex list to be snapped  
  std::list<pEntity>::iterator vtIt=vtsOnCB.begin();
  for (;vtIt!=vtsOnCB.end();++vtIt) {
    if ( std::find(rmVt.begin(),rmVt.end(),*vtIt)==rmVt.end() ) {
      if (std::find(pSnaplist->begin(), pSnaplist->end(), *vtIt) == pSnaplist->end()) 
      {
        computeTarget(*vtIt);
	pSnaplist->push_back(*vtIt);
      }
      checkSnapTarget(*vtIt);
    }
  }
  pairIt=pairList.begin();
  for (;pairIt!=pairList.end();++pairIt) {
    if ( std::find(rmVt.begin(),rmVt.end(),pairIt->first)==rmVt.end() ) 
    {
      if (std::find(pSnaplist->begin(), pSnaplist->end(), pairIt->first) == pSnaplist->end())
      {
        computeTarget(pairIt->first);
        pSnaplist->push_back(pairIt->first);
      }
      checkSnapTarget(pairIt->first);
    }
//    else
//      adaptUtil::Error("deleted an interior vertex to be snapped");
  }

  int gtype;
  std::vector<pEntity>::iterator newvIt=newVt.begin();
  for (; newvIt != newVt.end(); ++newvIt) {
    gtype=V_whatInType(*newvIt);
    if( gtype == Gvertex || gtype == Gregion )
      continue;
    computeTarget(*newvIt);
    if( checkSnapTarget(*newvIt) )
      continue;
    pSnaplist->push_back(*newvIt);
#ifdef DEBUG_
    adaptUtil::Info("append a vertex into snaplist (3)");
#endif
  }

  return 1;
}


int meshSnap::migrateMeshForSnapBL(std::list<pair<pEntity,pEntity> >& pairList,
                          std::list<pEntity>& vtsOnCB,
                          pmMigrationCallbacks& userLB)
{
  if (P_getSumInt(pairList.size()+vtsOnCB.size())==0) return 0;

#ifdef DEBUG
//M_writeVTKFile(pmesh,"mesh_out_before_migration_BL_Snap");
#endif

  std::list<pair<pVertex,pFace> >::iterator pairIt, pairItRem;
  pairIt = pairList.begin();
  while (pairIt != pairList.end())
  {
    if (M_findE(pmesh, pairIt->first, 0)==0)
    {
      pairItRem = pairIt;
      ++pairIt;
      pairList.erase(pairItRem);
    }
    else
      ++pairIt;
  }

  std::list<pEntity>::iterator vtIt = vtsOnCB.begin();

  /// Add top nodes to the list of verts on the boundary for the correct BL migration in case not all of them are top-most.
  /// At the same time can't delete originating nodes when doing BL snapping since there are some additional
  /// checks for the first problem planes associated with the originating nodes in the migration routine itself.
  /// Have to figure out whether it's needed for thickness adaptation.
  std::list<pVertex> lst_TopNodes;
  std::vector<pVertex> nodesOnGC;
  int iNodeNum;
  pVertex vtx;
  for ( ; vtIt != vtsOnCB.end(); ++vtIt)
  {
    vtx = *vtIt;
    if (EN_levelInBL(vtx) < 0)
      continue;
    BL_getGrowthCurveNodes(vtx, nodesOnGC);
    iNodeNum = nodesOnGC.size();
    lst_TopNodes.push_back(nodesOnGC[iNodeNum - 1]);
  }

  /// Put available vtsOnCB and top-most nodes together for the migration
  std::list<pEntity> lst_BLVertOnCB;
  vtIt = vtsOnCB.begin();
  for ( ; vtIt != vtsOnCB.end(); ++vtIt)
    lst_BLVertOnCB.push_back(*vtIt);

  vtIt = lst_TopNodes.begin();
  for ( ; vtIt != lst_TopNodes.end(); ++vtIt)
    lst_BLVertOnCB.push_back(*vtIt);


  /// Temporary solution for keeping BL nodes tags consistent when do migration within snapBLNodes() routine.
  /// Later all the tags have to migrate along with the entity and this solution will be obsolete.
  /// Here it is assumed that all the tags are uniformly allocated on each part, otherwise it is needed to send the string instead of each tag.
  /// Check paraTemplateUtil.h for details.
//  UpdateTagsForBLSnap UpdtForBLSnap(gGlobalSF);

  std::vector<pEntity> newVt;
  std::vector<pEntity> rmVt;
  std::vector<mEntityGroup*> VecRmvEG;
  std::vector<mEntityGroup*> VecNewEG;
//  M_migrationForSnap(pmesh,UpdtForBLSnap,lst_BLVertOnCB,pairList,0,rmVt,newVt);
  M_migrationForSnap(pmesh,userLB,lst_BLVertOnCB,pairList,0,rmVt,newVt,VecRmvEG,VecNewEG);

  /// Categorize newly migrated BLs
  for (int iIt = 0; iIt < VecNewEG.size(); ++iIt)
  {
    BL_CategorizeBLEntities(VecNewEG[iIt]);
//    BL_AssignBLLevelsToEnts(VecNewEG[iIt]);
  }

  /// Some entities are now probably unaware of being layer edges (if interface region is disconnected from its BL)
  Mesh_AssignBLLevelsToAllBLEnts(pmesh);
  Mesh_UnifyBLInterfaceOnCB(pmesh);

  Mesh_ClrHangingBLEntLvl(pmesh);

  // update the vertex list to be snapped
  /// All the targets should be already assigned
  vtIt=vtsOnCB.begin();
  for (;vtIt!=vtsOnCB.end();++vtIt)
  {
    if ( std::find(rmVt.begin(),rmVt.end(),*vtIt)==rmVt.end() )
    {
      if (std::find(pSnaplist->begin(), pSnaplist->end(), *vtIt) == pSnaplist->end())
      {
        /// For the migrated top-most nodes of BLs the targets are already assigned - see paraTemplateUtil.cc: receiveUserData()
//        computeTarget(*vtIt);
        pSnaplist->push_back(*vtIt);
      }

      checkSnapTarget(*vtIt);
    }
  }

  pairIt=pairList.begin();
  for (;pairIt!=pairList.end();++pairIt)
  {
    if ( std::find(rmVt.begin(),rmVt.end(),pairIt->first)==rmVt.end() )
    {
/*
      if (!pSnaplist->inList(pairIt->first))
      {
        computeTarget(pairIt->first);
        pSnaplist->append(pairIt->first);
      }
*/
      checkSnapTarget(pairIt->first);
    }
//    else
//      adaptUtil::Error("deleted an interior vertex to be snapped");
  }

  /// From the container of newly migrated verts originating nodes are needed for snapping, and the top-most for thickness.
  /// NOT SURE WHAT TO DO WITH THICKNESS HERE, SO LETTING IT WORK FOR SNAPPING SO FAR
  /// HAVE TO MAKE SURE NOT TO PASS VERTEXES WHICH ARE NOT SUPPOSED TO BE SNAPPED, BUT ARE IN newVt CONTAINER AFTER 
  /// BL MIGRATION!!! AS WE UPDATE VERTEX TAGS FOR NOW THE MIGRATED VERTEXES ARE ASSIGNED THEIR TARGETS ALREADY, IF ANY
  std::vector<pEntity>::iterator newvIt=newVt.begin();

  void * vpVertPtr;
  for (; newvIt != newVt.end(); ++newvIt)
  {
    if (EN_getDataPtr((pEntity)(*newvIt), ptr_xyz, &vpVertPtr))
      pSnaplist->push_back(*newvIt);
  }

  return 1;
}


/*
  migrate the mesh to as many vertices in vertex list become interior
  as possible, and update the face list and the snap vertex list.
 */
int meshSnap::migrateMesh_2(std::list<pEntity>& vtsOnCB,
			    std::list<pFace>& DisSimfaces,
			    pmMigrationCallbacks& userLB) 
{
  std::vector<pEntity> rmFcs;
  std::vector<pEntity> newFcs;
  std::vector<pEntity> rmVts;
  std::vector<pEntity> newVts;
  std::vector<mEntityGroup*> VecRmvEG;
  std::vector<mEntityGroup*> VecNewEG;
  M_migration(pmesh,0,vtsOnCB,userLB,2,rmFcs,newFcs,0,rmVts,newVts,VecRmvEG,VecNewEG);

  // delete those removed faces from DisSimfaces
  std::list<pFace>::iterator fcIt=DisSimfaces.begin();
  for( ; fcIt!=DisSimfaces.end(); ) { 
    if ( std::find(rmFcs.begin(),rmFcs.end(),*fcIt)!=rmFcs.end() ) 
    {
#ifdef DEBUG
      adaptUtil::Info(" removed a face from DisSimfaces");
#endif      
      DisSimfaces.erase(fcIt++);
    }
    else
      fcIt++;
  }

  // append any moved-in dissimilar face into DisSimfaces
  std::vector<pEntity>::iterator newFcIt=newFcs.begin();
  for( ; newFcIt!=newFcs.end(); ++newFcIt ) { 
    if( F_whatInType(*newFcIt) == Gregion )
      continue;
    if( EN_onCB((pEntity)(*newFcIt)) )
      continue;
    if( adaptUtil::F_checkGeoSim(*newFcIt)==1 )
      continue;
    DisSimfaces.push_back(*newFcIt);
#ifdef DEBUG
    adaptUtil::Info("insert a new face into DisSimfaces");
#endif
  }

  // delete those removed vertex from pSnaplist
  std::list<pVertex>::iterator vIt = pSnaplist->begin(), vItDel;
  pVertex vertex;
  while (vIt != pSnaplist->end())
  {
    vertex = *vIt;
    if ( std::find(rmVts.begin(),rmVts.end(),vertex)!=rmVts.end() )
    {
      vItDel = vIt;
      vIt++;
      pSnaplist->erase(vItDel);
    }
    else
      vIt++;
  }
  
  // append any moved-in vertex unsnapped vertex into pSnaplist
  std::vector<pEntity>::iterator newVtIt=newVts.begin();
  for( ; newVtIt!=newVts.end(); ++newVtIt ) { 
    if( F_whatInType(*newVtIt) == Gregion )
      continue;
    if( F_whatInType(*newVtIt) == Gvertex )
      continue;    
    if (std::find(pSnaplist->begin(), pSnaplist->end(), *newVtIt) != pSnaplist->end() )
      continue;
    computeTarget(*newVtIt);
    if( checkSnapTarget(*newVtIt) )
      continue;
    pSnaplist->push_back(*newVtIt);
#ifdef DEBUG
    adaptUtil::Info("append a vertex into snaplist <4>");
#endif
  }
  
  return 1;
}


/*
  for a vertex in local snaplist that is on partition boundary, make sure
  that its remotecopies existed in corresponding local snaplist.

  Although rare, such inconsistency can occur in paralllel vertex snapping
  created 1/20/2004  -li
 */
void meshSnap::unifySnapList()
{
  pVertex vertex;
  pEntity ent;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  int msg_size = sizeof(remoteCopyPack);
  CM->set_fixed_msg_size(msg_size);
  remoteCopyPack *msg_send = (remoteCopyPack*)CM->alloc_msg(msg_size);
  int num_sent = 0, num_recvd = 0;

  std::list<pVertex>::iterator snapIter = pSnaplist->begin(), snapIterDel;
  while(snapIter != pSnaplist->end())
  {
    vertex = *snapIter;
    ent = (pEntity)vertex;
    if(EN_onCB(ent))
    {
      int pid;
      std::vector<std::pair<pEntity,int> > remotePtrs;
      std::vector<std::pair<pEntity,int> >::iterator remoteIter;
      EN_getRemoteCopies(pmesh, ent, remotePtrs);

      for( remoteIter=remotePtrs.begin(); remoteIter!=remotePtrs.end(); ++remoteIter )
      {
        pid=remoteIter->second;
        msg_send->localInSend  = ent;
        msg_send->remoteInSend = remoteIter->first;
        msg_send->type = EN_type(ent);
        msg_send->pid = M_Pid();
        CM->send(pid, (void*)msg_send);
        num_sent++;
      }
    }
    snapIter++;
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;

  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    remoteCopyPack *castbuf = (remoteCopyPack *)msg_recv;      
    vertex = (pVertex)castbuf->remoteInSend;      
    if (std::find(pSnaplist->begin(), pSnaplist->end(), vertex) == pSnaplist->end() )
    {
      computeTarget(vertex);
      pSnaplist->push_back(vertex);
#ifdef DEBUG
      adaptUtil::Info("united vertex",EN_id((pEntity)vertex));
#endif
    }
    CM->free_msg(msg_recv);
  }
  
  return;
}


/*
  for a vertex in local snaplist that is on partition boundary, make sure
  that its remotecopies existed in corresponding local snaplist.

  Although rare, such inconsistency can occur in paralllel vertex snapping
  created 1/20/2004  -li
 */
void meshSnap::unifySnapListBL()
{
  pVertex vertex;
  pEntity ent;
  double *pdVtxCoords, *pdVtxTarget;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  int msg_size = sizeof(pVertex) + 3*sizeof(double);
  CM->set_fixed_msg_size(msg_size);
  void *msg_send = CM->alloc_msg(msg_size);
  int num_sent = 0, num_recvd = 0;

  std::list<pVertex>::iterator snapIter = pSnaplist->begin(), snapIterDel;
  while(snapIter != pSnaplist->end())
  {
    vertex = *snapIter;
    ent = (pEntity)vertex;
    if(EN_onCB(ent))
    {
      int pid;
      std::vector<std::pair<pEntity,int> > remotePtrs;
      std::vector<std::pair<pEntity,int> >::iterator remoteIter;
      EN_getRemoteCopies(pmesh, ent, remotePtrs);
   
      pVertex *pVertexVtxRemCopy;

      for( remoteIter=remotePtrs.begin(); remoteIter!=remotePtrs.end(); ++remoteIter )
      {
        pid = remoteIter->second;
        pVertexVtxRemCopy = (pVertex*)msg_send;
        *pVertexVtxRemCopy = remoteIter->first;
        pdVtxCoords = (double*)((char*)msg_send + sizeof(pVertex));

        // get the target
        GetTarget(ent, pdVtxTarget);
        for (int iIt = 0; iIt < 3; ++iIt)
          pdVtxCoords[iIt] = pdVtxTarget[iIt]; 

        CM->send(pid, (void*)msg_send);
        num_sent++;
      }
    }
    snapIter++;
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;

  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    vertex = *(pVertex*)msg_recv;

    if((EN_levelInBL(vertex) < 0) && (std::find(pSnaplist->begin(), pSnaplist->end(), vertex) == pSnaplist->end()))
    {
      pdVtxCoords = (double*)((char*)msg_recv + sizeof(pVertex));
      pdVtxTarget = new double[3];
      for (int iIt = 0; iIt < 3; ++iIt)
        pdVtxTarget[iIt] = pdVtxCoords[iIt];
      append(vertex, pdVtxTarget);
    }
    CM->free_msg(msg_recv);
  }

  return;
}

#endif /* MA_PARALLEL */
#endif /* AOMD_ */ 


